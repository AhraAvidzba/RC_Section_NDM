﻿# ==================== ДЛЯ ТЕСТОВ ====================
# В собственном Excel компилирует три компонента либо читает готовую копию без Save и пересчёта НДС.
param([ValidateSet('User','Template')][string]$Label,[switch]$Readback,[switch]$ResumeSavedCompile)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$phase='Compile';if($Readback){$phase='Readback'}
$dir=Join-Path $PSScriptRoot ($Label+$phase);[void][IO.Directory]::CreateDirectory($dir)
$path=Join-Path $dir 'RC_Section_NDM.xlsm'
if($Readback){$path=Join-Path $PSScriptRoot ($Label+'Final/RC_Section_NDM.xlsm')}else{
 $source=Join-Path $PSScriptRoot 'UserMainBefore.xlsm'
 if($Label -ceq 'Template'){$source=Join-Path $root 'docs/regression/PlotLayoutControls_2026-11-03_Run01/FreshBuild05/RC_Section_NDM.xlsm'}
 if(Test-Path -LiteralPath $path){if(-not $ResumeSavedCompile){throw 'Existing candidate refused'}}else{Copy-Item -LiteralPath $source -Destination $path}
}
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory;if($m.AvailableMBytes/1024 -lt 8 -or ($m.CommitLimit-$m.CommittedBytes)/1GB -lt 14){throw 'Insufficient native reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestHeaderOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object Id);$app=$null;$book=$null;$own=0;$ticks=0
try{
 $app=New-Object -ComObject Excel.Application;[uint32]$id=0;[void][TestHeaderOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($id -le 0 -or $existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;StartTicksUTC=[string]$ticks;Label=$Label;Phase=$phase}|ConvertTo-Json|Set-Content (Join-Path $dir 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 $book=$app.Workbooks.Open($path,0,[bool]$Readback)
 if($book.ReadOnly -ne [bool]$Readback){throw 'Wrong open mode'}
 if(-not $Readback){
  foreach($name in @('CStrengthSummaryWriter','CCrackSummaryWriter','CNDMResultsWriter')){
   $body=[regex]::Match([IO.File]::ReadAllText((Join-Path $root ('src/Excel/'+$name+'.cls')),[Text.Encoding]::UTF8),'(?ms)^Option Explicit.*').Value
   if(-not $body){throw 'Missing source body'};$module=$book.VBProject.VBComponents.Item($name).CodeModule;$module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($body)
  }
  $app.VBE.ActiveVBProject=$book.VBProject;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'VBA compile failed'}
  $book.Save()
 }else{
  if($Label -ceq 'User'){
   $changes=Get-Content (Join-Path $PSScriptRoot 'HeaderChanges.json') -Raw -Encoding UTF8|ConvertFrom-Json
   foreach($entry in $changes.PSObject.Properties){if($book.Worksheets.Item('Results').Range($entry.Name).Value2 -cne $entry.Value.After){throw ('Header readback failed '+$entry.Name)}}
  }
  $code=New-Object Text.StringBuilder;[void]$code.AppendLine('VBA PROJECT EXPORT');[void]$code.AppendLine('Workbook: '+$book.Name);[void]$code.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  foreach($component in $book.VBProject.VBComponents){
   [void]$code.AppendLine(('='*100));[void]$code.AppendLine('COMPONENT: '+$component.Name);[void]$code.AppendLine('TYPE: '+$component.Type);[void]$code.AppendLine('LINES: '+$component.CodeModule.CountOfLines);[void]$code.AppendLine(('='*100))
   if($component.CodeModule.CountOfLines){[void]$code.AppendLine($component.CodeModule.Lines(1,$component.CodeModule.CountOfLines))}
  }
  [IO.File]::WriteAllText((Join-Path $dir 'VBA_All_Code.txt'),$code.ToString(),[Text.UTF8Encoding]::new($true))
  if($Label -ceq 'User'){
   $sheet=$book.Worksheets.Item('Results');$app.Visible=$true;$sheet.Activate()
   foreach($area in @('R45:AA50','BG81:BT86','AN155:BD158','BR155:CI158','CL155:DI158','S155:X160')){
    $sheet.PageSetup.PrintArea=$sheet.Range($area).Address();$sheet.PageSetup.Orientation=2;$sheet.PageSetup.Zoom=$false;$sheet.PageSetup.FitToPagesWide=1;$sheet.PageSetup.FitToPagesTall=1
    $sheet.ExportAsFixedFormat(0,(Join-Path $dir ($area.Replace(':','_')+'.pdf')))
   }
  }
 }
 [ordered]@{Status='PASS';Label=$Label;Phase=$phase;Components=$book.VBProject.VBComponents.Count;NoNDSCalculation=$true;ReadOnly=[bool]$Readback;MemoryFreeGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Result.json') -Encoding UTF8
}finally{
 if($own){$proc=Get-Process -Id $own -ErrorAction Stop;if($proc.StartTime.ToUniversalTime().Ticks -ne $ticks){throw 'Owner changed'};if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($book)};if($app){$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
Write-Output ($Label+' '+$phase+' PASS')
