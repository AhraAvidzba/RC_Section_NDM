# ==================== ДЛЯ ТЕСТОВ ====================
# Публикует проверенные VBA и заголовки с CAS по исходным байтам; данные и чужие процессы не меняет.
$ErrorActionPreference='Stop'
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
function Test-Sha([byte[]]$Bytes){$hash=[Security.Cryptography.SHA256]::Create();try{return [BitConverter]::ToString($hash.ComputeHash($Bytes)).Replace('-','')}finally{$hash.Dispose()}}
foreach($file in @('UserPreservation.json','TemplatePreservation.json','HeaderUnitsNative.json')){if((Get-Content (Join-Path $PSScriptRoot $file) -Raw|ConvertFrom-Json).Status -cne 'PASS'){throw ('Missing pass '+$file)}}
foreach($file in @('UserSourceEquality.json','TemplateSourceEquality.json')){if(-not (Get-Content (Join-Path $PSScriptRoot $file) -Raw|ConvertFrom-Json).Passed){throw ('Missing source equality '+$file)}}
foreach($name in @('UserReadback','TemplateReadback','UserCompile','TemplateCompile')){if((Get-Content (Join-Path $PSScriptRoot ($name+'/Result.json')) -Raw|ConvertFrom-Json).Status -cne 'PASS'){throw ('Missing native '+$name)}}
$records=@();$identities=@{}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File -Filter '*Own*.json'){
 $o=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json;if(-not $o.PID -or -not $o.StartTicksUTC){continue};$key=[string]$o.PID+'/'+[string]$o.StartTicksUTC;if($identities.ContainsKey($key)){continue};$identities[$key]=$true
 $proc=Get-Process -Id ([int]$o.PID) -ErrorAction SilentlyContinue
 if($proc){if($proc.StartTime.ToUniversalTime().Ticks.ToString() -eq [string]$o.StartTicksUTC){throw ('Own still live '+$key)};$state='PIDReused'}else{$state='Absent'}
 $cim=@(Get-CimInstance Win32_Process -Filter ('ProcessId='+$o.PID))
 if($cim.Count){$expected=[long]$o.StartTicksUTC;$expected=$expected-($expected%10);if($cim[0].Name -ieq 'EXCEL.EXE' -and $cim[0].CreationDate.ToUniversalTime().Ticks -eq $expected){throw ('CIM own live '+$key)}}
 $records+=,[ordered]@{PID=$o.PID;StartTicksUTC=[string]$o.StartTicksUTC;State=$state;CIMFresh=$true}
}
if($records.Count -lt 7){throw 'Incomplete own inventory'}
[ordered]@{Status='PASS';Count=$records.Count;Identities=$records;NoForcedClosure=$true}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'AllOwnClosures.json') -Encoding UTF8
$paths=@((Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'),(Join-Path $root 'workbook/output/VBA_All_Code.txt'))
$before=@([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'UserMainBefore.xlsm')),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'AllCodeBefore.txt')))
$after=@([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'UserFinal/RC_Section_NDM.xlsm')),[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'UserReadback/VBA_All_Code.txt')))
$streams=@();$written=$false
try{
 foreach($path in $paths){$streams+=,[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
 for($i=0;$i -lt 2;$i++){$b=New-Object byte[] $streams[$i].Length;$read=0;while($read -lt $b.Length){$n=$streams[$i].Read($b,$read,$b.Length-$read);if($n -le 0){throw 'Unexpected EOF'};$read+=$n};if((Test-Sha $b) -cne (Test-Sha $before[$i])){throw ('Current file changed since backup '+$paths[$i])}}
 $written=$true
 for($i=0;$i -lt 2;$i++){$streams[$i].Position=0;$streams[$i].Write($after[$i],0,$after[$i].Length);$streams[$i].SetLength($after[$i].Length);$streams[$i].Flush($true)}
}catch{
 if($written){for($i=0;$i -lt 2;$i++){$streams[$i].Position=0;$streams[$i].Write($before[$i],0,$before[$i].Length);$streams[$i].SetLength($before[$i].Length);$streams[$i].Flush($true)}};throw
}finally{foreach($stream in $streams){$stream.Dispose()}}
for($i=0;$i -lt 2;$i++){if((Get-FileHash -LiteralPath $paths[$i]).Hash -cne (Test-Sha $after[$i])){throw 'Published bytes mismatch'}}
[ordered]@{Status='PASS';UserBookSHA256=(Test-Sha $after[0]);AllCodeSHA256=(Test-Sha $after[1]);OriginalUserBookSHA256=(Test-Sha $before[0]);HeaderCells=12;UserDataUnchanged=$true;NativeReopenVerified=$true;NoNDSRecalculation=$true;Backup='UserMainBefore.xlsm'}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'Publication.json') -Encoding UTF8
Write-Output 'PUBLICATION_PASS'
