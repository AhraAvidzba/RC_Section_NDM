﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Экспортирует только изображение Config собственной readonly-книги; изменения в книгу не сохраняет.
$ErrorActionPreference='Stop'
$path=Join-Path $PSScriptRoot 'ReleaseCandidate/Main/RC_Section_NDM.xlsm'
$hash=(Get-FileHash -LiteralPath $path).Hash
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient memory'}
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class TestPreviewOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$scratch=$null;$owned=0;$ticks=0
try{
 $app=New-Object -ComObject Excel.Application;$app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 [uint32]$id=0;[void][TestPreviewOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;SourceSHA256=$hash}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'NativePreviewOwnership.json') -Encoding UTF8
 $book=$app.Workbooks.Open($path,0,$true);if(-not$book.ReadOnly){throw 'Readonly expected'}
 $sheet=$book.Worksheets.Item('Config');$sheet.Activate();$range=$sheet.Range('A3:E28');$range.CopyPicture(1,-4147)
 $scratch=$app.Workbooks.Add();$chart=$scratch.Worksheets.Item(1).ChartObjects().Add(0,0,[double]$range.Width,[double]$range.Height)
 $chart.Activate();$chart.Chart.Paste();if(-not$chart.Chart.Export((Join-Path $PSScriptRoot 'NativeConfig.png'),'PNG')){throw 'Native picture export failed'}
}finally{
 if($scratch){$scratch.Close($false)};if($book){$book.Close($false)}
 if($app){$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 $scratch=$null;$book=$null;$app=$null;$sheet=$null;$range=$null;$chart=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ine'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Identity mismatch'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 200}while($watch.ElapsedMilliseconds-lt10000)
 [ordered]@{Passed=$absent;PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false;SourceUnchanged=((Get-FileHash -LiteralPath $path).Hash-ceq$hash)}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'NativePreviewClosure.json') -Encoding UTF8
 if(-not$absent){throw 'Own Excel exit not proven'}
}
if((Get-FileHash -LiteralPath $path).Hash-cne$hash){throw 'Preview changed source book'}
Write-Output 'NATIVE_PREVIEW_EXPORTED; source unchanged; own Excel absent'
