﻿# ДЛЯ ТЕСТОВ: фиксирует исходные книги и проверяет каталог/PS5 до нативной сборки.
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
. (Join-Path $root 'tools/build_workbook/WorkbookLayout.ps1')
. (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
$files=@('tools/build_workbook/SettingsCatalog.ps1','tools/build_workbook/WorkbookLayout.ps1','tools/build_workbook/Build-Workbook.ps1','tools/build_workbook/Measure-SnapshotIOPhases.ps1','tools/build_workbook/Run-Audit02SnapshotReopen.ps1','tools/build_workbook/Test-BatchSummaryLoads.ps1','tools/build_workbook/Test-MultipleSnapshotFiles.ps1','tools/build_workbook/Prepare-PerformanceWorkbook.ps1','tools/build_workbook/Test-DependentRowsTemplate.ps1')
$parses=@()
foreach($path in $files){$tokens=$null;$errors=$null;[void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path $root $path),[ref]$tokens,[ref]$errors);if(@($errors).Count){throw ('PS5 parse error: '+$path)};$parses+=,[ordered]@{Path=$path;ParseErrors=0;SHA256=(Get-FileHash -LiteralPath $path).Hash}}
$catalog=@(Get-SystemSettingsCatalog)
$block=@($catalog|Where-Object{$_.Name -eq'LoadDiagramSettings'})
if($block.Count -ne1 -or $block[0].Title -cne'[Нагрузки, сочетания и диаграммы материалов]'){throw 'Wrong common section'}
$keys=@($block[0].Rows|ForEach-Object{[string]$_[0]})
$expected=@('[Нагрузки]','Load.ReferenceOffsetX','Load.ReferenceOffsetY','Calculation.ZeroMomentPerDepth','[Выводимое сочетание]','Output.CombinationMode','General.WorstCombinationCriterion','Output.CombinationID','[Диаграммы материалов]','General.PlateauSlopeFactor','General.DiagramExtension')
if(($keys -join'|') -cne($expected -join'|')){throw 'Requested subsection/selector order differs'}
$allKeys=@($catalog|ForEach-Object{$_.Rows}|ForEach-Object{[string]$_[0]})
if(@($allKeys|Where-Object{$_ -in@('Plot.LoadCase','AutoCAD.Export.CombinationID','[Импорт]')}).Count){throw 'Obsolete keys/header remain'}
$row=4;foreach($section in $catalog){$row+=1+@($section.Rows).Count+1}
if($row-2 -ne149){throw ('Actual catalog ends at unexpected row: '+($row-2))}
$nativeBefore=@(Get-Process -Name EXCEL,acad -ErrorAction SilentlyContinue|ForEach-Object{[ordered]@{Name=$_.ProcessName;PID=$_.Id;UTCStartTicks=[string]$_.StartTime.ToUniversalTime().Ticks}})
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$memory=[ordered]@{FreeRAMGiB=[double]$m.AvailableMBytes/1024;FreeCommitGiB=([double]$m.CommitLimit-[double]$m.CommittedBytes)/1GB;RequiredRAMGiB=8;RequiredCommitGiB=14}
if($memory.FreeRAMGiB -lt8 -or $memory.FreeCommitGiB -lt14){throw 'Native reserve8RAM/14commit unavailable'}
$books=@();foreach($path in @('workbook/output/RC_Section_NDM.xlsm','workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm','workbook/output/VBA_All_Code.txt')){$books+=,[ordered]@{Path=$path;SHA256=(Get-FileHash -LiteralPath $path).Hash}}
$proof=[ordered]@{Status='SOURCE_PREPARED_BOOKS_NOT_CHANGED';TimeUTC=[DateTimeOffset]::UtcNow.ToString('o');Branch=(& git branch --show-current);BaseCommit=(& git rev-parse HEAD);CatalogOrder=$keys;SystemSettingsLastRow=$row-2;PS5Parses=$parses;BeforeNative=$nativeBefore;Memory=$memory;OriginalPublished=$books;SubsectionUserApproved='Выводимое сочетание';SelectionKeysUserApproved=@('Output.CombinationMode','Output.CombinationID');OldFullPassAppliesOnlyToOriginalSHA=$true;NewFullAuthorized=$false;NativeStarted=$false}
$proof|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'SourcePreparation.json') -Encoding UTF8
[pscustomobject]@{Status=$proof.Status;PS5Files=$parses.Count;SettingsLastRow=$row-2;Memory=$memory;UserNativeUntouched=$nativeBefore.Count}|ConvertTo-Json -Depth 5
