// ДЛЯ ТЕСТОВ: только читает XLSM для локальной визуальной проверки; экспорт книги не выполняется.
import fs from 'node:fs/promises';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';
const [source, output, range = 'A3:E28'] = process.argv.slice(2);
if (!source || !output) throw new Error('Source workbook and preview path required');
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(source));
const preview = await workbook.render({ sheetName: 'Config', range, scale: 1.5, format: 'png' });
await fs.writeFile(output, new Uint8Array(await preview.arrayBuffer()));
console.log(JSON.stringify({ status: 'READONLY_CONFIG_PREVIEW', range, output, workbookExported: false }));
