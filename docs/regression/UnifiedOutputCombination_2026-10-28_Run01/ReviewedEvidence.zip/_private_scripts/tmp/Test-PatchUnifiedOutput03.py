"""ДЛЯ ТЕСТОВ: явно переводит тестовые сценарии и действующие пояснения на общий выбор."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'tmp/Test-PatchUnifiedOutput01.py').read_text(encoding='utf-8')
namespace = {'__file__': str(ROOT / 'tmp/Test-PatchUnifiedOutput01.py')}
exec(compile(source[:source.index("TestEdit('src/Excel/modSectionSnapshot.bas'")], namespace['__file__'], 'exec'), namespace)
TestEdit, TestReplace = namespace['TestEdit'], namespace['TestReplace']
OLD = r'(?:Plot\.LoadCase|AutoCAD\.Export\.CombinationID)'


def TestPatchCalls(text):
    """ДЛЯ ТЕСТОВ: прежний выбор сценария теперь задаёт оба новых поля явно."""
    text = re.sub(r'\b(?:TestSetSystemSetting|TestSnapshotSetting|TestPerformanceSetting) "' + OLD + r'", ', 'modTestPlotConfig.TestSetOutputCombination ThisWorkbook, ', text)
    text = re.sub(r'\bTestAudit03SetPlotSetting ([^,\n]+), "' + OLD + r'", ', r'TestSetOutputCombinationInTable \1, ', text)
    text = re.sub(r'\bTestSetValue (\w+), "' + OLD + r'", ', r'modTestPlotConfig.TestSetOutputCombinationInTable \1, ', text)
    text = re.sub(r'\bTestSetTableValue (\w+), "' + OLD + r'", ("[^"]*"), 2', r'modTestPlotConfig.TestSetOutputCombinationInTable \1, \2', text)
    if 'TestAssertRequiredKeys' in text:
        text = text.replace('"Plot.LoadCase"', '"Output.CombinationMode"')
    else:
        text = text.replace('"Plot.LoadCase"', '"Output.CombinationID"')
    return text.replace('"AutoCAD.Export.CombinationID"', '"Output.CombinationID"')


files = []
for folder in ('tests', 'tools/build_workbook'):
    for path in (ROOT / folder).glob('*.bas'):
        if path.name == 'modTestRecipeSetbacks.bas':
            continue
        content = path.read_text(encoding='utf-8-sig')
        if 'Plot.LoadCase' in content or 'AutoCAD.Export.CombinationID' in content:
            files.append(path.relative_to(ROOT).as_posix())
for relative in files:
    TestEdit(relative, TestPatchCalls)


def TestPatchFixtures(text):
    """ДЛЯ ТЕСТОВ: автономные reader-fixtures содержат режим, а не полагаются на default."""
    pattern = r'(?m)^Private (?:Sub|Function) [^\n]*\n[\s\S]*?^End (?:Sub|Function)'
    def TestOne(match):
        block = match.group(0)
        if 'configuration(2, 1) = "Output.CombinationID"' not in block:
            return block
        assert 'configuration(1 To 2, 1 To 3)' in block
        block = block.replace('configuration(1 To 2, 1 To 3)', 'configuration(1 To 3, 1 To 3)')
        if 'configuration(2, 2) = "Worst"' in block:
            block = block.replace('configuration(2, 2) = "Worst"', 'configuration(2, 2) = vbNullString')
            mode = 'Worst'
        else:
            mode = 'User'
        block = re.sub(r'(?m)^(    configuration\(2, 1\) = "Output.CombinationID"[^\n]*)$', r'\1\n    configuration(3, 1) = "Output.CombinationMode": configuration(3, 2) = "' + mode + '"', block)
        block = block.replace('.Resize(2, 3).Value2 = configuration', '.Resize(3, 3).Value2 = configuration')
        block = re.sub(r'(settings.LoadFromRange sheet.Range\("AO(?:5|70)"\))\.Resize\(2, 3\)', r'\1.Resize(3, 3)', block)
        return block
    return re.sub(pattern, TestOne, text)


TestEdit('tests/modTestWorkbookInterface.bas', TestPatchFixtures)

HELPERS = '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задаёт логический выбор тестового сценария двумя реальными полями Config.
' Строка Worst здесь означает режим теста; отдельные проверки задают буквальный ID Worst напрямую.
Public Sub TestSetOutputCombination(ByVal workbook As Object, ByVal requested As Variant)
    TestSetOutputCombinationInTable workbook.Names.Item("rngSystemSettings").RefersToRange, requested
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Работает только с явно подготовленной тестовой таблицей, не создавая отсутствующих ключей.
Public Sub TestSetOutputCombinationInTable(ByVal table As Object, ByVal requested As Variant)
    Dim mode As String: mode = "User"
    If VarType(requested) = vbString Then
        If StrComp(Trim$(CStr(requested)), "Worst", vbTextCompare) = 0 Then mode = "Worst"
    End If
    TestAudit03PlotSettingCell(table, "Output.CombinationMode").Value2 = mode
    If mode = "User" Then TestAudit03PlotSettingCell(table, "Output.CombinationID").Value2 = requested
End Sub
'''
TestEdit('tests/modTestPlotConfig.bas', lambda text: text + HELPERS)

# Матрица отрицательных CAD-проверок передаёт имя ключа переменной; режим User задаётся перед потреблением ID.
def TestPatchCadNegative(text):
    marker = '    ElseIf key = "Output.CombinationID" Then\n        text = Audit02ReadExportSnapshotForTests(ThisWorkbook)'
    return TestReplace(text, marker, '    ElseIf key = "Output.CombinationID" Then\n        TestSetValue ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange, "Output.CombinationMode", "User"\n        text = Audit02ReadExportSnapshotForTests(ThisWorkbook)')
TestEdit('tests/modTestAutoCADConfig.bas', TestPatchCadNegative)

for name in ('CBatchResultWriter.cls',):
    TestEdit('src/Excel/' + name, lambda text: text.replace('Plot.LoadCase = Worst', 'Output.CombinationMode = Worst'))
TestEdit('src/Batch/CBatchSectionCalculator.cls', lambda text: text.replace('Его же используют схема Plot.LoadCase = Worst и экспорт AutoCAD\n\' с AutoCAD.Export.CombinationID = Worst.', 'Его же используют схема Excel и экспорт AutoCAD\n\' при Output.CombinationMode = Worst.'))


def TestPatchGuide(text):
    """ДЛЯ ТЕСТОВ: пользователь видит один последовательный выбор для всех способов вывода."""
    text = TestReplace(text, '`Plot.LoadCase` задаёт конкретный `CombinationID` либо `Worst`. Выбирайте сочетание, которое действительно сохранено в текущем источнике.', '`Output.CombinationMode` задаёт единый режим для схемы Excel и экспорта AutoCAD: `Worst` либо `User`.\n\nВ подразделе **[Выводимое сочетание]** настройки идут в порядке: режим, критерий выбора Worst, ID пользовательского сочетания. В режиме `User` выберите `Output.CombinationID`, который действительно сохранён в текущем источнике. В режиме `Worst` это поле не используется; схема и экспорт берут определяющее сочетание сохранённого расчёта.')
    text = TestReplace(text, 'Выбор сочетания AutoCAD задаётся отдельно от выбора схемы Excel: `AutoCAD.Export.CombinationID`. Для обеих задач можно использовать Worst либо конкретное имя.', 'Схема Excel и экспорт AutoCAD используют общий выбор `Output.CombinationMode` и `Output.CombinationID`. Менять сочетание отдельно для AutoCAD не требуется.')
    text = TestReplace(text, '2. Укажите нужный `Plot.LoadCase`.', '2. Выберите `Output.CombinationMode = User` и нужный `Output.CombinationID` либо режим `Worst`.')
    text = TestReplace(text, 'Для AutoCAD задайте `AutoCAD.Export.CombinationID` и повторите экспорт. Это не изменяет нагрузки сохранённого расчёта.', 'Для AutoCAD повторите экспорт с тем же общим выбором сочетания. Это не изменяет нагрузки сохранённого расчёта.')
    text = TestReplace(text, '- `Plot.LoadCase` — сочетание.', '- `Output.CombinationMode` — общий режим Worst/User для схемы и AutoCAD.\n- `Output.CombinationID` — ID при режиме User; список напрямую связан с таблицей сочетаний Config.')
    text = TestReplace(text, '- `AutoCAD.Export.CombinationID` — сочетание выгрузки.\n', '')
    return text.replace('[Нагрузки и диаграммы материалов]', '[Нагрузки, сочетания и диаграммы материалов]')
TestEdit('docs/NDM_User_Guide.md', TestPatchGuide)
print('PATCHED_TEST_CALLS_EXPLICIT_FIXTURES_AND_USER_GUIDE; REGISTRY_TESTS_AND_NATIVE_PENDING')
