"""ДЛЯ ТЕСТОВ: переносит согласованный выбор сочетания в существующие слои и сборку."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def TestEdit(relative, transform):
    """ДЛЯ ТЕСТОВ: сохраняет исходную кодировку и CRLF затронутого файла."""
    path = ROOT / relative
    raw = path.read_bytes()
    bom = b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b''
    text = raw.decode('utf-8-sig').replace('\r\n', '\n')
    changed = transform(text)
    assert changed != text, relative
    path.write_bytes(bom + changed.replace('\n', '\r\n').encode('utf-8'))


def TestReplace(text, old, new):
    """ДЛЯ ТЕСТОВ: требует единственного исходного фрагмента вместо приблизительной подмены."""
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new, 1)


def TestRemovePrivate(text, name):
    """ДЛЯ ТЕСТОВ: убирает только конкретный прежний частный resolver с его шапкой."""
    pattern = r"(?m)^(?:'[^\n]*\n)*Private Function " + name + r"\b[^\n]*\n[\s\S]*?^End Function\n\n?"
    changed, count = re.subn(pattern, '', text)
    assert count == 1, name
    return changed


def TestPatchSnapshot(text):
    """ДЛЯ ТЕСТОВ: единый resolver читает только активный источник уже сохранённых данных."""
    marker = "' Читает собственную геометрию один раз блочными таблицами Results."
    code = '''' Выбирает одно сочетание для схемы и AutoCAD по общим настройкам Config.
' User читает только ID; Worst игнорирует ID и использует сохранённый итог расчёта.
' При отсутствии определяющей строки сохранённые состояния проверяются в прежнем порядке.
Public Function ReadOutputCombinationID(ByVal workbook As Object, ByVal settings As CSystemSettingsReader) As String
    Dim mode As String: mode = settings.GetRequiredChoice("Output.CombinationMode", Array("Worst", "User"))
    If mode = "User" Then
        ReadOutputCombinationID = settings.GetRequiredString("Output.CombinationID")
        Exit Function
    End If
    ReadOutputCombinationID = ReadSavedWorstCombinationID(workbook)
    If Len(ReadOutputCombinationID) = 0 Then ReadOutputCombinationID = FirstOutputCombinationInTable(workbook, "rngNDMElementResults")
    If Len(ReadOutputCombinationID) = 0 Then ReadOutputCombinationID = FirstOutputCombinationInTable(workbook, "rngNDMSectionProperties")
    If Len(ReadOutputCombinationID) = 0 Then Err.Raise vbObjectError + 4702, "ReadOutputCombinationID", _
        settings.InputErrorMessage("Output.CombinationMode", _
            "В сохранённом снимке нет определяющего или другого рассчитанного сочетания для режима Worst.", _
            "Выполните расчёт либо выберите User и ID сочетания, уже сохранённого в текущем снимке.")
End Function

' Возвращает первое сохранённое сочетание, если верхняя сводка не содержит Worst.
' Общие свойства ALL не являются сочетанием. Отсутствующая необязательная таблица пропускается.
Private Function FirstOutputCombinationInTable(ByVal workbook As Object, ByVal rangeName As String) As String
    On Error GoTo Failed
    Dim data As Variant: data = ReadAnchoredResultTable(workbook, rangeName)
    If Not HasResultTableRows(data) Then Exit Function
    Dim column As Long: column = ResultColumn(data, "LoadCase")
    Dim row As Long, candidate As String
    For row = 2 To UBound(data, 1)
        candidate = Trim$(SafeText(data(row, column)))
        If Len(candidate) > 0 Then
            If rangeName <> "rngNDMSectionProperties" Or StrComp(candidate, "ALL", vbTextCompare) <> 0 Then
                FirstOutputCombinationInTable = candidate: Exit Function
            End If
        End If
    Next row
Failed:
End Function

'''
    return TestReplace(text, marker, code + marker)


def TestPatchPlot(text):
    """ДЛЯ ТЕСТОВ: схема использует общий выбор, оставляя собственное чтение комментария."""
    old = '    mLoadCase = ResolveLoadCase(workbook, settings.GetRequiredString("Plot.LoadCase"))'
    assert text.count(old) == 2
    text = text.replace(old, '    mLoadCase = ReadOutputCombinationID(workbook, settings)\n    mLoadCaseComment = ReadBatchSummaryComment(workbook, mLoadCase)')
    for name in ('ResolveLoadCase', 'ReadWorstCombinationID', 'FirstCalculatedLoadCaseFromResults', 'FirstLoadCaseFromSectionProperties'):
        text = TestRemovePrivate(text, name)
    return text


def TestPatchExport(text):
    """ДЛЯ ТЕСТОВ: экспорт не имеет отдельного селектора и не трактует ID как команду Worst."""
    text = TestReplace(text, 'combinationID = ResolveExportCombinationID(workbook, settings.GetRequiredString("AutoCAD.Export.CombinationID"))', 'combinationID = ReadOutputCombinationID(workbook, settings)')
    text = TestReplace(text, 'settings.InputErrorMessage("AutoCAD.Export.CombinationID", _', 'settings.InputErrorMessage("Output.CombinationID", _')
    text = TestReplace(text, '"Выберите Worst или ID сохраненного сочетания; для новых нагрузок сначала выполните расчет.")', '"Выберите Output.CombinationMode = Worst либо User и ID сохранённого сочетания; для новых нагрузок сначала выполните расчёт.")')
    for name in ('ResolveExportCombinationID', 'ReadGoverningCombinationID', 'FirstCalculatedLoadCaseFromResults', 'FirstLoadCaseFromSectionProperties'):
        text = TestRemovePrivate(text, name)
    return text


def TestPatchCatalog(text):
    """ДЛЯ ТЕСТОВ: меняет только согласованные строки и прямые источники двух списков."""
    start = text.index('        @{ Name = "LoadDiagramSettings";')
    end = text.index('        @{ Name = "GeometrySettings";', start)
    block = '''        @{ Name = "LoadDiagramSettings"; Title = "[Нагрузки, сочетания и диаграммы материалов]"; Rows = @(
            @("[Нагрузки]", "", "-", ""),
            @("Load.ReferenceOffsetX", "0", "мм", "Смещение точки приложения нагрузок по X относительно центра тяжести бетонного сечения без учёта арматуры."),
            @("Load.ReferenceOffsetY", "0", "мм", "Смещение точки приложения нагрузок по Y относительно центра тяжести бетонного сечения. Рабочие моменты для решателя автоматически переносятся к координатам расчётных элементов."),
            @("Calculation.ZeroMomentPerDepth", "0.0005", "Н*мм/мм", "Порог обнуления малых моментов: M_tol = значение·h. Убирает численный остаток после переносов и поворотов; слишком большое значение может обнулить значимый малый момент."),
            @("[Выводимое сочетание]", "", "-", ""),
            @("Output.CombinationMode", "Worst", "-", "Общий выбор сочетания для схемы Excel и экспорта AutoCAD: Worst — определяющее сочетание сохранённого расчёта; User — сочетание из Output.CombinationID."),
            @("General.WorstCombinationCriterion", "StrengthCapacity", "-", "Критерий выбора сочетания Worst при расчёте: прочность по деформациям, прочность по несущей, трещины или устойчивость. Схема и экспорт используют сохранённый выбор."),
            @("Output.CombinationID", "", "-", "ID сочетания для схемы и экспорта при Output.CombinationMode = User. Список берётся непосредственно из таблицы сочетаний; в режиме Worst поле не используется."),
            @("[Диаграммы материалов]", "", "-", ""),
            @("General.PlateauSlopeFactor", "0.001", "-", "Коэффициент α определяет наклон ненулевых плато бетона и арматуры: Et = α·E. По умолчанию α = 0,001, наклон плато — 0,001·E (0,1% от E своей ветви). 0 — горизонтальное плато. Наклон помогает сходимости и меняет напряжения; предельные деформации сохраняются."),
            @("General.DiagramExtension", "Yes", "-", "Численное продолжение диаграмм: продолжает активные ветви за физическими пределами. Рекомендуется для сходимости и диагностики. Не увеличивает физические пределы и не делает состояние в продолжении допустимым. При No работают обычные диаграммы.")
        )},
'''
    text = text[:start] + block + text[end:]
    for pattern in (r'^            @\("\[Импорт\]"[^\n]*\n', r'^            @\("AutoCAD.Export.CombinationID"[^\n]*\n', r'^            @\("Plot.LoadCase"[^\n]*\n'):
        text, count = re.subn(pattern, '', text, flags=re.M)
        assert count == 1, pattern
    text = TestReplace(text, '        "General.WorstCombinationCriterion" = @("StrengthStrain", "StrengthCapacity", "Cracks", "Stability")', '        "Output.CombinationMode" = @("Worst", "User")\n        "General.WorstCombinationCriterion" = @("StrengthStrain", "StrengthCapacity", "Cracks", "Stability")')
    start = text.index("    $exportCombinationListColumn = Get-NextConfigValidationColumn $Sheet 'LoadCases'")
    end = text.index('    Add-CalculationProfilesValidation $Sheet', start)
    direct = '''    $loads = $Workbook.Names.Item("rngLoadCombinations").RefersToRange
    $combinationSource = $loads.Cells.Item(2, 1).Resize($loads.Rows.Count - 1, 1)
    $combinationListAddress = '=' + $combinationSource.Address($true, $true) # Прямой столбец ID без заголовка и отдельного служебного Worst.
    for ($r = 2; $r -le $settingsRange.Rows.Count; $r++) {
        if ([string]$settingsRange.Cells.Item($r, 1).Value2 -eq "Output.CombinationID") {
            $cell = $settingsRange.Cells.Item($r, 2)
            $cell.Validation.Delete()
            $cell.Validation.Add(3, 1, 1, $combinationListAddress)
            $cell.Validation.IgnoreBlank = $true # Поле не обязательно в режиме Worst; User проверяет выбранный ID при действии.
            $cell.Validation.InCellDropdown = $true
        }
    }
'''
    text = text[:start] + direct + text[end:]
    start = text.index("    $ListColumn = Get-NextConfigValidationColumn $Sheet 'LoadProfiles'")
    end = text.index('    $profileInputRange = ', start)
    text = text[:start] + '''    $source = $profilesRange.Cells.Item($displayRow, 3).Resize(1, $profileCount)
    $listAddress = '=' + $source.Address($true, $true) # Имена профилей непосредственно из строки Profile.DisplayName (J39:M39).
''' + text[end:]
    text = text.replace('# Ячейки сочетаний остаются обычным пользовательским вводом без формул; динамика\n# сидит только в служебном списке, который ссылается на строку Profile.DisplayName.', '# Ячейки сочетаний остаются обычным вводом; проверка данных прямо ссылается\n# на видимую строку Profile.DisplayName, без скрытой копии имён профилей.')
    return text


TestEdit('src/Excel/modSectionSnapshot.bas', TestPatchSnapshot)
TestEdit('src/Excel/CSectionPlotDataReader.cls', TestPatchPlot)
TestEdit('src/Excel/modAutoCADStressExport.bas', TestPatchExport)
TestEdit('tools/build_workbook/SettingsCatalog.ps1', TestPatchCatalog)
print('PATCHED_SHARED_RESOLVER_AND_CATALOG_ONLY; HELP_TESTS_LAYOUT_NATIVE_PENDING')
