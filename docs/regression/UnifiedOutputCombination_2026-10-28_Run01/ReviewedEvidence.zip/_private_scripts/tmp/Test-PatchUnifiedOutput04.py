"""ДЛЯ ТЕСТОВ: обновляет оставшиеся штатные probes и проверку списка типов без скрытых ячеек."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'tmp/Test-PatchUnifiedOutput01.py').read_text(encoding='utf-8')
namespace = {'__file__': str(ROOT / 'tmp/Test-PatchUnifiedOutput01.py')}
exec(compile(source[:source.index("TestEdit('src/Excel/modSectionSnapshot.bas'")], namespace['__file__'], 'exec'), namespace)
TestEdit, TestReplace = namespace['TestEdit'], namespace['TestReplace']

def TestOnce(relative, old, new):
    """ДЛЯ ТЕСТОВ: продолжает уже частично завершённый перенос, не перезаписывая его повторно."""
    current = (ROOT / relative).read_text(encoding='utf-8-sig')
    if old not in current:
        assert new in current, relative
        return
    TestEdit(relative, lambda text: TestReplace(text, old, new))


TestOnce('tools/build_workbook/Measure-SnapshotIOPhases.ps1', "            Set-TestSnapshotPhaseSetting 'Plot.LoadCase' ([string]$allLoads[2,1])", "            Set-TestSnapshotPhaseSetting 'Output.CombinationMode' 'User'\n            Set-TestSnapshotPhaseSetting 'Output.CombinationID' ([string]$allLoads[2,1])")
TestOnce('tools/build_workbook/Run-Audit02SnapshotReopen.ps1', '    TestSetSystemSetting "AutoCAD.Export.CombinationID", "LC1"', '    modTestPlotConfig.TestSetOutputCombination ThisWorkbook, "LC1"')
TestOnce('tools/build_workbook/Test-BatchSummaryLoads.ps1', "@('Plot.LoadCase','Worst')", "@('Output.CombinationMode','Worst')")
TestOnce('tools/build_workbook/Test-MultipleSnapshotFiles.ps1', "        Test-SetSnapshotInput 'Plot.LoadCase' 'Worst'\n        Test-SetSnapshotInput 'AutoCAD.Export.CombinationID' 'Worst'", "        Test-SetSnapshotInput 'Output.CombinationMode' 'Worst'")
TestOnce('tests/modTestWorkbookInterface.bas', "' При Plot.LoadCase = Worst схема", "' При Output.CombinationMode = Worst схема")


def TestPatchRegistryTests(text):
    """ДЛЯ ТЕСТОВ: обновление реестра меняет только validation и сохраняет все пользовательские данные."""
    start = text.index("' обновление реестра не перестраивает Config")
    end = text.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Сравнивает весь Config", start)
    new = '''' Обновление реестра меняет только встроенный список, без служебных ячеек и таблиц геометрии.
Public Function RunRecipeTypeListTests() As String
    Dim config As Object, system As Object, typeKey As Object, typeCell As Object, saved As Variant, expected As Variant
    Dim ids As Variant, choices As String, originalValidation As String, originalCircle As String, brokenCircle As String
    Dim i As Long, count As Long, code As Long, absent As Boolean, unused As Object
    Dim calculation As Long, events As Boolean, updating As Boolean, alerts As Boolean
    On Error GoTo Failed
    mPassed = 0: mFailed = 0: mReport = ""
    calculation = Application.Calculation: events = Application.EnableEvents
    updating = Application.ScreenUpdating: alerts = Application.DisplayAlerts
    Set config = ThisWorkbook.Worksheets("Config").UsedRange: saved = TestFixtureSaveInputs(config)
    Set system = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For i = 2 To system.Rows.Count
        If CStr(system.Cells(i, 1).Value2) = "Geometry.Type" Then Set typeKey = system.Cells(i, 1): Set typeCell = system.Cells(i, 2)
    Next i
    If typeCell Is Nothing Then Err.Raise 5, "RunRecipeTypeListTests", "Geometry.Type отсутствует в тестовой книге."
    originalValidation = typeCell.Validation.Formula1
    originalCircle = ThisWorkbook.Names("rngCircleGeometry").RefersTo
    ids = RegisteredSectionRecipeTypes: count = UBound(ids) - LBound(ids) + 1
    choices = Join(ids, CStr(Application.International(xlListSeparator)))
    Application.Calculation = xlCalculationManual: Application.EnableEvents = False
    Application.ScreenUpdating = False: Application.DisplayAlerts = False
    ThisWorkbook.Names("rngCircleGeometry").RefersTo = "=#REF!" ' Повреждённая таблица геометрии не нужна обновлению списка.
    brokenCircle = ThisWorkbook.Names("rngCircleGeometry").RefersTo
    typeCell.Validation.Delete: typeCell.Validation.Add xlValidateList, xlValidAlertStop, xlBetween, "stale choice"
    expected = config.Formula: modSectionRecipeSetup.UpdateSectionRecipeTypes
    TestCheck "types.config.allValuesPreserved", TestSameConfigOutsideTypeList(config, expected, Nothing)
    TestCheck "types.current.selection", TestSameConfigOutsideTypeList(config, saved, Nothing)
    TestCheck "types.unrelated.name", ThisWorkbook.Names("rngCircleGeometry").RefersTo = brokenCircle
    TestCheck "types.inline", Left$(typeCell.Validation.Formula1, 1) <> "="
    TestCheck "types.registered.all", Replace$(typeCell.Validation.Formula1, ";", ",") = Replace$(choices, ";", ",")
    TestCheck "types.dropdown", typeCell.Validation.Type = xlValidateList And typeCell.Validation.InCellDropdown
    On Error Resume Next
    Set unused = ThisWorkbook.Names("rngSectionRecipeTypes"): absent = Err.Number <> 0: Err.Clear
    On Error GoTo Failed
    TestCheck "types.noHelperName", absent
    TestCheck "types.state.success", Application.Calculation = xlCalculationManual And Not Application.EnableEvents And Not Application.ScreenUpdating And Not Application.DisplayAlerts
    expected = config.Formula: modSectionRecipeSetup.UpdateSectionRecipeTypes
    TestCheck "types.idempotent", TestSameConfigOutsideTypeList(config, expected, Nothing) And Replace$(typeCell.Validation.Formula1, ";", ",") = Replace$(choices, ";", ",")
    typeKey.Value2 = "Missing.Geometry.Type": expected = config.Formula
    On Error Resume Next
    modSectionRecipeSetup.UpdateSectionRecipeTypes: code = Err.Number: Err.Clear
    On Error GoTo Failed
    TestCheck "types.missing.rejected", code <> 0
    TestCheck "types.missing.data", TestSameConfigOutsideTypeList(config, expected, Nothing)
    TestCheck "types.state.failure", Application.Calculation = xlCalculationManual And Not Application.EnableEvents And Not Application.ScreenUpdating And Not Application.DisplayAlerts
    GoTo Restore
Failed:
    TestCheck "types.runtime; " & CStr(Err.Number) & "; " & Err.Description, False
Restore:
    On Error Resume Next
    If Len(originalCircle) > 0 Then ThisWorkbook.Names("rngCircleGeometry").RefersTo = originalCircle
    If Not config Is Nothing And Not IsEmpty(saved) Then TestFixtureRestoreInputs config, saved
    If Not typeCell Is Nothing And Len(originalValidation) > 0 Then
        typeCell.Validation.Delete: typeCell.Validation.Add xlValidateList, xlValidAlertStop, xlBetween, originalValidation
        typeCell.Validation.IgnoreBlank = False: typeCell.Validation.InCellDropdown = True
    End If
    Application.Calculation = calculation: Application.EnableEvents = events
    Application.ScreenUpdating = updating: Application.DisplayAlerts = alerts
    On Error GoTo 0
    RunRecipeTypeListTests = mReport & "TOTAL RECIPE TYPE LIST: passed=" & CStr(mPassed) & "; failed=" & CStr(mFailed) & vbCrLf
End Function

'''
    return text[:start] + new + text[end:]


TestEdit('tests/modTestRecipeSetbacks.bas', TestPatchRegistryTests)
TestEdit('AGENTS.md', lambda text: TestReplace(text, '- Экспорт, схема и повторный расчёт используют сохранённую геометрию', '- Схема Excel и экспорт AutoCAD выбирают одно сочетание через Output.CombinationMode = Worst/User и Output.CombinationID. Worst берёт сохранённый выбор расчёта и не читает пользовательский ID; User читает точный ID без специального значения Worst. Выпадающие списки ID и профиля ссылаются прямо на исходные видимые таблицы, без скрытых копий.\n- Экспорт, схема и повторный расчёт используют сохранённую геометрию') if '- Экспорт, схема и повторный расчёт используют сохранённую геометрию' in text else TestReplace(text, '- В режиме File весь снимок читается', '- Схема Excel и экспорт AutoCAD выбирают одно сочетание через Output.CombinationMode = Worst/User и Output.CombinationID. Worst берёт сохранённый выбор расчёта и не читает пользовательский ID; User читает точный ID без специального значения Worst. Выпадающие списки ID и профиля ссылаются прямо на исходные видимые таблицы, без скрытых копий.\n- В режиме File весь снимок читается'))
print('PATCHED_NATIVE_TEST_ORACLES_AND_DOCUMENTED_SHARED_CONTRACT')
