"""ДЛЯ ТЕСТОВ: переносит проверенные Config/VBA/Справку в частные копии, сохраняя Results побайтно."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
import hashlib, json, posixpath, re
from lxml import etree as X

ROOT = Path(__file__).resolve().parents[1]
E = ROOT / 'docs/regression/UnifiedOutputCombination_2026-10-28_Run01'
FRESH = E / 'FreshBuild02/RC_Section_NDM.xlsm'
S = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'
NS = {'s': S}
def tag(n): return '{'+S+'}'+n
def parse(data): return X.fromstring(data)
def dump(x): return X.tostring(x, encoding='UTF-8', xml_declaration=True, standalone=True)
def sha(data): return hashlib.sha256(data).hexdigest().upper()
def col(c):
    n=0
    for a in re.match('[A-Z]+', c).group(): n=n*26+ord(a)-64
    return n
def strings(data): return [''.join(e.itertext()) for e in parse(data)]
def value(c, ss):
    v=c.find(tag('v'))
    if v is None: return ''
    return ss[int(v.text)] if c.get('t')=='s' else v.text

def TestPackage(base_path, case):
    """ДЛЯ ТЕСТОВ: старые индексы строк/стилей и все нецелевые части остаются неизменными."""
    with ZipFile(base_path) as z: old={n:z.read(n) for n in z.namelist()}
    with ZipFile(FRESH) as z: fresh={n:z.read(n) for n in z.namelist()}
    out=dict(old)
    osst=parse(old['xl/sharedStrings.xml']); fsst=parse(fresh['xl/sharedStrings.xml'])
    oldstrings=strings(old['xl/sharedStrings.xml']); fstrings=strings(fresh['xl/sharedStrings.xml'])
    soff=len(osst)
    for item in fsst: osst.append(deepcopy(item))
    osst.set('uniqueCount',str(len(osst)))

    # Старые стили сохраняют номера: добавляются только эквивалентные наборы новой сборки.
    ost=parse(old['xl/styles.xml']); fst=parse(fresh['xl/styles.xml']); maps={}
    onum=ost.find(tag('numFmts')); fnum=fst.find(tag('numFmts'))
    num_map={}; used={int(n.get('numFmtId')) for n in onum} if onum is not None else set()
    if fnum is not None:
        if onum is None: onum=X.Element(tag('numFmts')); ost.insert(0,onum)
        for f in fnum:
            match=next((o for o in onum if o.get('formatCode')==f.get('formatCode')),None)
            if match is not None: new_id=int(match.get('numFmtId'))
            else:
                new_id=max(used|{163})+1; copy=deepcopy(f);copy.set('numFmtId',str(new_id));onum.append(copy);used.add(new_id)
            num_map[int(f.get('numFmtId'))]=new_id
        onum.set('count',str(len(onum)))
    for name in ['fonts','fills','borders','cellStyleXfs','cellXfs','dxfs']:
        fs=fst.find(tag(name)); os=ost.find(tag(name))
        if fs is None: continue
        if os is None: raise AssertionError('Unexpected missing style collection '+name)
        offset=len(os); maps[name]={i:offset+i for i in range(len(fs))}
        for item in fs:
            item=deepcopy(item)
            if name in ['cellXfs','cellStyleXfs']:
                for attr,collection in [('fontId','fonts'),('fillId','fills'),('borderId','borders'),('xfId','cellStyleXfs')]:
                    if attr in item.attrib: item.set(attr,str(maps[collection][int(item.get(attr))]))
                n=int(item.get('numFmtId','0'));item.set('numFmtId',str(num_map.get(n,n)))
            os.append(item)
        os.set('count',str(len(os)))
    out['xl/styles.xml']=dump(ost)

    def remap(x):
        for c in x.iter(tag('c')):
            if c.get('s') is not None: c.set('s',str(maps['cellXfs'][int(c.get('s'))]))
            if c.get('t')=='s':
                v=c.find(tag('v'));v.text=str(int(v.text)+soff)
        for row in x.iter(tag('row')):
            if row.get('s') is not None: row.set('s',str(maps['cellXfs'][int(row.get('s'))]))
        for c in x.iter(tag('col')):
            if c.get('style') is not None: c.set('style',str(maps['cellXfs'][int(c.get('style'))]))
        for r in x.iter(tag('cfRule')):
            if r.get('dxfId') is not None:r.set('dxfId',str(maps['dxfs'][int(r.get('dxfId'))]))
        return x

    config=parse(old['xl/worksheets/sheet1.xml']); fc=parse(fresh['xl/worksheets/sheet1.xml'])
    osd=config.find(tag('sheetData')); fsd=fc.find(tag('sheetData'))
    cells={c.get('r'):c for c in config.iter(tag('c'))}
    previous={}
    for row in osd:
        rr=row.get('r');a=cells.get('A'+rr);b=cells.get('B'+rr)
        if a is not None and b is not None: previous[value(a,oldstrings)]=deepcopy(b)
    for row in osd:
        for c in list(row):
            if col(c.get('r'))<=5 or 69<=col(c.get('r'))<=71:row.remove(c)
    preserved=[]
    for fr in fsd:
        rn=int(fr.get('r'))
        if rn>149:continue
        row=next((r for r in osd if r.get('r')==str(rn)),None)
        if row is None: row=X.SubElement(osd,tag('row'),r=str(rn))
        keycell=next((c for c in fr if c.get('r')=='A'+str(rn)),None)
        key=value(keycell,fstrings) if keycell is not None else ''
        for c in fr:
            if col(c.get('r'))>5:continue
            copy=remap(deepcopy(c))
            if col(c.get('r'))==2 and key in previous and key and not key.startswith('['):
                saved=deepcopy(previous[key]); saved.set('r',copy.get('r'))
                if copy.get('s') is not None:saved.set('s',copy.get('s'))
                copy=saved
                if key not in ['Config','Параметр']:preserved.append(key)
            row.append(copy)
        row[:]=sorted(row,key=lambda c:col(c.get('r')))
    osd[:]=sorted(osd,key=lambda r:int(r.get('r')))
    # Два динамических списка берутся из видимых источников, а не из старых копий BR:BS.
    for name in ['dataValidations','hyperlinks']:
        oldnode=config.find(tag(name));fn=fc.find(tag(name))
        if oldnode is None:raise AssertionError('Missing '+name)
        for item in list(oldnode):
            addr=item.get('sqref',item.get('ref',''))
            if col(addr.split(':')[0])<=5 or (name=='dataValidations' and addr=='L71:L100'):oldnode.remove(item)
        if fn is not None:
            for item in fn:
                addr=item.get('sqref',item.get('ref',''))
                if col(addr.split(':')[0])<=5 or (name=='dataValidations' and addr=='L71:L100'):oldnode.append(deepcopy(item))
        if name=='dataValidations':oldnode.set('count',str(len(oldnode)))
    for c in config.findall('s:cols/s:col',NS):c.attrib.pop('hidden',None)
    out['xl/worksheets/sheet1.xml']=dump(config)

    # Справка берётся целиком из свежей сборки; её рисунки копируются под частными именами.
    out['xl/worksheets/sheet3.xml']=dump(remap(parse(fresh['xl/worksheets/sheet3.xml'])))
    content=parse(old['[Content_Types].xml']); fcontent=parse(fresh['[Content_Types].xml'])
    overrides={c.get('PartName'):c.get('ContentType') for c in fcontent if X.QName(c).localname=='Override'}
    renamed={}
    def copy_part(name, root=False):
        if name in renamed:return renamed[name]
        if name.startswith('xl/media/') and old.get(name)==fresh[name]:
            renamed[name]=name
            return name
        dest=name if root else posixpath.join(posixpath.dirname(name),'ndm_unified_'+posixpath.basename(name))
        renamed[name]=dest;out[dest]=fresh[name]
        if not root:
            typ=overrides.get('/'+name)
            if typ and not any(c.get('PartName')=='/'+dest for c in content):X.SubElement(content,'{'+CT+'}Override',PartName='/'+dest,ContentType=typ)
        relpath=posixpath.join(posixpath.dirname(name),'_rels',posixpath.basename(name)+'.rels')
        if relpath in fresh:
            rel=parse(fresh[relpath])
            for r in rel:
                if r.get('TargetMode')=='External':continue
                target=posixpath.normpath(posixpath.join(posixpath.dirname(name),r.get('Target')))
                nd=copy_part(target)
                r.set('Target',posixpath.relpath(nd,posixpath.dirname(dest)))
            dr=posixpath.join(posixpath.dirname(dest),'_rels',posixpath.basename(dest)+'.rels');out[dr]=dump(rel)
        return dest
    # Не заменяем уже перенумерованные ячейки Справки сырым XML.
    help_bytes=out['xl/worksheets/sheet3.xml'];copy_part('xl/worksheets/sheet3.xml',True);out['xl/worksheets/sheet3.xml']=help_bytes
    for c in fcontent:
        if X.QName(c).localname=='Default' and not any(o.get('Extension')==c.get('Extension') for o in content):content.append(deepcopy(c))
    wb=parse(old['xl/workbook.xml']);fwb=parse(fresh['xl/workbook.xml']);names=wb.find(tag('definedNames'));fnames=fwb.find(tag('definedNames'))
    for n in list(names):
        if n.get('name') in ['rngSectionRecipeTypes','rngSystemSettings','rngSectionRecipeGuide']:names.remove(n)
    for n in fnames:
        if n.get('name') in ['rngSystemSettings','rngSectionRecipeGuide']:names.append(deepcopy(n))
    # Цепочка прежних формул указывает старые строки Config; Excel пересоздаст её штатно.
    out.pop('xl/calcChain.xml',None)
    wr=parse(old['xl/_rels/workbook.xml.rels'])
    for r in list(wr):
        if r.get('Type','').endswith('/calcChain'):wr.remove(r)
    for c in list(content):
        if c.get('PartName')=='/xl/calcChain.xml':content.remove(c)
    out['xl/_rels/workbook.xml.rels']=dump(wr);out['[Content_Types].xml']=dump(content)
    out['xl/workbook.xml']=dump(wb);out['xl/vbaProject.bin']=fresh['xl/vbaProject.bin']
    count=0
    for n,d in out.items():
        if re.match(r'xl/worksheets/sheet\d+\.xml$',n):
            count+=sum(1 for c in parse(d).iter(tag('c')) if c.get('t')=='s')
    osst.set('count',str(count));out['xl/sharedStrings.xml']=dump(osst)
    # Все нецелевые данные, в том числе рассчитанная тяжёлая геометрия/НДС, остаются побайтно.
    protected=['xl/worksheets/sheet2.xml','xl/worksheets/sheet4.xml','xl/worksheets/sheet5.xml']
    assert all(out[n]==old[n] for n in protected)
    target=E/'ReleaseCandidate'/case/'RC_Section_NDM.xlsm';target.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(target,'w',ZIP_DEFLATED) as z:
        for n,d in out.items():z.writestr(n,d)
    with ZipFile(target) as z:assert z.testzip() is None
    changed=[n for n in old if n not in out or old[n]!=out[n]]
    proof={'Case':case,'Base':str(base_path.relative_to(ROOT)),'BaseSHA256':sha(base_path.read_bytes()),'CandidateSHA256':sha(target.read_bytes()),'FreshCodeSHA256':sha(fresh['xl/vbaProject.bin']),'PreservedSettings':preserved,'PreservedSettingsCount':len(preserved),'ResultsAndSectionsAndPlotXMLUnchanged':True,'ChangedParts':changed,'AddedParts':[n for n in out if n not in old],'UnchangedParts':sum(n in out and old[n]==out[n] for n in old),'Mode':'Worst','NativeVerificationPending':True}
    (target.parent/'PackagePreservation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:proof[k] for k in ['Case','BaseSHA256','CandidateSHA256','PreservedSettingsCount','UnchangedParts','ChangedParts','AddedParts']},ensure_ascii=False))

for case,path in [('Main',ROOT/'workbook/output/RC_Section_NDM.xlsm'),('Ready',ROOT/'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm')]:TestPackage(path,case)
