"""ДЛЯ ТЕСТОВ: читает каждый первичный журнал и формирует ограниченную адресную приёмку."""
from pathlib import Path
import json,re,hashlib
R=Path(__file__).resolve().parents[1]
E=R/'docs/regression/UnifiedOutputCombination_2026-10-28_Run01'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
rows=[];total=0
specs=[('Directed02/Selector_No.txt',43,2),('Directed02/Selector_Yes.txt',43,2),('Directed02/Affected_No.txt',19527,7),('Directed02/Affected_Yes.txt',19527,7),('ReleaseSmoke/Main_No.txt',43,2),('ReleaseSmoke/Ready_Yes.txt',43,2),('ReleaseSmoke/Rebuild03_No.txt',43,2)]
for relative,expected,macros in specs:
 p=E/relative;s=p.read_text(encoding='utf-8-sig');lines=s.splitlines()
 bad=[l for l in lines if re.search(r'^(?:FAIL:|FAILED:|RUNTIME ERROR:|WATCHDOG_FAILURE:|CLEANUP ERROR:)',l) or re.search(r'\bfailed=[1-9][0-9]*',l)]
 summaries=[l for l in lines if l.startswith('TOTAL')];counts=[(int(a),int(b)) for l in summaries for a,b in re.findall(r'passed=(\d+); failed=(\d+)',l)]
 assert not bad and counts and sum(a for a,b in counts)==expected and all(b==0 for a,b in counts),(relative,bad,counts)
 assert s.count('SUITE_STARTED:')==s.count('SUITE_FINISHED:')==macros,relative
 assert 'SOURCE_UNCHANGED: True' in s and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in s
 closure=read(Path(str(p)+'.ProcessClosure.json'));assert closure['Passed'] and closure['RunnerCleanupValid'] and not closure['OrdinaryPathKilledAnything']
 sourcehash=re.search(r'^SOURCE_SHA256: (\w+)',s,re.M).group(1)
 rows.append({'Primary':relative,'SHA256':sha(p),'SourceSHA256':sourcehash,'LinesRead':len(lines),'AllLinesRead':True,'PassedAssertions':expected,'FailedAssertions':0,'MacrosFinished':macros,'Summaries':summaries,'NormalOwnClosure':True});total+=expected
for c in ['Main','Ready']:
 native=read(E/'Native'/c/'NativeVerification.json');eq=read(E/'Native'/c/'SourceEquality.json');closed=read(E/'Native'/c/'Closure.json');package=read(E/'ReleaseCandidate'/c/'PackagePreservation.json')
 assert native['Passed'] and native['AllHeadingStylesMatch'] and closed['Passed'] and not closed['ForceKilled']
 assert eq['Passed'] and eq['SourceComponents']==175 and eq['ExportComponents']==181,eq.keys()
 assert package['CandidateSHA256']==native['SourceSHA256']==sha(E/'ReleaseCandidate'/c/'RC_Section_NDM.xlsm')
 assert package['NativeVerificationPassed'] and package['ResultsAndSectionsAndPlotXMLUnchanged']
assert read(E/'RebuildProof03/BuildAcceptance.json')['ExactOwnIdentityAbsent']
assert read(E/'RebuildProof03/Reproducibility.json')['Passed']
assert read(E/'NativePreviewClosure.json')['Passed'] and read(E/'NativePreviewClosure.json')['SourceUnchanged']
scope=read(E/'Native/IndependentCodeScope.json');assert not scope['UnexpectedNativeChanges']
body=lambda p:p.read_text(encoding='utf-8-sig').splitlines()[3:]
assert body(E/'Native/Main/VBA_All_Code.txt')==body(E/'Native/Ready/VBA_All_Code.txt')
result={'Status':'PASS_DIRECTED_UNIFIED_OUTPUT_ONLY','FullRunStarted':False,'FullPassTransferredToNewSHA':False,'PassedAssertions':total,'FailedAssertions':0,'AcceptedPrimaries':rows,'NativeSource175Plus6':True,'MainReady181BodiesLiteralEqual':True,'UniformNativeHeaderStyles':True,'NativeVisualReviewed':True,'RebuildWithCapturedLayoutPassed':True,'PreservedReadyResults':True,'OldUnsuccessfulSelectorProbePreserved':'Directed01/Selector_No.txt','NdMUnchanged':'PAUSED','MainSHA256':sha(E/'ReleaseCandidate/Main/RC_Section_NDM.xlsm'),'ReadySHA256':sha(E/'ReleaseCandidate/Ready/RC_Section_NDM.xlsm'),'AllCodeSHA256':sha(E/'Native/Main/VBA_All_Code.txt')}
(E/'Acceptance.json').write_bytes(json.dumps(result,ensure_ascii=False,indent=2).encode())
print(json.dumps({k:result[k] for k in ['Status','PassedAssertions','FailedAssertions','MainSHA256','ReadySHA256','AllCodeSHA256']},ensure_ascii=False))
