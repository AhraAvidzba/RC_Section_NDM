"""ДЛЯ ТЕСТОВ: проверяет новый контракт выбора и реальные прямые источники validation."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'tmp/Test-PatchUnifiedOutput01.py').read_text(encoding='utf-8')
namespace = {'__file__': str(ROOT / 'tmp/Test-PatchUnifiedOutput01.py')}
exec(compile(source[:source.index("TestEdit('src/Excel/modSectionSnapshot.bas'")], namespace['__file__'], 'exec'), namespace)
TestEdit, TestReplace = namespace['TestEdit'], namespace['TestReplace']


def TestPatchValidationOracles(text):
    """ДЛЯ ТЕСТОВ: проверяет исходные видимые диапазоны вместо удалённых формульных копий."""
    start = text.index("' Подготавливает круговой fixture и проверяет реальную validation выбора LC для AutoCAD.")
    end = text.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Применяет ту же проверку", start)
    text = text[:start] + '''' Проверяет единый прямой список ID, который используют схема и AutoCAD.
Private Function TestAutoCADCombinationValidationIsDynamic() As Boolean
    TestAutoCADCombinationValidationIsDynamic = TestLoadCaseValidationIsDynamicForSetting("Output.CombinationID")
End Function

''' + text[end:]
    old = '''            listRange.Calculate ' Данные сочетаний изменены тестом; обновляем формулы списка и при ручном пересчёте.
            TestLoadCaseValidationIsDynamicForSetting = (CStr(listRange.Cells.Item(1, 1).Value2) = "Worst" And _
                CStr(listRange.Cells.Item(2, 1).Value2) = "LC1" And listRange.Cells.Item(2, 1).HasFormula)'''
    new = '''            Dim loads As Object: Set loads = ThisWorkbook.Names.Item("rngLoadCombinations").RefersToRange
            TestLoadCaseValidationIsDynamicForSetting = (listRange.Address = loads.Cells(2, 1).Resize(loads.Rows.Count - 1, 1).Address And _
                CStr(listRange.Cells.Item(1, 1).Value2) = "LC1" And Not listRange.Cells.Item(1, 1).HasFormula)'''
    text = TestReplace(text, old, new)
    text = text.replace("' Список сочетаний должен содержать вычисленные формулами названия всех профилей.\n' Смена имени профиля обновляет список без изменения VBA.", "' ProfileId ссылается непосредственно на горизонтальную строку имён профилей.\n' Смена имени видна в списке без служебной копии, формулы и обновления VBA.")
    old = '''    Dim i As Long
    For i = 1 To listRange.Cells.Count
        If Not CBool(listRange.Cells.Item(i, 1).HasFormula) Then Exit Function
        If CStr(listRange.Cells.Item(i, 1).Value2) <> CStr(profiles.Cells.Item(displayRow, i + 2).Value2) Then Exit Function
    Next i
    TestLoadProfileValidationUsesDisplayNames = True'''
    new = '''    Dim i As Long, count As Long: count = profiles.Columns.Count - 3
    If listRange.Address <> profiles.Cells(displayRow, 3).Resize(1, count).Address Then Exit Function
    If listRange.Rows.Count <> 1 Or listRange.Columns.Count <> count Then Exit Function
    For i = 1 To count
        If CStr(listRange.Cells.Item(1, i).Value2) <> CStr(profiles.Cells.Item(displayRow, i + 2).Value2) Then Exit Function
    Next i
    TestLoadProfileValidationUsesDisplayNames = True'''
    return TestReplace(text, old, new)


TestEdit('tests/modTestWorkbookInterface.bas', TestPatchValidationOracles)
TestEdit('tests/modTestContourMesh.bas', lambda text: TestReplace(text, '    For i = 2 To profiles.Rows.Count\n        If CStr(profiles.Cells(i, 2).Value2) = "Visualization.State"', '    modTestPlotConfig.TestSetOutputCombinationInTable table, "CM_BEND"\n    For i = 2 To profiles.Rows.Count\n        If CStr(profiles.Cells(i, 2).Value2) = "Visualization.State"'))
TestEdit('tools/build_workbook/Test-DependentRowsTemplate.ps1', lambda text: TestReplace(text, '    Reset-ConfigValidationSources $sheet\n', ''))
TestEdit('tools/build_workbook/Prepare-PerformanceWorkbook.ps1', lambda text: TestReplace(text, '''            # Находим свободную служебную колонку без сброса прежнего реестра.
            Reset-ConfigValidationSources $config
            while ($config.Application.WorksheetFunction.CountA($config.Range($config.Cells.Item(1, $script:ConfigValidationNextColumn), $config.Cells.Item(501, $script:ConfigValidationNextColumn))) -gt 0) {
                $script:ConfigValidationNextColumn++
            }
''', ''))

TESTS = '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет общий выбор без НДС-решателя и прямые списки настоящего Config.
Public Function RunUnifiedOutputSelectionTests(Optional ByRef passed As Long = 0, Optional ByRef failed As Long = 0) As String
    Dim stats As TUiTestStats
    TestUnifiedOutputSelectionContracts stats
    TestUnifiedOutputConfigContracts stats
    TestAppendLine stats, "TOTAL_UNIFIED_OUTPUT: passed=" & CStr(stats.Passed) & "; failed=" & CStr(stats.Failed)
    passed = stats.Passed: failed = stats.Failed: RunUnifiedOutputSelectionTests = stats.Report
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Один resolver проверяется с User/Worst, неактивным ID и сохранёнными fallback-таблицами.
Private Sub TestUnifiedOutputSelectionContracts(ByRef stats As TUiTestStats)
    Dim fixture As Object, sheet As Object, table As Object, settings As CSystemSettingsReader
    Dim data(1 To 5, 1 To 3) As Variant, bad As Variant, value As String, reason As String, code As Long
    On Error GoTo Failed
    Set fixture = Application.Workbooks.Add(xlWBATWorksheet): Set sheet = fixture.Worksheets(1): sheet.Name = "Selection"
    data(1, 1) = "Параметр": data(1, 2) = "Значение": data(1, 3) = "Комментарий"
    data(2, 1) = "Output.CombinationMode": data(2, 2) = "Worst"
    data(3, 1) = "Output.CombinationID": data(3, 2) = "IGNORED"
    data(4, 1) = "Results.SnapshotStorage": data(4, 2) = "Excel"
    data(5, 1) = "Results.SnapshotName": data(5, 2) = "UnusedSelectionSnapshot"
    Set table = sheet.Range("A1").Resize(5, 3): table.Value2 = data
    fixture.Names.Add Name:="rngSystemSettings", RefersTo:="=Selection!$A$1:$C$5"
    fixture.Names.Add Name:="rngBatchSummary", RefersTo:="=Selection!$H$2"
    sheet.Range("H2").Value2 = "WORST_REAL"
    Set settings = New CSystemSettingsReader
    For Each bad In Array("", CVErr(2015), "NOT_SAVED")
        table.Cells(3, 2).Value2 = bad: settings.LoadFromRange table
        TestAssertTrue stats, "output.Worst.ignoresID." & CStr(VarType(bad)), ReadOutputCombinationID(fixture, settings) = "WORST_REAL"
    Next bad
    table.Cells(2, 2).Value2 = "User": table.Cells(3, 2).Value2 = "USER_REAL": settings.LoadFromRange table
    TestAssertTrue stats, "output.User.exactID", ReadOutputCombinationID(fixture, settings) = "USER_REAL"
    table.Cells(3, 2).Value2 = "Worst": settings.LoadFromRange table
    TestAssertTrue stats, "output.User.literalWorstIsID", ReadOutputCombinationID(fixture, settings) = "Worst"
    For Each bad In Array("", "TODO", CVErr(2015))
        table.Cells(3, 2).Value2 = bad: settings.LoadFromRange table
        TestCaptureUnifiedOutput fixture, settings, value, code, reason
        TestAssertTrue stats, "output.User.rejectsBadID." & CStr(VarType(bad)), code <> 0 And InStr(1, reason, "Output.CombinationID", vbTextCompare) > 0
        TestAssertTrue stats, "output.User.IDaddress." & CStr(VarType(bad)), InStr(1, reason, table.Cells(3, 2).Address(False, False), vbTextCompare) > 0
    Next bad
    table.Cells(3, 2).Value2 = "USER_REAL"
    For Each bad In Array("", "TODO", "Auto", CVErr(2015))
        table.Cells(2, 2).Value2 = bad: settings.LoadFromRange table
        TestCaptureUnifiedOutput fixture, settings, value, code, reason
        TestAssertTrue stats, "output.rejectsBadMode." & CStr(VarType(bad)) & "." & CStr(Len(reason)), code <> 0 And InStr(1, reason, "Output.CombinationMode", vbTextCompare) > 0
    Next bad
    table.Cells(2, 2).Value2 = "Worst": settings.LoadFromRange table: sheet.Range("H2").ClearContents
    sheet.Range("J1").Value2 = "LoadCase": sheet.Range("J2").Value2 = "ELEMENT_FALLBACK"
    fixture.Names.Add Name:="rngNDMElementResults", RefersTo:="=Selection!$J$1"
    TestAssertTrue stats, "output.Worst.savedElementFallback", ReadOutputCombinationID(fixture, settings) = "ELEMENT_FALLBACK"
    sheet.Range("J2").ClearContents
    sheet.Range("P1").Value2 = "LoadCase": sheet.Range("Q1").Value2 = "Parameter"
    sheet.Range("P2").Value2 = "ALL": sheet.Range("Q2").Value2 = "Bounds.MaxX"
    sheet.Range("P3").Value2 = "PROPERTIES_FALLBACK": sheet.Range("Q3").Value2 = "ProfileId"
    fixture.Names.Add Name:="rngNDMSectionProperties", RefersTo:="=Selection!$P$1"
    TestAssertTrue stats, "output.Worst.savedPropertiesFallback", ReadOutputCombinationID(fixture, settings) = "PROPERTIES_FALLBACK"
    sheet.Range("P3:Q3").ClearContents
    TestCaptureUnifiedOutput fixture, settings, value, code, reason
    TestAssertTrue stats, "output.Worst.noCalculatedCases", code <> 0 And InStr(1, reason, "Output.CombinationMode", vbTextCompare) > 0
    GoTo Restore
Failed:
    TestAssertTrue stats, "output.runtime." & CStr(Err.Number) & "." & Err.Description, False
Restore:
    On Error Resume Next
    If Not fixture Is Nothing Then fixture.Close False
    On Error GoTo 0
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет полную исходную ошибку resolver-а для независимой проверки ключа и адреса.
Private Sub TestCaptureUnifiedOutput(ByVal fixture As Object, ByVal settings As CSystemSettingsReader, _
        ByRef value As String, ByRef code As Long, ByRef reason As String)
    value = vbNullString: code = 0: reason = vbNullString
    On Error GoTo Failed
    value = ReadOutputCombinationID(fixture, settings)
    Exit Sub
Failed:
    code = Err.Number: reason = Err.Description: Err.Clear
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет настоящий порядок, оба прямых диапазона и немедленную реакцию dropdown на смену источника.
Private Sub TestUnifiedOutputConfigContracts(ByRef stats As TUiTestStats)
    Dim table As Object, loads As Object, profiles As Object, config As Object, mode As Object, id As Object, criterion As Object
    Dim display As Object, row As Long, formula As String, foundImport As Boolean, helper As Object, absent As Boolean
    Dim savedID As Variant, savedSourceID As Variant, savedProfile As Variant, savedAssigned As Variant, saved As Boolean
    On Error GoTo Failed
    Set table = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange: Set config = table.Worksheet
    Set loads = ThisWorkbook.Names.Item("rngLoadCombinations").RefersToRange
    Set profiles = ThisWorkbook.Names.Item("rngCalculationProfiles").RefersToRange
    Set mode = TestAudit03PlotSettingCell(table, "Output.CombinationMode")
    Set criterion = TestAudit03PlotSettingCell(table, "General.WorstCombinationCriterion")
    Set id = TestAudit03PlotSettingCell(table, "Output.CombinationID")
    TestAssertTrue stats, "output.config.order", mode.Row + 1 = criterion.Row And criterion.Row + 1 = id.Row
    TestAssertTrue stats, "output.config.subsection", CStr(mode.Offset(-1, -1).Value2) = "[Выводимое сочетание]"
    For row = 2 To table.Rows.Count
        If CStr(table.Cells(row, 1).Value2) = "[Импорт]" Then foundImport = True
    Next row
    TestAssertTrue stats, "output.config.noEmptyImport", Not foundImport
    formula = CStr(id.Validation.Formula1)
    TestAssertTrue stats, "output.config.IDdirect", formula = "=" & loads.Cells(2, 1).Resize(loads.Rows.Count - 1, 1).Address(True, True)
    For row = 2 To profiles.Rows.Count
        If CStr(profiles.Cells(row, 2).Value2) = "Profile.DisplayName" Then Set display = profiles.Cells(row, 3).Resize(1, profiles.Columns.Count - 3): Exit For
    Next row
    TestAssertTrue stats, "output.config.profileDirect", CStr(loads.Cells(2, 5).Validation.Formula1) = "=" & display.Address(True, True)
    TestAssertTrue stats, "output.config.profileCurrentLayout", display.Address = "$J$39:$M$39"
    TestAssertTrue stats, "output.config.noHiddenColumns", config.Range("BQ:EF").EntireColumn.Hidden = False
    On Error Resume Next
    Set helper = ThisWorkbook.Names("rngSectionRecipeTypes"): absent = Err.Number <> 0: Err.Clear
    On Error GoTo Failed
    TestAssertTrue stats, "output.config.noHelperName", absent
    savedID = id.Formula: savedSourceID = loads.Cells(2, 1).Formula
    savedProfile = display.Cells(1, 1).Formula: savedAssigned = loads.Cells(2, 5).Formula: saved = True
    loads.Cells(2, 1).Value2 = "TEST_SHARED_OUTPUT": id.Value2 = "TEST_SHARED_OUTPUT"
    TestAssertTrue stats, "output.config.IDdynamicPositive", id.Validation.Value
    loads.Cells(2, 1).Value2 = "TEST_SHARED_CHANGED"
    TestAssertTrue stats, "output.config.IDdynamicNegative", Not id.Validation.Value
    display.Cells(1, 1).Value2 = "TEST_PROFILE_DIRECT": loads.Cells(2, 5).Value2 = "TEST_PROFILE_DIRECT"
    TestAssertTrue stats, "output.config.profileDynamicPositive", loads.Cells(2, 5).Validation.Value
    display.Cells(1, 1).Value2 = "TEST_PROFILE_CHANGED"
    TestAssertTrue stats, "output.config.profileDynamicNegative", Not loads.Cells(2, 5).Validation.Value
    GoTo Restore
Failed:
    TestAssertTrue stats, "output.config.runtime." & CStr(Err.Number) & "." & Err.Description, False
Restore:
    On Error Resume Next
    If saved Then
        id.Formula = savedID: loads.Cells(2, 1).Formula = savedSourceID
        display.Cells(1, 1).Formula = savedProfile: loads.Cells(2, 5).Formula = savedAssigned
    End If
    On Error GoTo 0
End Sub
'''
TestEdit('tests/modTestPlotConfig.bas', lambda text: TestReplace(text, '    TestAudit03GeneralPlotContracts stats\n', '    TestUnifiedOutputSelectionContracts stats\n    TestUnifiedOutputConfigContracts stats\n    TestAudit03GeneralPlotContracts stats\n') + TESTS)
print('ADDED_NEW_SELECTOR_AND_DIRECT_VALIDATION_CHECKS_WITHOUT_SOLVER')
