"""ДЛЯ ТЕСТОВ: удаляет скрытые копии перечислений, синхронизируя реестр и раскладку."""
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('TestPatchHelpers', ROOT / 'tmp/Test-PatchUnifiedOutput01.py')
# Импортируется только определение утилит; выполненные переносы первого шага не повторяются.
source = (ROOT / 'tmp/Test-PatchUnifiedOutput01.py').read_text(encoding='utf-8')
namespace = {'__file__': str(ROOT / 'tmp/Test-PatchUnifiedOutput01.py')}
exec(compile(source[:source.index("TestEdit('src/Excel/modSectionSnapshot.bas'")], namespace['__file__'], 'exec'), namespace)
TestEdit, TestReplace = namespace['TestEdit'], namespace['TestReplace']


def TestPatchCatalog(text):
    """ДЛЯ ТЕСТОВ: короткие перечисления живут только в validation, большие не прячутся в листе."""
    start = text.index('# Начинает распределение служебных списков Config')
    end = text.index('# Возвращает фактические таблицы форматирования', start)
    text = text[:start] + '''# Возвращает короткий список непосредственно для проверки данных, без служебных ячеек.
# Имена сочетаний и профилей передаются прямыми ссылками на их видимые таблицы отдельно.
function Get-ConfigValidationListAddress {
    param([object]$Sheet, [array]$Options)
    if ($Options.Count -eq 0) { throw 'Пустой список допустимых значений Config.' }
    $inline = @($Options | ForEach-Object {[string]$_}) -join [string]$Sheet.Application.International(5)
    if ($inline.Length -gt 255 -or @($Options | Where-Object {[string]$_ -match '[,;\\r\\n]'}).Count) {
        throw 'Перечисление не помещается в проверку данных: используйте прямую ссылку на видимую исходную таблицу.'
    }
    return $inline
}

''' + text[end:]
    text = TestReplace(text, '    Reset-ConfigValidationSources $Sheet\n', '')
    text = TestReplace(text, '    $Sheet.Columns.Item("BR:EF").Hidden = $true\n', '')
    pattern = r'(?m)^        "AutoCAD.Export.CombinationID" \{ return @\([\s\S]*?^        \)[ \t]*\}\n'
    replacement = '''        "Output.CombinationMode" { return @(
            "Одна настройка выбирает сочетание и для схемы Excel, и для экспорта AutoCAD. Worst берёт определяющее сочетание сохранённого снимка; User использует Output.CombinationID.",
            "Критерий General.WorstCombinationCriterion применяется при расчёте. Последующая смена критерия не пересчитывает сохранённый Worst: для этого повторите расчёт.",
            "Предварительная схема и экспорт одной геометрии не требуют рассчитанного сочетания. В режиме Worst поле Output.CombinationID не используется и может оставаться пустым."
        )}
        "Output.CombinationID" { return @(
            "При Output.CombinationMode = User укажите точный ID сочетания, сохранённого в текущем источнике: Excel Results либо файле снимка. В режиме Worst это поле игнорируется.",
            "Выпадающий список непосредственно связан со столбцом CombinationID таблицы сочетаний Config и меняется вместе с ним. Отдельного служебного варианта Worst в этом списке нет.",
            "При User пустое значение, ошибка Excel, TODO и ID отсутствующего сочетания дают понятную ошибку с адресом настройки. Они не заменяются Worst автоматически."
        )}
'''
    text, count = re.subn(pattern, replacement, text)
    assert count == 1
    text, count = re.subn(r'(?m)^        "Plot.LoadCase" \{ return @\([\s\S]*?^        \)[ \t]*\}\n', '', text)
    assert count == 1
    text = text.replace('Plot.LoadCase = Worst и AutoCAD.Export.CombinationID = Worst', 'Output.CombinationMode = Worst для схемы Excel и экспорта AutoCAD')
    return text


def TestPatchRecipeSetup(text):
    """ДЛЯ ТЕСТОВ: реестр остаётся единственным источником типов без именованной скрытой копии."""
    start = text.index("' Обновляет только список Geometry.Type")
    end = text.index("' Читает реестр без обращения", start)
    block = '''' Обновляет встроенный список Geometry.Type по реестру без служебных диапазонов.
' Значение настройки, размеры, таблицы ввода и оформление книги не перестраиваются.
Public Sub UpdateSectionRecipeTypes()
    Dim table As Object, cell As Object, ids As Variant, choices As String
    Dim row As Long, i As Long, guard As CExcelAppStateGuard
    Dim number As Long, source As String, description As String
    On Error GoTo Failed
    Set table = RequiredTable("rngSystemSettings")
    For i = 2 To table.Rows.Count
        If Not IsError(table.Cells(i, 1).Value2) Then
            If CStr(table.Cells(i, 1).Value2) = "Geometry.Type" Then
                If row > 0 Then SectionRecipeError "modSectionRecipeSetup", "В rngSystemSettings повторяется ключ Geometry.Type."
                row = i
            End If
        End If
    Next i
    If row = 0 Then SectionRecipeError "modSectionRecipeSetup", "В rngSystemSettings отсутствует ключ Geometry.Type."
    Set cell = table.Cells(row, 2)
    ids = RegisteredSectionRecipeTypes
    choices = Join(ids, CStr(ThisWorkbook.Application.International(xlListSeparator)))
    If Len(choices) = 0 Or Len(choices) > 255 Then SectionRecipeError "modSectionRecipeSetup", _
        "Список зарегистрированных типов не помещается в проверку данных Geometry.Type."
    Set guard = New CExcelAppStateGuard: guard.Enter ThisWorkbook.Application
    cell.Validation.Delete
    cell.Validation.Add xlValidateList, xlValidAlertStop, xlBetween, choices
    cell.Validation.IgnoreBlank = False: cell.Validation.InCellDropdown = True
    guard.Restore True
    Exit Sub
Failed:
    number = Err.Number: source = Err.Source: description = Err.Description
    If Not guard Is Nothing Then guard.Restore
    Err.Raise number, source, description
End Sub

'''
    return text[:start] + block + text[end:]


def TestPatchBuilder(text):
    """ДЛЯ ТЕСТОВ: сборка просит сам реестр обновить короткий встроенный список."""
    return TestReplace(text, '''    $recipeTypes = @($excel.Run("'" + $workbook.Name + "'!modSectionRecipeSetup.RegisteredSectionRecipeTypes"))
    Get-ConfigValidationListAddress $system $recipeTypes 'rngSectionRecipeTypes' | Out-Null
''', '')


def TestPatchLayout(text):
    """ДЛЯ ТЕСТОВ: snapshot расположения больше не ожидает отсутствующих служебных списков."""
    text, count = re.subn(r'(?m)^# Возвращает закреплённую колонку служебного списка[^\n]*\nfunction Get-WorkbookLayoutHelperColumn[\s\S]*?^}\n\n', '', text)
    assert count == 1
    start = text.index("    $config=$Workbook.Worksheets.Item('Config');$system=")
    end = text.index("    $controls=$config.Cells.Find", start)
    text = text[:start] + "    $config=$Workbook.Worksheets.Item('Config')\n" + text[end:]
    text, count = re.subn(r'HelperColumns=\[ordered\]@\{rngSectionRecipeTypes=.*?\};OtherTables=', 'HelperColumns=[ordered]@{};OtherTables=', text)
    assert count == 1
    return text


TestEdit('tools/build_workbook/SettingsCatalog.ps1', TestPatchCatalog)
TestEdit('src/Excel/modSectionRecipeSetup.bas', TestPatchRecipeSetup)
TestEdit('tools/build_workbook/Build-Workbook.ps1', TestPatchBuilder)
TestEdit('tools/build_workbook/WorkbookLayout.ps1', TestPatchLayout)
TestEdit('src/Excel/CSystemSettingsReader.cls', lambda text: text.replace('sectionName = "Нагрузки и диаграммы материалов"', 'sectionName = "Нагрузки, сочетания и диаграммы материалов"').replace('        Case Left$(key, 5) = "Plot.":', '        Case Left$(key, 7) = "Output.": sectionName = "Нагрузки, сочетания и диаграммы материалов"\n        Case Left$(key, 5) = "Plot.":'))
path = ROOT / 'tools/build_workbook/WorkbookLayout.json'
layout = json.loads(path.read_text(encoding='utf-8-sig'))
layout['Names'] = [x for x in layout['Names'] if x['Name'] != 'rngSectionRecipeTypes']
system = next(x for x in layout['Names'] if x['Name'] == 'rngSystemSettings')
assert system['Address'] == '$A$3:$E$147' and system['Rows'] == 145
system.update(Address='$A$3:$E$149', RefersTo='=Config!$A$3:$E$149', Rows=147)
layout['HelperColumns'] = {}
for sheet in layout['Sheets']:
    if sheet['Name'] == 'Config':
        for column in sheet['Columns']:
            column['Hidden'] = False
path.write_text(json.dumps(layout, ensure_ascii=False, indent=2) + '\n', encoding='utf-8-sig')
print('PATCHED_INLINE_REGISTRY_AND_LAYOUT; CAPTURE_ACTUAL_LAYOUT_AFTER_BUILD_PENDING')
