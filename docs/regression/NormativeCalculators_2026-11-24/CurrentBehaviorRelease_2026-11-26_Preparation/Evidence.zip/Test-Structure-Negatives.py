"""ДЛЯ ТЕСТОВ: проверяет отказ структурного контроля при реальном нарушении макета."""
import json
from pathlib import Path
import subprocess
import os
from zipfile import ZipFile
from lxml import etree as E

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if (p/'AGENTS.md').is_file())
M={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
PS='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
environment=dict(os.environ)
environment['PSModulePath']=str(Path(PS).parent/'Modules')
directory=HERE/'StructureNegativeCases'
directory.mkdir(exist_ok=True)
cases=[('MovedGeometryAnchor','Results ranges layout'),('WrongPrintArea','Print area'),('UnexpectedRowBreak','Presentation print layout: rowBreaks')]
results=[]
for name,expected in cases:
    with ZipFile(HERE/'RC_Section_NDM.xlsm') as original:
        parts={n:original.read(n) for n in original.namelist()}
        catalog=E.fromstring(parts['xl/workbook.xml'])
        relations={n.get('Id'):n.get('Target') for n in E.fromstring(parts['xl/_rels/workbook.xml.rels'])}
        sheet=next(n for n in catalog.findall('m:sheets/m:sheet',M) if n.get('name')=='Расчет')
        target=relations[sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
        calc=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        if name=='MovedGeometryAnchor':
            node=next(n for n in catalog.findall('m:definedNames/m:definedName',M) if n.get('name')=='rngNDMSectionGeometry')
            assert node.text.endswith('$A$192')
            node.text='Results!$B$192'
        elif name=='WrongPrintArea':
            node=next(n for n in catalog.findall('m:definedNames/m:definedName',M) if n.get('name')=='_xlnm.Print_Area')
            assert '$BD$59' in node.text
            node.text=node.text.replace('$BD$59','$BC$59')
        else:
            doc=E.fromstring(parts[calc]);node=doc.find('m:rowBreaks',M)
            assert node is None
            node=E.Element('{'+M['m']+'}rowBreaks',count='1',manualBreakCount='1')
            E.SubElement(node,'{'+M['m']+'}brk',id='30',min='0',max='16383',man='1')
            before=next((n for n in doc if E.QName(n).localname in ['colBreaks','drawing','legacyDrawing','extLst']),None)
            doc.insert(doc.index(before) if before is not None else len(doc),node)
            parts[calc]=E.tostring(doc,encoding='UTF-8',xml_declaration=True,standalone=True)
        parts['xl/workbook.xml']=E.tostring(catalog,encoding='UTF-8',xml_declaration=True,standalone=True)
        book=directory/(name+'.xlsm')
        with ZipFile(book,'w') as out:
            for item in original.infolist():out.writestr(item,parts[item.filename])
    gate=subprocess.run([PS,'-NoProfile','-Command',"$ErrorActionPreference='Stop';$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory; if($m.AvailableMBytes -lt 7168 -or ([double]$m.CommitLimit-[double]$m.CommittedBytes) -lt 7GB){exit 1}"],cwd=ROOT,env=environment)
    assert gate.returncode==0,'Insufficient memory before negative structure test'
    report=directory/(name+'.json')
    run=subprocess.run([PS,'-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'tools/build_workbook/Validate-Workbook.ps1'),
                        '-WorkbookPath',book.relative_to(ROOT).as_posix(),'-ReportPath',report.relative_to(ROOT).as_posix()],cwd=ROOT,capture_output=True,env=environment)
    (directory/(name+'.stdout.log')).write_bytes(run.stdout)
    (directory/(name+'.stderr.log')).write_bytes(run.stderr)
    checks=json.loads(report.read_text(encoding='utf-8-sig'))
    failures=[r['Check'] for r in checks if not r['Passed']]
    assert run.returncode==1 and failures==[expected],(name,run.returncode,failures)
    assert next(r for r in checks if r['Check']=='Source workbook unchanged')['Passed']
    results.append({'Case':name,'ExpectedFailure':expected,'ActualFailures':failures,'Passed':True})
(HERE/'StructureNegativeAcceptance.json').write_text(json.dumps({'Status':'PASS','Cases':results},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('STRUCTURE_NEGATIVE_TESTS_PASS: 3 deliberate errors rejected')
