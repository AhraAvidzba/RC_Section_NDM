"""ДЛЯ ТЕСТОВ: проверяет локальность редакторских правок и соответствие VBA исходникам."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
from decimal import Decimal

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p/'AGENTS.md').is_file())
spec = importlib.util.spec_from_file_location('package',ROOT/'tools/build_workbook/Package-NormativeCalculators.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)

def code(text):
    """Удаляет только комментарии VBA, сохраняя выражения и строковые литералы."""
    lines=[]
    for line in text.splitlines():
        quote=False
        for i,c in enumerate(line):
            if c=='"': quote=not quote
            if c=="'" and not quote:
                line=line[:i]
                break
        if line.strip(): lines.append(line.rstrip())
    return '\n'.join(lines)

paths = sorted(p for folder in ['src','tests'] for p in (ROOT/folder).rglob('*') if p.suffix in ['.cls','.bas'])
assert len(paths)==203
scope=[]
for p in paths:
    name=p.relative_to(ROOT).as_posix()
    original=subprocess.check_output(['git','show','8eda256c:'+name],cwd=ROOT).decode('utf-8-sig')
    current=p.read_text(encoding='utf-8-sig')
    expected=code(original)
    if name=='tests/modTestRecipeOperations.bas':
        assert expected.count('Предупреждение: исторический текст без кодов.')==1
        expected=expected.replace('Предупреждение: исторический текст без кодов.','Предупреждение: текст без кода диагностики.')
    assert expected==code(current),name
    if original!=current:
        scope.append({'Path':name,'OnlyComments':name!='tests/modTestRecipeOperations.bas',
                      'OnlyCommentAndDiagnosticFixtureText':name=='tests/modTestRecipeOperations.bas'})

def native_tokens(text):
    """Учитывает точную десятичную запись чисел редактором VBA: 1E-8 и 0.00000001."""
    values=h.normalized(text).splitlines()
    result=[]
    numeric=False
    for value in values:
        if value=='#' and numeric:
            numeric=False
            continue
        numeric=bool(re.fullmatch(r'\d+(?:\.\d*)?(?:[eE][+-]?\d+)?',value))
        result.append(str(Decimal(value).normalize()) if numeric else value)
    return result

native=h.components(HERE/'NativeRelease.txt')
assert len(native)==209
baseline_file=HERE/'NativeBaseline.txt'
assert hashlib.sha256(baseline_file.read_bytes()).hexdigest().upper()=='FF16687121501D92957DA959E9D315CC369FA080DA838F570A22B9D9FDE925FF'
baseline=h.components(baseline_file)
assert len(baseline)==209
differences=[]
for p in paths:
    assert p.stem in native,p.stem
    source=p.read_text(encoding='utf-8-sig')
    body=re.search(r'(?ms)^Option Explicit.*',source)
    body=body[0] if body else '\n'.join(line for line in source.splitlines() if not line.startswith('Attribute VB_Name'))
    # Нативная запись VBE этих неизменённых литералов уже проверена в исходной книге.
    body=body.replace('1.797693134862315E+308','1.79769313486231E+308')
    body=body.replace('3.552713678800501E-15','3.5527136788005E-15')
    if p.stem=='modTestWorkbookInterface': body=body.replace('0.000000000000000001','1E-18')
    if native_tokens(body)!=native_tokens(native[p.stem][1]):
        import difflib
        delta='\n'.join(difflib.unified_diff(native_tokens(body),native_tokens(native[p.stem][1])))
        (HERE/(p.stem+'_SourceDifference.txt')).write_text(delta,encoding='utf-8')
        differences.append(p.stem)
    previous=code(baseline[p.stem][1])
    if p.stem=='modTestRecipeOperations':
        previous=previous.replace('Предупреждение: исторический текст без кодов.','Предупреждение: текст без кода диагностики.')
    assert native_tokens(previous)==native_tokens(code(native[p.stem][1])),('Native executable code changed',p.stem)
result={'Status':'PASS' if not differences else 'SOURCE_DIFFERENCES','WorkingVBASourceFiles':len(paths),
        'NativeComponents':len(native),'ChangedVBASources':scope,'RuntimeLogicUnchanged':True,
        'FixtureOnlyChange':'Текст произвольной диагностической строки без кода; численные данные и assertions не менялись.',
        'SourceEquality':not differences,'SourceDifferences':differences,'NativeExecutableCodeEqualsBaseline':True,
        'WorkbookSHA256':hashlib.sha256((HERE/'RC_Section_NDM.xlsm').read_bytes()).hexdigest().upper()}
(HERE/'TextScope.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
if differences: raise SystemExit(1)
