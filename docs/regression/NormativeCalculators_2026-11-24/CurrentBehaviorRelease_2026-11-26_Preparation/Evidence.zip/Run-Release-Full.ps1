# ДЛЯ ТЕСТОВ: запускает полный набор на чистой релизной книге и сохраняет владение процессом.
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global -ErrorAction Stop
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$preparation='docs/regression/NormativeCalculators_2026-11-24/CurrentBehaviorRelease_2026-11-26_Preparation'
$full='docs/regression/CurrentBehaviorRelease_2026-11-26_Full_Run01'
$deadline='2026-11-27T10:00:00+03:00'
$book=Join-Path $root ($preparation+'/RC_Section_NDM.xlsm')
$expected='FE0689F3DFECF0708D85A0027B5DEF7F3D97C071466171A25441AC48A6B5C807'
if((Get-FileHash -LiteralPath $book).Hash -cne $expected){throw 'Release workbook changed before full acceptance.'}
foreach($item in @('TextScope.json','CleanRelease.json','StructureNegativeAcceptance.json','HelpStyle_Final/SettingsHelpStyle.json')){
    $result=Get-Content -LiteralPath (Join-Path $PSScriptRoot $item) -Raw -Encoding UTF8|ConvertFrom-Json
    if($result.Status -ne 'PASS'){throw ('Preflight incomplete: '+$item)}
}
$stateDirectory=Join-Path $root 'outputs/CurrentBehaviorRelease_2026-11-26'
New-Item -ItemType Directory -Path $stateDirectory -Force|Out-Null
$statePath=Join-Path $stateDirectory 'TaskState.json'
$identity=Get-Process -Id $PID
$state=[ordered]@{Status='FULL_RUN_ACTIVE';SourceCommit=(& git -C $root rev-parse HEAD);SourceWorkbook=$book;SourceSHA256=$expected;
    ControllerPID=$PID;ControllerStartUTC=$identity.StartTime.ToUniversalTime().ToString('o');StartedUTC=[DateTimeOffset]::UtcNow.ToString('o');
    Deadline=$deadline;ForecastHours=6;FullDirectory=$full;PreparationDirectory=$preparation;FullRetriesAuthorizedIfForecastFitsDeadline=$true;
    RequiredCoreExecutions=202;RequiredFocusedSingleCases=122;RequiredSupplementExecutions=14;Publication='Only after complete PASS and primary log audit'}
$state|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $statePath -Encoding UTF8
Write-Output ('RELEASE_FULL_STARTED: PID='+$PID+'; start='+$state.ControllerStartUTC+'; workbook='+$expected)
& (Join-Path $PSHOME 'powershell.exe') -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/build_workbook/Run-NormativeFullAcceptance.ps1') -SourceWorkbook $book -EvidenceDirectory $full -Deadline $deadline -ForecastHours 6
$exitCode=$LASTEXITCODE
$current=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8|ConvertFrom-Json
$acceptancePath=Join-Path $root ($full+'/GoalAcceptance.json')
$accepted=$false
if(Test-Path -LiteralPath $acceptancePath){$accepted=(Get-Content -LiteralPath $acceptancePath -Raw -Encoding UTF8|ConvertFrom-Json).Status -eq 'PASS'}
$current.Status=if($accepted -and $exitCode -eq 0){'FULL_RUN_PASS_PENDING_AUDIT'}else{'FULL_RUN_REVIEW_REQUIRED'}
$current|Add-Member NoteProperty FinishedUTC ([DateTimeOffset]::UtcNow.ToString('o')) -Force
$current|Add-Member NoteProperty ExitCode $exitCode -Force
$current|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $statePath -Encoding UTF8
Write-Output ('RELEASE_FULL_FINISHED: exit='+$exitCode+'; accepted='+$accepted)
exit $exitCode
