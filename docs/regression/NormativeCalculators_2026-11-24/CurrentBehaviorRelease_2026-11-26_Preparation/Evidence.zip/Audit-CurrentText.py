"""ДЛЯ ТЕСТОВ: инвентаризация текстовых мест исходников и сохраненной справки."""
import hashlib
import json
import argparse
from pathlib import Path
import re
import subprocess
from zipfile import ZipFile
from lxml import etree as E

ROOT = next(p for p in Path(__file__).resolve().parents if (p/'AGENTS.md').is_file())
OUT = Path(__file__).resolve().parent
OUT.mkdir(exist_ok=True, parents=True)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--book', default='workbook/output/RC_Section_NDM.xlsm')
parser.add_argument('--name', default='TextInventory.json')
args = parser.parse_args()
assert not (OUT/args.name).exists(), 'Use a new inventory name; primary evidence is immutable.'
PATTERN = re.compile(r'согласован|согласили|тобой|тво[йея]|по (?:ваш|тво|просьб|замечан)|раньше|ранее|прежн|стар(?:ая|ой|ый|ые|ого|ом|ую)|теперь|историческ|устаревш|legacy|backward|compatib|\bold\b|\bfixed\b|исправлен|добавлен|изменен|удален|удалён|\bИИ\b|chatgpt|codex|агент|по сравнению|обсужд|уточнен|верси|рефактор|договорен|договорён', re.I)
tracked = subprocess.check_output(['git','ls-files','-z'], cwd=ROOT).decode().split('\0')
paths = sorted(ROOT / n for n in tracked if n and (n.startswith(('src/','tests/','tools/build_workbook/')))
               and Path(n).suffix in ('.cls','.bas','.vba','.ps1','.json','.py'))
paths += [ROOT/n for n in ['README.md','docs/NDM_User_Guide.md','docs/MathematicalModel.md','docs/CoordinateSystem.md']]
inventory, hits = [], []
for p in paths:
    text = p.read_text(encoding='utf-8-sig')
    lines = text.splitlines()
    inv = {'Path':p.relative_to(ROOT).as_posix(), 'Lines':len(lines), 'SHA256':hashlib.sha256(p.read_bytes()).hexdigest().upper(), 'Matches':0}
    for i,line in enumerate(lines,1):
        if PATTERN.search(line):
            hits.append({'Path':inv['Path'],'Line':i,'Text':line})
            inv['Matches'] += 1
    inventory.append(inv)

book = ROOT / args.book
M = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
help_cells, book_hits, extra, help_formulas = [], [], [], []
with ZipFile(book) as z:
    strings = [''.join(si.itertext()) for si in E.fromstring(z.read('xl/sharedStrings.xml'))]
    relationships = {e.get('Id'):e.get('Target') for e in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    for s in E.fromstring(z.read('xl/workbook.xml')).findall('m:sheets/m:sheet',M):
        target = relationships[s.get(R)]
        part = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        doc = E.fromstring(z.read(part))
        for c in doc.findall('.//m:sheetData/m:row/m:c',M):
            formula=c.find('m:f',M)
            if s.get('name')=='Справка' and formula is not None:
                help_formulas.append({'Cell':c.get('r'),'Formula':formula.text or ''})
            v = c.find('m:v',M)
            text = ''.join(c.find('m:is',M).itertext()) if c.get('t') == 'inlineStr' else (strings[int(v.text)] if c.get('t') == 's' and v is not None else '')
            if not text:
                continue
            rec={'Sheet':s.get('name'),'Cell':c.get('r'),'Text':text}
            if s.get('name') == 'Справка':
                help_cells.append(rec)
            if PATTERN.search(text):
                book_hits.append(rec)
    for n in z.namelist():
        if n.startswith(('xl/comments','xl/drawings/')) and n.endswith('.xml'):
            for t in E.fromstring(z.read(n)).xpath('//*[local-name()="t"]'):
                if t.text and PATTERN.search(t.text):
                    extra.append({'Part':n,'Text':t.text})
result={'SourceFiles':inventory,'Matches':hits,'WorkbookSHA256':hashlib.sha256(book.read_bytes()).hexdigest().upper(),
        'HelpCells':help_cells,'HelpFormulaCells':help_formulas,'WorkbookMatches':book_hits,'DrawingCommentMatches':extra}
(OUT/args.name).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'Files':len(inventory),'VBASources':sum(Path(v['Path']).suffix in ('.bas','.cls','.vba') for v in inventory),
                  'Lines':sum(v['Lines'] for v in inventory),'HelpTextCells':len(help_cells),'SourceMatches':len(hits),'WorkbookMatches':len(book_hits),'DrawingCommentMatches':len(extra)},ensure_ascii=False))
strong = re.compile(r'согласовано|тобой|по просьбе|в этой версии|раньше был|теперь|историческ|по сравнению|рефактор|\bИИ\b|chatgpt|codex', re.I)
for h in book_hits+extra:
    if strong.search(h['Text']):
        print(json.dumps(h,ensure_ascii=False))
