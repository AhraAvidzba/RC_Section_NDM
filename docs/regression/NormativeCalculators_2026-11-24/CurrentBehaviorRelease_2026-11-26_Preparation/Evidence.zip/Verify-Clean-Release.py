"""ДЛЯ ТЕСТОВ: проверяет отсутствие пользовательских расчетных данных в чистой сборке."""
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZipFile
from lxml import etree as E

HERE=Path(__file__).resolve().parent
M={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
book=HERE/'RC_Section_NDM.xlsm'
with ZipFile(book) as z:
    strings=[''.join(si.itertext()) for si in E.fromstring(z.read('xl/sharedStrings.xml'))]
    catalog=E.fromstring(z.read('xl/workbook.xml'))
    names={n.get('name'):n.text for n in catalog.findall('m:definedNames/m:definedName',M)}
    relations={n.get('Id'):n.get('Target') for n in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    sheets={}
    for node in catalog.findall('m:sheets/m:sheet',M):
        target=relations[node.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
        path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        sheets[node.get('name')]=E.fromstring(z.read(path))
    assert list(sheets)==['Config','Сечения','Справка','Расчет','Results']
    cells={c.get('r'):c for c in sheets['Results'].findall('.//m:sheetData/m:row/m:c',M)}
    def value(c):
        if c is None:return ''
        v=c.find('m:v',M)
        if c.get('t')=='inlineStr':return ''.join(c.find('m:is',M).itertext())
        return strings[int(v.text)] if c.get('t')=='s' and v is not None else (v.text or '' if v is not None else '')
    tables=[]
    for key in ['rngStrengthSummaryAnchor','rngCrackSummaryAnchor','rngStabilitySummaryAnchor','rngTorsionSummaryAnchor',
                'rngNDMSectionGeometry','rngNDMSectionProperties','rngNDMMaterialDiagrams','rngNDMSectionContours',
                'rngNDMElementResults','rngNDMElementGeometry','rngNDMSectionAnnotations','rngTorsionBarForces']:
        match=re.fullmatch(r"'?Results'?!\$([A-Z]+)\$(\d+)",names[key])
        assert match,(key,names[key])
        column,row=match[1],int(match[2])
        summary=key.endswith('SummaryAnchor')
        first=row if summary else row+1
        last=row+29 if summary else max(int(re.search(r'\d+',a)[0]) for a in cells)
        saved=[a for a,c in cells.items() if re.fullmatch(column+r'\d+',a) and first<=int(re.search(r'\d+',a)[0])<=last and value(c)!='']
        assert not saved,(key,saved)
        tables.append({'Table':key,'DataIDs':0})
    assert not any(k.startswith('NDM.Snapshot.') for k in names)
    assert all(r['Passed'] for r in json.loads((HERE/'Structure.json').read_text(encoding='utf-8-sig')))
    assert json.loads((HERE/'TextScope.json').read_text(encoding='utf-8'))['Status']=='PASS'
    receipt={'Status':'PASS','WorkbookSHA256':hashlib.sha256(book.read_bytes()).hexdigest().upper(),
             'BuildCommand':'Build-Workbook.ps1 -OutputPath <preparation>/RC_Section_NDM.xlsm -UseFormattedLayout',
             'Sheets':list(sheets),'Tables':tables,'NoSavedUserGeometryOrCalculatedResults':True,
             'DefaultsAndExamplesComeFromBuilder':True,'WorkbookBytesUnchangedAfterNativeReadOnlyChecks':True}
(HERE/'CleanRelease.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
