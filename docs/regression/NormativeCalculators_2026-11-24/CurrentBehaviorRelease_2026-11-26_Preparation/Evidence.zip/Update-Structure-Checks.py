"""ДЛЯ ТЕСТОВ: связывает структурные ожидания с входными данными сборщика."""
from pathlib import Path
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'AGENTS.md').is_file())
path=ROOT/'tools/build_workbook/Validate-Workbook.ps1'
text=path.read_text(encoding='utf-8-sig')
first=text.index('        Add-Check $checks "Results ranges layout" (')
last=text.index('        Add-Check $checks "Stability duration loads range"',first)
text=text[:first]+'''        $layoutIssues=@()
        foreach($key in @('rngBatchSummary','rngStrengthSummaryAnchor','rngCrackSummaryAnchor',
            'rngStabilitySummaryAnchor','rngTorsionSummaryAnchor','rngNDMSectionGeometry',
            'rngNDMSectionProperties','rngNDMMaterialDiagrams','rngNDMSectionContours',
            'rngNDMElementResults','rngNDMElementGeometry','rngNDMSectionAnnotations','rngTorsionBarForces')){
            $range=$workbook.Names.Item($key).RefersToRange
            if(-not (Test-SavedNamedRange $range $key)){$layoutIssues+=($key+'='+$range.Worksheet.Name+'!'+$range.Address())}
        }
        Add-Check $checks "Results ranges layout" ($layoutIssues.Count -eq 0) ("WorkbookLayout.json; mismatches: "+($layoutIssues-join ', '))
'''+text[last:]
first=text.index('    $printArea = [string]$calc.PageSetup.PrintArea')
last=text.index('    $loadsRangeForLayout =',first)
text=text[:first]+'''    $printArea = [string]$calc.PageSetup.PrintArea
    $savedPrintArea=[string]@($layout.Sheets|Where-Object Name -ceq 'Расчет')[0].PrintArea
    $expectedPrintArea=if($UnformattedWorkbook){'$A$1:$AJ$60'}else{$savedPrintArea}
    $printAreaOk = $printArea.Contains($expectedPrintArea) -or $printAreaXml.Contains($expectedPrintArea)
    Add-Check $checks "Print area" $printAreaOk ("Expected=$expectedPrintArea; PageSetup=$printArea; Xml=$printAreaXml")
    Add-Check $checks "A4 portrait" (($calc.PageSetup.PaperSize -eq 9) -and ($calc.PageSetup.Orientation -eq 1)) ("PaperSize=$($calc.PageSetup.PaperSize); Orientation=$($calc.PageSetup.Orientation)")
    if($UnformattedWorkbook){
        Add-Check $checks "Print scale for one-page blocks" (($calc.PageSetup.Zoom -le 100) -and ($calc.HPageBreaks.Count -eq 0)) ("Zoom=$($calc.PageSetup.Zoom); HBreaks=$($calc.HPageBreaks.Count)")
        $breakColumns=@($calc.VPageBreaks|Where-Object Type -eq -4135|ForEach-Object {$_.Location.Column})
        Add-Check $checks "Vertical page breaks" ($breakColumns -contains 19) ("Columns: "+($breakColumns-join ', '))
    }else{
        $expectedPrint=Get-TestPrintLayoutSignature (Join-Path $PSScriptRoot 'CalculationPresentation.zip') -Template
        $actualPrint=Get-TestPrintLayoutSignature $fullWorkbookPath
        foreach($tag in $expectedPrint.Keys){
            Add-Check $checks ("Presentation print layout: "+$tag) ($actualPrint[$tag] -ceq $expectedPrint[$tag]) ("Expected="+$expectedPrint[$tag]+"; Actual="+$actualPrint[$tag])
        }
    }

'''+text[last:]
path.write_bytes(b'\xef\xbb\xbf'+text.replace('\n','\r\n').encode())
