"""Устанавливает принятые байты релиза, сохраняя пользовательскую книгу локально."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if (p/'AGENTS.md').is_file())
FULL=ROOT/'docs/regression/CurrentBehaviorRelease_2026-11-26_Full_Run01'
EXPECTED='FE0689F3DFECF0708D85A0027B5DEF7F3D97C071466171A25441AC48A6B5C807'
OUT=ROOT/'workbook/output'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

for name in ['GoalAcceptance.json','PrimaryAudit.json']:
    data=json.loads((FULL/name).read_text(encoding='utf-8-sig'))
    assert data['Status']=='PASS' and data['SourceSHA256']==EXPECTED
source=HERE/'RC_Section_NDM.xlsm'
assert sha(source)==sha(FULL/'Source/RC_Section_NDM.xlsm')==EXPECTED
with ZipFile(source) as package:
    assert package.testzip() is None

backups=[]
for name,initial in [('RC_Section_NDM.xlsm','UserSavedBeforeRelease.xlsm'),
                     ('RC_Section_NDM_execution_report.txt','UserSavedReportBeforeRelease.txt')]:
    current=OUT/name
    if not current.exists():
        continue
    backup=HERE/initial
    if not backup.exists() or sha(backup)!=sha(current):
        backup=HERE/('UserSavedAtInstall_'+name)
        assert not backup.exists(),'Preserve every existing backup'
        shutil.copy2(current,backup)
    assert sha(current)==sha(backup)
    backups.append({'Source':current.relative_to(ROOT).as_posix(),'LocalBackup':backup.relative_to(ROOT).as_posix(),
                    'SHA256':sha(backup),'Published':False})

native=(HERE/'NativeRelease.txt').read_text(encoding='utf-8-sig')
lines=native.splitlines()
assert lines[0]=='VBA PROJECT EXPORT' and lines[1]=='Workbook: RC_Section_NDM.xlsm' and lines[2].startswith('Date: ')
del lines[2]
export_text='\r\n'.join(lines)+'\r\n'
export_bytes=b'\xef\xbb\xbf'+export_text.encode('utf-8')
spec=importlib.util.spec_from_file_location('package',ROOT/'tools/build_workbook/Package-NormativeCalculators.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
export=OUT/'VBA_All_Code.txt'
export_temp=OUT/'VBA_All_Code.release.tmp'
export_temp.write_bytes(export_bytes)
assert len(helper.components(export_temp))==209
assert helper.components(export_temp)==helper.components(HERE/'NativeRelease.txt')

target=OUT/'RC_Section_NDM.xlsm'
temporary=OUT/'RC_Section_NDM.release.tmp'
shutil.copy2(source,temporary)
assert sha(temporary)==EXPECTED
os.replace(temporary,target)
os.replace(export_temp,export)
assert sha(target)==EXPECTED

archive=HERE/'OutputCleanup'
archive.mkdir(exist_ok=True)
cleanup=[]
for name in ['RC_Section_NDM_execution_report.txt','RC_NDM_ui_test_progress.txt']:
    old=OUT/name
    if not old.exists():
        continue
    dest=archive/name
    assert old.resolve().parent==OUT.resolve() and not dest.exists()
    digest=sha(old)
    shutil.move(str(old),str(dest))
    assert sha(dest)==digest
    cleanup.append({'From':old.relative_to(ROOT).as_posix(),'To':dest.relative_to(ROOT).as_posix(),
                    'SHA256':digest,'Published':False})

receipt={'Status':'PASS','WorkbookSHA256':sha(target),'ExportSHA256':sha(export),
         'InstalledWorkbookEqualsFullRunSource':True,'NativeComponents':209,
         'UserDataPreservedInLocalBackups':backups,'ArchivedOutputFiles':cleanup,
         'HistoryAndOtherWorktreesUnchanged':True}
(HERE/'Installation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['Status','WorkbookSHA256','ExportSHA256','NativeComponents']},ensure_ascii=False))
