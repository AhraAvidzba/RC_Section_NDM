"""ДЛЯ ТЕСТОВ: сверяет первичные журналы и состав завершённой релизной приёмки."""
from pathlib import Path
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if (p/'AGENTS.md').is_file())
FULL=ROOT/'docs/regression/CurrentBehaviorRelease_2026-11-26_Full_Run01'
EXPECTED='FE0689F3DFECF0708D85A0027B5DEF7F3D97C071466171A25441AC48A6B5C807'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def path(value):
    return ROOT/Path(value)

def log_check(file,macros=None,mode=None):
    text=file.read_text(encoding='utf-8-sig')
    starts=re.findall(r'^SUITE_STARTED: ([^;\r\n]+)',text,re.M)
    finishes=re.findall(r'^SUITE_FINISHED: ([^;\r\n]+)',text,re.M)
    if macros is not None:
        assert starts==finishes==macros,(file,starts,finishes,macros)
    failures=re.findall(r'^(?:FAIL[: ]|RUNTIME_ERROR[: ]|ERROR:).*',text,re.M)
    failed_counts=[int(n) for n in re.findall(r'\bfailed\s*=\s*(\d+)',text,re.I)]
    assert not failures and not any(failed_counts),(file,failures,failed_counts)
    assert 'SOURCE_UNCHANGED: True' in text,file
    assert 'WATCHDOG_COMPLETED: exit=0' in text,file
    if mode:
        assert f'GLOBAL_MODE: General.DiagramExtension={mode};' in text,file
        after=re.findall(r'^MODE_AFTER_SUITE: (\w+)',text,re.M)
        assert len(after)==len(starts) and set(after).issubset({'No','Yes'}),file
        overrides=re.findall(r'^SUITE_MODE_OVERRIDE: explicit test setup left (\w+); changes discarded on close',text,re.M)
        assert overrides==[value for value in after if value!=mode],file
    return {'Path':file.relative_to(ROOT).as_posix(),'SHA256':sha(file),'Executions':len(starts),'FailureLines':0}

run=read(FULL/'Run.json')
goal=read(FULL/'GoalAcceptance.json')
core=read(FULL/'CompleteCurrentAcceptance.json')
focused=read(FULL/'Focused/Acceptance.json')
focused_run=read(FULL/'Focused/Run.json')
supplement=read(FULL/'Supplement/Acceptance.json')
for record in [goal,core,focused,supplement]:
    assert record['Status']=='PASS' and record['SourceSHA256']==EXPECTED,record
assert sha(HERE/'RC_Section_NDM.xlsm')==sha(FULL/'Source/RC_Section_NDM.xlsm')==EXPECTED
assert not run['SourceChanged'] and not run['RunnerChanged']
assert goal['PrimaryExitCode']==goal['SupplementExitCode']==0
assert core['SingleInvocation'] and core['SameWorkbookBytes'] and goal['SameWorkbookBytes']
assert sha(FULL/'FullRunner.ps1')==run['RunnerSHA256']
assert sha(FULL/'ModeRunner.ps1')==run['ModeRunnerSHA256']
assert len(run['Jobs'])==len(run['CompletedJobs'])==12
assert len({(r['Group'],r['Mode']) for r in run['CompletedJobs']})==12
default=['modTestGeometry.RunGeometryTests','modTestMaterialDiagrams.RunMaterialDiagramTests',
         'modTestSectionSolver.RunSectionSolverTests','modTestCapacitySolver.RunCapacitySolverTests',
         'modTestCrackWidth.RunCrackWidthTests','modTestBatchCalculation.RunBatchCalculationTests',
         'modTestWorkbookInterface.RunWorkbookInterfaceTests','modTestRegressionBaseline.RunRegressionBaselineTests']
logs=[]
for job,done in zip(run['Jobs'],run['CompletedJobs']):
    assert (job['Group'],job['Mode'])==(done['Group'],done['Mode']) and done['ExitCode']==0
    macros=job['Macro'] or default
    assert len(macros)==job['ExpectedSuites']==done['ExpectedSuites']
    logs.append(log_check(path(done['Report']),macros,done['Mode']))
assert sum(r['Executions'] for r in logs)==core['CoreSuites']==202

expected_cases={}
for mode in ['No','Yes']:
    for shape in ['Rectangles','Circle','PointedSection','HollowRectangle']:
        expected_cases[f'{shape}_Generated_{mode}']=8
    expected_cases[f'SavedWorkbook_Saved_{mode}']=23
    expected_cases[f'SavedWorkbook_Paths_{mode}']=6
assert focused['IndividualCases']==core['FocusedSingleCases']==sum(expected_cases.values())==122
stages={s['ID']:s for s in focused['Stages']}
assert len(stages)==19 and all(s['Passed'] for s in stages.values()) and not focused['Errors']
assert set(expected_cases).issubset(stages)
records={r['ID']:r for r in focused_run['Records']}
assert len(records)==26 and all(r['Passed'] for r in records.values())
input_manifest=read(FULL/'Focused/Probe/InputManifest.json')
for identifier,count in expected_cases.items():
    text=path(records[identifier]['Report']).read_text(encoding='utf-8-sig')
    actual=re.search(r'TOTAL_FOCUSED_ACCEPTANCE:.*?cases=(\d+);',text)
    assert actual and int(actual[1])==count,identifier
    record=records[identifier]
    group=next(g for g in input_manifest['Groups'] if (g['Shape'],g['Group'])==(record['Argument1'],record['Argument2']))
    input_path=Path(group['Report'])
    assert sha(input_path)==group['ReportSHA256'],identifier
    selected=re.findall(r'^FOCUSED_INPUT\|id=([^|\r\n]+)',input_path.read_text(encoding='utf-8-sig'),re.M)
    timings=re.findall(r'^FOCUSED_TIME\|.*?\|id=([^|\r\n]+)',text,re.M)
    results=re.findall(r'^FOCUSED_RESULT\|id=([^|\r\n]+)',text,re.M)
    assert len(selected)==len(set(selected))==count and timings==selected,identifier
    assert results==[value for value in selected if value!='zero'],identifier
    if 'zero' in selected:
        assert re.search(r'^FOCUSED_TIME\|.*\|id=zero\|.*\|solverCalls=0$',text,re.M),identifier
        assert '.zeroStatesCleared' in text and '.zeroGeometryPreserved' in text,identifier
for identifier,record in records.items():
    if record['Kind']=='VBA':
        report=path(record['Report'])
        assert sha(report)==record['ReportSHA256'] and record['ExitCode']==0
        logs.append(log_check(report,[record['Macro']],record['Mode']))
        if identifier in expected_cases or identifier.startswith(('Batch15_','Stability_','AsymmetricSteel_')):
            text=report.read_text(encoding='utf-8-sig')
            assert re.search(r'^RESULTS_SAVE_REOPEN:.*equal=True',text,re.M),identifier
            assert re.search(r'^STATUS_STYLE_SAVE_REOPEN:.*equal=True',text,re.M),identifier

native=read(FULL/'Focused/NativeCAD/Stage.json')
assert native['Passed'] and not native['UserDocumentsUsed'] and len(native['Results'])==2
for r in native['Results']:
    file=FULL/'Focused/NativeCAD'/r['Macro']/'NativeCAD.txt'
    assert r['Passed'] and sha(file)==r['ReportSHA256']
    text=file.read_text(encoding='utf-8-sig')
    assert not re.search(r'^FAIL[: ]',text,re.M) and re.search(r'TOTAL_REAL_AUTOCAD_FAR_ORIGIN:.*failed=0',text)
independent=read(FULL/'Focused/Independent.json')
assert independent['Passed'] and independent['SourceSHA256']==EXPECTED
assert independent['ModelCount']==5 and independent['IndependentIntegrals']==563
assert independent['ReviewedNumFailStates']==7 and not independent['Unsupported']
assert len(independent['Failures'])==7
assert all(r['Passed'] and r['HiGHSStatus']==2 and r['StrictMarginN']>0
           and r['Classification']=='ProvenImpossibleByNecessaryForceBounds' for r in independent['Failures'])
for identifier,digest in independent['ReportHashes'].items():
    assert sha(path(records[identifier]['Report']))==digest,identifier
assert sha(FULL/'Focused/Run.json')==core['FocusedRunSHA256']
assert sha(FULL/'Focused/Independent.json')==core['IndependentSHA256']
assert focused_run['ProtectedInputsUnchanged']

assert supplement['ExpectedExecutions']==14 and [r['Mode'] for r in supplement['Results']]==['No','Yes']
for r in supplement['Results']:
    assert r['Passed'] and r['ExitCode']==0 and r['ProcessClosed'] and not r['Errors']
    assert len(r['Macros'])==7 and sha(path(r['Report']))==r['ReportSHA256']
    logs.append(log_check(path(r['Report']),r['Macros'],r['Mode']))
receipt={'Status':'PASS','SourceSHA256':EXPECTED,'CoreExecutions':202,'FocusedSingleCases':122,
         'SupplementExecutions':14,'NativeAutoCADStages':2,'IndependentModels':5,'IndependentIntegrals':563,
         'IndependentlyReviewedNumFailStates':7,'ExactMacroOrderChecked':True,'PrimaryLogs':logs,
         'FirstRunCompletedInFull':True,'FullRepeatRequired':False,
         'StartedUTC':run['StartedUTC'],'FinishedUTC':goal['FinishedUTC']}
output=FULL/'PrimaryAudit.json'
assert not output.exists(),'Do not overwrite a primary audit'
output.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PRIMARY_AUDIT_PASS: 202 core + 122 single + 14 supplement; real AutoCAD and independent controls verified')
