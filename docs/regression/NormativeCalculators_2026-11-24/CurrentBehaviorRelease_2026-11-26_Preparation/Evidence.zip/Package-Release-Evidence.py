"""Сохраняет компактные доказательства релиза без пользовательских резервных копий."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
from zipfile import ZipFile,ZIP_DEFLATED

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if (p/'AGENTS.md').is_file())
FULL=ROOT/'docs/regression/CurrentBehaviorRelease_2026-11-26_Full_Run01'
EXPECTED='FE0689F3DFECF0708D85A0027B5DEF7F3D97C071466171A25441AC48A6B5C807'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

assert sha(ROOT/'workbook/output/RC_Section_NDM.xlsm')==EXPECTED
assert read(FULL/'GoalAcceptance.json')['Status']==read(FULL/'PrimaryAudit.json')['Status']=='PASS'
assert subprocess.run(['git','diff','--quiet','3561d9d0','--','src','tests'],cwd=ROOT).returncode==0
positive=read(HERE/'Structure_Publication.json')
negative=read(HERE/'StructureNegativeAcceptance_Publication.json')
assert all(r['Passed'] for r in positive)
assert negative['Status']=='PASS' and len(negative['Cases'])==3 and all(r['Passed'] for r in negative['Cases'])
assert read(HERE/'EditorialReview.json')['Status']==read(HERE/'TextScope.json')['Status']=='PASS'
assert read(HERE/'CleanRelease.json')['WorkbookSHA256']==EXPECTED
assert read(HERE/'Portability.json')['WorkbookSHA256']==EXPECTED
spec=importlib.util.spec_from_file_location('package',ROOT/'tools/build_workbook/Package-NormativeCalculators.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
assert helper.components(ROOT/'workbook/output/VBA_All_Code.txt')==helper.components(HERE/'NativeRelease.txt')
assert len(helper.components(ROOT/'workbook/output/VBA_All_Code.txt'))==209

publication={'Status':'PASS','WorkbookSHA256':EXPECTED,
             'ExportSHA256':sha(ROOT/'workbook/output/VBA_All_Code.txt'),
             'NativeComponents':209,'SourceCodeUnchangedSinceFullRunCommit':'3561d9d0eaaf5aefc4ed02b705f1adb00e45ad41',
             'CoreExecutions':202,'FocusedSingleCases':122,'SupplementExecutions':14,
             'PrimaryAudit':'PrimaryAudit.json','CleanOutputInstalled':True,
             'PostRunChange':'Only the external structural checker and README; unused raw-layout option removed.',
             'PostRunPositiveStructureChecks':len(positive),'PostRunNegativeStructureCases':3,
             'UserBackupsExcludedFromPublication':True,'PriorRegressionHistoryRetained':True}
(HERE/'PublicationAcceptance.json').write_text(json.dumps(publication,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

receipts=[]
for directory in [HERE,FULL]:
    target=directory/'Evidence.zip'
    manifest_path=directory/'EvidenceManifest.json'
    assert not target.exists() and not manifest_path.exists(),'Preserve completed evidence archives'
    included=[];excluded=[]
    for file in sorted(directory.rglob('*')):
        if not file.is_file():continue
        relative=file.relative_to(directory)
        if relative.name in ['Evidence.zip','EvidenceManifest.json','EvidenceArchive.json']:continue
        private=relative.parts[0]=='OutputCleanup' or relative.name.startswith('UserSaved')
        duplicate=file.suffix.lower() in ['.xlsm','.xlsx']
        if private or duplicate:
            excluded.append({'Path':relative.as_posix(),'Reason':'Local user backup' if private else 'Workbook retained locally; accepted release published separately'})
            continue
        included.append({'Path':relative.as_posix(),'Bytes':file.stat().st_size,'SHA256':sha(file)})
    manifest={'Format':'NDM.ReleaseEvidence/1','SourceSHA256':EXPECTED,'Files':included,'Excluded':excluded,
              'LocalPrimaryFilesRetained':True,'WorkbookLocation':'workbook/output/RC_Section_NDM.xlsm'}
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with ZipFile(target,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
        for entry in included:archive.write(directory/entry['Path'],entry['Path'])
        archive.write(manifest_path,'EvidenceManifest.json')
    with ZipFile(target) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist())=={r['Path'] for r in included}|{'EvidenceManifest.json'}
        for entry in included:
            assert hashlib.sha256(archive.read(entry['Path'])).hexdigest().upper()==entry['SHA256']
        assert not any(Path(n).name.startswith('UserSaved') or n.startswith('OutputCleanup/') for n in archive.namelist())
    receipt={'Status':'PASS','Archive':'Evidence.zip','SHA256':sha(target),'Bytes':target.stat().st_size,
             'ArchivedFiles':len(included),'ManifestSHA256':sha(manifest_path),'UserBackupsIncluded':False}
    (directory/'EvidenceArchive.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    receipts.append(receipt)
print(json.dumps(receipts,ensure_ascii=False))
