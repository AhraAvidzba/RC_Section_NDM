"""ДЛЯ ТЕСТОВ: фиксирует охват локального поиска исторических и авторских формулировок."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if (p/'AGENTS.md').is_file())
inventory_path=HERE/'ReleaseTextInventory.json'
audit=json.loads(inventory_path.read_text(encoding='utf-8'))
pattern=re.compile(r'согласовано|согласованное программное|\bтеперь\b|по просьбе|по замечаниям|как мы обсуждали|тобой|твоему|вашему|до и после (?:исправления|рефакторинга)|Проверяет исправление|исправленного размерного|устаревших проверок|удалённому формату|историческ|прежний табличный|в этой версии|старого ограничения|старого большого гайда|плоскость раньше|прежние 380|фиксирует старую|старую матрицу|старую длинную|\bИИ\b|\bChatGPT\b|\bAI assistant\b',re.I)
sources=[r for r in audit['SourceFiles'] if Path(r['Path']).suffix in ['.cls','.bas','.vba']]
assert len(sources)==217
hits=[]
for entry in sources:
    path=ROOT/entry['Path']
    assert hashlib.sha256(path.read_bytes()).hexdigest().upper()==entry['SHA256'],path
    for i,line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(),1):
        if pattern.search(line):hits.append({'Path':entry['Path'],'Line':i,'Text':line})
for entry in audit['HelpCells']:
    if pattern.search(entry['Text']):hits.append(entry)
for entry in audit['HelpFormulaCells']:
    if pattern.search(entry['Formula']):hits.append(entry)
for entry in audit['DrawingCommentMatches']:
    if pattern.search(entry['Text']):hits.append(entry)
spec=importlib.util.spec_from_file_location('package',ROOT/'tools/build_workbook/Package-NormativeCalculators.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
native=h.components(HERE/'NativeRelease.txt')
assert len(native)==209
for name,(_,body) in native.items():
    for i,line in enumerate(body.splitlines(),1):
        if pattern.search(line):hits.append({'NativeComponent':name,'Line':i,'Text':line})
assert not hits,hits
receipt={'Status':'PASS','VBASourceFilesScanned':len(sources),'NativeVBAComponentsScanned':len(native),
         'BuildAndActiveDocumentationFilesScanned':len(audit['SourceFiles']),
         'ScannedSourceLines':sum(r['Lines'] for r in audit['SourceFiles']),
         'HelpTextCellsScanned':len(audit['HelpCells']),'HelpFormulaCellsScanned':len(audit['HelpFormulaCells']),
         'SearchPattern':pattern.pattern,'UnresolvedTargetPhrases':hits,'RewriteScope':'Локальные строки; остальной текст сохранен.',
         'PreservedCurrentContracts':['Предыдущий расчет, кэш и ранее выданные объекты относятся к данным текущего алгоритма.',
             'NDMSNP04/05/06, расширение .ndms, размеры матриц и технические имена описывают конкретные поддерживаемые форматы.',
             'Согласованность единиц, геометрии и равновесия имеет расчетный смысл.',
             'Сравнения и журналы в docs/reports и docs/regression сохраняют историю проверок.'],
         'InventorySHA256':hashlib.sha256(inventory_path.read_bytes()).hexdigest().upper(),
         'SourceScopeProof':'TextScope.json','CleanReleaseProof':'CleanRelease.json'}
(HERE/'EditorialReview.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
