﻿# ДЛЯ ТЕСТОВ: только затронутые расчётные, табличные, диагностические и файловые пути T.
param([ValidateSet('Baseline','Candidate')][string[]]$Labels=@('Baseline','Candidate'))
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$relative='docs/regression/NormativeCalculators_2026-11-24/TorsionTyped_2026-11-25'
$macros=@(
 'modTestTorsionPost.RunTorsionPostTests',
 'modTestTorsionPost.RunTorsionPostAvailabilityTests',
 'modTestTorsionPost.RunTorsionPostUnitTests',
 'modTestTorsionPost.RunTorsionPostOutputTests',
 'modTestTorsionPost.RunTorsionBarLengthTests',
 'modTestTorsionPost.RunTorsionPostGuardTests',
 'modTestTorsionPost.RunTorsionPostDiagnosticTests',
 'modTestTorsionPost.RunTorsionGeometryInvariantTests',
 'modTestTorsionPost.RunTorsionOnlyTests',
 'modTestTorsionProjections.RunTorsionCornerLengthTests'
)
$runs=@()
if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'DirectedRuns.json')){
 $runs=@(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'DirectedRuns.json') -Raw -Encoding UTF8|ConvertFrom-Json)
}
foreach($label in $Labels){
 foreach($mode in @('No','Yes')){
  # Резерв при одновременном старом полном наборе: 4 ГиБ + 4 ГиБ + 3 ГиБ для Codex.
  $o=Get-CimInstance Win32_OperatingSystem
  $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
  if($o.FreePhysicalMemory/1MB -lt 11 -or ($m.CommitLimit-$m.CommittedBytes)/1GB -lt 11){throw 'Combined process memory reserve insufficient; defer this directed job.'}
  $report=$relative+'/'+$label+'_'+$mode+'.txt'
  if(Test-Path -LiteralPath (Join-Path $root $report)){throw 'Fresh directed report required.'}
  $source=Join-Path $PSScriptRoot ($label+'.xlsm')
  Write-Output ('START '+$label+' '+$mode+'; '+[DateTimeOffset]::Now.ToString('o'))
  & (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') -SourceWorkbook $source -ReportPath $report -Mode $mode -Macro ($macros -join ',') -TimeoutSeconds 1800 -NormativeCoreGuard
  if($LASTEXITCODE -ne 0){throw ('Related torsion tests failed: '+$label+' '+$mode)}
  $body=[IO.File]::ReadAllText((Join-Path $root $report))
  if($body -match '(?m)^FAIL[: ]|Failed=[1-9]|failed=[1-9]|RUNTIME ERROR|WATCHDOG_FAILURE'){throw ('Related report failed: '+$report)}
  if([regex]::Matches($body,'(?m)^SUITE_FINISHED:').Count -ne $macros.Count){throw 'Related test scope incomplete.'}
  $runs+=,[ordered]@{Label=$label;Mode=$mode;SourceSHA256=(Get-FileHash -LiteralPath $source).Hash;Report=$report;Macros=$macros;Passed=$true}
  $runs|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'DirectedRuns.json') -Encoding UTF8
 }
}
Write-Output 'RELATED_TORSION_COMPLETE: 40 executions, no new full suite started.'
