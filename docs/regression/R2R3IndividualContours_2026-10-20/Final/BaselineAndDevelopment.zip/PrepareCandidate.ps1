# Обновляет явно перечисленные компоненты только в новой изолированной копии.
param([Parameter(Mandatory=$true)][string]$SourceWorkbook,[Parameter(Mandatory=$true)][string]$Directory,[Parameter(Mandatory=$true)][string]$Modules)
$ErrorActionPreference='Stop'
function Get-ComProperty([object]$Target,[string]$Property) {
 $value=$Target.GetType().InvokeMember($Property,[Reflection.BindingFlags]::GetProperty,$null,$Target,$null)
 return ,$value
}
$source=(Resolve-Path -LiteralPath $SourceWorkbook).Path
if(Test-Path -LiteralPath $Directory){throw 'Candidate directory already exists.'}
New-Item -ItemType Directory -Path $Directory | Out-Null
$directoryPath=(Resolve-Path -LiteralPath $Directory).Path
$target=Join-Path $directoryPath 'RC_Section_NDM.xlsm'
$sourceHash=(Get-FileHash -LiteralPath $source).Hash
Copy-Item -LiteralPath $source -Destination $target
$excel=$null;$book=$null
try {
 $excel=New-Object -ComObject Excel.Application
 $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=1
 $book=$excel.Workbooks.Open($target)
 $project=Get-ComProperty $book 'VBProject'
 $components=Get-ComProperty $project 'VBComponents'
 foreach($file in ($Modules -split ',')) {
  $text=[IO.File]::ReadAllText((Resolve-Path -LiteralPath $file).Path,[Text.Encoding]::UTF8)
  $name=[regex]::Match($text,'Attribute VB_Name = "([^"]+)"').Groups[1].Value
  if(-not $name){throw 'Missing component name.'}
  $component=$null
  try {$component=$components.Item($name)} catch {}
  if($null -eq $component){$kind=1;if($file.EndsWith('.cls')){$kind=2};$component=$components.Add($kind);$component.Name=$name}
  $body=[regex]::Match($text,'(?ms)^Option Explicit.*').Value
  if(-not $body){
   $body=(($text -split "`r?`n") | Where-Object {$_ -notmatch '^Attribute '}) -join "`r`n"
   $codeLines=@(($body -split "`r?`n") | Where-Object { $_.Trim() -and -not $_.TrimStart().StartsWith("'") })
   if($codeLines.Count){throw ('Missing module body: '+$name)}
  }
  $code=Get-ComProperty $component 'CodeModule'
  if($code.CountOfLines){$code.DeleteLines(1,$code.CountOfLines)}
  $code.AddFromString(($body -split "`r?`n") -join "`r`n")
 }
 $vbe=Get-ComProperty $excel 'VBE'
 $bars=Get-ComProperty $vbe 'CommandBars'
 $compile=$bars.FindControl(1,578)
 if($compile.Enabled){$compile.Execute()}
 if($compile.Enabled){
  $pane=Get-ComProperty $vbe 'ActiveCodePane'
  $row=0;$column=0;$lastRow=0;$lastColumn=0
  $pane.GetSelection([ref]$row,[ref]$column,[ref]$lastRow,[ref]$lastColumn)
  @{Compiled=$false;Module=$pane.CodeModule.Parent.Name;Row=$row;Column=$column;LastColumn=$lastColumn;Line=$pane.CodeModule.Lines($row,1)} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $directoryPath 'Preparation.json') -Encoding UTF8
  throw 'Candidate VBA compilation failed; see Preparation.json.'
 }
 $book.Save()
 $receipt=@{Compiled=$true;SourceSHA256=$sourceHash;UpdatedSources=($Modules -split ',');ProductionChanged=$false}
}
finally {
 if($book){$book.Close($false)}
 if($excel){$excel.Quit()}
}
if((Get-FileHash -LiteralPath $source).Hash -ne $sourceHash){throw 'Source workbook changed.'}
$receipt.CandidateSHA256=(Get-FileHash -LiteralPath $target).Hash
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $directoryPath 'Preparation.json') -Encoding UTF8
Write-Output 'CANDIDATE_COMPILED'
