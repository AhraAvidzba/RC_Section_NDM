param([Parameter(Mandatory=$true)][string]$WorkbookPath,[Parameter(Mandatory=$true)][string]$ReportPath)
$ErrorActionPreference='Stop'
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class NDMCompileWindow { [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p); }'
$excel=$null; $book=$null
function Get-ComProperty([object]$Target,[string]$Property) {
 $value=$Target.GetType().InvokeMember($Property,[Reflection.BindingFlags]::GetProperty,$null,$Target,$null)
 return ,$value
}
try {
 $excel=New-Object -ComObject Excel.Application
 $excel.Visible=$false; $excel.DisplayAlerts=$false; $excel.EnableEvents=$false; $excel.AutomationSecurity=1
 $excelProcessID=[uint32]0
 [void][NDMCompileWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$excelProcessID)
 $process=Get-Process -Id $excelProcessID
 @{ExcelPID=$excelProcessID;StartTicks=$process.StartTime.ToUniversalTime().Ticks;Status='COMPILING'} | ConvertTo-Json | Set-Content -LiteralPath $ReportPath -Encoding UTF8
 $book=$excel.Workbooks.Open((Resolve-Path -LiteralPath $WorkbookPath).Path,0,$true)
 $vbe=Get-ComProperty $excel 'VBE'
 $bars=Get-ComProperty $vbe 'CommandBars'
 $compile=$bars.FindControl(1,578)
 if($compile.Enabled){$compile.Execute()}
 $row=0;$column=0;$lastRow=0;$lastColumn=0
 $pane=Get-ComProperty $vbe 'ActiveCodePane'
 if($null -ne $pane){$pane.GetSelection([ref]$row,[ref]$column,[ref]$lastRow,[ref]$lastColumn)}
 $result=@{Compiled=(-not $compile.Enabled); Module=$(if($pane){$pane.CodeModule.Parent.Name}else{''});Row=$row;Line=$(if($pane -and $row -gt 0){$pane.CodeModule.Lines($row,1)}else{''})}
 $result | ConvertTo-Json | Set-Content -LiteralPath $ReportPath -Encoding UTF8
 $result | ConvertTo-Json
}
catch {
 @{Status='COMPILE_DIAGNOSTIC_ERROR';Reason=$_.Exception.Message;ExcelPID=$excelProcessID;StartTicks=$process.StartTime.ToUniversalTime().Ticks} | ConvertTo-Json | Set-Content -LiteralPath $ReportPath -Encoding UTF8
 throw
}
finally {
 if($book){$book.Close($false)}
 if($excel){$excel.Quit()}
}
