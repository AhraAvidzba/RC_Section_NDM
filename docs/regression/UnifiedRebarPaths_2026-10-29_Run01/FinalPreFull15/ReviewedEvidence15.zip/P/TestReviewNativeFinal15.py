"""ДЛЯ ТЕСТОВ: фиксирует просмотр двух native PNG и точные проверки окончательной книги."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

p = Path(__file__).parent
r = Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
e = r / 'docs/regression/UnifiedRebarPaths_2026-10-29_Run01'
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
build = read(e / 'Build12/Build.json')
equality = read(p / 'SourceEquality12.json')
primary = read(p / 'FourModePrimaryTerminalReview14.json')
closures = read(p / 'AllPreFullOwnClosures15.json')
controls = read(p / 'Native12/Main/EndModeControls.json')
defaults = read(p / 'Native12/Main/FinalHelpAndDefaults.json')
assert build['Status'] == 'CLEAN_BUILD_COMPILED' and build['OwnIdentityTerminal']
assert equality['Passed'] and equality['SourceComponents'] == 175 and equality['ExportComponents'] == 181
assert primary['Status'] == 'PASS_COMPLETE_DIRECTED_PRIMARY_READ'
assert closures['AllOwnIdentitiesTerminal'] and closures['UniqueOwnCount'] == 180
assert controls['PositiveIndividualChoices'] == 68 and controls['RejectedCombinedOrUnknown'] == 85
assert controls['ProjectionDashes'] == 4 and controls['HelpMatchesExistingParagraphStyle']
assert defaults['ChangedDefaultCells'] == 16 and all(row['Value'] == 40 for row in defaults['SetbackDefaults'])
book = e / 'Build12/RC_Section_NDM.xlsm'
assert hashlib.sha256(book.read_bytes()).hexdigest().upper() == build['BookSHA256']
ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(book) as z:
    sheets = ET.fromstring(z.read('xl/workbook.xml')).find('m:sheets', ns)
    assert [sheet.attrib['name'] for sheet in sheets][2] == 'Справка'
    help_xml = ET.fromstring(z.read('xl/worksheets/sheet3.xml'))
    links = [(link.attrib['ref'], link.attrib.get('location', '')) for link in help_xml.findall('m:hyperlinks/m:hyperlink', ns)]
    common_links = [item for item in links if item[1] == "'Справка'!A711"]
    assert common_links == [('B730', "'Справка'!A711"), ('B737', "'Справка'!A711"), ('B744', "'Справка'!A711"), ('B752', "'Справка'!A711")], common_links

images = []
for name in ('Main_EndMode.png', 'Help_Common.png'):
    path = p / 'Native12/Main' / name
    images.append({'Path': str(path), 'SHA256': hashlib.sha256(path.read_bytes()).hexdigest().upper(), 'VisualReview': 'Viewed in this conversation: readable text, same peer style, no clipped body paragraphs; Main s0/s1 show40.'})
proof = {'Status': 'FINAL_SAVED_NATIVE_AND_DIRECTED_REFERENCE_REVIEW_PASS', 'ObservedUTC': datetime.now(timezone.utc).isoformat(), 'NativeSourceSHA256': build['BookSHA256'], 'DirectedReferenceSHA256': primary['SourceSHA256'], 'PrimaryAndStdoutStderrAllRead': True, 'NativeImagesReviewed': True, 'Images': images, 'ImageDeliveryToUserClaim': False, 'APICatalog338Reviewed': True, 'APICatalogChecks': ['SOURCE_CALLS_AND_NATIVE_ROOTS_MATCH', 'SOURCE_MANIFEST_DOC_EXAMPLES_MATCH', 'API_CATALOG_MUTATION_GUARDS_PASS3'], 'APIManifestSHA256': hashlib.sha256((r / 'docs/geometry_refactor/SECTION_RECIPE_API_MANIFEST.json').read_bytes()).hexdigest().upper(), 'SharedHelpLinks': common_links, 'FinalDefaultCells': 16, 'SavedNativeIndividualChoices': 68, 'RejectedCombinedOrUnknown': 85, 'AllOwnTerminalCount': 180, 'FinalExecutableVBAStatementsEqual': True, 'FinalBookRequiresFullAcceptance': True, 'FullAcceptanceClaim': False}
(p / 'FourModeDirectedTerminalReview15.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: proof[key] for key in ('Status', 'NativeSourceSHA256', 'DirectedReferenceSHA256', 'AllOwnTerminalCount', 'FullAcceptanceClaim')}))
