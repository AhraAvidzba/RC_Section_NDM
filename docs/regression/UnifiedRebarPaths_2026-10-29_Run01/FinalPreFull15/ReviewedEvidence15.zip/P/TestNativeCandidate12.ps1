﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет сохранённую чистую сборку без запуска макросов и сохранения.
$ErrorActionPreference='Stop'
Import-Module 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1' -Global
$repoOuter='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
Set-Location -LiteralPath $repoOuter
. (Join-Path $repoOuter 'tools/build_workbook/GeometryTables.ps1')
$directory='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/UnifiedRebarPaths_2026-10-29_Run01'
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestNativeEndModeOwner12{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve insufficient'}
$app=$null;$book=$null;$project=$null;$component=$null;$code=$null
$ownedNew=$false
try{
 $preexistingExcelIDs=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object {$_.Id})
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestNativeEndModeOwner12]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 if($preexistingExcelIDs-contains$owned){$app=$null;throw 'Existing Excel returned; no user instance modified or closed'}
 $ownedNew=$true
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks}|ConvertTo-Json|Set-Content (Join-Path $directory 'Native12Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 foreach($case in @('Main')){
  $path=Join-Path $repoOuter 'docs/regression/UnifiedRebarPaths_2026-10-29_Run01/Build12/RC_Section_NDM.xlsm';$hash=(Get-FileHash -LiteralPath $path).Hash
  $book=$app.Workbooks.Open($path,0,$true);if(-not$book.ReadOnly){throw 'Readonly required'}
  $project=$book.VBProject;if($project.VBComponents.Count-ne181){throw '181 real components required'}
  $out=Join-Path $directory ('Native12/'+$case);[void][IO.Directory]::CreateDirectory($out)
  $all=New-Object Text.StringBuilder;[void]$all.AppendLine('VBA PROJECT EXPORT');[void]$all.AppendLine('Workbook: '+$book.Name);[void]$all.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $names=@()
  for($i=1;$i-le$project.VBComponents.Count;$i++){
   $component=$project.VBComponents.Item($i);$code=$component.CodeModule;$n=[int]$code.CountOfLines;$body=if($n){[string]$code.Lines(1,$n)}else{''}
   [void]$all.AppendLine('='*100);[void]$all.AppendLine('COMPONENT: '+$component.Name);[void]$all.AppendLine('TYPE: '+$component.Type);[void]$all.AppendLine('LINES: '+$n);[void]$all.AppendLine('='*100);if($n){[void]$all.AppendLine($body)};[void]$all.AppendLine()
   [IO.File]::WriteAllText((Join-Path $out ($component.Name+'.txt')),$body,[Text.Encoding]::UTF8);$names+=[ordered]@{Name=[string]$component.Name;Type=[int]$component.Type;Lines=$n}
  }
  [IO.File]::WriteAllText((Join-Path $out 'VBA_All_Code.txt'),$all.ToString(),[Text.Encoding]::UTF8)

  # ДЛЯ ТЕСТОВ: каждый пункт нового сохранённого списка проверяется нативным Validation.Value.
  $setbackDefaults=@()
  $geometry=@();$options=@('IncludeBoth','ExcludeBoth','IncludeStart','IncludeEnd')
  $positiveChoices=0;$negativeChoices=0;$projectedRows=0
  foreach($definition in @(Get-GeometrySettingsCatalog)){
   $table=$book.Names.Item($definition.RangeName).RefersToRange
   $expectedName=@((Get-Content -LiteralPath (Join-Path $repoOuter 'tools/build_workbook/WorkbookLayout.json') -Raw -Encoding UTF8|ConvertFrom-Json).Names|Where-Object Name -eq $definition.RangeName)[0]
   if($table.Address()-cne$expectedName.Address -or $table.Rows.Count-ne$expectedName.Rows -or $table.Columns.Count-ne$expectedName.Columns){throw ('Outer geometry bounds changed: '+$definition.RangeName)}
   $main=@(Get-GeometryTableBlocks $table|Where-Object Key -eq 'Main')[0]
   if([int]$main.Columns.endMode-ne8 -or [int]$main.Columns.note-ne9){throw 'Main field order differs'}
   $rows=@(($definition.Blocks|Where-Object Key -eq 'Main').Rows)
   foreach($row in $rows){
    if($definition.Type-ceq'Rectangles'){
     foreach($field in @('s0','s1')){
      $defaultCell=Get-GeometryTableCell $table 'Main' ([string]$row[0]) $field
      if([double]$defaultCell.Value2-ne40){throw ('Rectangles default must be40: '+[string]$row[0]+'/'+$field)}
      $setbackDefaults+=,[ordered]@{Row=[string]$row[0];Field=$field;Value=$defaultCell.Value2;Address=$defaultCell.Address()}
     }
    }
    $key=[string]$row[0];$cell=Get-GeometryTableCell $table 'Main' $key 'endMode';$original=$cell.Formula
    $note=Get-GeometryTableCell $table 'Main' $key 'note'
    if([string]$cell.Value2-cne[string]$row[7]){throw ('Incorrect configured default: '+$definition.Type+'/'+$key)}
    if($cell.HorizontalAlignment-ne-4108 -or $cell.WrapText -or $note.HorizontalAlignment-ne-4152 -or $note.WrapText){throw 'Main alignment/wrap differs'}
    if($key-like'Opening*'){
     if([string]$cell.Value2-cne[char]0x2014 -or [int]$cell.Interior.Color-eq15135487){throw 'Projection must show a non-input dash'}
     $projectedRows++
    }else{
     if($cell.Validation.Type-ne3 -or -not$cell.Validation.InCellDropdown -or -not$cell.Validation.ShowError){throw 'Saved list is missing'}
     if([int]$cell.Interior.Color-ne15135487){throw 'Editable EndMode fill differs'}
     foreach($choice in $options){$cell.Value2=$choice;if(-not$cell.Validation.Value){throw ('Saved EndMode rejects individual choice: '+$choice)};$positiveChoices++}
     foreach($bad in @('IncludeBoth,ExcludeBoth,IncludeStart,IncludeEnd','IncludeBoth;ExcludeBoth;IncludeStart;IncludeEnd','Auto','ClosedUniform','TEST_UNKNOWN_END_MODE')){
      $cell.Value2=$bad;if($cell.Validation.Value){throw ('Saved EndMode accepts invalid combined/unknown value: '+$bad)};$negativeChoices++
     }
     $cell.Formula=$original
     if([string]$cell.Value2-cne[string]$row[7]){throw 'EndMode default not restored'}
    }
    foreach($edge in 7..10){if($cell.Borders.Item($edge).LineStyle-eq-4142 -or $note.Borders.Item($edge).LineStyle-eq-4142){throw 'New Main cell/note border missing'}}
    $geometry+=,[ordered]@{Type=$definition.Type;Key=$key;EndMode=[string]$cell.Value2;Address=$cell.Address();CommentAddress=$note.Address();CommentRightAligned=$true;Bounds=$table.Address();Rows=$table.Rows.Count;Columns=$table.Columns.Count}
   }
  }
  # ДЛЯ ТЕСТОВ:21 строка =17 редактируемых+4 проекционных;17×4 разрешённых и17×5 запрещённых значений.
  [ordered]@{EditableCells=17;ModeChoices=$options;ExpectedPositive=17*$options.Count;ActualPositive=$positiveChoices;ExpectedNegative=17*5;ActualNegative=$negativeChoices;ExpectedProjectionDashes=4;ActualProjectionDashes=$projectedRows;ActualRows=$geometry.Count}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $out 'EndModeControlCounts.json') -Encoding UTF8
  if($geometry.Count-ne21 -or $options.Count-ne4 -or $positiveChoices-ne68 -or $negativeChoices-ne85 -or $projectedRows-ne4){throw 'Native four-mode EndMode list coverage incomplete'}
  $help=$book.Worksheets.Item('Справка');$helpCells=@()
  foreach($text in @('Поле «Расстановка» (endMode)','При n = 1','При совпадении центров основных стержней Main')){
   $found=$help.Cells.Find($text,[Type]::Missing,-4163,2,1,1,$false)
   if($null-eq$found){throw ('Help paragraph missing: '+$text)}
   $helpCells+=,[ordered]@{Text=$text;Address=$found.Address();FontName=[string]$found.Font.Name;FontSize=$found.Font.Size;Bold=$found.Font.Bold;Fill=$found.Interior.Color;HorizontalAlignment=$found.HorizontalAlignment;WrapText=$found.WrapText}
  }
  if($setbackDefaults.Count-ne16){throw 'Exactly16 saved Rectangles s0/s1 defaults must be40'}
  $expectedHelp='Поле «Расстановка» (endMode) задаёт размещение стержней на пути после отступов s0 и s1: IncludeBoth — на обоих концах и между ними; ExcludeBoth — между концами; IncludeStart — в начале и внутри пути; IncludeEnd — в конце и внутри пути. Направление пути указано в справке своего типа сечения.'
  $actualHelp=$help.Cells.Find('Поле «Расстановка» (endMode)',[Type]::Missing,-4163,2,1,1,$false)
  if([string]$actualHelp.Value2-cne$expectedHelp){throw 'Saved Help must contain the exact approved current-contract explanation'}
  $helpData=$help.UsedRange.Value2
  foreach($value in $helpData){if([string]$value-match'(?i)(прежн.{0,35}(способ|поведени)|стар.{0,35}(способ|поведени))'){throw 'Saved Help contains an unexplained historical behavior description'}}
  [ordered]@{Status='SAVED_RECTANGLES_DEFAULTS_AND_CURRENT_HELP_PASS';ChangedDefaultCells=16;SetbackDefaults=$setbackDefaults;CommonEndModeText=[string]$actualHelp.Value2;HistoricalBehaviorPhrases=0;SavedAgain=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $out 'FinalHelpAndDefaults.json') -Encoding UTF8
  $defaultCell=$null;$actualHelp=$null;$helpData=$null
  $body=$help.Cells.Find('Дополнительные ряды арматуры задаются в блоке Extra таблицы.',[Type]::Missing,-4163,2,1,1,$false)
  if($null-eq$body){throw 'Existing comparable Help paragraph missing'}
  foreach($record in $helpCells){
   if($record.FontName-cne[string]$body.Font.Name -or $record.FontSize-ne$body.Font.Size -or $record.Bold-ne$body.Font.Bold -or $record.Fill-ne$body.Interior.Color -or $record.HorizontalAlignment-ne$body.HorizontalAlignment -or $record.WrapText-ne$body.WrapText){throw 'New Help paragraph styling differs from existing peer paragraph'}
  }
  [ordered]@{Status='NATIVE_SAVED_REOPENED_END_MODE_CONTROLS';PositiveIndividualChoices=$positiveChoices;RejectedCombinedOrUnknown=$negativeChoices;ProjectionDashes=$projectedRows;OriginalsRestored=$true;SavedAgain=$false;Tables=$geometry;HelpParagraphs=$helpCells;HelpMatchesExistingParagraphStyle=$true}|ConvertTo-Json -Depth 7|Set-Content -LiteralPath (Join-Path $out 'EndModeControls.json') -Encoding UTF8

  # ДЛЯ ТЕСТОВ: снимки готовых Main и общей справки; копирование рисунка не сохраняет входную книгу.
  $scratch=$app.Workbooks.Add()
  try{
   $images=@(@('Сечения','A32:K43','Main_EndMode'),@('Справка','A711:F723','Help_Common'))
   foreach($image in $images){
    $sheet=$book.Worksheets.Item($image[0]);$capture=$sheet.Range($image[1]);$sheet.Activate();$capture.CopyPicture(1,2)
    $canvas=$scratch.Worksheets.Item(1);$canvas.Activate();$chartBox=$canvas.ChartObjects().Add(0,0,[double]$capture.Width,[double]$capture.Height)
    try{$chartBox.Activate();$chartBox.Chart.Paste();$imagePath=Join-Path $out ($image[2]+'.png');if(-not$chartBox.Chart.Export($imagePath,'PNG')){throw 'Native picture export failed'}}finally{$chartBox.Delete();$chartBox=$null}
   }
  }finally{$capture=$null;$sheet=$null;$canvas=$null;$scratch.Close($false);$scratch=$null}

  $cell=$null;$note=$null;$table=$null;$found=$null;$body=$null;$help=$null

  $range=$book.Names.Item('rngSystemSettings').RefersToRange;$data=$range.Value2;$settings=@{}
  for($row=2;$row-le$data.GetLength(0);$row++){
   $key=[string]$data[$row,1]
   if($key-and-not$key.StartsWith('[')){$settings[$key]=[ordered]@{Value=$data[$row,2];Address=$range.Cells.Item($row,2).Address()}}
  }
  foreach($pair in @(@('Mesh.CellGeometry','Contour'),@('Mesh.StepMode','Auto 0.1'),@('Results.SnapshotStorage','Excel'),@('Output.CombinationMode','Worst'))){if($settings[$pair[0]].Value-cne$pair[1]){throw ('Incorrect clean default '+$pair[0])}}
  foreach($key in @('Mesh.CellGeometry','Geometry.Type','Results.SnapshotStorage','Output.CombinationMode')){
   $cell=$book.Worksheets.Item('Config').Range($settings[$key].Address)
   if($cell.Validation.Type-ne3-or-not$cell.Validation.InCellDropdown){throw ('Required saved dropdown missing: '+$key)}
   $settings[$key]['ValidationFormula']=[string]$cell.Validation.Formula1
  }
  $cell=$null
  $clean=@{}
  foreach($name in @('rngNDMSectionGeometry','rngNDMSectionProperties','rngNDMMaterialDiagrams','rngNDMSectionContours','rngNDMElementResults','rngNDMElementGeometry','rngNDMSectionAnnotations')){
   $range=$book.Names.Item($name).RefersToRange
   if([string]$range.Offset(1,0).Value2-ne''){throw ('Not a clean snapshot: '+$name)}
   $clean[$name]=$range.Address()
  }
  $range=$book.Names.Item('rngLoadCombinations').RefersToRange;$data=$range.Value2
  for($row=2;$row-le$data.GetLength(0);$row++){foreach($column in 1..4){if([string]$data[$row,$column]-ne''){throw 'User loads must not be copied'}}}
  $sheetOrder=(($book.Worksheets|ForEach-Object {$_.Name})-join'|')
  if($sheetOrder-cne'Config|Сечения|Справка|Расчет|Results'){throw 'Unexpected sheet order'}
  $plotSheet=$book.Worksheets.Item('Расчет');$plotCharts=$plotSheet.ChartObjects();$elementShapes=0;$charts=@()
  for($j=1;$j-le$plotCharts.Count;$j++){
   $plotChart=$plotCharts.Item($j).Chart
   for($k=1;$k-le$plotChart.Shapes.Count;$k++){if([string]$plotChart.Shapes.Item($k).Name-match'^NDMPlot_Element(Concrete|Rebar)'){$elementShapes++}}
   $charts+=,[ordered]@{Name=[string]$plotCharts.Item($j).Name;Shapes=$plotChart.Shapes.Count;Series=$plotChart.SeriesCollection().Count}
  }
  if($elementShapes-ne0){throw 'Clean template contains previous section element shapes'}
  [ordered]@{FromWorkbookLayout=$true;Charts=$charts;ElementShapes=$elementShapes}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'EmptyPlotContainers.json') -Encoding UTF8
  $plotChart=$null;$plotCharts=$null;$plotSheet=$null
  [ordered]@{Settings=$settings;CleanSnapshotAnchors=$clean;SheetOrder=$sheetOrder;UserLoadsCopied=$false;PreviousPlotCopied=$false;CalculationsOrBehaviorTestsRun=$false}|ConvertTo-Json -Depth 7|Set-Content (Join-Path $out 'CleanStructure.json') -Encoding UTF8
  $range=$null
  [ordered]@{Case=$case;SHA256=$hash;ReadOnly=[bool]$book.ReadOnly;MacroRunImportSave=$false;Components=$names;ConfigPresent=($book.Worksheets.Item('Config').Name-eq'Config');GeometryAnchor=$book.Names.Item('rngNDMSectionGeometry').RefersTo;BoundariesAnchor=$book.Names.Item('rngNDMElementGeometry').RefersTo}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $out 'NativeVerification.json') -Encoding UTF8
  $code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $book.Close($false);$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if((Get-FileHash -LiteralPath $path).Hash-cne$hash){throw 'Readonly package changed'}
  Write-Output ('NATIVE_READONLY: '+$case+'; 181 components')
 }
}catch{
 [ordered]@{PrimaryError=$_.Exception.ToString();Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $directory 'Native12Failure.json') -Encoding UTF8
 throw
}finally{
 $cell=$null;$range=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app-and$ownedNew){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;QuitRequested=$true;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $directory 'Native12Quit.json') -Encoding UTF8
}
