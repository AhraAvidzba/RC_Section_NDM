﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Публикует проверенную чистую книгу с окончательными defaults и справкой; полный PASS не присваивает.
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$private=$PSScriptRoot
$evidence=Join-Path $root 'docs/regression/UnifiedRebarPaths_2026-10-29_Run01'
$review=Get-Content -LiteralPath (Join-Path $private 'FourModeDirectedTerminalReview15.json') -Raw|ConvertFrom-Json
$closures=Get-Content -LiteralPath (Join-Path $private 'AllPreFullOwnClosures15.json') -Raw|ConvertFrom-Json
$matrix=Get-Content -LiteralPath (Join-Path $private 'DirectedMatrix16.json') -Raw|ConvertFrom-Json
$build=Get-Content -LiteralPath (Join-Path $evidence 'Build12/Build.json') -Raw|ConvertFrom-Json
$equality=Get-Content -LiteralPath (Join-Path $private 'SourceEquality12.json') -Raw|ConvertFrom-Json
$statements=Get-Content -LiteralPath (Join-Path $private 'ExecutableStatementsEquality15.json') -Raw|ConvertFrom-Json
$transfer=Get-Content -LiteralPath (Join-Path $private 'HelpAndDefaultsTransfer15.json') -Raw|ConvertFrom-Json
if($review.Status-cne'FINAL_SAVED_NATIVE_AND_DIRECTED_REFERENCE_REVIEW_PASS'-or-not$review.PrimaryAndStdoutStderrAllRead-or-not$review.NativeImagesReviewed-or-not$review.APICatalog338Reviewed-or$review.FullAcceptanceClaim){throw 'Actual saved native/current text review required'}
if(-not$closures.AllOwnIdentitiesTerminal-or$closures.FullAcceptanceClaim){throw 'Fresh own closure required'}
foreach($identity in $closures.Identities){
 $process=$null;try{$process=Get-Process -Id ([int]$identity.PID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId-notlike'NoProcessFoundForGivenId*'){throw}}
 if($process-and[string]$process.StartTime.ToUniversalTime().Ticks-ceq[string]$identity.StartTicksUTC){throw ('Own identity still live: '+$identity.PID)}
}
if($matrix.Status-cne'DIRECTED_PASS'-or@($matrix.Completed).Count-ne2-or$review.DirectedReferenceSHA256-cne$matrix.SourceSHA256-or$statements.DirectedSourceSHA256-cne$matrix.SourceSHA256-or-not$statements.ExecutableStatementsEqual){throw 'Directed executable reference proof differs'}
foreach($step in $matrix.Completed){if(-not$step.Passed-or@($step.Finished).Count-ne40){throw 'Both40-macro reference modes must be complete'}}
if($transfer.ChangedDefaultCells-ne16-or$transfer.S0S1Defaults-ne40-or$transfer.ProductionExecutableStatementsChanged){throw 'Only approved final defaults and text changes may follow directed reference'}
foreach($file in $transfer.Files){if((Get-FileHash -LiteralPath (Join-Path $root $file.Path)).Hash-cne$file.AfterSHA256){throw ('Final reviewed input changed: '+$file.Path)}}
if($review.NativeSourceSHA256-cne$build.BookSHA256-or-not$equality.Passed-or$equality.SourceComponents-ne175-or$equality.ExportComponents-ne181-or@($equality.Missing).Count-or@($equality.Differences).Count){throw 'Exact native code equality175+6 required'}
$native=Get-Content -LiteralPath (Join-Path $private 'Native12/Main/NativeVerification.json') -Raw|ConvertFrom-Json
$defaults=Get-Content -LiteralPath (Join-Path $private 'Native12/Main/FinalHelpAndDefaults.json') -Raw|ConvertFrom-Json
$controls=Get-Content -LiteralPath (Join-Path $private 'Native12/Main/EndModeControls.json') -Raw|ConvertFrom-Json
if($native.SHA256-cne$build.BookSHA256-or-not$native.ReadOnly-or$native.MacroRunImportSave-or$defaults.Status-cne'SAVED_RECTANGLES_DEFAULTS_AND_CURRENT_HELP_PASS'-or$defaults.ChangedDefaultCells-ne16-or$defaults.HistoricalBehaviorPhrases-ne0){throw 'Saved final book/text/defaults proof differs'}
if($controls.PositiveIndividualChoices-ne68-or$controls.RejectedCombinedOrUnknown-ne85-or$controls.ProjectionDashes-ne4-or-not$controls.HelpMatchesExistingParagraphStyle){throw 'Native saved controls/style proof incomplete'}
$main=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$allCode=Join-Path $root 'workbook/output/VBA_All_Code.txt'
$newMain=Join-Path $evidence 'Build12/RC_Section_NDM.xlsm';$newAllCode=Join-Path $private 'Native12/Main/VBA_All_Code.txt'
$oldMainSHA='4B70AA3AEC5D91B2A94DA8F7303C0FAB4C3491AB8DD027916B8AFCC7947BBFCB'
$oldAllCodeSHA='36A1460DCD363E1C39B2C18C293A81963AB0BCD3588593C693C4AF926340F091'
if((Get-FileHash -LiteralPath $main).Hash-cne$oldMainSHA-or(Get-FileHash -LiteralPath $allCode).Hash-cne$oldAllCodeSHA){throw 'Root book/export changed since user replacement approval; inspect edits'}
if((Get-FileHash -LiteralPath $newMain).Hash-cne$build.BookSHA256-or(Get-FileHash -LiteralPath $newAllCode).Hash-cne$equality.ExportSHA256){throw 'Reviewed source book/export changed'}
$userBackup=Join-Path $private 'UserMainBefore.xlsm'
if((Get-FileHash -LiteralPath $userBackup).Hash-cne'6A9598E05DBBC908A2650A5E73E64A5E9B12CC7899EBC0E126B183E66A2C23F5'){throw 'Original user backup must remain exact'}
$backup=Join-Path $private 'BeforeFinalMainPublication15'
if(Test-Path -LiteralPath $backup){throw 'Fresh publication backup required'}
[void][IO.Directory]::CreateDirectory($backup)
[IO.File]::Copy($main,(Join-Path $backup 'RC_Section_NDM.xlsm'),$false)
[IO.File]::Copy($allCode,(Join-Path $backup 'VBA_All_Code.txt'),$false)
[IO.File]::Copy($newMain,$main,$true)
[IO.File]::Copy($newAllCode,$allCode,$true)
if((Get-FileHash -LiteralPath $main).Hash-cne$build.BookSHA256-or(Get-FileHash -LiteralPath $allCode).Hash-cne$equality.ExportSHA256){throw 'Publication hash verification failed'}
$proof=[ordered]@{Status='CLEAN_FINAL_NATIVE_REVIEWED_SOURCE_PUBLISHED_FOR_FULL_RUN';AtUTC=[DateTimeOffset]::UtcNow.ToString('o');BeforeMainSHA256=$oldMainSHA;BeforeAllCodeSHA256=$oldAllCodeSHA;BookSHA256=$build.BookSHA256;AllCodeSHA256=$equality.ExportSHA256;SourceHEAD=(& git -C $root rev-parse HEAD);Book=$main;AllCode=$allCode;Backup=$backup;UserBackup=$userBackup;UserBackupPreserved=$true;NativeComponents=181;DirectedReferenceMacrosPerMode=40;DirectedReferenceSHA256=$matrix.SourceSHA256;FinalVBAStatementsEqualToDirectedReference=$true;FinalDefaultCellsChanged=16;FinalRectanglesS0S1Default=40;FinalCalculationsVerifiedByFullRun=$false;MainModes=@('IncludeBoth','ExcludeBoth','IncludeStart','IncludeEnd');CircleDefault='IncludeStart';UserDataCopied=$false;AllOwnIdentitiesTerminal=$true;AllOwnProofSHA256=(Get-FileHash -LiteralPath (Join-Path $private 'AllPreFullOwnClosures15.json')).Hash;FullAcceptanceClaim=$false;FullRunStarted=$false}
$proof|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $evidence 'Publication15.json') -Encoding utf8
$proof|ConvertTo-Json -Depth 6
