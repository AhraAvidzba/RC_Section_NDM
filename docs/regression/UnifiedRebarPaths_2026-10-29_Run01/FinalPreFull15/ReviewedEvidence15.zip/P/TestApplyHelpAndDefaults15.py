"""ДЛЯ ТЕСТОВ: переносит согласованные тексты и defaults после полного выхода directed16."""
from pathlib import Path
import hashlib
import json
import re
from datetime import datetime, timezone

ROOT = Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
PRIVATE = Path(__file__).parent
proof_path = PRIVATE / 'HelpAndDefaultsTransfer15.json'
assert not proof_path.exists(), 'Transfer already recorded; do not repeat'
closure = json.loads((PRIVATE / 'AllPreFullOwnClosures14.json').read_text(encoding='utf-8-sig'))
assert closure['AllOwnIdentitiesTerminal'] and closure['Status'] == 'ALL_CURRENT_OWN_IDENTITIES_TERMINAL'
review = json.loads((PRIVATE / 'FourModePrimaryTerminalReview14.json').read_text(encoding='utf-8-sig'))
assert review['Status'] == 'PASS_COMPLETE_DIRECTED_PRIMARY_READ'

edits = {
 'tools/build_workbook/SettingsCatalog.ps1': [
  ('Поле «Расстановка» (endMode) применяется к пути после отступов s0 и s1. IncludeBoth включает оба конца, ExcludeBoth исключает оба, IncludeStart включает только начало, IncludeEnd — только конец. На полном замкнутом пути IncludeStart или IncludeEnd дают равномерный ряд без повторения точки замыкания. При IncludeBoth начало и конец физически совпадают: повторный основной стержень и его повторные зависимые стержни пропускаются; основной пропуск сопровождается предупреждением. Начало и конец определяются направлением раскладки соответствующей стороны.',
   'Поле «Расстановка» (endMode) задаёт размещение стержней на пути после отступов s0 и s1: IncludeBoth — на обоих концах и между ними; ExcludeBoth — между концами; IncludeStart — в начале и внутри пути; IncludeEnd — в конце и внутри пути. Направление пути указано в справке своего типа сечения.'),
  ('При n = 1 IncludeStart ставит стержень в начале, IncludeEnd — в конце, IncludeBoth и ExcludeBoth — посередине. По умолчанию в каждой строке выбран прежний способ расстановки.',
   'При n = 1 IncludeStart ставит стержень в начале пути, IncludeEnd — в конце, IncludeBoth и ExcludeBoth — посередине пути.'),
 ],
 'src/Geometry/CSectionRecipeHollowRectangle.cls': [
  ('Сохраняем направления сторон и прежние привязки к прямым или исчезнувшим скруглениям.', 'Выбираем направление стороны и опорные точки на прямых или исчезнувших скруглениях.')],
 'src/Section/CRebarRuleExecutor.cls': [
  ('Семейства разных сторон и разные исходные линии сохраняют независимые дополнительные ряды и прежние проверки конфликтов.', 'Дополнительные ряды разных сторон или исходных линий независимы и проходят общую проверку конфликтов.')],
 'src/Section/CSectionGeometryQuery.cls': [
  ('Это сохраняет прежний равномерный нормальный перенос всех сторон и проверку попадания на путь при a2/a3=0.', 'Все стороны переносятся на одинаковое дополнительное расстояние по нормали; при a2/a3=0 проверяется попадание на путь.')],
 'src/Section/CConcreteElement.cls': [
  ('Использует тот же геометрический запрос; независимая публичная Geometry по-прежнему возвращает Clone.', 'Использует общий геометрический запрос; публичная Geometry возвращает независимую копию Clone.')],
 'src/Batch/CSectionStateResult.cls': [
  ('Вычисляет прежние поля элементов тем же порядком операций в заданном окне массива.', 'Вычисляет ID, тип, деформацию и напряжение элементов в заданном окне массива.'),
  ('Общая реализация сохраняет точное совпадение старого пятиколоночного и прямого путей вывода.', 'Общая реализация обеспечивает точное совпадение пятиколоночной матрицы и прямой записи в таблицу.'),
  ('при нулевой кривизне прежний h отсутствует, x определён и равен нулю.', 'при нулевой кривизне h не определён, x определён и равен нулю.')],
 'src/Excel/CCalculationSnapshot.cls': [
  ('Изменённая или посторонняя геометрия проходит прежний полный разбор, без округлённых ключей.', 'Изменённая или посторонняя геометрия проходит полный разбор, без округлённых ключей.')],
 'src/Excel/modCalculationSnapshot.bas': [
  ('ручное чтение без него по-прежнему выбирает Config.', 'ручное чтение без него выбирает источник по Config.'),
  ('Источник Excel — только лист; прежняя служебная привязка ничего не подгружает.', 'Источник Excel — только лист; служебная файловая привязка не участвует в чтении.')],
 'src/Excel/modSectionSnapshot.bas': [
  ('Числовые значения каждой строки по-прежнему проходят отдельную строгую проверку.', 'Числовые значения каждой строки проходят отдельную строгую проверку.'),
  ('сохранённые состояния проверяются в прежнем порядке.', 'сохранённые состояния проверяются в порядке таблицы.'),
  ('При отсутствии/ошибке JSON или хеша возвращает прежний полный путь без подмены геометрии.', 'При отсутствии или ошибке JSON/хеша передаёт запись полному разбору без подмены геометрии.'),
  ('Основной читатель выдаст прежнюю адресную ошибку, если обязательные данные повреждены.', 'Основной читатель выдаст адресную ошибку, если обязательные данные повреждены.'),
  ('Неподдерживаемая запись остаётся на обычном пути; старые снимки без подписи не меняют поведения.', 'Запись неподдерживаемого вида или без контрольной суммы проходит полный разбор.'),
  ('Сохраняет прежнюю числовую интерпретацию угла, без изменения результатов.', 'Общий читатель проверяет угол дуги и возвращает его в радианах.'),
  ('внешние окружности проверяются как прежде.', 'внешние окружности проходят полный разбор.')],
 'AGENTS.md': [
  ('- Справка описывает действия пользователя и расчетный смысл. Ссылка ведет к своей настройке, без повторения всего соседнего раздела.',
   '- Справка описывает действия пользователя и расчетный смысл. Ссылка ведет к своей настройке, без повторения всего соседнего раздела.\n- Рабочий код, комментарии и справка описывают единственный актуальный контракт: что программа делает и какие значения принимает. Не объяснять его ссылками на неопределённые «старое поведение», «прежний способ» или участников изменений. Историю изменений и сравнений хранить в отчётах и доказательствах. Для совместимости указывать конкретный формат или контракт и правило его обработки; предыдущие значения и состояния текущего алгоритма описывать по их фактическому назначению.'),
  ('`Mesh.CellGeometry=Adaptive` сохраняет прежнюю интерпретацию;', '`Mesh.CellGeometry=Adaptive` строит прямоугольную сетку с уточнением у границы;'),
  ('Область трещин не должна менять прежние A/I и конвейер устойчивости.', 'Выбор области трещин не меняет площадь A, моменты инерции I и расчёт устойчивости сечения.')],
}

pending = {}
for relative, replacements in edits.items():
    path = ROOT / relative
    raw = path.read_bytes()
    bom = raw.startswith(b'\xef\xbb\xbf')
    text = raw.decode('utf-8-sig')
    newline = '\r\n' if '\r\n' in text else '\n'
    for before, after in replacements:
        assert text.count(before) == 1, (relative, before, text.count(before))
        text = text.replace(before, after.replace('\n', newline))
    encoded = text.encode('utf-8')
    if bom:
        encoded = b'\xef\xbb\xbf' + encoded
    pending[relative] = (raw, encoded)

relative = 'tools/build_workbook/GeometryTables.json'
raw = (ROOT / relative).read_bytes()
text = raw.decode('utf-8-sig')
data = json.loads(text)
rect = next(item for item in data if item['Type'] == 'Rectangles')
rows = next(block for block in rect['Blocks'] if block['Key'] == 'Main')['Rows']
assert len(rows) == 8 and all(row[5:7] == [80, 80] for row in rows)
# Меняем только два значения каждого из восьми Main-рядов; форматирование JSON сохраняется.
pattern = re.compile(r'("R[12]\.(?:Top|Bottom|Left|Right)",\s*"[^"\r\n]*",\s*40,\s*32,\s*\d+,\s*)80,(\s*)80,')
text, count = pattern.subn(lambda m: m[1] + '40,' + m[2] + '40,', text)
assert count == 8
changed = json.loads(text)
for row in rows:
    row[5:7] = [40, 40]
assert changed == data, 'Unexpected catalogue changes'
pending[relative] = (raw, (b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b'') + text.encode('utf-8'))

backup = PRIVATE / 'BeforeFinalHelp15'
assert not backup.exists(), 'Fresh backup required'
records = []
for relative, (before, after) in pending.items():
    target = backup / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(before)
    (ROOT / relative).write_bytes(after)
    records.append({'Path': relative, 'BeforeSHA256': hashlib.sha256(before).hexdigest().upper(), 'AfterSHA256': hashlib.sha256(after).hexdigest().upper()})
proof = {'Status': 'HELP_CURRENT_CONTRACT_AND_RECTANGLE_DEFAULTS_APPLIED', 'ObservedUTC': datetime.now(timezone.utc).isoformat(), 'AllPriorOwnTerminalCount': closure['UniqueOwnCount'], 'RectanglesMainRows': 8, 'S0S1Defaults': 40, 'ChangedDefaultCells': 16, 'ProductionExecutableStatementsChanged': False, 'Files': records, 'FullAcceptanceClaim': False}
proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'Status': proof['Status'], 'Files': len(records), 'ChangedDefaultCells': 16}, ensure_ascii=False))
