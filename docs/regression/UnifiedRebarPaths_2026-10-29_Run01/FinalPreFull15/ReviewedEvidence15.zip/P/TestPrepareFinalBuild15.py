"""ДЛЯ ТЕСТОВ: готовит отдельную saved-book проверку текста и16 defaults без повторения расчётной матрицы."""
from pathlib import Path
import ast
import hashlib
import json

p = Path(__file__).parent
r = Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
proof = json.loads((p / 'HelpAndDefaultsTransfer15.json').read_text(encoding='utf-8-sig'))
assert proof['ChangedDefaultCells'] == 16 and not proof['ProductionExecutableStatementsChanged']

def statements(raw):
    """ДЛЯ ТЕСТОВ: исключает комментарии VBA с учётом кавычек строковых литералов."""
    result = []
    for line in raw.decode('utf-8-sig').splitlines():
        quoted = False
        for i, character in enumerate(line):
            if character == '"':
                quoted = not quoted
            elif character == "'" and not quoted:
                line = line[:i]
                break
        if line.strip():
            result.append(line.rstrip())
    return result

checked = []
for item in proof['Files']:
    if Path(item['Path']).suffix.lower() not in ('.bas', '.cls'):
        continue
    before = (p / 'BeforeFinalHelp15' / item['Path']).read_bytes()
    after = (r / item['Path']).read_bytes()
    assert statements(before) == statements(after), item['Path']
    checked.append(item['Path'])
(p / 'ExecutableStatementsEquality15.json').write_text(json.dumps({'Status': 'COMMENT_ONLY_VBA_CHANGES', 'Files': checked, 'ExecutableStatementsEqual': True, 'DirectedSourceSHA256': 'EF9EC63F1D06B8A3647EADCC5C6F1EFD1C8D5F2A84E17BFCD5A51E67DE800804', 'FullAcceptanceClaim': False}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

native = (p / 'TestNativeCandidate11.ps1').read_text(encoding='utf-8-sig')
native = native.replace('Native11', 'Native12').replace('Build11', 'Build12').replace('Owner11', 'Owner12')
native = native.replace('Incorrect old-behavior default:', 'Incorrect configured default:')
needle = '  $geometry=@();$options='
assert native.count(needle) == 1
native = native.replace(needle, '  $setbackDefaults=@()\n' + needle)
needle = '    $key=[string]$row[0];$cell=Get-GeometryTableCell'
assert native.count(needle) == 1
native = native.replace(needle, '''    if($definition.Type-ceq'Rectangles'){
     foreach($field in @('s0','s1')){
      $defaultCell=Get-GeometryTableCell $table 'Main' ([string]$row[0]) $field
      if([double]$defaultCell.Value2-ne40){throw ('Rectangles default must be40: '+[string]$row[0]+'/'+$field)}
      $setbackDefaults+=,[ordered]@{Row=[string]$row[0];Field=$field;Value=$defaultCell.Value2;Address=$defaultCell.Address()}
     }
    }
''' + needle)
needle = '  $body=$help.Cells.Find('
assert native.count(needle) == 1
native = native.replace(needle, '''  if($setbackDefaults.Count-ne16){throw 'Exactly16 saved Rectangles s0/s1 defaults must be40'}
  $expectedHelp='Поле «Расстановка» (endMode) задаёт размещение стержней на пути после отступов s0 и s1: IncludeBoth — на обоих концах и между ними; ExcludeBoth — между концами; IncludeStart — в начале и внутри пути; IncludeEnd — в конце и внутри пути. Направление пути указано в справке своего типа сечения.'
  $actualHelp=$help.Cells.Find('Поле «Расстановка» (endMode)',[Type]::Missing,-4163,2,1,1,$false)
  if([string]$actualHelp.Value2-cne$expectedHelp){throw 'Saved Help must contain the exact approved current-contract explanation'}
  $helpData=$help.UsedRange.Value2
  foreach($value in $helpData){if([string]$value-match'(?i)(прежн.{0,35}(способ|поведени)|стар.{0,35}(способ|поведени))'){throw 'Saved Help contains an unexplained historical behavior description'}}
  [ordered]@{Status='SAVED_RECTANGLES_DEFAULTS_AND_CURRENT_HELP_PASS';ChangedDefaultCells=16;SetbackDefaults=$setbackDefaults;CommonEndModeText=[string]$actualHelp.Value2;HistoricalBehaviorPhrases=0;SavedAgain=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $out 'FinalHelpAndDefaults.json') -Encoding UTF8
  $defaultCell=$null;$actualHelp=$null;$helpData=$null
''' + needle)
(p / 'TestNativeCandidate12.ps1').write_text(native, encoding='utf-8-sig', newline='\r\n')
print(json.dumps({'Status': 'FINAL_NATIVE_HELPER_PREPARED', 'VBACommentOnlyFiles': len(checked), 'Native': 'TestNativeCandidate12.ps1'}))
