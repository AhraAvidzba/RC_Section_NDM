﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# После завершения новой directed-матрицы заново проверяет все ранее доказанные собственные идентичности.
# Повторное использование PID допустимо; неизвестное время старта не принимается за завершение. Ничего не закрывает.
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$private=$PSScriptRoot
$evidence=Join-Path $root 'docs/regression/UnifiedRebarPaths_2026-10-29_Run01'
$oldLaunch=Join-Path $root 'docs/regression/FullSuiteLaunch_2026-10-29_UnifiedRebar_Run01'
$pipeline=Get-Content -LiteralPath (Join-Path $private 'FourModesPipeline14.json') -Raw|ConvertFrom-Json
$matrix=Get-Content -LiteralPath (Join-Path $private 'DirectedMatrix16.json') -Raw|ConvertFrom-Json
if($pipeline.Status-cne'DIRECTED_PASS_WAIT_PUBLICATION_REVIEW'-or$matrix.Status-cne'DIRECTED_PASS'-or@($matrix.Completed).Count-ne2){throw 'New native/directed pipeline must finish before release closure review'}
$unique=@{}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Добавляет только идентичность из собственного сохранённого журнала; повтор одного PID/start не увеличивает счётчик.
function Test-AddOwn([object]$identity,[string]$provenance){
 $id=[int]$identity.PID
 $ticks=$null
 foreach($field in @('StartTicksUTC','StartTicks','Ticks')){if($identity.PSObject.Properties.Name-contains$field){$ticks=[string]$identity.$field;break}}
 if($id-le0-or$ticks-notmatch'^\d{18}$'){throw ('Invalid own identity in '+$provenance)}
 $key=[string]$id+'/'+$ticks
 if(-not$unique.ContainsKey($key)){$unique[$key]=[ordered]@{PID=$id;StartTicksUTC=$ticks;Provenance=@($provenance)}}else{$unique[$key].Provenance+=,$provenance}
}
$previous=Get-Content -LiteralPath (Join-Path $oldLaunch 'ReleaseEligibility.json') -Raw|ConvertFrom-Json
if(-not$previous.Ready-or-not$previous.AllOwnClosed){throw 'Previous release own inventory is incomplete'}
foreach($identity in $previous.OwnIdentities){Test-AddOwn $identity 'L1/ReleaseEligibility.json'}
$interrupted=Get-Content -LiteralPath (Join-Path $oldLaunch 'UserInterruptedOwnClosures01.json') -Raw|ConvertFrom-Json
if(-not$interrupted.AllOwnClosed-or$interrupted.FullAcceptanceClaim){throw 'Interrupted full closure proof must stay truthful'}
foreach($identity in $interrupted.Identities){Test-AddOwn $identity 'L1/UserInterruptedOwnClosures01.json'}
foreach($file in @(Get-ChildItem -LiteralPath $evidence -Recurse -File -Filter '*Ownership.json')){
 $identity=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json
 Test-AddOwn $identity $file.FullName
}
foreach($file in @(Get-ChildItem -LiteralPath $private -File -Filter 'Native*Ownership.json')){
 $identity=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json
 Test-AddOwn $identity $file.FullName
}
Test-AddOwn ([pscustomobject]@{PID=$pipeline.ControllerPID;StartTicksUTC=$pipeline.ControllerStartTicksUTC}) 'P/FourModesPipeline14.json'
$oldController13=Get-Content -LiteralPath (Join-Path $private 'FourModesPipeline13.json') -Raw|ConvertFrom-Json
Test-AddOwn ([pscustomobject]@{PID=$oldController13.ControllerPID;StartTicksUTC=$oldController13.ControllerStartTicksUTC}) 'P/FourModesPipeline13.json'
$oldController=Get-Content -LiteralPath (Join-Path $private 'FourModesPipeline12.json') -Raw|ConvertFrom-Json
Test-AddOwn ([pscustomobject]@{PID=$oldController.ControllerPID;StartTicksUTC=$oldController.ControllerStartTicksUTC}) 'P/FourModesPipeline12.json'
$review=@();$live=@()
foreach($identity in $unique.Values){
 $process=$null
 try{$process=Get-Process -Id $identity.PID -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId-notlike'NoProcessFoundForGivenId*'){throw}}
 $current=$null;$terminal=$true;$state='Absent'
 if($process){
  $started=$process.StartTime
  if($null-eq$started){throw ('Unknown process start time: '+$identity.PID)}
  $current=[ordered]@{Name=$process.ProcessName;StartTicksUTC=[string]$started.ToUniversalTime().Ticks}
  if($current.StartTicksUTC-ceq$identity.StartTicksUTC){$terminal=$false;$state='ExactIdentityLive';$live+=,$identity}else{$state='PIDReusedDifferentStart'}
 }
 $review+=,[ordered]@{PID=$identity.PID;StartTicksUTC=$identity.StartTicksUTC;Provenance=$identity.Provenance;State=$state;OwnIdentityTerminal=$terminal;CurrentProcess=$current;ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');ProcessModifiedOrClosed=$false}
}
$proof=[ordered]@{Status=if($live.Count){'OWN_IDENTITIES_STILL_LIVE'}else{'ALL_CURRENT_OWN_IDENTITIES_TERMINAL'};AtUTC=[DateTimeOffset]::UtcNow.ToString('o');AllOwnIdentitiesTerminal=($live.Count-eq0);UniqueOwnCount=$review.Count;Identities=$review;DirectedSourceSHA256=$matrix.SourceSHA256;FullAcceptanceClaim=$false;NothingClosed=$true;UnknownAcceptedAsAbsent=$false}
$proof|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $private 'AllPreFullOwnClosures15.json') -Encoding utf8
if($live.Count){throw ('Some exact own identities remain live: '+$live.Count)}
[ordered]@{Status=$proof.Status;OwnCount=$review.Count;AllTerminal=$true;FullAcceptanceClaim=$false}|ConvertTo-Json
