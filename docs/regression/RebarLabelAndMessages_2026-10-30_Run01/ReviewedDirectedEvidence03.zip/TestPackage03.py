# ДЛЯ ТЕСТОВ: сохраняет все части пользовательского файла, заменяя только проверенный VBA-проект.
from pathlib import Path
from copy import copy
import zipfile, json, hashlib
P=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
receipt=json.loads((P/'Build_No03/Result.json').read_text(encoding='utf-8-sig'))
equality=json.loads((P/'CandidateEquality03.json').read_text(encoding='utf-8-sig'))
assert receipt['Passed'] and receipt['OwnClosure']=='ConfirmedNotFound' and equality['Passed']
original=P/'UserMainBefore.xlsm'; candidate=P/'Candidate03.xlsm'; final=P/'FinalCodeOnly03.xlsm'
assert not final.exists()
with zipfile.ZipFile(original) as a, zipfile.ZipFile(candidate) as b:
    parts=[(copy(i),a.read(i.filename)) for i in a.infolist()]
    payload=b.read('xl/vbaProject.bin')
with zipfile.ZipFile(final,'w') as z:
    for info,data in parts:z.writestr(info,payload if info.filename=='xl/vbaProject.bin' else data)
with zipfile.ZipFile(original) as a,zipfile.ZipFile(final) as f:
    assert f.testzip() is None and a.namelist()==f.namelist()
    changed=[n for n in a.namelist() if a.read(n)!=f.read(n)]
    assert changed==['xl/vbaProject.bin']
    report={'ChangedParts':changed,'UnchangedParts':len(a.namelist())-1,'OriginalSHA256':sha(original),'FinalSHA256':sha(final),'UserDataResultsChartFormattingUnchanged':True}
(P/'CodeOnlyPreservation03.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
