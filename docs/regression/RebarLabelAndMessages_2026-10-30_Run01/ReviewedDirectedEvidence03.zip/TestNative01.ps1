﻿# ДЛЯ ТЕСТОВ: отдельный Excel читает, компилирует или проверяет частную копию; пользовательский Excel не используется.
param([ValidateSet('Inspect','Build','Test')][string]$Stage='Inspect',[string]$WorkbookPath='', [string]$Tag='', [switch]$PresentationWorkflowOnly, [ValidateSet('No','Yes')][string]$Mode='No')
$ErrorActionPreference='Stop'
Import-Module 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1' -Global
$p=$PSScriptRoot
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
if(-not $WorkbookPath){$WorkbookPath=Join-Path $p 'UserMainBefore.xlsm'}
$path=(Resolve-Path -LiteralPath $WorkbookPath).Path
if(-not $path.StartsWith($p+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Native operation requires a private copy.'}
$output=Join-Path $p ($Stage+'_'+$Mode+$Tag)
if(Test-Path -LiteralPath (Join-Path $output 'Result.json')){throw 'Use a fresh result directory.'}
[void][IO.Directory]::CreateDirectory($output)
$os=Get-CimInstance Win32_OperatingSystem
$perf=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$free=[double]$os.FreePhysicalMemory*1024/1GB
$commit=([double]$perf.CommitLimit-[double]$perf.CommittedBytes)/1GB
if($free -lt 8 -or $commit -lt 14){throw "Insufficient memory: RAM=$free commit=$commit"}
$before=@(Get-Process EXCEL -ErrorAction SilentlyContinue | ForEach-Object {$_.Id})
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class TestNativeWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hWnd,out uint id);}'
$excel=$null;$book=$null;$ownedId=0;$ticks=0;$quitRequested=$false
$receipt=[ordered]@{Stage=$Stage;Mode=$Mode;Source=$path;SourceSHA256=(Get-FileHash -LiteralPath $path).Hash;FreeRAMGiB=$free;FreeCommitGiB=$commit;Passed=$false;Error=''}
try {
    $excel=New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][TestNativeWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    if([int]$id -in $before){throw 'Excel returned a pre-existing process; no workbook operation authorized.'}
    $ownedId=[int]$id;$ticks=(Get-Process -Id $ownedId).StartTime.ToUniversalTime().Ticks
    $receipt.OwnedPID=$ownedId;$receipt.OwnedStartTicksUTC=[string]$ticks
    $receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $output 'Ownership.json') -Encoding UTF8
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=3
    if($Stage -eq 'Test'){$excel.AutomationSecurity=1}
    $book=$excel.Workbooks.Open($path,0,($Stage -ne 'Build'))
    if($Stage -eq 'Build'){
        if($book.ReadOnly){throw 'Candidate unexpectedly read-only'}
        $names=@('modWorkbookCalculation','modWorkbookMessages','modTestAudit02Api','modTestRecipeAnnotations','modTestWorkbookInterface')
        foreach($name in $names){
            $file=@(Get-ChildItem -LiteralPath (Join-Path $p 'SourceAfter') -Recurse -File | Where-Object BaseName -eq $name)
            if($file.Count -ne 1){throw "Missing source $name"}
            $text=[IO.File]::ReadAllText($file[0].FullName,[Text.Encoding]::UTF8)
            $body=[regex]::Match($text,'(?ms)^Option Explicit.*').Value
            if(-not $body){throw "Empty source $name"}
            $module=$book.VBProject.VBComponents.Item($name).CodeModule
            $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($body)
        }
        $excel.VBE.ActiveVBProject=$book.VBProject
        $compile=$excel.VBE.CommandBars.FindControl(1,578)
        if($null -eq $compile){throw 'Compile command unavailable'}
        if($compile.Enabled){$compile.Execute()}
        if($compile.Enabled){throw 'VBA compile did not complete'}
        $book.Save();$receipt.Compiled=$true
    }
    if($Stage -eq 'Test'){
        $settings=$book.Names.Item('rngSystemSettings').RefersToRange
        for($row=1;$row -le $settings.Rows.Count;$row++){
            if([string]$settings.Cells.Item($row,1).Value2 -eq 'General.ReformatResultsEnabled'){$settings.Cells.Item($row,2).Value2=$Mode}
        }
        $macros=@('modTestAudit02Api.RunProgramMessagePresentationTests','modTestAudit02Api.RunInputOnlyDialogTests',
            'modTestRecipeAnnotations.RunRecipeAnnotationTests','modTestSectionRecipes.RunRecipeAnnotationCountTests',
            'modTestWorkbookInterface.RunFormationPreviewTests')
        if($PresentationWorkflowOnly){$macros=@('modTestAudit02Api.RunProgramMessagePresentationTests','modTestWorkbookInterface.RunFormationPreviewTests')}
        $results=@()
        foreach($macro in $macros){
            $started=[DateTime]::UtcNow
            $result=[string]$excel.Run("'"+$book.Name+"'!"+$macro)
            $file=Join-Path $output ($macro+'.txt')
            [IO.File]::WriteAllText($file,$result,[Text.UTF8Encoding]::new($false))
            $failed=[regex]::Matches($result,'(?im)\bfailed\s*=\s*(\d+)')
            $passed=$failed.Count -gt 0 -and @($failed | Where-Object {[long]$_.Groups[1].Value -ne 0}).Count -eq 0 -and $result -notmatch '(?im)^FAIL\b'
            $results+=,[ordered]@{Macro=$macro;Passed=$passed;Seconds=([DateTime]::UtcNow-$started).TotalSeconds;Bytes=(Get-Item -LiteralPath $file).Length}
            $results | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $output 'Macros.json') -Encoding UTF8
            Write-Output ($macro+': '+($result -split '\r?\n' | Where-Object {$_ -match '^TOTAL'} | Select-Object -Last 1))
            if(-not $passed){throw "Native test failed: $macro"}
        }
        $receipt.Macros=$results
    }
    if($Stage -ne 'Test'){
        $bodies=[ordered]@{};$dump=New-Object Text.StringBuilder
        [void]$dump.AppendLine('Date: '+[DateTime]::UtcNow.ToString('o'))
        foreach($component in $book.VBProject.VBComponents){
            $module=$component.CodeModule;$count=$module.CountOfLines;$body=''
            if($count -gt 0){$body=[string]$module.Lines(1,$count)}
            $bodies[$component.Name]=[ordered]@{Type=[int]$component.Type;Body=$body}
            [void]$dump.AppendLine('COMPONENT: '+$component.Name);[void]$dump.AppendLine('TYPE: '+$component.Type)
            [void]$dump.AppendLine('LINES: '+$count);[void]$dump.AppendLine('');[void]$dump.AppendLine($body)
        }
        $bodies | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $output 'Components.json') -Encoding UTF8
        [IO.File]::WriteAllText((Join-Path $output 'VBA_All_Code.txt'),$dump.ToString(),[Text.UTF8Encoding]::new($false))
        $receipt.ComponentCount=$bodies.Count
    }
    $receipt.Passed=$true
}catch{$receipt.Error=$_.Exception.ToString();throw}
finally{
    if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book);$book=$null}
    if($excel -and $ownedId){$excel.Quit();$quitRequested=$true}
    if($excel){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null}
    $settings=$null;$module=$null;$component=$null;$compile=$null
    [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
    $state='Unknown'
    for($attempt=0;$attempt -lt 30;$attempt++){
        try{$own=Get-Process -Id $ownedId -ErrorAction Stop
            if($own.ProcessName -ne 'EXCEL' -or $own.StartTime.ToUniversalTime().Ticks -ne $ticks){$state='DifferentIdentity';break}
            $state='Live'
        }catch{if($_.FullyQualifiedErrorId -like 'NoProcessFoundForGivenId*'){$state='ConfirmedNotFound';break}else{$state='Unknown';break}}
        Start-Sleep -Milliseconds 200
    }
    $receipt.QuitRequested=$quitRequested;$receipt.OwnClosure=$state
    $receipt.SourceAfterSHA256=(Get-FileHash -LiteralPath $path).Hash
    $receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $output 'Result.json') -Encoding UTF8
    if($state -notin @('ConfirmedNotFound','DifferentIdentity')){throw "Owned Excel closure not confirmed: $state"}
}
