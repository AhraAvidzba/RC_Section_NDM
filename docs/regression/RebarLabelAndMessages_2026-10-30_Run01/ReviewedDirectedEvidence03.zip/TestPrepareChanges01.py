from pathlib import Path
import hashlib, json, zipfile, io, subprocess

R = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
P = Path(__file__).parent
def sha(data): return hashlib.sha256(data).hexdigest().upper()
calculation = (R / 'src/Excel/modWorkbookCalculation.bas').read_text(encoding='utf-8-sig')
formation = calculation.split('Private Function FormSectionCore(', 1)[1].split('\nEnd Function', 1)[0]
calculating = calculation.split('Private Function CalculateSectionCore(', 1)[1].split('\nEnd Function', 1)[0]
assert 'section.GeometryWarningText' in formation
assert all(term not in calculating for term in ('GeometryWarningText', 'HasGeometryWarnings', 'FormSectionCore(', 'FormSectionForWorkbook('))
assert calculation.count('message = FormSectionCore(') == 1
(P / 'WarningActionScopeReview01.json').write_text(json.dumps({
    'FormationCaller':'FormSectionForWorkbook -> FormSectionCore',
    'CalculationCaller':'RunSectionCalculationForWorkbook -> CalculateSectionCore',
    'CalculationDoesNotReadGeometryWarningsOrCallFormation':True,
    'ProductionChangeConfinedToFormationParagraphSeparator':True,
    'NativeRegression':'RunFormationPreviewTests: Excel/File form warns, subsequent actual calculation does not repeat geometry warnings'
},ensure_ascii=False,indent=2),encoding='utf-8')
book = R / 'workbook/output/RC_Section_NDM.xlsm'
original = (P / 'UserMainBefore.xlsm').read_bytes()
assert book.read_bytes() == original, 'Saved user workbook changed since backup'
committed = subprocess.check_output(['git', 'show', 'HEAD:workbook/output/RC_Section_NDM.xlsm'], cwd=R)
with zipfile.ZipFile(io.BytesIO(original)) as z, zipfile.ZipFile(io.BytesIO(committed)) as c:
    same_vba = z.read('xl/vbaProject.bin') == c.read('xl/vbaProject.bin')
(P / 'SavedVbaComparison01.json').write_text(json.dumps({'UserBookSHA256':sha(original), 'SavedVbaEqualsHEAD':same_vba}, indent=2), encoding='utf-8')
if not same_vba:
    equality=json.loads((P/'SavedSourceEquality01.json').read_text(encoding='utf-8-sig'))
    inspect=json.loads((P/'Inspect_No/Result.json').read_text(encoding='utf-8-sig'))
    assert equality['Passed'] and equality['SourceComponents']==175 and equality['ExportComponents']==181
    assert inspect['SourceSHA256']==sha(original) and inspect['SourceAfterSHA256']==sha(original)
    assert inspect['Passed'] and inspect['OwnClosure']=='ConfirmedNotFound'

changes = {}
def edit(path, old, new):
    if path not in changes: changes[path] = (R / path).read_text(encoding='utf-8-sig')
    assert changes[path].count(old) == 1, path + ': target not unique'
    changes[path] = changes[path].replace(old, new)

edit('src/Excel/modWorkbookCalculation.bas',
     'If Len(section.GeometryWarningText) > 0 Then FormSectionCore = FormSectionCore & vbCrLf & section.GeometryWarningText',
     'If Len(section.GeometryWarningText) > 0 Then FormSectionCore = WorkbookMessageParagraph(FormSectionCore, section.GeometryWarningText)')
edit('src/Excel/modWorkbookMessages.bas',
     '"Ширина трещин:", "Продольные трещины:", "НДС:")',
     '"Ширина трещин:", "Продольные трещины:", "НДС:", "Предупреждение:")')
edit('src/Excel/modWorkbookMessages.bas',
     '        text = ReplaceWorkbookMessageFragment(text, CStr(caption) & " ", CStr(caption) & vbCrLf)',
     '        text = ReplaceWorkbookMessageFragment(text, vbCrLf & CStr(caption), vbCrLf & vbCrLf & CStr(caption))\n'
     '        text = ReplaceWorkbookMessageFragment(text, CStr(caption) & " ", CStr(caption) & vbCrLf)')
edit('src/Excel/modWorkbookMessages.bas',
     '    WorkbookDialogText = TrimWorkbookMessage(text)',
     '''    ' Геометрические предупреждения хранятся компактно; только окно разделяет счётчик, причину и техническую ссылку.
    For Each caption In Array("В каждой совпавшей позиции ", "Их положения по нормали ", _
            "В расчёте и подписях учтён ", "Площадь каждого из них ")
        text = ReplaceWorkbookMessageFragment(text, ". " & CStr(caption), "." & vbCrLf & vbCrLf & CStr(caption))
    Next caption
    text = ReplaceWorkbookMessageFragment(text, ". Подробности и адреса полей приведены в ", _
        "." & vbCrLf & vbCrLf & "Подробности и адреса полей:" & vbCrLf)
    text = ReplaceWorkbookMessageFragment(text, vbCrLf & "По настройке Mesh.MinElementArea ", _
        vbCrLf & vbCrLf & "По настройке Mesh.MinElementArea ")
    WorkbookDialogText = TrimWorkbookMessage(text)''')

edit('tests/modTestAudit02Api.bas', '    GoTo Finish\nFailed:\n    TestCheck "presentation.runtime", False', '''    TestGeometryWarningParagraphs
    GoTo Finish
Failed:
    TestCheck "presentation.runtime", False''')
changes['tests/modTestAudit02Api.bas'] += '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет реальное предупреждение после счётчиков, несколько причин и точность цитируемых пользовательских строк.
Private Sub TestGeometryWarningParagraphs()
    Dim warning As String, message As String, text As String, expected As String
    warning = "Предупреждение: пропущено совпавших стержней: 8. В каждой совпавшей позиции сохранён первый добавленный стержень с его диаметром и материалом. " & _
        "На схеме и в расчёте учтены фактически созданные стержни. Подробности и адреса полей приведены в Geometry.RecipeDiagnostics на Results."
    message = "Сечение сформировано и сохранено на Results." & vbCrLf & vbCrLf & _
        "Бетонных элементов: 1232." & vbCrLf & "Стержней арматуры: 20."
    text = WorkbookDialogText(WorkbookMessageParagraph(message, warning))
    expected = message & vbCrLf & vbCrLf & "Предупреждение:" & vbCrLf & "пропущено совпавших стержней: 8." & vbCrLf & vbCrLf & _
        "В каждой совпавшей позиции сохранён первый добавленный стержень с его диаметром и материалом. На схеме и в расчёте учтены фактически созданные стержни." & vbCrLf & vbCrLf & _
        "Подробности и адреса полей:" & vbCrLf & "Geometry.RecipeDiagnostics на Results."
    TestCheck "presentation.geometry.warning.blocks", text = expected
    TestCheck "presentation.geometry.warning.single.newline", WorkbookDialogText(message & vbCrLf & warning) = expected
    TestCheck "presentation.geometry.warning.idempotent", WorkbookDialogText(text) = text
    TestCheck "presentation.geometry.warning.raw.compact", InStr(warning, vbCrLf) = 0
    mReport = mReport & "GEOMETRY_WARNING_LAYOUT:" & vbCrLf & text & vbCrLf & "END_GEOMETRY_WARNING_LAYOUT" & vbCrLf
    warning = "Предупреждение: после смещения не размещено дополнительных стержней: 2. Их положения по нормали оказались вне полного смещённого контура. " & _
        "Подробности и адреса полей приведены в Geometry.RecipeDiagnostics на Results." & vbCrLf & _
        "Предупреждение: объединено дополнительных стержней соседних граней: 3. В расчёте и подписях учтён только первый добавленный стержень с его координатами и диаметром." & vbCrLf & _
        "По настройке Mesh.MinElementArea пропущено стержней: 4. Площадь каждого из них меньше заданного порога; в расчёте и подписях они не учитываются."
    text = WorkbookDialogText(warning)
    TestCheck "presentation.geometry.warning.offset.reason", InStr(text, "2." & vbCrLf & vbCrLf & "Их положения по нормали") > 0
    TestCheck "presentation.geometry.warning.neighbor.reason", InStr(text, "3." & vbCrLf & vbCrLf & "В расчёте и подписях") > 0
    TestCheck "presentation.geometry.warning.area.reason", InStr(text, "4." & vbCrLf & vbCrLf & "Площадь каждого из них") > 0
    TestCheck "presentation.geometry.warning.several.idempotent", WorkbookDialogText(text) = text
    TestCheck "presentation.geometry.warning.no.extra.blanks", InStr(text, vbCrLf & vbCrLf & vbCrLf) = 0
    warning = "«Предупреждение: 8. В каждой совпавшей позиции имя. Подробности и адреса полей приведены в Имя»"
    TestCheck "presentation.geometry.warning.quoted", WorkbookDialogText(warning) = warning
End Sub
'''
edit('tests/modTestRecipeAnnotations.bas',
     '    For i = 0 To 4: TestCheck "invalid." & CStr(i), TestInvalidAnnotation(i): Next i',
     '    For i = 0 To 4: TestCheck "invalid." & CStr(i), TestInvalidAnnotation(i): Next i\n    TestPhysicalLabelOwnership')
changes['tests/modTestRecipeAnnotations.bas'] += '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Полностью совпавший ряд не получает подпись ни при одной привязке; частичный ряд показывает только созданные стержни.
Private Sub TestPhysicalLabelOwnership()
    Dim kind As Long, partial As Long, facade As CSectionDefinitionBuilder, path As CGeometryPath
    Dim options As CRebarRuleOptions, definition As CSectionDefinition, executor As CRebarRuleExecutor
    Dim layout As CRebarLayout, labels As CSectionAnnotations, repeated As CSectionAnnotations, builder As CSectionAnnotationBuilder
    Dim i As Long, firstText As String, secondText As String, prefix As String
    For kind = 0 To 3
        For partial = 0 To 1
            prefix = "physical.label.kind" & CStr(kind) & ".partial" & CStr(partial)
            Set facade = New CSectionDefinitionBuilder: facade.Initialize "Test.PhysicalLabels"
            Set path = facade.RectanglePath("Concrete", 0#, 0#, 600#, 600#): facade.Outer "OUTER", path.ID
            Set path = facade.LinePath("AxisA", 100#, 100#, 300#, 100#)
            Set path = facade.LinePath("AxisB", 100# + 200# * partial, 100#, 300# + 200# * partial, 100#)
            Set options = New CRebarRuleOptions
            options.Coincidence = KeepPublishedOwner: options.WarnOnCoincidence = True: options.EndMode = IncludeBoth
            options.AnnotationGroup = "First": facade.RebarByCount "First.Main", "AxisA", 3, 20#, options
            options.AnnotationGroup = "Second": facade.RebarByCount "Second.Main", "AxisB", 3, 16#, options
            facade.RebarLabel "First", "AxisA", 0#, -1#
            Select Case kind
                Case 0: facade.RebarLabel "Second", "AxisB", 0#, -1#
                Case 1: facade.RebarRowLabel "Second", "Second.Main", 0#, -1#
                Case 2: facade.RebarRowExtentLabel "Second", "Second.Main", 0#, -1#
                Case 3: facade.RebarRowExtremeLabel "Second", "Second.Main", 0#, -1#, 0#, -1#
            End Select
            Set definition = facade.Finish: Set executor = New CRebarRuleExecutor
            Set layout = TestFixtureAnnotatedLayout(definition, executor, labels)
            TestCheck prefix & ".physical", layout.Count = 3 + 2 * partial
            TestCheck prefix & ".merged", executor.MergedPositions = 3 - 2 * partial
            TestCheck prefix & ".labels", labels.Count = 1 + partial
            firstText = "": secondText = ""
            For i = 1 To labels.Count
                If labels.AnnotationID(i) = "REBAR_First" Then firstText = labels.Text(i)
                If labels.AnnotationID(i) = "REBAR_Second" Then secondText = labels.Text(i)
            Next i
            TestCheck prefix & ".first.owner", firstText = "3" & ChrW$(216) & "20"
            If partial = 0 Then
                TestCheck prefix & ".empty.hidden", secondText = ""
            Else
                TestCheck prefix & ".created.only", secondText = "2" & ChrW$(216) & "16"
            End If
            Set builder = New CSectionAnnotationBuilder: Set repeated = New CSectionAnnotations
            builder.Build definition, layout, repeated, executor
            TestCheck prefix & ".repeat", repeated.Count = labels.Count And layout.Count = 3 + 2 * partial
        Next partial
    Next kind
End Sub
'''

edit('tests/modTestWorkbookInterface.bas',
     '    TestAssertTrue stats, "formPreview.disabled.noSolver", SectionEquilibriumSolveCount() = solves',
     '    TestAssertTrue stats, "formPreview.disabled.noSolver", SectionEquilibriumSolveCount() = solves\n    TestGeometryWarningFormationOnly stats')
changes['tests/modTestWorkbookInterface.bas'] += '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' В Excel и File совпавший шов круга предупреждает при формировании; последующий настоящий расчёт не повторяет это предупреждение.
Private Sub TestGeometryWarningFormationOnly(ByRef stats As TUiTestStats)
    Dim mode As Variant, values As Variant, message As String, attention As Boolean, solves As Long
    For Each mode In Array("Excel", "File")
        TestPrepareCircleInput
        TestSetSystemSetting "General.ExecutionReportEnabled", "No"
        TestSetSystemSetting "Plot.Enabled", "No"
        TestSetSystemSetting "Plot.AutoUpdateAfterCalculation", "No"
        TestSetSystemSetting "Results.SnapshotStorage", CStr(mode)
        TestSetSystemSetting "Results.SnapshotName", "TestWarningFormationOnly_" & CStr(mode) & "_" & Format$(Now, "yyyymmdd_hhnnss")
        values = ThisWorkbook.Names("rngCircleGeometry").RefersToRange.Value2
        TestFixtureSetInput values, "Main", "Circle", "s0", 0#
        TestFixtureSetInput values, "Main", "Circle", "s1", 0#
        TestFixtureSetInput values, "Main", "Circle", "endMode", "IncludeBoth"
        ThisWorkbook.Names("rngCircleGeometry").RefersToRange.Value2 = values
        solves = SectionEquilibriumSolveCount()
        message = FormSectionForWorkbook(ThisWorkbook, -1#, , attention)
        TestAssertTrue stats, "geometryWarning." & CStr(mode) & ".formation.warns", attention And InStr(message, "пропущено совпавших стержней: 1") > 0
        TestAssertTrue stats, "geometryWarning." & CStr(mode) & ".formation.paragraph", InStr(message, vbCrLf & vbCrLf & "Предупреждение:") > 0
        TestAssertTrue stats, "geometryWarning." & CStr(mode) & ".formation.noSolver", SectionEquilibriumSolveCount() = solves
        message = RunSectionCalculationForWorkbook(ThisWorkbook, False, -1#, , attention)
        TestAssertTrue stats, "geometryWarning." & CStr(mode) & ".calculation.completed", InStr(message, "Расчет завершен") > 0
        TestAssertTrue stats, "geometryWarning." & CStr(mode) & ".calculation.solved", SectionEquilibriumSolveCount() > solves
        TestAssertTrue stats, "geometryWarning." & CStr(mode) & ".calculation.noRepeat", InStr(message, "пропущено совпавших стержней") = 0 And InStr(message, "Geometry.RecipeDiagnostics") = 0
    Next mode
End Sub
'''

records=[]
for name, value in changes.items():
    source=R/name; before=source.read_bytes()
    target=P/'SourceBefore'/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(before)
    # Исходники проекта UTF-8; сохраняем исходный BOM и окончания строк.
    after=value.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8')
    if before.startswith(b'\xef\xbb\xbf'): after=b'\xef\xbb\xbf'+after
    source.write_bytes(after)
    target=P/'SourceAfter'/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(after)
    records.append({'Path':name,'BeforeSHA256':sha(before),'AfterSHA256':sha(after)})
(P/'SourceChanges01.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'Edited':len(records),'UserBookUnchanged':book.read_bytes()==original,'SavedVbaEqualsHEAD':same_vba}))
