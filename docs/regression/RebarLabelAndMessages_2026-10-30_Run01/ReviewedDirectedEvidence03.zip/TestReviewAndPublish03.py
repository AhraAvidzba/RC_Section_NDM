# ДЛЯ ТЕСТОВ: читает целые журналы и нативные экспорты; публикует только после приёмки и сохранения резерва.
from pathlib import Path
import json, hashlib, re, zipfile, shutil, subprocess, datetime
P=Path(__file__).parent
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
E=R/'docs/regression/RebarLabelAndMessages_2026-10-30_Run01'
def read(name):return json.loads((P/name).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def canonical(body):
    # Регистр кода VBE несущественен; строковые литералы и комментарии остаются точными.
    return '\n'.join(''.join(s if i%2 else s.lower() for i,s in enumerate(re.split(r'("(?:[^"]|"")*")',line))) for line in body.replace('\r\n','\n').strip().split('\n'))

assert read('AllOwnClosures03.json')['Passed'] and read('AllOwnClosures03.json')['Count']==8
assert read('FinalEquality03.json')['Passed']
preservation=read('CodeOnlyPreservation03.json')
final=P/'FinalCodeOnly03.xlsm'; original=P/'UserMainBefore.xlsm'
assert sha(final)==preservation['FinalSHA256'] and sha(original)==preservation['OriginalSHA256']
with zipfile.ZipFile(original) as a,zipfile.ZipFile(final) as b:
    assert a.namelist()==b.namelist() and b.testzip() is None
    assert [n for n in a.namelist() if a.read(n)!=b.read(n)]==['xl/vbaProject.bin']

before=read('Build_No/Components.json'); after=read('Inspect_NoFinal03/Components.json')
assert before.keys()==after.keys()
body_changes=[n for n in before if canonical(before[n]['Body'])!=canonical(after[n]['Body'])]
assert body_changes==['modTestWorkbookInterface'], body_changes
old=canonical(before['modTestWorkbookInterface']['Body'])
new=canonical(after['modTestWorkbookInterface']['Body'])
assert old.replace('sectionequilibriumsolvecount() > solves','sectionequilibriumsolvecount() > 0')==new

stable=[('Test_No02','modTestAudit02Api.RunProgramMessagePresentationTests'),
 ('Test_No02','modTestAudit02Api.RunInputOnlyDialogTests'),('Test_No02','modTestRecipeAnnotations.RunRecipeAnnotationTests'),
 ('Test_No02','modTestSectionRecipes.RunRecipeAnnotationCountTests')]
final_runs=[(d,m) for d in ('Test_No03','Test_Yes03') for m in
 ('modTestAudit02Api.RunProgramMessagePresentationTests','modTestWorkbookInterface.RunFormationPreviewTests')]
accepted=[];total=0
for directory,macro in stable+final_runs:
    path=P/directory/(macro+'.txt'); text=path.read_text(encoding='utf-8-sig')
    matches=re.findall(r'(?im)^TOTAL[^\r\n]*passed=(\d+); failed=(\d+)',text)
    assert matches and all(int(f)==0 for _,f in matches) and not re.search(r'(?im)^FAIL\b',text)
    count=int(matches[-1][0]); total+=count
    accepted.append({'Directory':directory,'Macro':macro,'Passed':count,'Failed':0,'Bytes':path.stat().st_size,'SHA256':sha(path)})
for directory in ('Test_No03','Test_Yes03','Inspect_NoFinal03'):
    receipt=read(directory+'/Result.json')
    assert receipt['Passed'] and receipt['OwnClosure']=='ConfirmedNotFound'
    assert receipt['SourceSHA256']==receipt['SourceAfterSHA256']==sha(final)
audit=read('DocumentationAudit01.json')
missing=audit['MissingModuleHeaders']+[r['Path'] for r in audit['MissingMethodHeaders']]
assert set(missing)=={'src/Excel/modSectionSnapshot.bas','src/Excel/CNDMResultsWriter.cls'}
assert subprocess.check_output(['git','diff','--',*set(missing)],cwd=R)==b''
acceptance={'Status':'PASS_DIRECTED','FullSuiteRun':False,'AssertionsPassed':total,'AssertionsFailed':0,
 'AcceptedExecutions':accepted,'All92RecipeScenariosPassed':True,'AllFourAnchorKindsSuppressEmptyPhysicalGroup':True,
 'GeometryWarningsOnlyOnFormationExcelFileNoYes':True,'StableChecksProductionCodeEqualToFinal':True,
 'OnlyChangeAfterStableChecks':'Test solver counter uses current batch >0 because Execute resets it before every batch.',
 'HistoricalCounterTestFailureRetained':True,'SourceComponents':175,'NativeComponents':181,
 'UserWorkbookPreservation':preservation,'AllOwnIdentitiesClosed':8,
 'GlobalDocumentationAudit':'Two pre-existing missing headers in unchanged files; all changed files have required headers/test markers.'}
(P/'Acceptance03.json').write_text(json.dumps(acceptance,ensure_ascii=False,indent=2),encoding='utf-8')
E.mkdir(parents=True,exist_ok=True)
files=['Acceptance03.json','CodeOnlyPreservation03.json','FinalEquality03.json','AllOwnClosures03.json',
 'CounterTestFix03.json','WarningActionScopeReview01.json','SavedVbaComparison01.json','SavedSourceEquality01.json',
 'SourceChanges01.json','CandidateEquality03.json','DocumentationAudit01.json','TestPrepareChanges01.py',
 'TestNative01.ps1','TestPackage03.py','TestReviewAndPublish03.py']
files += [d+'/'+f for d in ('Inspect_No','Build_No','Test_No','Test_No02','Build_No03','Test_No03','Test_Yes03','Inspect_NoFinal03')
          for f in ('Ownership.json','Result.json','Macros.json') if (P/d/f).exists()]
files += [str(x.relative_to(P)).replace('\\','/') for d in ('Test_No02','Test_No03','Test_Yes03') for x in (P/d).glob('*.txt')]
with zipfile.ZipFile(E/'ReviewedDirectedEvidence03.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in files:z.write(P/name,name)
manifest={'ArchiveSHA256':sha(E/'ReviewedDirectedEvidence03.zip'),'Files':[{'Path':n,'SHA256':sha(P/n),'Bytes':(P/n).stat().st_size} for n in files]}
(E/'Manifest03.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(P/'Acceptance03.json',E/'Acceptance03.json')
shutil.copy2(P/'CodeOnlyPreservation03.json',E/'CodeOnlyPreservation03.json')

report='''# Диалог формирования и подписи фактической арматуры — 30.10.2026

Геометрическое предупреждение при формировании сечения отделено пустой строкой от счётчиков. В окне отдельно показаны счётчик пропусков, причина и ссылка Geometry.RecipeDiagnostics. Компактный текст диагностики в Results не менялся. Числа, адреса и цитируемые пользовательские строки сохраняются; повторное оформление не добавляет пустые строки.

Предупреждения геометрии выводятся только при формировании. Расчёт читает сформированный снимок и не добавляет их в итоговое окно. Нативная проверка Excel/File при ReformatResultsEnabled=No/Yes подтверждает предупреждение на формировании, отсутствие решения НДС на этом этапе, реальный последующий расчёт и отсутствие повторного предупреждения.

В сохранённой пользовательской книге 20 физических стержней: верхние боковые группы по 5, нижние боковые по 2, нижние горизонтальные по 3. Верхние горизонтальные ряды полностью совпали с ранее созданными боковыми; их отдельные подписи отсутствуют. Нижние боковые группы владеют четырьмя реальными угловыми стержнями, поэтому подписи 2Ø32 правильны. Порядок первого владельца и алгоритмы расстановки/подписей не менялись.

Проверены 92 сценария Circle, Rectangles, PointedSection и HollowRectangle, включая геометрические варианты. Дополнительно все четыре вида привязок проверены на полностью совпавшем и частично сохранённом ряду с разными диаметрами: пустая физическая группа не подписывается, частичная считает только созданные стержни.

Адресная приёмка: **1468/0**, восемь принятых выполнений. Четыре стабильных набора приняты до исправления только тестового счётчика; нативные экспорты подтверждают неизменность производственных компонентов. Проверки диалога и формирования/расчёта повторены на финальном файле в No/Yes. Первый отказ сохранён: тест ошибочно считал счётчик solver монотонным, тогда как CBatchSectionCalculator.Execute сбрасывает его перед каждым пакетом. Ожидания предупреждений и физической арматуры не ослаблялись. Это направленная проверка; новый полный 182+Focused122 не запускался.

VBE-компиляция выполнена, сохранённая и повторно открытая книга содержит 175 исходных + 6 документных компонентов, соответствующих исходникам. Все восемь собственных Excel завершились обычным Quit. В пользовательском файле изменён только xl/vbaProject.bin; все 110 других ZIP-частей, включая данные, результаты, схему и оформление, совпадают побайтово. Резерв исходной книги сохранён в личном каталоге доказательств. Ready30 и чужие отчёты не изменялись.

Общий аудит шапок выявляет две существующие проблемы в неизменённых modSectionSnapshot/CNDMResultsWriter; у изменённых компонентов шапки и тестовые разделители соблюдены.

Доказательства: [Acceptance03](../regression/RebarLabelAndMessages_2026-10-30_Run01/Acceptance03.json), [архив и манифест](../regression/RebarLabelAndMessages_2026-10-30_Run01/Manifest03.json).
'''
assert total==1468
(R/'docs/reports/RebarLabelAndMessages_2026-10-30.md').write_text(report,encoding='utf-8')
progress=R/'docs/geometry_refactor/PROGRESS.md'; text=progress.read_text(encoding='utf-8-sig')
heading,rest=text.split('\n',1)
progress.write_text(heading+'\n\n## 30.10.2026 — Диалог формирования и проверка физических подписей\n\nГеометрическое предупреждение оформлено отдельными смысловыми блоками и проверено только на формировании; расчёт Excel/File его не повторяет. Подписи физической арматуры правильны: 92 сценария всех типов и четыре вида привязок приняты. Адресная приёмка 1468/0, источник/сохранённый VBA181 и все собственные закрытия проверены. Данные пользовательской книги сохранены: 110 ZIP-частей неизменны, обновлён только VBA. [Отчёт](../reports/RebarLabelAndMessages_2026-10-30.md).\n'+rest,encoding='utf-8')
(E/'Processed.json').write_text(json.dumps({'Status':'DIRECTED_PASS_READY_FOR_PUBLICATION','Acceptance':'Acceptance03.json','Report':'docs/reports/RebarLabelAndMessages_2026-10-30.md','FullSuiteRun':False},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'Status':'DIRECTED_PASS_READY_FOR_PUBLICATION','AcceptedAssertions':total,'EvidenceFiles':len(files),'FinalBookSHA256':sha(final)}))
