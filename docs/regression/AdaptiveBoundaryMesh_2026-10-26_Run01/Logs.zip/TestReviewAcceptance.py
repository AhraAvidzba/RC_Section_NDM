"""ДЛЯ ТЕСТОВ: полная повторная вычитка принятых первичных журналов и доказательств ветки."""
from pathlib import Path
import json,re,hashlib,zipfile,xml.etree.ElementTree as E
here=Path(__file__).resolve().parent;root=here.parents[2]
package=json.loads((here/'PackagePreservation02.json').read_text(encoding='utf-8'))
sha=package['ReleaseSHA256'];expected=['modTestContourMesh.RunAdaptiveBoundaryMeshTests','modTestContourMesh.RunAutomaticMeshTests','modTestGeometry.RunGeometryTests','modTestGeneralGeometryConfig.RunAudit03GeneralGeometryConfigTests','modTestContourMesh.RunContourMeshTests','modTestSectionWorkflow.RunWorkflowSnapshotTests','modTestCalculationSnapshot.RunCalculationSnapshotTests','modTestRegressionBaseline.RunRegressionBaselineTests']
reviews=[]
for mode in ['No','Yes']:
 for kind in ['Directed03','Reopen01']:
  p=here/(kind+'_'+mode+'.txt');raw=p.read_bytes();s=raw.decode('utf-8-sig')
  starts=re.findall(r'^SUITE_STARTED: ([^;]+);',s,re.M);ends=re.findall(r'^SUITE_FINISHED: ([^;]+);',s,re.M)
  wanted=expected if kind=='Directed03' else ['modTestWorkbookInterface.RunSectionWorkflowCalculationTests']
  assert starts==wanted and ends==wanted,p
  assert 'SOURCE_SHA256: '+sha in s
  assert 'SOURCE_UNCHANGED: True' in s and 'WATCHDOG_COMPLETED: exit=0' in s
  errors=re.findall(r'^FAIL:.*|^RUNTIME.*ERROR.*|^SCRIPT ERROR.*|^WATCHDOG_FAILURE.*',s,re.M)
  assert not errors,(p,errors)
  assert all(int(n)==0 for n in re.findall(r'failed=(\d+)',s))
  totals=re.findall(r'^TOTAL[^\r\n]*',s,re.M)
  assert len(totals)==len(wanted)
  if kind=='Reopen01':
   assert re.search(r'^RESULTS_SAVE_REOPEN:.*equal=True',s,re.M)
   assert re.search(r'^STATUS_STYLE_SAVE_REOPEN:.*equal=True',s,re.M)
  reviews.append(dict(Primary=p.name,SHA256=hashlib.sha256(raw).hexdigest().upper(),Bytes=len(raw),Mode=mode,Macros=starts,Totals=totals,Errors=[],FullPrimaryRead=True))
comparison=json.loads((here/'Comparison.json').read_text(encoding='utf-8'));assert comparison['Status']=='PASS_NATIVE_AB_25_CASES'
for file in ['SourceEqualityFinal.json','SourceEqualityFresh.json']:
 x=json.loads((here/file).read_text(encoding='utf-8-sig'));assert x['Passed'] and x['SourceComponents']==172 and x['ExportComponents']==178
fresh=json.loads((here/'FreshBuild.json').read_text(encoding='utf-8-sig'));assert fresh['Status']=='FRESH_BUILD_COMPLETED'
layout=json.loads((here/'FreshLayoutFinal.json').read_text(encoding='utf-8-sig'))
layoutpassed=layout.get('Status')=='PASS'
assert layoutpassed,'Fresh build layout mismatch'
plan=json.loads((here/'HelpPlan.json').read_text(encoding='utf-8'))
n={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
settings=[]
for path in [here/'Before_RC_Section_NDM.xlsm',here/'FreshBuild/RC_Section_NDM.xlsm',here/'ReleaseCandidate03/RC_Section_NDM.xlsm']:
 with zipfile.ZipFile(path) as z:
  strings=[''.join(x.itertext()) for x in E.fromstring(z.read('xl/sharedStrings.xml'))]
  if path.name=='RC_Section_NDM.xlsm':assert all(t in strings for t in plan['New'])
  sheet=E.fromstring(z.read('xl/worksheets/sheet1.xml'))
  values={}
  for row in sheet.findall('m:sheetData/m:row',n):
   cells={}
   for c in row:
    v=c.find('m:v',n)
    if v is not None:cells[c.attrib['r']]=strings[int(v.text)] if c.attrib.get('t')=='s' else v.text
   number=row.attrib['r'];key=cells.get('A'+number,'')
   if key in ['Plot.Enabled','General.ReformatResultsEnabled','Mesh.BoundarySubdivisions','Mesh.StepMode']:values[key]=cells.get('B'+number)
  settings.append(dict(File=str(path.relative_to(here)),Values=values))
assert settings[0]['Values']['Plot.Enabled']=='Yes' and settings[0]['Values']['General.ReformatResultsEnabled']=='Yes'
final=json.loads((here/'PackagePreservationFinal.json').read_text(encoding='utf-8'))
assert final['VBAIdenticalToDirectedAcceptedBook'] and final['DirectedAcceptedBookSHA256']==sha
smokes=[]
for mode in ['No','Yes']:
 p=here/('FinalSmoke_'+mode+'.txt');raw=p.read_bytes();text=raw.decode('utf-8-sig')
 assert 'SOURCE_SHA256: '+final['ReleaseSHA256'] in text and 'WATCHDOG_COMPLETED: exit=0' in text
 assert not re.search(r'^FAIL:|RUNTIME ERROR|SCRIPT ERROR|WATCHDOG_FAILURE',text,re.M)
 assert all(int(v)==0 for v in re.findall(r'failed=(\d+)',text))
 assert 'TOTAL_ADAPTIVE_BOUNDARY_MESH: passed=109; failed=0' in text and 'TOTAL_AUTO_MESH: passed=131161; failed=0' in text
 smokes.append(dict(Primary=p.name,SHA256=hashlib.sha256(raw).hexdigest().upper(),Mode=mode,Passed=True,FullPrimaryRead=True))
for file in ['FinalBookLayout.json','FreshLayoutFinal.json']:
 assert json.loads((here/file).read_text(encoding='utf-8-sig'))['Status']=='PASS'
published=json.loads((here/'SourceEqualityPublished.json').read_text(encoding='utf-8-sig'));assert published['Passed']
proof=dict(Status='PASS_DIRECTED_ADAPTIVE_BRANCH',WorkbookSHA256=final['ReleaseSHA256'],ComputationalPrimaryBookSHA256=sha,FinalVBAIdenticalToComputationalPrimaries=True,ComparisonCases=25,Comparison='Comparison.json',PrimaryReviews=reviews,FinalBookSmoke=smokes,FullNativeSourceEquality=True,FreshFullBuild=True,FreshLayoutPassed=True,FinalBookLayoutPassed=True,HelpCatalogAndBooksSynchronized=True,Settings=settings,PartsPreserved=104,FullOnOffFocusedRun=False,RealAutoCADSessionRun=False,ExistingStaticFinding='CommentAuditTriage.json',FailuresPreserved=['Directed01_No.txt','Directed02_No.txt','Build02_New/CompileFailure.json','FreshLayout.json','FreshLayout02.json'])
(here/'Acceptance.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'Status':proof['Status'],'SHA256':proof['WorkbookSHA256'],'Primaries':len(reviews),'FinalBookSmoke':len(smokes),'Assertions':sum(int(x) for r in reviews for t in r['Totals'] for x in re.findall(r'passed=(\d+)',t))}))
