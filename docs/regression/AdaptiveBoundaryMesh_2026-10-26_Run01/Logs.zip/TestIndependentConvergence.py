"""ДЛЯ ТЕСТОВ: независимая квадратура скруглённого прямоугольника 400x220, R35."""
from pathlib import Path
import math,json,re
here=Path(__file__).resolve().parent
records=[]
for level in [1,2,4]:
 for base in [50.,25.,12.5]:
  q=base/(2**level);nx=(int(400/base)+1)*2**level;ny=(int(220/base)+1)*2**level
  area=sx=sy=ix=iy=0.
  for j in range(ny):
   y=-110+(j+.5)*q
   for i in range(nx):
    x=-200+(i+.5)*q
    if abs(x)>200 or abs(y)>110:continue
    dx=max(abs(x)-165,0);dy=max(abs(y)-75,0)
    if dx*dx+dy*dy>35**2+1e-9:continue
    a=q*q;area+=a;sx+=a*x;sy+=a*y;ix+=a*(y*y+q*q/12);iy+=a*(x*x+q*q/12)
  records.append(dict(Level=level,Base=base,Area=area,CentroidX=sx/area,CentroidY=sy/area,Ixc=ix-sy*sy/area,Iyc=iy-sx*sx/area))
raw=(here/'Directed02_No.txt').read_text(encoding='utf-8-sig')
for r in records:
 if r['Level']!=1:continue
 m=re.search(r'CONVERGENCE: step='+str(r['Base']).rstrip('0').rstrip('.')+r' area=([0-9.]+);.*?Ix=([0-9.]+); Iy=([0-9.]+)',raw)
 if not m:raise ValueError('Missing native reference')
 actual=list(map(float,m.groups()))
 assert abs(actual[0]-r['Area'])<1e-6
 assert abs(actual[1]-r['Ixc'])/(1+abs(r['Ixc']))<1e-10
 assert abs(actual[2]-r['Iyc'])/(1+abs(r['Iyc']))<1e-10
proof=dict(Status='NATIVE_LEVEL1_REPRODUCED_BY_INDEPENDENT_RASTER',Shape='Rounded rectangle 400x220 R35',Records=records,AnalyticalArea=400*220-(4-math.pi)*35**2,OldNative='Directed02_No.txt',ThresholdsNotRelaxed=True)
(here/'IndependentConvergence.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
print(proof['Status'])
