"""ДЛЯ ТЕСТОВ: читает все первичные A/B журналы и сохраняет численные результаты."""
from pathlib import Path
import re,json,hashlib,statistics,csv
here=Path(__file__).resolve().parent
folder=here/'Comparison01'
state=json.loads((folder/'Run.json').read_text(encoding='utf-8-sig'))
if state['Status']!='COMPLETED_PRIMARY_REVIEW_REQUIRED' or len(state['Completed'])!=25:raise SystemExit('Comparison not complete')
records=[]
for job in state['Completed']:
 p=Path(job['Primary']); raw=p.read_bytes(); text=raw.decode('utf-8-sig')
 if hashlib.sha256(raw).hexdigest().upper()!=job['SHA256']:raise ValueError('Primary changed')
 if re.search(r'^FAIL:|RUNTIME_ERROR|WATCHDOG_FAILURE',text,re.M) or 'TOTAL_ADAPTIVE_BENCHMARK: passed=1; failed=0' not in text or 'WATCHDOG_COMPLETED: exit=0' not in text:raise ValueError('Failed primary')
 info=re.search(r'^BENCH_INFO\|(.+)$',text,re.M).group(1).strip().split('|')
 times={kind:[float(m.group(1)) for m in re.finditer(r'^BENCH_'+kind+r'\|[^\r\n]+\|([0-9.]+)\r?$',text,re.M)] for kind in ['MESH','FORM']}
 if any(len(v)!=5 for v in times.values()):raise ValueError('Missing measured repeats')
 level=int(info[1]); base=float(info[6]); minimum=base/(2**level if job['Variant']=='New' else level)
 r=dict(Shape=info[0],Value=level,Variant=job['Variant'],Concrete=int(info[2]),Rebar=int(info[3]),WidthMM=float(info[4]),HeightMM=float(info[5]),BaseStepMM=base,MinimumAllowedStepMM=minimum,AreaMM2=float(info[7]),AnalyticalAreaMM2=float(info[8]),IxcMM4=float(info[9]),IycMM4=float(info[10]),MeshSeconds=times['MESH'],FormationSeconds=times['FORM'],Primary=p.name,PrimarySHA256=job['SHA256'])
 for kind,key in [('MESH','Mesh'),('FORM','Formation')]:
  r[key+'MedianSeconds']=statistics.median(times[kind]);r[key+'MinSeconds']=min(times[kind]);r[key+'MaxSeconds']=max(times[kind])
 r['AreaRelativeErrorPercent']=100*(r['AreaMM2']/r['AnalyticalAreaMM2']-1)
 records.append(r)
lookup={(r['Shape'],r['Value'],r['Variant']):r for r in records}
same=[];equal=[]
for shape in ['OneRect','Rectangles','Circle','HollowRectangle','PointedSection']:
 for value in [2,4]:
  a=lookup[shape,value,'Old'];b=lookup[shape,value,'New']
  same.append(dict(Shape=shape,Value=value,OldElements=a['Concrete'],NewElements=b['Concrete'],OldMeshMS=1000*a['MeshMedianSeconds'],NewMeshMS=1000*b['MeshMedianSeconds'],OldFormationSeconds=a['FormationMedianSeconds'],NewFormationSeconds=b['FormationMedianSeconds'],FormationDeltaSeconds=b['FormationMedianSeconds']-a['FormationMedianSeconds']))
  e=lookup[shape,2**value,'Old']
  if abs(e['AreaMM2']-b['AreaMM2'])>1e-5:raise ValueError('Equal-resolution raster areas differ: '+shape)
  if max(abs(e['IxcMM4']-b['IxcMM4'])/(1+abs(e['IxcMM4'])),abs(e['IycMM4']-b['IycMM4'])/(1+abs(e['IycMM4'])))>1e-10:raise ValueError('Equal-resolution inertias differ: '+shape)
  equal.append(dict(Shape=shape,OldValue=2**value,NewLevels=value,OldElements=e['Concrete'],NewElements=b['Concrete'],ElementSavingPercent=100*(1-b['Concrete']/e['Concrete']),OldFormationSeconds=e['FormationMedianSeconds'],NewFormationSeconds=b['FormationMedianSeconds'],SameArea=True,SameIxcIyc=True))
proof=dict(Status='PASS_NATIVE_AB_25_CASES',Records=records,SameParameter=same,EqualMinimumStep=equal,Repeats=5,WarmupRepeats=1,MeshBuildsPerTimedRepeat=20,FullFormationIncludes=['Excel guard','input reread','settings/geometry/rebar/annotations','Results write','diagram update','Excel restoration'],OtherUserApplicationsKeptOpen=True,FullRegressionRun=False)
(here/'Comparison.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
with (here/'Comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(same[0]));w.writeheader();w.writerows(same)
print(json.dumps({'Status':proof['Status'],'SameParameter':same,'EqualMinimumStep':equal},ensure_ascii=True))
