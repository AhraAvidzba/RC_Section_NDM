﻿# ДЛЯ ТЕСТОВ: последовательное A/B, пять повторов после прогрева; штатное формирование со схемой.
param([string]$OldRelative='Build04_Old/RC_Section_NDM.xlsm',[string]$NewRelative='Build04_New/RC_Section_NDM.xlsm',[string]$Label='Comparison01')
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$directory=Join-Path $PSScriptRoot $Label
if(Test-Path -LiteralPath $directory){throw 'Fresh comparison directory required.'}
[void][IO.Directory]::CreateDirectory($directory)
$self=Get-Process -Id $PID
$state=[ordered]@{Status='RUNNING';PID=$PID;StartTicksUTC=[string]$self.StartTime.ToUniversalTime().Ticks;Started=[DateTimeOffset]::Now.ToString('o');Completed=@();Current=$null;FullRegressionRun=$false}
try{
 foreach($shape in @('OneRect','Rectangles','Circle','HollowRectangle','PointedSection')){
  foreach($depth in @(2,4,16)){
   $variants=@('Old','New');if($depth -eq 4){$variants=@('New','Old')};if($depth -eq 16){$variants=@('Old')}
   foreach($variant in $variants){
    $relative=if($variant -eq 'Old'){$OldRelative}else{$NewRelative}
    $source=Join-Path $PSScriptRoot $relative
    $report=Join-Path $directory ($shape+'_'+$depth+'_'+$variant+'.txt')
    $state.Current=$shape+' / '+$depth+' / '+$variant
    $state|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $directory 'Run.json') -Encoding UTF8
    & (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') -SourceWorkbook $source -ReportPath $report.Substring($root.Length+1) -Mode No -Macro 'modTestContourMesh.TestMeasureAdaptiveMeshBenchmark' -MacroArgument1 $shape -MacroArgument2 ([string]$depth) -TimeoutSeconds 600
    if($LASTEXITCODE -ne 0){throw "Benchmark failed: $($state.Current)"}
    $text=[IO.File]::ReadAllText($report,[Text.Encoding]::UTF8)
    if($text -notmatch 'TOTAL_ADAPTIVE_BENCHMARK: passed=1; failed=0' -or $text -match '(?m)^FAIL:|RUNTIME_ERROR|WATCHDOG_FAILURE' -or $text -notmatch 'WATCHDOG_COMPLETED: exit=0') {throw "Incomplete primary: $report"}
    $state.Completed+=@{Shape=$shape;Value=$depth;Variant=$variant;Primary=$report;SHA256=(Get-FileHash -LiteralPath $report).Hash}
   }
  }
 }
 $state.Status='COMPLETED_PRIMARY_REVIEW_REQUIRED'
}catch{$state.Status='REVIEW_REQUIRED';$state.Error=$_.Exception.Message;throw}
finally{$state.Finished=[DateTimeOffset]::Now.ToString('o');$state|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $directory 'Run.json') -Encoding UTF8}
