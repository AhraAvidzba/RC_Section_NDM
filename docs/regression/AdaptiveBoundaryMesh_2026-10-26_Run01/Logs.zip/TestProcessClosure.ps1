﻿# ДЛЯ ТЕСТОВ: финальная сверка точных идентичностей всех собственных Excel/контроллеров без закрытия чужих процессов.
$ErrorActionPreference='Stop'
$records=@()
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File -Filter '*.json'){
 if($file.Name -match 'NativeCode|BeforeNative|Requirements|Acceptance|Manifest|Review|ProcessClosure'){continue}
 try{$x=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json}catch{continue}
 $ticks=$null
 if($x.StartTicksUTC){$ticks=[string]$x.StartTicksUTC}elseif($x.StartTicks){$ticks=[string]$x.StartTicks}elseif($x.StartTicksUtc){$ticks=[string]$x.StartTicksUtc}
 if($x.PID -and $ticks){$records+=@{PID=[int]$x.PID;Ticks=$ticks;Source=$file.Name}}
 if($x.GuardPID -and $x.GuardStartTicks){$records+=@{PID=[int]$x.GuardPID;Ticks=[string]$x.GuardStartTicks;Source=$file.Name+' guard'}}
}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File -Filter '*.txt'){
 if($file.Name -match 'NativeSnapshot|progress'){continue}
 $line=Select-String -LiteralPath $file.FullName -Pattern '^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)' -Encoding UTF8|Select-Object -First 1
 if($line -and $line.Line -match 'id=(\d+); startTicks=(\d+)'){$records+=@{PID=[int]$Matches[1];Ticks=$Matches[2];Source=$file.Name}}
}
# WMI не теряет наблюдение при гонке выхода процесса или недоступном Process.StartTime.
# Его точность — микросекунда: совпадение в пределах 10 ticks трактуется консервативно как возможный живой собственный процесс.
$inventory=@{}
foreach($process in Get-CimInstance Win32_Process){$inventory[[int]$process.ProcessId]=$process}
$seen=@{};$checks=@()
foreach($x in $records){
 $identity=[string]$x.PID+'|'+$x.Ticks
 if($seen.ContainsKey($identity)){continue};$seen[$identity]=$true
 $process=$inventory[[int]$x.PID];$live=$false;$currentTicks=$null;$unknown=$false
 if($process){
  if($process.CreationDate){$currentTicks=$process.CreationDate.ToUniversalTime().Ticks;$live=([math]::Abs([decimal]$currentTicks-[decimal]$x.Ticks) -le 10)}
  elseif($process.Name -in @('EXCEL.EXE','powershell.exe','pwsh.exe')){$unknown=$true}
 }
 $checks+=@{PID=$x.PID;UTCStartTicks=$x.Ticks;ExactIdentityLive=$live;Unverifiable=$unknown;CurrentWmiStartTicks=if($currentTicks){[string]$currentTicks}else{''};Source=$x.Source;Name=if($process){$process.Name}else{''}}
}
$user=$inventory[12016]
$m=Get-CimInstance Win32_OperatingSystem
$passed=@($checks|Where-Object {$_.ExactIdentityLive -or $_.Unverifiable}).Count -eq 0
[ordered]@{Status=if($passed){'ALL_OWN_IDENTITIES_CLOSED'}else{'REVIEW_LIVE_OWN_IDENTITIES'};CheckedUTC=[DateTimeOffset]::UtcNow.ToString('o');OwnIdentityCount=$checks.Count;Checks=$checks;UserExcelPID=12016;UserExcelUTCStartTicks=if($user){[string]$user.CreationDate.ToUniversalTime().Ticks}else{''};UserExcelStoppedByAgent=$false;FreePhysicalGiB=$m.FreePhysicalMemory*1KB/1GB;FreeCommitGiB=$m.FreeVirtualMemory*1KB/1GB}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'ProcessClosure.json') -Encoding UTF8
if(-not $passed){throw 'Recorded own process still alive; observe it before publication.'}
Write-Output ('All own identities closed: '+$checks.Count)
