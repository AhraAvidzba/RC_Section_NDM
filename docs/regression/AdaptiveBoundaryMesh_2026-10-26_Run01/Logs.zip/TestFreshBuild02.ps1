﻿# ДЛЯ ТЕСТОВ: полная сборка нового шаблона в изоляции, без перезаписи пользовательской книги.
$ErrorActionPreference='Stop'
$evidenceOuter=$PSScriptRoot
$repoOuter=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $repoOuter
$memoryOuter=Get-CimInstance Win32_OperatingSystem
if($memoryOuter.FreePhysicalMemory*1KB -lt 4GB -or $memoryOuter.FreeVirtualMemory*1KB -lt 8GB){throw 'Insufficient reserve; no Excel started.'}
$builderScript=Join-Path $repoOuter 'tools/build_workbook/Build-Workbook.ps1'
$startedOuter=[DateTimeOffset]::Now.ToString('o')
. $builderScript -OutputPath 'docs/regression/AdaptiveBoundaryMesh_2026-10-26_Run01/FreshBuild02/RC_Section_NDM.xlsm' -FormulaImageDirectory 'docs/regression/AdaptiveBoundaryMesh_2026-10-26_Run01/FreshBuild02/FormulaImages'
[ordered]@{Status='FRESH_BUILD_COMPLETED';Started=$startedOuter;Finished=[DateTimeOffset]::Now.ToString('o');PID=$ownedExcelProcessId;StartTicksUTC=[string]$ownedExcelStartTicks;FreePhysicalBeforeGiB=$memoryOuter.FreePhysicalMemory*1KB/1GB;FreeCommitBeforeGiB=$memoryOuter.FreeVirtualMemory*1KB/1GB;SourceBuildScriptSHA256=(Get-FileHash -LiteralPath $builderScript).Hash;BookSHA256=(Get-FileHash -LiteralPath (Join-Path $evidenceOuter 'FreshBuild02/RC_Section_NDM.xlsm')).Hash}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $evidenceOuter 'FreshBuild02.json') -Encoding UTF8