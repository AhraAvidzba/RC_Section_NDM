﻿# ДЛЯ ТЕСТОВ: профильная приёмка адаптивного генератора без полного UI и без нового полного набора.
param([ValidateSet('No','Yes')][string]$Mode='No',[string]$SourceRelative='Build04_New/RC_Section_NDM.xlsm',[string]$Label='Directed01')
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$source=Join-Path $PSScriptRoot $SourceRelative
$report=Join-Path $PSScriptRoot ($Label+'_'+$Mode+'.txt')
if(Test-Path -LiteralPath $report){throw 'Preserve existing primary.'}
$macros=@('modTestContourMesh.RunAdaptiveBoundaryMeshTests','modTestContourMesh.RunAutomaticMeshTests','modTestGeometry.RunGeometryTests','modTestGeneralGeometryConfig.RunAudit03GeneralGeometryConfigTests','modTestContourMesh.RunContourMeshTests','modTestSectionWorkflow.RunWorkflowSnapshotTests','modTestCalculationSnapshot.RunCalculationSnapshotTests','modTestRegressionBaseline.RunRegressionBaselineTests')
& (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') -SourceWorkbook $source -ReportPath $report.Substring($root.Length+1) -Mode $Mode -Macro ($macros -join ',') -TimeoutSeconds 900
exit $LASTEXITCODE
