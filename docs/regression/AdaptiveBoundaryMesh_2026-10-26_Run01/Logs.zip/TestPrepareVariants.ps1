﻿# ДЛЯ ТЕСТОВ: готовит только частную копию; старый и новый варианты различаются рабочим построителем.
param([ValidateSet('Old','New')][string]$Variant='New',[string]$Label='Build01')
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$source=Join-Path $PSScriptRoot 'Before_RC_Section_NDM.xlsm'
$directory=Join-Path $PSScriptRoot ($Label+'_'+$Variant)
if(Test-Path -LiteralPath $directory){throw 'Use fresh preparation directory.'}
[void][IO.Directory]::CreateDirectory($directory)
$path=Join-Path $directory 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath $source -Destination $path
$memory=Get-CimInstance Win32_OperatingSystem
if($memory.FreePhysicalMemory*1KB -lt 4GB -or $memory.FreeVirtualMemory*1KB -lt 8GB){throw 'Insufficient reserve; no Excel started.'}
$changed=@{'modTestContourMesh'='tests/modTestContourMesh.bas'}
if($Variant -eq 'New'){
 foreach($relative in @(git -C $root diff --name-only b7819a488bca3fe3465bf412114a067d703d7ca1 -- src tests)){
  if([IO.Path]::GetExtension($relative) -in '.cls','.bas'){$changed[[IO.Path]::GetFileNameWithoutExtension($relative)]=$relative}
 }
}
$sourceHash=(Get-FileHash -LiteralPath $source).Hash
Add-Type 'using System;using System.Runtime.InteropServices;public static class NdmAdaptiveOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$beforePids=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$owned=0;$ticks=0
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$nativeId=0;[void][NdmAdaptiveOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$nativeId)
 $owned=[int]$nativeId;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 if($owned -in $beforePids){throw 'New owned Excel required.'}
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Status='PREPARING';Variant=$Variant;SourceSHA256=$sourceHash;FreeRAMGiB=$memory.FreePhysicalMemory*1KB/1GB;FreeCommitGiB=$memory.FreeVirtualMemory*1KB/1GB}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $directory 'Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 $book=$app.Workbooks.Open($path,0,$false)
 $before=[ordered]@{}
 foreach($c in $book.VBProject.VBComponents){$n=$c.CodeModule.CountOfLines;$before[$c.Name]=if($n){$c.CodeModule.Lines(1,$n)}else{''}}
 foreach($name in $changed.Keys){
  $body=[regex]::Match([IO.File]::ReadAllText((Join-Path $root $changed[$name]),[Text.Encoding]::UTF8),'(?ms)^Option Explicit.*').Value
  if(-not $body){throw "Missing source $name"}
  $module=$book.VBProject.VBComponents.Item($name).CodeModule
  $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString(($body -split '\r?\n') -join "`r`n")
 }
 $app.VBE.ActiveVBProject=$book.VBProject
 $compile=$app.VBE.CommandBars.FindControl(1,578)
 if(-not $compile){throw 'Compile command missing.'}
 if($compile.Enabled){$compile.Execute()}
 if($compile.Enabled){
  $pane=$app.VBE.ActiveCodePane;$sl=0;$sc=0;$el=0;$ec=0
  $pane.GetSelection([ref]$sl,[ref]$sc,[ref]$el,[ref]$ec)
  $failure=[ordered]@{Component=$pane.CodeModule.Parent.Name;Line=$sl;Text=$pane.CodeModule.Lines([math]::Max(1,$sl-2),5)}
  $failure|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $directory 'CompileFailure.json') -Encoding UTF8
  throw ('Compile failed: '+($failure|ConvertTo-Json -Compress))
 }
 $after=[ordered]@{}
 foreach($c in $book.VBProject.VBComponents){$n=$c.CodeModule.CountOfLines;$after[$c.Name]=if($n){$c.CodeModule.Lines(1,$n)}else{''}}
 $caseOnly=@();$differences=@($before.Keys|Where-Object {$before[$_] -cne $after[$_]})
 foreach($name in $differences){
  if($changed.ContainsKey($name)){continue}
  $pattern='"(?:[^"\r\n]|"")*"|''[^\r\n]*|[A-Za-z_][A-Za-z_0-9]*'
  $normalizer=[Text.RegularExpressions.MatchEvaluator]{param($m) if($m.Value.StartsWith('"') -or $m.Value.StartsWith("'")){$m.Value}else{$m.Value.ToLowerInvariant()}}
  if([regex]::Replace($before[$name],$pattern,$normalizer) -cne [regex]::Replace($after[$name],$pattern,$normalizer)){throw "Unexpected code change: $name"}
  $caseOnly+=$name
 }
 if($after.Count -ne 178){throw 'Unexpected component count.'}
 $book.Save();$book.Close($false);$book=$null
 [ordered]@{Status='COMPILED_PRIVATE';Variant=$Variant;SourceSHA256=$sourceHash;SHA256=(Get-FileHash -LiteralPath $path).Hash;Changed=@($changed.Keys);CompilerIdentifierCaseOnly=$caseOnly;Components=$after.Count;FullRegressionRun=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $directory 'Preparation.json') -Encoding UTF8
}finally{
 $process=Get-Process -Id $owned -ErrorAction SilentlyContinue
 if($process -and $process.ProcessName -eq 'EXCEL' -and $process.StartTime.ToUniversalTime().Ticks -eq $ticks -and $owned -notin $beforePids){if($book){$book.Close($false)};if($app){$app.Quit()}}
 if($app){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
if((Get-FileHash -LiteralPath $source).Hash -cne $sourceHash){throw 'Baseline changed.'}
Get-Content -LiteralPath (Join-Path $directory 'Preparation.json') -Raw
