"""ДЛЯ ТЕСТОВ: переносит только VBA и согласованные тексты; все остальные части исходного пакета сохраняет побайтно."""
from pathlib import Path
import zipfile,re,subprocess,json,hashlib,xml.etree.ElementTree as E,html
root=Path.cwd();here=Path(__file__).resolve().parent
oldsource=subprocess.run(['git','show','b7819a4:tools/build_workbook/SettingsCatalog.ps1'],capture_output=True,check=True).stdout.decode('utf-8-sig')
source=(root/'tools/build_workbook/SettingsCatalog.ps1').read_text(encoding='utf-8-sig')
plan=json.loads((here/'HelpPlan.json').read_text(encoding='utf-8'))
oldpars=plan['Old'];newpars=plan['New']
assert len(oldpars)==len(newpars)==8
pattern=r'        "Mesh.BoundarySubdivisions" \{ return @\((.*?)\n        \) \}'
actual=re.findall(r'^\s*"(.*)"[,]?$',re.search(pattern,source,re.S).group(1),re.M)
assert actual==newpars,'Build catalog not synchronized'
pairs=dict(zip(oldpars,newpars))
for marker in ['@("Mesh.BoundarySubdivisions",','Mesh.BoundarySubdivisions работает в Auto и User одинаково:']:
 oldline=next(line for line in oldsource.splitlines() if marker in line)
 if marker.startswith('@('):
  before=re.findall(r'"(.*?)"',oldline)[3]
  newline=next(line for line in source.splitlines() if '@("Mesh.BoundarySubdivisions",' in line)
  after=re.findall(r'"(.*?)"',newline)[3]
 else:
  before=re.findall(r'"(.*?)"',oldline)[0]
  after=next(re.findall(r'"(.*?)"',line)[0] for line in source.splitlines() if 'Mesh.BoundarySubdivisions работает в Auto и User одинаково.' in line)
 pairs[before]=after
baseline=here/'Before_RC_Section_NDM.xlsm';candidate=here/'Build06_New/RC_Section_NDM.xlsm'
out=here/'ReleaseCandidate02/RC_Section_NDM.xlsm';out.parent.mkdir(exist_ok=True)
if out.exists():raise FileExistsError(out)
changed_strings=[]
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(baseline) as a,zipfile.ZipFile(candidate) as b:
 xml=a.read('xl/sharedStrings.xml').decode('utf-8')
 def change(m):
  text=''.join(E.fromstring(m.group(0)).itertext())
  if text not in pairs:return m.group(0)
  if len(re.findall(r'<t(?: [^>]*)?>',m.group(0)))!=1:raise ValueError('Rich text replacement unsupported')
  changed_strings.append(text)
  return re.sub(r'(<t(?: [^>]*)?>).*?(</t>)',lambda t:t.group(1)+html.escape(pairs[text],quote=False)+t.group(2),m.group(0),flags=re.S)
 xml=re.sub(r'<si(?: [^>]*)?>.*?</si>',change,xml,flags=re.S)
 if len(changed_strings)!=10 or set(changed_strings)!=set(pairs):raise ValueError('Expected 10 unique string replacements')
 with zipfile.ZipFile(out,'w') as z:
  for item in a.infolist():
   data=a.read(item.filename)
   if item.filename=='xl/vbaProject.bin':data=b.read(item.filename)
   if item.filename=='xl/sharedStrings.xml':data=xml.encode('utf-8')
   z.writestr(item,data)
with zipfile.ZipFile(baseline) as a,zipfile.ZipFile(out) as b:
 assert a.namelist()==b.namelist();assert b.testzip() is None
 diffs=[n for n in a.namelist() if a.read(n)!=b.read(n)]
 assert set(diffs)=={'xl/vbaProject.bin','xl/sharedStrings.xml'}
 proof=dict(Status='PASS_VBA_AND_10_TEXTS_ONLY',Parts=len(a.namelist()),UnchangedParts=len(a.namelist())-2,ChangedParts=diffs,DataResultsFormattingNamesListsPreserved=True,SourceBookSHA256=hashlib.sha256(baseline.read_bytes()).hexdigest().upper(),CandidateSHA256=hashlib.sha256(candidate.read_bytes()).hexdigest().upper(),ReleaseSHA256=hashlib.sha256(out.read_bytes()).hexdigest().upper(),TextReplacements=[{'Before':k,'After':v} for k,v in pairs.items()])
(here/'PackagePreservation02.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in proof.items() if k!='TextReplacements'},ensure_ascii=True))
