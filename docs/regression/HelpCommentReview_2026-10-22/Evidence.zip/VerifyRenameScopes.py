"""ДЛЯ ТЕСТОВ: независимый повтор разрешения владельцев по сохранённому состоянию до rename."""
import importlib.util
import json
import zipfile
from pathlib import Path
from ApprovedMethodFixes import ApprovedFixes

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rename', HERE / 'RenameTests.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
fixes = ApprovedFixes(m.spans, m.meaningful_tokens)
plan = json.loads((HERE / 'TestRenamePlan.json').read_text(encoding='utf-8'))
archive = zipfile.ZipFile(HERE / 'TestRenameBefore.zip')
saved = {name: archive.read(name) for name in archive.namelist()}
inverse = {value: key for key, value in m.CLASSES.items()}


class SavedPath:
    def __init__(self, actual):
        self.actual = actual
        self.old = actual.with_name(inverse.get(actual.stem, actual.stem) + actual.suffix)
        self.raw = saved.get(self.old.relative_to(ROOT).as_posix(), actual.read_bytes())
    def __getattr__(self, name):
        return getattr(self.old, name)
    def read_text(self, encoding='utf-8-sig'):
        return self.raw.decode(encoding)
    def read_bytes(self):
        return self.raw


paths = [SavedPath(path) for path in m.files()]
m.files = lambda: paths
modules, exceptions, public, returns = m.build_plan()
maps = {name.casefold(): {old.casefold(): new for old, new in names.items()} for name, names in modules.items()}
assert plan['Methods'] == {name: names for name, names in modules.items() if names}, 'Renaming scope changed.'
non_test = {method['Name'].casefold() for path in paths if path.parent.name != 'tests' and path.stem not in m.TEST_CLASS
            for method in m.audit.inspect(path)['Methods'] if not method['TestMarker']}
non_test |= {name.casefold() for names in m.CONTRACTS.values() for name in names}
m.CLASS_MEMBER_MODULES = {path.stem for path in paths if path.suffix == '.cls' and modules.get(path.stem)}
unique = {old.casefold(): new for cls in m.CLASS_MEMBER_MODULES for old, new in modules.get(cls, {}).items() if old.casefold() not in non_test}
different = []
unresolved = []
checked = 0
for path in paths:
    before = path.read_text()
    output = ''
    last = 0
    parts = m.spans(before)
    global_types = m.declared_types(before[:parts[0][0]] if parts else before)
    for start, end, name in parts:
        prefix = before[last:start]
        for old, new in m.CLASSES.items(): prefix = m.re.sub(r'\b' + m.re.escape(old) + r'\b', new, prefix)
        output += prefix
        result, logs = m.transform_scope(before[start:end], path.stem, maps.get(path.stem.casefold(), {}), maps, public, returns, global_types, unique, unresolved)
        output += result
        last = end
    tail = before[last:]
    for old, new in m.CLASSES.items(): tail = m.re.sub(r'\b' + m.re.escape(old) + r'\b', new, tail)
    output += tail
    if path.stem == 'CNDMResultsWriter':
        for old, new in m.DISPLAY_LITERALS.items(): output = output.replace(old, new)
    actual = path.actual.read_bytes().decode('utf-8-sig')
    left = m.meaningful_tokens(output)
    right = fixes.module_tokens(path.actual.relative_to(ROOT).as_posix(), actual)
    if left != right:
        mismatch = [{'Token': i, 'Expected': a, 'Actual': b} for i, (a, b) in enumerate(zip(left, right)) if a != b]
        different.append({'File': path.actual.relative_to(ROOT).as_posix(), 'Differences': mismatch[:30]})
    checked += 1
report = {'VbaFiles': checked, 'KnownDeclaredTypesNeverOverriddenByFactoryGuesses': True,
          'MechanicalRenamesOnlyExceptApprovedMethods': True, 'ApprovedMethodFixes': fixes.finish(),
          'Mismatches': different, 'Unresolved': unresolved}
(HERE / 'TestRenameScopeProof.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'VbaFiles': checked, 'Mismatches': len(different), 'Unresolved': len(unresolved)}))
assert not different, different
assert not unresolved, unresolved
