﻿# ДЛЯ ТЕСТОВ: обновляет исходники и события только в отдельной копии, затем экспортирует фактический VBA.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$candidate=Join-Path $PSScriptRoot 'CompiledCandidate.xlsm'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Baseline.xlsm') -Destination $candidate
& (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath 'docs/regression/HelpCommentReview_2026-10-22/CompiledCandidate.xlsm' -RetiredModules @('CFakeAcadContour','CFakeAcadContourExport','CFakeAcadDocument','CFakeAcadLine','CFakeAcadRegion','CLinearConcreteMaterial','CLinearSteelMaterial')
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'CodeUpdate.json'))) {throw 'Source import did not finish.'}
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class DocumentationCompileWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint id);}'
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0
try {
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=3
    [uint32]$id=0;[void][DocumentationCompileWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    $ownedPid=[int]$id;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
    [ordered]@{OwnPID=$ownedPid;OwnStartTicks=$ownedTicks} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'CompileProcess.json') -Encoding UTF8
    Write-Output "OWNED_EXCEL: id=$ownedPid; utcStartTicks=$ownedTicks"
    $book=$excel.Workbooks.Open($candidate,0,$false)
    if ($book.ReadOnly) {throw 'Private candidate is read-only.'}
    $module=$book.VBProject.VBComponents.Item([string]$book.CodeName).CodeModule
    if ($module.CountOfLines) {$module.DeleteLines(1,$module.CountOfLines)}
    $module.AddFromString([IO.File]::ReadAllText((Join-Path $root 'tools/build_workbook/WorkbookHelpEvents.vba'),[Text.Encoding]::UTF8))
    $excel.VBE.ActiveVBProject=$book.VBProject
    $compile=$excel.VBE.CommandBars.FindControl(1,578)
    if ($null -eq $compile) {throw 'Compile command unavailable.'}
    if ($compile.Enabled) {$compile.Execute()}
    if ($compile.Enabled) {throw 'VBA compilation failed.'}
    $book.Save();$book.Close($false);$book=$null
    # Reopen the saved container before reading code; the export proves the actual candidate.
    $book=$excel.Workbooks.Open($candidate,0,$true)
    $native=New-Object Text.StringBuilder
    [void]$native.AppendLine('VBA PROJECT EXPORT');[void]$native.AppendLine('Workbook: RC_Section_NDM.xlsm')
    [void]$native.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    $names=@()
    foreach ($component in $book.VBProject.VBComponents) {
        $names+=[string]$component.Name;$lines=[int]$component.CodeModule.CountOfLines
        [void]$native.AppendLine('='*100);[void]$native.AppendLine('COMPONENT: '+$component.Name)
        [void]$native.AppendLine('TYPE: '+$component.Type);[void]$native.AppendLine('LINES: '+$lines);[void]$native.AppendLine('='*100)
        if ($lines) {[void]$native.AppendLine($component.CodeModule.Lines(1,$lines))}
        [void]$native.AppendLine()
    }
    [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'NativeVBA.txt'),$native.ToString(),(New-Object Text.UTF8Encoding($true)))
    $book.Close($false);$book=$null
    [ordered]@{Compiled=$true;Reopened=$true;WorkbookSHA256=(Get-FileHash -LiteralPath $candidate).Hash;Components=$names;OwnPID=$ownedPid;OwnStartTicks=$ownedTicks} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'NativeCompilation.json') -Encoding UTF8
    Write-Output ('COMPILED_NATIVE_READY: components='+$names.Count)
} finally {
    if ($book) {$book.Close($false)}
    if ($excel) {$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if ($ownedPid) {
        $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
        if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks) {Stop-Process -Id $ownedPid -Force}
    }
}
