"""Сопоставляет новую справку с существующими ячейками без сдвига ссылок и таблиц."""
from pathlib import Path
import json,re,sys
HERE=Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding='utf-8')
read=lambda name:json.loads((HERE/name).read_text(encoding='utf-8-sig'))
before,after=read('HelpCatalogBefore.json'),read('HelpCatalogAfter.json')
cells={c['Cell']:c['Text'] for r in read('HelpBefore.json') for c in r['Cells']}
edits={};coverage=[];unmatched=[]
def add(address,new,reason):
 old=cells.get(address,'')
 if old==new:return
 assert address not in edits or edits[address]['After']==new,(address,reason)
 edits[address]={'Address':address,'Before':old,'After':new,'Reason':reason}
def split_balanced(text,count):
 """Сохраняет исходное число строк абзаца, деля только по пробелам."""
 words=text.split();result=[]
 for index in range(count-1):
  target=max(1,(len(' '.join(words))+(count-index)-1)//(count-index));take=1
  while take<len(words) and len(' '.join(words[:take+1]))<=target:take+=1
  result.append(' '.join(words[:take]));words=words[take:]
 result.append(' '.join(words));return result
def find_paragraph(text):
 matches=[]
 for address,value in cells.items():
  if not address.startswith('A') or not text.startswith(value[:80]):continue
  row=int(address[1:]);parts=[]
  for offset in range(12):
   key='A'+str(row+offset)
   if key not in cells:break
   parts.append(cells[key]);joined=' '.join(parts)
   if joined==text:matches.append(['A'+str(row+k) for k in range(len(parts))]);break
   if len(joined)>len(text):break
 return matches
after_by_key={block['Key']:block for block in after}
assert len(after_by_key)==len(after)==len(before)
for old in before:
 new=after_by_key[old['Key']]
 assert len(old['Lines'])==len(new['Lines'])
 if old['Title']!=new['Title']:
  assert old['Key']=='General.ReformatResultsEnabled' and new['Title'] in cells.values()
 anchors=[int(a[1:]) for a,t in cells.items() if a.startswith('A') and t in (old['Title'],new['Title'])]
 paragraphs=0
 for index,(a,b) in enumerate(zip(old['Lines'],new['Lines']),1):
  if a==b:continue
  paragraphs+=1
  if len(anchors)==1 and cells.get('B'+str(anchors[0]+index))==a:
   add('B'+str(anchors[0]+index),b,old['Key']);continue
  matches=find_paragraph(a)
  if len(matches)!=1:unmatched.append({'Key':old['Key'],'Before':a,'After':b,'Matches':matches});continue
  addresses=matches[0]
  for address,text in zip(addresses,split_balanced(b,len(addresses))):add(address,text,old['Key'])
 coverage.append({'Key':old['Key'],'ParagraphsReviewed':len(old['Lines']),'ChangedParagraphs':paragraphs,'HeaderRows':anchors})
# Методические разделы записаны объединёнными строками A:F с разбиением абзацев.
methodology=[]
for change in read('HelpTextChanges.json'):
 if 'before' not in change:continue
 old,new=change['before'],change['after']
 if old==new or '$' in old:continue  # Интерполированные lead-строки уже сверены через живой каталог.
 if any(old in block['Lines'] for block in before):continue
 matches=find_paragraph(old)
 if len(matches)==1:
  for address,text in zip(matches[0],split_balanced(new,len(matches[0]))):add(address,text,'Методика')
  methodology.append({'SourceLine':change.get('sourceLineBefore'),'Cells':matches[0]})
 else:methodology.append({'SourceLine':change.get('sourceLineBefore'),'NotDisplayed':True,'Matches':matches})
# Убираем хвост прежнего двухстрочного уведомления после точечной правки предыдущей задачи.
assert cells['A67']=='AUTOCAD».' and cells['A66'].startswith('Если бетонная сетка автоматически создана')
add('A67','','Удалён остаток прежнего уведомления об импорте')
# Numbered catalog cells are numeric and were omitted from the text-only dump.
for change in read('HelpDedupEdits.json')['Edits']:
 if change['Address'].startswith('A'):
  assert change['After']=='' and change['Address'] not in edits
  edits[change['Address']]={k:change[k] for k in ('Address','Before','After','Reason')}
result={'CatalogBlocks':coverage,'Methodology':methodology,'Edits':list(edits.values()),'Unmatched':unmatched}
(HERE/'HelpEdits.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'CatalogBlocks':len(coverage),'ChangedCells':len(edits),'MethodologyParagraphs':len(methodology),'Unmatched':unmatched},ensure_ascii=False))
assert not unmatched,'Every displayed changed paragraph must map to its actual cells.'
