"""Inventory all native help links and exact top-level outline groups, without Excel."""
from pathlib import Path
import collections, hashlib, json, re, sys, zipfile, xml.etree.ElementTree as E
p = Path(__file__).resolve().parent
book = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else p/'NativeHelpNewType.xlsm'
n = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
with zipfile.ZipFile(book) as z:
    strings = [''.join(x.itertext()) for x in E.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',n)]
    wb = E.fromstring(z.read('xl/workbook.xml'))
    rels = {x.get('Id'):x.get('Target').lstrip('/') for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    sheets = {}
    for s in wb.find('s:sheets',n):
        target = rels[s.get('{'+n['r']+'}id')]
        if not target.startswith('xl/'): target = 'xl/'+target
        sheets[s.get('name')] = E.fromstring(z.read(target))
    help_sheet = sheets['Справка']
    rows = {int(x.get('r')):x for x in help_sheet.findall('.//s:row',n)}
    cells = {x.get('r'):x for x in help_sheet.findall('.//s:c',n)}
    def level(row): return int(rows[row].get('outlineLevel','0'))
    def text(address):
        c = cells.get(address)
        if c is None: return ''
        if c.get('t') == 'inlineStr': return ''.join(c.find('s:is',n).itertext())
        v = c.find('s:v',n)
        if v is None: return ''
        return strings[int(v.text)] if c.get('t') == 's' else v.text
    groups = []
    for row in sorted(rows):
        if level(row) or row+1 not in rows or level(row+1) == 0: continue
        end = row+1
        while end in rows and level(end)>0: end += 1
        groups.append({'HeaderRow':row,'FirstRow':row+1,'LastRow':end-1,'Title':text('A'+str(row)),'NestedRows':[r for r in range(row+1,end) if level(r)>1]})
    links = []; ungrouped_targets=[]
    for name,sheet in sheets.items():
        for h in sheet.findall('s:hyperlinks/s:hyperlink',n):
            target = h.get('location','')
            match = re.fullmatch(r"'?Справка'?!(\$?[A-Z]+)\$?(\d+)",target,re.I)
            if not match: continue
            row = int(match.group(2))
            group = next((g for g in groups if g['HeaderRow']<=row<=g['LastRow']),None)
            if group is None:
                ungrouped_targets.append({'SourceSheet':name,'SourceAddress':h.get('ref'),'Target':target})
                group=max((g for g in groups if g['HeaderRow']<=row),key=lambda g:g['HeaderRow'])
            letters = match.group(1).replace('$',''); column=0
            for char in letters: column=column*26+ord(char)-64
            links.append({'SourceSheet':name,'SourceAddress':h.get('ref'),'SubAddress':target,'TargetRow':row,'TargetColumn':column,'SectionHeaderRow':group['HeaderRow']})
result = {'InventorySource':book.name,'InventorySourceSHA256':hashlib.sha256(book.read_bytes()).hexdigest().upper(),'SectionCount':len(groups),'Sections':groups,'UngroupedTargets':ungrouped_targets,'LinkCount':len(links),'LinkCountBySource':dict(collections.Counter(h['SourceSheet'] for h in links)),'UniqueTargets':len(set(h['SubAddress'] for h in links)),'Links':links,'ExecutionPlan':{'NativeExcel':True,'WorkbookOpenEvents':True,'ReadOnly':True,'Save':False,'NDS':False,'OutlineButtonCyclesPerSection':1,'HyperlinkCyclesPerLink':2,'HiddenCheck':'All rows of the complete top-level section, including nested groups; mixed Hidden is a failure.','SiblingSections':'Must remain collapsed after expanding the target section.','Viewport':'ActiveSheet, ActiveCell row/column, ScrollRow == target row, ScrollColumn == 1.'}}
(p/'HelpNavigationPlan.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ('Links','Sections','ExecutionPlan')},ensure_ascii=False))
