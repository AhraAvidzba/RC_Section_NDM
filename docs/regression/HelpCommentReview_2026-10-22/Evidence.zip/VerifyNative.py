"""Проверяет фактический VBA приватной скомпилированной книги против актуальных исходников."""
from pathlib import Path
from decimal import Decimal
from importlib import import_module
import hashlib
import json
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = 'be0a27f195370bdf3069af1ba320f2681d5327b4'
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, str(ROOT / 'tools/build_workbook'))
audit = import_module('Audit-VbaDocumentation')
LITERAL = re.compile(r'"(?:[^"\n]|"")*"')
NUMBER_TEXT = r'(?<![\w.])(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+-]?\d+)?[#@!%&^]?(?![\w.])'
LEXICAL = re.compile(r'"(?:[^"\n]|"")*"|' + NUMBER_TEXT)
NUMBER = re.compile(NUMBER_TEXT)

# Это закрытый список полных операторов, подтвержденных прежним native-экспортом.
# Особенно важно не округлять произвольные литералы до 15 значащих цифр.
RULES = {
    'CLoadPathMath': [(
        'roundoff = 0.000000001 + 0.00000000000000177635683940025 * (Abs(moment) + Abs(transfer))',
        'roundoff = 0.000000001 + 1.77635683940025E-15 * (Abs(moment) + Abs(transfer))')],
    'CLinearSystem3x3': [(
        'If mRelativeResidual > 1E-8 Then', 'If mRelativeResidual > 0.00000001 Then')],
    'modNonlinearStepControl': [(
        'Private Const SIGNIFICANT_REDUCTION As Double = 0.000000000000007105427357601',
        'Private Const SIGNIFICANT_REDUCTION As Double = 7.105427357601E-15')],
    'CLoadMultiplierSearch': [(
        'If Abs(value) > 1.797693134862315E+308 Then Exit Function',
        'If Abs(value) > 1.79769313486231E+308 Then Exit Function')],
    'CUltimateStrainSearch': [(
        'If Abs(value) > 1.797693134862315E+308 Then Exit Function',
        'If Abs(value) > 1.79769313486231E+308 Then Exit Function')],
    'CCrackFormationCalculator': [(
        'If mLambdaTolerance > 0# And mLambdaTolerance <= 1.797693134862315E+308 Then Exit Sub',
        'If mLambdaTolerance > 0# And mLambdaTolerance <= 1.79769313486231E+308 Then Exit Sub')],
    'CStabilityCalculator': [(
        'If squaredLength <> squaredLength Or squaredLength > 1.797693134862315E+308 Then GoTo RangeFailed',
        'If squaredLength <> squaredLength Or squaredLength > 1.79769313486231E+308 Then GoTo RangeFailed')],
}


def components(text):
    """Разбирает штатный экспорт CodeModule; служебные заголовки не входят в VBA."""
    result = {}
    for part in re.split(r'(?m)^={100}\nCOMPONENT: ', text.replace('\r\n', '\n'))[1:]:
        head, body = part.split('=' * 100 + '\n', 1)
        name = head.splitlines()[0]
        assert name not in result, ('duplicate component', name)
        result[name] = body.rstrip()
    return result


def strip_redundant_double_suffix(code):
    """У дробного Double литерал без # имеет тот же тип; строки и целые 1# сохраняются."""
    def replace(match):
        value = match.group()
        if not value.startswith('"') and value.endswith('#') and '.' in value:
            return value[:-1]
        return value
    return LEXICAL.sub(replace, code)


def code_line(line):
    """Отделяет комментарий: VBE может добавить перед ним пробел, но его текст проверяется отдельно."""
    return strip_redundant_double_suffix(audit.split_comment(line)[0]).rstrip()


def canon(text, module=''):
    """Допускает регистр VBE и только проверенные числовые написания в известных операторах."""
    replacements = {left.casefold(): right.casefold() for left, right in RULES.get(module, [])}
    lines = []
    for line in text.strip().splitlines():
        code = code_line(line).casefold()
        statement = code.strip()
        if statement in replacements:
            code = code[:len(code) - len(code.lstrip())] + replacements[statement]
        lines.append(code)
    return '\n'.join(lines)


def source_body(text, module):
    if module == 'modSectionRecipeApiGuide':
        return '\n'.join(line for line in text.splitlines() if not line.startswith('Attribute ')).strip()
    return re.search(r'(?ms)^Option Explicit.*', text).group().rstrip()


def numeric_evidence(files, native):
    """Фиксирует каждую разрешенную пару вместе с прежним исходником и прежним фактическим VBA."""
    old_export = subprocess.check_output(['git', 'show', BASE + ':workbook/output/VBA_All_Code.txt'], cwd=ROOT)
    old_native = components(old_export.decode('utf-8-sig'))
    records = []
    for module, pairs in RULES.items():
        path = next(path for path in files if path.stem == module)
        relative = path.relative_to(ROOT).as_posix()
        old_source = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT).decode('utf-8-sig')
        source = path.read_text(encoding='utf-8-sig')
        def statements(text):
            return [code_line(line).strip().casefold() for line in text.splitlines()]
        for left, right in pairs:
            a, b = left.casefold(), right.casefold()
            for label, text, statement in (
                ('baseline source', old_source, a), ('current source', source, a),
                ('baseline native', old_native[module], b), ('current native', native[module], b)):
                assert statements(text).count(statement) == 1, (module, label, statement)
            old_numbers = NUMBER.findall(left)
            new_numbers = NUMBER.findall(right)
            assert len(old_numbers) == len(new_numbers)
            differences = []
            for old, new in zip(old_numbers, new_numbers):
                if old == new:
                    continue
                equal = Decimal(old.rstrip('#')) == Decimal(new.rstrip('#'))
                differences.append({'Source': old, 'Native': new, 'ExactlyEqualDecimal': equal})
            assert len(differences) == 1
            assert differences[0]['ExactlyEqualDecimal'] or (
                differences[0]['Source'] == '1.797693134862315E+308' and
                differences[0]['Native'] == '1.79769313486231E+308')
            records.append({'Module': module, 'SourceStatement': left, 'NativeStatement': right,
                            'NumericDifference': differences[0], 'BaselineSourceAndNativePairExact': True,
                            'CurrentSourceAndNativePairExact': True,
                            'NoNewNumericBehaviorChangeRelativeToPublishedBaseline': True})
    checks = {
        'KnownPairAccepted': all(canon(left, module) == canon(right, module)
                                 for module, pairs in RULES.items() for left, right in pairs),
        'UnknownContextRejected': canon('x = 1.797693134862315E+308', 'CStabilityCalculator') !=
                                  canon('x = 1.79769313486231E+308', 'CStabilityCalculator'),
        'OtherModuleRejected': canon(RULES['CStabilityCalculator'][0][0], 'Unrelated') !=
                               canon(RULES['CStabilityCalculator'][0][1], 'Unrelated'),
        'PerturbedNumberRejected': canon('If mRelativeResidual > 1E-8 Then', 'CLinearSystem3x3') !=
                                   canon('If mRelativeResidual > 0.00000001000001 Then', 'CLinearSystem3x3'),
        'IntegerDoubleMarkerPreserved': canon('x = 1#') != canon('x = 1'),
        'NumericTextInsideStringPreserved': canon('x = "1.25#"') != canon('x = "1.25"'),
        'EquivalentFractionalDoubleMarkerAccepted': canon('x = 1.25#') == canon('x = 1.25'),
    }
    assert all(checks.values()), checks
    report = {'Passed': True, 'Baseline': BASE, 'BaselineNativePath': 'workbook/output/VBA_All_Code.txt',
              'BaselineNativeSHA256': hashlib.sha256(old_export).hexdigest().upper(),
              'RuleCount': len(records), 'ExactDecimalSpellingChanges': 3,
              'PreviouslyExistingVbe15DigitMaxDoubleSpellings': 4,
              'NoGeneralRoundingTolerance': True, 'NumericSourceFilesChanged': False,
              'MaxDoubleCaveat': 'Два десятичных написания maxDouble не равны. Разрешена только прежняя '
                                 'пара source/native в тех же четырех операторах, уже сохраненная в baseline; '
                                 'новое числовое поведение относительно опубликованной книги не вводится.',
              'Records': records, 'NegativeControls': checks}
    (HERE / 'VbeNumericCanonicalization.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return report


def main():
    native = components((HERE / 'NativeVBA.txt').read_text(encoding='utf-8-sig'))
    files = sorted(path for directory in ('src', 'tests') for path in (ROOT / directory).rglob('*')
                   if path.suffix in ('.cls', '.bas'))
    numeric = numeric_evidence(files, native)
    if '--numeric-report-only' in sys.argv:
        print(json.dumps({'NumericEvidencePassed': numeric['Passed'], 'Rules': numeric['RuleCount']}, ensure_ascii=False))
        return
    checks = []
    for path in files:
        body = source_body(path.read_text(encoding='utf-8-sig'), path.stem)
        actual = native[path.stem]
        assert canon(body, path.stem) == canon(actual, path.stem), path.stem
        # Регистр идентификаторов разрешен; текст комментариев и литералов сравнивается точно.
        comments = lambda text: [audit.split_comment(line)[1] for line in text.splitlines() if audit.split_comment(line)[1]]
        assert comments(body) == comments(actual), ('comments', path.stem)
        strings = lambda text: [literal for line in text.splitlines() for literal in LITERAL.findall(audit.split_comment(line)[0])]
        assert strings(body) == strings(actual), ('strings', path.stem)
        checks.append(path.stem)
    events = (ROOT / 'tools/build_workbook/WorkbookHelpEvents.vba').read_text(encoding='utf-8-sig')
    documents = [name for name, body in native.items() if 'Private Sub Workbook_Open()' in body]
    assert len(documents) == 1 and canon(events) == canon(native[documents[0]])
    assert len(native) == 169
    retired = ['CFakeAcadContour', 'CFakeAcadContourExport', 'CFakeAcadDocument', 'CFakeAcadLine', 'CFakeAcadRegion',
               'CLinearConcreteMaterial', 'CLinearSteelMaterial']
    assert not set(retired) & native.keys()
    assert {'CTestFakeAcadContour', 'CTestFakeAcadContourExport', 'CTestFakeAcadDocument', 'CTestFakeAcadLine',
            'CTestFakeAcadRegion', 'CTestLinearConcreteMaterial', 'CTestLinearSteelMaterial'} <= native.keys()
    result = {'Passed': True, 'Components': len(native), 'SourceModulesChecked': len(checks), 'WorkbookEventsChecked': True,
              'CommentUnicodeExact': True, 'StringLiteralsExact': True, 'RetiredComponentsAbsent': retired,
              'NumericCanonicalizationEvidence': 'VbeNumericCanonicalization.json',
              'NoGeneralNumericRounding': True,
              'AllCodeSHA256': hashlib.sha256((HERE / 'NativeVBA.txt').read_bytes()).hexdigest().upper()}
    (HERE / 'NativeSourceEquality.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()

