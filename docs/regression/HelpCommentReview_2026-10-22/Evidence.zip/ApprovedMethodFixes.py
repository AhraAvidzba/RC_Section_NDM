"""ДЛЯ ТЕСТОВ: разрешает только точные вставки в трех исправлениях и одном новом runner."""
from pathlib import Path
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
EXPECTED = {
    ('tests/modTestCapacitySolver.bas', 'TestLoadMultiplierWithWorkbookTfDefaults'),
    ('src/Section/CSectionGeometryQuery.cls', 'RequireOffsetCorner'),
    ('tests/modTestRecipeApiCatalogue.bas', 'TestRunApiGeometryReadExamples'),
    ('tests/modTestCapacitySolver.bas', 'RunWorkbookTfFixtureTests'),
}


def tokens_sha256(tokens):
    return hashlib.sha256(json.dumps(tokens, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest().upper()


class ApprovedFixes:
    """Проверяет before/after целого метода и убирает только задокументированные точные вставки."""
    def __init__(self, spans, tokenize):
        self.data = json.loads((HERE / 'ApprovedMethodFixes.json').read_text(encoding='utf-8'))
        self.records = self.data['Records']
        assert {(item['File'], item['Method']) for item in self.records} == EXPECTED
        assert len(self.records) == 4
        self.lookup = {(item['File'], alias.casefold()): item for item in self.records for alias in item['Aliases']}
        self.seen = set()
        self.spans, self.tokenize = spans, tokenize
        archive_path = HERE / self.data['BeforeReference']
        assert hashlib.sha256(archive_path.read_bytes()).hexdigest().upper() == self.data['BeforeReferenceSHA256']
        with zipfile.ZipFile(archive_path) as archive:
            for item in self.records:
                text = archive.read(item['File']).decode('utf-8-sig')
                bodies = [text[start:end] for start, end, name in spans(text) if name == item['Method']]
                assert len(bodies) == (0 if item['AddedProcedure'] else 1), item['Method']
                before = tokenize(bodies[0]) if bodies else []
                assert tokens_sha256(before) == item['BeforeExecutableTokensSHA256']
                assert item['OriginalTokensAllPreserved']
                assert all(part['Tokens'] for part in item['Insertions'])

    def is_addition(self, path, name):
        item = self.lookup.get((str(path).replace('\\', '/'), name.casefold()))
        return item is not None and item['AddedProcedure']

    def restore_tokens(self, path, name, tokens):
        item = self.lookup.get((str(path).replace('\\', '/'), name.casefold()))
        if item is None:
            return tokens
        assert tokens_sha256(tokens) == item['AfterExecutableTokensSHA256'], ('Unapproved method change', path, name)
        result = tokens[:]
        for part in reversed(item['Insertions']):
            index, inserted = part['AfterTokenIndex'], part['Tokens']
            assert result[index:index + len(inserted)] == inserted, (path, name, index)
            del result[index:index + len(inserted)]
        assert tokens_sha256(result) == item['BeforeExecutableTokensSHA256'], (path, name, 'before tokens')
        self.seen.add((item['File'], item['Method']))
        return result

    def module_tokens(self, path, text):
        result, last = [], 0
        for start, end, name in self.spans(text):
            result += self.tokenize(text[last:start])
            result += self.restore_tokens(path, name, self.tokenize(text[start:end]))
            last = end
        return result + self.tokenize(text[last:])

    def finish(self):
        assert self.seen == EXPECTED, ('Approved fix not checked', EXPECTED - self.seen)
        return [{'File': item['File'], 'Method': item['Method'], 'AddedProcedure': item['AddedProcedure'],
                 'BeforeExecutableTokensSHA256': item['BeforeExecutableTokensSHA256'],
                 'AfterExecutableTokensSHA256': item['AfterExecutableTokensSHA256'],
                 'OriginalTokensAllPreserved': True, 'Reason': item['Reason']} for item in self.records]
