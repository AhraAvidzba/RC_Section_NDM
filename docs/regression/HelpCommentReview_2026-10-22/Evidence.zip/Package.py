"""Публикует только справку и скомпилированный VBA, сохраняя пользовательские таблицы и рисунки."""
from copy import deepcopy
from pathlib import Path
from zipfile import ZipFile
import argparse,hashlib,json,sys
from lxml import etree as E
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
S='{'+NS['s']+'}'
read=lambda name:json.loads((HERE/name).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
def book(path):
 with ZipFile(path) as z:parts={i.filename:z.read(i) for i in z.infolist()}
 wb=E.fromstring(parts['xl/workbook.xml']);rels={r.get('Id'):r.get('Target') for r in E.fromstring(parts['xl/_rels/workbook.xml.rels'])}
 sheets={s.get('name'):'xl/'+rels[s.get('{'+NS['r']+'}id')] for s in wb.find('s:sheets',NS)}
 strings=[''.join(e.itertext()) for e in E.fromstring(parts['xl/sharedStrings.xml'])]
 return parts,sheets,strings
def values(doc,strings):
 result={}
 for c in doc.findall('s:sheetData/s:row/s:c',NS):
  v=c.find('s:v',NS)
  result[c.get('r')]=''.join(c.find('s:is',NS).itertext()) if c.get('t')=='inlineStr' else strings[int(v.text)] if c.get('t')=='s' and v is not None else v.text if v is not None else ''
 return result
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--verify',type=Path);args=parser.parse_args()
 baseline=HERE/'Baseline.xlsm';meta=read('Before.json');assert sha(baseline.read_bytes())==meta['WorkbookSHA256']
 old,sheets,strings=book(baseline);part=sheets['Справка'];original=E.fromstring(old[part]);doc=deepcopy(original)
 old_values=values(original,strings);cells={c.get('r'):c for c in doc.findall('s:sheetData/s:row/s:c',NS)}
 edits=read('HelpEdits.json')['Edits']+read('NewTypeHelpEdits.json')['Edits'];native=read('HelpNativeEdit.json');new_type=read('NewTypeNativeEdit.json')
 # Native measurements are read independently of the private Excel save's other package changes.
 heights={**native['Heights'],**new_type['Heights'],**read('DedupNativeEdit.json')['Heights']}
 blank_rows={str(r) for r in new_type['BlankWhiteRows']}|{str(r['Row']) for r in read('DedupBlankRows.json')['Rows']}
 for row in blank_rows:heights[row]=2.5
 assert len({e['Address'] for e in edits})==len(edits)
 for edit in edits:
  a=edit['Address'];assert old_values.get(a,'')==edit['Before'],a
  c=cells[a]
  for child in list(c):c.remove(child)
  c.set('t','inlineStr');E.SubElement(E.SubElement(c,S+'is'),S+'t').text=edit['After']
 for row,height in heights.items():
  target=doc.find(f's:sheetData/s:row[@r="{row}"]',NS)
  assert target is not None,row
  target.set('ht',format(height,'.12g'));target.set('customHeight','1')
 # A previously appended setting escaped the last outline group. Use the same
 # title-to-content boundary as Set-HelpSectionOrderAndOutline in the full build.
 config_titles=[a for a,v in old_values.items() if v=='Справка по настройкам Config и листа «Сечения»']
 assert len(config_titles)==1
 config_start=int(''.join(filter(str.isdigit,config_titles[0])))
 content_last=max(int(''.join(filter(str.isdigit,a))) for a,v in old_values.items() if v)
 outline_rows=[]
 for row in range(config_start+1,content_last+1):
  target=doc.find(f's:sheetData/s:row[@r="{row}"]',NS)
  assert target is not None,row
  if target.get('outlineLevel')!='1':target.set('outlineLevel','1');outline_rows.append(str(row))
 # Append style variants for compact blank lines; never alter any existing user style.
 styles=E.fromstring(old['xl/styles.xml']);original_styles=deepcopy(styles)
 fills=styles.find('s:fills',NS);xfs=styles.find('s:cellXfs',NS)
 white_fill=E.Element(S+'fill');pattern=E.SubElement(white_fill,S+'patternFill',patternType='solid')
 E.SubElement(pattern,S+'fgColor',rgb='FFFFFFFF');E.SubElement(pattern,S+'bgColor',indexed='64')
 white_id=next((i for i,f in enumerate(fills) if E.tostring(f,method='c14n')==E.tostring(white_fill,method='c14n')),None)
 if white_id is None:white_id=len(fills);fills.append(white_fill);fills.set('count',str(len(fills)))
 style_variants={};style_cells=[]
 for row in sorted(blank_rows,key=int):
  for col in 'ABCDEF':
   a=col+row;c=cells[a];old_id=int(c.get('s','0'))
   if old_id not in style_variants:
    variant=deepcopy(xfs[old_id]);variant.set('fillId',str(white_id));variant.set('applyFill','1')
    existing=next((i for i,xf in enumerate(xfs) if E.tostring(xf,method='c14n')==E.tostring(variant,method='c14n')),None)
    if existing is None:existing=len(xfs);xfs.append(variant);xfs.set('count',str(len(xfs)))
    style_variants[old_id]=existing
   c.set('s',str(style_variants[old_id]));style_cells.append(a)
 new=dict(old);new[part]=E.tostring(doc,encoding='UTF-8',xml_declaration=True,standalone=True)
 new['xl/styles.xml']=E.tostring(styles,encoding='UTF-8',xml_declaration=True,standalone=True)
 with ZipFile(HERE/'CompiledCandidate.xlsm') as z:new['xl/vbaProject.bin']=z.read('xl/vbaProject.bin')
 target=args.verify or HERE/'FinalRelease/RC_Section_NDM.xlsm'
 if not args.verify:
  target.parent.mkdir(exist_ok=True)
  with ZipFile(baseline) as src,ZipFile(target,'w') as dst:
   for info in src.infolist():dst.writestr(info,new[info.filename])
 actual,actual_sheets,actual_strings=book(target)
 assert actual.keys()==old.keys()
 changed=[p for p in old if old[p]!=actual[p]]
 assert set(changed)=={part,'xl/styles.xml','xl/vbaProject.bin'},changed
 assert actual==new
 after_doc=E.fromstring(actual[part]);after_values=values(after_doc,actual_strings)
 expected={e['Address']:e['After'] for e in edits}
 assert after_values.keys()==old_values.keys()
 for a,v in old_values.items():assert after_values[a]==expected.get(a,v),a
 # Restore permitted help-cell/height edits: all other help XML must be canonically identical.
 restored=deepcopy(after_doc);rc={c.get('r'):c for c in restored.findall('s:sheetData/s:row/s:c',NS)}
 oc={c.get('r'):c for c in original.findall('s:sheetData/s:row/s:c',NS)}
 for a in set(expected)|set(style_cells):rc[a].getparent().replace(rc[a],deepcopy(oc[a]))
 for row in set(heights)|set(outline_rows):
  rr=restored.find(f's:sheetData/s:row[@r="{row}"]',NS);oo=original.find(f's:sheetData/s:row[@r="{row}"]',NS)
  rr.attrib.clear();rr.attrib.update(oo.attrib)
 assert E.tostring(restored,method='c14n')==E.tostring(original,method='c14n')
 restored_styles=deepcopy(styles)
 for tag in ('fills','cellXfs'):
  current=restored_styles.find('s:'+tag,NS);before=original_styles.find('s:'+tag,NS)
  for node in list(current)[len(before):]:current.remove(node)
  current.attrib.clear();current.attrib.update(before.attrib)
 assert E.tostring(restored_styles,method='c14n')==E.tostring(original_styles,method='c14n')
 result={'Passed':True,'WorkbookSHA256':sha(target.read_bytes()),'BaselineSHA256':meta['WorkbookSHA256'],
         'ChangedParts':changed,'UnchangedParts':len(old)-len(changed),'ChangedHelpCells':len(edits),
         'AllUserInputsResultsExistingStylesGraphicsAndHyperlinksPreserved':True,
         'BlankHelpRowsWhitened':len(blank_rows),'AppendedStyleVariants':style_variants,
         'ChangedHelpRowHeights':len(heights),
         'RepairedOutlineRows':[int(r) for r in outline_rows],
         'ConfigHelpBody':[config_start+1,content_last],
         'CompiledVbaSHA256':sha(actual['xl/vbaProject.bin'])}
 (HERE/('PublishedVerification.json' if args.verify else 'Acceptance.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 if not args.verify:
  path=ROOT/'tools/build_workbook/WorkbookLayout.json';layout=json.loads(path.read_text(encoding='utf-8-sig'))
  sheet=next(s for s in layout['Sheets'] if s['Name']=='Справка');rows={str(r['Row']):r for r in sheet['Rows']}
  for row,height in heights.items():
   if row in rows:rows[row]['Height']=height
   else:
    original_row=doc.find(f's:sheetData/s:row[@r="{row}"]',NS)
    sheet['Rows'].append({'Row':int(row),'Height':height,'Hidden':original_row.get('hidden')=='1'})
  sheet['Rows'].sort(key=lambda r:r['Row'])
  path.write_text(json.dumps(layout,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
