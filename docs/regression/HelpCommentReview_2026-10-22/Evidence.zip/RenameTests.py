"""ДЛЯ ТЕСТОВ: согласованное переименование тестовых символов с журналом каждой замены."""
from pathlib import Path
import argparse, hashlib, json, re, subprocess, sys, zipfile
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/build_workbook'))
from importlib import import_module
audit=import_module('Audit-VbaDocumentation')
METHOD=audit.METHOD
LEX=re.compile(r'"(?:[^"\r\n]|"")*"|\'[^\r\n]*|\bRem(?=\s|$)[^\r\n]*|[A-Za-z_А-Яа-яЁё][A-Za-z_А-Яа-яЁё0-9]*|\s+|.',re.M|re.I)
IDENT=re.compile(r'^[A-Za-z_А-Яа-яЁё][A-Za-z_А-Яа-яЁё0-9]*$')
CLASSES={'CFakeAcadContour':'CTestFakeAcadContour','CFakeAcadContourExport':'CTestFakeAcadContourExport',
         'CFakeAcadDocument':'CTestFakeAcadDocument','CFakeAcadLine':'CTestFakeAcadLine',
         'CFakeAcadRegion':'CTestFakeAcadRegion','CLinearConcreteMaterial':'CTestLinearConcreteMaterial',
         'CLinearSteelMaterial':'CTestLinearSteelMaterial','modFinalGeometryChecks':'modTestFinalGeometryChecks'}
CONTRACTS={
 'CFakeAcadContour':set('Document GetXData ObjectName Layer Handle Closed Elevation Normal StartPoint EndPoint Center Radius TotalAngle Copy Explode Delete'.split()),
 'CFakeAcadContourExport':set('AddLightWeightPolyline AddRegion Area ObjectName Count Item Layer Color Closed Coordinates SetBulge Update Delete Document RegisteredApplications SetXData GetXData'.split()),
 'CFakeAcadDocument':set('GetVariable ModelSpace Layers'.split()),
 'CFakeAcadLine':set('ObjectName StartPoint EndPoint Delete Layer'.split()),
 'CFakeAcadRegion':set('ObjectName Layer Handle Area Centroid MomentOfInertia ProductOfInertia Copy Explode Delete'.split()),
 'CTestExcelApplicationState':set('EnableCancelKey ScreenUpdating EnableEvents DisplayAlerts Calculation'.split()),
 'CLinearConcreteMaterial':set('GetStress GetTangentModulus GetSecantModulus'.split()),
 'CLinearSteelMaterial':set('GetStress GetTangentModulus GetSecantModulus'.split())}
TEST_CLASS=set(CONTRACTS)|{'CTestLimitSearchProblem'}
DISPLAY_LITERALS={('"Единица вывода '+name+' на момент импорта."'):('"Единица вывода '+name+' на момент формирования сечения."') for name in ('длины','площади','напряжения','кривизны')}
# CreatedEntities — тестовая коллекция однородных созданных объектов. Тип её
# элемента известен из AddLightWeightPolyline/AddRegion, хотя Collection.Item
# возвращает Object. Другие коллекции и обязательные имена AutoCAD не меняются.
INDEXED_COLLECTION_ELEMENTS={
 ('cfakeacadcontourexport','createdentities'):'CFakeAcadContourExport',
 ('ctestfakeacadcontourexport','testcreatedentities'):'CFakeAcadContourExport',
}
def files():
 return sorted(p for d in ('src','tests','docs/geometry_refactor/examples') for p in (ROOT/d).rglob('*') if p.suffix in ('.cls','.bas'))
def spans(text):
 lines=text.splitlines(keepends=True); result=[];active=None;offset=0
 for line in lines:
  m=METHOD.match(line)
  if m: active=(offset,m[2])
  if active and re.search(r'(?:^|:)\s*End\s+(Sub|Function|Property)\b',audit.split_comment(line)[0],re.I):
   result.append((active[0],offset+len(line),active[1]));active=None
  offset+=len(line)
 return result
def build_plan():
 modules={}; exceptions=[];public={}; returns={}
 for p in files():
  text=p.read_text(encoding='utf-8-sig');name=p.stem;info=audit.inspect(p);selected={}
  all_test=p.parent.name=='tests' or name in TEST_CLASS or name.startswith('modTest') or name=='modFinalGeometryChecks'
  for m in info['Methods']:
   old=m['Name']; contract=old.startswith('Class_') or old.startswith('ILimitSearchProblem_') or old in CONTRACTS.get(name,set())
   if all_test and contract:
    exceptions.append({'Module':name,'Method':old,'Reason':'Обязательное имя события VBA, рабочего интерфейса либо внешнего COM API; класс явно тестовый.'})
   elif (all_test or m['TestMarker']) and 'Test' not in old:
    candidate='Test'+old
    existing={m['Name'].casefold() for m in info['Methods']}
    if candidate.casefold() in existing:candidate='TestHelper'+old
    selected[old]=candidate
  existing={m['Name'].casefold() for m in info['Methods']}
  assert not any(new.casefold() in existing for new in selected.values()),(name,'collision')
  modules[name]=selected
  pending='';logical=[]
  for line in text.splitlines():
   line=audit.split_comment(line)[0]
   pending+=line.strip()
   if pending.endswith(' _'):pending=pending[:-2]+' ';continue
   logical.append(pending);pending=''
  for line in logical:
   m=METHOD.match(line)
   if m:
    tail=re.search(r'\)\s+As\s+(\w+)',line,re.I)
    if tail: returns[(name.casefold(),m[2].casefold())]=tail[1]
    if re.match(r'\s*Public\s+(Function|Sub|Property)',line,re.I) and p.suffix=='.bas' and m[2] in selected:
     old=m[2].casefold();assert old not in public or public[old]==selected[m[2]],(old,name)
     public[old]=selected[m[2]]
 # A fixture factory declared Object can still return a known fake class.
 for _ in range(4):
  for p in files():
   text=p.read_text(encoding='utf-8-sig')
   for start,end,method in spans(text):
    body=audit.executable(text[start:end]);types=declared_types(body)
    declared=returns.get((p.stem.casefold(),method.casefold()))
    if declared and declared.casefold() not in ('object','variant'):continue
    for m in re.finditer(r'(?im)\bSet\s+(\w+)\s*=\s*New\s+(\w+)',body):types[m[1].casefold()]=m[2]
    for m in re.finditer(r'(?im)\bSet\s+'+re.escape(method)+r'\s*=\s*(?:New\s+)?(\w+)\b(?:\s*\.\s*(\w+))?',body):
     kind=types.get(m[1].casefold()) or returns.get((p.stem.casefold(),m[1].casefold()))
     if m[2]:kind=returns.get(((kind or '').casefold(),m[2].casefold()))
     if m[1] in modules:kind=m[1]
     if kind and kind.casefold() not in ('object','variant'):returns[(p.stem.casefold(),method.casefold())]=kind
 return modules,exceptions,public,returns
def declared_types(text):
 # A procedure's parameter list must not consume its individual ByVal/ByRef declarations.
 text=''.join((' '*len(m.group()) if m.group().startswith(('"',"'")) or re.match(r'^Rem(?:\s|$)',m.group(),re.I) else m.group()) for m in LEX.finditer(text))
 return {m[1].casefold():m[2] for m in re.finditer(r'\b(\w+)(?:\((?![^()\r\n]*\b(?:ByVal|ByRef|Optional|As)\b)[^()\r\n]*\))?\s+As\s+(?:New\s+)?(\w+)',text,re.I)}
def transform_scope(text,module,own,all_maps,public,returns,global_types,unique_members,unresolved):
 tokens=list(LEX.finditer(text));vals=[m.group() for m in tokens]
 sig=[i for i,v in enumerate(vals) if not v.isspace() and not v.startswith("'") and not re.match(r'^Rem(?:\s|$)',v,re.I)]
 local=declared_types(audit.executable(text));method=METHOD.match(text)[2];local.pop(method.casefold(),None)
 positions={i:n for n,i in enumerate(sig)};types=dict(global_types);types.update(local)
 for m in re.finditer(r'(?im)\bSet\s+(\w+)\s*=\s*New\s+(\w+)',audit.executable(text)): types[m[1].casefold()]=m[2]
 # A variable declared Object can receive a typed fixture factory's result.
 for _ in range(3):
  for m in re.finditer(r'(?im)\bSet\s+(\w+)\s*=\s*(\w+)(?:\s*\.|\s*\()',audit.executable(text)):
   if types.get(m[1].casefold(),'').casefold() not in ('','object','variant'):continue
   key=(module.casefold(),m[2].casefold())
   if key in returns: types[m[1].casefold()]=returns[key]
  for m in re.finditer(r'(?im)\bSet\s+(\w+)\s*=\s*(\w+)\s*(?:\(|$)',audit.executable(text)):
   if types.get(m[1].casefold(),'').casefold() not in ('','object','variant'):continue
   kind=types.get(m[2].casefold()) or returns.get((module.casefold(),m[2].casefold()))
   if kind and kind.casefold() not in ('object','variant'):types[m[1].casefold()]=kind
 def previous(i):
  n=positions.get(i,-1);return sig[n-1] if n>0 else None
 def infer(end,depth=0):
  if end is None or depth>8:return None
  value=vals[end]
  if value==')':
   n=positions[end];level=1
   while n>0:
    n-=1
    if vals[sig[n]]==')':level+=1
    elif vals[sig[n]]=='(':
     level-=1
     if level==0:
      receiver=sig[n-1] if n>0 else None
      kind=infer(receiver,depth+1)
      dot=previous(receiver) if receiver is not None else None
      if kind and kind.casefold()=='collection' and dot is not None and vals[dot]=='.':
       owner=infer(previous(dot),depth+1)
       kind=INDEXED_COLLECTION_ELEMENTS.get(((owner or '').casefold(),vals[receiver].casefold()),kind)
      return kind
   return None
  if not IDENT.fullmatch(value):return None
  prev=previous(end)
  if prev is not None and vals[prev]=='.':
   owner=infer(previous(prev),depth+1)
   return returns.get(((owner or '').casefold(),value.casefold()))
  if value.casefold()=='me':return module
  return types.get(value.casefold()) or (value if value.casefold() in all_maps else None) or returns.get((module.casefold(),value.casefold()))
 changed=[];with_types=[];line_start=0
 for i,match in enumerate(tokens):
  value=vals[i];new=None
  if value.isspace():
   if '\n' in value:line_start=i+1
   continue
  if value.startswith("'") or re.match(r'^Rem(?:\s|$)',value,re.I):continue
  # Track With's receiver for unqualified dotted members.
  if value.casefold()=='with' and i in positions:
   n=positions[i]
   if n and vals[sig[n-1]].casefold()=='end':
    if with_types:with_types.pop()
   else:
    line_end=next((j for j in sig[n+1:] if '\n' in text[match.end():tokens[j].start()]),None)
    line_tokens=[j for j in sig[n+1:] if line_end is None or j<line_end]
    with_types.append(infer(line_tokens[-1]) if line_tokens else None)
  if value.startswith('"'):
   new=value
   for old,renamed in CLASSES.items(): new=re.sub(r'\b'+re.escape(old)+r'\b',renamed,new)
   new=re.sub(r'\b(\w+)\.(\w+)\b',lambda m:m[1]+'.'+all_maps.get(next((old for old,renamed in CLASSES.items() if renamed.casefold()==m[1].casefold()),m[1]).casefold(),{}).get(m[2].casefold(),m[2]),new)
   # Exact macro-name literals used by Excel.Run or entrypoint instrumentation.
   if value[1:-1].casefold() in public:new='"'+public[value[1:-1].casefold()]+'"'
   elif value[1:-1].casefold() in unique_members:new='"'+unique_members[value[1:-1].casefold()]+'"'
  elif IDENT.fullmatch(value):
   if value in CLASSES:new=CLASSES[value]
   else:
    prev=previous(i)
    if prev is not None and vals[prev]=='.':
     before=previous(prev)
     leading=(vals[before]==':' or ('\n' in text[tokens[before].end():tokens[prev].start()] and vals[before]!='_')) if before is not None else True
     owner=with_types[-1] if leading and with_types else infer(before)
     new=all_maps.get((owner or '').casefold(),{}).get(value.casefold())
     if new is None and (owner is None or owner.casefold() in ('object','variant')):new=unique_members.get(value.casefold())
     if new is None and (owner is None or owner.casefold() in ('object','variant')) and any(value.casefold() in all_maps.get(cls.casefold(),{}) for cls in CLASS_MEMBER_MODULES):
      unresolved.append({'Module':module,'Method':method,'Member':value,'Line':text.count('\n',0,match.start())+1,'Statement':text[text.rfind('\n',0,match.start())+1:text.find('\n',match.start()) if '\n' in text[match.start():] else len(text)].strip()})
    elif value.casefold() not in local or value.casefold()==method.casefold():new=own.get(value.casefold()) or public.get(value.casefold())
  if new and new!=value: changed.append((match.start(),match.end(),value,new))
 out=text
 for start,end,old,new in reversed(changed):out=out[:start]+new+out[end:]
 return out,[{'Offset':a,'Old':c,'New':d} for a,b,c,d in changed]
def meaningful_tokens(text):
 return [m.group() for m in LEX.finditer(text) if not m.group().isspace() and not m.group().startswith("'") and not re.match(r'^Rem(?:\s|$)',m.group(),re.I)]

def prove_identifiers_only(before,after,modules,public,unique,display_literals=None):
 left=meaningful_tokens(before);right=meaningful_tokens(after)
 assert len(left)==len(right),('Token count changed',len(left),len(right))
 permitted={}
 for old,new in CLASSES.items():permitted.setdefault(old.casefold(),set()).add(new)
 for members in modules.values():
  for old,new in members.items():permitted.setdefault(old.casefold(),set()).add(new)
 differences=[]
 for index,(old,new) in enumerate(zip(left,right)):
  if old==new:continue
  if IDENT.fullmatch(old):assert new in permitted.get(old.casefold(),set()),(index,old,new)
  else:
   assert old.startswith('"') and new.startswith('"'),('Non-name executable token changed',index,old,new)
   # Strings are limited to actual class/method names, never arbitrary replacement text.
   expected=(display_literals or {}).get(old,old)
   for name,renamed in CLASSES.items():expected=re.sub(r'\b'+re.escape(name)+r'\b',renamed,expected)
   def qualified(m):
    original=next((name for name,renamed in CLASSES.items() if renamed.casefold()==m[1].casefold()),m[1])
    names={key.casefold():value for key,value in modules.get(original,{}).items()}
    return m[1]+'.'+names.get(m[2].casefold(),m[2])
   expected=re.sub(r'\b(\w+)\.(\w+)\b',qualified,expected)
   if old[1:-1].casefold() in public:expected='"'+public[old[1:-1].casefold()]+'"'
   elif old[1:-1].casefold() in unique:expected='"'+unique[old[1:-1].casefold()]+'"'
   assert new==expected,('Unapproved string change',index,old,new,expected)
  differences.append({'Token':index,'Old':old,'New':new})
 return {'Tokens':len(left),'RenamedTokens':len(differences),'AllOtherTokensExactlyUnchanged':True,'Differences':differences}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');args=parser.parse_args()
 modules,exceptions,public,returns=build_plan()
 maps={name.casefold():{k.casefold():v for k,v in members.items()} for name,members in modules.items()}
 non_test_members={m['Name'].casefold() for p in files() if p.parent.name!='tests' and p.stem not in TEST_CLASS for m in audit.inspect(p)['Methods'] if not m['TestMarker']}
 non_test_members|={v.casefold() for names in CONTRACTS.values() for v in names}
 global CLASS_MEMBER_MODULES
 CLASS_MEMBER_MODULES={p.stem for p in files() if p.suffix=='.cls' and modules.get(p.stem)}
 unique={old.casefold():new for cls in CLASS_MEMBER_MODULES for old,new in modules.get(cls,{}).items() if old.casefold() not in non_test_members}
 plan={'Classes':CLASSES,'Methods':{m:v for m,v in modules.items() if v},'ContractExceptions':exceptions,'Applied':args.apply,'ChangedFiles':[],'UnresolvedMembers':[]}
 previews={};originals={}
 class_pattern=re.compile(r'\b('+ '|'.join(map(re.escape,CLASSES))+r')\b')
 for p in files():
  data=p.read_bytes();text=data.decode('utf-8-sig');out='';last=0;replacements=[];unresolved=[]
  parts=spans(text);global_types=declared_types(text[:parts[0][0]] if parts else text)
  for start,end,name in parts:
   prefix=class_pattern.sub(lambda m:CLASSES[m[1]],text[last:start]);out+=prefix
   body,logs=transform_scope(text[start:end],p.stem,maps.get(p.stem.casefold(),{}),maps,public,returns,global_types,unique,unresolved)
   out+=body;replacements.extend({**e,'Offset':e['Offset']+start} for e in logs)
   for item in unresolved:
    if 'File' not in item:item.update({'File':p.relative_to(ROOT).as_posix(),'Line':item['Line']+text.count('\n',0,start)})
   last=end
  out+=class_pattern.sub(lambda m:CLASSES[m[1]],text[last:])
  display_literals=DISPLAY_LITERALS if p.name=='CNDMResultsWriter.cls' else {}
  for old,new in display_literals.items():
   assert out.count(old)==1,(p.name,old,out.count(old));out=out.replace(old,new)
  proof=prove_identifiers_only(text,out,modules,public,unique,display_literals)
  plan['UnresolvedMembers'].extend(unresolved)
  if out!=text:
   relative=p.relative_to(ROOT).as_posix();previews[p]=(b'\xef\xbb\xbf' if data.startswith(b'\xef\xbb\xbf') else b'')+out.encode();originals[p]=data
   plan['ChangedFiles'].append({'File':relative,'BeforeSHA256':hashlib.sha256(data).hexdigest(),'AfterSHA256':hashlib.sha256(previews[p]).hexdigest(),'Replacements':replacements,'TokenProof':proof})
 support=list((ROOT/'tools').rglob('*.ps1'))+list((ROOT/'tools').rglob('*.py'))+[ROOT/'docs/ValidationPlan.md',ROOT/'README.md']
 for p in support:
  if not p.exists():continue
  data=p.read_bytes();text=data.decode('utf-8-sig');out=text
  for old,new in CLASSES.items():out=re.sub(r'\b'+re.escape(old)+r'\b',new,out)
  out=re.sub(r'\b(\w+)\.(\w+)\b',lambda m:m[1]+'.'+maps.get(next((old for old,renamed in CLASSES.items() if renamed.casefold()==m[1].casefold()),m[1]).casefold(),{}).get(m[2].casefold(),m[2]),out)
  for old,new in public.items():out=re.sub(r'([\'\"])'+re.escape(old)+r'\1',lambda m:m[1]+new+m[1],out,flags=re.I)
  if out!=text:
   previews[p]=(b'\xef\xbb\xbf' if data.startswith(b'\xef\xbb\xbf') else b'')+out.encode();originals[p]=data
   plan['ChangedFiles'].append({'File':p.relative_to(ROOT).as_posix(),'SupportReferencesOnly':True,'BeforeSHA256':hashlib.sha256(data).hexdigest(),'AfterSHA256':hashlib.sha256(previews[p]).hexdigest()})
 if args.apply:
  baseline=HERE/'TestRenameBefore.zip';assert not baseline.exists(),'Rename already applied: inspect the existing evidence.'
  with zipfile.ZipFile(baseline,'w',zipfile.ZIP_DEFLATED) as archive:
   for p,data in originals.items():archive.writestr(p.relative_to(ROOT).as_posix(),data)
  for p,data in previews.items():p.write_bytes(data)
  for p in list(previews):
   if p.suffix in ('.bas','.cls') and p.stem in CLASSES:
    destination=p.with_name(CLASSES[p.stem]+p.suffix);assert not destination.exists(),destination;p.rename(destination)
 (HERE/'TestRenamePlan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 with zipfile.ZipFile(HERE/'TestRenamePreview.zip','w',zipfile.ZIP_DEFLATED) as archive:
  for p,data in previews.items():archive.writestr(p.relative_to(ROOT).as_posix(),data)
 print(json.dumps({'ClassRenames':len(CLASSES),'MethodRenames':sum(len(v) for v in modules.values()),'ContractExceptions':len(exceptions),'Applied':args.apply,'ChangedFiles':len(plan['ChangedFiles']),'UnresolvedMembers':len(plan['UnresolvedMembers'])}))
if __name__=='__main__':main()
