"""ДЛЯ ТЕСТОВ: точное переименование свойства элемента тестовой Collection."""
from pathlib import Path
import hashlib, importlib.util, json, re, zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
spec=importlib.util.spec_from_file_location('rename_contour',HERE/'RenameTests.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=json.loads((HERE/'TestRenamePlan.json').read_text(encoding='utf-8'))
maps={name.casefold():{old.casefold():new for old,new in names.items()} for name,names in plan['Methods'].items()}
m.CLASS_MEMBER_MODULES={'CFakeAcadContourExport'}
returns={('cfakeacadcontourexport','createdentities'):'Collection',('cactualcollector','createdentities'):'Collection'}
before='''Private Sub TestChainProbe()
    Dim space As CFakeAcadContourExport, i As Long
    Debug.Print space.CreatedEntities(i).Deleted
End Sub
'''
expected='''Private Sub TestChainProbe()
    Dim space As CTestFakeAcadContourExport, i As Long
    Debug.Print space.TestCreatedEntities(i).TestDeleted
End Sub
'''
unresolved=[]
after,changes=m.transform_scope(before,'modTestAutoCADContours',{},maps,{},returns,{}, {},unresolved)
assert after==expected,(after,expected)
assert not unresolved,unresolved
# Без явного контракта коллекции воспроизводится именно сбойная цепочка,
# а не случайное изменение другого диагностического/внешнего свойства.
contract=m.INDEXED_COLLECTION_ELEMENTS
m.INDEXED_COLLECTION_ELEMENTS={}
mutant,_=m.transform_scope(before,'modTestAutoCADContours',{},maps,{},returns,{}, {},[])
m.INDEXED_COLLECTION_ELEMENTS=contract
assert 'space.TestCreatedEntities(i).Deleted' in mutant
assert mutant!=expected
unrelated='''Private Sub TestForeignCollection()
    Dim space As CActualCollector, i As Long
    Debug.Print space.CreatedEntities(i).Deleted
End Sub
'''
unchanged,_=m.transform_scope(unrelated,'modTestAutoCADContours',{},maps,{},returns,{}, {},[])
assert unrelated==unchanged
source=ROOT/'tests/modTestAutoCADContours.bas';actual=source.read_text(encoding='utf-8-sig')
mock=ROOT/'tests/CTestFakeAcadContourExport.cls';mock_text=mock.read_text(encoding='utf-8-sig')
assert 'space.TestCreatedEntities(i).TestDeleted' in actual
assert 'space.TestCreatedEntities(i).Deleted' not in actual
assert 'Public Property Get TestDeleted() As Boolean' in mock_text
assert 'TestDeleted = mDeleted' in mock_text and 'mDeleted = True' in mock_text
stale=[];scanned=0
for folder in ('src','tests','docs/geometry_refactor/examples'):
 for path in (ROOT/folder).rglob('*'):
  if path.suffix not in ('.bas','.cls'):continue
  scanned+=1
  for number,line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(),1):
   code=''.join(' '*len(token.group()) if token.group().startswith(('"',"'")) else token.group() for token in m.LEX.finditer(line))
   if re.search(r'\.(Deleted|CreatedEntities|ForbiddenReads|LastCopy|ExplodedPieces|BulgeAt|XDataReads|FailRegionAt)\b',code,re.I):
    stale.append({'File':path.relative_to(ROOT).as_posix(),'Line':number,'Code':code.strip()})
assert not stale,stale
log=(HERE/'Directed_No.txt').read_text(encoding='utf-8-sig').splitlines()
failure=next(i for i,line in enumerate(log) if line=="FAIL: contour.runtime; 438; Object doesn't support this property or method")
assert log[failure-1]=='OK: export.region.previousObjectPreserved'
report={'Status':'STATIC_FIX_VERIFIED','Cause':'Коллекция позднего связывания скрыла тип её элемента; одно диагностическое свойство осталось под старым именем. Это тестовый признак, а не обязательный AutoCAD API.',
 'FailureLog':'docs/regression/HelpCommentReview_2026-10-22/Directed_No.txt','FailureLine':failure+1,'LastPassedAssertion':log[failure-1],
 'Target':'tests/modTestAutoCADContours.bas:416','Before':'space.TestCreatedEntities(i).Deleted','After':'space.TestCreatedEntities(i).TestDeleted',
 'ChangedSourceFiles':['tests/modTestAutoCADContours.bas'],'SourceChanges':{'Identifiers':1,'Literals':0,'Operators':0,'NumericalData':0,'AssertionsRemoved':0},
 'CorrectDeclaredProperty':'CTestFakeAcadContourExport.TestDeleted','RenameSupport':'RenameTests.py: INDEXED_COLLECTION_ELEMENTS records only the explicit fake collection contract.',
 'StaticChecks':{'PositiveExplicitCollection':True,'DisabledContractReproducesOldFailure':True,'UnrelatedCollectionPreserved':True,'OldMockCallsRemaining':stale,'VbaFilesScanned':scanned},
 'ChangesInProbe':changes,'SourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest().upper(),
 'ExcelExecuted':False,'FrozenYesRunTouched':False,'NativeRerunRequired':'modTestAutoCADContours.RunAutoCADContourTests; root runs the affected directed checks after frozen Yes finishes.'}
(HERE/'FailureFixAutoCAD.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'Status':report['Status'],'NegativeMutationDetected':True,'UnrelatedCollectionPreserved':True,'VbaFilesScanned':scanned,'OldMockCallsRemaining':len(stale)}))
