"""ДЛЯ ТЕСТОВ: доказывает, что ревизия меняет только комментарии, согласованные имена и четыре пояснения."""
import importlib.util
import json
import subprocess
from pathlib import Path
from ApprovedMethodFixes import ApprovedFixes

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rename', HERE / 'RenameTests.py')
rename = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rename)
BASE = 'be0a27f195370bdf3069af1ba320f2681d5327b4'


def units(text):
    """Comments and the physical location of a whole procedure do not affect its executable tokens."""
    declarations = []
    procedures = {}
    last = 0
    for start, end, name in rename.spans(text):
        declarations.append(text[last:start])
        match = rename.METHOD.match(text[start:end])
        key = (match[1].casefold(), name.casefold())
        assert key not in procedures, key
        procedures[key] = text[start:end]
        last = end
    declarations.append(text[last:])
    return ''.join(declarations), procedures


def main():
    fixes = ApprovedFixes(rename.spans, rename.meaningful_tokens)
    plan = json.loads((HERE / 'TestRenamePlan.json').read_text(encoding='utf-8'))
    assert plan['Applied'], 'The plan is only a preview.'
    assert not plan['UnresolvedMembers'], plan['UnresolvedMembers']
    modules = plan['Methods']
    public = {}
    unique = {}
    # Literal references appearing in the recorded, token-checked mutation are the complete allowlist.
    recorded_strings = {}
    for item in plan['ChangedFiles']:
        for change in item.get('TokenProof', {}).get('Differences', []):
            if change['Old'].startswith('"'):
                recorded_strings.setdefault(change['Old'], set()).add(change['New'])
    report = {'Baseline': BASE, 'Files': [], 'Unexpected': [], 'MovedProceduresAllowed': True,
              'OnlyWholeProceduresMayMove': True, 'ContractExceptions': plan['ContractExceptions'],
              'AllowedDisplayedTextChanges': rename.DISPLAY_LITERALS}
    paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, '--', 'src', 'tests', 'docs/geometry_refactor/examples'], cwd=ROOT, text=True).splitlines()
    expected_files = set()
    for old_path in paths:
        path = Path(old_path)
        if path.suffix not in ('.bas', '.cls'): continue
        module = path.stem
        new_path = path.with_name(rename.CLASSES.get(module, module) + path.suffix)
        current_path = ROOT / new_path
        expected_files.add(new_path.as_posix())
        assert current_path.exists(), current_path
        before = subprocess.check_output(['git', 'show', BASE + ':' + old_path], cwd=ROOT).decode('utf-8-sig')
        after = current_path.read_bytes().decode('utf-8-sig')
        before_declarations, before_methods = units(before)
        after_declarations, after_methods = units(after)
        current_procedure_count = len(after_methods)
        for kind, name in list(after_methods):
            if fixes.is_addition(new_path, name):
                assert fixes.restore_tokens(new_path, name, rename.meaningful_tokens(after_methods.pop((kind, name)))) == []
        reverse = {new.casefold(): old.casefold() for old, new in modules.get(module, {}).items()}
        after_methods = {(kind, reverse.get(name, name)): value for (kind, name), value in after_methods.items()}
        assert before_methods.keys() == after_methods.keys(), (old_path, before_methods.keys() ^ after_methods.keys())
        permitted = {}
        for old, new in rename.CLASSES.items(): permitted.setdefault(old.casefold(), set()).add(new)
        for names in modules.values():
            for old, new in names.items(): permitted.setdefault(old.casefold(), set()).add(new)
        renamed = 0
        strings = 0
        for unit_name, left, right in [('declarations', before_declarations, after_declarations)] + [
            (kind + ':' + name, body, after_methods[(kind, name)]) for (kind, name), body in before_methods.items()]:
            left_tokens = rename.meaningful_tokens(left)
            right_tokens = rename.meaningful_tokens(right)
            if unit_name != 'declarations':
                right_tokens = fixes.restore_tokens(new_path, unit_name.split(':', 1)[1], right_tokens)
            assert len(left_tokens) == len(right_tokens), (old_path, unit_name, len(left_tokens), len(right_tokens))
            for index, (old, new) in enumerate(zip(left_tokens, right_tokens)):
                if old == new: continue
                if rename.IDENT.fullmatch(old):
                    assert new in permitted.get(old.casefold(), set()), (old_path, unit_name, index, old, new)
                    renamed += 1
                elif old.startswith('"'):
                    assert new in recorded_strings.get(old, set()), (old_path, unit_name, index, old, new)
                    strings += 1
                else:
                    raise AssertionError(('Formula, operator or data token changed', old_path, unit_name, index, old, new))
        report['Files'].append({'Before': old_path, 'After': new_path.as_posix(), 'BaselineProcedures': len(before_methods),
                                'Procedures': current_procedure_count,
                                'RenamedIdentifiers': renamed, 'CorrespondingStringReferencesOrFourDisplayTexts': strings,
                                'AllOtherExecutableTokensExactlyUnchangedOutsideApprovedFixes': True})
    actual = {path.relative_to(ROOT).as_posix() for path in rename.files()}
    assert actual == expected_files, (actual - expected_files, expected_files - actual)
    report['ApprovedMethodFixes'] = fixes.finish()
    event_count = len(rename.spans((ROOT / 'tools/build_workbook/WorkbookHelpEvents.vba').read_text(encoding='utf-8-sig')))
    report['Summary'] = {'Files': len(report['Files']), 'Procedures': sum(item['Procedures'] for item in report['Files']),
                         'BaselineProcedures': sum(item['BaselineProcedures'] for item in report['Files']),
                         'WorkbookEventProcedures': event_count,
                         'TotalProceduresIncludingWorkbookEvents': sum(item['Procedures'] for item in report['Files']) + event_count,
                         'RenamedIdentifiers': sum(item['RenamedIdentifiers'] for item in report['Files']),
                         'CorrespondingStringChanges': sum(item['CorrespondingStringReferencesOrFourDisplayTexts'] for item in report['Files']),
                         'UnexpectedExecutableChanges': 0, 'UnresolvedMemberReferences': 0,
                         'WorkingNumericalAlgorithmsAndInputsUnchanged': True,
                         'MechanicalRenamesOnlyExceptApprovedMethods': True,
                         'DocumentedChangedExistingMethods': 3, 'DocumentedAddedTargetedRunner': 1,
                         'TestFixtureInputsExplicitlySelectedAndRestored': ['Geometry.Type=Rectangles', 'Geometry.Source=Generated']}
    (HERE / 'TestRenameTokenProof.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report['Summary'], ensure_ascii=False))


if __name__ == '__main__': main()
