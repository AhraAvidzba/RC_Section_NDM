﻿# Нативная проверка просмотра Справки. Выполнять только после разрешения root для FinalRelease.
# Книга открывается только для чтения; расчёт, генерация и сохранение не вызываются.
param(
    [Parameter(Mandatory=$true)][string]$WorkbookPath,
    [string]$PlanPath='',
    [string]$ReportPath=''
)
$ErrorActionPreference='Stop'
if (-not $PlanPath) {$PlanPath=Join-Path $PSScriptRoot 'HelpNavigationPlan.json'}
if (-not $ReportPath) {$ReportPath=Join-Path $PSScriptRoot 'HelpNavigationNative.json'}
$evidence=(Resolve-Path -LiteralPath $PSScriptRoot).Path
$path=(Resolve-Path -LiteralPath $WorkbookPath).Path
if (-not $path.StartsWith($evidence+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {throw 'Use an isolated evidence workbook, never production.'}
$sourceHash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
$plan=Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
$sections=@($plan.Sections);$links=@($plan.Links)
if ($sections.Count -ne 8 -or $links.Count -ne 151) {throw 'Unexpected navigation inventory; regenerate and review the plan first.'}
if (@($plan.UngroupedTargets).Count -ne 0) {throw 'Help links target ungrouped content; repair the workbook and regenerate the navigation plan.'}
if ($sourceHash -cne [string]$plan.InventorySourceSHA256) {throw 'The native workbook differs from the reviewed navigation inventory.'}
$checks=New-Object 'System.Collections.Generic.List[object]'
$buttonChecks=New-Object 'System.Collections.Generic.List[object]'
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0;$failure=$null;$passed=$false
$report=[ordered]@{Status='RUNNING';StartedUtc=(Get-Date).ToUniversalTime().ToString('o');Workbook=$path;WorkbookSHA256=$sourceHash;ReadOnly=$true;WorkbookOpenEventsEnabled=$true;NoNDSSolveRequested=$true;NoSaveRequested=$true;PlanSHA256=(Get-FileHash -LiteralPath $PlanPath -Algorithm SHA256).Hash;Sections=$sections;LinkCount=$links.Count;LinkCountBySource=$plan.LinkCountBySource;ButtonChecks=$buttonChecks;LinkChecks=$checks}
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class HelpNavigationWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint id);}'

function Write-Report {
    $temporary=$ReportPath+'.tmp'
    $report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $ReportPath -Force
}

function Assert-SectionHidden([object]$section,[bool]$expected,[string]$context) {
    $address=[string]$section.FirstRow+':'+[string]$section.LastRow
    $raw=$help.Range($address).EntireRow.Hidden
    if ($null -ne $raw -and $raw -isnot [DBNull] -and [bool]$raw -eq $expected) {return}
    $bad=New-Object 'System.Collections.Generic.List[int]'
    for ($r=[int]$section.FirstRow;$r -le [int]$section.LastRow;$r++) {
        if ([bool]$help.Rows.Item($r).Hidden -ne $expected) {$bad.Add($r)}
    }
    throw ($context+': section A'+$section.HeaderRow+' expects Hidden='+$expected+' for every row '+$address+'; different rows='+($bad -join ','))
}

function Assert-SiblingsCollapsed([int]$targetHeader,[string]$context) {
    foreach ($section in $sections) {
        if ([int]$section.HeaderRow -ne $targetHeader) {Assert-SectionHidden $section $true $context}
    }
}

function Collapse-All([string]$context) {
    [void]$help.Outline.ShowLevels(1)
    foreach ($section in $sections) {Assert-SectionHidden $section $true $context}
}

try {
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$true;$excel.AutomationSecurity=1
    [uint32]$id=0;[void][HelpNavigationWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    $ownedPid=[int]$id;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
    $report['OwnPID']=$ownedPid;$report['OwnStartTicks']=$ownedTicks
    Write-Output "OWNED_EXCEL: id=$ownedPid; utcStartTicks=$ownedTicks"
    $book=$excel.Workbooks.Open($path,0,$true)
    if (-not $book.ReadOnly) {throw 'Native navigation must remain read-only.'}
    $help=$book.Worksheets.Item('Справка')
    $excel.Calculation=-4135
    # Полные границы взяты из outline исходного файла; проверяем, что FinalRelease не сдвинул разделы.
    foreach ($section in $sections) {
        $h=[int]$section.HeaderRow;$first=[int]$section.FirstRow;$last=[int]$section.LastRow
        if ([string]$help.Cells.Item($h,1).Value2 -cne [string]$section.Title) {throw ('Section heading changed at A'+$h)}
        if ([int]$help.Rows.Item($h).OutlineLevel -ne 1 -or [int]$help.Rows.Item($first).OutlineLevel -le 1 -or [int]$help.Rows.Item($last).OutlineLevel -le 1 -or [int]$help.Rows.Item(($last+1)).OutlineLevel -ne 1) {throw ('Section outline boundary differs at A'+$h)}
    }
    # Workbook_Open раскрывает целиком последний раздел; остальные целиком скрыты.
    $default=@($sections | Where-Object HeaderRow -eq 621)[0]
    Assert-SectionHidden $default $false 'Workbook_Open'
    Assert-SiblingsCollapsed 621 'Workbook_Open'
    $report['WorkbookOpenDefaultVerified']=$true
    # ShowDetail переключает те же группы, которыми управляют штатные кнопки outline +/− Excel.
    foreach ($section in $sections) {
        Collapse-All 'Before outline expand'
        $help.Rows.Item([int]$section.HeaderRow).ShowDetail=$true
        Assert-SectionHidden $section $false 'Outline expand'
        Assert-SiblingsCollapsed ([int]$section.HeaderRow) 'Outline expand'
        $help.Rows.Item([int]$section.HeaderRow).ShowDetail=$false
        Assert-SectionHidden $section $true 'Outline collapse'
        Assert-SiblingsCollapsed ([int]$section.HeaderRow) 'Outline collapse'
        $buttonChecks.Add([ordered]@{HeaderRow=$section.HeaderRow;Body=([string]$section.FirstRow+':'+[string]$section.LastRow);ExpandedAllRows=$true;CollapsedAllRows=$true;NeighborsPreserved=$true})
    }
    # Сверяем весь фактический состав внутренних ссылок, включая Config, «Сечения» и саму Справку.
    $actual=New-Object 'System.Collections.Generic.List[string]'
    foreach ($sheet in $book.Worksheets) {
        for ($i=1;$i -le [int]$sheet.Hyperlinks.Count;$i++) {
            $link=$sheet.Hyperlinks.Item($i);$sub=[string]$link.SubAddress
            if ($sub -match "^'?Справка'?!") {$actual.Add([string]$sheet.Name+'|'+$link.Range.Address($false,$false)+'|'+$sub)}
        }
    }
    $expected=@($links | ForEach-Object {[string]$_.SourceSheet+'|'+[string]$_.SourceAddress+'|'+[string]$_.SubAddress})
    if (@(Compare-Object @($actual) $expected -CaseSensitive).Count -ne 0) {throw 'Actual help links differ from the complete reviewed inventory.'}
    foreach ($item in $links) {
        $source=$book.Worksheets.Item([string]$item.SourceSheet)
        $cell=$source.Range([string]$item.SourceAddress)
        $matching=@()
        for ($i=1;$i -le [int]$cell.Hyperlinks.Count;$i++) {
            if ([string]$cell.Hyperlinks.Item($i).SubAddress -ceq [string]$item.SubAddress) {$matching+=,$cell.Hyperlinks.Item($i)}
        }
        if ($matching.Count -ne 1) {throw ('No unique matching hyperlink: '+$item.SourceSheet+'!'+$item.SourceAddress)}
        $targetSection=@($sections | Where-Object HeaderRow -eq $item.SectionHeaderRow)[0]
        for ($cycle=1;$cycle -le 2;$cycle++) {
            Collapse-All 'Before hyperlink'
            [void]$source.Activate();[void]($matching[0].Follow())
            $activeSheet=[string]$excel.ActiveSheet.Name;$activeRow=[int]$excel.ActiveCell.Row;$activeColumn=[int]$excel.ActiveCell.Column
            $scrollRow=[int]$excel.ActiveWindow.ScrollRow;$scrollColumn=[int]$excel.ActiveWindow.ScrollColumn
            if ($activeSheet -cne 'Справка' -or $activeRow -ne [int]$item.TargetRow -or $activeColumn -ne [int]$item.TargetColumn) {throw ('Wrong active target after '+$item.SourceSheet+'!'+$item.SourceAddress+' -> '+$item.SubAddress)}
            if ($scrollRow -ne [int]$item.TargetRow -or $scrollColumn -ne 1) {throw ('Target is not at top-left after '+$item.SourceSheet+'!'+$item.SourceAddress+': ScrollRow='+$scrollRow+'; ScrollColumn='+$scrollColumn)}
            if ([bool]$help.Rows.Item([int]$item.TargetRow).Hidden) {throw ('Target row remains hidden: '+$item.SubAddress)}
            Assert-SectionHidden $targetSection $false 'Hyperlink expand'
            Assert-SiblingsCollapsed ([int]$item.SectionHeaderRow) 'Hyperlink expand'
            $checks.Add([ordered]@{SourceSheet=$item.SourceSheet;SourceAddress=$item.SourceAddress;Target=$item.SubAddress;Cycle=$cycle;ActiveRow=$activeRow;ActiveColumn=$activeColumn;ScrollRow=$scrollRow;ScrollColumn=$scrollColumn;ExpandedWholeSection=$true;NeighborsPreserved=$true})
        }
        if ($checks.Count % 40 -eq 0) {Write-Output ('HELP_NAV_PROGRESS: follows='+$checks.Count)}
    }
    if ($checks.Count -ne 302 -or $buttonChecks.Count -ne 8) {throw 'Incomplete navigation coverage.'}
    $book.Close($false);$book=$null
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -cne $sourceHash) {throw 'Read-only navigation changed the workbook bytes.'}
    $report['SourceUnchanged']=$true;$report['Status']='PASS';$passed=$true
    Write-Output ('HELP_NAV_PASS: outline sections='+$buttonChecks.Count+'; hyperlinks='+$links.Count+'; follows='+$checks.Count)
} catch {
    $failure=$_.Exception.Message;$report['Status']='FAIL';$report['Failure']=$failure
    Write-Output ('HELP_NAV_FAIL: '+$failure)
} finally {
    if ($book) {$book.Close($false)}
    if ($excel) {$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if ($ownedPid) {
        $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
        if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks) {Stop-Process -Id $ownedPid -Force}
    }
    $report['CompletedUtc']=(Get-Date).ToUniversalTime().ToString('o')
    $report['CompletedHyperlinkFollows']=$checks.Count;$report['CompletedOutlineCycles']=$buttonChecks.Count
    $report['SourceHashAfter']=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    Write-Report
}
if (-not $passed) {throw $failure}
