﻿# Сверяет все компоненты с предыдущим нативным снимком, учитывая только регистр VBA.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$base=Join-Path $root 'docs/regression/SharedRebarInput_2026-10-18/RecipeDiagnosticsNoWrap_2026-10-20'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'tools/build_workbook/Verify-PostAudit03VbaEquality.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Canonical comparator parse failed.'}
foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -eq 'Add-Type'},$true)){. ([scriptblock]::Create($node.Extent.Text))}
foreach($node in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)){. ([scriptblock]::Create($node.Extent.Text))}
function Read-Dump([string]$path){
    $lines=[IO.File]::ReadAllLines($path,[Text.Encoding]::UTF8);$result=@{}
    for($i=0;$i -lt $lines.Length;$i++){
        if(-not $lines[$i].StartsWith('COMPONENT: ')){continue}
        $name=$lines[$i].Substring(11);$count=[int]$lines[$i+2].Substring(7)
        $body='';if($count -gt 0){$body=($lines[($i+4)..($i+3+$count)] -join "`n")}
        $result[$name]=$body.TrimEnd();$i=$i+3+$count
    }
    return $result
}
$before=Read-Dump (Join-Path $root 'docs/regression/SharedRebarInput_2026-10-18/OffsetExport_2026-10-19/PublishedNative.txt')
$after=Read-Dump (Join-Path $base 'AcceptedNative.txt')
if($before.Count -ne 161 -or $after.Count -ne $before.Count){throw 'Component inventory changed.'}
$changed=@();$caseOnly=@()
foreach($name in $before.Keys){
    if(-not $after.ContainsKey($name)){throw "Missing component: $name"}
    if((ConvertTo-VbaCodeCase $before[$name]) -cne (ConvertTo-VbaCodeCase $after[$name])){$changed+=$name}
    elseif($before[$name] -cne $after[$name]){$caseOnly+=$name}
}
if($changed.Count -ne 1 -or $changed[0] -ne 'CNDMResultsWriter'){throw ('Unexpected executable changes: '+($changed -join ', '))}
$needle=ConvertTo-VbaCodeCase '    If rowCount > 1 Then tableRange.Offset(1, 0).Resize(rowCount - 1, columnCount).WrapText = False'
$actual=ConvertTo-VbaCodeCase $after['CNDMResultsWriter']
[IO.File]::WriteAllText((Join-Path $base 'CanonicalBefore.txt'),(ConvertTo-VbaCodeCase $before['CNDMResultsWriter']),[Text.Encoding]::UTF8)
[IO.File]::WriteAllText((Join-Path $base 'CanonicalAfter.txt'),$actual,[Text.Encoding]::UTF8)
$matchingLines=@($actual -split "`n" | Where-Object {$_.Trim() -ceq $needle.Trim()})
if($matchingLines.Count -ne 1 -or $actual.Replace($matchingLines[0]+"`n",'') -cne (ConvertTo-VbaCodeCase $before['CNDMResultsWriter'])){throw 'Writer differs by more than the no-wrap assignment.'}
@{Passed=$true;Components=161;ChangedComponents=$changed;CaseOnlyComponents=$caseOnly;CodeChange='One explicit WrapText=False assignment for data rows';PendingFullPreflightTestEditsIncluded=$false} |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $base 'ComponentPreservation.json') -Encoding UTF8
Write-Output 'COMPONENT_PRESERVATION_PASS: only CNDMResultsWriter, one line'
