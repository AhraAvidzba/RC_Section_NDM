﻿# Проверяет сохранённую ячейку и повторный штатный вывод без решения НДС.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$directory=Join-Path $root 'docs/regression/SharedRebarInput_2026-10-18/RecipeDiagnosticsNoWrap_2026-10-20'
$path=Join-Path $directory 'Accepted.xlsm'
$hash=(Get-FileHash -LiteralPath $path).Hash
$excel=$null;$book=$null;$ownedPid=0;$ticks=0
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class NoWrapWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
function Inspect($workbook){
    $anchor=$workbook.Names.Item('rngNDMSectionProperties').RefersToRange.Cells(1,1)
    for($i=2;$i -le 46;$i++){
        if([string]$anchor.Cells($i,3).Value2 -eq 'Geometry.RecipeDiagnostics'){
            $cell=$anchor.Cells($i,4)
            if([bool]$cell.WrapText -or [double]$cell.RowHeight -ne 15){throw 'Diagnostic cell is wrapped or has wrong height.'}
            return @{Cell=$cell.Address($false,$false);WrapText=[bool]$cell.WrapText;RowHeight=[double]$cell.RowHeight;TextLength=([string]$cell.Value2).Length}
        }
    }
    throw 'Diagnostic row not found.'
}
try{
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=1
    [uint32]$id=0;[void][NoWrapWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    $ownedPid=[int]$id;$ticks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
    Write-Output ('OWNED_EXCEL: id='+$ownedPid+'; utcStartTicks='+$ticks)
    $book=$excel.Workbooks.Open($path,0,$true)
    if(-not $book.ReadOnly){throw 'Read-only copy required.'}
    $before=Inspect $book
    $report=[string]$excel.Run("'Accepted.xlsm'!modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests")
    if($report -match '(?m)^(FAIL:|RUNTIME ERROR)' -or $report -match 'failed=[1-9][0-9]*'){throw 'Snapshot check failed.'}
    $after=Inspect $book
    [IO.File]::WriteAllText((Join-Path $directory 'NativeSnapshot.txt'),$report,(New-Object Text.UTF8Encoding($true)))
    @{Passed=$true;SavedCell=$before;AfterPreview=$after;NoEquilibriumCalculation=$true;SourceSHA256=$hash;SourceUnchanged=((Get-FileHash -LiteralPath $path).Hash -ceq $hash)} |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $directory 'FormattingVerification.json') -Encoding UTF8
}finally{
    if($book){$book.Close($false)}
    if($excel){$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if($ownedPid){$p=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue;if($p -and $p.ProcessName -eq 'EXCEL' -and $p.StartTime.ToUniversalTime().Ticks -eq $ticks){Stop-Process -Id $ownedPid -Force -ErrorAction SilentlyContinue}}
}
Write-Output 'RECIPE_DIAGNOSTICS_NO_WRAP: PASS'
