"""Меняет VBA и флаг переноса сохранённой диагностики, сохраняя остальные части книги."""
from pathlib import Path
from zipfile import ZipFile
from copy import deepcopy
import xml.etree.ElementTree as E
import hashlib,json,re

base=Path('docs/regression/SharedRebarInput_2026-10-18/RecipeDiagnosticsNoWrap_2026-10-20')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
n={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
tag='{'+n['m']+'}'
with ZipFile(base/'Before.xlsm') as old, ZipFile(base/'Candidate.xlsm') as compiled:
    workbook=E.fromstring(old.read('xl/workbook.xml'))
    rel={r.attrib['Id']:r.attrib['Target'] for r in E.fromstring(old.read('xl/_rels/workbook.xml.rels'))}
    sheet=next(s for s in workbook.find('m:sheets',n) if s.attrib['name']=='Results')
    target=rel[sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
    path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    strings=[''.join(s.itertext()) for s in E.fromstring(old.read('xl/sharedStrings.xml'))]
    result_bytes=old.read(path);style_bytes=old.read('xl/styles.xml')
    results=E.fromstring(result_bytes);styles=E.fromstring(style_bytes)
    formats=styles.find('m:cellXfs',n);changed=[];new_format=None
    for row in results.findall('.//m:row',n):
        cells=list(row.findall('m:c',n))
        for i,c in enumerate(cells):
            v=c.find('m:v',n)
            if c.attrib.get('t')=='s' and v is not None and strings[int(v.text)]=='Geometry.RecipeDiagnostics':
                value=cells[i+1];old_index=int(value.attrib.get('s','0'))
                fmt=deepcopy(formats[old_index]);alignment=fmt.find('m:alignment',n)
                if alignment is None:alignment=E.SubElement(fmt,tag+'alignment')
                before=alignment.attrib.get('wrapText','0');alignment.set('wrapText','0');fmt.set('applyAlignment','1')
                index=next((j for j,f in enumerate(formats) if E.tostring(f)==E.tostring(fmt)),None)
                if index is None:
                    index=len(formats);formats.append(fmt);formats.set('count',str(len(formats)));new_format=fmt
                value.set('s',str(index));changed.append({'Cell':value.attrib['r'],'WrapTextBefore':before,'WrapTextAfter':False})
    assert len(changed)==1,changed
    # Сохраняем исходные декларации пространств имён и все остальные байты XML.
    # Их пересериализация могла бы удалить префиксы из mc:Ignorable.
    address=changed[0]['Cell']
    pattern=rb'(<c\b[^>]*\br="'+address.encode()+rb'"[^>]*)(>)'
    def cell_style(match):
        text=match[1]
        if re.search(rb'\bs="[^"]*"',text):text=re.sub(rb'\bs="[^"]*"',b's="'+str(index).encode()+b'"',text)
        else:text+=b' s="'+str(index).encode()+b'"'
        return text+match[2]
    result_bytes,count=re.subn(pattern,cell_style,result_bytes);assert count==1
    if new_format is not None:
        style_bytes,count=re.subn(rb'(<cellXfs\b[^>]*\bcount=")[0-9]+(")',lambda m:m[1]+str(len(formats)).encode()+m[2],style_bytes);assert count==1
        assert style_bytes.count(b'</cellXfs>')==1
        style_bytes=style_bytes.replace(b'</cellXfs>',E.tostring(new_format,encoding='utf-8')+b'</cellXfs>')
    replacements={'xl/vbaProject.bin':compiled.read('xl/vbaProject.bin'),path:result_bytes,'xl/styles.xml':style_bytes}
    assert not (base/'Accepted.xlsm').exists()
    with ZipFile(base/'Accepted.xlsm','w') as output:
        for part in old.infolist():output.writestr(part,replacements.get(part.filename,old.read(part.filename)))
with ZipFile(base/'Before.xlsm') as old,ZipFile(base/'Accepted.xlsm') as new:
    assert old.namelist()==new.namelist()
    changed_parts=[p for p in old.namelist() if old.read(p)!=new.read(p)]
    assert set(changed_parts)=={p for p,data in replacements.items() if old.read(p)!=data},changed_parts
    before_tree=E.fromstring(old.read(path));after_tree=E.fromstring(new.read(path))
    before_cells={c.attrib['r']:c for c in before_tree.findall('.//m:c',n)}
    after_cells={c.attrib['r']:c for c in after_tree.findall('.//m:c',n)}
    assert before_cells.keys()==after_cells.keys()
    for address,cell in before_cells.items():
        after=deepcopy(after_cells[address])
        if address==changed[0]['Cell']:
            if 's' in cell.attrib:after.set('s',cell.attrib['s'])
            else:after.attrib.pop('s',None)
        assert E.tostring(cell)==E.tostring(after),address
    before_rows=before_tree.findall('.//m:row',n);after_rows=after_tree.findall('.//m:row',n)
    assert [r.attrib for r in before_rows]==[r.attrib for r in after_rows]
    old_formats=E.fromstring(old.read('xl/styles.xml')).find('m:cellXfs',n)
    new_formats=E.fromstring(new.read('xl/styles.xml')).find('m:cellXfs',n)
    assert all(E.tostring(f)==E.tostring(new_formats[i]) for i,f in enumerate(old_formats))
receipt={'Passed':True,'BeforeSHA256':sha(base/'Before.xlsm'),'AcceptedSHA256':sha(base/'Accepted.xlsm'),
         'ChangedParts':changed_parts,'ChangedFormatting':changed,'AllCellValuesAndFormulasPreserved':True,
         'AllRowHeightsPreserved':True,'AllOtherOriginalStylesPreserved':True,
         'AllCodeBeforeSHA256':sha(Path('workbook/output/VBA_All_Code.txt')),
         'ExecutionReportSHA256':sha(Path('workbook/output/RC_Section_NDM_execution_report.txt'))}
(base/'Package.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
