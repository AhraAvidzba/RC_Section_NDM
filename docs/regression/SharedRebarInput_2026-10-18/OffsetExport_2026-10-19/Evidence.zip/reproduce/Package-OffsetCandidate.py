from pathlib import Path
from zipfile import ZipFile
from xml.sax.saxutils import escape
import importlib,sys,json,hashlib
sys.path.insert(0,'tools/build_workbook')
reader=importlib.import_module('Verify-SectionRecipeGuide')
base=Path('docs/regression/SharedRebarInput_2026-10-18/OffsetExport_2026-10-19')
old=reader.read(base/'Saved.xlsm')
matches=[(a,c['value'])for a,c in old['sheets']['Справка']['cells'].items() if 'Арматурные условия и фактическое размещение' in str(c['value'])]
assert len(matches)==1
address,before=matches[0]
doc=Path('docs/geometry_refactor/ADDING_SECTION_TYPE.md').read_text('utf-8-sig')
after=next(x for x in doc.splitlines() if x.startswith('5. '))
assert len(after)<=len(before),(len(before),len(after))
accepted=base/'AcceptedV3.xlsm'
assert not accepted.exists()
with ZipFile(base/'Saved.xlsm') as source, ZipFile(base/'Candidate.xlsm') as compiled, ZipFile(accepted,'w') as result:
 shared=source.read('xl/sharedStrings.xml')
 oldText=escape(before).encode('utf-8');newText=escape(after).encode('utf-8')
 assert shared.count(oldText)==1
 shared=shared.replace(oldText,newText)
 for item in source.infolist():
  data=compiled.read(item.filename) if item.filename=='xl/vbaProject.bin' else shared if item.filename=='xl/sharedStrings.xml' else source.read(item.filename)
  result.writestr(item,data)
with ZipFile(base/'Saved.xlsm') as source,ZipFile(accepted) as new:
 changed=[n for n in source.namelist()if source.read(n)!=new.read(n)]
 assert changed==['xl/vbaProject.bin','xl/sharedStrings.xml'] or sorted(changed)==['xl/sharedStrings.xml','xl/vbaProject.bin']
new=reader.read(accepted)
for name,sheet in old['sheets'].items():
 assert new['sheets'][name]['columns']==sheet['columns']
 assert new['sheets'][name]['rows']==sheet['rows']
 assert new['sheets'][name]['cells'].keys()==sheet['cells'].keys()
 for addr,cell in sheet['cells'].items():
  actual=new['sheets'][name]['cells'][addr]
  if name=='Справка' and addr==address:
   assert actual['value']==after
   assert {k:v for k,v in actual.items()if k!='value'}=={k:v for k,v in cell.items()if k!='value'}
  else:assert cell==actual,(name,addr)
assert new['names']==old['names'] and new['drawings']==old['drawings']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
receipt={'Status':'PRESERVATION_PASS','SavedSHA256':sha(base/'Saved.xlsm'),'AcceptedSHA256':sha(accepted),'ChangedParts':changed,'ChangedHelpCell':address,'HelpCharsBefore':len(before),'HelpCharsAfter':len(after),'AllInputAndResultCellsPreserved':True,'AllStylesDimensionsAndObjectsPreserved':True,'CodeSHA256':sha(Path('workbook/output/VBA_All_Code.txt'))}
(base/'Package.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
