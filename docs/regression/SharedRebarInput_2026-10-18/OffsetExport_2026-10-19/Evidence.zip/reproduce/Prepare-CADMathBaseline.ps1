$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$base='docs/regression/SharedRebarInput_2026-10-18/OffsetExport_2026-10-19/'
[IO.File]::Copy((Join-Path $root ($base+'Saved.xlsm')),(Join-Path $root ($base+'MathBaseline.xlsm')),$false)
& (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath ($base+'MathBaseline.xlsm') -ModuleNames @('modTestPerformance') -EntryPointNames @('PrepareNativeCADRoundoffFixture','MeasureCADRoundoffCalculation','CADRoundoffFields')
