﻿$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
& (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath 'docs/regression/SharedRebarInput_2026-10-18/OffsetExport_2026-10-19/Candidate.xlsm' -ModuleNames @('modTestPerformance','modSectionRecipeApiGuide','modAutoCADStressExport','modWorkbookCalculation','CGeometryPath','CRebarRuleExecutor','CSectionGeometryQuery','CSectionDefinitionBuilder','CSectionModel','modTestRecipeOperations','modTestAudit02Api')
