"""Проверяет, что импорт тестового VBA не изменил данные и оформление книги."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

S = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def verify(before, after):
    changed = []
    with zipfile.ZipFile(before) as a, zipfile.ZipFile(after) as b:
        assert set(a.namelist()) == set(b.namelist()), 'Package parts differ'
        sa, sb = [ET.fromstring(z.read('xl/styles.xml')) for z in (a, b)]
        xa, xb = [s.find(S + 'cellXfs') for s in (sa, sb)]
        # Excel перенумеровывает одинаковые стили при сохранении; их свойства сохраняются.
        assert {ET.tostring(x) for x in xa} == {ET.tostring(x) for x in xb}
        sa.remove(xa)
        sb.remove(xb)
        assert ET.tostring(sa) == ET.tostring(sb), 'Style definitions changed'
        for name in a.namelist():
            old, new = a.read(name), b.read(name)
            if old == new:
                continue
            changed.append(name)
            if name in ('xl/vbaProject.bin', 'xl/styles.xml'):
                continue
            u, v = ET.fromstring(old), ET.fromstring(new)
            if name.startswith('xl/worksheets/sheet') and name.endswith('.xml'):
                for root, styles in ((u, xa), (v, xb)):
                    for node in root.iter():
                        for attr in ('s', 'style'):
                            if attr in node.attrib:
                                node.set(attr, ET.tostring(styles[int(node.get(attr))]).decode())
                    merged = root.find(S + 'mergeCells')
                    if merged is not None:
                        merged[:] = sorted(merged, key=lambda n: n.get('ref'))
            elif name == 'xl/workbook.xml':
                for root in (u, v):
                    for node in root.iter():
                        if node.tag.endswith('}absPath'):
                            node.attrib.pop('url')
                        if node.tag.endswith('}revisionPtr'):
                            node.attrib.pop('documentId')
            elif name == 'docProps/core.xml':
                for root in (u, v):
                    root.find('{http://purl.org/dc/terms/}modified').text = ''
            else:
                raise AssertionError('Unexpected changed part: ' + name)
            assert ET.tostring(u) == ET.tostring(v), 'Data or formatting changed: ' + name
    return {'Passed': True, 'BeforeSHA256': digest(before), 'AfterSHA256': digest(after),
            'AllWorksheetDataAndFormattingPreserved': True, 'ChangedPackageParts': changed,
            'AllowedNormalization': 'Style numbering, merge order, save path, revision ID and modified time only'}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('before', type=Path)
    p.add_argument('after', type=Path)
    p.add_argument('report', type=Path)
    args = p.parse_args()
    result = verify(args.before, args.after)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))
