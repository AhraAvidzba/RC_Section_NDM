"""ДЛЯ ТЕСТОВ. Переносит проверенную справку, сохраняя пользовательский расчёт побайтно.

Нативная копия служит только донором справки и её ссылок. VBA, Results,
данные ввода и рисунки других листов берутся из исходной сохранённой книги.
"""
import copy
import hashlib
import importlib.util
import json
import posixpath
import re
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E

R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('help_package',R/'tools/build_workbook/Package-HelpOnly.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
M=helper.M; X=helper.X; A=helper.A; NS=helper.NS
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG='http://schemas.openxmlformats.org/package/2006/relationships'

def test_read(path):
    """ДЛЯ ТЕСТОВ. Читает ZIP как набор независимых неизменяемых частей."""
    with ZipFile(path) as z:return z.infolist(),{n:z.read(n) for n in z.namelist()}

def test_relationships(parts,part):
    """ДЛЯ ТЕСТОВ. Связывает части по владельцу, а не по номеру листа."""
    name=posixpath.join(posixpath.dirname(part),'_rels',posixpath.basename(part)+'.rels')
    root=E.fromstring(parts[name])
    resolved={n.get('Id'):posixpath.normpath(posixpath.join(posixpath.dirname(part),n.get('Target'))).lstrip('/') for n in root}
    return name,root,resolved

def test_help_part(parts):
    """ДЛЯ ТЕСТОВ. Находит справку по отображаемому имени."""
    _,_,rel=test_relationships(parts,'xl/workbook.xml')
    w=E.fromstring(parts['xl/workbook.xml'])
    sheet=next(s for s in w.find('m:sheets',NS) if s.get('name')=='Справка')
    return rel[sheet.get('{'+REL+'}id')]

def test_dump(root):return E.tostring(root,encoding='UTF-8',xml_declaration=True,standalone=True)
def test_sha(data):return hashlib.sha256(data).hexdigest().upper()

source=P/'UserMainBefore.xlsm';native=P/'NativeHelp07.xlsm';target=P/'UpdatedHelp07.xlsm'
assert not target.exists(),'Target already exists'
infos,before=test_read(source);_,donor=test_read(native);parts=dict(before)
hp=test_help_part(before);np=test_help_part(donor);assert hp==np
parts['xl/styles.xml'],style_map=helper.merge_styles(before['xl/styles.xml'],donor['xl/styles.xml'])
ws=E.fromstring(donor[np]);strings=list(E.fromstring(donor['xl/sharedStrings.xml']))
for cell in ws.findall('.//m:c',NS):
    if cell.get('s') is not None:cell.set('s',str(style_map[int(cell.get('s'))]))
    if cell.get('t')=='s':
        index=int(cell.find('m:v',NS).text)
        for n in list(cell):cell.remove(n)
        cell.set('t','inlineStr');inline=E.SubElement(cell,'{'+M+'}is')
        for n in strings[index]:inline.append(copy.deepcopy(n))
for node in ws.findall('m:cols/m:col',NS)+ws.findall('m:sheetData/m:row',NS):
    for attr in ('s','style'):
        if node.get(attr) is not None:node.set(attr,str(style_map[int(node.get(attr))]))
oldws=E.fromstring(before[hp]); old_relname,oldrels,oldtargets=test_relationships(before,hp)
_,newrels,newtargets=test_relationships(donor,np)
# Локальную бинарную настройку принтера, добавленную Excel при Save,
# не переносим; исходная привязка страницы остаётся исходной.
page=ws.find('m:pageSetup',NS);oldpage=oldws.find('m:pageSetup',NS)
if page is not None and page.get('{'+REL+'}id') is not None:
    page.attrib.pop('{'+REL+'}id')
    if oldpage is not None and oldpage.get('{'+REL+'}id') is not None:page.set('{'+REL+'}id',oldpage.get('{'+REL+'}id'))
old_draw_id=oldws.find('m:drawing',NS).get('{'+REL+'}id')
new_draw_id=ws.find('m:drawing',NS).get('{'+REL+'}id')
old_draw=oldtargets[old_draw_id];new_draw=newtargets[new_draw_id]
ws.find('m:drawing',NS).set('{'+REL+'}id',old_draw_id)
for node in ws.iter():
    for attr,value in list(node.attrib.items()):
        if attr=='{'+REL+'}id' and node.tag!='{'+M+'}drawing':
            targetpart=newtargets[value]
            matching=[k for k,v in oldtargets.items() if v==targetpart]
            assert len(matching)==1,('Unmapped relation',targetpart)
            node.set(attr,matching[0])
parts[hp]=test_dump(ws)
old_dr_rel,_,old_media=test_relationships(before,old_draw)
_,_,new_media=test_relationships(donor,new_draw)
old_draw_xml=E.fromstring(before[old_draw])
assert all(n.find('x:pic/x:nvPicPr/x:cNvPr',NS).get('name','').startswith('NDMHelpFormula_') for n in old_draw_xml),'Foreign Help shapes'
# Перезаписываются только медиа, принадлежащие исключительно справке.
other_targets=set()
for part in before:
    if not part.endswith('.rels') or part==old_dr_rel:continue
    owner=posixpath.join(posixpath.dirname(posixpath.dirname(part)),posixpath.basename(part)[:-5])
    for rel in E.fromstring(before[part]):
        if rel.get('TargetMode')=='External':continue
        other_targets.add(posixpath.normpath(posixpath.join(posixpath.dirname(owner),rel.get('Target'))).lstrip('/'))
pool=list(dict.fromkeys(old_media.values()));assert not(set(pool)&other_targets),'Shared media cannot be replaced'
dr=E.fromstring(donor[new_draw]); relroot=E.Element('{'+PKG+'}Relationships',nsmap={None:PKG})
used={}; added=[]
for i,(rid,part) in enumerate(new_media.items()):
    if i<len(pool):dest=pool[i]
    else:
        dest=f'xl/media/ndm_help_normative_{i:03d}.png';assert dest not in parts;added.append(dest)
    parts[dest]=donor[part];used[rid]=dest
    E.SubElement(relroot,'{'+PKG+'}Relationship',Id=rid,Type=REL+'/image',Target=posixpath.relpath(dest,posixpath.dirname(old_draw)))
parts[old_draw]=test_dump(dr);parts[old_dr_rel]=test_dump(relroot)
link_count=0
for name in before:
    if name==hp or not name.startswith('xl/worksheets/') or not name.endswith('.xml'):continue
    old=E.fromstring(before[name]);new=E.fromstring(donor[name])
    links=lambda root:{n.get('ref'):n for n in root.findall('m:hyperlinks/m:hyperlink',NS) if helper.help_link(n.get('location'))}
    a,b=links(old),links(new);assert a.keys()==b.keys(),('Changed link cells',name)
    for ref in a:a[ref].set('location',b[ref].get('location'));link_count+=1
    if a:parts[name]=test_dump(old)
w=E.fromstring(before['xl/workbook.xml']);nw=E.fromstring(donor['xl/workbook.xml'])
for name in w.findall('m:definedNames/m:definedName',NS):
    if re.match(r"^=?'?Справка'?!",name.text or ''):
        match=nw.find("m:definedNames/m:definedName[@name='"+name.get('name')+"']",NS)
        assert match is not None;name.text=match.text
parts['xl/workbook.xml']=test_dump(w)
changed=[n for n in before if before[n]!=parts[n]]
allowed={hp,'xl/styles.xml','xl/workbook.xml',old_draw,old_dr_rel,*pool}
allowed.update(n for n in before if n.startswith('xl/worksheets/') and n.endswith('.xml') and n!=hp and E.fromstring(before[n]).find('m:hyperlinks',NS) is not None)
assert set(changed)<=allowed,changed
assert before['xl/vbaProject.bin']==parts['xl/vbaProject.bin']
results=[n for n in before if n.startswith('xl/worksheets/') and n.endswith('.xml') and n!=hp and before[n]==parts[n]]
with ZipFile(target,'w') as z:
    for info in infos:z.writestr(info,parts[info.filename])
    for name in added:z.writestr(name,parts[name])
_,reopened=test_read(target);assert all(reopened[n]==parts[n] for n in parts)
receipt=dict(Status='PASS',SourceSHA256=test_sha(source.read_bytes()),TargetSHA256=test_sha(target.read_bytes()),
 ChangedParts=changed,AddedParts=added,HelpLinks=link_count,Pictures=len(dr),VBAByteIdentical=True,
 UnchangedParts=len(before)-len(changed),SourceParts=len(before),ProtectedSheets=results)
(P/'HelpPackageReview07.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
