﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Перестраивает только справку в частной копии, не вызывает VBA и расчёт.
param([string]$Root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM',[int]$Attempt=1)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot
. (Join-Path $Root 'tools/build_workbook/SettingsCatalog.ps1')
. (Join-Path $Root 'tools/build_workbook/SectionRecipeGuide.ps1')
. (Join-Path $Root 'tools/build_workbook/HelpOutline.ps1')
. (Join-Path $Root 'tools/build_workbook/StandaloneHelpText.ps1')
$suffix=if($Attempt -eq 1){''}else{$Attempt.ToString('00')}
$script:FormulaImageDir=Join-Path $p ('FormulaImages'+$suffix)
$os=Get-CimInstance Win32_OperatingSystem; $mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if ($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB) {throw 'Недостаточный запас памяти для тестового Excel.'}
$source=Join-Path $p 'UserMainBefore.xlsm'; $target=Join-Path $p ('NativeHelp'+$suffix+'.xlsm')
if (Test-Path -LiteralPath $target) {throw 'NativeHelp уже существует; повторная сборка требует отдельного доказательства.'}
Copy-Item -LiteralPath $source -Destination $target
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue | ForEach-Object Id)
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class NDMHelpTestPid{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null; $book=$null; $own=0; $ticks=0
try {
    $app=New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][NDMHelpTestPid]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
    if ($existing -contains [int]$id) {throw 'COM вернул пользовательский Excel.'}
    $own=[int]$id; $ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
    [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content (Join-Path $p ('NativeHelpOwn'+$suffix+'.json')) -Encoding UTF8
    Write-Output "OWN $own $ticks"
    $app.Visible=$false; $app.DisplayAlerts=$false; $app.EnableEvents=$false; $app.AutomationSecurity=3
    $book=$app.Workbooks.Open($target,0,$false)
    if ($book.ReadOnly) {throw 'Частная копия открылась readonly.'}
    $app.Calculation=-4135; $app.CalculateBeforeSave=$false
    $sheet=$book.Worksheets.Item('Справка')
    if($Attempt -gt 1){$book.Names.Item('rngSectionRecipeGuide').Delete()} # Полная перестройка справки создаёт руководство заново; прежнее имя в этой частной копии больше не относится к действующему блоку.
    Write-Output 'STAGE SettingsInstructions'
    Add-SettingsInstructions $book $book.Worksheets.Item('Config') $sheet
    Write-Output 'STAGE RecipeGuide'
    Update-SectionRecipeGuide $book $Root | Out-Null
    Write-Output 'STAGE StandaloneText'
    Update-StandaloneHelpText $book | Out-Null
    Fit-SettingsInstructionRows $sheet
    Write-Output 'STAGE Outline'
    Set-HelpSectionOrderAndOutline $book -Expanded | Out-Null
    $records=@(foreach($shape in $sheet.Shapes){
        $proc=Get-Process -Id $own
        if ($proc.PrivateMemorySize64 -gt 900MB) {throw 'Предел памяти собственного тестового Excel.'}
        [ordered]@{Name=[string]$shape.Name;Row=[int]$shape.TopLeftCell.Row;Width=[double]$shape.Width;Height=[double]$shape.Height;Description=[string]$shape.AlternativeText}
    })
    $book.Save(); $book.Close($false); [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book);$book=$null
    $book=$app.Workbooks.Open($target,0,$true)
    $sheet=$book.Worksheets.Item('Справка')
    foreach ($r in $records) {
        $shape=$sheet.Shapes.Item($r.Name)
        if ([string]$shape.AlternativeText -cne $r.Description -or $shape.Height -le 0 -or $shape.TopLeftCell.Row -ne $r.Row) {throw "Повреждён сохранённый рисунок $($r.Name)"}
    }
    [ordered]@{Status='PASS';SavedReopened=$true;Pictures=$records;PeakMemoryBytes=(Get-Process -Id $own).PeakWorkingSet64;SourceSHA256=(Get-FileHash $source).Hash;TargetSHA256=(Get-FileHash $target).Hash} | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $p ('NativeHelpReview'+$suffix+'.json')) -Encoding UTF8
    Write-Output ('PASS pictures='+$records.Count)
} finally {
    if ($book) {$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
    if ($app) {$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
    $shape=$null;$sheet=$null; [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
}
