"""ДЛЯ ТЕСТОВ. Проверяет полный набор формул и ссылок и защиту пользовательских частей."""
import hashlib,json,posixpath,re
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
from pypdf import PdfReader
from PIL import Image,ImageDraw,ImageFont

R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
P=Path(__file__).resolve().parent
N={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','x':'http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
def test_sha(data):return hashlib.sha256(data).hexdigest().upper()
def test_parts(path):
    with ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
def test_sig(node):return node.tag,tuple(sorted(node.attrib.items())),node.text,tuple(test_sig(n) for n in node)
def test_normal(text):return re.sub(r'\s+',' ',text).strip()
before=test_parts(P/'UserMainBefore.xlsm');after=test_parts(P/'UpdatedHelp07.xlsm')
strings=[''.join(n.itertext()) for n in E.fromstring(after['xl/sharedStrings.xml'])]
ws=E.fromstring(after['xl/worksheets/sheet3.xml'])
texts=[]
for c in ws.findall('.//s:c',N):
    v=c.find('s:v',N)
    if c.get('t')=='s' and v is not None:t=strings[int(v.text)]
    elif c.get('t')=='inlineStr':t=''.join(c.find('s:is',N).itertext())
    else:continue
    texts.append(t)
body=test_normal(' '.join(texts))
plan=json.loads((P/'TextReferencesPlan.json').read_text(encoding='utf-8'))
endplan=json.loads((P/'FinalTextReferencesPlan.json').read_text(encoding='utf-8'))
prose=plan+endplan['Paragraphs']
for record in prose:assert test_normal(record['After']) in body,record['After']
for key,text in endplan['SettingReferences'].items():assert test_normal(text) in body,key
assert '1,4 по п. 8.2.6' not in body and '0,8 по СП 63, п. 8.2.6' not in body
assert 'Расчётная запись программы' not in body and 'без номера' not in body
catalog=json.loads((R/'tools/build_workbook/NormativeFormulaImages.json').read_text(encoding='utf-8'))
readers={}
for item in catalog:
    pdf=R/item['Source']
    if str(pdf) not in readers:
        assert test_sha(pdf.read_bytes())==item['SourceSHA256'];readers[str(pdf)]=PdfReader(pdf)
    raw=next(im.data for im in readers[str(pdf)].pages[item['Page']-1].images if im.name==item['Image']+'.png')
    asset=R/'tools/build_workbook/NormativeFormulaImages'/item['File']
    assert asset.read_bytes()==raw and test_sha(raw)==item['SHA256'],item['Key']
expected={}
for f in (P/'FormulaImages07').glob('*.png'):
    m=re.match(r'formula_(\d{3})_',f.name)
    if m:expected['NDMHelpFormula_'+m[1]]=f
dre=E.fromstring(after['xl/drawings/drawing3.xml'])
rels=E.fromstring(after['xl/drawings/_rels/drawing3.xml.rels'])
media={n.get('Id'):posixpath.normpath(posixpath.join('xl/drawings',n.get('Target'))) for n in rels}
records=[];found=set();images=[]
schemes={'NDMHelpFormula_031','NDMHelpFormula_036','NDMHelpFormula_038','NDMHelpFormula_046'}
for anchor in dre:
    prop=anchor.find('.//x:cNvPr',N);name=prop.get('name');description=prop.get('descr','')
    blip=anchor.find('.//a:blip',N);raw=after[media[blip.get('{'+REL+'}embed')]]
    assert name in expected and raw==expected[name].read_bytes(),('Picture differs from builder',name)
    assert 'Расчётная запись программы' not in description and 'без номера' not in description
    matching=[n for n in catalog if description==n['Formula']+'      '+n['Reference']]
    if matching:
        assert len(matching)==1
        item=matching[0];found.add(item['Key']);kind='normative-numbered' if item['Equation'] else 'normative-unnumbered'
    elif name in schemes:kind='scheme'
    elif 'СП ' in description:
        assert re.search(r'п\.?\s*\d',description),description
        kind='clause-explanation-unnumbered'
    else:kind='auxiliary'
    records.append(dict(Name=name,Description=description,Kind=kind,SHA256=test_sha(raw)))
    images.append((name,expected[name]))
assert len(dre)==78 and len(expected)==78 and found=={n['Key'] for n in catalog}
assert before['xl/vbaProject.bin']==after['xl/vbaProject.bin']
for part in ('xl/worksheets/sheet4.xml','xl/worksheets/sheet5.xml','xl/sharedStrings.xml'):
    assert before[part]==after[part],part
assert before.get('docProps/custom.xml')==after.get('docProps/custom.xml'),'Custom properties changed'
for part in ('xl/worksheets/sheet1.xml','xl/worksheets/sheet2.xml'):
    a=E.fromstring(before[part]);b=E.fromstring(after[part])
    for root in (a,b):
        for link in root.findall('s:hyperlinks/s:hyperlink',N):
            if re.match(r"^'?Справка'?!",link.get('location','')):link.set('location','HELP_LINK_ONLY')
    assert test_sig(a)==test_sig(b),('Input cells/formatting changed',part)
oldstyles=E.fromstring(before['xl/styles.xml']);styles=E.fromstring(after['xl/styles.xml'])
for group in ('numFmts','fonts','fills','borders','cellStyleXfs','cellXfs'):
    a=oldstyles.find('s:'+group,N);b=styles.find('s:'+group,N)
    assert len(b)>=len(a) and all(test_sig(x)==test_sig(y) for x,y in zip(a,b)),group
oldw=E.fromstring(before['xl/workbook.xml']);w=E.fromstring(after['xl/workbook.xml'])
assert test_sig(oldw.find('s:calcPr',N))==test_sig(w.find('s:calcPr',N))
recipe=w.find("s:definedNames/s:definedName[@name='rngSectionRecipeGuide']",N)
assert recipe is not None
row=int(re.search(r'\$A\$(\d+)',recipe.text)[1])
owner=ws.find(f"s:sheetData/s:row[@r='{row}']/s:c[@r='A{row}']/s:is",N)
assert owner is not None and ''.join(owner.itertext())=='Добавление нового типа сечения'
counts={kind:sum(r['Kind']==kind for r in records) for kind in sorted({r['Kind'] for r in records})}
# Листы визуальной сверки покрывают каждое изображение текущей сборки.
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',18)
for first in range(0,len(images),12):
    sheet=Image.new('RGB',(1560,6*225),(220,220,220));d=ImageDraw.Draw(sheet)
    for i,(name,path) in enumerate(images[first:first+12]):
        canvas=Image.new('RGB',(780,225),'white');g=ImageDraw.Draw(canvas);g.text((8,3),name,fill='black',font=font)
        im=Image.open(path).convert('RGB');ratio=min(1.5,760/im.width,185/im.height)
        im=im.resize((round(im.width*ratio),round(im.height*ratio)))
        canvas.paste(im,((780-im.width)//2,35+(185-im.height)//2));sheet.paste(canvas,((i%2)*780,(i//2)*225))
    sheet.save(P/f'FinalFormulaContact07_{first//12+1:02d}.png')
receipt=dict(Status='PASS_ALL_FORMULAS_AND_NORMATIVE_REFERENCES',Pictures=78,Counts=counts,
 ExactPDFAssets=len(found),MethodologyTextReferences=len(prose),SettingReferences=len(endplan['SettingReferences']),
 TargetSHA256=test_sha((P/'UpdatedHelp07.xlsm').read_bytes()),VBAResultsAndUserDataPreserved=True,
 FormulaAudit=records,SourceEditScope='Help and build only; no solver or storage changes')
(P/'FinalHelpAudit07.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='FormulaAudit'},ensure_ascii=False))
