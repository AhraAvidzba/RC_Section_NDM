﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Свежо проверяет все Excel данного этапа по PID и точному UTC времени запуска.
$ErrorActionPreference='Stop'
$names=@('NativeHelpOwn.json','NativeHelpOwn02.json','NativeHelpOwn03.json','NativeHelpOwn04.json','NativeHelpOwn05.json','NativeHelpFinalOwn06.json','NativeHelpOwn07.json','NativeHelpFinalOwn08.json')
$records=@()
foreach($file in $names){
    $expected=Get-Content -LiteralPath (Join-Path $PSScriptRoot $file) -Raw|ConvertFrom-Json
    $actual=@(Get-CimInstance Win32_Process -Filter ('ProcessId='+$expected.PID) -ErrorAction Stop)
    if($actual.Count -eq 0){$state='Absent';$observed=$null}
    else{
        if($actual.Count -ne 1){throw 'Ambiguous process observation'}
        $observed=[ordered]@{Name=$actual[0].Name;UTCStartTicks=[string]$actual[0].CreationDate.ToUniversalTime().Ticks}
        if($observed.Name -ieq 'EXCEL.EXE' -and $observed.UTCStartTicks -ceq [string]$expected.UTCStartTicks){throw ('Own Excel still live: '+$expected.PID)}
        $state='OtherIdentity'
    }
    $records+=,[ordered]@{File=$file;PID=$expected.PID;UTCStartTicks=[string]$expected.UTCStartTicks;TerminalState=$state;Observed=$observed}
}
[ordered]@{Status='ALL_OWN_TERMINAL';ObservedUTC=[DateTime]::UtcNow.ToString('o');Processes=$records;FirstEmptyOwnTerminationProof='EmptyOwnBeforeClose.json'}|ConvertTo-Json -Depth 8|Set-Content (Join-Path $PSScriptRoot 'AllHelpOwnClosures09.json') -Encoding UTF8
Write-Output ('PASS own='+$records.Count)
