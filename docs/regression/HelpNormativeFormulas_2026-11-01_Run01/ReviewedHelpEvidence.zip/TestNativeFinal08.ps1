﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет именно упакованный файл без Save, VBA-макросов и расчёта.
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$path=Join-Path $p 'UpdatedHelp07.xlsm'
$before=(Get-FileHash $path).Hash
$os=Get-CimInstance Win32_OperatingSystem;$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $m.CommitLimit-$m.CommittedBytes -lt 14GB){throw 'Memory reserve is insufficient'}
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMHelpFinalOwner08{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try {
    $app=New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][NDMHelpFinalOwner08]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
    if($existing -contains [int]$id){throw 'Attached to existing Excel'}
    $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
    [ordered]@{PID=$own;UTCStartTicks=[string]$ticks}|ConvertTo-Json|Set-Content (Join-Path $p 'NativeHelpFinalOwn08.json') -Encoding UTF8
    $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
    $book=$app.Workbooks.Open($path,0,$true)
    if(-not $book.ReadOnly){throw 'Readonly open required'}
    $app.Calculation=-4135;$sheet=$book.Worksheets.Item('Справка')
    $expected=(Get-Content -LiteralPath (Join-Path $p 'NativeHelpReview07.json') -Raw|ConvertFrom-Json).Pictures
    $records=@()
    foreach($r in $expected){
        $shape=$sheet.Shapes.Item($r.Name);$row=[int]$shape.TopLeftCell.Row
        if($row -ne $r.Row -or [string]$shape.AlternativeText -cne $r.Description){throw ('Formula moved or changed: '+$r.Name)}
        if([string]$shape.AlternativeText -match 'Расчётная запись программы|без номера'){throw 'Unwanted helper caption'}
        $band=$sheet.Range($sheet.Cells.Item($row,1),$sheet.Cells.Item($row,6))
        if($shape.Left -lt $band.Left-1 -or $shape.Left+$shape.Width -gt $band.Left+$band.Width+1){throw ('Clipped horizontally: '+$r.Name)}
        $top=[double]$sheet.Rows.Item($row).Top;$height=[double]$sheet.Rows.Item($row).RowHeight
        if($shape.Top -lt $top-1 -or $shape.Top+$shape.Height -gt $top+$height+1){throw ('Clipped vertically: '+$r.Name)}
        $records+=,[ordered]@{Name=$r.Name;Row=$row;RowHeight=$height;PictureHeight=[double]$shape.Height;Fits=$true}
    }
    if($sheet.Shapes.Count -ne 78){throw 'Unexpected shape count'}
    $links=0
    foreach($s in $book.Worksheets){foreach($link in $s.Hyperlinks){
        if([string]$link.SubAddress -match "^'?Справка'?!([A-Z]+[0-9]+)$"){
            if([string]$sheet.Range($Matches[1]).Value2 -eq ''){throw ('Blank Help link target '+$s.Name+' '+$link.SubAddress)}
            $links++
        }
    }}
    if([string]$book.Names.Item('rngSectionRecipeGuide').RefersToRange.Cells.Item(1,1).Value2 -cne 'Добавление нового типа сечения'){throw 'Recipe guide name is stale'}
    [ordered]@{Status='PASS_PACKAGED_NATIVE_READONLY';SHA256=$before;Pictures=$records;WorkingHelpLinks=$links;MacrosDisabled=$true;NoSave=$true;OwnedPID=$own;UTCStartTicks=[string]$ticks}|ConvertTo-Json -Depth 7|Set-Content (Join-Path $p 'NativeHelpFinalReview08.json') -Encoding UTF8
    Write-Output ('PASS pictures='+$records.Count+' links='+$links)
} finally {
    if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
    $shape=$null;$band=$null;$sheet=$null;$s=$null;$link=$null
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $p 'NativeHelpFinalQuit08.json') -Encoding UTF8
}
if((Get-FileHash $path).Hash -cne $before){throw 'Readonly candidate changed'}
