"""Проверяет численные данные, текст, индексы, стили и размеры Results."""
from copy import copy
from pathlib import Path
import json
import openpyxl

here = Path(__file__).resolve().parent
before = openpyxl.load_workbook(here / 'ImagesBefore/ResultsCalc.xlsm', rich_text=True)
after = openpyxl.load_workbook(here / 'ImagesAfter15/ResultsCalc.xlsm', rich_text=True)
left, right = before['Results'], after['Results']
assert {str(r) for r in left.merged_cells.ranges} == {str(r) for r in right.merged_cells.ranges}
styles = set()
count = 0
rich = 0
ignored_times = 0
json_columns = {}
for name in ('rngNDMSectionGeometry', 'rngNDMSectionAnnotations'):
    _, address = next(after.defined_names[name].destinations)
    anchor = right[address.replace('$', '')]
    width = 16 if name == 'rngNDMSectionGeometry' else 24
    end = anchor.row
    while right.cell(end + 1, anchor.column).value is not None:
        end += 1
    json_columns[anchor.column + width - 1] = (anchor.row, end)
json_alignments = 0
def style(cell):
    return tuple(copy(getattr(cell, key)) for key in ('font', 'fill', 'border', 'alignment', 'protection')) + (cell.number_format,)
for position in left._cells.keys() | right._cells.keys():
    first, second = left.cell(*position), right.cell(*position)
    if first.coordinate == 'A4' or first.data_type == second.data_type == 'd':
        ignored_times += 1
    else:
        assert first.value == second.value, (first.coordinate, first.value, second.value)
        count += 1
        rich += isinstance(first.value, openpyxl.cell.rich_text.CellRichText)
    if position[1] in json_columns and json_columns[position[1]][0] < position[0] <= json_columns[position[1]][1]:
        assert second.alignment.horizontal == 'right', (first.coordinate, 'JSON alignment')
        original = copy(first.alignment)
        original.horizontal = 'right'
        assert original == copy(second.alignment), (first.coordinate, 'JSON other alignment')
        first.alignment = original
        json_alignments += 1
    pair = (first.style_id, second.style_id)
    if pair not in styles:
        assert style(first) == style(second), (first.coordinate, 'style', pair)
        styles.add(pair)
for attribute in ('row_dimensions', 'column_dimensions'):
    first, second = getattr(left, attribute), getattr(right, attribute)
    assert set(first) == set(second), attribute
    for key in first:
        for item in ('height', 'width', 'hidden', 'outlineLevel', 'collapsed'):
            assert getattr(first[key], item, None) == getattr(second[key], item, None), (attribute, key, item)
result = {'Passed': True, 'ResultsCellsExactlyEqual': count, 'RichTextCellsExactlyEqual': rich,
          'ResolvedStylePairsExactlyEqual': len(styles), 'MergesAndDimensionsUnchanged': True,
          'IgnoredElapsedAndDateCells': ignored_times}
result['IntentionalJsonRightAlignedCells'] = json_alignments
(here / 'OutputEquality.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result))
