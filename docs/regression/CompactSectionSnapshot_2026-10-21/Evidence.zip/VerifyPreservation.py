"""Проверяет пользовательские листы и численные таблицы до публикации книги."""
import hashlib
import json
from copy import copy
from pathlib import Path
import sys
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
import openpyxl
from openpyxl.xml.functions import tostring
from openpyxl.utils.datetime import to_excel

here = Path(__file__).resolve().parent
before_path = here / 'SavedBeforeRelease.xlsm'
after_path = Path(sys.argv[1])
before = openpyxl.load_workbook(before_path, keep_vba=True)
after = openpyxl.load_workbook(after_path, keep_vba=True)
assert before.sheetnames == after.sheetnames
ns = {'x': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def saved_calculation(path):
    with zipfile.ZipFile(path) as archive:
        return ET.fromstring(archive.read('xl/workbook.xml')).find('x:calcPr', ns).attrib
assert saved_calculation(before_path) == saved_calculation(after_path), 'saved calculation mode'
finalization = json.loads((after_path.parent / 'Finalization.json').read_text(encoding='utf-8-sig'))
allowed = {(r['Sheet'], r['Address'].replace('$', '')): r for r in finalization['Changes']}

def style(cell):
    return tuple(copy(getattr(cell, key)) for key in ('font', 'fill', 'border', 'alignment', 'protection')) + (cell.number_format,)

checked_cells = 0
for first, second in zip(before, after):
    if first.title == 'Results':
        continue
    assert {str(r) for r in first.merged_cells.ranges} == {str(r) for r in second.merged_cells.ranges}, (first.title, 'merges')
    for attribute in ('row_dimensions', 'column_dimensions'):
        left, right = getattr(first, attribute), getattr(second, attribute)
        assert set(left) == set(right), (first.title, attribute)
        for key in left:
            for name in ('height', 'width', 'hidden', 'outlineLevel', 'collapsed'):
                assert getattr(left[key], name, None) == getattr(right[key], name, None), (first.title, attribute, key, name)
    assert str(first.data_validations) == str(second.data_validations), (first.title, 'validation')
    def conditional(sheet):
        return [(str(key.sqref), [tostring(rule.to_tree()) for rule in rules])
                for key, rules in sheet.conditional_formatting._cf_rules.items()]
    assert conditional(first) == conditional(second), (first.title, 'conditional formatting')
    for position in first._cells.keys() | second._cells.keys():
        left, right = first.cell(*position), second.cell(*position)
        change = allowed.get((first.title, left.coordinate))
        if change:
            assert left.value == change['Before'] and right.value == change['After'], left.coordinate
        else:
            assert left.value == right.value, (first.title, left.coordinate, left.value, right.value)
        assert style(left) == style(right), (first.title, left.coordinate, 'style')
        checked_cells += 1

removed = 'rngNDMSectionModelMetadata'
assert set(before.defined_names) - {removed} == set(after.defined_names)
shifted = {'rngNDMSectionGeometry': 'L156', 'rngNDMSectionContours': 'AD156',
           'rngNDMSectionProperties': 'AW156', 'rngNDMMaterialDiagrams': 'BE156',
           'rngNDMSectionAnnotations': 'BR156'}
for name in after.defined_names:
    if name in shifted:
        destinations = list(after.defined_names[name].destinations)
        assert destinations == [('Results', '$' + shifted[name][:-3] + '$156')], (name, destinations)
    else:
        assert before.defined_names[name].attr_text == after.defined_names[name].attr_text, name

def table(book, name, columns):
    sheet, address = next(book.defined_names[name].destinations)
    anchor = book[sheet][address]
    row = anchor.row
    result = []
    while book[sheet].cell(row, anchor.column).value is not None:
        values = [book[sheet].cell(row, anchor.column + col).value for col in range(columns)]
        result.append([to_excel(value, book.epoch) if isinstance(value, datetime) else value for value in values])
        row += 1
    return result

tables = {}
for name, width in (('rngNDMElementResults', 9), ('rngNDMSectionContours', 17),
                    ('rngNDMSectionProperties', 6), ('rngNDMMaterialDiagrams', 11)):
    first, second = table(before, name, width), table(after, name, width)
    if first != second:
        mismatch = [(r, c, a, b) for r, (left, right) in enumerate(zip(first, second)) for c, (a, b) in enumerate(zip(left, right)) if a != b]
        raise AssertionError((name, len(first), len(second), mismatch[:8]))
    tables[name] = len(first)
first, second = table(before, 'rngNDMSectionGeometry', 15), table(after, 'rngNDMSectionGeometry', 16)
assert len(first) == len(second)
for left, right in zip(first, second):
    assert left[:14] == right[:14], (left[:2], 'physical geometry')
tables['rngNDMSectionGeometry'] = len(first)
meta = {(r[1], r[2]): r for r in table(before, removed, 17)[1:]}
for row in second[1:]:
    original = meta[(row[2], row[1])]
    extra = json.loads(row[15])
    assert row[14] == original[16] or (row[14] is None and original[16] in (None, '')), row[1]
    assert extra['SourceName'] == (original[3] or '') and extra['SourceHandle'] == (original[4] or ''), row[1]
    assert float(extra['MaterialID']) == original[5], row[1]
    if row[2] == 'Rebar':
        assert extra['SteelClass'] == (original[6] or '') and extra['RecipeTrace'] == (original[7] or ''), row[1]

first, second = table(before, 'rngNDMSectionAnnotations', 22), table(after, 'rngNDMSectionAnnotations', 24)
assert len(first) == len(second)
for left, right in zip(first[1:], second[1:]):
    expected = left.copy()
    if left[2] == 'REBAR_AUTO_ALL':
        expected[1] = 'REBAR_GLOBAL_ANNOTATION'
        factor = {'m': 1000, 'cm': 10, 'mm': 1}[right[22]]
        expected[4] -= 5 / factor
        expected[6] = expected[4]
    assert expected == right[:22], (left[:3], 'annotation')
    if ('Annotation', left[2]) in meta:
        original = meta[('Annotation', left[2])]
        extra = json.loads(right[23])
        assert extra['OriginalText'] == (original[13] or '')
tables['rngNDMSectionAnnotations'] = len(first)
result = {'Passed': True, 'InputAndHelpCellsChecked': checked_cells, 'HelpCellsUpdated': len(allowed),
          'RequiredGeometryFieldsExactlyUnchanged': True, 'SavedTablesRows': tables,
          'BeforeSHA256': hashlib.sha256(before_path.read_bytes()).hexdigest().upper(),
          'AfterSHA256': hashlib.sha256(after_path.read_bytes()).hexdigest().upper()}
(here / 'Preservation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result))
