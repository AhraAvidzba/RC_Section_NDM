from pathlib import Path

root = Path(__file__).resolve().parent
source = Path('src/Excel/modWorkbookCalculation.bas').read_text(encoding='utf-8-sig')
source = source.replace('Option Explicit', 'Option Explicit\nPrivate mProfileText As String\nPrivate mProfileAt As Double', 1)
start = source.index('Public Function FormSectionForWorkbook(')
end = source.index('\nEnd Function', start)
part = source[start:end]
part = part.replace('    On Error GoTo Failed', '    mProfileText = vbNullString: mProfileAt = Timer\n    On Error GoTo Failed', 1)
marks = {
    '    guard.Enter workbook.Application': 'guard',
    '    settings.LoadFromWorkbook workbook': 'settings',
    '    units.LoadFromSettings settings': 'units',
    '        Set section = BuildWorkbookSectionModel(workbook, settings, units)': 'build',
    '    Dim snapshot As CSectionPropertiesCalculator: Set snapshot = PrepareSectionSnapshot(section)': 'properties',
    '    If issues.Count > 0 Then Err.Raise vbObjectError + 4163, "FormSectionForWorkbook", ResultsOutputLayoutMessage(0, issues)': 'validateLayout',
    '    summary.ClearSummary workbook': 'clearSummary',
    '    writer.WriteGeometryPreview workbook, section, snapshot, units': 'writeResults',
    '    ClearSectionPlotForNoData workbook, "Сечение сформировано. Схема не обновлена."': 'clearPlot',
    '    CalculateResultsSheet workbook': 'recalculateResults',
    '    UpdateSectionGeometryPreviewForWorkbook workbook': 'drawPlot',
    '    guard.Restore True': 'restore',
}
for line, name in marks.items():
    assert line in part, name
    part = part.replace(line, line + '\n    FormationProfileMark "' + name + '"', 1)
source = source[:start] + part + source[end:]
start = source.index('Public Function RunSectionCalculationForWorkbook(')
end = source.index('\nEnd Function', start)
part = source[start:end]
part = part.replace('    On Error GoTo Failed', '    mProfileText = vbNullString: mProfileAt = Timer\n    On Error GoTo Failed', 1)
for line, stage in {
    '    excelGuard.Enter workbook.Application': 'guard',
    '    settings.LoadFromWorkbook workbook': 'settings',
    '    Set section = ReadFormedSectionFromResults(workbook)': 'restoreSection',
    '    materialProvider.Initialize settings, units': 'materials',
    '    profiles.LoadFromWorkbook workbook, False': 'profiles',
    '    ValidateResultsOutputLayout workbook, section, batch, profiles': 'batchPreparation',
    '    batch.Execute': 'batchExecute',
    '    summaryWriter.WriteSummary workbook, batch, units, section': 'writeSummary',
    '    ndmWriter.WriteResults workbook, section, PrepareSectionSnapshot(section, materialProvider), batch, units, True': 'writeStates',
    '    plotWarning = UpdateCalculatedSectionPlot(workbook, settings, batch.StateAvailableCount, report)': 'plot',
    '    excelGuard.Restore True': 'finishAndRestore',
}.items():
    assert line in part, stage
    part = part.replace(line, line + '\n    FormationProfileMark "' + stage + '"', 1)
source = source[:start] + part + source[end:]
source += '''
Public Sub FormationProfileMark(ByVal stage As String)
    Dim nowValue As Double: nowValue = Timer
    mProfileText = mProfileText & stage & "=" & Format$(nowValue - mProfileAt, "0.00000") & "; "
    mProfileAt = nowValue
End Sub
Public Function FormationProfileReportForTests() As String
    FormationProfileReportForTests = mProfileText
End Function
Public Sub FormationProfileSample(ByVal name As String, ByVal seconds As Double)
    mProfileText = mProfileText & name & "=" & Format$(seconds, "0.00000") & "; "
End Sub
'''
(root / 'ProfileCalculation.bas').write_text(source, encoding='utf-8-sig', newline='\r\n')
builder = Path('src/Section/CSectionBuilder.cls').read_text(encoding='utf-8-sig')
for line, stage in {
    '    Set geometry = New CGeometryRegion: geometry.Initialize definition.ConcreteDomain': 'region',
    '    Set rules = New CRebarRuleExecutor: Set rebars = rules.Build(definition, geometry)': 'rebar',
    '    mesh.BuildMesh geometry, meshOptions.StepX, meshOptions.StepY, meshOptions.MaterialID, meshOptions.BoundarySubdivisions, meshOptions.SourceReference': 'mesh',
    '    Set modelBuilder = New CSectionModelBuilder: Set model = modelBuilder.BuildFromGenerated(mesh, rebars)': 'model',
    '    annotationBuilder.Build definition, rebars, model.Annotations, rules': 'annotations',
}.items():
    assert line in builder
    builder = builder.replace(line, line + '\n    FormationProfileMark "' + stage + '"', 1)
(root / 'ProfileBuilder.cls').write_text(builder, encoding='utf-8-sig', newline='\r\n')
writer = Path('src/Excel/CBatchResultWriter.cls').read_text(encoding='utf-8-sig')
for line, stage in {
    '    PrepareSummaryTarget SummaryClearRange(workbook), summaryRows': 'summaryClear',
    '    WriteSummaryBody target, data': 'summaryData',
    '    FormatSummary workbook, target, batch': 'summaryFormat',
    '    WriteStrengthSummary workbook, batch, units, section': 'strengthSummary',
    '    WriteCrackSummary workbook, batch, units': 'crackSummary',
    '    WriteStabilitySummary workbook, batch, units': 'stabilitySummary',
}.items():
    assert line in writer, stage
    writer = writer.replace(line, line + '\n    FormationProfileMark "' + stage + '"', 1)
(root / 'ProfileResultWriter.cls').write_text(writer, encoding='utf-8-sig', newline='\r\n')
snapshot = Path('src/Excel/CNDMResultsWriter.cls').read_text(encoding='utf-8-sig')
for signature, label in (
    ('Friend Sub FormatResultsBlock(', 'format'),
    ('Private Sub ClearNamedRegion(', 'clear'),
):
    start = snapshot.index(signature)
    begin = snapshot.index('\n', start)
    end = snapshot.index('\nEnd Sub', start)
    part = snapshot[begin:end]
    part = '\n    Dim profilingStarted As Double: profilingStarted = Timer' + part
    if label == 'format':
        part += '\n    FormationProfileSample "format_" & CStr(target.Column), Timer - profilingStarted'
    else:
        part = part.replace('\nMissingRange:', '\n    FormationProfileSample "clear_" & rangeName, Timer - profilingStarted\nMissingRange:')
    snapshot = snapshot[:begin] + part + snapshot[end:]
start = snapshot.index('Private Sub WriteSectionGeometry(')
begin = snapshot.index('\n    Dim target As Object', start)
snapshot = snapshot[:begin] + '\n    Dim profilingPrepared As Double: profilingPrepared = Timer' + snapshot[begin:]
line = '    target.Resize(rowCount, GEOMETRY_COLUMNS).Columns.Item(15).NumberFormat = "@"'
snapshot = snapshot.replace(line, '    FormationProfileSample "geometryArray", Timer - profilingPrepared\n    profilingPrepared = Timer\n' + line, 1)
line = '    target.Resize(rowCount, GEOMETRY_COLUMNS).Value2 = data'
snapshot = snapshot.replace(line, line + '\n    FormationProfileSample "geometryWrite", Timer - profilingPrepared', 1)
(root / 'ProfileSnapshotWriter.cls').write_text(snapshot, encoding='utf-8-sig', newline='\r\n')
tests = Path('tests/modTestWorkbookInterface.bas').read_text(encoding='utf-8-sig')
tests += '''
' ДЛЯ ТЕСТОВ: повторяемая оценка этапов в изолированной копии книги.
Public Function RunFormationTimingProbe() As String
    Dim iteration As Long, text As String, message As String
    PrepareCircleInput
    SetSystemSetting "General.ExecutionReportEnabled", "No"
    SetSystemSetting "Plot.Enabled", "Yes"
    For iteration = 1 To 5
        message = FormSectionForWorkbook(ThisWorkbook)
        text = text & "PROFILE " & CStr(iteration) & ": " & FormationProfileReportForTests() & vbCrLf & message & vbCrLf
    Next iteration
    RunFormationTimingProbe = text
End Function

Public Function RunFormationScaleProbe() As String
    Dim iteration As Long, scenario As Long, text As String, message As String
    SetSystemSetting "Geometry.Source", "Generated"
    For scenario = 0 To 2
        If scenario = 1 Then
            PrepareCircleInput
            SetSystemSetting "Mesh.StepX", "10"
            SetSystemSetting "Mesh.StepY", "10"
        ElseIf scenario = 2 Then
            SetSystemSetting "Circle.Diameter", "1000"
        End If
        SetSystemSetting "Plot.Enabled", "Yes"
        For iteration = 1 To 3
            message = FormSectionForWorkbook(ThisWorkbook)
            text = text & "SCALE " & CStr(scenario) & "/" & CStr(iteration) & ": " & FormationProfileReportForTests() & vbCrLf & message & vbCrLf
        Next iteration
    Next scenario
    RunFormationScaleProbe = text
End Function

Public Function RunCalculationTimingProbe() As String
    Dim iteration As Long, text As String, message As String
    PrepareCircleInput
    SetSystemSetting "General.ExecutionReportEnabled", "No"
    SetSystemSetting "Plot.Enabled", "Yes"
    SetSystemSetting "Mesh.StepX", "10"
    SetSystemSetting "Mesh.StepY", "10"
    message = FormSectionForWorkbook(ThisWorkbook)
    text = "FORMATION: " & FormationProfileReportForTests() & vbCrLf & message & vbCrLf
    For iteration = 1 To 3
        message = RunSectionCalculationForWorkbook(ThisWorkbook)
        text = text & "CALC " & CStr(iteration) & ": " & FormationProfileReportForTests() & vbCrLf & message & vbCrLf
    Next iteration
    RunCalculationTimingProbe = text
End Function

Public Function RunFormationWriterProbe() As String
    Dim iteration As Long, text As String, message As String
    PrepareCircleInput
    SetSystemSetting "Plot.Enabled", "Yes"
    SetSystemSetting "Mesh.StepX", "10": SetSystemSetting "Mesh.StepY", "10"
    For iteration = 1 To 3
        message = FormSectionForWorkbook(ThisWorkbook)
        text = text & "WRITER_FORM " & iteration & ": " & FormationProfileReportForTests() & vbCrLf
    Next iteration
    RunFormationWriterProbe = text
End Function
'''
(root / 'ProfileTests.bas').write_text(tests, encoding='utf-8-sig', newline='\r\n')
tests += (root / 'RenderProbe.vba').read_text(encoding='utf-8-sig')
(root / 'ProfileTests.bas').write_text(tests, encoding='utf-8-sig', newline='\r\n')
