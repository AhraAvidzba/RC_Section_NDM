"""Создаёт только диагностическую копию прежнего построителя для побитовой сверки."""
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
old = subprocess.check_output(['git', 'show', 'af0c525b0e65a8c4bd6bc3256fdb4d71763637fd:src/Geometry/CFiberMeshBuilder.cls']).decode('utf-8-sig')
old = old.replace('Attribute VB_Name = "CFiberMeshBuilder"', 'Attribute VB_Name = "CReferenceFiberMesh"')
(here / 'CReferenceFiberMesh.cls').write_text(old, encoding='utf-8-sig', newline='\r\n')
probe = '''Attribute VB_Name = "modMeshExactProbe"
Option Explicit
Private Type TDoubleValue
    Value As Double
End Type
Private Type TDoubleWords
    Low As Long
    High As Long
End Type
Private Function Bits(ByVal value As Double) As String
    Dim a As TDoubleValue, b As TDoubleWords
    a.Value = value: LSet b = a
    Bits = Right$("00000000" & Hex$(b.High), 8) & Right$("00000000" & Hex$(b.Low), 8)
End Function
Private Sub Setting(ByVal key As String, ByVal value As Double)
    Dim table As Object, data As Variant, row As Long
    Set table = ThisWorkbook.Names("rngSystemSettings").RefersToRange: data = table.Value2
    For row = 2 To UBound(data, 1)
        If CStr(data(row, 1)) = key Then table.Cells(row, 2).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, , key
End Sub
Public Function RunMeshExactProbe() As String
    On Error GoTo Failed
    Dim fixture As Variant, stepValue As Variant, stats As String, count As Long, fields As Long, i As Long
    Dim settings As CSystemSettingsReader, units As CUnitSystem, definition As CSectionDefinition
    Dim geometry As CGeometryRegion, options As TSectionMeshOptions, actual As CFiberMeshBuilder, expected As CReferenceFiberMesh
    Dim saved As Variant: saved = FixtureSaveInputs(ThisWorkbook.Worksheets("Config").UsedRange)
    Dim guard As CExcelAppStateGuard: Set guard = New CExcelAppStateGuard: guard.Enter Application
    For Each fixture In Array("Circle", "Rectangle", "LSection", "TwoRectangles", "RoundedSimple", "RoundedTapered", "RoundedMixed", "RoundedMixedLeft", "HollowCentered", "HollowOffset")
        For Each stepValue In Array(20#, 7.3, 10.1)
            FixtureRestoreInputs ThisWorkbook.Worksheets("Config").UsedRange, saved
            modTestShapeArchitecture.ConfigureShapeFixture CStr(fixture)
            Setting "Mesh.StepX", CDbl(stepValue): Setting "Mesh.StepY", CDbl(stepValue)
            Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
            Set units = New CUnitSystem: units.LoadFromSettings settings
            Set definition = ReadWorkbookSectionDefinition(ThisWorkbook, settings, units)
            options = ReadSectionMeshOptions(settings, units)
            Set geometry = New CGeometryRegion: geometry.Initialize definition.ConcreteDomain
            Set expected = New CReferenceFiberMesh
            expected.BuildMesh geometry, options.StepX, options.StepY, options.MaterialID, options.BoundarySubdivisions
            Set actual = New CFiberMeshBuilder
            actual.BuildMesh geometry, options.StepX, options.StepY, options.MaterialID, options.BoundarySubdivisions
            If actual.FiberCount <> expected.FiberCount Then Err.Raise 5, , "count: " & CStr(fixture)
            For i = 1 To actual.FiberCount
                If Bits(actual.FiberX(i)) <> Bits(expected.FiberX(i)) Or Bits(actual.FiberY(i)) <> Bits(expected.FiberY(i)) Or _
                    Bits(actual.FiberArea(i)) <> Bits(expected.FiberArea(i)) Or Bits(actual.FiberWidth(i)) <> Bits(expected.FiberWidth(i)) Or _
                    Bits(actual.FiberHeight(i)) <> Bits(expected.FiberHeight(i)) Or Bits(actual.FiberFillFactor(i)) <> Bits(expected.FiberFillFactor(i)) Or _
                    actual.FiberMaterialID(i) <> expected.FiberMaterialID(i) Then Err.Raise 5, , "fiber: " & CStr(fixture) & "/" & CStr(i)
            Next i
            count = count + 1: fields = fields + 7 * actual.FiberCount
            stats = stats & "EXACT_MESH: " & CStr(fixture) & "; step=" & CStr(stepValue) & "; count=" & actual.FiberCount & vbCrLf
        Next stepValue
    Next fixture
    RunMeshExactProbe = stats & "TOTAL_EXACT_MESH: passed=" & count & "; failed=0; fields=" & fields & vbCrLf
    guard.Restore True
    Exit Function
Failed:
    RunMeshExactProbe = stats & "FAIL: " & CStr(Err.Number) & "; " & Err.Description & vbCrLf
    If Not guard Is Nothing Then guard.Restore
End Function
'''
(here / 'modMeshExactProbe.bas').write_text(probe, encoding='utf-8-sig', newline='\r\n')
