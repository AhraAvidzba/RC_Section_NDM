"""Сводит сравнительные замеры вывода и схемы после общей оптимизации."""
import hashlib
import json
from pathlib import Path
import re
from statistics import median

here = Path(__file__).resolve().parent
def read(name):
    text = (here / name).read_text(encoding='utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    values = []
    for line in text.splitlines():
        if re.match(r'^CALC [123]:', line):
            values.append({key: float(value) for key, value in re.findall(r'(\w+)=([0-9.]+);', line)})
    assert len(values) == 3
    for row in values:
        total = sum(row.values())
        row['AllSummaryTables'] = sum(row[key] for key in ('summaryClear', 'summaryData', 'summaryFormat', 'strengthSummary', 'crackSummary', 'stabilitySummary', 'writeSummary'))
        row['AllResultsOutput'] = row['AllSummaryTables'] + row['writeStates']
        row['TotalCommand'] = total
    return {key: median(row[key] for row in values) for key in values[0]}

before, after = read('OutputBefore.txt'), read('OutputAfter15.txt')
result = {'Passed': True, 'Unit': 'seconds', 'MedianOf': 3,
          'Fixture': 'Circle D300 mm, mesh 10 mm, 884 concrete elements, 8 bars d20, PR2, N=-100000 N, Mx=-4000000 Nmm, My=-3000000 Nmm',
          'Before': before, 'After': after,
          'PlotSpeedup': before['plot'] / after['plot'],
          'PlotTimeReductionPercent': 100 * (1 - after['plot'] / before['plot']),
          'OutputTimeReductionPercent': 100 * (1 - after['AllResultsOutput'] / before['AllResultsOutput']),
          'TotalCommandReductionPercent': 100 * (1 - after['TotalCommand'] / before['TotalCommand']),
          'VariantWithNameLookupRejected': True,
          'SmallSampleAndTimerResolutionLimit': 'About 0.008 s; separate isolated Excel processes, no guarantee on user hardware.',
          'EvidenceSHA256': {name: hashlib.sha256((here / name).read_bytes()).hexdigest().upper() for name in ('OutputBefore.txt', 'OutputAfter15.txt')}}
(here / 'OutputPerformance.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result))
