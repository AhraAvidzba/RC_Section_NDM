from pathlib import Path
import hashlib
import json
import openpyxl

here = Path(__file__).resolve().parent
root = here.parents[2]
publication = json.loads((here / 'Publication.json').read_text(encoding='utf-8'))
book_path = root / 'workbook/output/RC_Section_NDM.xlsm'
all_path = root / 'workbook/output/VBA_All_Code.txt'
assert hashlib.sha256(book_path.read_bytes()).hexdigest().upper() == publication['WorkbookSHA256']
assert hashlib.sha256(all_path.read_bytes()).hexdigest().upper() == publication['AllCodeSHA256']
book = openpyxl.load_workbook(book_path, rich_text=True)
checked = {}
for name, columns in (('rngNDMSectionGeometry', 16), ('rngNDMSectionAnnotations', 24)):
    sheet_name, address = next(book.defined_names[name].destinations)
    sheet = book[sheet_name]
    anchor = sheet[address.replace('$', '')]
    assert sheet.cell(anchor.row, anchor.column + columns - 1).value == 'ExtraData'
    row = anchor.row + 1
    while sheet.cell(row, anchor.column).value is not None:
        cell = sheet.cell(row, anchor.column + columns - 1)
        assert cell.alignment.horizontal == 'right' and not cell.alignment.wrapText, cell.coordinate
        row += 1
    checked[name] = row - anchor.row - 1
assert 'rngNDMSectionModelMetadata' not in book.defined_names
result = {'Passed': True, 'WorkbookSHA256': publication['WorkbookSHA256'],
          'AllCodeSHA256': publication['AllCodeSHA256'], 'JsonRightAlignedRows': checked,
          'ObsoleteMetadataRangeAbsent': True}
(here / 'PublishedOutput.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result))
