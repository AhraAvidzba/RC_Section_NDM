"""Сравнивает все 120 прямых решений до и после сохранения геометрии."""
from hashlib import sha256
from pathlib import Path
import json
import math
import re
import struct
import sys

HERE = Path(__file__).resolve().parent

def read(name):
    path = HERE / name
    text = path.read_text(encoding="utf-8-sig")
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in text, name
    assert not re.search(r"(?m)^(?:FAIL|ERROR):", text), name
    result = {}
    for line in text.splitlines():
        fields = line.split("|")
        if len(fields) != 13 or not all(re.fullmatch(r"[0-9A-F]{16}", value) for value in fields[4:]):
            continue
        key = tuple(fields[:3])
        assert key not in result, key
        result[key] = (fields[3], [struct.unpack(">d", bytes.fromhex(value))[0] for value in fields[4:]])
    assert len(result) == 120, (name, len(result))
    return result, sha256(path.read_bytes()).hexdigest().upper()

original_name = sys.argv[1] if len(sys.argv) > 1 else "NdsOriginal07.txt"
restored_name = sys.argv[2] if len(sys.argv) > 2 else "NdsRestored07.txt"
original, original_hash = read(original_name)
restored, restored_hash = read(restored_name)
assert original.keys() == restored.keys()
maximum = 0.0
exact = 0
for key, (status, values) in original.items():
    assert restored[key][0] == status, (key, status, restored[key][0])
    for expected, actual in zip(values, restored[key][1]):
        assert math.isfinite(expected) and math.isfinite(actual), key
        error = abs(actual - expected) / max(1.0, abs(expected))
        maximum = max(maximum, error)
        exact += actual == expected
        assert error <= 1e-10, (key, expected, actual, error)
result = {
    "Passed": True, "Cases": 120, "Shapes": 10, "MaterialPurposes": 3, "LoadsPerPurpose": 4,
    "ComparedNumbers": 1080, "ExactlyEqualNumbers": exact, "ConvergenceStatusesUnchanged": True,
    "MaxNormalizedDifference": maximum, "Tolerance": 1e-10,
    "OriginalLog": original_name, "RestoredLog": restored_name,
    "OriginalLogSHA256": original_hash, "RestoredLogSHA256": restored_hash,
}
destination = HERE / (Path(restored_name).stem + "_Comparison.json")
destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
