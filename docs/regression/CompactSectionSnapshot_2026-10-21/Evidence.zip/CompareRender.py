"""Сравнивает реальные объекты диаграммы и растры до/после оптимизации."""
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageChops

here = Path(__file__).resolve().parent
def read(name):
    text = (here / name).read_text(encoding='utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    assert 'TOTAL_VISUAL_PROBE: passed=6; failed=0' in text
    values = {}
    for line in text.splitlines():
        if line.startswith('VISUAL|'):
            parts = line.split('|')
            key = tuple(parts[1:3])
            assert key not in values
            values[key] = parts[3:]
    return values

before, after = read('VisualBefore.txt'), read('VisualAfter15.txt')
assert before.keys() == after.keys(), (len(before), len(after))
differences = [(key, value, after[key]) for key, value in before.items() if value != after[key]]
assert not differences, differences[:3]
images = {}
for stage in ('SavedImport', 'CircleForm', 'CircleCalc', 'CircleDiscrete', 'PointedForm', 'HollowForm'):
    first, second = here / 'ImagesBefore' / (stage + '.png'), here / 'ImagesAfter15' / (stage + '.png')
    left, right = Image.open(first).convert('RGB'), Image.open(second).convert('RGB')
    assert left.size == right.size, stage
    difference = ImageChops.difference(left, right)
    images[stage] = {'Size': list(left.size), 'PixelsExactlyEqual': difference.getbbox() is None,
                     'BeforeSHA256': hashlib.sha256(first.read_bytes()).hexdigest().upper(),
                     'AfterSHA256': hashlib.sha256(second.read_bytes()).hexdigest().upper()}
    assert images[stage]['PixelsExactlyEqual'], (stage, difference.getbbox())
result = {'Passed': True, 'Scenarios': 6, 'ShapeRecordsExactlyEqual': len(before),
          'IndividualShapesPreserved': True, 'UserFigurePreserved': all((stage, 'USER_KEEP_TEST') in before for stage in images),
          'Images': images}
(here / 'RenderEquality.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result))
