
' ДЛЯ ТЕСТОВ: фактические фигуры и изображения шести контрольных схем.
Public Function RunPlotVisualProbe(ByVal directory As String) As String
    On Error GoTo Failed
    Dim text As String, message As String, chart As Object, custom As Object
    Set chart = ThisWorkbook.Worksheets("Расчет").ChartObjects("chtNDMSectionPlot").Chart
    Set custom = chart.Shapes.AddTextbox(1, 10, 10, 110, 16)
    custom.Name = "USER_KEEP_TEST": custom.TextFrame.Characters().Text = "User figure"
    custom.Line.Visible = False: custom.Fill.Visible = False
    UpdateSectionPlotForWorkbook ThisWorkbook
    text = RenderSnapshot("SavedImport", directory)
    PrepareCircleInput
    SetSystemSetting "General.ExecutionReportEnabled", "No"
    SetSystemSetting "Plot.Enabled", "Yes"
    SetSystemSetting "Plot.ResultGradient", "Yes"
    SetSystemSetting "Mesh.StepX", "10": SetSystemSetting "Mesh.StepY", "10"
    message = FormSectionForWorkbook(ThisWorkbook)
    text = text & RenderSnapshot("CircleForm", directory)
    message = RunSectionCalculationForWorkbook(ThisWorkbook)
    text = text & RenderSnapshot("CircleCalc", directory)
    ThisWorkbook.SaveCopyAs directory & "\ResultsCalc.xlsm"
    SetSystemSetting "Plot.ResultGradient", "No"
    UpdateSectionPlotForWorkbook ThisWorkbook
    text = text & RenderSnapshot("CircleDiscrete", directory)
    modTestShapeArchitecture.ConfigureShapeFixture "RoundedTapered"
    message = FormSectionForWorkbook(ThisWorkbook)
    text = text & RenderSnapshot("PointedForm", directory)
    modTestShapeArchitecture.ConfigureShapeFixture "HollowOffset"
    message = FormSectionForWorkbook(ThisWorkbook)
    text = text & RenderSnapshot("HollowForm", directory)
    RunPlotVisualProbe = text & "TOTAL_VISUAL_PROBE: passed=6; failed=0" & vbCrLf
    Exit Function
Failed:
    RunPlotVisualProbe = text & "FAIL: visualProbe " & Err.Number & "; " & Err.Description & vbCrLf
End Function

' Снимок координат и оформления реальных Chart.Shapes, включая пользовательскую фигуру.
Private Function RenderSnapshot(ByVal stage As String, ByVal directory As String) As String
    Dim chart As Object, shape As Object, i As Long, lines() As String, text As String
    Set chart = ThisWorkbook.Worksheets("Расчет").ChartObjects("chtNDMSectionPlot").Chart
    ReDim lines(0 To chart.Shapes.Count)
    lines(0) = "VISUAL_COUNT|" & stage & "|" & chart.Shapes.Count
    For i = 1 To chart.Shapes.Count
        Set shape = chart.Shapes.Item(i)
        text = "VISUAL|" & stage & "|" & shape.Name & "|" & shape.Type & "|" & shape.ZOrderPosition & "|" & _
            shape.Left & "|" & shape.Top & "|" & shape.Width & "|" & shape.Height & "|" & shape.Rotation & "|" & _
            shape.Fill.Visible & "|" & shape.Fill.Type & "|" & shape.Fill.ForeColor.RGB & "|" & shape.Fill.Transparency & "|" & _
            shape.Line.Visible & "|" & shape.Line.ForeColor.RGB & "|" & shape.Line.Weight & "|" & shape.Line.Transparency
        If shape.Type = 17 Then
            text = text & "|" & Replace$(Replace$(Replace$(shape.TextFrame.Characters().Text, "|", "%7C"), vbCr, "\\r"), vbLf, "\\n") & "|" & _
                shape.TextFrame.Characters().Font.Name & "|" & shape.TextFrame.Characters().Font.Size & "|" & _
                shape.TextFrame.Characters().Font.Color & "|" & shape.TextFrame.Characters().Font.Bold & "|" & shape.TextFrame.Characters().Font.Italic & "|" & _
                shape.TextFrame.HorizontalAlignment & "|" & shape.TextFrame.VerticalAlignment & "|" & _
                shape.TextFrame.MarginLeft & "|" & shape.TextFrame.MarginRight & "|" & shape.TextFrame.MarginTop & "|" & shape.TextFrame.MarginBottom
        End If
        lines(i) = text
    Next i
    If Not chart.Export(directory & "\" & stage & ".png", "PNG") Then Err.Raise 5, , "Chart export failed"
    RenderSnapshot = Join(lines, vbCrLf) & vbCrLf
End Function

' ДЛЯ ТЕСТОВ: обе команды в одном экземпляре Excel для сравнения этапов вывода.
Public Function RunOutputPerformanceProbe() As String
    RunOutputPerformanceProbe = RunFormationScaleProbe() & RunCalculationTimingProbe()
End Function
