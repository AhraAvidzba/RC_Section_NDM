"""Сводит замеры диагностических копий, не изменяя исходники и книгу."""
import hashlib
import json
from pathlib import Path
import re
from statistics import median

here = Path(__file__).resolve().parent

def stages(name, prefix):
    text = (here / name).read_text(encoding='utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    result = []
    for line in text.splitlines():
        match = re.match(prefix, line)
        if match:
            values = {key: float(value) for key, value in re.findall(r'(\w+)=([0-9.]+);', line)}
            result.append((match.groups(), values))
    return result

formation = {}
for stage, name in (('Before', 'ProfileDetail.txt'), ('After', 'ProfileAfter.txt')):
    values = stages(name, r'^SCALE (\d)/(\d):')
    assert len(values) == 9
    scenarios = []
    for scenario in range(3):
        warm = [row for (case, iteration), row in values if int(case) == scenario and int(iteration) > 1]
        record = {key: median(row[key] for row in warm) for key in warm[0]}
        record['BuildModel'] = sum(record[key] for key in ('region', 'rebar', 'mesh', 'model', 'annotations', 'build'))
        record['Total'] = sum(value for key, value in record.items() if key != 'BuildModel')
        scenarios.append(record)
    formation[stage] = scenarios

calc = stages('ProfileCalculation.txt', r'^CALC (\d):')
assert len(calc) == 3
calc_medians = {key: median(row[key] for _, row in calc) for key in calc[0][1]}
calc_medians['Total'] = sum(calc_medians.values())
result = {'Passed': True, 'Unit': 'seconds', 'TimerResolutionApproximately': 0.0078125,
          'FormationScenarios': ['Saved section: 136 concrete elements', 'Circle D300, 884 concrete elements, 8 bars',
                                 'Circle D1000, 8496 concrete elements, 8 bars'],
          'FormationWarmMedianOf2': formation, 'CalculationMedianOf3': calc_medians,
          'CalculationFixture': 'Circle D300; mesh 10 mm; 884 concrete elements; 8 bars; N=-100000 N, Mx=-4000000 Nmm, My=-3000000 Nmm; PR2',
          'FirstExcelGuardSeconds': stages('ProfileAfter.txt', r'^SCALE (\d)/(\d):')[0][1]['guard'],
          'ProductionProfilingInstrumentationAdded': False,
          'RepeatedGeometryGenerationInCalculation': False,
          'OldTimerStartedAfterExcelGuard': True,
          'Limits': 'Isolated Excel; no competing user books. Warm sample is small; no speed guarantee on user hardware.',
          'EvidenceSHA256': {name: hashlib.sha256((here / name).read_bytes()).hexdigest().upper()
                             for name in ('ProfileDetail.txt', 'ProfileAfter.txt', 'ProfileCalculation.txt')}}
(here / 'Performance.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result))
