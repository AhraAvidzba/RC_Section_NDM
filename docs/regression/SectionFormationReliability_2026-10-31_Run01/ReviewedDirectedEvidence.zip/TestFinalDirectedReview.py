# ДЛЯ ТЕСТОВ: объединяет только доказанный адресный состав, не объявляя полный набор пройденным.
from pathlib import Path
import json,hashlib,subprocess
p=Path(__file__).parent
names=['Candidate05SourceEquality','Candidate06SourceEquality','Candidate06NativeReview','PackageReview','PerformanceReview','FreshPackageReview','FreshSafe07NativeReview','FreshSafe07SourceEquality','FinalTimingReview']
proofs={n:json.loads((p/(n+'.json')).read_text('utf-8-sig')) for n in names}
for n,v in proofs.items():assert v['Passed'],n
core=json.loads((p/'Candidate05NativeReview.json').read_text('utf-8-sig'))
assert core['Switches']==120 and core['MultipleBooksIsolated'] and core['GeneralSourceOnly']
assert 'System.IO.IOException' in core['Error'] and 'UiLive.json' in core['Error'], 'Only observer sharing failure permitted'
ui=proofs['Candidate06NativeReview'];assert len(ui['UiSteps'])==6
for row in ui['UiSteps']:assert row['Actual']==row['Expected'] and row['NativeSelectionAccepted']
book=p/'Candidate05.xlsm';sha=hashlib.sha256(book.read_bytes()).hexdigest().upper()
assert proofs['PackageReview']['BookSHA256']==sha==ui['BookSHA256']==proofs['FinalTimingReview']['BookSHA256']
assert proofs['Candidate05SourceEquality']['SourceComponents']==176 and proofs['Candidate05SourceEquality']['ExportComponents']==182
fresh=proofs['FreshSafe07NativeReview'];assert fresh['Switches']==4 and fresh['MultipleBooksIsolated'] and fresh['GeneralSourceOnly'] and fresh['Components']==182
assert fresh['BookSHA256']==proofs['FreshPackageReview']['BookSHA256']
for n in ['Candidate05Native.log','Candidate06Native.log','FreshBuildFinal.log','FreshSafe07Native.log','FinalTiming.log']:
 raw=(p/n).read_bytes();assert raw,n
result={'Passed':True,'Scope':'DIRECTED_ILLUSTRATIONS_FORMATION_ALL_FOUR_TYPES_FRESH_BUILD','FullAcceptanceClaim':False,'BookSHA256':sha,'SourceComponents':176,'ExportComponents':182,'RepeatedSwitches':120,'RepeatedSwitchesPerType':30,'MaxSampledPrivateBytes':max(v['PrivateBytes'] for v in core['MemorySamples']),'FinalRepeatedPrivateBytes':json.loads((p/'Candidate05SwitchProgress.json').read_text('utf-8-sig'))['PrivateBytes'],'RealUiSelections':ui['UiSteps'],'SourceDataCellsPreserved':proofs['PackageReview']['PreservedCellRecords'],'AllFiveSourcePicturesByteExact':len(proofs['PackageReview']['SourceImagesByteExact'])==5,'FinalTimingSeconds':[x['Seconds'] for x in proofs['FinalTimingReview']['Samples']],'VbaCacheResetUsed':False,'HistoricalFailuresPreserved':True,'OwnFilesOnlyPendingPublication':True}
(p/'FinalDirectedReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
