﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сохранённая книга: варианты списка, обычные картинки, независимость открытых книг и восстановление состояния.
param([string]$BookPath='', [string]$Label='Candidate', [switch]$Ui)
$ErrorActionPreference='Stop';$p=$PSScriptRoot
if(-not$BookPath){$BookPath="$p/Candidate.xlsm"}
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory;if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestUsabilityWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$r=[ordered]@{Passed=$false;FullAcceptanceClaim=$false;Choices=@();Switches=0;UiSteps=@();MemorySamples=@()};$a=$null;$b=$null;$other=$null;$second=$null;$own=$false
try{
 $prior=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object Id);$a=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestUsabilityWindow]::GetWindowThreadProcessId([IntPtr]$a.Hwnd,[ref]$id);if($prior-contains[int]$id){throw 'Own Excel required'};$own=$true
 @{PID=$id;StartTicksUTC=[string](Get-Process -Id $id).StartTime.ToUniversalTime().Ticks}|ConvertTo-Json|Set-Content "$p/${Label}NativeOwnership.json"
 $a.Visible=$true;$a.DisplayAlerts=$false;$a.EnableEvents=$false;$a.AutomationSecurity=1
 $b=$a.Workbooks.Open([IO.Path]::GetFullPath($BookPath),0,$true)
 $lines=New-Object 'System.Collections.Generic.List[string]';$lines.Add('VBA PROJECT EXPORT');$lines.Add('Date: '+(Get-Date).ToString('s'));$lines.Add('')
 foreach($component in $b.VBProject.VBComponents){$code=$component.CodeModule;$n=$code.CountOfLines;$lines.Add('COMPONENT: '+$component.Name);$lines.Add('TYPE: '+$component.Type);$lines.Add('LINES: '+$n);$lines.Add('');if($n){$lines.Add($code.Lines(1,$n))};$lines.Add('');$code=$null;$component=$null;[GC]::Collect()}
 [IO.File]::WriteAllLines("$p/${Label}_VBA_All_Code.txt",$lines,[Text.UTF8Encoding]::new($false));$r.Components=$b.VBProject.VBComponents.Count
 $sheet=$b.Worksheets.Item('Расчет');$source=$b.Worksheets.Item('Сечения');$cell=$sheet.Range('K2');$saved=$cell.Formula
 $frame=$sheet.Shapes.Item('CurrentSection');$r.FrameBefore=@($frame.Left,$frame.Top,$frame.Width,$frame.Height)
 if($frame.Type-ne13){throw 'CurrentSection must be an ordinary picture'}
 $names=@('Circle','Rectangles','PointedSection','HollowRectangle');$shapeCount=$sheet.Shapes.Count
 foreach($value in $names+@(($names-join','),($names-join';'),'Unknown','Общие_иллюстрации')){
  $cell.Value2=$value;$accepted=[bool]$cell.Validation.Value
  if($accepted-ne($value-in$names)){throw ('Validation '+$value)};$r.Choices+=,@{Value=$value;Accepted=$accepted}
 }
 $cell.Formula=$saved
 # Две другие книги, включая вторую NDM, содержат те же имена. Активная книга не должна менять адрес назначения.
 $secondPath="$p/${Label}_SecondNDM.xlsm";Copy-Item -LiteralPath $BookPath -Destination $secondPath -Force
 $second=$a.Workbooks.Open($secondPath,0,$true);$secondCell=$second.Worksheets.Item('Расчет').Range('K2');$secondValue=$secondCell.Formula
 $secondCount=$second.Worksheets.Item('Расчет').Shapes.Count
 $other=$a.Workbooks.Add();$other.Worksheets.Item(1).Name='Расчет'
 foreach($name in $names+@('CurrentSection')){$shape=$other.Worksheets.Item(1).Shapes.AddShape(1,10,10,10,10);$shape.Name=$name}
 $a.Calculation=-4135;$a.EnableEvents=$true;$a.ScreenUpdating=$true
 for($i=0;$i-lt120;$i++){
  @{Index=$i;Stage='StartingSwitch';UTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$p/${Label}SwitchProgress.json"
  $a.EnableEvents=$false;$cell.Value2=$names[$i%4];$a.EnableEvents=$true
  $other.Activate();$other.Worksheets.Item(1).Range('D7').Select()
  $a.Run(("'"+$b.Name+"'!modSectionIllustrations.SwitchSectionPicture"))
  if($a.ActiveWorkbook.Name-ne$other.Name-or$a.Selection.Address()-ne'$D$7'){throw 'Active selection not restored'}
  if(-not$a.EnableEvents-or-not$a.ScreenUpdating-or$a.Calculation-ne-4135){throw 'Application state changed'}
  $current=$sheet.Shapes.Item('CurrentSection')
  if($current.Type-ne13-or$current.AlternativeText-cne$names[$i%4]-or$sheet.Shapes.Count-ne$shapeCount){throw 'Picture switch failed or leaked objects'}
  $after=@($current.Left,$current.Top,$current.Width,$current.Height)
  for($k=0;$k-lt4;$k++){if([Math]::Abs($after[$k]-$r.FrameBefore[$k])-gt0.08){throw 'Frame changed'}}
  $original=$source.Shapes.Item($names[$i%4]);$ratio=[Math]::Min($current.Width/$original.Width,$current.Height/$original.Height);$crop=$current.PictureFormat.Crop
  if([Math]::Abs($crop.PictureWidth-$original.Width*$ratio)-gt0.1-or[Math]::Abs($crop.PictureHeight-$original.Height*$ratio)-gt0.1){throw 'Aspect ratio changed'}
  if($secondCell.Formula-cne$secondValue-or$second.Worksheets.Item('Расчет').Shapes.Count-ne$secondCount-or$other.Worksheets.Item(1).Shapes.Count-ne5){throw 'Other workbook changed'}
  $r.Switches++
  foreach($temporary in @($crop,$current,$original)){if($temporary-and[Runtime.InteropServices.Marshal]::IsComObject($temporary)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($temporary)}}
  $crop=$null;$current=$null;$original=$null;$temporary=$null
  [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
  $process=Get-Process -Id $id;$private=$process.PrivateMemorySize64
  if(($i%10)-eq0){$r.MemorySamples+=,@{Index=$i;PrivateBytes=$private};$r.MemorySamples|ConvertTo-Json|Set-Content "$p/${Label}MemorySamples.json"}
  if($private-gt900MB){throw 'Native test memory guard: more than 900 MiB; stop before OOM'}
  @{CompletedSwitches=$r.Switches;PrivateBytes=$private;UTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$p/${Label}SwitchProgress.json"
 }
 $r.MultipleBooksIsolated=$true
 $other.Close($false);$other=$null;$second.Close($false);$second=$null
 # Автоматическое событие при выборе K2 также обновляет обычный рисунок.
 $sheet.Activate();$cell.Select()
 foreach($name in $names){$cell.Value2=$name;if($sheet.Shapes.Item('CurrentSection').AlternativeText-cne$name){throw 'K2 event did not switch'}}
 $a.EnableEvents=$false;$cell.Formula=$saved;$a.Run(("'"+$b.Name+"'!modSectionIllustrations.SwitchSectionPicture"));$a.EnableEvents=$true
 $r.GeneralSourceOnly=($source.Shapes.Item('Общие_иллюстрации').Type-eq13)
 if(-not$r.GeneralSourceOnly){throw 'General illustration missing'}
 if($Ui){
  $steps=@(@{Sheet='Расчет';Cell='K2';Expected='Circle';Index=0},@{Sheet='Расчет';Cell='K2';Expected='Rectangles';Index=1},@{Sheet='Расчет';Cell='K2';Expected='PointedSection';Index=2},@{Sheet='Расчет';Cell='K2';Expected='HollowRectangle';Index=3},@{Sheet='Config';Cell='I4';Expected='cm';Index=1},@{Sheet='Сечения';Cell='H40';Expected='IncludeStart';Index=2})
  for($step=0;$step-lt$steps.Count;$step++){
   $def=$steps[$step];$s=$b.Worksheets.Item($def.Sheet);$c=$s.Range($def.Cell);$old=$c.Formula
   $s.Activate();$c.Select();$a.ScreenUpdating=$true;$a.WindowState=-4137
   if($c.Validation.Type-ne3){throw 'UI cell not a list'}
   $a.ActiveWindow.ScrollRow=[Math]::Max(1,$c.Row-3);$a.ActiveWindow.ScrollColumn=1
   $continue="$p/${Label}UiContinue$step"
   @{Step=$step;PID=$id;Book=$b.Name;Sheet=$s.Name;Cell=$c.Address();Expected=$def.Expected;DownCount=$def.Index;Formula=[string]$c.Validation.Formula1}|ConvertTo-Json|Set-Content "$p/UiReady.json"
   $deadline=[DateTime]::UtcNow.AddMinutes(4)
   while(-not(Test-Path $continue)){
    @{Step=$step;Value=[string]$c.Value2;Valid=[bool]$c.Validation.Value;ActiveSheet=[string]$a.ActiveSheet.Name;ActiveCell=[string]$a.ActiveCell.Address()}|ConvertTo-Json|Set-Content "$p/UiLive.json"
    if([DateTime]::UtcNow-gt$deadline){throw 'UI inspection timeout'}
    [GC]::Collect();Start-Sleep -Milliseconds 300
   }
   $actual=[string]$c.Value2
   if($actual-cne$def.Expected-or-not$c.Validation.Value){throw ('Actual UI selection mismatch: '+$actual+' expected '+$def.Expected)}
   $r.UiSteps+=,@{Step=$step;Sheet=$s.Name;Cell=$c.Address();Expected=$def.Expected;Actual=$actual;NativeSelectionAccepted=$true}
   $a.EnableEvents=$false;$c.Formula=$old;$a.EnableEvents=$true
  }
 }
 $r.BookSHA256=(Get-FileHash -LiteralPath $BookPath).Hash;$r.Passed=$true
}catch{$r.Error=$_.Exception.ToString();throw}finally{
 foreach($book in @($other,$second,$b)){if($book){try{$book.Close($false)}catch{$r.CloseError=$_.Exception.Message}}}
 if($own-and$a){try{$a.Quit()}catch{$r.QuitError=$_.Exception.Message}}
 $book=$null;$other=$null;$second=$null;$b=$null;$sheet=$null;$source=$null;$cell=$null;$frame=$null;$current=$null;$original=$null;$shape=$null;$component=$null;$code=$null;$crop=$null;$secondCell=$null;$s=$null;$c=$null;$a=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
 $r|ConvertTo-Json -Depth 8|Set-Content "$p/${Label}NativeReview.json"
}
$r|ConvertTo-Json -Depth 8
