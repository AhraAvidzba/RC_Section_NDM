"""ДЛЯ ТЕСТОВ: точное сохранение ячеек, стилей, исходных рисунков и именованных диапазонов."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
from decimal import Decimal
import hashlib,json,posixpath
P=Path(__file__).resolve().parent
R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
def tree(node):
 if node is None:return None
 return (E.QName(node).localname,sorted(node.attrib.items()),node.text,tuple(tree(c) for c in node))
def package(path):
 with ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
def data(parts):
 styles=[tree(x) for x in E.fromstring(parts['xl/styles.xml']).find('m:cellXfs',NS)]
 strings=[]
 if 'xl/sharedStrings.xml' in parts:strings=[''.join(e.itertext()) for e in E.fromstring(parts['xl/sharedStrings.xml']).findall('m:si',NS)]
 rels={e.get('Id'):e.get('Target') for e in E.fromstring(parts['xl/_rels/workbook.xml.rels'])}
 result={}
 for sh in E.fromstring(parts['xl/workbook.xml']).find('m:sheets',NS):
  path=posixpath.normpath('xl/'+rels[sh.get('{'+REL+'}id')]);xml=E.fromstring(parts[path]);cells={}
  for c in xml.findall('.//m:sheetData/m:row/m:c',NS):
   t=c.get('t','n');v=c.findtext('m:v',None,NS);f=c.findtext('m:f',None,NS)
   if t=='s':v=strings[int(v)]
   elif t=='inlineStr':v=''.join(c.find('m:is',NS).itertext());t='s'
   elif t=='n' and v is not None:v=str(Decimal(v).normalize())
   if v is not None or f is not None:cells[c.get('r')]=(t,v,f,styles[int(c.get('s','0'))])
  result[sh.get('name')]={'xml':xml,'cells':cells}
 return result
def names(parts):
 result=[]
 for v in E.fromstring(parts['xl/workbook.xml']).find('m:definedNames',NS):
  attrs=dict(v.attrib)
  if attrs.get('name')=='Print_Area':attrs['name']='_xlnm.Print_Area'
  result.append((sorted(attrs.items()),v.text))
 return sorted(result)
def source_images(parts):
 result={}
 for part,raw in parts.items():
  if not(part.startswith('xl/drawings/drawing') and part.endswith('.xml')):continue
  pics=E.fromstring(raw).xpath('//*[local-name()="pic"]')
  if not pics:continue
  rels={v.get('Id'):v.get('Target') for v in E.fromstring(parts['xl/drawings/_rels/'+posixpath.basename(part)+'.rels'])}
  for pic in pics:
   name=pic.xpath('./*[local-name()="nvPicPr"]/*[local-name()="cNvPr"]')[0].get('name')
   if name in ['Рисунок 1','Picture 1']:name='Общие_иллюстрации'
   if name not in ['Circle','Rectangles','PointedSection','HollowRectangle','Общие_иллюстрации']:continue
   blip=pic.xpath('./*[local-name()="blipFill"]/*[local-name()="blip"]')[0];path=posixpath.normpath(posixpath.dirname(part)+'/'+rels[blip.get('{'+REL+'}embed')])
   result[name]=sha(parts[path])
 return result
import sys
accepted=P/(sys.argv[1] if len(sys.argv)>1 else 'Candidate.xlsm')
before=package(P/'UserMainBefore.xlsm');after=package(accepted);a=data(before);b=data(after)
assert a.keys()==b.keys()
preserved=0
for name in a:
 assert a[name]['cells']==b[name]['cells'],name
 preserved+=len(a[name]['cells'])
 assert tree(a[name]['xml'].find('m:cols',NS))==tree(b[name]['xml'].find('m:cols',NS)),(name,'cols')
 assert sorted(a[name]['xml'].xpath('./m:mergeCells/m:mergeCell/@ref',namespaces=NS))==sorted(b[name]['xml'].xpath('./m:mergeCells/m:mergeCell/@ref',namespaces=NS)),(name,'merge areas')
 for tag in ['pageMargins','pageSetup','printOptions']:
  assert tree(a[name]['xml'].find('m:'+tag,NS))==tree(b[name]['xml'].find('m:'+tag,NS)),(name,tag)
 assert [dict(v.attrib) for v in a[name]['xml'].findall('m:sheetData/m:row',NS)]==[dict(v.attrib) for v in b[name]['xml'].findall('m:sheetData/m:row',NS)],(name,'row dimensions')
 assert tree(a[name]['xml'].find('m:dataValidations',NS))==tree(b[name]['xml'].find('m:dataValidations',NS)),(name,'validation')
assert names(before)==names(after),'Named ranges or print areas changed'
assert tree(E.fromstring(before['xl/workbook.xml']).find('m:calcPr',NS))==tree(E.fromstring(after['xl/workbook.xml']).find('m:calcPr',NS)), 'Calculation settings changed'
assert len(source_images(before))==5 and len(source_images(after))==5, 'Five source images required'
assert source_images(before)==source_images(after),'Source illustration bytes changed'
assert not any(n.startswith('xl/externalLinks/') for n in after),'External workbook link'
result={'Passed':True,'BookSHA256':sha(accepted.read_bytes()),'BeforeSHA256':sha((P/'UserMainBefore.xlsm').read_bytes()),'PreservedCellRecords':preserved,'CellStylesAndFormulasExact':True,'AllValidationUnchanged':True,'AllNamedRangesAndPrintAreaAddressesPreserved':True,'SourceImagesByteExact':source_images(after),'NoExternalWorkbookLinks':True,'FullAcceptanceClaim':False}
(P/'PackageReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
