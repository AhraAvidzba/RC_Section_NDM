# ДЛЯ ТЕСТОВ: сохранённый ZIP чистой сборки, пять точных PNG и обычный CurrentSection.
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import hashlib,json,posixpath
p=Path(__file__).parent;r=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM');file=p/'FreshBuildFinal/RC_Section_NDM.xlsm'
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};rel='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
parts={}
with ZipFile(file) as z:parts={n:z.read(n) for n in z.namelist()}
book=E.fromstring(parts['xl/workbook.xml']);rels={v.get('Id'):v.get('Target') for v in E.fromstring(parts['xl/_rels/workbook.xml.rels'])};by_sheet={}
for sh in book.find('m:sheets',ns):
 path=posixpath.normpath('xl/'+rels[sh.get('{'+rel+'}id')]);root=E.fromstring(parts[path]);drawing=root.find('m:drawing',ns)
 if drawing is None:continue
 sr={v.get('Id'):v.get('Target') for v in E.fromstring(parts[posixpath.dirname(path)+'/_rels/'+posixpath.basename(path)+'.rels'])};dp=posixpath.normpath(posixpath.dirname(path)+'/'+sr[drawing.get('{'+rel+'}id')]);d=E.fromstring(parts[dp]);dr={v.get('Id'):v.get('Target') for v in E.fromstring(parts[posixpath.dirname(dp)+'/_rels/'+posixpath.basename(dp)+'.rels'])};pictures={}
 for pic in d.xpath('//*[local-name()="pic"]'):
  name=pic.xpath('./*[local-name()="nvPicPr"]/*[local-name()="cNvPr"]')[0].get('name');blip=pic.xpath('./*[local-name()="blipFill"]/*[local-name()="blip"]')[0];assert blip.get('{'+rel+'}link') is None
  media=posixpath.normpath(posixpath.dirname(dp)+'/'+dr[blip.get('{'+rel+'}embed')]);pictures[name]=hashlib.sha256(parts[media]).hexdigest().upper()
 by_sheet[sh.get('name')]=pictures
catalog=json.loads((r/'tools/build_workbook/SectionIllustrations/Illustrations.json').read_text('utf-8-sig'));expected={n:n+'.png' for n in catalog['Names']};expected.update({v['Name']:v['File'] for v in catalog['Additional']})
assert set(by_sheet['Сечения'])==set(expected)
for n,f in expected.items():assert by_sheet['Сечения'][n]==hashlib.sha256((r/'tools/build_workbook/SectionIllustrations'/f).read_bytes()).hexdigest().upper(),n
assert 'Общие_иллюстрации' not in by_sheet['Расчет']
assert 'CurrentSection' in by_sheet['Расчет']
assert by_sheet['Расчет']['CurrentSection']==by_sheet['Сечения'][catalog['Default']], 'Initial ordinary picture must retain the project PNG bytes'
assert not any(b'<x:Camera' in value or b'<x:FmlaPict' in value for key,value in parts.items() if key.endswith('.vml'))
calc_sh=next(sh for sh in book.find('m:sheets',ns) if sh.get('name')=='Расчет');calc=E.fromstring(parts['xl/'+rels[calc_sh.get('{'+rel+'}id')]])
dv=next(v for v in calc.findall('.//m:dataValidation',ns) if v.get('sqref')=='K2');assert dv.findtext('m:formula1',None,ns)=='"'+','.join(catalog['Names'])+'"'
result={'Passed':True,'BookSHA256':hashlib.sha256(file.read_bytes()).hexdigest().upper(),'Bytes':file.stat().st_size,'SourceImagesByteExact':by_sheet['Сечения'],'TargetOrdinaryPicture':True,'TargetStaticUnlinkedPicture':True,'GeneralOnlyOnSource':True,'K2InlineFourChoices':True,'CacheResetUsed':False,'FullAcceptanceClaim':False}
(p/'FreshPackageReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
