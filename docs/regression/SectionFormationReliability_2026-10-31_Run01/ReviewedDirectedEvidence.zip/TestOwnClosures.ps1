﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Свежая проверка собственных идентичностей; повторно занятый PID не относится к тесту.
$ErrorActionPreference='Stop';$p=$PSScriptRoot
$processes=@(Get-CimInstance Win32_Process);$rows=@();$seen=@{}
foreach($file in Get-ChildItem -LiteralPath $p -Recurse -File -Filter '*Ownership*.json'){
 $owner=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json
 $key=[string]$owner.PID+'/'+[string]$owner.StartTicksUTC;if($seen.ContainsKey($key)){continue};$seen[$key]=$true
 $actual=@($processes|Where-Object ProcessId -eq $owner.PID)
 $row=[ordered]@{PID=$owner.PID;StartTicksUTC=[string]$owner.StartTicksUTC;Receipt=$file.FullName;Terminal=$false}
 if($actual.Count-eq0){$row.Status='ConfirmedNotFound';$row.Terminal=$true}
 elseif($actual.Count-ne1){$row.Status='Unknown'}
 elseif($actual[0].Name-ine'EXCEL.EXE'){$row.Status='PIDReusedDifferentExecutable';$row.ActualName=$actual[0].Name;$row.ActualCreationUTC=$actual[0].CreationDate.ToUniversalTime().ToString('o');$row.Terminal=$true}
 else{
  try{$proc=Get-Process -Id $owner.PID -ErrorAction Stop;$ticks=[string]$proc.StartTime.ToUniversalTime().Ticks;$row.ActualStartTicksUTC=$ticks
   if($ticks-ceq[string]$owner.StartTicksUTC){$row.Status='ExactOwnStillLive'}
   else{$row.Status='PIDReusedDifferentStart';$row.Terminal=$true;$row.ActualCreationUTC=$actual[0].CreationDate.ToUniversalTime().ToString('o')}
  }catch{$row.Status='Unknown';$row.Error=$_.Exception.Message}
 }
 $rows+=,$row
}
$forced=@()
foreach($receipt in Get-ChildItem -LiteralPath $p -File -Filter '*ForcedClosure.json'){$forced+=,(Get-Content -LiteralPath $receipt.FullName -Raw|ConvertFrom-Json)}
$result=[ordered]@{Passed=(@($rows|Where-Object {-not$_.Terminal}).Count-eq0);UTC=(Get-Date).ToUniversalTime().ToString('o');OwnIdentityCount=$rows.Count;Rows=$rows;ForcedTerminationUsed=($forced.Count-gt0);ForcedIdentities=$forced}
$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$p/AllOwnClosures.json" -Encoding utf8
if(-not$result.Passed){throw 'Own identities not all terminal'}
Write-Output ('ALL_OWN_TERMINAL: '+$rows.Count)
