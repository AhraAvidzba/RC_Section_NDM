"""ДЛЯ ТЕСТОВ: сверяет все ячейки семи таблиц, исключая только явно озаглавленную дату RunID."""
from pathlib import Path
import json,re,statistics,hashlib
p=Path(__file__).resolve().parent
def parse(raw):
 text=raw.decode('utf-8-sig');pos=0;tables={};date_cells=0
 def newline():
  nonlocal pos
  if text.startswith('\r\n',pos):pos+=2
  else:assert text[pos]=='\n';pos+=1
 while pos<len(text):
  end=text.index('\n',pos);header=text[pos:end].rstrip('\r');pos=end+1
  name,nrows,ncols=header.split(':');nrows=int(nrows);ncols=int(ncols);rows=[]
  for row in range(nrows):
   cells=[]
   for col in range(ncols):
    kind=text[pos];pos+=1
    if kind=='D':value=text[pos:pos+16];assert re.fullmatch('[0-9A-F]{16}',value);pos+=16
    else:
     assert kind=='S';end=text.index(':',pos);length=int(text[pos:end]);pos=end+1;start=pos;units=0
     while units<length:units+=2 if ord(text[pos])>0xFFFF else 1;pos+=1
     assert units==length;value=text[start:pos]
    assert text[pos]=='|';pos+=1;cells.append((kind,value))
   newline();rows.append(cells)
  if rows[0][0]==('S','RunID'):
   for row in rows[1:]:assert row[0][0]=='D';row[0]=('D','RUN_DATE');date_cells+=1
  tables[name]=rows
 return tables,date_cells
r=json.loads((p/'PerformanceMatrix.json').read_text(encoding='utf-8-sig'));assert r['Passed']
result={'Passed':True,'FullAcceptanceClaim':False,'OnlyExcludedField':'Data column explicitly headed RunID (service date); all other strings and IEEE values compared exactly','Types':{}}
for shape in ['Rectangles','Circle','PointedSection','HollowRectangle']:
 samples=[s for s in r['Samples'] if s['Type']==shape];base=None;compared=0;dates=0;timing={}
 for sample in samples:
  name='Fingerprint_'+sample['Variant']+'_'+shape+'_'+str(sample['Index'])+'.txt';tables,count=parse((p/name).read_bytes());dates+=count
  if base is None:base=tables
  if tables!=base:
   diffs=[]
   for key in tables.keys()|base.keys():
    for i,(a,b) in enumerate(zip(base.get(key,[]),tables.get(key,[]))):
     for j,(x,y) in enumerate(zip(a,b)):
      if x!=y:diffs.append((key,i,j,x,y))
   raise AssertionError((shape,sample['Variant'],sample['Index'],diffs[:5]))
  compared+=sum(len(row) for table in tables.values() for row in table)
  timing.setdefault(sample['Variant'],[]).append(sample['Seconds'])
 result['Types'][shape]={'ExactComparedCells':compared,'RunDateCellsExcluded':dates,'Timings':{key:{'Seconds':values,'Median':statistics.median(values)} for key,values in timing.items()}}
(p/'PerformanceReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
