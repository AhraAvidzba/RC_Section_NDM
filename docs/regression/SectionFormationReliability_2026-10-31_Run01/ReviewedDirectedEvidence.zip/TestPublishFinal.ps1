﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Публикует только проверенную пользовательскую копию и её точный экспорт VBA.
$ErrorActionPreference='Stop';$p=$PSScriptRoot
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
foreach($name in @('Candidate06NativeReview','Candidate05SourceEquality','FreshSafe07NativeReview','FreshSafe07SourceEquality','FreshPackageReview','PackageReview','FinalDirectedReview','AllOwnClosures')){
 $proof=Get-Content -LiteralPath "$p/$name.json" -Raw|ConvertFrom-Json
 if(-not$proof.Passed){throw ('Proof not accepted: '+$name)}
}
& "$p/TestOwnClosures.ps1"
$expected='C9F436818712202C8330DCF739B3128AAFE433568C230DC7A2BB0C0EB807AA51'
$book=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$code=Join-Path $root 'workbook/output/VBA_All_Code.txt'
if((Get-FileHash -LiteralPath $book).Hash-cne$expected){throw 'User workbook changed; preserve and review latest version first'}
if((Get-FileHash -LiteralPath $code).Hash-cne'137FA8032B3101BA002970076C83EC49A1B0918BDC87F99E0D02C22D53F35C33'){throw 'AllCode changed'}
$package=Get-Content -LiteralPath "$p/PackageReview.json" -Raw|ConvertFrom-Json
if((Get-FileHash -LiteralPath "$p/Candidate05.xlsm").Hash-cne$package.BookSHA256){throw 'Candidate changed'}
$probe=[IO.File]::Open($book,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$probe.Dispose()
$backup=Join-Path $p 'BeforePublication';if(Test-Path -LiteralPath $backup){throw 'Backup already exists; inspect receipt before repeating publication'}
New-Item -ItemType Directory -Path $backup|Out-Null
Copy-Item -LiteralPath $book -Destination "$backup/RC_Section_NDM.xlsm"
Copy-Item -LiteralPath $code -Destination "$backup/VBA_All_Code.txt"
if((Get-FileHash -LiteralPath "$backup/RC_Section_NDM.xlsm").Hash-cne$expected){throw 'Backup mismatch'}
Copy-Item -LiteralPath "$p/Candidate05.xlsm" -Destination $book -Force
Copy-Item -LiteralPath "$p/Candidate05_VBA_All_Code.txt" -Destination $code -Force
$new=(Get-FileHash -LiteralPath $book).Hash
if($new-cne$package.BookSHA256-or(Get-FileHash -LiteralPath $code).Hash-cne(Get-FileHash -LiteralPath "$p/Candidate05_VBA_All_Code.txt").Hash){throw 'Published hash mismatch'}
@{Passed=$true;UTC=(Get-Date).ToUniversalTime().ToString('o');BookSHA256=$new;BeforeBookSHA256=$expected;AllCodeSHA256=(Get-FileHash -LiteralPath $code).Hash;Backup=$backup;UserDataPreserved=$true;ResultsRecalculated=$false}|ConvertTo-Json|Set-Content -LiteralPath "$p/Publication.json" -Encoding utf8
Write-Output ('PUBLISHED '+$new)
