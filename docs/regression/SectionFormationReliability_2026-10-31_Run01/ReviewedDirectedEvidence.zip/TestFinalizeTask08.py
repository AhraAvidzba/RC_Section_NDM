# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сохраняет компактные доказательства только после адресной приёмки и публикации.
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, shutil

p = Path(__file__).parent
r = Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
def read(name):
    return json.loads((p / (name + '.json')).read_text('utf-8-sig'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

accepted, pub, own = (read(n) for n in ['FinalDirectedReview', 'Publication', 'AllOwnClosures'])
assert accepted['Passed'] and pub['Passed'] and own['Passed']
book = r / 'workbook/output/RC_Section_NDM.xlsm'
assert sha(book) == pub['BookSHA256'] == accepted['BookSHA256']
assert sha(r / 'workbook/output/VBA_All_Code.txt') == pub['AllCodeSHA256']
before, after = (p / 'UserMainBefore.xlsm').stat().st_size, book.stat().st_size
size = {'Passed': True, 'BeforeBytes': before, 'AcceptedBytes': after,
        'ReductionPercent': 100 * (before - after) / before,
        'BookSHA256': sha(book), 'FreshBuildBytes': (p / 'FreshBuildFinal/RC_Section_NDM.xlsm').stat().st_size,
        'VbaCacheResetUsed': False, 'SourceImagesRetained': 5,
        'SourceComponentsRetained': 176, 'ExportComponents': 182,
        'ImportantContentRemoved': False, 'FullAcceptanceClaim': False}
write(p / 'FinalSizeDecision08.json', size)
memory = {'UserReportedLatestOOM': True, 'UserIdentifiedContext': 'Test Excel',
          'ExactFailingStepRecorded': False, 'OrdinaryUserSessionFailureConfirmed': False,
          'InstalledOfficePlatformObserved': 'x86',
          'RepeatedSwitchesCompleted': 120, 'FinalRepeatedPrivateBytes': accepted['FinalRepeatedPrivateBytes'],
          'FreshGuardedRepeat': 'FreshSafe07NativeReview.json',
          'InternalExcelAllocationMechanismProven': False,
          'UnlimitedSessionMemoryGuarantee': False, 'FullAcceptanceClaim': False}
write(p / 'MemoryContext08.json', memory)

e = r / 'docs/regression/SectionFormationReliability_2026-10-31_Run01'
assert not e.exists(), 'Do not overwrite an existing evidence package'
e.mkdir(parents=True)
proofs = [
    'FinalDirectedReview.json', 'Publication.json', 'AllOwnClosures.json',
    'FinalSizeDecision08.json', 'MemoryContext08.json', 'PackageReview.json',
    'FreshPackageReview.json', 'PerformanceReview.json', 'PerformanceMatrix.json',
    'CameraTiming.json', 'Candidate05SourceEquality.json', 'Candidate06SourceEquality.json',
    'Candidate05NativeReview.json', 'Candidate05SwitchProgress.json',
    'Candidate06NativeReview.json', 'FreshSafe07NativeReview.json',
    'FreshSafe07SourceEquality.json', 'FreshSafe07NativeOwnership.json',
    'FreshSafe07MemorySamples.json', 'FreshSafe07SwitchProgress.json',
    'FreshFinalNativeReview.json', 'FinalTimingReview.json',
    'Attempt01_CandidateNativeReview.json', 'Candidate02NativeReview.json',
    'Candidate03NativeReview.json', 'Candidate04NativeReview.json',
    'NativeMemory03ForcedClosure.json', 'FinalBuildAssets.json',
    'Candidate05Native.log', 'Candidate06Native.log', 'FreshSafe07Native.log',
    'FreshBuildFinal.log', 'FinalTiming.log', 'FreshFinalNative.log',
    'TestPackage.py', 'TestFreshPackage.py', 'TestReviewPerformance.py',
    'TestVerifySource.ps1', 'TestFinalDirectedReview.py', 'TestOwnClosures.ps1',
    'TestNativeFreshSafe07.ps1', 'TestNativeManaged04.ps1', 'TestNativeUi06.ps1',
    'TestPublishFinal.ps1', 'TestFinalizeTask08.py',
] + [f'UiSelection06_{i}.json' for i in range(6)]
missing = [n for n in proofs if not (p / n).is_file()]
assert not missing, missing
archive = e / 'ReviewedDirectedEvidence.zip'
manifest = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as z:
    for name in proofs:
        raw = (p / name).read_bytes()
        z.writestr(name, raw)
        manifest.append({'Name': name, 'Bytes': len(raw), 'SHA256': hashlib.sha256(raw).hexdigest().upper()})
with ZipFile(archive) as z:
    for item in manifest:
        assert hashlib.sha256(z.read(item['Name'])).hexdigest().upper() == item['SHA256']
write(e / 'Manifest.json', {'ArchiveSHA256': sha(archive), 'Files': manifest})
processed = {'Status': 'DIRECTED_ACCEPTED_NO_FULL_RUN', 'Passed': True,
             'FullAcceptanceClaim': False, 'BookSHA256': pub['BookSHA256'],
             'AllCodeSHA256': pub['AllCodeSHA256'], 'OwnIdentitiesTerminal': own['OwnIdentityCount'],
             'ForcedTerminationUsed': own['ForcedTerminationUsed'],
             'DataCellsPreserved': accepted['SourceDataCellsPreserved'],
             'RealUiChoices': 6, 'RepeatedSwitches': 120,
             'FreshProtectedSwitches': 4, 'OfficePlatform': 'x86',
             'UserReportedOOMInTest': True, 'UnlimitedSessionGuarantee': False,
             'HistoricalFailuresPreserved': True, 'VbaCacheResetUsed': False,
             'EvidenceArchiveSHA256': sha(archive)}
write(e / 'Processed.json', processed)

report = f'''# Переключение иллюстраций и время формирования сечения — 31.10.2026

Основная книга обновлена обычным Copy/Paste иллюстраций; пользовательские данные, результаты, исходные рисунки и оформление сохранены. Сборщик воспроизводит эти изменения и добавляет общую иллюстрацию только на «Сечения». Принят адресный состав; полный расчётный ON/OFF-набор в этой задаче не запускался и не заявляется пройденным.

## Поведение книги

`modSectionIllustrations.SwitchSectionPicture` копирует именованный рисунок из ThisWorkbook и пропорционально вписывает его в постоянные внешние габариты обычного CurrentSection. Картинка заменяется только после успешной подготовки; при временной занятости буфера допускаются три попытки. Восстанавливаются лист, выделение, ScreenUpdating и EnableEvents. Calculation и расчётные таблицы не меняются. DoEvents после возврата состояния позволяет Excel обработать отложенные события и графику. Нет связанной камеры, обновления при открытии и переходе на лист. K2 содержит непосредственное перечисление четырёх имён, без служебных ячеек.

Сборщик использует Names/Default для выбираемых PNG, Additional — для Общие_иллюстрации.png только на «Сечения». Раскладка взята из сохранённой пользовательской книги. Все пять пользовательских исходных рисунков обновлённой книги побайтно сохранены. Чистая сборка использует все пять PNG проекта побайтно; исходная общая картинка сохранённой книги имеет иную кодировку PNG и сохраняется отдельно от проектного файла.

## Время формирования

На одной сохранённой копии полное формирование с камерой занимало 5,343 / 4,759 / 4,737 с; удаление только камеры в памяти дало 0,446 / 0,545 / 0,501 с при тех же 95 бетонных элементах и 28 стержнях. Рабочее ядро, рецепты и математические исходники не менялись.

Дополнительное сравнение опубликованной c34e9987, пользовательской камеры и первого варианта обычного рисунка при одинаковых входах. Медианы штатного FormSectionForWorkbook включают запись Results и схему:

| Тип | c34e9987, с | Камера, с | Обычный рисунок, с |
|---|---:|---:|---:|
| Rectangles | 0,562 | 5,029 | 0,461 |
| Circle | 0,487 | 4,665 | 0,357 |
| PointedSection | 1,049 | 5,199 | 0,950 |
| HollowRectangle | 0,593 | 5,288 | 0,721 |

Семь физических таблиц сравнивались полностью: 67 060 / 56 350 / 226 681 / 85 071 ячеек соответственно. Все строки и значения IEEE754 совпадают; исключён только явно именованный столбец RunID с временем запуска. Эти замеры относятся к промежуточной обычной картинке; конечная версия добавляет обработку временной занятости буфера и очереди событий. Финальная точная книга в свежем Excel: первое формирование 3,303 с, повторные 0,756 и 0,561 с. Холодное первое действие медленнее повторного; очистка кэша для ускорения или уменьшения книги не применялась.

## Проверки памяти и интерфейса

На компьютере установлен x86 Excel. В отклонённых вариантах тестов были Paste1004 после 37 замен, APPCRASH после 87 и рост памяти до 2,25 ГБ у варианта CopyPicture. Отдельный защищённый повтор остановлен на 84 заменах при пороге 900 МиБ. Эти результаты сохранены как FAIL; CopyPicture не публикуется.

Конечная обычная картинка с обработкой событий после восстановления состояния выполнила 120 замен, по 30 на тип, при одновременно открытых второй NDM и посторонней книге с совпадающими именами. Габариты, пропорции, количество объектов, активное выделение и общие флаги Excel проверены. Память выросла с 203 112 448 до 292 159 488 байт и к концу серии стабилизировалась около 280 МиБ. Это наблюдение поддерживает объяснение отложенной обработки графических ресурсов, но не доказывает внутренний механизм распределения памяти Excel.

После серии сам наблюдатель получил sharing violation UiLive.json; исходный отчёт всей попытки остаётся FAIL. Отдельная нативная UI-проверка той же точной книги прошла: клавиатурой раскрыты списки и фактически выбраны все четыре картинки, Config I4=cm и Сечения H40=IncludeStart; значения и Validation.Value подтверждены. Одна строка через запятую/точку с запятой, Unknown и общая иллюстрация отклоняются.

Пользователь сообщил ещё один Out of memory и уточнил, что окно относилось к тестовому Excel. Точный шаг этого диалога в завершающих журналах не записан; обычная пользовательская работа не была источником подтверждённого повторения. После сообщения выполнены только четыре защищённые замены свежей сборки с освобождением COM, проверкой свободной RAM/commit и пределом 900 МиБ. Повтор прошёл, все собственные процессы терминальны. Отсутствие ошибок при любой длительности сеанса не гарантируется.

## Сохранность и размер

Сохранены все 11 722 непустые ячейки пользовательской книги: значения, формулы, стили, проверки данных, имена и адреса областей печати, размеры строк/столбцов и объединения. Проверены 176 исходных / 182 экспортированных VBA-компонента как в обновлённой книге, так и в сохранённой чистой сборке. AllCode соответствует точному нативному экспорту. Пользовательские результаты не пересчитывались при публикации.

Размер основной книги: {before:,} → {after:,} байт (−{size['ReductionPercent']:.2f}%). Удалены только технические части связанной камеры и её дублирующиеся кэшированные представления; рабочий код, тесты, справка, исходные PNG и данные сохранены. Свежая чистая сборка — {size['FreshBuildBytes']:,} байт, включая новую общую PNG. Большого дополнительного уменьшения без отвергнутой пользователем очистки VBA-кэша не достигнуто; этот способ и переупаковка ZIP в сборщик не включены.

## Артефакты

Основная книга SHA256 `{pub['BookSHA256']}`; AllCode `{pub['AllCodeSHA256']}`. Чистая контрольная сборка SHA256 `1DEBC29380E91708E5EE1986E1ECE66FAE61433FC957C1F093F286F8AEEE69E8`.

Все {own['OwnIdentityCount']} собственных идентичностей терминальны. Одно фактическое принудительное закрытие тестового Excel после Out of memory сохранено отдельной квитанцией; остальные исходы не названы принудительными без доказательства. Пользовательские приложения не закрывались. Полный резерв основной книги и AllCode сохранён в частном каталоге BeforePublication.

Компактные доказательства: `docs/regression/SectionFormationReliability_2026-10-31_Run01/Processed.json`, Manifest.json и ReviewedDirectedEvidence.zip. Ветка `codex/section-illustrations`; main не менялась. Состояние отправки фиксируется отдельной квитанцией после push и независимого ls-remote.
'''
(r / 'docs/reports/SectionFormationReliability_2026-10-31.md').write_text(report, encoding='utf-8')
progress = r / 'docs/geometry_refactor/PROGRESS.md'
text = progress.read_text('utf-8-sig')
entry = '''## 31.10.2026 — Обычные иллюстрации и устранение задержки формирования

Связанная камера заменена обычным Copy/Paste с сохранением рамки и состояния Excel. Полное формирование Г-сечения в открытой книге вернулось примерно с 5 с к 0,5–0,8 с; семь таблиц всех четырёх типов совпали точно кроме даты RunID. В точной конечной книге первое действие 3,303 с, повторные 0,756/0,561 с. Приняты 120 замен при нескольких книгах (около 280 МиБ к концу), отдельные шесть реальных UI-выборов и четыре защищённые замены чистой сборки. Неуспешные попытки и пользовательский Out of memory в тестовом Excel сохранены; универсальная гарантия памяти не заявляется. Все 176/182 компонента и 11 722 ячейки сохранены. Сборщик добавляет общую PNG только на «Сечения», размер основной книги уменьшен на 9,82% без очистки VBA-кэша. Полного ON/OFF нет. [Отчёт](../reports/SectionFormationReliability_2026-10-31.md).

'''
assert '## 31.10.2026 — Обычные иллюстрации и устранение задержки формирования' not in text
first, rest = text.split('\n', 1)
progress.write_text(first + '\n\n' + entry + rest.lstrip('\n'), encoding='utf-8')
print(json.dumps(processed, ensure_ascii=False))
