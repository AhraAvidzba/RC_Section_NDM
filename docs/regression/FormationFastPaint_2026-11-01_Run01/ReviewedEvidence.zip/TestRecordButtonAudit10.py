"""ДЛЯ ТЕСТОВ: фиксирует проверку всех назначенных кнопок и границы нативной проверки AutoCAD."""
from pathlib import Path
import hashlib
import json
import re

P = Path(__file__).resolve().parent
R = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
build = (R/'tools/build_workbook/Build-Workbook.ps1').read_text(encoding='utf-8-sig')
actions = re.findall(r'\.OnAction\s*=\s*"(\w+)"', build)
assert sorted(actions) == sorted(['RunSectionCalculation', 'FormSection', 'ClearAutoCADDrawing', 'ExportSectionStressToAutoCAD', 'UpdateSectionPlot'])
files = ['src/Excel/modWorkbookCalculation.bas', 'src/Excel/modCalculationSnapshot.bas',
         'src/Excel/modAutoCADStressExport.bas', 'src/Excel/modSectionIllustrations.bas',
         'src/Excel/CExcelAppStateGuard.cls', 'src/Excel/modWorkbookMessages.bas']
texts = {name: (R/name).read_text(encoding='utf-8-sig') for name in files}
cad = texts['src/Excel/modAutoCADStressExport.bas']
assert not re.search(r'ScreenUpdating\s*=|CExcelAppStateGuard|\.Calculate\b|\bSleep\b|\bWait\b', cad, re.I)
assert 'If Not hadLayers Then Exit Function' in cad
assert 'If DeleteAutoCADDocumentAnnotations > 0 Then doc.Regen 1' in cad
calculation = texts['src/Excel/modWorkbookCalculation.bas']
clear = calculation.split('Public Sub ClearSectionResultsForWorkbook(', 1)[1].split('End Sub', 1)[0]
assert not re.search(r'ScreenUpdating|CExcelAppStateGuard|\.Calculate\b', clear, re.I)
assert not re.search(r'ScreenUpdating\s*=', texts['src/Excel/modSectionIllustrations.bas'], re.I)
result = dict(Status='ALL_FIVE_BUILDER_BUTTON_ACTIONS_AUDITED', Actions=actions,
    ScreenPreserved=['FormSection', 'RunSectionCalculation', 'UpdateSectionPlot'],
    NoExcelScreenToggle=['ExportSectionStressToAutoCAD', 'ClearAutoCADDrawing', 'ClearSectionResults', 'SwitchSectionPicture'],
    AutoCADCleanup=dict(NoLayersSkipsModelSpace=True, RegenOnlyAfterActualDeletion=True),
    AutoCADValidation='Existing fake-document consumer tests, no native DWG timing or native AutoCAD acceptance claimed',
    NonButtonAdministrativeGuard='modSectionRecipeSetup.UpdateSectionRecipeTypes retains default guard; not assigned to a workbook button',
    NoFullCalculationFromExportOrCleanup=True, UserDrawingsTouched=False,
    SourceSHA256={name: hashlib.sha256((R/name).read_bytes()).hexdigest().upper() for name in files},
    FullOnOffPerformed=False)
(P/'ButtonAudit10.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(result['Status'])
