﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет полный штатный вход сохранённой книги после открытия, без тестовых модулей и вставленных таймеров.
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$out=Join-Path $p 'FinalSavedPerformance08'
if(Test-Path -LiteralPath $out){throw 'Fresh final performance directory required'}
[void][IO.Directory]::CreateDirectory($out)
$source=Join-Path $p 'Prepared08/Main/RC_Section_NDM.xlsm';$before=(Get-FileHash -LiteralPath $source).Hash
$path=Join-Path $out 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath $source -Destination $path
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestFinalPaintOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false;$samples=@()
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestFinalPaintOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o');SourceSHA256=$before}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$true;$app.DisplayAlerts=$false;$app.EnableEvents=$true;$app.AutomationSecurity=1;$app.ScreenUpdating=$true
 $book=$app.Workbooks.Open($path,0,$false);$book.Worksheets.Item('Расчет').Activate()
 if($book.VBProject.VBComponents.Count -ne 187){throw 'Unexpected/test component in saved book'}
 for($i=0;$i -lt 13;$i++){
  $timer=[Diagnostics.Stopwatch]::StartNew();$message=[string]$app.Run("'$($book.Name)'!modWorkbookCalculation.FormSectionForWorkbook",$book);$timer.Stop()
  if($message -notmatch 'Бетонных элементов: 95\.' -or $message -notmatch 'Стержней арматуры: 28\.' -or $message -match 'Схема не обновлена|Предупреждение:'){throw $message}
  $match=[regex]::Match($message,'Время формирования сечения: ([0-9.,]+) с\.');if(-not $match.Success){throw 'No native action time'}
  $native=[double]::Parse($match.Groups[1].Value.Replace(',','.'),[Globalization.CultureInfo]::InvariantCulture)
  $samples+=,[ordered]@{Index=$i;Cold=($i -eq 0);Warmup=($i -lt 3);ExternalSeconds=$timer.Elapsed.TotalSeconds;ReportedSeconds=$native;Message=$message}
  $samples|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'Samples.json') -Encoding UTF8
  Write-Output ('SAVED_FORM '+$i+' native='+$native+' external='+[math]::Round($timer.Elapsed.TotalSeconds,4))
 }
 [ordered]@{Status='SAVED_REOPEN_FULL_FORMATION_MEASURED';WorkbookSHA256=$before;Components=187;NoProfilingCode=$true;Samples=13;FullAcceptanceClaim=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'Complete.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
if((Get-FileHash -LiteralPath $source).Hash -ne $before){throw 'Prepared source workbook changed'}
