"""ДЛЯ ТЕСТОВ: обновляет только VBA трёх книг, сохраняя точные пользовательские ZIP-компоненты."""
from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def codes(parts):
    result={}
    for name,data in parts.items():
        if name=='xl/workbook.xml' or (name.startswith('xl/worksheets/sheet') and name.endswith('.xml')):
            x=ET.fromstring(data);prop=x.find('{*}workbookPr') if name=='xl/workbook.xml' else x.find('{*}sheetPr')
            result[name]=None if prop is None else prop.get('codeName')
    return result
build=json.loads((P/'CodeDonor10/Build.json').read_text(encoding='utf-8-sig'))
with zipfile.ZipFile(P/'CodeDonor10/RC_Section_NDM.xlsm') as z:donor={n:z.read(n) for n in z.namelist()}
cases=[('Clean',P/'Prepared08/Clean/RC_Section_NDM.xlsm','51378F8C21D3E35961E34B17C77A2E0F5A94FECF43B11DE538CD290CA7FDFE83'),
 ('Main',R/'workbook/output/RC_Section_NDM.xlsm',build['SourceSHA256']),
 ('Heavy',R/'workbook/output/NDM_HeavyCircle_1232_30_2026-11-01/RC_Section_NDM_HeavyCircle_1232_30.xlsm','FCAD6936758B8EBEBC5BDD6DED9CF47CC92EB8A6A761897F9DB15785684946FE')]
records=[]
for label,source,expected in cases:
    assert digest(source)==expected,(label,'Source changed; preserve new user data')
    directory=P/'Prepared10'/label;directory.mkdir(parents=True,exist_ok=False)
    target=directory/source.name
    with zipfile.ZipFile(source) as old:
        before={n:old.read(n) for n in old.namelist()}
        assert codes(before)==codes(donor),label
        assert not any('signature' in n.lower() for n in before)
        with zipfile.ZipFile(target,'w') as new:
            for info in old.infolist():new.writestr(info,donor[info.filename] if info.filename=='xl/vbaProject.bin' else before[info.filename])
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(before)
        assert [n for n,v in before.items() if z.read(n)!=v]==['xl/vbaProject.bin']
    records.append(dict(Label=label,Source=str(source),SourceSHA256=expected,Prepared=str(target),PreparedSHA256=digest(target),
        OnlyVBAChanged=True,UnchangedParts=len(before)-1,DataResultsPicturesSettingsAndLayoutByteExact=True,DocumentCodeNamesEqual=True))
(P/'PreparedOutputs10.json').write_text(json.dumps(dict(Status='PREPARED_NATIVE_REOPEN_REQUIRED',Books=records),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(records,ensure_ascii=False))
