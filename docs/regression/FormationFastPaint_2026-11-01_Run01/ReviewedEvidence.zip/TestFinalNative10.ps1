﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет сохранённый код трёх книг и окончательный замер, не запуская полный набор.
$ErrorActionPreference='Stop'
$p=$PSScriptRoot;$ps='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
$python='C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$readonly=Join-Path $p 'TestReadOnlyOutput10.ps1'
function TestOwn {
 & $ps -NoProfile -ExecutionPolicy Bypass -File (Join-Path $p 'TestAllOwn08.ps1')
 if($LASTEXITCODE -ne 0){throw 'Own closure verification failed'}
}
TestOwn
& $python -X utf8 (Join-Path $p 'TestPrepareOutputs10.py')
if($LASTEXITCODE -ne 0){throw 'Only-VBA package preparation failed'}
foreach($label in 'Clean','Main','Heavy'){
 TestOwn
 $name='RC_Section_NDM.xlsm';if($label -eq 'Heavy'){$name='RC_Section_NDM_HeavyCircle_1232_30.xlsm'}
 & $ps -NoProfile -ExecutionPolicy Bypass -File $readonly -WorkbookPath (Join-Path $p ('Prepared10/'+$label+'/'+$name)) -OutputDirectory (Join-Path $p ($label+'Native10'))
 if($LASTEXITCODE -ne 0){throw ('Native saved reopen failed '+$label)}
 & $python -X utf8 (Join-Path $p 'TestVerifySource10.py') --export (Join-Path $p ($label+'Native10/VBA_All_Code.txt')) --report (Join-Path $p ($label+'Native10/SourceEquality.json'))
 if($LASTEXITCODE -ne 0){throw ('Source equality failed '+$label)}
}
TestOwn
Write-Output 'FINAL_SAVED_CALCULATION_SOURCE_COMPLETE'
