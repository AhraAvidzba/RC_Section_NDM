"""ДЛЯ ТЕСТОВ: сопоставляет реальные модули до/после точечного обновления, сохраняя чужой VBA."""
from pathlib import Path
import sys,importlib,json,argparse
P=Path(__file__).resolve().parent
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
sys.path.insert(0,str(R/'tools/build_workbook'))
check=importlib.import_module('Verify-CalculationSnapshotRelease')
a=argparse.ArgumentParser();a.add_argument('--export',type=Path,required=True);a.add_argument('--before',action='store_true');a.add_argument('--report',type=Path,required=True);args=a.parse_args()
components=check.exported_components(args.export);errors=[]
sources=[*R.glob('src/**/*.cls'),*R.glob('src/**/*.bas'),*R.glob('tests/**/*.cls'),*R.glob('tests/**/*.bas')]
for file in sources:
    expected=P/'BeforeCalculation10'/file.name
    if not args.before or not expected.exists():expected=file
    native=components.get(file.stem)
    if native is None or check.normalized_vba(check.source_body(expected))!=check.normalized_vba(native[1]):errors.append(str(file.relative_to(R)))
docs=[(name,body) for name,(kind,body) in components.items() if kind==100]
events=check.normalized_vba((R/'tools/build_workbook/WorkbookHelpEvents.vba').read_text(encoding='utf-8-sig'))
if len(docs)!=6 or not any(check.normalized_vba(body)==events for _,body in docs):errors.append('Document event mismatch')
if set(components)!={f.stem for f in sources}|{name for name,_ in docs}:errors.append('Unexpected/missing module')
result=dict(Status='FAIL' if errors else 'PASS',ExpectedVersion='BeforeCalculation10' if args.before else 'CurrentSource',SourceComponents=len(sources),DocumentComponents=len(docs),Errors=errors)
args.report.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False));raise SystemExit(bool(errors))
