﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Запускает только затронутые регрессии хранилища и представления в частных книгах No/Yes.
param([int]$Attempt=1)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM';$out=Join-Path $p ('DirectedCalculation10_Attempt'+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh directed directory required'}
[void][IO.Directory]::CreateDirectory($out)
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestDirectedOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=@()
foreach($mode in 'No','Yes'){
 $os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
 $dir=Join-Path $out $mode;[void][IO.Directory]::CreateDirectory($dir)
 $path=Join-Path $dir 'Directed.xlsm';Copy-Item -LiteralPath (Join-Path (Split-Path $p) 'IndexedFormationFix_2026-11-01_Run01/Prepared/Clean/RC_Section_NDM.xlsm') -Destination $path
 $app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
 $existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
 try{
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][NDMTestDirectedOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
  if($existing -contains [int]$id){throw 'Existing Excel refused'}
  $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;Mode=$mode;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $dir 'Own.json') -Encoding UTF8
  $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
  $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135
  foreach($relative in @('src/Excel/CExcelAppStateGuard.cls','src/Excel/CNDMResultsWriter.cls','src/Excel/CSectionPlotDataReader.cls','src/Excel/modWorkbookCalculation.bas','src/Excel/modCalculationSnapshot.bas','tests/CTestExcelApplicationState.cls','tests/CTestWorkflowWorkbook.cls','tests/modTestWorkbookInterface.bas')){
   $file=Get-Item -LiteralPath (Join-Path $root $relative)
   $component=$null;try{$component=$book.VBProject.VBComponents.Item($file.BaseName)}catch{}
   if(-not $component){$kind=1;if($file.Extension -eq '.cls'){$kind=2};$component=$book.VBProject.VBComponents.Add($kind);$component.Name=$file.BaseName}
   $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
   if($file.Extension -eq '.cls'){$code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')}else{$code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')}
   if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
   $component.CodeModule.AddFromString($code)
  }
  $app.VBE.ActiveVBProject=$book.VBProject;$app.VBE.CommandBars.FindControl(1,578).Execute()
  $settings=$book.Names.Item('rngSystemSettings').RefersToRange
  for($row=1;$row -le $settings.Rows.Count;$row++){if([string]$settings.Cells.Item($row,1).Value2 -eq 'General.DiagramExtension'){$settings.Cells.Item($row,2).Value2=$mode}}
  $settings=$null
  foreach($macro in 'modTestWorkbookInterface.RunTestCalculationFreshnessWorkflow','modTestWorkbookInterface.RunSectionWorkflowCalculationTests','modTestSectionWorkflow.RunWorkflowSnapshotTests','modTestWorkbookInterface.RunExcelGuardWorkflowTests','modTestCalculationSnapshot.RunCalculationSnapshotTests','modTestSectionWorkflow.RunCleanupLayerPreflightTests','modTestAutoCADConfig.RunAudit03AutoCADConfigTests'){
   # Каждый адресный набор начинает с источника Excel; File-сценарии выбирают файл сами.
   # Иначе предыдущий preview-тест оставляет File и следующий sheet-fixture читает его файл.
   $settings=$book.Names.Item('rngSystemSettings').RefersToRange
   for($row=1;$row -le $settings.Rows.Count;$row++){if([string]$settings.Cells.Item($row,1).Value2 -eq 'Results.SnapshotStorage'){$settings.Cells.Item($row,2).Value2='Excel'}}
   $settings=$null
   Write-Output ('START '+$mode+' '+$macro)
   $started=[DateTime]::UtcNow;$result=[string]$app.Run("'$($book.Name)'!"+$macro)
   $result|Set-Content (Join-Path $dir (($macro.Split('.')[-1])+'.txt')) -Encoding UTF8
   $fail=[regex]::IsMatch($result,'(?im)^FAIL|failed=[1-9]')
   $records+=,[ordered]@{Mode=$mode;Macro=$macro;StartedUTC=$started.ToString('o');FinishedUTC=[DateTime]::UtcNow.ToString('o');Failed=$fail}
   $records|ConvertTo-Json|Set-Content (Join-Path $out 'Run.json') -Encoding UTF8
   Write-Output (($result -split '[\r\n]+'|Where-Object {$_ -match '^FAIL|^TOTAL'}) -join [Environment]::NewLine)
   if($fail){throw ('Directed failed: '+$macro)}
  }
 }catch{
  $_.Exception.ToString()|Set-Content (Join-Path $dir 'Error.txt') -Encoding UTF8
  throw
 }finally{
  if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
  $component=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
  [GC]::Collect();[GC]::WaitForPendingFinalizers()
  [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $dir 'Quit.json') -Encoding UTF8
 }
}
[ordered]@{Status='PASS_AFFECTED_FORMATION_FAST_PAINT_NO_YES';Records=$records.Count;FullAcceptanceClaim=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'Complete.json') -Encoding UTF8
