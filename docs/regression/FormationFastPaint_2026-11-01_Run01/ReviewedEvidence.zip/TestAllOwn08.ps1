﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Сверяет все исторические собственные Excel по PID и UTC-startTicks; ничего не закрывает.
$ErrorActionPreference='Stop'
$files=@(Get-ChildItem -Recurse -File -LiteralPath $PSScriptRoot -Filter Own.json)
$records=@()
foreach($file in $files){
 $own=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json
 $expected=[string]$own.UTCStartTicks;if(-not $expected){$expected=[string]$own.StartTicksUTC}
 if([int]$own.PID -le 0 -or -not $expected){throw ('Invalid own proof '+$file.FullName)}
 $cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$own.PID)
 $state='Unknown';$actual='';$exe='';$created=''
 if(-not $cim){$state='ConfirmedNotFound'}else{
  $exe=[string]$cim.Name;$created=[string]$cim.CreationDate
  if($exe -ine 'EXCEL.EXE'){$state='PIDReusedDifferentExecutable'}else{
   $process=Get-Process -Id ([int]$own.PID) -ErrorAction Stop
   $actual=[string]$process.StartTime.ToUniversalTime().Ticks
   if($actual -eq $expected){$state='ExactAlive'}else{$state='PIDReusedDifferentStart'}
  }
 }
 $records+=,[ordered]@{Proof=$file.FullName;PID=[int]$own.PID;UTCStartTicks=$expected;State=$state;ObservedTicks=$actual;CIMExecutable=$exe;CIMCreation=$created}
}
$bad=@($records|Where-Object {$_.State -in @('Unknown','ExactAlive')})
[ordered]@{Status=$(if($bad.Count){'REVIEW_REQUIRED'}else{'ALL_OWN_TERMINAL'});ObservedUTC=[DateTime]::UtcNow.ToString('o');Processes=$records}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot 'AllOwnClosures08.json') -Encoding UTF8
Write-Output ('Own reviewed='+$records.Count+'; remaining='+$bad.Count)
if($bad.Count){$bad|ConvertTo-Json -Depth 4;throw 'Some exact own identities remain live or unknown'}
