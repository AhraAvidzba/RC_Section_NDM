"""ДЛЯ ТЕСТОВ: добавляет таймеры только в частную копию расчётного входа."""
from pathlib import Path
import json

P = Path(__file__).resolve().parent
R = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
code = (R/'src/Excel/modWorkbookCalculation.bas').read_text(encoding='utf-8-sig')
start = code.index('Private Function CalculateSectionCore(')
end = code.index('\nEnd Function', start) + len('\nEnd Function')
body = code[start:end]
replacements = {
    '    excelGuard.Enter workbook.Application\n': '    excelGuard.Enter workbook.Application, modTestCalculationTiming.TestKeepScreen\n    modTestCalculationTiming.TestMark "Enter"\n',
    '    Dim reader As CLoadCombinationReader:': '    modTestCalculationTiming.TestMark "InputCalculate"\n    Dim reader As CLoadCombinationReader:',
    '    batch.Execute\n': '    modTestCalculationTiming.TestMark "Preparation"\n    batch.Execute\n    modTestCalculationTiming.TestMark "Batch"\n',
    '    savedSnapshot.Validate\n': '    savedSnapshot.Validate\n    modTestCalculationTiming.TestMark "Capture"\n',
    '    plotWarning = SaveAndDisplayCalculationSnapshot(workbook, savedSnapshot, plotHasWarning)\n': '    plotWarning = SaveAndDisplayCalculationSnapshot(workbook, savedSnapshot, plotHasWarning)\n    modTestCalculationTiming.TestMark "SaveAndDisplay"\n',
    '    CalculateResultsSheet workbook\n': '    modTestCalculationTiming.TestMark "MessageAndReport"\n    CalculateResultsSheet workbook\n    modTestCalculationTiming.TestMark "ResultsCalculate"\n',
    '    excelGuard.Restore True\n    savedDestination': '    excelGuard.Restore True\n    modTestCalculationTiming.TestMark "Restore"\n    savedDestination',
}
for old, new in replacements.items():
    assert body.count(old) == 1, old
    body = body.replace(old, new)
out = P/'CalculationBench09'
out.mkdir(exist_ok=False)
(out/'modWorkbookCalculation.bas').write_text(code[:start]+body+code[end:], encoding='utf-8-sig')
(out/'Preparation.json').write_text(json.dumps(dict(PrivateOnly=True, ProductionStatementsChanged=['ScreenUpdating policy selected by test flag'],
    PhaseTimers=7, SolverMathChanged=False, FullOnOffPerformed=False), indent=2), encoding='utf-8')
