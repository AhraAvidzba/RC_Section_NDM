"""ДЛЯ ТЕСТОВ: проверяет фазовые замеры расчёта, полные таблицы и точные RGB схемы."""
from pathlib import Path
import hashlib
import json
import statistics
from PIL import Image

P = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


records = []
for kind, folder, selected in [
    ('Light', P/'CalculationBench09/Light', ['Excel']),
    ('Light', P/'CalculationBench10/Light', ['File']),
    ('Heavy', P/'CalculationBench10/Heavy', ['Excel', 'File']),
]:
    samples = load(folder/'Samples.json')
    # Execute обнуляет счётчик перед каждым пакетом. В первоначальном helper поле
    # SolverCalls записывало разность с предыдущим пакетом, а не итог пакета.
    # В новом процессе счётчик нулевой; сумма последовательных разностей восстанавливает итог.
    after = 0
    for sample in samples:
        if sample['Mode'] not in selected:
            continue
        assert not sample['Result'].startswith('ERROR|'), sample
        metrics = dict(part.split('=', 1) for part in sample['Result'].split('|'))
        after += int(metrics['SolverCalls'])
        assert after == (3 if kind == 'Light' else 30), (kind, sample)
        assert metrics['ReadReleased'] == 'True'
        sample['Metrics'] = metrics
        sample['ActualSolverCallsAfterResetDerived'] = after
    for mode in selected:
        group = [sample for sample in samples if sample['Mode'] == mode]
        assert len(group) == 9
        baseline = [sample for sample in group if sample['Variant'].startswith('Baseline')]
        candidate = [sample for sample in group if sample['Variant'].startswith('Candidate')]
        assert len(baseline) == len(candidate) == 4
        checks = []
        reference = Image.open(folder/(mode+'_Baseline.png')).convert('RGB')
        for variant in ['Baseline', 'Candidate', 'CandidateAgain', 'BaselineAgain']:
            parity = (folder/(mode+'_'+variant+'_Parity.txt')).read_text(encoding='utf-8-sig').strip()
            assert parity.startswith('PASS|Capture=False|'), parity
            picture = Image.open(folder/(mode+'_'+variant+'.png')).convert('RGB')
            assert picture.size == reference.size and picture.tobytes() == reference.tobytes(), (kind, mode, variant)
            checks.append(dict(Variant=variant, EntireTableComparison=parity,
                               RGBSHA256=hashlib.sha256(picture.tobytes()).hexdigest().upper()))
        records.append(dict(Kind=kind, Mode=mode,
            BeforeMedianSeconds=statistics.median(float(sample['Metrics']['Total']) for sample in baseline),
            AfterMedianSeconds=statistics.median(float(sample['Metrics']['Total']) for sample in candidate),
            BeforeRestoreSeconds=statistics.median(float(sample['Metrics']['Restore']) for sample in baseline),
            AfterRestoreSeconds=statistics.median(float(sample['Metrics']['Restore']) for sample in candidate),
            SamplesPerVariant=4, AllSevenPhysicalTablesExactExceptRunID=True,
            RGBPixelExact=True, ActualSolverCallsPerRun=(3 if kind == 'Light' else 30),
            Inputs='DIRECT test profiles and distinct test loads; authentic saved geometry',
            Checks=checks, RawSamples=group))
result = dict(Status='PASS_LIGHT_HEAVY_FULL_BUTTON_PHASE_PARITY', Measurements=records,
    RepeatedCalculationActuallyExecuted=True, NoCrossRunSolverReuseClaim=True,
    CounterClarification='Raw SolverCalls is a difference across counters reset by Execute; cumulative deltas recover 3/30 actual calls. Future helper writes final count directly.',
    FullOnOffPerformed=False, FullAcceptanceClaim=False)
(P/'CalculationReview10.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps([dict(Kind=item['Kind'], Mode=item['Mode'], Before=item['BeforeMedianSeconds'],
    After=item['AfterMedianSeconds'], RestoreBefore=item['BeforeRestoreSeconds'], RestoreAfter=item['AfterRestoreSeconds']) for item in records]))
