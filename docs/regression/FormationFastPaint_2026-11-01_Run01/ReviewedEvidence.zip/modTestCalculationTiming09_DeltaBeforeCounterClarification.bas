Attribute VB_Name = "modTestCalculationTiming"
Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Профилирует полный штатный расчёт частной копии, меняя только управление экраном.
Private Declare PtrSafe Function TestQpc Lib "kernel32" Alias "QueryPerformanceCounter" (ByRef value As Currency) As Long
Private Declare PtrSafe Function TestQpf Lib "kernel32" Alias "QueryPerformanceFrequency" (ByRef value As Currency) As Long
Public TestKeepScreen As Boolean
Private mTestLast As Double
Private mTestTimes As String
Private mTestExpected As Object

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Монотонный таймер Windows, одинаковый для двух вариантов.
Private Function TestNow() As Double
    Dim ticks As Currency, frequency As Currency
    TestQpc ticks: TestQpf frequency: TestNow = ticks / frequency
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует длительность предыдущего этапа без обращения к Excel.
Public Sub TestMark(ByVal label As String)
    Dim current As Double: current = TestNow()
    mTestTimes = mTestTimes & "|" & label & "=" & Replace$(Format$(current - mTestLast, "0.000000"), ",", ".")
    mTestLast = current
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет существующую настройку только в собственной тестовой книге.
Private Sub TestSetting(ByVal key As String, ByVal value As String)
    Dim target As Range, row As Long: Set target = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = key Then target.Cells(row, 2).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, , "Missing test setting " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Готовит три прямых НДС для Г-сечения либо тридцать на подлинной тяжёлой сетке без её генерации.
Public Function TestInit(ByVal kind As String) As String
    On Error GoTo Failed
    Dim count As Long, shape As String, message As String
    If kind = "Light" Then count = 3: shape = "Rectangles" Else count = 30: shape = "Saved"
    modTestPerformance.TestConfigurePerformanceFixture "DIRECT", count, "Newton", shape, "Normal", "No"
    TestSetting "General.ExecutionReportEnabled", "No": TestSetting "General.NonCriticalMessagesEnabled", "No"
    TestSetting "General.ReformatResultsEnabled", "No": TestSetting "Plot.Enabled", "Yes"
    TestSetting "Plot.AutoUpdateAfterCalculation", "Yes": TestSetting "Results.SnapshotStorage", "Excel"
    TestSetting "Results.SnapshotName", "TestCalculationTiming"
    TestSetting "Output.CombinationMode", "User": TestSetting "Output.CombinationID", "PERF_01"
    If kind = "Light" Then message = FormSectionForWorkbook(ThisWorkbook)
    TestInit = "OK|Kind=" & kind & "|LoadCases=" & CStr(count): Exit Function
Failed:
    TestInit = "ERROR|Init|" & CStr(Err.Number) & "|" & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Носитель переключается между опытами; результаты предыдущего расчёта уже сохранены.
Public Sub TestMode(ByVal mode As String)
    If mode = "File" Then
        Dim section As CSectionModel, properties As CSectionPropertiesCalculator, settings As New CSystemSettingsReader
        Dim writer As New CNDMResultsWriter, units As New CUnitSystem, store As New CCalculationSnapshotStore
        Set section = ReadFormedSectionFromResults(ThisWorkbook)
        Set properties = PrepareSectionSnapshot(section)
        settings.LoadFromWorkbook ThisWorkbook: units.LoadFromSettings settings
        store.SaveFile ThisWorkbook, writer.PrepareGeometryPreviewSnapshot(ThisWorkbook, section, properties, units)
    End If
    TestSetting "Results.SnapshotStorage", mode
    Set mTestExpected = Nothing
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Замеряет всю кнопку, включая освобождение модели и конечный показ.
Public Function TestRun(ByVal keepScreen As Boolean) As String
    On Error GoTo Failed
    TestKeepScreen = keepScreen
    Dim started As Double, message As String, solves As Long
    solves = SectionEquilibriumSolveCount(): started = TestNow(): mTestLast = started: mTestTimes = vbNullString
    message = RunSectionCalculationForWorkbook(ThisWorkbook)
    TestMark "FinishAndRelease"
    If InStr(message, "Расчет завершен") = 0 Then Err.Raise 5, , message
    TestRun = "Total=" & Replace$(Format$(TestNow() - started, "0.000000"), ",", ".") & mTestTimes & _
        "|SolverCalls=" & CStr(SectionEquilibriumSolveCount() - solves) & "|ReadReleased=" & CStr(TestCalculationSnapshotReadReleased())
    Exit Function
Failed:
    TestRun = "ERROR|Run|" & CStr(Err.Number) & "|" & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает все семь физических таблиц точно, исключая только дату RunID.
Public Function TestParity() As String
    On Error GoTo Failed
    Dim key As Variant, values As Variant, row As Long, cells As Double, capture As Boolean
    capture = mTestExpected Is Nothing
    If capture Then Set mTestExpected = CreateObject("Scripting.Dictionary")
    For Each key In Array("rngNDMSectionGeometry", "rngNDMSectionProperties", "rngNDMMaterialDiagrams", "rngNDMElementResults", "rngNDMSectionContours", "rngNDMSectionAnnotations", "rngNDMElementGeometry")
        values = modSectionSnapshot.ReadPhysicalResultTable(ThisWorkbook, CStr(key))
        If IsArray(values) Then
            If CStr(values(1, 1)) = "RunID" Then
                For row = 2 To UBound(values, 1): values(row, 1) = 0#: Next row
            End If
            cells = cells + CDbl(UBound(values, 1)) * CDbl(UBound(values, 2))
        End If
        If capture Then
            mTestExpected.Add CStr(key), values
        ElseIf Not SnapshotMatricesEqual(values, mTestExpected.Item(CStr(key))) Then
            Err.Raise 5, , "Numeric table mismatch: " & CStr(key)
        End If
    Next key
    TestParity = "PASS|Capture=" & CStr(capture) & "|Cells=" & CStr(cells): Exit Function
Failed:
    TestParity = "ERROR|Parity|" & CStr(Err.Number) & "|" & Err.Description
End Function
