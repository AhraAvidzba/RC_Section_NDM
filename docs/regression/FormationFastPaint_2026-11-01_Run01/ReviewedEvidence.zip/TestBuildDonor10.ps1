﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет текущую сохранённую книгу и обновляет только семь своих модулей в частной копии.
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM';$out=Join-Path $p 'CodeDonor10'
if(Test-Path -LiteralPath $out){throw 'Fresh donor directory required'}
[void][IO.Directory]::CreateDirectory($out)
$source=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$path=Join-Path $out 'RC_Section_NDM.xlsm'
$before=(Get-FileHash -LiteralPath $source).Hash;Copy-Item -LiteralPath $source -Destination $path
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestFastDonorOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
function TestExport([string]$name){
 $text=New-Object Text.StringBuilder
 [void]$text.AppendLine('VBA PROJECT EXPORT');[void]$text.AppendLine('Workbook: '+$book.Name);[void]$text.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
 for($i=1;$i -le $book.VBProject.VBComponents.Count;$i++){
  $item=$book.VBProject.VBComponents.Item($i);$lines=$item.CodeModule.CountOfLines
  [void]$text.AppendLine('='*100);[void]$text.AppendLine('COMPONENT: '+$item.Name);[void]$text.AppendLine('TYPE: '+$item.Type);[void]$text.AppendLine('LINES: '+$lines);[void]$text.AppendLine('='*100)
  if($lines){[void]$text.AppendLine($item.CodeModule.Lines(1,$lines))};[void]$text.AppendLine()
 }
 [IO.File]::WriteAllText((Join-Path $out $name),$text.ToString(),[Text.UTF8Encoding]::new($true))
}
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestFastDonorOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o');SourceSHA256=$before}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135
 TestExport 'BeforeVBA_All_Code.txt'
 & 'C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 (Join-Path $p 'TestVerifySource10.py') --export (Join-Path $out 'BeforeVBA_All_Code.txt') --before --report (Join-Path $out 'BeforeSourceEquality.json')
 if($LASTEXITCODE -ne 0){throw 'Existing workbook VBA contains unexpected manual differences; preserve it'}
 foreach($relative in @('src/Excel/CExcelAppStateGuard.cls','src/Excel/CNDMResultsWriter.cls','src/Excel/CSectionPlotDataReader.cls','src/Excel/modWorkbookCalculation.bas','src/Excel/modCalculationSnapshot.bas','tests/CTestExcelApplicationState.cls','tests/CTestWorkflowWorkbook.cls','tests/modTestWorkbookInterface.bas')){
  $file=Get-Item -LiteralPath (Join-Path $root $relative);$component=$book.VBProject.VBComponents.Item($file.BaseName)
  $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  if($file.Extension -eq '.cls'){$code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')}else{$code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')}
  $component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines);$component.CodeModule.AddFromString($code)
 }
 $app.VBE.ActiveVBProject=$book.VBProject;$app.VBE.CommandBars.FindControl(1,578).Execute()
 TestExport 'VBA_All_Code.txt'
 & 'C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 (Join-Path $p 'TestVerifySource10.py') --export (Join-Path $out 'VBA_All_Code.txt') --report (Join-Path $out 'SourceEquality.json')
 if($LASTEXITCODE -ne 0){throw 'Current source equality failed'}
 $book.Save()
 [ordered]@{Status='COMPILED_SOURCE_VERIFIED_PRIVATE_DONOR';SourceSHA256=$before;Components=$book.VBProject.VBComponents.Count;ChangedComponents=8}|ConvertTo-Json|Set-Content (Join-Path $out 'Build.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
if((Get-FileHash -LiteralPath $source).Hash -ne $before){throw 'Original workbook changed; take a fresh user-data base'}
