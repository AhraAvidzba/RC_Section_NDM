﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Экспортирует фактический VBA конечного файла при отключённых макросах, без сохранения.
param([Parameter(Mandatory=$true)][string]$WorkbookPath,[Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
if(Test-Path -LiteralPath $OutputDirectory){throw 'Fresh readonly output directory required'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
$before=(Get-FileHash $WorkbookPath).Hash
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestOutputOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestOutputOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 $book=$app.Workbooks.Open($WorkbookPath,0,$true)
 if(-not $book.ReadOnly){throw 'Readonly reopen required'}
 $buttons=@()
 foreach($sheet in $book.Worksheets){
  foreach($shape in $sheet.Shapes){
   $action='';try{$action=[string]$shape.OnAction}catch{}
   if($action){$buttons+=,[ordered]@{Sheet=$sheet.Name;Name=$shape.Name;Action=$action;FontSize=$shape.TextFrame.Characters().Font.Size}}
  }
 }
 $expected=@('RunSectionCalculation','FormSection','ClearAutoCADDrawing','ExportSectionStressToAutoCAD','UpdateSectionPlot')
 if($buttons.Count -ne 5){throw 'Unexpected button inventory'}
 foreach($name in $expected){if(@($buttons|Where-Object {($_.Action -split '!')[-1] -eq $name}).Count -ne 1){throw ('Button action missing '+$name)}}
 if(@($buttons|Where-Object {$_.FontSize -ne 9}).Count){throw 'Button font size changed'}
 $index=$book.Names.Item('rngNDMElementResultIndex').RefersToRange
 if($index.Address() -ne '$DL$156' -or $index.Worksheet.Name -ne 'Results' -or [string]$index.Value2 -ne 'IndexKind'){throw 'Saved index structure mismatch'}
 if([string]$index.Font.Name -ne 'Arial' -or $index.Font.Size -ne 9 -or -not $index.Font.Bold -or $index.Interior.Color -ne 14277081){throw 'Saved index header style mismatch'}
 if($book.Worksheets.Item('Справка').Shapes.Count -ne 78){throw 'Saved Help image inventory'}
 $text=New-Object Text.StringBuilder
 [void]$text.AppendLine('VBA PROJECT EXPORT');[void]$text.AppendLine('Workbook: '+$book.Name);[void]$text.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
 $components=[int]$book.VBProject.VBComponents.Count
 for($i=1;$i -le $components;$i++){
  $component=$book.VBProject.VBComponents.Item($i);$lines=$component.CodeModule.CountOfLines
  [void]$text.AppendLine('='*100);[void]$text.AppendLine('COMPONENT: '+$component.Name);[void]$text.AppendLine('TYPE: '+$component.Type);[void]$text.AppendLine('LINES: '+$lines);[void]$text.AppendLine('='*100)
  if($lines){[void]$text.AppendLine($component.CodeModule.Lines(1,$lines))};[void]$text.AppendLine()
 }
 [IO.File]::WriteAllText((Join-Path $OutputDirectory 'VBA_All_Code.txt'),$text.ToString(),[Text.UTF8Encoding]::new($true))
 [ordered]@{Status='PASS_READONLY_NATIVE_OUTPUT';WorkbookSHA256=$before;Components=$components;HelpPictures=78;IndexAnchor='Results!DL156';IndexStyle='Arial9/Grey217/Border200';MacrosDisabled=$true;Buttons=$buttons}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'Native.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;$index=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'Quit.json') -Encoding UTF8
}
if((Get-FileHash $WorkbookPath).Hash -ne $before){throw 'Readonly verification changed workbook'}
Write-Output ('Readonly output accepted: '+$components+' components')
