"""ДЛЯ ТЕСТОВ: читает все первичные журналы окончательной адресной проверки No/Yes."""
from pathlib import Path
import hashlib
import json
import re

P = Path(__file__).resolve().parent
macros = dict(RunTestCalculationFreshnessWorkflow=371,
    RunSectionWorkflowCalculationTests=116, RunWorkflowSnapshotTests=151,
    RunExcelGuardWorkflowTests=55, RunCalculationSnapshotTests=1001,
    RunCleanupLayerPreflightTests=4, RunAudit03AutoCADConfigTests=1243)
records = []
for mode in ['No', 'Yes']:
    for macro, expected in macros.items():
        path = P/'DirectedCalculation10_Attempt2'/mode/(macro+'.txt')
        raw = path.read_bytes()
        text = raw.decode('utf-8-sig')
        assert not re.search(r'(?im)^FAIL|failed=[1-9]', text), str(path)
        assert re.findall(r'(?m)^TOTAL[^\r\n]*passed=(\d+); failed=(\d+)', text) == [(str(expected), '0')]
        records.append(dict(Mode=mode, Macro=macro, Passed=expected, Failed=0,
            EntirePrimaryRead=True, Bytes=len(raw), SHA256=hashlib.sha256(raw).hexdigest().upper()))
assert sum(item['Passed'] for item in records) == 5882
result = dict(Status='PASS_FINAL_CALCULATION_AND_OTHER_BUTTON_CONSUMERS_NO_YES',
    Invocations=14, AssertionsPassed=5882, AssertionsFailed=0, Records=records,
    NativeAutoCADPerformed=False, FullOnOffPerformed=False, FullAcceptanceClaim=False)
(P/'DirectedFinalReview10.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(result['Status'])
