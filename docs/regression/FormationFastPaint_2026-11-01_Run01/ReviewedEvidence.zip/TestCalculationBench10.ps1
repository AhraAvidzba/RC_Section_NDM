﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Сравнивает полный расчёт при двух политиках экрана на лёгкой и тяжёлой сетках в собственных Excel.
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestCalcOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
foreach($kind in 'Light','Heavy'){
 $out=Join-Path $p ('CalculationBench10/'+$kind);[void][IO.Directory]::CreateDirectory($out)
 $source=Join-Path $p 'Prepared08/Main/RC_Section_NDM.xlsm'
 if($kind -eq 'Heavy'){$source=Join-Path $p 'Prepared08/Heavy/RC_Section_NDM_HeavyCircle_1232_30.xlsm'}
 $before=(Get-FileHash -LiteralPath $source).Hash
 $path=Join-Path $out 'TestCalculation.xlsm';Copy-Item -LiteralPath $source -Destination $path
 $os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
 $existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
 $app=$null;$book=$null;$own=0;$ticks=0;$quit=$false;$samples=@()
 try{
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][NDMTestCalcOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
  if($existing -contains [int]$id){throw 'Existing Excel refused'}
  $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o');Kind=$kind}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
  $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$true
  $book=$app.Workbooks.Open($path,0,$false)
  $component=$book.VBProject.VBComponents.Add(1);$component.Name='modTestCalculationTiming'
  $code=[IO.File]::ReadAllText((Join-Path $p 'modTestCalculationTiming.bas'),[Text.Encoding]::UTF8)
  $component.CodeModule.AddFromString(([regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')))
  $component=$book.VBProject.VBComponents.Item('modWorkbookCalculation')
  $code=[IO.File]::ReadAllText((Join-Path $p 'CalculationBench10/modWorkbookCalculation.bas'),[Text.Encoding]::UTF8)
  $component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)
  $component.CodeModule.AddFromString(([regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')))
  $app.VBE.ActiveVBProject=$book.VBProject;$app.VBE.CommandBars.FindControl(1,578).Execute()
  $result=[string]$app.Run("'$($book.Name)'!modTestCalculationTiming.TestInit",$kind)
  $result|Set-Content (Join-Path $out 'Init.txt') -Encoding UTF8
  Write-Output ($kind+' '+$result);if($result.StartsWith('ERROR|')){throw $result}
  $app.Visible=$true;$app.EnableEvents=$true;$book.Worksheets.Item('Расчет').Activate()
  $modes=@('Excel','File');if($kind -eq 'Light'){$modes=@('File')};foreach($mode in $modes){
   [void]$app.Run("'$($book.Name)'!modTestCalculationTiming.TestMode",$mode)
   $index=0
   foreach($variant in 'Warmup','Baseline','Candidate','CandidateAgain','BaselineAgain'){
    $runs=2;if($variant -eq 'Warmup'){$runs=1}
    for($i=0;$i -lt $runs;$i++){
     $timer=[Diagnostics.Stopwatch]::StartNew()
     $result=[string]$app.Run("'$($book.Name)'!modTestCalculationTiming.TestRun",[bool]($variant -like 'Candidate*'))
     $timer.Stop()
     $samples+=,[ordered]@{Kind=$kind;Mode=$mode;Variant=$variant;Index=$index;ExternalSeconds=$timer.Elapsed.TotalSeconds;Result=$result}
     $index++
     $samples|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'Samples.json') -Encoding UTF8
     Write-Output ($kind+' '+$mode+' '+$variant+' '+$result)
     if($result.StartsWith('ERROR|') -or $result -notmatch 'ReadReleased=True'){throw $result}
     $process=Get-Process -Id $own
     if($process.StartTime.ToUniversalTime().Ticks -ne $ticks -or $process.PrivateMemorySize64 -gt 900MB){throw 'Exact own/memory guard'}
    }
    $result=[string]$app.Run("'$($book.Name)'!modTestCalculationTiming.TestParity")
    $result|Set-Content (Join-Path $out ($mode+'_'+$variant+'_Parity.txt')) -Encoding UTF8
    if($result.StartsWith('ERROR|')){throw $result}
    $chart=$book.Worksheets.Item('Расчет').ChartObjects().Item('chtNDMSectionPlot').Chart
    if(-not $chart.Export((Join-Path $out ($mode+'_'+$variant+'.png')),'PNG')){throw 'Chart export failed'}
   }
  }
  [ordered]@{Status='MEASURED_FULL_CALCULATION_EXCEL_FILE';Kind=$kind;Samples=$samples.Count;FullAcceptanceClaim=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'Complete.json') -Encoding UTF8
 }finally{
  if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
  $component=$null;$chart=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
  [GC]::Collect();[GC]::WaitForPendingFinalizers()
  [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
 }
 if((Get-FileHash -LiteralPath $source).Hash -ne $before){throw 'Prepared source changed'}
}
