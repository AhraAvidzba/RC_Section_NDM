"""ДЛЯ ТЕСТОВ: целиком читает адресные журналы и окончательные нативные доказательства."""
from pathlib import Path
import hashlib
import json
import re
import statistics

P = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


groups = {
    'GuardIntegration06_Attempt1': {
        'RunFormationDisplayStateTests': 47, 'RunExcelGuardWorkflowTests': 55},
    'DirectedUpdate08_Attempt1': {
        'RunTestCalculationFreshnessWorkflow': 347,
        'RunPreparedSnapshotReuseTests': 69,
        'RunCalculationSnapshotTests': 1001,
        'RunResultsFormattingTests': 64},
}
records = []
for group, macros in groups.items():
    for mode in ['No', 'Yes']:
        for macro, expected in macros.items():
            path = P/group/mode/(macro+'.txt')
            raw = path.read_bytes()
            text = raw.decode('utf-8-sig')
            assert not re.search(r'(?im)^FAIL|failed=[1-9]', text), str(path)
            totals = re.findall(r'(?m)^TOTAL[^\r\n]*passed=(\d+); failed=(\d+)', text)
            assert totals == [(str(expected), '0')], (path, totals)
            records.append(dict(Group=group, Mode=mode, Macro=macro, Passed=expected,
                                Failed=0, EntirePrimaryRead=True, Bytes=len(raw), SHA256=sha(path)))
assert sum(item['Passed'] for item in records) == 3166
prior = load(P/'DirectedPrimaryReview06.json')
assert prior['AssertionsPassed'] == 3758 and prior['AssertionsFailed'] == 0
for item in load(P/'PreparedOutputs08.json')['Books']:
    label = item['Label']
    assert sha(Path(item['Prepared'])) == item['PreparedSHA256']
    native = load(P/(label+'Native08')/'Native.json')
    equality = load(P/(label+'Native08')/'SourceEquality.json')
    assert native['WorkbookSHA256'] == item['PreparedSHA256'] and native['Components'] == 187
    assert (equality['SourceComponents'], equality['DocumentComponents'], equality['Errors']) == (181, 6, [])
    assert item['OnlyVBAChanged'] and item['DataResultsPicturesSettingsAndLayoutByteExact']
samples = load(P/'FinalSavedPerformance08/Samples.json')
assert len(samples) == 13 and load(P/'FinalSavedPerformance08/Complete.json')['NoProfilingCode']
warm = [sample['ExternalSeconds'] for sample in samples if not sample['Warmup']]
assert len(warm) == 10
performance = dict(ColdSeconds=samples[0]['ExternalSeconds'], WarmupCount=3,
                   MeasuredSamples=len(warm), MedianSeconds=statistics.median(warm),
                   MinimumSeconds=min(warm), MaximumSeconds=max(warm),
                   SamplesSeconds=warm, CompleteNativeAction=True,
                   NoProfilingCode=True, UniversalHalfSecondGuarantee=False)
result = dict(Status='PASS_FINAL_AFFECTED_PRIMARY_AND_SAVED_NATIVE',
              AdditionalInvocations=len(records), AdditionalAssertionsPassed=3166,
              EarlierInvocations=20, EarlierAssertionsPassed=3758,
              TotalActualInvocations=32, TotalActualAssertionsPassed=6924,
              AssertionsFailed=0, Records=records, SavedFormation=performance,
              FullOnOffPerformed=False, FullAcceptanceClaim=False)
(P/'FinalReview08.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(Status=result['Status'], SavedFormation=performance), ensure_ascii=False))
