"""ДЛЯ ТЕСТОВ: публикует проверенный VBA с резервом, сохраняя все данные книг и отдельный NDM."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import zipfile

P = Path(__file__).resolve().parent
R = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


review = load(P/'FinalReview08.json')
assert load(P/'DirectedFinalReview10.json')['AssertionsFailed'] == 0
assert review['AssertionsFailed'] == 0 and review['TotalActualAssertionsPassed'] == 6924
own = load(P/'AllOwnClosures08.json')
assert own['Status'] == 'ALL_OWN_TERMINAL'
assert (datetime.now(timezone.utc)-datetime.fromisoformat(own['ObservedUTC'].replace('Z','+00:00'))).total_seconds() < 120
prep = load(P/'PreparedOutputs10.json')['Books']
for item in prep:
    assert sha(Path(item['Source'])) == item['SourceSHA256'], 'Source was saved again: preserve fresh user data'
    assert sha(Path(item['Prepared'])) == item['PreparedSHA256']
    native = load(P/(item['Label']+'Native10')/'Native.json')
    equality = load(P/(item['Label']+'Native10')/'SourceEquality.json')
    assert native['WorkbookSHA256'] == item['PreparedSHA256'] and equality['Status'] == 'PASS'
    with zipfile.ZipFile(item['Source']) as old, zipfile.ZipFile(item['Prepared']) as new:
        assert set(old.namelist()) == set(new.namelist())
        assert [key for key in old.namelist() if old.read(key) != new.read(key)] == ['xl/vbaProject.bin']
heavy_folder = R/'workbook/output/NDM_HeavyCircle_1232_30_2026-11-01'
sidecar = heavy_folder/'NDM_HeavyCircle_1232_30.ndm'
sidecar_sha = sha(sidecar)
archive_name = 'NDM_HeavyCircle_1232_30_Комплект.zip'
original_snapshot_sha = 'E48038B73A6E4146A9AB6D594BC57B4E7C26C561D2DBAC3A9FE7496AFA96C9AA'
with zipfile.ZipFile(heavy_folder/archive_name) as archive:
    assert archive.testzip() is None
    original_snapshot = archive.read(sidecar.name)
    assert hashlib.sha256(original_snapshot).hexdigest().upper() == original_snapshot_sha
backup = P/'BeforePublication10'
backup.mkdir(exist_ok=False)
for item in prep:
    if item['Label'] != 'Clean':
        reserve = backup/item['Label']/Path(item['Source']).name
        reserve.parent.mkdir(parents=True)
        shutil.copy2(item['Source'], reserve)
        assert sha(reserve) == item['SourceSHA256']
for name in ['Прочитать.txt', 'Verification.json', archive_name, sidecar.name]:
    shutil.copy2(heavy_folder/name, backup/'Heavy'/name)
shutil.copy2(R/'workbook/output/VBA_All_Code.txt', backup/'Main/VBA_All_Code.txt')
receipts = []
for item in prep:
    if item['Label'] == 'Clean':
        continue
    target = Path(item['Source'])
    temporary = target.with_name(target.stem+'.fastpaint-update.tmp')
    assert not temporary.exists()
    shutil.copy2(item['Prepared'], temporary)
    try:
        os.replace(temporary, target)
        standard = True
    except PermissionError:
        temporary.unlink()
        target = target.parent.with_name(target.parent.name+'_FastPaint_2026-11-01')/target.name
        target.parent.mkdir(exist_ok=True)
        assert not target.exists()
        shutil.copy2(item['Prepared'], target)
        standard = False
    assert sha(target) == item['PreparedSHA256']
    receipts.append(dict(Label=item['Label'], Destination=str(target), SHA256=sha(target),
                         StandardPathUpdated=standard, OnlyVBAChanged=True,
                         UnchangedParts=item['UnchangedParts'], Backup=str(backup/item['Label']/Path(item['Source']).name)))
    if item['Label'] == 'Main':
        shutil.copy2(P/'MainNative10/VBA_All_Code.txt', target.parent/'VBA_All_Code.txt')
heavy = next(item for item in receipts if item['Label'] == 'Heavy')
folder = Path(heavy['Destination']).parent
verification = load(backup/'Heavy/Verification.json')
verification['WorkbookSHA256'] = heavy['SHA256']
verification['FormationAndUpdateFastPaint'] = dict(ChangedParts=['xl/vbaProject.bin'],
    UnchangedParts=heavy['UnchangedParts'], DataAndResultsByteExact=True,
    NativeSavedReopen=True, SourceComponents=181, DocumentComponents=6,
    FullOnOffPerformed=False, Review=str(P/'DirectedFinalReview10.json'))
verification['PackagedSnapshotSHA256'] = original_snapshot_sha
verification['SeparateLocalSnapshotSHA256AtPublication'] = sidecar_sha
verification['SeparateLocalSnapshotPreserved'] = True
verification['SeparateLocalSnapshotSameAsOriginalArchive'] = sidecar_sha == original_snapshot_sha
(folder/'Verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding='utf-8')
readme = (backup/'Heavy/Прочитать.txt').read_text(encoding='utf-8-sig')
readme = readme.replace('В нём те же сохранённые результаты в формате NDMSNP06.',
    'В комплекте ZIP сохранён исходный проверенный снимок NDMSNP06. Отдельный файл рядом с книгой мог быть изменён при последующей работе.')
readme = readme.replace('Обновлён код формирования и ручного обновления схемы: устранено лишнее переключение ScreenUpdating.',
    'Обновлён код формирования, расчёта и ручного обновления схемы: устранено лишнее переключение ScreenUpdating.')
(folder/'Прочитать.txt').write_text(readme, encoding='utf-8-sig')
archive_path = folder/archive_name
temp_archive = archive_path.with_suffix('.fastpaint.tmp')
assert not temp_archive.exists()
with zipfile.ZipFile(temp_archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in [Path(heavy['Destination']), folder/'Прочитать.txt', folder/'Verification.json']:
        archive.write(path, path.name)
    archive.writestr(sidecar.name, original_snapshot)
with zipfile.ZipFile(temp_archive) as archive:
    assert archive.testzip() is None
    assert hashlib.sha256(archive.read(Path(heavy['Destination']).name)).hexdigest().upper() == heavy['SHA256']
    assert hashlib.sha256(archive.read(sidecar.name)).hexdigest().upper() == original_snapshot_sha
os.replace(temp_archive, archive_path)
assert sha(sidecar) == sidecar_sha, 'Independent local snapshot must be preserved'
result = dict(Status='PUBLISHED_NATIVE_VERIFIED_FAST_PAINT', PublishedUTC=datetime.now(timezone.utc).isoformat(),
              Books=receipts, SeparateLocalSnapshotSHA256=sidecar_sha,
              PackagedOriginalSnapshotSHA256=original_snapshot_sha,
              Package=str(archive_path), PackageSHA256=sha(archive_path),
              UserApplicationsClosed=False, FullOnOffPerformed=False)
(P/'Publication10.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
