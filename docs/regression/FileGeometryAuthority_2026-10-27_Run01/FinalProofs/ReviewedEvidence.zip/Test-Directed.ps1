# ДЛЯ ТЕСТОВ: последовательные адресные Snapshot/Workflow проверки; это не полный UI/ON-OFF набор.
param([string]$Label='FreshBuild02',[string]$Attempt='Directed02')
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$source=Join-Path $PSScriptRoot ($Label+'/RC_Section_NDM.xlsm')
$build=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.Build.json')) -Raw -Encoding UTF8|ConvertFrom-Json
$pins=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'CandidateSourcePins.json') -Raw -Encoding UTF8|ConvertFrom-Json
$records=@()
foreach($macro in @('RunCalculationSnapshotTests','RunWorkflowSnapshotTests','RunSectionWorkflowCalculationTests')){
 foreach($mode in @('No','Yes')){
  foreach($pin in $pins){if((Get-FileHash -LiteralPath (Join-Path $root $pin.Path)).Hash -cne$pin.SHA256){throw 'Source pin changed'}}
  if((Get-FileHash -LiteralPath $source).Hash -cne$build.BookSHA256){throw 'Built source changed'}
  $report='docs/regression/FileGeometryAuthority_2026-10-27_Run01/'+$Attempt+'_'+$macro+'_'+$mode+'.txt'
  if(Test-Path -LiteralPath $report){throw 'Fresh directed report required'}
  $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
  $ram=[double]$m.AvailableMBytes/1024;$commit=([double]$m.CommitLimit-[double]$m.CommittedBytes)/1GB
  [ordered]@{RAMGiB=$ram;CommitGiB=$commit;RequiredRAMGiB=8;RequiredCommitGiB=14}|ConvertTo-Json|Set-Content -LiteralPath ($report+'.memory.json') -Encoding UTF8
  if($null -eq$m -or $ram -lt8 -or $commit -lt14){throw '8RAM/14commit required'}
  & (Join-Path $PSHOME 'powershell.exe') -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') -SourceWorkbook $source -ReportPath $report -Macro $macro -Mode $mode -TimeoutSeconds 600 -VerifyResultsReopen -VerifyStatusReopen
  $exit=$LASTEXITCODE
  $text=Get-Content -LiteralPath $report -Raw -Encoding UTF8
  $passed=$exit -eq0 -and $text -match'SUITE_FINISHED:' -and $text -match'WATCHDOG_COMPLETED: exit=0' -and $text -notmatch'(?m)^(FAIL |RUNTIME:|WATCHDOG_FAILURE:)'
  $records+=,[ordered]@{Macro=$macro;Mode=$mode;ExitCode=$exit;Passed=$passed;Primary=$report;SHA256=(Get-FileHash -LiteralPath $report).Hash}
  $records|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Attempt+'.json')) -Encoding UTF8
  if(-not$passed){throw ('Directed failure: '+$report)}
 }
}
