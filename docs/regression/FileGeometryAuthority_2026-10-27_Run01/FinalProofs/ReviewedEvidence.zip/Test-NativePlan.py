"""ДЛЯ ТЕСТОВ: закрепляет два готовых пакета для readonly сверки native-кода без импорта."""
from pathlib import Path
import hashlib
import json

E=Path(__file__).resolve().parent
ROOT=E.parents[2]

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: проверяет фактический файл плана."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def TestMain():
    """ДЛЯ ТЕСТОВ: никакое приложение не создаётся; reference AllCode только охраняется от изменений."""
    proof=json.loads((E/'PackageProof.json').read_text(encoding='utf-8-sig'))
    plan={'Status':'PRIVATE_SOURCE_ONLY_TWO_BOOKS_NO_IMPORT','Cases':[
        {'ID':b['ID'],'Path':b['Path'],'SHA256':b['SHA256'],'TextCells':b['TextCells']} for b in proof['Books']
    ]}
    for key,path in [('PublishedAllCode',ROOT/'workbook/output/VBA_All_Code.txt'),('Verifier',E/'NativePlan01/Verifier/Test-VerifyProbeSourceEquality.ps1')]:
        plan[key]={'Path':str(path),'SHA256':TestSHA(path)}
    (E/'NativePlan01/Plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':TestMain()
