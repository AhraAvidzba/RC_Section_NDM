"""ДЛЯ ТЕСТОВ: фиксирует границы File-authority задачи и исходные байты без изменения старых доказательств."""
from pathlib import Path
import hashlib
import json

E = Path(__file__).resolve().parent
ROOT = E.parents[2]

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: хэширует точные исходные байты."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def TestWrite(name, value):
    """ДЛЯ ТЕСТОВ: сохраняет читаемое доказательство с Unicode."""
    (E/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def TestMain():
    """ДЛЯ ТЕСТОВ: исходные копии и текущие изменения сохраняются раздельно."""
    originals = json.loads((E/'Inputs.json').read_text(encoding='utf-8-sig'))
    known = {p['Path'] for p in originals}
    for path in sorted((E/'Before').rglob('*')):
        if path.is_file():
            relative = path.relative_to(E/'Before').as_posix()
            if relative not in known:
                originals.append({'Path': relative, 'SHA256': TestSHA(path)})
    for row in originals:
        assert TestSHA(E/'Before'/row['Path']) == row['SHA256']
    TestWrite('Inputs.json', originals)
    TestWrite('Plan.json', {
        'Status': 'IMPLEMENTED_IN_PRIVATE_BUILD_DIRECTED_ACCEPTANCE_PENDING', 'BaseCommit': 'ecf085ad',
        'Requirements': [
            'File: весь снимок из файла текущего Results.SnapshotName без обязательной предварительной загрузки; Results только справочный вывод.',
            'Excel: источником сохранённого снимка являются таблицы Results.',
            'Геометрия, единицы, ID, контуры, аннотации, все сохранённые НДС, сводки, профиль выполненных проверок читаются согласованно.',
            'Выбор LC/НДС/величины/точности, оформление и параметры экспорта остаются в Config.',
            'Worst и комментарий LC относятся к сохранённому расчёту.',
            'Загрузка File обновляет верхние и первые четыре нижние таблицы в согласованном порядке; три подробных блока выводятся только шапками.',
            'Удаление всего содержимого Results не меняет чтение File, повторный расчёт и экспорт.',
            'Отсутствующий/повреждённый файл не подменяется Results. Excel всегда читает только Results и не загружает File при смене режима.',
            'После итога каждого действия указывается его источник; формирование сообщает место сохранения, расчёт повторяет место сохранения последней строкой. Отсутствующий файл даёт имя, путь, реальный адрес настройки и подсказку.',
            'Новый расчёт использует текущие нагрузки/материалы/настройки Config и сохранённую геометрию без новой генерации.',
            'Математика и формат старых файлов неизменны. Сборка, обе книги и AllCode синхронизируются.'
        ],
        'Verification': 'Snapshot/Workflow No/Yes, сохранение/reopen, строгие численные сравнения, current UI и очистка Results; без полного ON/OFF/целого UI/реального CAD.',
        'Preserve': ['1232 concrete/8 rebar/30 LC and exact ready Results', 'Help ecf085ad', 'Foreign execution_report and outputs'],
        'RoutingAudit': {
            'SharedDataReader': 'modSectionSnapshot.ReadAnchoredResultTable / ReadElementResultTable',
            'SharedFileResolution': 'modCalculationSnapshot.CurrentCalculationSnapshot, one operation scope',
            'SharedWorstSelection': 'modSectionSnapshot.ReadSavedWorstCombinationID',
            'PhysicalReadsRemaining': [
                'Excel branch in shared table reader',
                'Excel branch in geometry-only detection and LC comment/Worst readers',
                'Workbook names/anchors/row limits/formatting for output and diagnostics, not snapshot values'
            ],
            'NoNewClassesOrModules': True
        }
    })
    TestWrite('CandidateSourcePins.json', [
        {'Path': row['Path'], 'SHA256': TestSHA(ROOT/row['Path'])}
        for row in originals if not row['Path'].startswith('workbook/')
    ])
    print(json.dumps({'Backups': len(originals), 'SourcePins': len(originals)-3}))

if __name__ == '__main__':
    TestMain()
