"""ДЛЯ ТЕСТОВ: сохраняет базу после отдельного завершённого изменения справки."""
from pathlib import Path
import hashlib
import json
import shutil

E=Path(__file__).resolve().parent
ROOT=E.parents[2]

def TestMain():
    """ДЛЯ ТЕСТОВ: не создаёт Excel и не меняет рабочую книгу."""
    files=['src/Excel/modSectionSnapshot.bas','src/Excel/CNDMResultsWriter.cls',
           'src/Excel/modWorkbookCalculation.bas','tests/modTestCalculationSnapshot.bas',
           'tools/build_workbook/SettingsCatalog.ps1','AGENTS.md',
           'workbook/output/RC_Section_NDM.xlsm','workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm',
           'workbook/output/VBA_All_Code.txt']
    records=[]
    for rel in files:
        source=ROOT/rel;target=E/'Before'/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        assert not target.exists()
        shutil.copy2(source,target)
        records.append({'Path':rel,'SHA256':hashlib.sha256(source.read_bytes()).hexdigest().upper()})
    (E/'Inputs.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    plan={'Status':'CONFIRMED_MIXED_SOURCE_READING_TO_FIX','BaseCommit':'ecf085ad',
          'Requirements':['File: единый связанный файл содержит всю геометрию, единицы, контуры, идентификаторы и аннотации.',
                          'Удаление/изменение геометрических данных Results не влияет на чтение и расчёт File.',
                          'Пропавший/повреждённый файл не подменяется данными листа.',
                          'Excel сохраняет свой штатный источник и поддерживается переход File→Excel.',
                          'Текущие нагрузки и модели материалов Config остаются входами нового расчёта.',
                          'Математика и исходные файлы снимков не меняются; источник сборки, книги и AllCode синхронизируются.'],
          'ConfirmedPaths':['modSectionSnapshot.ReadAnchoredResultTable: только ElementGeometry берётся из файла, geometryOnly читает физические таблицы.',
                            'ResultsGeometrySource / ReadLoadCasePropertyText: общие свойства читаются физически.',
                            'CNDMResultsWriter.PreparePreservedSnapshotSource: geometry/contours/annotations из физического листа.'],
          'Verification':'Адресные No/Yes Snapshot/Workflow и новые File authority случаи; без полного/целого UI или настоящего CAD.',
          'Preserve':['Готовые данные/Results тестовой книги с 30 сочетаниями','Новые тексты справки ecf085ad','Чужие execution_report/outputs']}
    (E/'Plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'Backups':len(records),'NativeProcessStarted':False}))

if __name__=='__main__':
    TestMain()
