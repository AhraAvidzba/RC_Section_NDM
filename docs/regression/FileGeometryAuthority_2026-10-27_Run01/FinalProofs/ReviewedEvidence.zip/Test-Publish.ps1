# ДЛЯ ТЕСТОВ: публикует только три принятых выходных файла с backups и защитой от чужих изменений.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$accept=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Acceptance.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not$accept.Passed -or $accept.FullRegressionPass){throw 'Directed acceptance required, without full PASS attribution'}
$native=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Native01.Watchdog/Completion.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not$native.Passed -or $native.Excel.State -ne'Absent' -or $native.Worker.State -ne'Absent'){throw 'Exact native closures required'}
$pins=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'CandidateSourcePins.json') -Raw -Encoding UTF8|ConvertFrom-Json
foreach($pin in $pins){if((Get-FileHash -LiteralPath (Join-Path $root $pin.Path)).Hash -cne$pin.SHA256){throw 'Accepted source changed'}}
$packages=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PackageProof.json') -Raw -Encoding UTF8|ConvertFrom-Json
$inputs=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Inputs.json') -Raw -Encoding UTF8|ConvertFrom-Json
$stage=Join-Path $PSScriptRoot 'PublicationStage';$backups=Join-Path $PSScriptRoot 'PublicationBackups'
if((Test-Path -LiteralPath $stage) -or (Test-Path -LiteralPath $backups)){throw 'Fresh publication directories required'}
[void][IO.Directory]::CreateDirectory($stage);[void][IO.Directory]::CreateDirectory($backups)
$files=@($packages.Books|ForEach-Object {[pscustomobject]@{ID=$_.ID;Source=$_.Path;Relative=$_.RelativeOutput;Before=$_.BeforeSHA256;After=$_.SHA256}})
$code=Join-Path $PSScriptRoot 'Native01/Main/VBA_All_Code.txt';$oldCode=@($inputs|Where-Object Path -eq 'workbook/output/VBA_All_Code.txt')
if($oldCode.Count -ne1){throw 'Original AllCode identity required'}
$files+=,[pscustomobject]@{ID='AllCode';Source=$code;Relative='workbook/output/VBA_All_Code.txt';Before=$oldCode[0].SHA256;After=(Get-FileHash -LiteralPath $code).Hash}
$records=@()
foreach($file in $files){
 $target=Join-Path $root $file.Relative
 if((Get-FileHash -LiteralPath $target).Hash -cne$file.Before -or (Get-FileHash -LiteralPath $file.Source).Hash -cne$file.After){throw 'User changed an output or private accepted package'}
 $lock=[IO.File]::Open($target,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$lock.Dispose()
 $staged=Join-Path $stage $file.ID;Copy-Item -LiteralPath $file.Source -Destination $staged
 $records+=,[ordered]@{ID=$file.ID;Path=$file.Relative;Destination=$target;Stage=$staged;Backup=(Join-Path $backups $file.ID);BeforeSHA256=$file.Before;AfterSHA256=$file.After}
}
foreach($record in $records){
 if((Get-FileHash -LiteralPath $record.Destination).Hash -cne$record.BeforeSHA256){throw 'Output changed immediately before publication'}
 [IO.File]::Replace($record.Stage,$record.Destination,$record.Backup)
 if((Get-FileHash -LiteralPath $record.Destination).Hash -cne$record.AfterSHA256 -or (Get-FileHash -LiteralPath $record.Backup).Hash -cne$record.BeforeSHA256){throw 'Atomic replacement verification failed'}
}
[ordered]@{Passed=$true;Status='PUBLISHED_DIRECTED_FILE_SOURCE_AND_TABLE_ORDER';Files=$records;PublishedUTC=[DateTimeOffset]::UtcNow.ToString('o');FullRegressionPass=$false}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Publication.json') -Encoding UTF8
