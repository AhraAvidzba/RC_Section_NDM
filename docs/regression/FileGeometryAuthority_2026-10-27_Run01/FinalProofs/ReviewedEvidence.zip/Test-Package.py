"""ДЛЯ ТЕСТОВ: переносит чисто собранный VBA и две строки справки, сохраняя остальные части готовых книг."""
from pathlib import Path
import argparse
import difflib
import hashlib
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
import zipfile

E=Path(__file__).resolve().parent
ROOT=E.parents[2]
OLD=ROOT/'docs/regression/GeometryFinalization_2026-10-26_Run01'
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
SST='xl/sharedStrings.xml'
HELP='xl/worksheets/sheet3.xml'
VBA='xl/vbaProject.bin'
MOVES=[(40,50,19),(51,69,-11),(70,93,20),(94,95,-6),(96,113,-26)]

def TestColumn(text):
    """ДЛЯ ТЕСТОВ: переводит адрес столбца без Excel."""
    value=0
    for c in text:value=value*26+ord(c)-64
    return value

def TestLetters(value):
    """ДЛЯ ТЕСТОВ: сохраняет обычные A1-адреса после перестановки."""
    text=''
    while value:value,r=divmod(value-1,26);text=chr(65+r)+text
    return text

def TestAddress(address,inverse=False):
    """ДЛЯ ТЕСТОВ: переставляет только нижние блоки, включая два пустых столбца между ними."""
    m=re.fullmatch(rb'([A-Z]+)([0-9]+)',address);assert m
    column,row=TestColumn(m[1].decode()),int(m[2])
    if row>=154:
        for a,b,delta in MOVES:
            if inverse:a,b,delta=a+delta,b+delta,-delta
            if a<=column<=b:column+=delta;break
    return (TestLetters(column)+str(row)).encode()

def TestReorderXML(raw,inverse=False):
    """ДЛЯ ТЕСТОВ: перемещает целые ячейки с исходными числами/стилями; инверсия обязана вернуть все байты."""
    def row_patch(match):
        row=match[0];number=int(re.search(rb'\br="([0-9]+)"',row)[1])
        if number<154:return row
        assert b'<f' not in row,'Formulas require a separate reference-safe move'
        begin,end=row.index(b'>')+1,row.rfind(b'</row>');body=row[begin:end]
        cells=list(re.finditer(rb'<c\b[^>]*?(?:/>|>.*?</c>)',body,re.S));records=[]
        assert re.sub(rb'<c\b[^>]*?(?:/>|>.*?</c>)',b'',body,flags=re.S).strip()==b''
        for cell in cells:
            old=cell[0];a=re.search(rb'\br="([A-Z]+[0-9]+)"',old);assert a
            new=TestAddress(a[1],inverse)
            changed=old[:a.start(1)]+new+old[a.end(1):]
            records.append((TestColumn(re.match(rb'[A-Z]+',new)[0].decode()),changed))
        assert len({p[0] for p in records})==len(records)
        return row[:begin]+b''.join(v for _,v in sorted(records))+row[end:]
    result=re.sub(rb'<row\b[^>]*>.*?</row>',row_patch,raw,flags=re.S)
    def merge_patch(match):
        ref=match[1];addresses=ref.split(b':');new=[TestAddress(a,inverse) for a in addresses]
        if len(addresses)==2:
            old_width=TestColumn(re.match(rb'[A-Z]+',addresses[1])[0].decode())-TestColumn(re.match(rb'[A-Z]+',addresses[0])[0].decode())
            new_width=TestColumn(re.match(rb'[A-Z]+',new[1])[0].decode())-TestColumn(re.match(rb'[A-Z]+',new[0])[0].decode())
            assert old_width==new_width,'A merge crosses moved blocks'
        return match[0].replace(ref,b':'.join(new),1)
    return re.sub(rb'<mergeCell\b[^>]*\bref="([A-Z0-9:]+)"[^>]*/>',merge_patch,result)

def TestReorder(book):
    """ДЛЯ ТЕСТОВ: переносит четыре таблицы и только их именованные якоря; верхние данные неизменны."""
    workbook=book.read('xl/workbook.xml');result_workbook=workbook
    names={'rngNDMSectionContours':('$AY$156','$AN$156'),'rngNDMElementResults':('$AN$156','$BG$156'),'rngNDMElementGeometry':('$CR$156','$BR$156'),'rngNDMSectionAnnotations':('$BR$156','$CL$156')}
    for name,(before,after) in names.items():
        pattern=rb'<definedName\b(?=[^>]*\bname="'+name.encode()+rb'")[^>]*>.*?</definedName>'
        match=re.search(pattern,result_workbook,re.S);assert match and match[0].count(before.encode())==1
        result_workbook=result_workbook[:match.start()]+match[0].replace(before.encode(),after.encode())+result_workbook[match.end():]
    parsed=ET.fromstring(workbook);rn='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
    rid=next(x.get(rn+'id') for x in parsed.iter(NS+'sheet') if x.get('name')=='Results')
    rel=next(x.get('Target') for x in ET.fromstring(book.read('xl/_rels/workbook.xml.rels')) if x.get('Id')==rid)
    part='xl/'+rel;raw=book.read(part);moved=TestReorderXML(raw)
    assert TestReorderXML(moved,True)==raw,'Lower table data/style bytes did not roundtrip exactly'
    return {'xl/workbook.xml':result_workbook,part:moved},{'ResultsPart':part,'ChangedNamedAnchors':names,'AllCellsAndStylesExactAfterInverseMove':True,'FormulasInMovedArea':0,'UpperRowsUnchanged':True}

def TestLoad(path, name):
    """ДЛЯ ТЕСТОВ: загружает только определения проверенных raw ZIP-функций."""
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.dont_write_bytecode=True
    spec.loader.exec_module(module)
    return module

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: хэширует фактический файл без пересохранения."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает proof с необязательным BOM."""
    return json.loads(path.read_text(encoding='utf-8-sig'))

def TestStrings(book):
    """ДЛЯ ТЕСТОВ: читает строки с сохранением пользовательского текста."""
    return [''.join(node.itertext()) for node in ET.fromstring(book.read(SST))]

def TestPatch(old,new,mapping):
    """ДЛЯ ТЕСТОВ: меняет лишь ссылки целевых ячеек справки; старые shared strings остаются побайтно."""
    raw=old.read(HELP);changed=raw;sst=old.read(SST)
    strings=TestStrings(old);fresh_strings=TestStrings(new)
    fresh_cells={c.get('r'):fresh_strings[int(c.findtext(NS+'v'))] for c in ET.fromstring(new.read(HELP)).iter(NS+'c') if c.get('t')=='s'}
    cells={c.get('r'):strings[int(c.findtext(NS+'v'))] for c in ET.fromstring(raw).iter(NS+'c') if c.get('t')=='s'}
    proofs=[];appended=[]
    for before,after in mapping:
        addresses=[a for a,v in cells.items() if v==before]
        assert len(addresses)==1
        address=addresses[0];assert fresh_cells[address]==after
        match=re.search(rb'<c\b(?=[^>]*\br="'+address.encode()+rb'")[^>]*>.*?</c>',changed,re.S)
        assert match
        original=match[0];index=len(strings)+len(appended)
        replacement,count=re.subn(rb'<v>[0-9]+</v>',b'<v>'+str(index).encode()+b'</v>',original)
        assert count==1
        changed=changed[:match.start()]+replacement+changed[match.end():]
        appended.append(('<si><t xml:space="preserve">'+escape(after)+'</t></si>').encode())
        proofs.append({'Part':HELP,'Cell':address,'Before':before,'After':after,'_old':original,'_new':replacement})
    reverse=changed
    for p in reversed(proofs):
        assert reverse.count(p['_new'])==1
        reverse=reverse.replace(p['_new'],p['_old'],1)
    assert reverse==raw
    header=re.search(rb'<sst\b[^>]*>',sst)[0]
    new_header,count=re.subn(rb'\buniqueCount="[0-9]+"',b'uniqueCount="'+str(len(strings)+len(appended)).encode()+b'"',header)
    assert count==1
    result_sst=sst.replace(header,new_header,1).replace(b'</sst>',b''.join(appended)+b'</sst>',1)
    assert re.findall(rb'<si\b[^>]*>.*?</si>',result_sst,re.S)[:len(strings)]==re.findall(rb'<si\b[^>]*>.*?</si>',sst,re.S)
    for p in proofs:del p['_old'],p['_new']
    return {SST:result_sst,HELP:changed},proofs

def TestMain():
    """ДЛЯ ТЕСТОВ: не меняет опубликованные книги, создаёт отдельные кандидаты и полное доказательство сохранения данных."""
    parser=argparse.ArgumentParser();parser.add_argument('--label',default='FreshBuild02');parser.add_argument('--packages',default='Packages05');args=parser.parse_args()
    assert re.fullmatch('FreshBuild[0-9]+',args.label)
    assert re.fullmatch('Packages[0-9]+',args.packages)
    fresh=E/args.label/'RC_Section_NDM.xlsm'
    assert TestSHA(fresh)==TestJSON(E/(args.label+'.Build.json'))['BookSHA256']
    inputs=TestJSON(E/'Inputs.json')
    before=(E/'Before/tools/build_workbook/SettingsCatalog.ps1').read_text(encoding='utf-8-sig').splitlines()
    after=(ROOT/'tools/build_workbook/SettingsCatalog.ps1').read_text(encoding='utf-8-sig').splitlines()
    mapping=[]
    for kind,a,b,c,d in difflib.SequenceMatcher(a=before,b=after,autojunk=False).get_opcodes():
        if kind=='equal':continue
        assert kind=='replace' and b-a==d-c==1
        mapping.append((json.loads(before[a].strip().rstrip(',')),json.loads(after[c].strip().rstrip(','))))
    assert len(mapping)==5
    helper=TestLoad(OLD/'LowMemoryPerformancePackagePlan/TestPrepareVbaOnlyPerformanceBook.py','TestRawZipFile')
    pack=TestLoad(OLD/'PostTransferNativePlan01/TestPreparePreservedReady01.py','TestXmlZipFile')
    records=[]
    with zipfile.ZipFile(fresh) as compiled:
        for case,relative in [('Main','workbook/output/RC_Section_NDM.xlsm'),('SavedExcelWarm2','workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm')]:
            base=E/'Before'/relative
            original=next(x['SHA256'] for x in inputs if x['Path']==relative)
            assert TestSHA(base)==TestSHA(ROOT/relative)==original
            target=E/args.packages/case/'RC_Section_NDM.xlsm';target.parent.mkdir(parents=True,exist_ok=True)
            assert not target.exists()
            with zipfile.ZipFile(base) as old:
                changed,cells=TestPatch(old,compiled,mapping)
                layout,layout_proof=TestReorder(old);changed.update(layout)
                xml_records=pack.TestXMLRecords(old,changed)
            old_meta,code_meta=helper.archive(base),helper.archive(fresh)
            pack.TestWritePackage(helper,base,fresh,target,old_meta,code_meta,xml_records)
            final_meta=helper.archive(target);preserved=[]
            with zipfile.ZipFile(base) as old,zipfile.ZipFile(target) as final:
                assert final.testzip() is None and old.namelist()==final.namelist()
                for part in old.namelist():
                    if part==VBA:assert final.read(part)==compiled.read(part)
                    elif part in changed:assert final.read(part)==changed[part]
                    else:
                        assert old.read(part)==final.read(part)
                        assert helper.slice_hash(base,*old_meta['blocks'][part])==helper.slice_hash(target,*final_meta['blocks'][part])
                        a,b=bytearray(dict(old_meta['entries'])[part]),bytearray(dict(final_meta['entries'])[part]);a[42:46]=b[42:46]=b'\0'*4
                        assert a==b
                        preserved.append(part)
            assert len(preserved)==len(old_meta['infos'])-5
            records.append({'ID':case,'Path':str(target),'RelativeOutput':relative,'SHA256':TestSHA(target),'BeforeSHA256':original,'TextCells':cells,'Layout':layout_proof,'OtherPartsByteExact':preserved,'ChangedParts':[VBA,*changed],'FreshSourceBuild':str(fresh),'ResultsAndUserDataPreserved':True})
    (E/'PackageProof.json').write_text(json.dumps({'Books':records,'FullRegressionPass':False},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps([{'ID':r['ID'],'PreservedParts':len(r['OtherPartsByteExact']),'SHA256':r['SHA256']} for r in records]))

if __name__=='__main__':TestMain()
