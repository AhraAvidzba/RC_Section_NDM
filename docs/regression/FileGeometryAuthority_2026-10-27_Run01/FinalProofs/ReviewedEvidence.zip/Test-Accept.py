"""ДЛЯ ТЕСТОВ: читает все принятые первичные журналы; адресный PASS не подменяет полную приёмку."""
from pathlib import Path
import hashlib
import json
import re

E=Path(__file__).resolve().parent
ROOT=E.parents[2]

def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает первичный proof."""
    return json.loads(path.read_text(encoding='utf-8-sig'))

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: фиксирует точные прочитанные байты."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def TestMain():
    """ДЛЯ ТЕСТОВ: принимает только шесть завершённых адресных No/Yes проверок и native двух книг."""
    jobs=TestJSON(E/'Directed11.json');assert isinstance(jobs,list) and len(jobs)==6
    assert {(j['Macro'],j['Mode']) for j in jobs}=={(m,mode) for m in ('RunCalculationSnapshotTests','RunWorkflowSnapshotTests','RunSectionWorkflowCalculationTests') for mode in ('No','Yes')}
    build=TestJSON(E/'FreshBuild11.Build.json');assert build['Passed']
    reviewed=[];total=0
    for job in jobs:
        path=ROOT/job['Primary'];text=path.read_text(encoding='utf-8-sig')
        assert job['Passed'] and job['ExitCode']==0 and TestSHA(path)==job['SHA256']
        assert 'SOURCE_SHA256: '+build['BookSHA256'] in text
        assert not re.search(r'(?m)^(FAIL\b|RUNTIME:|WATCHDOG_FAILURE:)',text)
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
        assert 'SOURCE_UNCHANGED: True' in text and 'SUITE_FINISHED: '+job['Macro'] in text
        assert re.search(r'RESULTS_SAVE_REOPEN:.*equal=True',text) and re.search(r'STATUS_STYLE_SAVE_REOPEN:.*equal=True',text)
        totals=re.findall(r'(?m)^TOTAL[^\r\n]+',text);assert len(totals)==1
        number=re.search(r'passed=(\d+); failed=(\d+)',totals[0]) or re.search(r'(\d+)/(\d+)',totals[0])
        assert number and int(number[2])==0
        passed=int(number[1]);total+=passed
        closure=TestJSON(Path(str(path)+'.ProcessClosure.json'))
        assert closure['Passed'] and closure['Closure']['FinalState']['State']=='Absent' and not closure['OrdinaryPathKilledAnything']
        if job['Macro']=='RunCalculationSnapshotTests':
            for key in ('missingFile.error','missingFile.name','missingFile.actions','missingFile.location','missingFile.path'):
                assert 'PASS '+key in text
            for shape in ('Adaptive','Contour'):
                for key in ('preview.fileModel','calculated.fileModel','calculated.export','calculated.plot','worst.exportFromFile','worst.plotFromFile','view.currentLC','view.currentState','view.currentQuantity','view.currentPrecision','view.currentExport','toExcel.completeModel','noLinkedFile.modelRejected','noLinkedFile.plotRejected','noLinkedFile.exportRejected','file.noPreloadRequired','file.directCalculation','excel.noFileFallback','saveAs.ignoresOtherName','message.formed.File','message.calculated.source.File','message.calculated.saved.File','message.calculated.source.Excel','message.calculated.saved.Excel'):
                    assert 'PASS '+shape+'.'+key in text
                for table in ('rngNDMElementResults','rngNDMElementGeometry','rngNDMSectionAnnotations'):
                    assert 'PASS '+shape+'.display.headerOnly.'+table in text
        reviewed.append({**job,'Assertions':passed,'BytesRead':path.stat().st_size,'OwnExcel':closure['Closure']['Identity']})
    native=TestJSON(E/'Native01.Watchdog/Completion.json');assert native['Passed'] and native['Excel']['State']=='Absent' and native['Worker']['State']=='Absent'
    assert TestJSON(E/'NativeNumeric.json')['Passed']
    for pin in TestJSON(E/'CandidateSourcePins.json'):assert TestSHA(ROOT/pin['Path'])==pin['SHA256']
    for case in ('Main','SavedExcelWarm2'):
        assert all(x['Equal'] for x in TestJSON(E/('Native01/'+case+'/LayoutAnchors.json')))
        assert all(x['Fits'] for x in TestJSON(E/('Native01/'+case+'/TextFits.json')))
    proof={'Passed':True,'Status':'PASS_DIRECTED_FILE_EXCEL_SOURCE_AND_LAYOUT_ONLY','Assertions':total,'Jobs':reviewed,'NativeComponentsPerBook':181,'SourceComponents':175,'DocumentModules':6,'NewLongOrFullRunStarted':False,'FullRegressionPass':False,'OriginalFullReviewRequiredUnchanged':True}
    (E/'Acceptance.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'Passed':True,'Assertions':total,'Jobs':len(reviewed)}))

if __name__=='__main__':TestMain()
