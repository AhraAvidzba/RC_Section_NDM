"""ДЛЯ ТЕСТОВ: сохраняет компактные доказательства без книг и чужих отчётов."""
from pathlib import Path
import hashlib
import json
import zipfile

E=Path(__file__).resolve().parent
ROOT=E.parents[2]

def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает фактический proof с возможным BOM PowerShell."""
    return json.loads(path.read_text(encoding='utf-8-sig'))

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: фиксирует точные опубликованные или архивируемые байты."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def TestMain():
    """ДЛЯ ТЕСТОВ: исходные неуспешные журналы сохраняются вместе с принятыми повторами."""
    acceptance=TestJSON(E/'Acceptance.json');publication=TestJSON(E/'Publication.json')
    assert acceptance['Passed'] and publication['Passed'] and not acceptance['FullRegressionPass']
    assert TestJSON(E/'OwnProcessFinal.json')['Passed']
    for item in publication['Files']:
        assert TestSHA(ROOT/item['Path'])==item['AfterSHA256']
    output=E/'FinalProofs';output.mkdir(exist_ok=True)
    archive=output/'ReviewedEvidence.zip';assert not archive.exists()
    files=[]
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as target:
        for path in sorted(E.rglob('*')):
            if not path.is_file() or output in path.parents:continue
            relative=path.relative_to(E)
            if any(p.startswith(('FreshBuild','Packages','PublicationStage','PublicationBackups')) for p in relative.parts[:-1]):
                if path.name!='BuildOwnership.json':continue
            if path.suffix.lower() not in ('.json','.txt','.ps1','.py','.bas','.cls','.md','.diff','.vba'):continue
            target.write(path,relative.as_posix())
            files.append({'Path':relative.as_posix(),'Bytes':path.stat().st_size,'SHA256':TestSHA(path)})
        for pin in TestJSON(E/'CandidateSourcePins.json'):
            path=ROOT/pin['Path'];assert TestSHA(path)==pin['SHA256']
            name='CurrentSource/'+pin['Path'];target.write(path,name)
            files.append({'Path':name,'Bytes':path.stat().st_size,'SHA256':pin['SHA256']})
    with zipfile.ZipFile(archive) as target:
        assert target.testzip() is None and len(target.namelist())==len(files)
        for row in files:assert hashlib.sha256(target.read(row['Path'])).hexdigest().upper()==row['SHA256']
    requirements=[
        ('Текущий Excel/File и текущее имя файла без предварительного обновления','Plan.json; Directed11*.txt'),
        ('Полное удаление Results не меняет чтение File, схему, экспорт и расчёт','Adaptive/Contour preview.*, calculated.*, repeat.*'),
        ('Excel не подмешивает прежний файл','Adaptive/Contour excel.noFileFallback'),
        ('Выбор сочетания, состояния и оформления остаётся на Config','Adaptive/Contour view.current*'),
        ('Четыре нижние справочные таблицы, полный Excel и согласованный порядок семи блоков','layout.order.*; display.*; LayoutAnchors.json'),
        ('Геометрия, единицы, состояния и результаты сохраняются точно','repeat.*; toExcel.*; save/reopen proofs'),
        ('Отсутствующий файл даёт имя, действия, фактический адрес настройки и путь','missingFile.*; noLinkedFile.*'),
        ('Сообщения называют источник действия и место сохранения в конце расчёта','message.*; SnapshotActionDataOrigin'),
        ('SaveAs не выбирает старую привязку другого имени','saveAs.ignoresOtherName'),
        ('Чистая пересборка с компиляцией и источники синхронизированы','FreshBuild11.Build.json; CandidateSourcePins.json'),
        ('Обе книги 175+6 native-компонентов и актуальный AllCode проверены без импорта','Native01; NativeNumeric.json'),
        ('1232 бетонных/8 стержней/30 сочетаний и готовые Results сохранены','PackageProof.json; точная обратная перестановка всех Results-байтов'),
        ('Опубликованные файлы и резервные копии сверены','Publication.json'),
        ('Все собственные процессы закрыты; новый полный не запускался','OwnProcessFinal.json; Acceptance.json')
    ]
    proof={'Status':'PASS_DIRECTED_FILE_EXCEL_AUTHORITY_AND_MESSAGES_ONLY','Assertions':acceptance['Assertions'],
        'Requirements':[{'Requirement':r,'Evidence':e,'Verified':True} for r,e in requirements],
        'PublishedFiles':[{k:row[k] for k in ('Path','BeforeSHA256','AfterSHA256')} for row in publication['Files']],
        'ArchivedFiles':len(files),'ArchiveBytes':archive.stat().st_size,'ArchiveSHA256':TestSHA(archive),
        'FullRegressionPass':False,'NewFullOrWholeUIRunStarted':False,'OldFullReviewRequiredPreserved':True}
    for name,value in [('Processed.json',proof),('ArchiveManifest.json',files),('Acceptance.json',acceptance)]:
        (output/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'Files':len(files),'ArchiveBytes':archive.stat().st_size,'Assertions':acceptance['Assertions']}))

if __name__=='__main__':TestMain()
