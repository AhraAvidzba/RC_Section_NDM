"""ДЛЯ ТЕСТОВ: дополнительная проверка точных Double изменённых модулей и прежних native-тел."""
from pathlib import Path
import hashlib
import json
import re
import struct

E=Path(__file__).resolve().parent
ROOT=E.parents[2]
CHUNKS=re.compile(r'"(?:[^"]|"")*"|\x27[^\r\n]*|[^"\x27\r\n]+|\r?\n')
NUMBERS=re.compile(r'(?<![\w&.])(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?#?(?![\w])')

def TestComponents(path):
    """ДЛЯ ТЕСТОВ: выделяет действительные строки COMPONENT/TYPE/LINES без нормализации чисел."""
    lines=path.read_text(encoding='utf-8-sig').splitlines();out={};i=0
    while i<len(lines):
        if not lines[i].startswith('COMPONENT: '):i+=1;continue
        name=lines[i][11:];count=int(lines[i+2][7:]);assert name not in out
        out[name]='\n'.join(lines[i+4:i+4+count]);i+=4+count
    assert len(out)==181
    return out

def TestCodeCase(text):
    """ДЛЯ ТЕСТОВ: разрешает только регистр идентификаторов VBE; литералы и комментарии буквальные."""
    return ''.join(c[0] if c[0].startswith(('"',"'")) else c[0].lower() for c in CHUNKS.finditer(text)).rstrip()

def TestBits(text):
    """ДЛЯ ТЕСТОВ: Double-константы проверяются по IEEE64, без G15 и допуска."""
    out=[]
    for chunk in CHUNKS.finditer(text):
        code=chunk[0].lower()
        if code.startswith(('"',"'")):continue
        for match in NUMBERS.finditer(code):
            value=match[0]
            if not any(c in value for c in '.e#') or (match.end()<len(code) and code[match.end()] in '!@%&^'):continue
            out.append(struct.pack('>d',float(value.rstrip('#'))).hex().upper())
    return out

def TestMain():
    """ДЛЯ ТЕСТОВ: G15 source equality дополняется точным сравнением изменённых констант."""
    old=TestComponents(E/'Before/workbook/output/VBA_All_Code.txt')
    new=TestComponents(E/'Native01/Main/VBA_All_Code.txt')
    inputs=json.loads((E/'Inputs.json').read_text(encoding='utf-8-sig'))
    changed={Path(r['Path']).stem:r['Path'] for r in inputs if Path(r['Path']).suffix in ('.bas','.cls')}
    assert len(changed)==12
    checks=[]
    for name,path in changed.items():
        source=(ROOT/path).read_text(encoding='utf-8-sig');source=source[source.index('Option Explicit'):]
        a,b=TestBits(source),TestBits(new[name])
        checks.append({'Component':name,'SourceDoubleCount':len(a),'NativeDoubleCount':len(b),'ExactIEEE64':a==b})
    unchanged=[name for name in old if name not in changed]
    differences=[name for name in unchanged if TestCodeCase(old[name])!=TestCodeCase(new[name])]
    proof={'Passed':all(c['ExactIEEE64'] for c in checks) and not differences,'Modified':checks,'UnchangedNativeComponents':len(unchanged),'Differences':differences,'AllowedForUnchanged':'identifier code case only; strings/comments/numbers/whitespace literal','G15UsedForThisProof':False}
    (E/'NativeNumeric.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    assert proof['Passed'],proof
    print(json.dumps({'Passed':True,'Modified':len(checks),'UnchangedNativeComponents':len(unchanged)}))

if __name__=='__main__':TestMain()
