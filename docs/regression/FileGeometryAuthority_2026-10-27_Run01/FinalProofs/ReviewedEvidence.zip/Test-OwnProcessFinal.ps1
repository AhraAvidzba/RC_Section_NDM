# ДЛЯ ТЕСТОВ: подтверждает отсутствие только исторических собственных identity, ничего не закрывает.
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'PS5.1 required'}
$identities=@()
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.Build.json' -File){
 $build=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
 $identities+=,[ordered]@{Evidence=$file.Name;PID=[int]$build.OwnExcelPID;StartTicksUTC=[string]$build.OwnExcelStartTicksUTC;Name='EXCEL'}
}
$native=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Native01.Watchdog/Completion.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not$native.Passed -or $native.OrdinaryForceKilled){throw 'Native closure not accepted'}
foreach($who in @($native.Excel,$native.Worker)){
 $identities+=,[ordered]@{Evidence='Native01.Watchdog/Completion.json';PID=[int]$who.PID;StartTicksUTC=[string]$who.ExpectedStartTicksUTC;Name=[string]$who.ExpectedName}
}
$records=@()
foreach($identity in $identities){
 $state='Unknown';$observed=$null
 try{
  $p=Get-Process -Id $identity.PID -ErrorAction Stop
  if($null -eq$p.StartTime){throw 'StartTime unavailable'}
  $observed=[ordered]@{Name=$p.ProcessName;StartTicksUTC=[string]$p.StartTime.ToUniversalTime().Ticks}
  if($p.ProcessName -ieq$identity.Name -and [string]$p.StartTime.ToUniversalTime().Ticks -ceq$identity.StartTicksUTC){$state='Live'}else{$state='DifferentIdentity'}
 }catch{
  if($_.FullyQualifiedErrorId -match'^NoProcessFoundForGivenId(,|$)'){$state='Absent'}else{throw}
 }
 $records+=,[ordered]@{Identity=$identity;State=$state;Observed=$observed;OwnIdentityAbsent=($state -in @('Absent','DifferentIdentity'))}
}
$passed=@($records|Where-Object {-not$_.OwnIdentityAbsent}).Count -eq0
[ordered]@{Passed=$passed;ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');Processes=$records;AnyProcessClosedOrKilled=$false}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'OwnProcessFinal.json') -Encoding UTF8
if(-not$passed){throw 'Own historical process identity still live'}
