# ДЛЯ ТЕСТОВ: чистая сборка актуальных источников в отдельной папке, без публикации.
param([ValidatePattern('^FreshBuild[0-9]+$')][string]$Label='FreshBuild01')
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne 5){throw 'PS5.1 required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$ram=[double]$memory.AvailableMBytes/1024;$commit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
[ordered]@{RAMGiB=$ram;CommitGiB=$commit;MinimumRAMGiB=8;MinimumCommitGiB=14}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.Memory.json')) -Encoding UTF8
if($null -eq $memory -or $ram -lt 8 -or $commit -lt 14){throw '8RAM/14commit required'}
$output='docs/regression/FileGeometryAuthority_2026-10-27_Run01/'+$Label+'/RC_Section_NDM.xlsm'
if(Test-Path -LiteralPath (Split-Path -Parent $output)){throw 'Fresh directory required'}
$start=[DateTimeOffset]::UtcNow.ToString('o')
. (Join-Path $root 'tools/build_workbook/Build-Workbook.ps1') -OutputPath $output -FormulaImageDirectory ('docs/regression/FileGeometryAuthority_2026-10-27_Run01/'+$Label+'/FormulaImages')
[ordered]@{Passed=$true;Status='FRESH_SOURCE_BUILD_COMPILE';StartedUTC=$start;FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o');BookSHA256=(Get-FileHash -LiteralPath $output).Hash;OwnExcelPID=$ownedExcelProcessId;OwnExcelStartTicksUTC=[string]$ownedExcelStartTicks;PublishedBooksChanged=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.Build.json')) -Encoding UTF8
