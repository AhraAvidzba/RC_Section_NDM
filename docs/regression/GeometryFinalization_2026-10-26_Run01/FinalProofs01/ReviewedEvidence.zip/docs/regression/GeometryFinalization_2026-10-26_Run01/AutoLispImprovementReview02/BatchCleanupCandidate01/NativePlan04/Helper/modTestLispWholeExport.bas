﻿Attribute VB_Name = "modTestLispWholeExport"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: парный полный путь сохранённой геометрии в собственный AutoCAD.
' ==========================================================================
' Сравнивает штатный COM и частный пакетный вариант. Подготовка preview,
' независимое чтение CAD и запись доказательств находятся вне таймера.

#If VBA7 Then
Private Declare PtrSafe Function QueryPerformanceCounter Lib "kernel32" (ByRef value As Currency) As Long
Private Declare PtrSafe Function QueryPerformanceFrequency Lib "kernel32" (ByRef value As Currency) As Long
#Else
Private Declare Function QueryPerformanceCounter Lib "kernel32" (ByRef value As Currency) As Long
Private Declare Function QueryPerformanceFrequency Lib "kernel32" (ByRef value As Currency) As Long
#End If

Private Type TTestDouble
    value As Double
End Type
Private Type TTestBytes
    bytes(0 To 7) As Byte
End Type
Private mPassed As Long, mFailed As Long, mReport As String
Private mProgressPath As String
Private mProgressFSO As Object

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Одна A/B-пара каждого размера; исходная историческая сетка не формируется заново.
Public Function TestRunWholeExport(ByVal cad As Object, ByVal originalScratch As Object, _
        ByVal unusedPath As String, ByVal token As String) As String
    mPassed = 0: mFailed = 0: mReport = vbNullString
    Dim activeTarget As Object, model As CSectionModel, small As CSectionModel
    Dim settings As CSystemSettingsReader, units As CUnitSystem, writer As CNDMResultsWriter
    TestPrepareProgress
    On Error GoTo Failed
    TestCheck "ownApplication", Not cad Is Nothing And Not originalScratch Is Nothing
    TestCheck "requestToken", Len(token) = 32
    Set model = ReadSectionGeometryFromResults(ThisWorkbook, "Results", True)
    TestCheck "historical1232", model.ConcreteCount = 1232
    TestCheck "historical8bars", model.RebarCount = 8
    If model.ConcreteCount <> 1232 Or model.RebarCount <> 8 Then Err.Raise 5, , "Exact historical model required."
    Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    Set units = New CUnitSystem: units.LoadFromSettings settings
    Set writer = New CNDMResultsWriter
    Set small = TestSmallModel()
    Dim scenario As Long, selected As CSectionModel, pair As Long, turn As Long, batch As Boolean
    Dim beforeTables As String, afterTables As String, fingerprintA As String, fingerprintB As String
    Dim warning As String, started As Double, seconds As Double, added As Long, name As String, artifact As String
    Dim counts As Long, scenarioName As String, initialDocuments As Long
    initialDocuments = cad.Documents.Count
    For scenario = 1 To 2
        If scenario = 1 Then Set selected = small: scenarioName = "Small" Else Set selected = model: scenarioName = "Heavy"
        writer.WriteGeometryPreview ThisWorkbook, selected, PrepareSectionSnapshot(selected), units, False
        beforeTables = TestTablesToken()
        TestCheck scenarioName & ".previewNoStates", Not HasResultTableRows(ReadPhysicalResultTable(ThisWorkbook, "rngNDMElementResults"))
        For pair = 1 To 1
            fingerprintA = vbNullString: fingerprintB = vbNullString
            For turn = 1 To 2
                batch = ((pair Mod 2 = 1 And turn = 2) Or (pair Mod 2 = 0 And turn = 1))
                If batch Then name = "B" Else name = "A"
                Set activeTarget = cad.Documents.Add
                activeTarget.Activate
                activeTarget.SetVariable "CELWEIGHT", CInt(50)
                activeTarget.SetVariable "CELTYPE", "Continuous"
                activeTarget.SetVariable "CELTSCALE", 2.5
                activeTarget.SetVariable "CECOLOR", "3"
                TestCheck scenarioName & "." & pair & "." & name & ".emptyTarget", activeTarget.ModelSpace.Count = 0
                If activeTarget.SelectionSets.Count <> 0 Then Err.Raise 5, "TestRunWholeExport", "Fresh target has SelectionSets."
                warning = vbNullString
                started = TestNow()
                modAutoCADStressExport.TestConfigureBatchGeometryExport batch
                added = modAutoCADStressExport.Audit03ExportAutoCADDocumentForTests(activeTarget, warning)
                seconds = TestNow() - started
                TestObserveTargetCleanup activeTarget, scenarioName & "." & CStr(pair) & "." & name, batch, selected, settings
                modAutoCADStressExport.TestConfigureBatchGeometryExport False
                TestCheck scenarioName & "." & pair & "." & name & ".geometryWarning", Len(warning) > 0
                counts = activeTarget.ModelSpace.Count
                TestCheck scenarioName & "." & pair & "." & name & ".appendedCount", added = counts And counts >= selected.ConcreteCount + selected.RebarCount
                Dim value As String: value = TestDrawingToken(activeTarget)
                artifact = ThisWorkbook.Path & "\WholeExport_" & scenarioName & "_" & pair & "_" & name & ".txt"
                TestWriteAscii artifact, value
                If batch Then fingerprintB = value Else fingerprintA = value
                TestLine "WHOLE_EXPORT_TIME: scenario=" & scenarioName & "; pair=" & CStr(pair) & "; variant=" & name & _
                    "; seconds=" & Trim$(Str$(seconds)) & "; count=" & CStr(counts) & "; artifact=" & artifact
                afterTables = TestTablesToken()
                TestCheck scenarioName & "." & pair & "." & name & ".sourceTables", beforeTables = afterTables
                TestCheck scenarioName & "." & pair & "." & name & ".noSolverStates", Not HasResultTableRows(ReadPhysicalResultTable(ThisWorkbook, "rngNDMElementResults"))
                activeTarget.Close False: Set activeTarget = Nothing
                originalScratch.Activate
            Next turn
            TestCheck scenarioName & "." & pair & ".allOrderedCadFieldsExact", fingerprintA = fingerprintB And Len(fingerprintA) > 0
            If fingerprintA <> fingerprintB Then Err.Raise 5, , "Ordered native geometry differs; retain both artifacts."
        Next pair
    Next scenario
    TestCheck "ownDocumentsRestored", cad.Documents.Count = initialDocuments
    GoTo Finish
Failed:
    mFailed = mFailed + 1
    TestLine "RUNTIME ERROR: " & CStr(Err.Number) & "; " & Err.Source & "; " & Err.Description
Finish:
    On Error Resume Next
    modAutoCADStressExport.TestConfigureBatchGeometryExport False
    If Not activeTarget Is Nothing Then activeTarget.Close False
    originalScratch.Activate
    On Error GoTo 0
    TestLine "TOTAL_WHOLE_EXPORT: passed=" & CStr(mPassed) & "; failed=" & CStr(mFailed)
    TestRunWholeExport = mReport
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Лёгкий случай с поворотом и точной прямоугольной границей без нового импорта.
Private Function TestSmallModel() As CSectionModel
    Dim model As CSectionModel: Set model = New CSectionModel: model.SourceType = "Generated"
    Dim i As Long, x As Double, y As Double, region As CConcreteRegion, properties As TGeometryProperties
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    For i = 1 To 8
        x = ((i - 1) Mod 4) * 60#: y = ((i - 1) \ 4) * 110#
        If i = 1 Then
            Set region = query.RectangleRegion(x, y, 50#, 100#, 0.13)
            query.RegionProperties region, properties
            model.AddConcreteElement properties.CentroidX, properties.CentroidY, properties.Area, 1, shapeType:="Contour", _
                localIx:=properties.Ixc, localIy:=properties.Iyc, localIxy:=properties.Ixyc, rotationKnown:=True, exactRegion:=region
        Else
            model.AddConcreteElement x, y, 50# * 100#, 1, shapeType:="Rectangle", width:=50#, height:=100#, rotation:=0.13, rotationKnown:=True
        End If
    Next i
    For i = 1 To 4
        model.AddRebarElement 20# * i, 20#, Sqr(800# / (4# * Atn(1#))), 200#, "A500"
    Next i
    Set TestSmallModel = model
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает каждую техническую таблицу целиком; сравниваются значения и типы.
Private Function TestTablesToken() As String
    Dim names As Variant, item As Variant, table As Variant, r As Long, c As Long
    Dim groups(0 To 6) As String, parts() As String, group As Long, position As Long
    names = Array("rngNDMSectionGeometry", "rngNDMSectionContours", "rngNDMElementGeometry", _
        "rngNDMSectionProperties", "rngNDMSectionAnnotations", "rngNDMElementResults", "rngNDMMaterialDiagrams")
    For Each item In names
        table = ReadPhysicalResultTable(ThisWorkbook, CStr(item))
        If IsArray(table) Then
            ReDim parts(0 To (UBound(table, 1) - LBound(table, 1) + 1) * (UBound(table, 2) - LBound(table, 2) + 1))
            parts(0) = CStr(item) & "[" & CStr(LBound(table, 1)) & ":" & CStr(UBound(table, 1)) & ":" & CStr(LBound(table, 2)) & ":" & CStr(UBound(table, 2)) & "]": position = 0
            For r = LBound(table, 1) To UBound(table, 1)
                For c = LBound(table, 2) To UBound(table, 2)
                    position = position + 1: parts(position) = TestValueToken(table(r, c))
                Next c
            Next r
            groups(group) = Join(parts, ";")
        Else
            groups(group) = CStr(item) & "|" & TestValueToken(table)
        End If
        group = group + 1
    Next item
    TestTablesToken = Join(groups, vbCrLf)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считывает все конечные объекты в порядке ModelSpace и все реальные линии/дуги.
' Explode создаёт только временные копии в своём чертеже; они удаляются сразу.
Private Function TestDrawingToken(ByVal document As Object) As String
    Dim ms As Object: Set ms = document.ModelSpace
    Dim amount As Long: amount = ms.Count
    Dim i As Long, entity As Object, result As String, curves As Variant, j As Long
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    For i = 0 To amount - 1
        Set entity = ms.Item(i)
        result = result & "OBJECT|" & CStr(i) & "|" & TestValueToken(entity.ObjectName) & "|" & _
            TestValueToken(entity.Layer) & "|" & TestValueToken(entity.Color) & "|" & TestValueToken(entity.Visible) & "|" & _
            TestValueToken(entity.Lineweight) & "|" & TestValueToken(entity.Linetype) & "|" & TestValueToken(entity.LinetypeScale) & "|"
        Dim low As Variant, high As Variant
        entity.GetBoundingBox low, high
        result = result & TestArrayToken(low) & "|" & TestArrayToken(high) & "|"
        Select Case CStr(entity.ObjectName)
            Case "AcDbRegion"
                result = result & TestValueToken(entity.Area) & "|" & TestArrayToken(entity.Centroid) & "|" & _
                    TestArrayToken(entity.MomentOfInertia) & "|" & TestArrayToken(entity.ProductOfInertia) & "|"
                curves = entity.Explode
                result = result & "CURVES:" & CStr(UBound(curves) - LBound(curves) + 1) & "|"
                For j = LBound(curves) To UBound(curves)
                    result = result & TestCurveToken(curves(j)) & "|"
                Next j
                For j = LBound(curves) To UBound(curves): curves(j).Delete: Next j
                curves = Empty
            Case Else
                result = result & TestCurveToken(entity) & "|"
        End Select
        result = result & vbCrLf
    Next i
    If ms.Count <> amount Then Err.Raise 5, , "Independent CAD review left temporary objects."
    TestDrawingToken = result
    Exit Function
Failed:
    errorNumber = Err.Number: errorText = Err.Description
    On Error Resume Next
    If IsArray(curves) Then
        For j = LBound(curves) To UBound(curves): curves(j).Delete: Next j
    End If
    On Error GoTo 0
    Err.Raise errorNumber, "TestDrawingToken", errorText
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет действительную геометрию кривой без восстановления по инерциям.
Private Function TestCurveToken(ByVal entity As Object) As String
    Dim result As String, coordinates As Variant, i As Long, size As Long
    result = CStr(entity.ObjectName) & "|"
    Select Case CStr(entity.ObjectName)
        Case "AcDbLine"
            result = result & TestArrayToken(entity.StartPoint) & "|" & TestArrayToken(entity.EndPoint)
        Case "AcDbArc"
            result = result & TestArrayToken(entity.StartPoint) & "|" & TestArrayToken(entity.EndPoint) & "|" & _
                TestArrayToken(entity.Center) & "|" & TestValueToken(entity.Radius) & "|" & _
                TestValueToken(entity.StartAngle) & "|" & TestValueToken(entity.EndAngle) & "|" & TestArrayToken(entity.Normal)
        Case "AcDbCircle"
            result = result & TestArrayToken(entity.Center) & "|" & TestValueToken(entity.Radius) & "|" & TestArrayToken(entity.Normal)
        Case "AcDbPolyline"
            coordinates = entity.Coordinates: size = (UBound(coordinates) - LBound(coordinates) + 1) \ 2
            result = result & TestArrayToken(coordinates) & "|" & TestValueToken(entity.Closed) & "|" & _
                TestValueToken(entity.Elevation) & "|" & TestArrayToken(entity.Normal)
            For i = 0 To size - 1: result = result & "|" & TestValueToken(entity.GetBulge(i)): Next i
        Case "AcDb2dPolyline", "AcDb3dPolyline"
            result = result & TestArrayToken(entity.Coordinates) & "|" & TestValueToken(entity.Closed)
        Case Else
            Err.Raise 5, "TestCurveToken", "Unsupported native entity in independent review: " & CStr(entity.ObjectName)
    End Select
    TestCurveToken = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вариант скаляра ProductOfInertia и массивов AutoCAD сохраняется явно.
Private Function TestArrayToken(ByVal value As Variant) As String
    Dim i As Long, result As String
    If Not IsArray(value) Then TestArrayToken = TestValueToken(value): Exit Function
    result = "ARRAY:" & CStr(LBound(value)) & ":" & CStr(UBound(value))
    For i = LBound(value) To UBound(value): result = result & "|" & TestValueToken(value(i)): Next i
    TestArrayToken = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сериализует Double побитово и Unicode по кодам; это диагностический артефакт.
Private Function TestValueToken(ByVal value As Variant) As String
    Dim result As String, i As Long, words As TTestBytes, number As TTestDouble, text As String, code As Long
    Select Case VarType(value)
        Case vbDouble, vbSingle, vbCurrency
            number.value = CDbl(value): LSet words = number
            For i = 0 To 7: result = result & Right$("0" & Hex$(words.bytes(i)), 2): Next i
        Case vbEmpty: result = "EMPTY"
        Case vbNull: result = "NULL"
        Case vbError: result = "ERROR:" & CStr(value)
        Case vbString
            text = CStr(value): result = "TEXT:"
            For i = 1 To Len(text)
                code = AscW(Mid$(text, i, 1)) And &HFFFF&
                result = result & Right$("0000" & Hex$(code), 4)
            Next i
        Case Else: result = CStr(value)
    End Select
    TestValueToken = CStr(VarType(value)) & ":" & result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает новый ASCII артефакт, не затрагивая исходные книги или чертежи.
Private Sub TestWriteAscii(ByVal path As String, ByVal value As String)
    If Len(Dir$(path)) > 0 Then Err.Raise 5, , "New evidence artifact required."
    Dim fileNumber As Integer: fileNumber = FreeFile
    Open path For Output As #fileNumber
    Print #fileNumber, value;
    Close #fileNumber
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Монотонный QPC; частота и счётчик делятся в одинаковом масштабе Currency.
Private Function TestNow() As Double
    Dim value As Currency, frequency As Currency
    If QueryPerformanceCounter(value) = 0 Or QueryPerformanceFrequency(frequency) = 0 Then Err.Raise 5, , "QPC unavailable."
    TestNow = value / frequency
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает независимый исход условия; ошибки не превращаются в пропуски.
Private Sub TestCheck(ByVal label As String, ByVal passed As Boolean)
    If passed Then mPassed = mPassed + 1: TestLine "OK: " & label Else mFailed = mFailed + 1: TestLine "FAIL: " & label
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Дополняет полный первичный журнал без изменения проверяемого состояния.
Private Sub TestLine(ByVal text As String)
    mReport = mReport & text & vbCrLf
    If Len(mProgressPath) = 0 Then Err.Raise 5, "TestLine", "Fresh progress file is not initialized."
    Dim stream As Object: Set stream = mProgressFSO.OpenTextFile(mProgressPath, 8, False, -1)
    stream.WriteLine text
    stream.Close
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создаёт отдельный новый первичный progress до первой проверки, без перезаписи истории.
Private Sub TestPrepareProgress()
    mProgressPath = ThisWorkbook.Path & "\WholeExportProgress.txt"
    Set mProgressFSO = CreateObject("Scripting.FileSystemObject")
    If mProgressFSO.FileExists(mProgressPath) Then Err.Raise 5, "TestPrepareProgress", "Fresh progress file required."
    Dim stream As Object: Set stream = mProgressFSO.CreateTextFile(mProgressPath, False, True)
    stream.Close
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет ordered target до Close: Regions тела и только ожидаемый Polyline-tail контуров.
' Region-Boolean контуры здесь не моделируются; fixture с контурами требует Polyline.
Private Sub TestObserveTargetCleanup(ByVal document As Object, ByVal caseID As String, _
        ByVal batch As Boolean, ByVal selected As CSectionModel, ByVal settings As CSystemSettingsReader)
    Dim sets As Object, item As Object, ms As Object, entity As Object, loops As Object
    Dim listed As Long, owned As Long, temporary As Long, amount As Long, diagnostics As String
    Dim contours As CSectionContours, i As Long, key As String, keys As Variant, role As String
    Dim concreteLayer As String, rebarLayer As String, layer As String, contourFormat As String
    Dim outerCount As Long, openingCount As Long, baseCount As Long
    Dim expectedType As String, expectedLayer As String, actualType As String, closedValue As Variant
    Dim needsClosed As Boolean, isClosed As Boolean
    Set sets = document.SelectionSets
    For Each item In sets
        listed = listed + 1
        If Left$(CStr(item.Name), 12) = "NDM_TEST_RB_" Then owned = owned + 1
    Next item
    If listed <> CLng(sets.Count) Then Err.Raise 5, "TestObserveTargetCleanup", "Incomplete target SelectionSets enumeration."
    modAutoCADStressExport.ReadAutoCADCommonMaterialLayers settings, concreteLayer, rebarLayer
    Set contours = selected.Contours: Set loops = CreateObject("Scripting.Dictionary")
    contourFormat = "NotUsed"
    If settings.GetRequiredBoolean("AutoCAD.Export.ContourEnabled") And contours.Count > 0 Then
        contourFormat = settings.GetRequiredChoice("AutoCAD.Export.ContourFormat", Array("Region", "Polyline"))
        If contourFormat <> "Polyline" Then Err.Raise 5, "TestObserveTargetCleanup", "This fixed historical fixture requires Polyline contour export; Region Boolean is outside this observer."
        For i = 1 To contours.Count
            role = contours.LoopRole(i)
            key = UCase$(role) & ":" & contours.LoopID(i)
            If Not loops.Exists(key) Then
                If StrComp(role, "Opening", vbTextCompare) = 0 Then
                    layer = modAutoCADStressExport.RequiredAutoCADLayerName(settings, "AutoCAD.Common.OpeningContourLayer")
                    openingCount = openingCount + 1
                ElseIf StrComp(role, "Outer", vbTextCompare) = 0 Then
                    layer = modAutoCADStressExport.RequiredAutoCADLayerName(settings, "AutoCAD.Common.SectionContourLayer")
                    outerCount = outerCount + 1
                Else
                    Err.Raise 5, "TestObserveTargetCleanup", "Unknown saved contour role."
                End If
                loops.Add key, layer
            End If
        Next i
    End If
    baseCount = selected.ConcreteCount + selected.RebarCount
    Set ms = document.ModelSpace: amount = ms.Count
    TestLine "TARGET_EXPECTED_CONTOURS: case=" & caseID & "; format=" & contourFormat & _
        "; bodyRegions=" & CStr(baseCount) & "; outer=" & CStr(outerCount) & "; opening=" & CStr(openingCount) & "; tailCount=" & CStr(loops.Count)
    If amount <> baseCount + loops.Count Then Err.Raise 5, "TestObserveTargetCleanup", "Target object count differs from saved material and enabled contour loops."
    If loops.Count > 0 Then keys = loops.Keys
    For i = 0 To amount - 1
        Set entity = ms.Item(i): expectedType = "AcDbRegion": needsClosed = False: isClosed = True
        If i < selected.ConcreteCount Then
            expectedLayer = concreteLayer
        ElseIf i < baseCount Then
            expectedLayer = rebarLayer
        Else
            expectedType = "AcDbPolyline": expectedLayer = CStr(loops.Item(keys(i - baseCount))): needsClosed = True
        End If
        actualType = CStr(entity.ObjectName)
        If needsClosed And actualType = "AcDbPolyline" Then
            closedValue = entity.Closed
            If VarType(closedValue) <> vbBoolean Then Err.Raise 5, "TestObserveTargetCleanup", "Actual contour Closed property is unavailable or not Boolean."
            isClosed = CBool(closedValue)
        End If
        If Not TestTargetRecordMatches(actualType, CStr(entity.Layer), isClosed, expectedType, expectedLayer, needsClosed) Then temporary = temporary + 1
    Next i
    TestLine "TARGET_CLEANUP: case=" & caseID & "; selectionSets=" & CStr(listed) & _
        "; ownedSets=" & CStr(owned) & "; tempCurves=" & CStr(temporary) & "; modelSpace=" & CStr(amount) & _
        "; targetName=" & TestValueToken(document.Name) & "; targetHWND=" & TestValueToken(document.HWND)
    If listed <> 0 Or owned <> 0 Or temporary <> 0 Then Err.Raise 5, "TestObserveTargetCleanup", "Target resource cleanup or ordered expected-object contract is not confirmed."
    If batch Then
        diagnostics = modAutoCADStressExport.TestBatchGeometryExportDiagnostics()
        TestLine "TARGET_BATCH_STATUS: case=" & caseID & "; " & diagnostics
        If diagnostics <> "BATCH_GEOMETRY_DONE: rectangles=" & CStr(selected.ConcreteCount) & _
                "; rebar=" & CStr(selected.RebarCount) & "; scratchClosed=True; previousActiveRestored=True; allRectOnly=True; COMFallback=False" Then _
            Err.Raise 5, "TestObserveTargetCleanup", "Successful batch diagnostics are missing."
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Чистый predicate: допускает только точные тип/слой и замкнутость ожидаемой полилинии.
Private Function TestTargetRecordMatches(ByVal actualType As String, ByVal actualLayer As String, ByVal isClosed As Boolean, _
        ByVal expectedType As String, ByVal expectedLayer As String, ByVal needsClosed As Boolean) As Boolean
    TestTargetRecordMatches = (StrComp(actualType, expectedType, vbBinaryCompare) = 0) And _
        (StrComp(actualLayer, expectedLayer, vbBinaryCompare) = 0)
    If needsClosed Then TestTargetRecordMatches = TestTargetRecordMatches And isClosed
End Function
