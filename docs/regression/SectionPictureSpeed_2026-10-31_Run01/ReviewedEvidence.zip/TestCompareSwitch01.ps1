# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сравнивает тот же Copy/Paste с переключением ScreenUpdating и без него в одном собственном Excel.
$ErrorActionPreference='Stop';$p=$PSScriptRoot
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestSwitchWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$a=$null;$books=@{};$own=$false;$r=[ordered]@{Passed=$false;FullAcceptanceClaim=$false;Samples=@();MemorySamples=@()}
function Test-PrivateBudget([int]$NativeId){
 $native=Get-Process -Id $NativeId -ErrorAction Stop
 if($native.PrivateMemorySize64-gt900MB){throw 'Own Excel private memory over 900 MiB'}
 return $native.PrivateMemorySize64
}
try{
 $source=[IO.File]::ReadAllText("$p/IllustrationSourceBefore.bas")
 $light=[regex]::Replace($source,'(?m)^    Application\.ScreenUpdating = (False|previousUpdating)[^\r\n]*\r?\n','')
 if($light-eq$source-or$light-match'Application\.ScreenUpdating ='){throw 'Unexpected screen-state experiment'}
 [IO.File]::WriteAllText("$p/NoScreenUpdating.bas",$light,[Text.UTF8Encoding]::new($false))
 $prior=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
 $a=New-Object -ComObject Excel.Application
 [uint32]$nativeId=0;[void][TestSwitchWindow]::GetWindowThreadProcessId([IntPtr]$a.Hwnd,[ref]$nativeId)
 if($prior-contains[int]$nativeId){throw 'Own Excel required'};$own=$true
 @{PID=$nativeId;StartTicksUTC=[string](Get-Process -Id $nativeId).StartTime.ToUniversalTime().Ticks}|ConvertTo-Json|Set-Content "$p/CompareOwnership.json"
 $a.DisplayAlerts=$false;$a.EnableEvents=$false;$a.Visible=$true;$a.AutomationSecurity=1
 foreach($label in @('A','B')){
  $path="$p/Compare$label.xlsm";if(Test-Path $path){throw 'Private comparison file already exists'}
  Copy-Item -LiteralPath "$p/UserMainBefore.xlsm" -Destination $path
  $b=$a.Workbooks.Open($path,0,$true);$books[$label]=$b;$a.Calculation=-4135
  $body=if($label-eq'A'){$source}else{$light};$body=[regex]::Replace($body,'(?m)^Attribute[^\r\n]*\r?\n','')
  $code=$b.VBProject.VBComponents.Item('modSectionIllustrations').CodeModule
  $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
  [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($code);$code=$null
  $a.VBE.ActiveVBProject=$b.VBProject;$compile=$a.VBE.CommandBars.FindControl(1,578)
  if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw ('Compile failed '+$label)}
  $compile=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[void](Test-PrivateBudget $nativeId)
 }
 $names=@('Circle','Rectangles','PointedSection','HollowRectangle')
 $a.EnableEvents=$true;$a.ScreenUpdating=$true
 $blocks=@('A','B','A','B','B','A','B','A','A','B')
 for($block=0;$block-lt$blocks.Count;$block++){
  $label=$blocks[$block];$b=$books[$label];$sheet=$b.Worksheets.Item('Расчет');$sheet.Activate();$cell=$sheet.Range('K2');$cell.Select()
  $count=$sheet.Shapes.Count
  foreach($name in $names){
   [void](Test-PrivateBudget $nativeId)
   $a.EnableEvents=$false;$cell.Value2=$name;$a.EnableEvents=$true
   $timer=[Diagnostics.Stopwatch]::StartNew();$a.Run(("'"+$b.Name+"'!modSectionIllustrations.SwitchSectionPicture"));$timer.Stop()
   $shape=$sheet.Shapes.Item('CurrentSection')
   if($shape.Type-ne13-or$shape.AlternativeText-cne$name-or$sheet.Shapes.Count-ne$count){throw 'Picture/shape-count mismatch'}
   if($a.ActiveSheet.Name-cne'Расчет'-or$a.Selection.Address()-cne'$K$2'-or-not$a.ScreenUpdating-or-not$a.EnableEvents-or$a.Calculation-ne-4135){throw 'Application state changed'}
   $r.Samples+=,@{Block=$block;Label=$label;Type=$name;Seconds=$timer.Elapsed.TotalSeconds;Warmup=($block-lt2)}
   [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shape);$shape=$null
   [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
   $private=Test-PrivateBudget $nativeId;$r.MemorySamples+=,@{Block=$block;Label=$label;Type=$name;PrivateBytes=$private}
   @{Block=$block;Label=$label;Type=$name;PrivateBytes=$private;Seconds=$timer.Elapsed.TotalSeconds}|ConvertTo-Json|Set-Content "$p/CompareProgress.json"
  }
 }
 $r.Passed=$true
}catch{$r.Error=$_.Exception.ToString();throw}finally{
 if($a){$a.EnableEvents=$false}
 foreach($b in $books.Values){try{$b.Close($false)}catch{$r.CloseError=$_.Exception.Message}}
 if($own-and$a){try{$a.Quit()}catch{$r.QuitError=$_.Exception.Message}}
 $b=$null;$books=$null;$sheet=$null;$cell=$null;$shape=$null;$code=$null;$compile=$null;$a=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
 $r|ConvertTo-Json -Depth 7|Set-Content "$p/CompareReview.json" -Encoding utf8
}
Write-Output ('COMPARISON_COMPLETE '+$r.Samples.Count)
