# -------------------- ДЛЯ ТЕСТОВ --------------------
# Выбирает отказ от переключения экрана только при измеримом выигрыше и завершённой серии.
from pathlib import Path
import json, statistics
p=Path(__file__).parent
r=json.loads((p/'Compare02Review.json').read_text('utf-8-sig'))
assert r['Passed'] and not r.get('CloseError') and not r.get('QuitError'), r
rows=[v for v in r['Samples'] if not v['Warmup']]
assert len(rows)==32
types=['Circle','Rectangles','PointedSection','HollowRectangle']
medians={label:statistics.median(v['Seconds'] for v in rows if v['Label']==label) for label in ['A','B']}
per_type={name:{label:statistics.median(v['Seconds'] for v in rows if v['Type']==name and v['Label']==label) for label in ['A','B']} for name in types}
gain=(medians['A']-medians['B'])/medians['A']
wins=sum(v['B']<v['A'] for v in per_type.values())
use_b=gain>=0.05 and medians['A']-medians['B']>=0.01 and wins>=3
result={'Passed':True,'Selected':'B' if use_b else 'A','MedianSeconds':medians,'PerTypeMedianSeconds':per_type,
        'RelativeGainB':gain,'FasterTypesB':wins,'SamplesPerVariant':16,'WarmupsExcluded':8,
        'MaxPrivateBytes':max(v['PrivateBytes'] for v in r['MemorySamples']),
        'Criterion':'B requires >=5% and >=10ms median gain, faster for at least 3 of 4 types',
        'FullAcceptanceClaim':False}
(p/'ComparisonDecision.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
