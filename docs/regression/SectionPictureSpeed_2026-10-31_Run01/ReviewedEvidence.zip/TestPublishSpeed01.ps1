# -------------------- ДЛЯ ТЕСТОВ --------------------
# Заменяет основной файл проверенной чистой сборкой после сохранения резервов и закрытия собственных Excel.
$ErrorActionPreference='Stop';$p=$PSScriptRoot
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$review=Get-Content -LiteralPath "$p/FinalReview.json" -Raw|ConvertFrom-Json
if(-not$review.Passed-or$review.UserDataCopied){throw 'Clean directed review required'}
& "$p/TestOwnClosures.ps1"
$before=Get-Content -LiteralPath "$p/Backup.json" -Raw|ConvertFrom-Json
$book=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$code=Join-Path $root 'workbook/output/VBA_All_Code.txt'
if((Get-FileHash -LiteralPath $book).Hash-cne$before.BookSHA256-or(Get-FileHash -LiteralPath $code).Hash-cne$before.AllCodeSHA256){throw 'Current output changed since backup'}
if((Get-FileHash -LiteralPath "$p/FreshBuildFinal/RC_Section_NDM.xlsm").Hash-cne$review.BookSHA256-or(Get-FileHash -LiteralPath "$p/Fresh_VBA_All_Code.txt").Hash-cne$review.AllCodeSHA256){throw 'Accepted files changed'}
$probe=[IO.File]::Open($book,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$probe.Dispose()
$backup=Join-Path $p 'BeforePublication';if(Test-Path -LiteralPath $backup){throw 'Inspect existing publication before repeating'}
New-Item -ItemType Directory -Path $backup|Out-Null
Copy-Item -LiteralPath $book -Destination "$backup/RC_Section_NDM.xlsm"
Copy-Item -LiteralPath $code -Destination "$backup/VBA_All_Code.txt"
if((Get-FileHash -LiteralPath "$backup/RC_Section_NDM.xlsm").Hash-cne$before.BookSHA256){throw 'Backup mismatch'}
Copy-Item -LiteralPath "$p/FreshBuildFinal/RC_Section_NDM.xlsm" -Destination $book -Force
Copy-Item -LiteralPath "$p/Fresh_VBA_All_Code.txt" -Destination $code -Force
if((Get-FileHash -LiteralPath $book).Hash-cne$review.BookSHA256-or(Get-FileHash -LiteralPath $code).Hash-cne$review.AllCodeSHA256){throw 'Published files differ'}
@{Passed=$true;UTC=[DateTimeOffset]::UtcNow.ToString('o');BookSHA256=$review.BookSHA256;AllCodeSHA256=$review.AllCodeSHA256;UserDataCopied=$false;UserAuthorizedCleanRebuild=$true;Backup=$backup}|ConvertTo-Json|Set-Content -LiteralPath "$p/Publication.json" -Encoding utf8
Write-Output ('PUBLISHED_CLEAN '+$review.BookSHA256)
