# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет адресный состав и после публикации сохраняет компактные доказательства чистой сборки.
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,sys
p=Path(__file__).parent
r=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
def read(n):return json.loads((p/(n+'.json')).read_text('utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def write(path,v):path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
decision,native,equality,clean,package,own=[read(n) for n in ['ComparisonDecision','FreshNativeReview','SourceEquality','CleanDefaultsReview','FreshPackageReview','AllOwnClosures']]
assert all(x['Passed'] for x in [decision,native,equality,clean,package,own])
assert decision['Selected']=='B' and decision['FasterTypesB']==4
assert native['Components']==182 and equality['SourceComponents']==176 and equality['ExportComponents']==182
assert native['Switches']==4 and native['MultipleBooksIsolated'] and native['GeneralSourceOnly'] and native['ButtonFonts9']
assert not native.get('Error') and not native.get('CloseError') and not native.get('QuitError')
assert len(native['UiSteps'])==6 and all(x['Actual']==x['Expected'] and x['NativeSelectionAccepted'] for x in native['UiSteps'])
book=p/'FreshBuildFinal/RC_Section_NDM.xlsm';book_sha=sha(book)
assert book_sha==native['BookSHA256']==clean['BookSHA256']==package['BookSHA256']
assert clean['GeometryCatalogCells']==615 and clean['ConfigSettings']==111 and clean['UserLoadsAbsent'] and not clean['UserDataCopied']
assets=read('BuildAssets')
for item in assets:assert sha(r/'tools/build_workbook/SectionIllustrations'/item['File'])==item['SHA256']
assert len(package['SourceImagesByteExact'])==5 and package['GeneralOnlyOnSource']
source=(r/'src/Excel/modSectionIllustrations.bas').read_text('utf-8-sig')
assert 'original.Parent.Activate' not in source and 'Application.ScreenUpdating =' not in source
def statements(text):
    result=[]
    for line in text.splitlines():
        quoted=False;chars=[];i=0
        while i<len(line):
            ch=line[i]
            if ch=='"':
                if quoted and i+1<len(line) and line[i+1]=='"':chars.extend(['"','"']);i+=2;continue
                quoted=not quoted
            if ch=="'" and not quoted:break
            chars.append(ch);i+=1
        value=''.join(chars).strip()
        if value:result.append(value)
    return result
assert statements(source)==statements((p/'NoScreenUpdating.bas').read_text('utf-8-sig'))
assert 'Workbook built:' in (p/'Build.log').read_text('utf-8-sig')
result={'Passed':True,'Scope':'CLEAN_REBUILD_AND_TARGETED_ILLUSTRATION_UI_SPEED','FullAcceptanceClaim':False,
        'BookSHA256':book_sha,'AllCodeSHA256':sha(p/'Fresh_VBA_All_Code.txt'),
        'MedianSecondsBefore':decision['MedianSeconds']['A'],'MedianSecondsAfter':decision['MedianSeconds']['B'],
        'RelativeGain':decision['RelativeGainB'],'MeasuredSamplesPerVariant':16,'UiSelections':6,
        'SourceComponents':176,'ExportComponents':182,'ProjectPngImages':5,'UserDataCopied':False,
        'NativeMaxPrivateBytes':native['MaxObservedPrivateBytes'],'OwnIdentitiesTerminal':own['OwnIdentityCount'],
        'ExecutableStatementsEqualMeasuredVariant':True,'VbaCacheResetUsed':False}
write(p/'FinalReview.json',result)
if '--finalize' not in sys.argv:
    print(json.dumps(result,ensure_ascii=False));sys.exit(0)
pub=read('Publication');assert pub['Passed'] and pub['BookSHA256']==book_sha
assert sha(r/'workbook/output/RC_Section_NDM.xlsm')==book_sha
assert sha(r/'workbook/output/VBA_All_Code.txt')==result['AllCodeSHA256']==pub['AllCodeSHA256']
e=r/'docs/regression/SectionPictureSpeed_2026-10-31_Run01';assert not e.exists();e.mkdir(parents=True)
files=['FinalReview.json','Publication.json','AllOwnClosures.json','Backup.json','BuildAssets.json',
       'ComparisonDecision.json','CompareReview.json','Compare02Review.json','CompareOwnership.json',
       'Compare02Ownership.json','CleanDefaultsReview.json','FreshPackageReview.json',
       'FreshNativeReview.json','FreshNativeOwnership.json','SourceEquality.json',
       'FreshBuildFinal/BuildOwnership.json','Build.log','FreshNative.log','SourceEquality.log',
       'TestCompareSwitch01.ps1','TestCompareSwitch02.ps1','TestReviewComparison02.py',
       'TestReviewCleanDefaults01.py','TestFreshPackage.py','TestNativeBuild01.ps1',
       'TestVerifySource.ps1','TestOwnClosures.ps1','TestPublishSpeed01.ps1','TestFinishSpeed01.py']+[f'UiSelection{i}.json' for i in range(6)]
manifest=[];archive=e/'ReviewedEvidence.zip'
with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as z:
    for name in files:
        path=p/name;raw=path.read_bytes();z.writestr(name,raw)
        manifest.append({'Name':name,'Bytes':len(raw),'SHA256':sha(path)})
with ZipFile(archive) as z:
    for item in manifest:assert hashlib.sha256(z.read(item['Name'])).hexdigest().upper()==item['SHA256']
write(e/'Manifest.json',{'ArchiveSHA256':sha(archive),'Files':manifest})
write(e/'Processed.json',dict(result,Status='CLEAN_REBUILD_DIRECTED_PASS',EvidenceArchiveSHA256=sha(archive)))
report=f'''# Чистая сборка и скорость переключения иллюстраций — 31.10.2026

Основная книга полностью пересобрана штатным Build-Workbook.ps1 из Workbooks.Add. Пользователь явно выбрал чистую сборку без переноса своих изменений. Предыдущая книга и AllCode сохранены резервно; новая содержит сборочные значения и пустые сочетания.

Процедура копирует именованный рисунок с неактивного листа «Сечения». При выборе K2 лист «Расчет» уже активен. Сохранены Copy/Paste с тремя попытками, постоянная пропорциональная рамка CurrentSection, замена после успешной подготовки, возврат выделения и событий, обработка очереди Excel. ScreenUpdating процедура читает для решения о завершающем DoEvents и не меняет; Calculation не меняется. Рабочие математические модули и рецепты не изменены.

## Сравнение скорости

В одном собственном Excel сравнивались две частные копии с одинаковыми PNG и рамкой. A переключает ScreenUpdating, B сохраняет текущий режим. 40 замен: первые восемь — прогрев, затем по 16 измерений на вариант с чередованием блоков четырёх типов. Медианы: A {result['MedianSecondsBefore']:.6f} с, B {result['MedianSecondsAfter']:.6f} с; выигрыш B {result['RelativeGain']*100:.2f}%. B быстрее для всех четырёх типов. Применён B; исполняемые строки опубликованного исходника равны измеренному варианту. Пик памяти серии {decision['MaxPrivateBytes']} байт.

Первая серия остановилась из-за ошибочного требования обвязки выделять только K2: фактическая область K2:N2 объединена. Исходный FAIL сохранён; повтор сравнивает точное выделение до/после. Ожидания рабочих результатов не менялись.

## Сборка и проверки

Все пять PNG при каждой сборке читаются из tools/build_workbook/SectionIllustrations через каталог Illustrations.json. Четыре имени Names доступны в K2; Общие_иллюстрации из Additional находится только на «Сечения». Исходные PNG внутри сохранённой книги и начальный CurrentSection совпали с проектными файлами побайтно. Служебных ячеек списка и связанной камеры нет.

Проверены 615 ячеек каталога четырёх таблиц и 111 настроек Config, формулы единиц и значения Double, порядок пяти листов, границы диапазонов и отсутствие пользовательских нагрузок. Нативно в сохранённой и повторно открытой read-only книге экспортированы 182 компонента, сверены все 176 исходных и шесть документных. Рамки четырёх таблиц и шрифт пяти кнопок 9 пт приняты. Четыре переключения проверены при открытых второй NDM и посторонней книге с совпадающими именами.

Реально раскрыты списки и выбраны Circle, Rectangles, PointedSection, HollowRectangle, Config I4=cm и Сечения H40=IncludeStart; значения, Validation.Value и фактическая картинка подтверждены. Склеенные строки через запятую/точку с запятой, Unknown и общая иллюстрация отклонены. Временные значения восстановлены без Save. Пик памяти нативной серии {result['NativeMaxPrivateBytes']} байт, предел 900 МиБ не достигнут. Все четыре собственные идентичности терминальны; принудительных завершений и новых Out of memory не было.

Полный расчётный ON/OFF-набор не запускался и не заявляется пройденным. Отсутствие любого мигания при любых внешних условиях не гарантируется; обычная ветвь K2 не переключает ни листы, ни ScreenUpdating. Очистка VBA-кэша и ухудшение изображений не применялись.

Книга SHA256 `{book_sha}`; AllCode `{result['AllCodeSHA256']}`. Размер {book.stat().st_size} байт. Компактные доказательства: docs/regression/SectionPictureSpeed_2026-10-31_Run01. Ветка codex/section-illustrations; отправка подтверждается отдельно после push и ls-remote. Main не менялась.
'''
(r/'docs/reports/SectionPictureSpeed_2026-10-31.md').write_text(report,encoding='utf-8')
progress=r/'docs/geometry_refactor/PROGRESS.md';text=progress.read_text('utf-8-sig');title='## 31.10.2026 — Чистая сборка с ускоренным переключением картинок'
assert title not in text
entry=f'''{title}

По выбору пользователя основная книга собрана с нуля без переноса данных. Все пять PNG автоматически встраиваются из проекта, общая иллюстрация — только на «Сечения». Copy/Paste работает по именам без активации источника и записи ScreenUpdating. Сравнение 16+16 измерений после прогрева: 0,632→0,518 с (−18,02%), все четыре типа быстрее; исполняемый код равен измеренному. Приняты 176/182 VBA, 615 ячеек геометрии, 111 настроек, пустые нагрузки, рамки/кнопки9 и шесть реальных UI-выборов. Все четыре собственные идентичности терминальны, без kill/OOM. Резерв сохранён; полного ON/OFF нет. [Отчёт](../reports/SectionPictureSpeed_2026-10-31.md).

'''
first,rest=text.split('\n',1);progress.write_text(first+'\n\n'+entry+rest.lstrip('\n'),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
