# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сверяет сохранённую чистую сборку с каталогами и не использует данные пользовательской книги.
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import json,re,posixpath,hashlib,struct,math
p=Path(__file__).parent
r=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
file=p/'FreshBuildFinal/RC_Section_NDM.xlsm'
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
rel='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
with ZipFile(file) as z: parts={n:z.read(n) for n in z.namelist()}
book=E.fromstring(parts['xl/workbook.xml'])
links={n.get('Id'):n.get('Target') for n in E.fromstring(parts['xl/_rels/workbook.xml.rels'])}
strings=[]
if 'xl/sharedStrings.xml' in parts:
    strings=[''.join(v.itertext()) for v in E.fromstring(parts['xl/sharedStrings.xml']).findall('m:si',ns)]
sheets={};cells={}
for sh in book.find('m:sheets',ns):
    path=posixpath.normpath('xl/'+links[sh.get('{'+rel+'}id')]);root=E.fromstring(parts[path]);sheets[sh.get('name')]=root
    table={}
    for c in root.findall('.//m:sheetData/m:row/m:c',ns):
        value=c.findtext('m:v',None,ns)
        if c.get('t')=='s':value=strings[int(value)]
        elif c.get('t')=='inlineStr':value=''.join(c.find('m:is',ns).itertext())
        table[c.get('r')]=(value,c.findtext('m:f',None,ns))
    cells[sh.get('name')]=table
assert list(sheets)==['Config','Сечения','Справка','Расчет','Results']
names={v.get('name'):v.text for v in book.find('m:definedNames',ns)}
def col(n):
    s=''
    while n:n,k=divmod(n-1,26);s=chr(65+k)+s
    return s
def coords(address):
    m=re.fullmatch(r'\$?([A-Z]+)\$?(\d+)',address);n=0
    for letter in m[1]:n=n*26+ord(letter)-64
    return int(m[2]),n
def bounds(name):
    sheet,area=names[name].lstrip('=').rsplit('!',1)
    a,b=area.split(':') if ':' in area else (area,area)
    return sheet.strip("'"),*coords(a),*coords(b)
def get(sheet,row,column):return cells[sheet].get(col(column)+str(row),(None,None))
def same(a,b):
    if a is None:a=''
    if b is None:b=''
    if str(a)==str(b):return True
    try:
        x,y=float(str(a)),float(str(b))
        return math.isfinite(x) and math.isfinite(y) and struct.pack('>d',x)==struct.pack('>d',y)
    except (ValueError,OverflowError):return False
unit_sheet,unit_first,unit_base,unit_last,unit_right=bounds('rngUnitSettings')
input_units={get(unit_sheet,row,unit_base)[0]:get(unit_sheet,row,unit_base+1)[0] for row in range(unit_first+1,unit_last+1)}
assert input_units['Length']=='mm'
length_formula='INDEX(rngUnitSettings,MATCH("Length",INDEX(rngUnitSettings,,1),0),2)'
def check_geometry_value(sheet,row,column,key,expected):
    actual,formula=get(sheet,row,column)
    if expected=='мм' and key=='unit':
        assert formula==length_formula and actual==input_units['Length'],(row,key,actual,formula)
    else:assert same(actual,expected),(row,key,actual,expected)
geometry=json.loads((r/'tools/build_workbook/GeometryTables.json').read_text('utf-8-sig'))
checked=0;range_bounds={}
for definition in geometry:
    sheet,first,base,last,right=bounds(definition['RangeName']);row=first;general={}
    range_bounds[definition['RangeName']]=names[definition['RangeName']]
    for block in definition['Blocks']:
        assert get(sheet,row,base)[0]==block['Key'],(definition['Type'],block['Key'])
        for i,key in enumerate(block['Keys']):assert get(sheet,row+2,base+i)[0]==key
        row+=3
        if block['Units']:
            for i,value in enumerate(block['Units']):
                check_geometry_value(sheet,row,base+i,'unit' if value=='мм' else block['Keys'][i],value)
                checked+=1
            row+=1
        for values in block['Rows']:
            if block['Key']=='General':general[str(values[0])]=col(base+block['Keys'].index('val'))+str(row)
            for i,expected in enumerate(values):
                actual,formula=get(sheet,row,base+i)
                if isinstance(expected,dict):
                    expression=re.sub(r'\{([^}]+)\}',lambda m:'$'+re.sub(r'(\d+)$',r'$\1',general[m[1]]),expected['Formula']).lstrip('=')
                    assert formula==expression,(definition['Type'],row,block['Keys'][i],formula,expression)
                else:check_geometry_value(sheet,row,base+i,block['Keys'][i],expected)
                checked+=1
            row+=1
        row+=1
    assert row-2==last,(definition['Type'],'bounds',row,last)
settings=json.loads((p/'SettingsCatalogExpected.json').read_text('utf-8-sig'))
sheet,first,base,last,right=bounds('rngSystemSettings')
actual={get(sheet,row,base)[0]:get(sheet,row,base+1)[0] for row in range(first+1,last+1)}
settings_count=0
for section in settings:
    for setting in section['Rows']:
        if str(setting[0]).startswith('['):continue
        assert setting[0] in actual,(setting[0],'missing')
        assert same(actual[setting[0]],setting[1]),(setting[0],actual[setting[0]],setting[1])
        settings_count+=1
calc=sheets['Расчет']
assert calc.find('.//m:c[@r="K2"]',ns) is not None
assert get('Расчет',2,11)[0]=='PointedSection'
# Строки сочетаний строятся заново; заполненных пользовательских ID в чистой книге нет.
load_names=[n for n in names if n.lower()=='rngloadcombinations']
assert len(load_names)==1
sheet,first,base,last,right=bounds(load_names[0]);ids=[get(sheet,row,base)[0] for row in range(first,last+1)]
assert all(v in [None,'','CombinationID','ID','-','—'] for v in ids),ids
result={'Passed':True,'BookSHA256':hashlib.sha256(file.read_bytes()).hexdigest().upper(),
        'GeometryCatalogCells':checked,'ConfigSettings':settings_count,'GeometryRanges':range_bounds,
        'SheetOrder':list(sheets),'UserLoadsAbsent':True,'DefaultIllustration':'PointedSection',
        'UserDataCopied':False,'FullAcceptanceClaim':False}
(p/'CleanDefaultsReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
