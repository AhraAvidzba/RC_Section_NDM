﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Штатно формирует, сохраняет и повторно открывает Contour в Excel/File, мм/см/м и двух разделителях Excel.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01'
$dir=Join-Path $scratch 'HashUiReopen01';if(Test-Path -LiteralPath $dir){throw 'New directory required'};[void][IO.Directory]::CreateDirectory($dir)
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestHashReopenOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$range=$null;$oldSeparators=$null;$records=New-Object 'System.Collections.Generic.List[object]';$primaryError=''

# Меняет только частную копию; видимые пользовательские источники не открываются.
function Set-TestSetting([string]$Key,[string]$Value){
 $column=2;$field=$Key
 if($Key.StartsWith('Units.')){$range=$book.Names.Item('rngUnitSettings').RefersToRange;$field=$Key.Split('.')[1];$column=4}else{$range=$book.Names.Item('rngSystemSettings').RefersToRange}
 $matrix=$range.Value2
 for($row=1;$row-le$matrix.GetLength(0);$row++){if([string]$matrix[$row,1]-ceq$field){$range.Cells.Item($row,$column).Value2=$Value;return}}
 throw ('Setting missing '+$Key)
}
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestHashReopenOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $oldSeparators=@{UseSystem=[bool]$app.UseSystemSeparators;Decimal=[string]$app.DecimalSeparator;Thousands=[string]$app.ThousandsSeparator}
 foreach($mode in @('Excel','File')){foreach($decimal in @('.',',')){foreach($unit in @('mm','cm','m')){
  $separator=if($decimal-eq'.'){'Dot'}else{'Comma'};$case=$mode+'_'+$separator+'_'+$unit
  $caseDir=Join-Path $dir $case;[void][IO.Directory]::CreateDirectory($caseDir)
  $path=Join-Path $caseDir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $scratch 'HashUiDirected02/RC_Section_NDM.xlsm') -Destination $path
  $app.UseSystemSeparators=$false;$app.DecimalSeparator=$decimal;$app.ThousandsSeparator=if($decimal-eq'.'){','}else{'.'}
  $book=$app.Workbooks.Open($path,0,$false)
  Set-TestSetting 'Mesh.CellGeometry' 'Contour';Set-TestSetting 'Results.SnapshotStorage' $mode
  Set-TestSetting 'Results.SnapshotName' 'TestHashRoundtrip';Set-TestSetting 'Units.Length.Output' $unit;Set-TestSetting 'Units.Area.Output' ($unit+'2')
  Set-TestSetting 'Plot.Enabled' 'No';Set-TestSetting 'General.ExecutionReportEnabled' 'No'
  $message=[string]$app.Run("'$($book.Name)'!FormSectionForWorkbook",$book)
  if($message-match'не сформирован|Ошибка|Предупреждение'){throw $message}
  $book.Save();$range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $book.Close($false);$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $hash=(Get-FileHash -LiteralPath $path).Hash
  $book=$app.Workbooks.Open($path,0,$true)
  $report=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.RunStoredGeometryHashTests")
  [IO.File]::WriteAllText((Join-Path $caseDir 'Primary.txt'),$report,[Text.Encoding]::UTF8)
  $total=[regex]::Matches($report,'TOTAL_STORED_GEOMETRY_HASH: passed=(\d+); failed=(\d+)')
  if($total.Count-ne1-or[int]$total[0].Groups[2].Value-ne0){throw ('Stored hash validation failed '+$case)}
  $records.Add([ordered]@{Case=$case;Passed=[int]$total[0].Groups[1].Value;Failed=0;WorkbookSHA256=$hash;SavedAndReopened=$true;ReadOnly=[bool]$book.ReadOnly;WindowsLocaleChanged=$false;Message=$message})
  $records|ConvertTo-Json -Depth 6|Set-Content (Join-Path $dir 'Results.json') -Encoding UTF8
  $book.Close($false);$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if((Get-FileHash -LiteralPath $path).Hash-cne$hash){throw 'Readonly validation changed package'}
  Write-Output ('HASH_REOPEN '+$case+': '+$records[$records.Count-1]['Passed']+'/0')
 }}}
 [ordered]@{Status='PASS_DIRECTED_ONLY';Cases=$records.Count;ExpectedCases=12;Failed=0;FullSuite=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Acceptance.json') -Encoding UTF8
}catch{
 $primaryError=$_.Exception.ToString();[ordered]@{Error=$primaryError;Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $dir 'Failure.json') -Encoding UTF8
 throw
}finally{
 $range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){if($oldSeparators){$app.UseSystemSeparators=$false;$app.DecimalSeparator=$oldSeparators.Decimal;$app.ThousandsSeparator=$oldSeparators.Thousands;$app.UseSystemSeparators=$oldSeparators.UseSystem};$app.Quit()}
 $app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$process=Get-Process -Id $owned -ErrorAction Stop;if($process.ProcessName-ne'EXCEL'-or$process.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false;PrimaryError=$primaryError;SeparatorsRestored=$true}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
