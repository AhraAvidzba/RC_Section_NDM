"""ДЛЯ ТЕСТОВ: добавляет таймеры в фактический VBA только частных копий."""
from pathlib import Path
import re
import sys

SCRATCH = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')
case = sys.argv[1]
native = SCRATCH/'NativeActual'/case
out = SCRATCH/'Instrumented'/case
out.mkdir(parents=True,exist_ok=True)
methods = {
    'modWorkbookCalculation':['RunSectionCalculationForWorkbook','FormSectionForWorkbook','UpdateSectionPlotForWorkbook','UpdateSectionGeometryPreviewForWorkbook'],
    'modSectionSnapshot':['ReadConcreteBoundaryMap','ReadSavedConcreteBoundaries','ReadSectionGeometryFromResults','SavedConcreteRegion','ValidateSavedBoundaryProperties'],
    'CCalculationSnapshot':['Validate','ValidateGeometryPreview'],
    'CSectionPlotDataReader':['LoadFromWorkbook','LoadGeometryPreviewFromWorkbook','ReadGeometryAndResults','ReadGeometryPreview'],
    'CSectionPlotter':['Draw','PrepareChart','AddConcreteElementShape'],
    'CNDMResultsWriter':['WriteResults','WriteGeometryPreview','RestoreSnapshotBase','PrepareGeometryPreviewSnapshot'],
    'CExcelAppStateGuard':['Enter','Restore'],
    'CFiberMeshBuilder':['BuildMesh'],
}
for module,names in methods.items():
    text=(native/(module+'.txt')).read_text(encoding='utf-8-sig')
    for name in names:
        pattern=rf'(?ims)^((?:Public |Private |Friend )?(Function|Sub) {re.escape(name)}\b.*?^End \2)'
        matches=list(re.finditer(pattern,text))
        if len(matches)!=1:
            raise ValueError((module,name,len(matches)))
        match=matches[0]
        body=match.group(1)
        lines=body.splitlines()
        i=0
        while lines[i].rstrip().endswith('_'):
            i+=1
        tag=module+'.'+name
        lines.insert(i+1,f'    modTestActionProfiler.TestBegin "{tag}"')
        body='\n'.join(lines)
        kind=match.group(2)
        body=body.replace('Exit '+kind,f'modTestActionProfiler.TestEnd "{tag}": Exit {kind}')
        body=body.rsplit('End '+kind,1)[0]+f'    modTestActionProfiler.TestEnd "{tag}"\nEnd {kind}'
        text=text[:match.start()]+body+text[match.end():]
    (out/(module+'.txt')).write_text(text,encoding='utf-8-sig')
print(f'INSTRUMENTED {case}: {sum(map(len,methods.values()))} methods')
