﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Подтверждает освобождение всех записанных собственных идентичностей без завершения процессов.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01'
$identities=@{}
foreach($directory in @($scratch,$PSScriptRoot)){
 foreach($file in Get-ChildItem -LiteralPath $directory -Recurse -File -Filter '*Ownership.json'){
  $v=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
  if(-not$v.PID-or-not$v.StartTicksUTC){continue}
  $key=[string]$v.PID+':'+[string]$v.StartTicksUTC
  $identities[$key]=[ordered]@{PID=[int]$v.PID;StartTicksUTC=[string]$v.StartTicksUTC;Evidence=$file.FullName}
 }
}
$results=New-Object 'System.Collections.Generic.List[object]'
foreach($identity in $identities.Values){
 $state='';$actualTicks='';$actualName=''
 try{
  $process=Get-Process -Id $identity.PID -ErrorAction Stop
  $actualTicks=[string]$process.StartTime.ToUniversalTime().Ticks;$actualName=$process.ProcessName
  if($actualTicks-ceq$identity.StartTicksUTC-and$actualName-ceq'EXCEL'){$state='SAME_IDENTITY_LIVE'}else{$state='RELEASED_DIFFERENT_IDENTITY'}
 }catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$state='ABSENT'}else{throw}}
 $results.Add([ordered]@{PID=$identity.PID;StartTicksUTC=$identity.StartTicksUTC;State=$state;ActualProcess=$actualName;ActualStartTicksUTC=$actualTicks})
}
$unreleased=@($results|Where-Object {$_.State-eq'SAME_IDENTITY_LIVE'})
[ordered]@{Passed=($unreleased.Count-eq0);Identities=$results.ToArray();Actions='ReadOnly';ForceKilled=$false;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot 'ProcessClosure.json') -Encoding UTF8
if($unreleased.Count){throw 'Own Excel identity still live'}
Write-Output ('OWN_IDENTITIES_RELEASED: '+$results.Count)
