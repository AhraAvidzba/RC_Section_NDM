"""ДЛЯ ТЕСТОВ: независимая приёмка первичных журналов и перенос только проверенного кода."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent
P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')


def sha(data):
    """Подписывает точные байты, включая кодировку и окончания строк."""
    return hashlib.sha256(data).hexdigest().upper()


def read_json(path):
    """Читает JSON PowerShell с возможным BOM."""
    return json.loads(path.read_text('utf-8-sig'))


def review(path):
    """Пересчитывает каждый PASS и единственный итог; отдельный JSON не заменяет первичный текст."""
    data = path.read_bytes()
    text = data.decode('utf-8-sig')
    totals = re.findall(r'^TOTAL[^\r\n]*?(?:passed=)?(\d+)(?:; failed=|/)(\d+)\s*$', text, re.M)
    assert len(totals) == 1, path
    passed, failed = map(int, totals[0])
    assert failed == 0 and not re.search(r'^(FAIL|RUNTIME|WATCHDOG_FAILURE)\b', text, re.M), path
    assert len(re.findall(r'^PASS\b', text, re.M)) == passed, path
    return dict(Path=str(path.relative_to(P)), Bytes=len(data), SHA256=sha(data), Passed=passed, Failed=failed)


logs = []
entries = ('RunWorkbookActionCompletionTests','RunGeometryHashTests','RunPreparedSnapshotReuseTests','RunConcreteGeometrySnapshotTests','RunGeometryPreviewStorageTests','RunFileGeometryAuthorityTests','RunCalculationSnapshotTests')
for mode in ('No','Yes'):
    logs += [review(P/'HashUiDirected02'/f'{entry}_{mode}.txt') for entry in entries]
    logs.append(review(P/'ButtonCompletion02'/f'RunButtonCompletionProbeTests_{mode}.txt'))
for mode in ('No','Yes'):
    logs += [review(P/'HashUiDirected03'/f'{entry}_{mode}.txt') for entry in ('RunWorkbookActionCompletionTests','RunGeometryHashTests','modTestAudit02Api.RunProgramMessagePresentationTests')]
for storage in ('Excel','File'):
    for separator in ('Dot','Comma'):
        for unit in ('mm','cm','m'):
            logs.append(review(P/'HashUiReopen01'/f'{storage}_{separator}_{unit}'/'Primary.txt'))
closures = {}
for case in ('HashUiDirected02','HashUiDirected03','ButtonCompletion02','HashUiReopen01','FinalFreshPaired_Contour_Excel','FinalFreshPaired_Adaptive_Excel','FinalFreshPaired_Contour_File'):
    closure = read_json(P/case/'Closure.json')
    assert closure['Absent'] and not closure['ForceKilled'], case
    closures[case] = closure
for case in ('FinalFreshPaired_Contour_Excel','FinalFreshPaired_Adaptive_Excel','FinalFreshPaired_Contour_File'):
    assert read_json(P/case/'Parity.json')['Passed'], case
# Финальный UI меняет только показ окна и удаляет лишний Chart.Refresh; расчётная/снимочная логика идентична полному адресному повтору.
old = P/'HashUiCandidate01'; new = P/'HashUiCandidate02'
changed = [f.name for f in old.glob('*') if f.suffix in ('.cls','.bas') and f.read_bytes() != (new/f.name).read_bytes()]
assert sorted(changed) == ['CSectionPlotter.cls','modWorkbookCalculation.bas','modWorkbookMessages.bas']
# В модуле сценария отличается исключительно пояснение последнего показа времени.
def code_without_comments(path):
    return '\n'.join(line.split("'",1)[0].rstrip() for line in path.read_text('utf-8').splitlines())
assert code_without_comments(old/'modWorkbookCalculation.bas') == code_without_comments(new/'modWorkbookCalculation.bas')
proof = dict(Status='PASS_DIRECTED_ONLY', FullSuite=False, Passed=sum(r['Passed'] for r in logs), Failed=0, Logs=logs, Closures=closures, RegressionBasis=dict(SnapshotAndHashImplementationUnchanged=True, FinalUIRetestedNoYes=True, ChangedFiles=changed))
(E/'FinalDirectedAcceptance.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')

manifest = read_json(P/'HashUiCandidate02/DeferredSourceManifest.json')
assert len(manifest['Changes']) == 12
for item in manifest['Changes']:
    assert sha((ROOT/item['Path']).read_bytes()) == item['OriginalSHA256'], item
    assert sha((P/'HashUiCandidate02'/Path(item['Path']).name).read_bytes()) == item['CandidateSHA256'], item
base = ROOT/'workbook/output/RC_Section_NDM.xlsm'
assert sha(base.read_bytes()) == '8E73B609D83347693E85E03DEEA46B478AA12E45EA88BE8DC3FC9193C622922D', 'User book changed: recapture required'
assert sha((ROOT/'workbook/output/NDM_Test_1232_30/RC_Section_NDM_ok.xlsm').read_bytes()) == '31F188692A01CC421A37CF962598778A5AD1FE6D9AB5D96DD41C29389C0919F7'
for item in manifest['Changes']:
    (ROOT/item['Path']).write_bytes((P/'HashUiCandidate02'/Path(item['Path']).name).read_bytes())
(E/'FinalSourceTransfer.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')

target = P/'Publication02/RC_Section_NDM.xlsm'
target.parent.mkdir(exist_ok=False)
(target.parent/'UserBase.xlsm').write_bytes(base.read_bytes())
with zipfile.ZipFile(P/'HashUiDirected03/RC_Section_NDM.xlsm') as z:
    vba = z.read('xl/vbaProject.bin')
with zipfile.ZipFile(base) as old, zipfile.ZipFile(target,'w') as new:
    for item in old.infolist():
        new.writestr(item, vba if item.filename=='xl/vbaProject.bin' else old.read(item.filename))
with zipfile.ZipFile(base) as old, zipfile.ZipFile(target) as new:
    assert old.namelist() == new.namelist() and new.testzip() is None
    unchanged = [n for n in old.namelist() if n != 'xl/vbaProject.bin' and old.read(n) == new.read(n)]
    assert len(unchanged) == len(old.namelist())-1 == 108
preservation = dict(UserBaseSHA256=sha(base.read_bytes()), CandidateSHA256=sha(target.read_bytes()), VBASHA256=sha(vba), UnchangedParts=unchanged, ChangedParts=['xl/vbaProject.bin'], UserDataPreserved=True, HeavyBookTouched=False, BuildSync='The builder imports these same production/test sources; layout and catalogs unchanged.')
(E/'FinalPackagePreservation.json').write_text(json.dumps(preservation,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(Passed=proof['Passed'],SourceFiles=12,CandidateSHA256=preservation['CandidateSHA256']),ensure_ascii=False))
