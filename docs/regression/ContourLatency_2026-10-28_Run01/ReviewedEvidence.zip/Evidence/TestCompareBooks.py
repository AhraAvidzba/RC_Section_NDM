"""ДЛЯ ТЕСТОВ: независимо сравнивает сохранённые Excel-результаты ABBA без VBA."""
from pathlib import Path
import json
import re
import zipfile
import xml.etree.ElementTree as ET

P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}


def read(path):
    """Возвращает типизированные значения Results и именованные диапазоны напрямую из ZIP."""
    with zipfile.ZipFile(path) as z:
        ss = ET.fromstring(z.read('xl/sharedStrings.xml'))
        strings = [''.join(n.itertext()) for n in ss]
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets = {r.attrib['Id']: r.attrib['Target'] for r in rels}
        sheet = next(s for s in wb.find('s:sheets', NS) if s.attrib['name'] == 'Results')
        target = targets[sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
        cells = {}
        for c in ET.fromstring(z.read('xl/' + target)).findall('.//s:sheetData/s:row/s:c', NS):
            value = c.find('s:v', NS)
            if value is None:
                continue
            value = value.text
            typ = c.attrib.get('t', 'n')
            cells[c.attrib['r']] = (typ, strings[int(value)] if typ == 's' else value)
        names = {n.attrib['name']: n.text for n in wb.find('s:definedNames', NS)}
        return cells, names


left, names = read(P / 'Paired01/Original.xlsm')
right, _ = read(P / 'Paired01/Candidate.xlsm')
diff = []
for address in sorted(left.keys() | right.keys()):
    a, b = left.get(address), right.get(address)
    if a == b:
        continue
    if a and b and a[0] == b[0] == 'n' and float(a[1]) == float(b[1]):
        continue
    diff.append({'Cell': address, 'Original': a, 'Candidate': b})
report = {'CellsOriginal': len(left), 'CellsCandidate': len(right), 'Differences': diff,
          'Names': {k:v for k,v in names.items() if 'Results!' in v or "'Results'!" in v}}
(P / 'Paired01/RawParity.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
run_columns = {re.search(r'!\$([A-Z]+)\$', names[n])[1] for n in
               ('rngNDMElementGeometry','rngNDMElementResults','rngNDMMaterialDiagrams',
                'rngNDMSectionAnnotations','rngNDMSectionContours','rngNDMSectionGeometry','rngNDMSectionProperties')}
run_ids, other = [], []
for d in diff:
    col, row = re.fullmatch(r'([A-Z]+)(\d+)', d['Cell']).groups()
    a, b = d['Original'], d['Candidate']
    if col in run_columns and int(row) > 156 and a and b and a[0] == b[0] == 'n' and 46000 < float(a[1]) < 47000 and 46000 < float(b[1]) < 47000:
        run_ids.append(d)
    elif d['Cell'] != 'A4':
        other.append(d)
assert all(left[col+'156'] == ('s','RunID') for col in run_columns)
assert left['A4'][0] == right['A4'][0] == 'n'
proof = {'Passed': not other, 'ComparedOriginalCells': len(left), 'ComparedCandidateCells': len(right),
         'RunIDCellsExcluded': len(run_ids), 'MeasuredElapsedSecondsCellExcluded': 'A4',
         'OriginalRunIDs': sorted({d['Original'][1] for d in run_ids}),
         'CandidateRunIDs': sorted({d['Candidate'][1] for d in run_ids}),
         'OtherDifferences': other, 'Scope': 'All saved Results values, including statuses, comments, boundaries and numeric results; no tolerance'}
(P / 'Paired01/Parity.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(proof, ensure_ascii=False))
assert proof['Passed']
