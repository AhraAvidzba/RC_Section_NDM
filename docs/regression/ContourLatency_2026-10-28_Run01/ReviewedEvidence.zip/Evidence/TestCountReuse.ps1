﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Считает реальные разборы границ в штатных действиях на двух частных копиях.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01'
$dir=Join-Path $scratch 'ReadCounts01';if(Test-Path -LiteralPath $dir){throw 'New directory required'};[void][IO.Directory]::CreateDirectory($dir)
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCountOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$project=$null;$code=$null;$compile=$null;$records=New-Object 'System.Collections.Generic.List[object]'
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestCountOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 foreach($case in @('Original','Candidate')){
  $path=Join-Path $dir ($case+'.xlsm');Copy-Item -LiteralPath (Join-Path $scratch 'Contour/RC_Section_NDM.xlsm') -Destination $path
  $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
  if($case-eq'Candidate'){
   foreach($file in Get-ChildItem -LiteralPath (Join-Path $scratch 'Candidate') -File|Where-Object {$_.Extension-in@('.bas','.cls')}){
    $code=$project.VBComponents.Item($file.BaseName).CodeModule;$body=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
    if($file.Extension-eq'.cls'){$body=$body.Substring($body.IndexOf('Option Explicit'))}else{$body=[regex]::Replace($body,'(?m)^Attribute [^\r\n]*\r?\n','')}
    $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
   }
  }
  $code=$project.VBComponents.Item('modSectionSnapshot').CodeModule;$body=[string]$code.Lines(1,$code.CountOfLines)
  $body=$body.Replace('Option Explicit',"Option Explicit`r`nPrivate mTestBoundaryMapCalls As Long")
  $at=$body.IndexOf('Public Function ReadConcreteBoundaryMap(',[StringComparison]::OrdinalIgnoreCase)
  $at=$body.IndexOf('    Dim result As Object',$at,[StringComparison]::OrdinalIgnoreCase)
  $body=$body.Insert($at,"    mTestBoundaryMapCalls = mTestBoundaryMapCalls + 1`r`n")
  $body+="`r`n' -------------------- ДЛЯ ТЕСТОВ --------------------`r`n' Счётчик вызовов не меняет геометрические проверки.`r`nPublic Function TestBoundaryMapCalls(Optional ByVal reset As Boolean = False) As Long`r`nTestBoundaryMapCalls = mTestBoundaryMapCalls`r`nIf reset Then mTestBoundaryMapCalls = 0`r`nEnd Function`r`n"
  $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Count compilation failed'}
  $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  foreach($action in @('FormSectionForWorkbook','RunSectionCalculationForWorkbook')){
   [void]$app.Run("'$($book.Name)'!modSectionSnapshot.TestBoundaryMapCalls",$true)
   $message=[string]$app.Run("'$($book.Name)'!$action",$book)
   $calls=[int]$app.Run("'$($book.Name)'!modSectionSnapshot.TestBoundaryMapCalls")
   if($message-match'не выполнен|не сформирован|Ошибка|Предупреждение'){throw $message}
   $records.Add([ordered]@{Case=$case;Action=$action;FullBoundaryReads=$calls;Message=$message})
   $records|ConvertTo-Json -Depth 6|Set-Content (Join-Path $dir 'Results.json') -Encoding UTF8
   Write-Output ($case+' '+$action+': full reads '+$calls)
  }
  $book.Close($false);$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 }
}finally{
 $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$w=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($w.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
