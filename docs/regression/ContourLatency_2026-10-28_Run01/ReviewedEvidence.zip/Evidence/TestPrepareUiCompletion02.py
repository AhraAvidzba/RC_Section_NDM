"""ДЛЯ ТЕСТОВ: завершение отрисовки и полный таймер в изолированном кандидате."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[3]
P=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')
OUT=P/'HashUiCandidate02';OUT.mkdir(exist_ok=True)
manifest=json.loads((P/'HashCandidate01/DeferredSourceManifest.json').read_text(encoding='utf-8'))
changes={r['Path']:r for r in manifest['Changes']}
for r in changes.values():
    (OUT/Path(r['Path']).name).write_bytes((P/'HashCandidate01'/Path(r['Path']).name).read_bytes())


def save(rel, text):
    """Фиксирует патч относительно опубликованного P1, не меняя участвующие рабочие источники."""
    data=text.encode('utf-8');(OUT/Path(rel).name).write_bytes(data)
    changes[rel]=dict(Path=rel,OriginalSHA256=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest().upper(),CandidateSHA256=hashlib.sha256(data).hexdigest().upper())


rel='src/Excel/modWorkbookMessages.bas';s=(ROOT/rel).read_text(encoding='utf-8-sig')
at=s.index('#If VBA7 Then')
s=s[:at]+"Private mPendingDrawingBooks As Collection ' Готовые изменения диаграмм до завершения показа; расчётные данные здесь не кэшируются.\n\n"+s[at:]
s=s.replace('    Private Declare PtrSafe Function MessageBoxUnicode', '''    Private Declare PtrSafe Function PaintPendingWindow Lib "user32" Alias "RedrawWindow" ( _
        ByVal window As LongPtr, ByVal rectangle As LongPtr, ByVal region As LongPtr, ByVal flags As Long) As Long
    Private Declare PtrSafe Function MessageBoxUnicode''',1)
s=s.replace('    Private Declare Function MessageBoxUnicode', '''    Private Declare Function PaintPendingWindow Lib "user32" Alias "RedrawWindow" ( _
        ByVal window As Long, ByVal rectangle As Long, ByVal region As Long, ByVal flags As Long) As Long
    Private Declare Function MessageBoxUnicode''',1)
s=s.replace('    displayText = WorkbookDialogText(message)', '''    Dim drawingWarning As String: drawingWarning = TryCompleteWorkbookDrawing(ThisWorkbook)
    If Len(drawingWarning) > 0 Then
        message = WorkbookMessageParagraph(message, drawingWarning)
        If style = vbInformation Then style = vbExclamation
    End If
    displayText = WorkbookDialogText(message)''',1)
s+='''

' Запоминает только необходимость закончить показ уже изменённой диаграммы, без повторного построения схемы.
Public Sub MarkWorkbookDrawingPending(ByVal workbook As Object)
    If mPendingDrawingBooks Is Nothing Then Set mPendingDrawingBooks = New Collection
    Dim pending As Object
    For Each pending In mPendingDrawingBooks
        If pending Is workbook Then Exit Sub
    Next pending
    mPendingDrawingBooks.Add workbook
End Sub

' После восстановления ScreenUpdating завершает показ готовой схемы и WM_PAINT своей книги.
' DoEvents не вызывается: обработчик не передаёт управление повторным нажатиям кнопок и очереди OnTime.
Public Sub CompleteWorkbookDrawing(ByVal workbook As Object)
    If workbook Is Nothing Then Exit Sub
    If Not workbook.Application.ScreenUpdating Then Exit Sub
    Dim refresh As Boolean, pending As Object, i As Long
    If Not mPendingDrawingBooks Is Nothing Then
        For i = mPendingDrawingBooks.Count To 1 Step -1
            Set pending = mPendingDrawingBooks.Item(i)
            If pending Is workbook Then mPendingDrawingBooks.Remove i: refresh = True
        Next i
        If mPendingDrawingBooks.Count = 0 Then Set mPendingDrawingBooks = Nothing
    End If
    Dim window As Object, succeeded As Long, flags As Long: flags = &H180&
    If refresh Then flags = flags Or &H1& ' Перерисовывается готовое окно; Chart.Refresh повторно не перестраивает диаграмму.
    For Each window In workbook.Windows
        If window.hWnd <> 0 Then ' Нулевой HWND обозначал бы рабочий стол Windows; его эта операция не затрагивает.
#If VBA7 Then
            succeeded = PaintPendingWindow(CLngPtr(window.hWnd), 0, 0, flags)
#Else
            succeeded = PaintPendingWindow(window.hWnd, 0, 0, flags)
#End If
            If succeeded = 0 Then Err.Raise vbObjectError + 4251, "CompleteWorkbookDrawing", "Excel не смог завершить обновление окна книги. Код Windows: " & CStr(Err.LastDllError)
        End If
    Next window
End Sub

' Сохранённые данные и НДС не превращаются в неудачный расчёт из-за отдельной ошибки экранного показа.
Public Function TryCompleteWorkbookDrawing(ByVal workbook As Object) As String
    On Error GoTo Failed
    CompleteWorkbookDrawing workbook
    Exit Function
Failed:
    TryCompleteWorkbookDrawing = "Предупреждение:" & vbCrLf & "Excel не завершил отрисовку схемы или окна книги. Данные сохранены." & vbCrLf & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет завершение показа конкретной книги без требования, чтобы чужие API-действия отсутствовали.
Public Function TestWorkbookDrawingPending(ByVal workbook As Object) As Boolean
    If mPendingDrawingBooks Is Nothing Then Exit Function
    Dim pending As Object
    For Each pending In mPendingDrawingBooks
        If pending Is workbook Then TestWorkbookDrawingPending = True: Exit Function
    Next pending
End Function
'''
save(rel,s)

rel='src/Excel/CSectionPlotter.cls';s=(ROOT/rel).read_text(encoding='utf-8-sig')
assert s.count('    DrawPlotTitleOverlay PlotTitleText(data)\nEnd Sub')==1
s=s.replace('    DrawPlotTitleOverlay PlotTitleText(data)\nEnd Sub','    DrawPlotTitleOverlay PlotTitleText(data)\n    MarkWorkbookDrawingPending workbook\nEnd Sub',1)
assert s.count('    DrawPlotTitleOverlay titleText\nEnd Sub')==1
s=s.replace('    DrawPlotTitleOverlay titleText\nEnd Sub','    DrawPlotTitleOverlay titleText\n    MarkWorkbookDrawingPending workbook\nEnd Sub',1)
save(rel,s)

rel='src/Excel/modCalculationSnapshot.bas';s=(ROOT/rel).read_text(encoding='utf-8-sig')
start=s.index('Public Sub UpdateSectionResultsForWorkbook(');end=s.index('\nEnd Sub',start)
part=s[start:end].replace('    guard.Restore True','    guard.Restore True\n    CompleteWorkbookDrawing workbook')
s=s[:start]+part+s[end:]
save(rel,s)


def rename_code(text, old, new):
    """Меняет имя результата функции, сохраняя строковые Source/диагностику и русские комментарии."""
    result=[]
    for line in text.splitlines():
        chunks=re.split(r'("(?:[^"]|"")*"|\x27.*$)',line)
        result.append(''.join(c if c.startswith(('"',"'")) else re.sub(r'\b'+old+r'\b',new,c) for c in chunks))
    return '\n'.join(result)


rel='src/Excel/modWorkbookCalculation.bas';s=(ROOT/rel).read_text(encoding='utf-8-sig')
# При прямом вызове обновления схема тоже завершается; внутри внешнего guard экран ещё выключен и финиш откладывается.
s=s.replace('    plotter.Draw workbook, reader, settings\nEnd Sub','    plotter.Draw workbook, reader, settings\n    CompleteWorkbookDrawing workbook\nEnd Sub')
for public,core,calc in [('FormSectionForWorkbook','FormSectionCore',False),('RunSectionCalculationForWorkbook','CalculateSectionCore',True)]:
    start=s.index('Public Function '+public+'(');end=s.index('\nEnd Function',start)+len('\nEnd Function')
    old=s[start:end];signature=old[:old.index(') As String')+len(') As String')]
    body=rename_code(old,public,core).replace('Public Function '+core,'Private Function '+core,1)
    sigend=body.index(') As String')
    extra=', _\n        Optional ByRef completed As Boolean = False'
    if calc:extra+=', Optional ByRef savedDestination As String = ""'
    body=body[:sigend]+extra+body[sigend:]
    body=body.replace('    On Error GoTo Failed','    completed = False\n    On Error GoTo Failed',1)
    caption='Время расчёта' if calc else 'Время формирования сечения'
    body=re.sub(r'(?m)^    '+core+r' = '+core+r' & vbCrLf & vbCrLf & _\n        "'+caption+r': "[^\n]*\n','',body)
    if calc:
        body=re.sub(r'(?m)^    (?:savedSnapshot.ElapsedSeconds = ElapsedSecondsFrom\(runStart\)|snapshotStore.UpdateSavedElapsed workbook, savedSnapshot|summaryWriter.UpdateElapsedSeconds workbook,[^\n]*)\n','',body)
        body=body.replace('        summaryWriter.UpdateElapsedSeconds workbook, ElapsedSecondsFrom(runStart)\n','')
        body=body.replace('    Dim savedDestination As String: savedDestination =','    savedDestination =')
        body=body.replace('    '+core+' = '+core+' & vbCrLf & vbCrLf & "Данные сохранены " & savedDestination & "."\n','')
    at=body.rindex('    Exit Function');body=body[:at]+'    completed = True\n'+body[at:]
    if calc:
        wrapper=signature+'''
    If startedAt < 0# Then startedAt = Timer
    Dim completed As Boolean, destination As String, message As String
    message = CalculateSectionCore(workbook, showMessages, startedAt, informationEnabled, requiresAttention, completed, destination)
    If completed Then
        message = FinishWorkbookAction(workbook, message, startedAt, "Время расчёта", requiresAttention, True)
        message = WorkbookMessageParagraph(message, "Данные сохранены " & destination & ".")
    End If
    RunSectionCalculationForWorkbook = message
End Function
'''
    else:
        wrapper=signature+'''
    If startedAt < 0# Then startedAt = Timer
    Dim completed As Boolean, message As String
    message = FormSectionCore(workbook, startedAt, informationEnabled, requiresAttention, completed)
    If completed Then message = FinishWorkbookAction(workbook, message, startedAt, "Время формирования сечения", requiresAttention)
    FormSectionForWorkbook = message
End Function
'''
    body="' Выполняет основную работу; тяжёлые модели и временные таблицы освобождаются до финального измерения в обёртке.\n"+body
    s=s[:start]+wrapper+'\n'+body+s[end:]
s+='''

' Завершает показ после освобождения расчётных объектов и учитывает подготовку, запись, отчёт и отрисовку.
' Время ожидания OK сюда не входит; после возвращения остаётся только форматирование самого окна.
Private Function FinishWorkbookAction(ByVal workbook As Object, ByVal message As String, ByVal startedAt As Double, _
        ByVal timeCaption As String, ByRef requiresAttention As Boolean, Optional ByVal calculated As Boolean = False) As String
    Dim warning As String: warning = TryCompleteWorkbookDrawing(workbook)
    If Len(warning) > 0 Then requiresAttention = True: message = WorkbookMessageParagraph(message, warning)
    If calculated Then
        Dim snapshot As CCalculationSnapshot: Set snapshot = New CCalculationSnapshot
        snapshot.ElapsedSeconds = ElapsedSecondsFrom(startedAt)
        Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
        store.UpdateSavedElapsed workbook, snapshot
        Dim summary As CBatchResultWriter: Set summary = New CBatchResultWriter
        summary.UpdateElapsedSeconds workbook, snapshot.ElapsedSeconds
        Dim finalWarning As String: finalWarning = TryCompleteWorkbookDrawing(workbook) ' Диаграмма не перестраивается: закрывается только показ последней ячейки времени.
        If Len(finalWarning) > 0 And finalWarning <> warning Then requiresAttention = True: message = WorkbookMessageParagraph(message, finalWarning)
    End If
    FinishWorkbookAction = WorkbookMessageParagraph(message, timeCaption & ": " & Format$(ElapsedSecondsFrom(startedAt), "0.00") & " с.")
End Function
'''
save(rel,s)

rel='tests/modTestCalculationSnapshot.bas';s=(OUT/Path(rel).name).read_text(encoding='utf-8')
s+=r'''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет внешний таймер и завершение показа до возврата API, не открывая модальное окно.
Public Function RunWorkbookActionCompletionTests() As String
    mTestReport = "": mTestPassed = 0: mTestFailed = 0
    Dim originalSettings As Variant: originalSettings = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange.Formula
    Dim originalScreen As Boolean: originalScreen = Application.ScreenUpdating
    On Error GoTo Failed
    TestSnapshotSetting "Mesh.CellGeometry", "Contour"
    TestSnapshotSetting "Results.SnapshotStorage", "Excel"
    TestSnapshotSetting "Plot.Enabled", "Yes"
    TestSnapshotSetting "General.ExecutionReportEnabled", "No"
    Application.ScreenUpdating = False
    MarkWorkbookDrawingPending ThisWorkbook
    CompleteWorkbookDrawing ThisWorkbook
    TestSnapshotCheck "action.paint.deferredWhileGuarded", TestWorkbookDrawingPending(ThisWorkbook)
    Application.ScreenUpdating = True
    CompleteWorkbookDrawing ThisWorkbook
    TestSnapshotCheck "action.paint.completedAfterRestore", Not TestWorkbookDrawingPending(ThisWorkbook)
    Dim message As String, started As Double, information As Boolean, attention As Boolean, position As Long, duration As Double
    started = Timer - 0.5
    message = FormSectionForWorkbook(ThisWorkbook, started, information, attention)
    TestSnapshotCheck "action.form.noWarning", Not attention
    TestSnapshotCheck "action.form.paintCompleted", Not TestWorkbookDrawingPending(ThisWorkbook)
    position = InStr(message, "Время формирования сечения: ") + Len("Время формирования сечения: ")
    duration = CDbl(Split(Mid$(message, position), " с.")(0))
    TestSnapshotCheck "action.form.outerTimer", duration >= 0.5
    Call TestSavedBoundaryReadCounts(True)
    started = Timer - 0.5
    message = RunSectionCalculationForWorkbook(ThisWorkbook, False, started, information, attention)
    TestSnapshotCheck "action.calc.noWarning", InStr(message, "Предупреждение:") = 0
    TestSnapshotCheck "action.calc.paintCompleted", Not TestWorkbookDrawingPending(ThisWorkbook)
    position = InStr(message, "Время расчёта: ") + Len("Время расчёта: ")
    duration = CDbl(Split(Mid$(message, position), " с.")(0))
    TestSnapshotCheck "action.calc.outerTimer", duration >= 0.5
    TestSnapshotCheck "action.calc.readScopeReleased", TestCalculationSnapshotReadReleased()
    TestSnapshotCheck "action.calc.fastBoundaries", Left$(TestSavedBoundaryReadCounts(), 2) = "0/"
    Dim counts As String: counts = TestSavedBoundaryReadCounts()
    CompleteWorkbookDrawing ThisWorkbook
    TestSnapshotCheck "action.paint.noRepeatedGeometry", TestSavedBoundaryReadCounts() = counts
    TestSnapshotCheck "action.destination.last", Right$(message, Len("Данные сохранены на листе Results текущей книги.")) = "Данные сохранены на листе Results текущей книги."
    GoTo Finished
Failed:
    TestSnapshotCheck "action.runtime " & CStr(Err.Number) & ": " & Err.Description, False
Finished:
    On Error Resume Next
    ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange.Formula = originalSettings
    Application.ScreenUpdating = originalScreen
    On Error GoTo 0
    RunWorkbookActionCompletionTests = mTestReport & "TOTAL_ACTION_COMPLETION: passed=" & CStr(mTestPassed) & "; failed=" & CStr(mTestFailed)
End Function
'''
save(rel,s)

(OUT/'DeferredSourceManifest.json').write_text(json.dumps({'Status':'PREPARED_NOT_VALIDATED','Changes':list(changes.values()),'Scope':'Numeric geometry hash plus synchronous final paint and outer action timing; no math changes'},ensure_ascii=False,indent=2),encoding='utf-8')
print('HASH_UI_CANDIDATE',len(changes))
