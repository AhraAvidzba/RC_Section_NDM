﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Запускает настоящую кнопку только после готовности computer-use к собственному окну.
param([ValidateSet('Contour','Adaptive')][string]$Case='Contour',[switch]$NoPlot)
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01'
$label=$Case+$(if($NoPlot){'_NoPlot'}else{'_Plot'})
$dir=Join-Path $scratch ('Dialog/'+$label);if(Test-Path -LiteralPath $dir){throw 'New dialog directory required'};[void][IO.Directory]::CreateDirectory($dir)
$path=Join-Path $dir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $scratch 'Contour/RC_Section_NDM.xlsm') -Destination $path
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestContourDialogOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'

# Меняет только настройку диагностической копии.
function Set-TestSetting([string]$Key,[string]$Value){$range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2;for($r=2;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}};throw ('Setting absent '+$Key)}
$app=$null;$book=$null;$project=$null;$component=$null;$code=$null;$compile=$null
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestContourDialogOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Case=$Case;NoPlot=[bool]$NoPlot;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $scratch 'DialogCode') -Filter '*.txt'){
  if($file.BaseName-eq'modTestActionProfiler'){$component=$project.VBComponents.Add(1);$component.Name=$file.BaseName;$code=$component.CodeModule}else{$code=$project.VBComponents.Item($file.BaseName).CodeModule;$code.DeleteLines(1,$code.CountOfLines)}
  $code.AddFromString([IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8))
 }
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $scratch 'Instrumented/Contour') -Filter '*.txt'|Where-Object {$_.BaseName-ne'modWorkbookCalculation'}){$code=$project.VBComponents.Item($file.BaseName).CodeModule;$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString([IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8))}
 $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private dialog compilation failed'}
 $compile=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 Set-TestSetting 'Mesh.CellGeometry' $Case
 Set-TestSetting 'General.NonCriticalMessagesEnabled' 'Yes'
 if($NoPlot){Set-TestSetting 'Plot.Enabled' 'No'}
 $app.Visible=$true;$app.Caption='NDM_DIAGNOSTIC_'+$label;$book.Windows.Item(1).Caption='NDM_DIAGNOSTIC_'+$label
 $book.Worksheets.Item('Расчет').Activate();$app.EnableEvents=$true;$app.Calculation=-4105
 [void]$app.Run("'$($book.Name)'!modTestActionProfiler.TestReset")
 [void]$app.Run("'$($book.Name)'!FormSectionForWorkbook",$book)
 [ordered]@{State='AWAITING_SKY_READY';PID=$owned;StartTicksUTC=[string]$ticks;Case=$Case;Label=$label;Directory=$dir;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $scratch 'DialogState.json') -Encoding UTF8
 Write-Output ('DIALOG_READY '+$label+' PID='+$owned)
 $gate=[Diagnostics.Stopwatch]::StartNew()
 while(-not(Test-Path -LiteralPath (Join-Path $dir 'Launch.flag'))){if(Test-Path -LiteralPath (Join-Path $dir 'Cancel.flag')){throw 'Dialog launch cancelled before macro'};if($gate.Elapsed.TotalSeconds-gt120){throw 'Dialog was not launched: UI readiness timeout'};Start-Sleep -Milliseconds 200}
 [void]$app.Run("'$($book.Name)'!modTestActionProfiler.TestReset")
 $startQpc=[double][Diagnostics.Stopwatch]::GetTimestamp()/[Diagnostics.Stopwatch]::Frequency
 Write-Output 'DIALOG_START'
 [void]$app.Run("'$($book.Name)'!RunSectionCalculation")
 $returnQpc=[double][Diagnostics.Stopwatch]::GetTimestamp()/[Diagnostics.Stopwatch]::Frequency
 $post=[Diagnostics.Stopwatch]::StartNew();$ready=[bool]$app.Ready;$calcState=[int]$app.CalculationState;$postSeconds=$post.Elapsed.TotalSeconds
 $idle=[double]$app.Run("'$($book.Name)'!modTestActionProfiler.TestIdle")
 $timeline=[string]$app.Run("'$($book.Name)'!modTestActionProfiler.TestTimeline")
 $dump=[string]$app.Run("'$($book.Name)'!modTestActionProfiler.TestDump")
 [IO.File]::WriteAllText((Join-Path $dir 'Timeline.txt'),$timeline,[Text.Encoding]::UTF8)
 [IO.File]::WriteAllText((Join-Path $dir 'Phases.txt'),$dump,[Text.Encoding]::UTF8)
 [ordered]@{Case=$Case;NoPlot=[bool]$NoPlot;StartQpcSeconds=$startQpc;ReturnQpcSeconds=$returnQpc;ExternalIncludingDialogWait=$returnQpc-$startQpc;PostReadySeconds=$postSeconds;PostIdleSeconds=$idle;Ready=$ready;CalculationState=$calcState;RealMessageBoxW=$true}|ConvertTo-Json|Set-Content (Join-Path $dir 'Timing.json') -Encoding UTF8
 Write-Output 'DIALOG_RETURNED'
}finally{
 $compile=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$w=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($w.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
