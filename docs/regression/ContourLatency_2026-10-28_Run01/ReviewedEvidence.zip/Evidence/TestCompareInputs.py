"""ДЛЯ ТЕСТОВ: сравнивает зафиксированные пользовательские копии без открытия Excel."""
from pathlib import Path
import importlib.util
import json

HERE = Path(__file__).parent
HERE.mkdir(exist_ok=True)
ROOT = Path(__file__).resolve().parents[3]
SCRATCH = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')
reader = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/MainCleanRebuild_2026-10-28_Run01/PreviousComparisonScripts/TestComparePublishedBooks.py')
spec = importlib.util.spec_from_file_location('test_book_reader', reader)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
books = {case:module.test_read_book(SCRATCH/case/'RC_Section_NDM.xlsm') for case in ('Contour','Adaptive')}
a,b = books.values()
diffs = {k:{'Contour':a['Settings'].get(k), 'Adaptive':b['Settings'].get(k)} for k in sorted(set(a['Settings'])|set(b['Settings'])) if a['Settings'].get(k,{}).get('Value') != b['Settings'].get(k,{}).get('Value')}
report = {'SettingsDifferences':diffs,'SameVBABinary':a['VBAProjectSHA256']==b['VBAProjectSHA256'],'Books':books}
(HERE/'InputsComparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'SettingsDifferences':diffs,'SameVBABinary':report['SameVBABinary'],'Cases':{k:{'SHA256':v['SHA256'],'VBAProjectSHA256':v['VBAProjectSHA256'],'TableRows':{n:t['FirstColumnNonempty']-1 for n,t in v['Tables'].items()},'FormulaCounts':{n:t['Formulas'] for n,t in v['Sheets'].items()}} for k,v in books.items()}},ensure_ascii=False,indent=2))
