"""ДЛЯ ТЕСТОВ: собирает финальные доказательства и отчёт без нового Excel."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import statistics
import zipfile

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent
P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')


def sha(path):
    """Подписывает точные опубликованные и архивные байты."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def load(path):
    """Читает доказательства Python/PowerShell с возможным BOM."""
    return json.loads(path.read_text('utf-8-sig'))


published = load(E/'FinalPublication.json')
assert sha(ROOT/'workbook/output/RC_Section_NDM.xlsm') == published['WorkbookSHA256']
assert sha(ROOT/'workbook/output/VBA_All_Code.txt') == published['AllCodeSHA256']
assert sha(ROOT/'workbook/output/NDM_Test_1232_30/RC_Section_NDM_ok.xlsm') == '31F188692A01CC421A37CF962598778A5AD1FE6D9AB5D96DD41C29389C0919F7'
assert load(E/'ProcessClosure.json')['Passed']
assert load(P/'SourceEquality_Final02.json')['Passed']
assert load(P/'ExactPackageSmoke02/Closure.json')['Absent']
smoke = []
for path in (P/'ExactPackageSmoke02').glob('Run*.txt'):
    text = path.read_text('utf-8-sig')
    total = re.findall(r'^TOTAL[^\r\n]*passed=(\d+); failed=(\d+)\s*$', text, re.M)
    assert len(total) == 1 and int(total[0][1]) == 0 and not re.search(r'^FAIL\b', text, re.M)
    passed = int(total[0][0])
    assert len(re.findall(r'^PASS\b', text, re.M)) == passed
    smoke.append(dict(Path=str(path.relative_to(P)), Passed=passed, SHA256=sha(path)))
assert len(smoke) == 4 and sum(r['Passed'] for r in smoke) == 430
(E/'ExactPackageAcceptance.json').write_text(json.dumps(dict(Status='PASS_SMOKE_ONLY', MacroImport=False, Passed=430, Failed=0, Logs=smoke),ensure_ascii=False,indent=2),encoding='utf-8')

stats = []
for case in ('Contour_Excel','Adaptive_Excel','Contour_File'):
    directory = P/('FinalFreshPaired_'+case)
    assert load(directory/'Parity.json')['Passed']
    records = load(directory/'Measurements.json')
    assert len(records) == 16 and all(r['Ready'] and r['CalculationState'] == 0 for r in records)
    for action in ('FormSectionForWorkbook','RunSectionCalculationForWorkbook'):
        row = dict(Case=case, Action=action)
        for version in ('Original','Candidate'):
            values = [r for r in records if r['Case']==version and r['Action']==action]
            assert len(values) == 4
            row[version] = {k:statistics.median(r[k] for r in values) for k in ('Seconds','IdleSeconds','ThroughIdleSeconds')}
        stats.append(row)
(E/'FinalMeasurements.json').write_text(json.dumps(dict(Baseline='P1 exact scoped snapshot reuse; before persistent geometry hashes and outer timer', Method='Fresh Excel; saved compiled books; ABBA, four runs each; visible scheme; no source editing during timing', Rows=stats),ensure_ascii=False,indent=2),encoding='utf-8')
table = '\n'.join('| '+r['Case'].replace('_',' / ')+' | '+('Формирование' if r['Action'].startswith('Form') else 'Расчёт')+f" | {r['Original']['Seconds']:.3f} | {r['Candidate']['Seconds']:.3f} | {r['Original']['ThroughIdleSeconds']:.3f} | {r['Candidate']['ThroughIdleSeconds']:.3f} |" for r in stats)

button_lines = []
for path in (P/'ButtonCompletion02').glob('RunButton*.txt'):
    button_lines += [path.stem+': '+s for s in path.read_text('utf-8-sig').splitlines() if s.startswith('TIMING ')]
(E/'ButtonTimings.json').write_text(json.dumps(dict(WaitForUserExcluded=True, RealPublicHandlers=True, DiagnosticMessageBoxSubstitution=True, VisualClickPassClaimed=False, Lines=button_lines),ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(P/'Contour/RC_Section_NDM.xlsm') as before, zipfile.ZipFile(ROOT/'workbook/output/RC_Section_NDM.xlsm') as after:
    names = before.namelist()
    assert names == after.namelist()
    assert all(before.read(n)==after.read(n) for n in names if n!='xl/vbaProject.bin')

report = f'''# Задержки Contour, хеши геометрии и время кнопок — 28.10.2026

## Что изменено

Готовый проверенный снимок повторно используется внутри текущего действия в Excel и File. Ранее Excel игнорировал явно переданный источник и снова читал Results перед схемой. Копии проверенных границ независимы; изменение любого значения или типа матрицы отменяет такое повторное использование. Между действиями изменяемый снимок не кэшируется.

После нового формирования каждый бетонный элемент с фактическими границами получает `GeometryHash` в существующем ExtraData. Подпись переносится с объектом элемента и сохраняется в Excel либо файле снимка. Она охватывает физические поля, ID, роли, единицы, площадь, центр тяжести, инерции и сегменты. RunID, комментарии и подписи происхождения исключены; RunID проверяется отдельно. Числа передаются точно, без округления и десятичного преобразования. Блок Double и UTF-16 обозначения сворачиваются штатным Windows SHA256, сохраняются первые 64 бита. Хеширование не вызывает геометрических операций и не открывает криптопровайдер для каждого элемента.

Совпадение подписи включает восстановление уже проверенной записи без полного контроля пересечений и повторной сверки A/центра тяжести/инерций. Числа и сегменты всё равно нужно прочитать и собрать в объект; лёгкая сборка замкнутых цепочек и вычисление площади сохраняют прежнее представление области. Отсутствующая/неподходящая подпись, необычная запись либо изменение данных возвращают прежний полный путь и его диагностику. Геометрические допуски не увеличивались. Старые снимки остаются читаемыми; подпись появляется после нового формирования, автоматической миграции старых данных нет.

Новых рабочих классов/модулей и новой версии NDMSNP04/05 не добавлено. Алгоритмы решателя, единицы и математические результаты не менялись. Контрольная сумма предназначена для обнаружения изменений, а не доказательства авторства или абсолютного отсутствия коллизий.

## Выполнение кнопок и время

Публичные обработчики формирования и расчёта запускают таймер при входе. Основной этап возвращается после освобождения тяжёлых моделей и таблиц; затем завершается показ готовой схемы, обновляется время и формируется сообщение. Ожидание OK не учитывается. Источник данных и место сохранения в сообщении сохранены, место сохранения остаётся последним абзацем.

Показ окна книги синхронно завершается через [RedrawWindow](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-redrawwindow), без повторного построения геометрии и без дополнительного Chart.Refresh. Временные настройки Excel восстанавливаются до завершения показа. Ошибка экранного показа даёт предупреждение и не маскирует сохранённые результаты под неудачный расчёт. Связанный файл и Results получают одно сохранённое значение времени после основного показа; итоговый диалог включает также последующую короткую запись поля времени/контрольной суммы.

Настоящие публичные кнопки проверены в диагностической копии: заменён только последний MessageBoxW, без ожидания человека. От точки показа окна до возврата кнопки Timer показал 0 с во всех четырёх пробах; это точность Timer, а не доказательство нулевого количества инструкций. Выводимое время отличается от границы показа не более чем на 0,02 с. Первая холодная проба формирования заняла 3,46 с; повторная — 1,32 с, расчёты — 1,31/1,48 с. Нажатие мышью и его доставка Windows до входа VBA этим замером не измеряются. Визуальный PASS нажатия OK не заявляется.

**Остаточное ограничение:** полностью убрать внутреннюю очередь/перерисовку Excel не удалось. После возврата API контрольный слив очереди занимает примерно 0,02–0,18 с; это не повторный запуск решателя или полного разбора границ. Такая остаточная обработка не включена в показание рабочего таймера. Поэтому гарантия отсутствия любой визуальной паузы после закрытия окна не даётся. [DoEvents](https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/doevents-function) в рабочий сценарий не добавлен: он допускает повторный вход и взаимодействие других обработчиков. Дополнительный Chart.Refresh оказался лишней работой и удалён из окончательного варианта.

## Причина исходной разницы

Нативно прочитанные 175 исходных и 6 документных компонентов двух пользовательских книг соответствовали одному коду. Помимо Mesh были три отличия настроек; причинное сравнение выполнялось на копиях с одинаковыми входами. В Contour — 342 бетонных элемента, 1370 строк границ и 28 стержней, в Adaptive — 474 элемента без подробной таблицы границ и те же 28 стержней.

Исходный профиль: построение сетки около 0,029/0,006 с, один разбор границ 0,219/0,009 с (Contour/Adaptive). При расчёте Contour выполнялись три разбора на 0,658 с. Значимая добавка приходилась на чтение, сборку и проверку фактических границ, а не решатель. Первая локальная правка уменьшила число полных разборов 3→2. Теперь в подписанном примере полный разбор не вызывается: формирование — 342 проверки подписи, расчёт — 684; схема использует подготовленный снимок.

## Парные измерения окончательного варианта

Свежий собственный Excel, уже сохранённые и скомпилированные книги, ABBA, по четыре запуска. Базовый код таблицы уже включает первую правку повторного использования снимка (P1). Нельзя суммировать проценты разных экспериментов или напрямую сопоставлять абсолютное время с замерами другого запуска.

| Режим | Действие | P1, вызов, с | Итог, вызов, с | P1, с очередью, с | Итог, с очередью, с |
|---|---|---:|---:|---:|---:|
{table}

Расчёт Contour ускорился; на лёгком Adaptive замедление не обнаружено. Для формирования Contour/Excel ускорение не подтверждено: с учётом остаточной очереди эта серия медленнее примерно на 0,14 с. Это ограничение сохраняется; полного равенства скорости Adaptive и полного исчезновения визуальных задержек не заявляем. Чтение матриц и построение фактических фигур дороже эквивалентных прямоугольников. Микрооптимизация хеша отдельно от полного сценария не принималась за ускорение кнопки.

## Проверки

- 3660/0 адресных исходов No/Yes: контекст снимка, хеши, фактические границы, Preview, независимость File от Results, полный короткий набор снимков, сообщения, время кнопок. После удаления лишнего Chart.Refresh заново проверены затронутый показ и сообщения; снимочная логика побайтно прежняя, в модуле сценария изменён только комментарий. Основание повторного использования регрессий записано в FinalDirectedAcceptance.json.
- Дополнительно 430/0 на копии **точного конечного пакета без импорта кода**. Нативная компиляция VBE578; readonly-экспорт: 175+6 компонентов соответствуют исходникам/шаблонам, AllCode получен из этого пакета.
- Дуги, отверстие, раздельные острова, повёрнутый прямоугольник, мм/см/м; изменения площади на 1e-12, всех физических колонок/единиц, отсутствующий и неправильный хеш, независимость копий и освобождение контекста. Прямой вектор Double сверён с Python.
- 12 сохранений и повторных открытий: Excel/File × точка/запятая в Excel × мм/см/м, все 48 проверок прошли. Системная локаль Windows не менялась; полный аудит всех путей при иной локали Windows этим этапом не заявляется.
- Независимое сравнение всех сохранённых чисел Results: 39295 (Contour/Excel), 28217 (Adaptive/Excel), 7351 (Contour/File), плюс 54438 значений полного бинарного File-снимка. Различий нет, кроме RunID, времени и нового GeometryHash. Численного допуска нет. Количество и типы сохранённых фигур Contour также совпали.
- Все собственные идентичности Excel повторно проверены по PID+UTCticks, освобождены, kill не применялся. Перед каждым процессом проверялись RAM и commit; native проверки последовательны.

## Отклонённые пробы

Первый вариант SHA256 с отдельной строковой упаковкой/провайдером и разбором JSON для каждого элемента замедлял работу и не публиковался. Подготовительный быстрый читатель сначала воспроизводил угол дуги иначе, чем старый путь через CStr: шесть точных сравнений площади не прошли. Исправлен только читатель, математический смысл и допуски не менялись. Проба переноса времени дала одно рассогласование файла и Results; оно исправлено, повторные журналы прошли. Ошибки диагностических помощников и первоначальные FAIL сохранены. Ни одна неуспешная проба не выдаётся за PASS.

## Публикация

Основная книга: `workbook/output/RC_Section_NDM.xlsm`, SHA256 `{published['WorkbookSHA256']}`. AllCode: `{published['AllCodeSHA256']}`. Изменён только vbaProject.bin, все 108 других ZIP-частей побайтно совпадают с исходной пользовательской книгой: данные, готовые Results, оформление, рамки, списки и раскладка сохранены. Старые готовые данные намеренно не мигрировались. Для подписей нужно один раз заново сформировать сечение.

Сборщик импортирует эти же актуальные исходники; раскладка/каталоги не менялись. `NDM_Test_1232_30/RC_Section_NDM_ok.xlsm` не изменён, удалённый пользователем прежний файл не восстанавливался. Чужие execution_report и outputs в коммит не включаются. Ветка codex/action-latency; main не менялась.

Доказательства: `docs/regression/ContourLatency_2026-10-28_Run01/FinalDirectedAcceptance.json`, ExactPackageAcceptance.json, FinalMeasurements.json, FinalPackagePreservation.json, FinalPublication.json, ProcessClosure.json, Processed.json, ReviewedEvidence.zip. Новый полный ON/OFF/целый UI не запускался; это адресная приёмка, **не общий полный PASS** новой SHA.
'''
(ROOT/'docs/reports/ContourLatency_2026-10-28.md').write_text(report,encoding='utf-8')
progress = ROOT/'docs/geometry_refactor/PROGRESS.md'
text = progress.read_text('utf-8-sig')
start = text.index('## 28.10.2026 —')
end = text.index('\n## ',start+5)
replacement = '''## 28.10.2026 — Contour: хеши геометрии, контекст снимка и время кнопок

Устранено повторное чтение готового снимка перед схемой; после нового формирования GeometryHash хранится у бетонного элемента и в снимке. Совпадение убирает полный геометрический контроль, изменение/отсутствие выбирает прежнюю проверку. Без новых рабочих классов, формата файла и изменения допусков/решателя. Таймер формирования/расчёта вынесен за освобождение тяжёлых объектов и показ готовой схемы, перед итоговым окном. Остаточную очередь Excel 0,02–0,18 с полностью убрать не удалось; гарантия нулевой визуальной паузы не заявляется.

3660/0 адресных исходов No/Yes и 430/0 smoke точного конечного пакета. 12 save/reopen при точке/запятой и мм/см/м; все численные результаты совпали точно. В свежем Excel медиана расчёта Contour/Excel P1→итог 1,626→1,470 с; File 1,622→1,403 с. Лёгкий Adaptive не замедлился; для формирования Contour/Excel улучшения нет, с очередью в этой серии добавилось около 0,14 с. Данные/оформление основной книги сохранены побайтно вне VBA, _ok не тронут. Нативно сверены 175+6 компонентов и AllCode, сборка синхронизирована. Книга 0D50727A0B01…; все свои Excel освобождены без kill. Полный набор не запускался, полного PASS нет. Отчёт: [ContourLatency_2026-10-28.md](../reports/ContourLatency_2026-10-28.md).
'''
progress.write_text(text[:start]+replacement+text[end:],encoding='utf-8')

selected = {}
for path in E.iterdir():
    if path.suffix in ('.json','.ps1','.py','.vba') and path.name not in ('ArchiveManifest.json','Processed.json'):
        selected['Evidence/'+path.name] = path
for directory in P.iterdir():
    if directory.is_dir() and (directory.name.startswith(('Hash','FinalFresh','ButtonCompletion','ExactPackage','Directed','Paired','ReadCounts'))):
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix in ('.json','.txt','.diff','.bas','.cls') and 'execution_report' not in path.name and path.name!='VBA_All_Code.txt':
                selected['Scratch/'+str(path.relative_to(P)).replace('\\','/')] = path
for path in (P/'SourceEquality_Final02.json',P/'NativeFinal02Ownership.json',P/'NativeFinal02Closure.json',P/'NativeFinal02/Main/NativeVerification.json'):
    selected['Native/'+path.name] = path
manifest = [dict(Path=name, Bytes=path.stat().st_size, SHA256=sha(path)) for name,path in sorted(selected.items())]
with zipfile.ZipFile(E/'ReviewedEvidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(selected.items()):
        archive.write(path,name)
assert zipfile.ZipFile(E/'ReviewedEvidence.zip').testzip() is None
(E/'ArchiveManifest.json').write_text(json.dumps(dict(Files=manifest,ArchiveSHA256=sha(E/'ReviewedEvidence.zip')),ensure_ascii=False,indent=2),encoding='utf-8')
processed = dict(Status='DIRECTED_COMPLETE_FULL_RUN_NOT_STARTED', AtUTC=datetime.now(timezone.utc).isoformat(), FullSuite=False, DirectedPassed=3660, ExactPackageSmokePassed=430, Failed=0, Publication=published, UserDataPreserved=True, HeavyOkUnchanged=True, SourceComponents=175, DocumentComponents=6, AllCodeExact=True, ProcessesReleased=True, ResidualRisk='Excel internal queue remains up to approximately 0.18 s; not included in VBA action timer; no zero-lag guarantee', ArchiveFiles=len(manifest), ArchiveSHA256=sha(E/'ReviewedEvidence.zip'))
(E/'Processed.json').write_text(json.dumps(processed,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(Status=processed['Status'],Checks=4090,ArchiveFiles=len(manifest),ArchiveBytes=(E/'ReviewedEvidence.zip').stat().st_size),ensure_ascii=False))
