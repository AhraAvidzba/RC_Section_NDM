"""ДЛЯ ТЕСТОВ: создаёт ABBA-помощник с отдельным учётом очереди отрисовки."""
from pathlib import Path

P=Path(__file__).resolve().parent
s=(P/'TestPairedCandidate.ps1').read_text(encoding='utf-8-sig')
s=s.replace("$ErrorActionPreference='Stop'", "param([ValidateSet('Contour','Adaptive')][string]$Mesh='Contour',[ValidateSet('Excel','File')][string]$Storage='Excel')\n$ErrorActionPreference='Stop'",1)
s=s.replace("'Paired01'","('HashPaired_'+$Mesh+'_'+$Storage)").replace('Contour/RC_Section_NDM.xlsm','Publication01/RC_Section_NDM.xlsm').replace("'Candidate') -File","'HashCandidate01') -File")
s=s.replace('$books[$case]=$book','$books[$case]=$book;$project=$book.VBProject\n  $range=$book.Names.Item(\'rngSystemSettings\').RefersToRange;$matrix=$range.Value2\n  for($row=2;$row-le$matrix.GetLength(0);$row++){switch([string]$matrix[$row,1]){\'Mesh.CellGeometry\'{$range.Cells.Item($row,2).Value2=$Mesh};\'Results.SnapshotStorage\'{$range.Cells.Item($row,2).Value2=$Storage};\'Results.SnapshotName\'{$range.Cells.Item($row,2).Value2=\'TestBench_\'+$case}}};$range=$null')
needle='''  }
 }
 $compile=$null;'''
assert needle in s
s=s.replace(needle,'''  }
  $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule
  $code.AddFromString("`r`n' -------------------- ДЛЯ ТЕСТОВ --------------------`r`n' Измеряет остаток очереди после возврата штатного действия.`r`nPublic Function TestDrainBenchmarkPaint() As Double`r`nDim started As Double: started = Timer`r`nDoEvents`r`nDoEvents`r`nDoEvents`r`nTestDrainBenchmarkPaint = Timer - started`r`nEnd Function`r`n")
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Benchmark compile failed'}
 }
 $compile=$null;''',1)
s=s.replace('''   $watch=[Diagnostics.Stopwatch]::StartNew();''','''   if($case-eq'Candidate'){[void]$app.Run("'$($book.Name)'!modSectionSnapshot.TestSavedBoundaryReadCounts",$true)}
   $watch=[Diagnostics.Stopwatch]::StartNew();''')
s=s.replace("$seconds=$watch.Elapsed.TotalSeconds",'''$seconds=$watch.Elapsed.TotalSeconds
   $idle=[double]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestDrainBenchmarkPaint")
   $counts=if($case-eq'Candidate'){[string]$app.Run("'$($book.Name)'!modSectionSnapshot.TestSavedBoundaryReadCounts")}else{''}''')
s=s.replace('Seconds=$seconds;Message=', 'Seconds=$seconds;IdleSeconds=$idle;ThroughIdleSeconds=($seconds+$idle);BoundaryFullHashCounts=$counts;Mesh=$Mesh;Storage=$Storage;Message=')
(P/'TestHashBenchmark.ps1').write_text(s,encoding='utf-8-sig')
print('HASH_BENCHMARK_PREPARED')
