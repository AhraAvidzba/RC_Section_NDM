"""ДЛЯ ТЕСТОВ: изолированный хеш точной записи элемента, без нового формата файла."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[3]
OUT=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01/HashCandidate01')
OUT.mkdir(exist_ok=True)
changes=[]


def read(rel):
    """Берёт актуальный P1; новые изменения остаются в отдельном каталоге."""
    return (ROOT/rel).read_text(encoding='utf-8-sig')


def save(rel, text):
    """Фиксирует исходную SHA для будущего переноса после приёмки."""
    data=text.encode('utf-8');(OUT/Path(rel).name).write_bytes(data)
    changes.append(dict(Path=rel,OriginalSHA256=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest().upper(),CandidateSHA256=hashlib.sha256(data).hexdigest().upper()))


rel='src/Excel/CFileChecksum.cls'
s=read(rel).replace('Контрольная сумма файла штатными средствами Windows', 'Контрольные суммы файла и числовой геометрической записи')
at=s.index("' SHA256 средствами Windows")
s=s[:at]+(Path(__file__).parent/'GeometryHashDeclarations.vba').read_text(encoding='utf-8')+'\n'+s[at:]
s+='\n'+(Path(__file__).parent/'GeometryHashMethods.vba').read_text(encoding='utf-8')
save(rel,s)

rel='src/Section/CConcreteRegion.cls';s=read(rel)
at=s.index("' Копирует готовые границы")
s=s[:at]+'''Private mGeometryHash As String ' Контрольная сумма точной записи снимка; пусто у внешней или изменённой границы.
Private mPreparedProperties As Variant ' Точные уже проверенные A/c/I этой неизменённой области, без округления.

'''+s[at:]
s=s.replace('    mCount = count:', '    mGeometryHash = vbNullString: mPreparedProperties = Empty\n    mCount = count:',1)
s=s.replace('    result.SetBoundaryProbes mBoundaryProbes', '    result.SetBoundaryProbes mBoundaryProbes\n    result.RememberGeometryHash mGeometryHash\n    result.CopyPreparedProperties mPreparedProperties',1)
s+='''

' Возвращает сохранённую подпись проверенной записи; она не является свойством материала или НДС.
Public Property Get GeometryHash() As String
    GeometryHash = mGeometryHash
End Property

' Сохраняет производную подпись после проверки записи; изменение границ через SetGeometry её сбрасывает.
Friend Sub RememberGeometryHash(ByVal value As String)
    mGeometryHash = value
End Sub

' Запоминает физические величины, проверенные вместе с этой границей либо подтверждённые её хешем.
Friend Sub RememberPreparedProperties(ByVal x As Double, ByVal y As Double, ByVal area As Double, _
        ByVal ix As Double, ByVal iy As Double, ByVal ixy As Double)
    mPreparedProperties = Array(x, y, area, ix, iy, ixy)
End Sub

' Копирует производную метку только при независимом Clone; массив снаружи не возвращается.
Friend Sub CopyPreparedProperties(ByVal values As Variant)
    mPreparedProperties = values
End Sub

' Исключает повторное интегрирование уже проверенной области только при точном совпадении всех A/c/I.
Friend Function MatchesPreparedProperties(ByVal x As Double, ByVal y As Double, ByVal area As Double, _
        ByVal ix As Double, ByVal iy As Double, ByVal ixy As Double) As Boolean
    If Not IsArray(mPreparedProperties) Then Exit Function
    MatchesPreparedProperties = (mPreparedProperties(0) = x And mPreparedProperties(1) = y And mPreparedProperties(2) = area And _
        mPreparedProperties(3) = ix And mPreparedProperties(4) = iy And mPreparedProperties(5) = ixy)
End Function
'''
save(rel,s)

rel='src/Section/CConcreteElement.cls';s=read(rel)
s+='''

' Подпись уже проверенной геометрической записи принадлежит тому же объекту, что и фактическая граница.
Public Property Get GeometryHash() As String
    If Not mExactGeometry Is Nothing Then GeometryHash = mExactGeometry.GeometryHash
End Property

' Добавляет только производную подпись сериализации; характеристики и границы элемента не меняются.
Friend Sub RememberGeometryHash(ByVal value As String)
    If Not mExactGeometry Is Nothing Then mExactGeometry.RememberGeometryHash value
End Sub
'''
save(rel,s)

rel='src/Section/CSectionGeometryQuery.cls';s=read(rel)
at=s.index("' Проверяет отсутствие самопересечений каждого контура")
s=s[:at]+''' ' Восстанавливает выпущенную программой неизменённую запись после совпадения контрольной суммы.
' Не повторяет самопересечения, вложенность и A/c/I; соединяет уже ориентированные сегменты тем же MakeRegion.
' Вызывать только после подтверждения хеша всей записи, включая роли, единицы и характеристики.
Friend Function RestoreHashedBoundary(ByRef edges() As TRegionEdge, ByVal count As Long) As CConcreteRegion
    Set RestoreHashedBoundary = MakeRegion(edges, count, "SavedConcreteBoundary", 0)
End Function

'''+s[at:]
save(rel,s)

rel='src/Section/CSectionModel.cls';s=read(rel)
needle='    query.ValidateBoundaryProperties region, x, y, area, localIx, localIy, localIxy'
assert s.count(needle)==1
s=s.replace(needle,'    If region.MatchesPreparedProperties(x, y, area, localIx, localIy, localIxy) Then Exit Sub\n'+needle)
save(rel,s)

rel='src/Excel/CNDMResultsWriter.cls';s=read(rel)
at=s.index('Private Const ELEMENT_RESULT_COLUMNS')
s=s[:at]+'''Private mPreparedElementGeometry As Variant ' Одна сериализация границ для подписи и записи, без повторного обхода областей.
Private mPreparedBoundaryOwner As CSectionModel ' Подготовка принадлежит одному вызову записи и сбрасывается после его потребления.
Private mPreparedFirstBoundary As Object, mPreparedLastBoundary As Object ' Непрерывные строки каждого элемента в готовой матрице.

'''+s[at:]
start=s.index('Private Sub WriteElementGeometry(')
build_start=s.index('    Dim groups As Collection',start)
build_end=s.index('    If Not mCapturedSnapshot Is Nothing Then',build_start)
build=s[build_start:build_end]
build=build.replace('    row = 1','    Set mPreparedFirstBoundary = CreateObject("Scripting.Dictionary")\n    Set mPreparedLastBoundary = CreateObject("Scripting.Dictionary")\n    row = 1',1)
build=build.replace('        For i = 1 To boundary.Count','        mPreparedFirstBoundary.Add CStr(owners(group)), row + 1\n        For i = 1 To boundary.Count',1)
build=build.replace('    Next group','        mPreparedLastBoundary.Add CStr(owners(group)), row\n    Next group',1)
preparer='''
' Готовит одну числовую матрицу границ для хеша и последующего блочного вывода.
' Вызывается заново для каждой записи геометрии; межоперационного кэша нет.
Private Sub PrepareElementGeometryRows(ByVal section As CSectionModel, ByVal runID As Variant, ByVal units As CUnitSystem)
'''+build+'''    mPreparedElementGeometry = data
    Set mPreparedBoundaryOwner = section
End Sub

'''
consume='''    If Not mPreparedBoundaryOwner Is section Then PrepareElementGeometryRows section, runID, units
    Dim data As Variant: data = mPreparedElementGeometry
    Dim total As Long: total = UBound(data, 1) - 1
    mPreparedElementGeometry = Empty: Set mPreparedBoundaryOwner = Nothing
    Set mPreparedFirstBoundary = Nothing: Set mPreparedLastBoundary = Nothing
'''
s=s[:build_start]+consume+s[build_end:]
s=s[:start]+preparer+s[start:]
at=s.index('    Dim target As Object',s.index('Private Sub WriteSectionGeometry('))
s=s[:at]+'    PrepareElementGeometryRows section, runID, units\n'+s[at:]
needle='''        data(rowIndex, 16) = SectionOptionalJson("SourceName", section.ConcreteSourceName(i), _
            "SourceHandle", section.ConcreteSourceHandle(i), "MaterialID", section.ConcreteMaterialID(i))'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
        If mPreparedFirstBoundary.Exists(section.ConcreteID(i)) Then
            Dim checksum As CFileChecksum
            If checksum Is Nothing Then
                Set checksum = New CFileChecksum
                checksum.PrepareGeometryHashHeaders data, mPreparedElementGeometry
            End If
            Dim digest As String: digest = checksum.PreparedGeometryHash(data, rowIndex, mPreparedElementGeometry, _
                CLng(mPreparedFirstBoundary.Item(section.ConcreteID(i))), CLng(mPreparedLastBoundary.Item(section.ConcreteID(i))))
            data(rowIndex, 16) = SectionOptionalJson("SourceName", section.ConcreteSourceName(i), _
                "SourceHandle", section.ConcreteSourceHandle(i), "MaterialID", section.ConcreteMaterialID(i), "GeometryHash", digest)
            Dim concrete As CConcreteElement: Set concrete = section.ConcreteElement(i)
            concrete.RememberGeometryHash digest
        End If''',1)
save(rel,s)

rel='src/Excel/modSectionSnapshot.bas';s=read(rel)
at=s.index("' Читает геометрию") if "' Читает геометрию" in s else s.index('Public Function ReadSectionGeometryFromResults(')
# Счётчики дают прямое доказательство выбора пути; рабочих значений они не меняют.
at=s.index('\n',s.index('Option Explicit'))
s=s[:at]+"\nPrivate mTestBoundaryFullReads As Long, mTestBoundaryHashReads As Long ' ДЛЯ ТЕСТОВ: число полных и подтверждённых хешем элементов."+s[at:]
needle='    Dim contours As CSectionContours, segmentID As String'
at=s.index(needle,s.index('Public Function ReadConcreteBoundaryMap('))
s=s[:at]+'''    Dim hashed As Object: Set hashed = ReadHashedConcreteBoundaries(boundaryData, geometryData, rows)
'''+s[at:]
needle='        segmentID = SavedBoundaryText(boundaryData, row, 3, sourceReference, boundaryAnchor)'
assert s.count(needle)==1
s=s.replace(needle,'        If hashed.Exists(owner) Then GoTo NextSavedContourRow\n'+needle,1)
start=s.index('Public Function ReadConcreteBoundaryMap(')
at=s.index('    Next row\n    On Error GoTo 0',start)
s=s[:at]+'NextSavedContourRow:\n'+s[at:]
needle='''        If Not groups.Exists(CStr(item)) Then SavedBoundaryError "Для бетонного элемента " & CStr(item) & " отсутствует обязательная фактическая граница.", sourceReference, 1, 18, boundaryAnchor'''
assert s.count(needle)==1
s=s.replace(needle,'''        If hashed.Exists(CStr(item)) Then
            Set region = hashed.Item(CStr(item)): result.Add CStr(item), region
            mTestBoundaryHashReads = mTestBoundaryHashReads + 1
            GoTo NextSavedBoundaryElement
        End If
'''+needle,1)
needle='        Set region = SavedConcreteRegion(contours, query, loopNames, actualLoopNames)'
s=s.replace(needle,'        mTestBoundaryFullReads = mTestBoundaryFullReads + 1\n'+needle,1)
s=s.replace('        result.Add CStr(item), region\n    Next item','        result.Add CStr(item), region\nNextSavedBoundaryElement:\n    Next item',1)
# После полноценной проверки модель не повторяет те же интегралы для неизменённой области.
needle='''    query.ValidateBoundaryProperties region, _
        OutputLengthToInternalByUnit(SavedBoundaryNumber(data, row, layout.XColumn, "rngNDMSectionGeometry", anchor), layout.LengthUnit), _'''
at=s.index(needle)
end=s.index('\nEnd Sub',at)
call=s[at:end]
remember=call.replace('    query.ValidateBoundaryProperties region, _','    region.RememberPreparedProperties _',1)
s=s[:end]+'\n'+remember+s[end:]
s+='''

' Подтверждает только целиком неизменённые записи, выпущенные штатным writer-ом.
' При отсутствии/ошибке JSON или хеша возвращает прежний полный путь без подмены геометрии.
Private Function ReadHashedConcreteBoundaries(ByRef boundaries As Variant, ByRef geometry As Variant, ByVal geometryRows As Object) As Object
    Dim result As Object: Set result = CreateObject("Scripting.Dictionary"): result.CompareMode = vbBinaryCompare
    Set ReadHashedConcreteBoundaries = result
    If UBound(boundaries, 1) < 2 Then Exit Function
    Dim extraColumn As Long: extraColumn = ResultColumn(geometry, "ExtraData", False)
    If extraColumn = 0 Then Exit Function
    Dim first As Object, last As Object, counts As Object
    Set first = CreateObject("Scripting.Dictionary"): Set last = CreateObject("Scripting.Dictionary"): Set counts = CreateObject("Scripting.Dictionary")
    Dim row As Long, owner As String, key As Variant
    On Error GoTo Untrusted
    For row = 2 To UBound(boundaries, 1)
        owner = CStr(boundaries(row, 18))
        If Not first.Exists(owner) Then first.Add owner, row: counts.Add owner, 0
        last(owner) = row: counts(owner) = CLng(counts(owner)) + 1
    Next row
    Dim checksum As CFileChecksum: Set checksum = New CFileChecksum
    checksum.PrepareGeometryHashHeaders geometry, boundaries
    Dim region As CConcreteRegion, query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim layout As TSavedBoundaryLayout, layoutReady As Boolean
    For Each key In first.Keys
        owner = CStr(key)
        If geometryRows.Exists(owner) And CLng(counts(owner)) = CLng(last(owner)) - CLng(first(owner)) + 1 Then
            Set region = TryReadHashedBoundary(boundaries, geometry, CLng(geometryRows.Item(owner)), _
                CLng(first(owner)), CLng(last(owner)), extraColumn, checksum, query, layout, layoutReady)
            If Not region Is Nothing Then result.Add owner, region
        End If
    Next key
    Exit Function
Untrusted:
    Err.Clear ' Основной читатель выдаст прежнюю адресную ошибку, если обязательные данные повреждены.
End Function

' Вычисляет контрольную сумму только по скалярам и при совпадении собирает отрезки/дуги без геометрического валидатора.
' Неподдерживаемая запись остаётся на обычном пути; старые снимки без подписи не меняют поведения.
Private Function TryReadHashedBoundary(ByRef boundaries As Variant, ByRef geometry As Variant, ByVal geometryRow As Long, _
        ByVal firstRow As Long, ByVal lastRow As Long, ByVal extraColumn As Long, ByVal checksum As CFileChecksum, _
        ByVal query As CSectionGeometryQuery, ByRef layout As TSavedBoundaryLayout, ByRef layoutReady As Boolean) As CConcreteRegion
    On Error GoTo Untrusted
    Dim digest As String: digest = SavedGeometryHashText(CStr(geometry(geometryRow, extraColumn)))
    If Len(digest) <> 16 Then Exit Function
    If StrComp(digest, checksum.PreparedGeometryHash(geometry, geometryRow, boundaries, firstRow, lastRow), vbBinaryCompare) <> 0 Then Exit Function
    Dim edges() As TRegionEdge, count As Long, row As Long, index As Long, kind As String, factor As Double, unit As String
    count = lastRow - firstRow + 1: ReDim edges(1 To count)
    For row = firstRow To lastRow
        index = row - firstRow + 1: unit = CStr(boundaries(row, 17))
        factor = OutputLengthToInternalByUnit(1#, unit)
        With edges(index)
            .X1 = CDbl(boundaries(row, 7)) * factor: .Y1 = CDbl(boundaries(row, 8)) * factor
            kind = CStr(boundaries(row, 6))
            Select Case kind
                Case "CONTOUR_LINE"
                    .X2 = CDbl(boundaries(row, 9)) * factor: .Y2 = CDbl(boundaries(row, 10)) * factor
                Case "CONTOUR_ARC"
                    .CenterX = CDbl(boundaries(row, 11)) * factor: .CenterY = CDbl(boundaries(row, 12)) * factor
                    .Sweep = ReadContourArcSweep(boundaries(row, 14), "rngNDMElementGeometry") ' Сохраняет прежнюю числовую интерпретацию угла, без изменения результатов.
                    .X2 = .CenterX + (.X1 - .CenterX) * Cos(.Sweep) - (.Y1 - .CenterY) * Sin(.Sweep)
                    .Y2 = .CenterY + (.X1 - .CenterX) * Sin(.Sweep) + (.Y1 - .CenterY) * Cos(.Sweep)
                Case Else: Exit Function ' Writer выпускает только линии и дуги; внешние окружности проверяются как прежде.
            End Select
        End With
    Next row
    Dim region As CConcreteRegion: Set region = query.RestoreHashedBoundary(edges, count)
    If Not layoutReady Then ReadSavedBoundaryLayout geometry, Nothing, layout: layoutReady = True
    region.RememberPreparedProperties _
        OutputLengthToInternalByUnit(CDbl(geometry(geometryRow, layout.XColumn)), layout.LengthUnit), _
        OutputLengthToInternalByUnit(CDbl(geometry(geometryRow, layout.YColumn)), layout.LengthUnit), _
        OutputAreaToInternalByUnit(CDbl(geometry(geometryRow, layout.AreaColumn)), layout.AreaUnit), _
        OutputFourthPowerLengthToInternalByUnit(CDbl(geometry(geometryRow, layout.IxColumn)), layout.InertiaUnit), _
        OutputFourthPowerLengthToInternalByUnit(CDbl(geometry(geometryRow, layout.IyColumn)), layout.InertiaUnit), _
        OutputFourthPowerLengthToInternalByUnit(CDbl(geometry(geometryRow, layout.IxyColumn)), layout.InertiaUnit)
    region.RememberGeometryHash digest
    Set TryReadHashedBoundary = region
    Exit Function
Untrusted:
    Err.Clear
End Function

' Извлекает только каноническую шестнадцатеричную подпись writer-а, не создавая словарь для каждого элемента.
' Необычное оформление или отсутствующий маркер выбирает полный путь; остальные необязательные поля не интерпретируются.
Private Function SavedGeometryHashText(ByVal text As String) As String
    Dim marker As String: marker = Chr$(34) & "GeometryHash" & Chr$(34) & ":" & Chr$(34)
    Dim prefix As String: prefix = "{" & Chr$(34) & "schema" & Chr$(34) & ":" & Chr$(34) & "1" & Chr$(34)
    If Left$(text, Len(prefix)) <> prefix Or Right$(text, 1) <> "}" Then Exit Function
    Dim position As Long: position = InStr(1, text, marker, vbBinaryCompare)
    If position = 0 Then Exit Function
    If InStr(position + Len(marker), text, marker, vbBinaryCompare) > 0 Then Exit Function
    position = position + Len(marker)
    If Mid$(text, position + 16, 1) <> Chr$(34) Then Exit Function
    Dim value As String: value = Mid$(text, position, 16)
    Dim i As Long
    For i = 1 To 16
        If InStr(1, "0123456789ABCDEF", Mid$(value, i, 1), vbBinaryCompare) = 0 Then Exit Function
    Next i
    SavedGeometryHashText = value
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает независимые счётчики выбора полного/хеш-пути; reset не меняет рабочие данные.
Public Function TestSavedBoundaryReadCounts(Optional ByVal reset As Boolean = False) As String
    TestSavedBoundaryReadCounts = CStr(mTestBoundaryFullReads) & "/" & CStr(mTestBoundaryHashReads)
    If reset Then mTestBoundaryFullReads = 0: mTestBoundaryHashReads = 0
End Function
'''
save(rel,s)

rel='tests/modTestCalculationSnapshot.bas';s=read(rel)
needle='    TestSnapshotPreparedReuse'
at=s.index(needle,s.index('Public Function RunCalculationSnapshotTests'))
s=s[:at]+s[at:].replace(needle,needle+'\n    TestSnapshotGeometryHashes',1)
s+='''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Изолированно проверяет подписи, быстрый путь и возврат к полному разбору без нового полного набора.
Public Function RunGeometryHashTests() As String
    mTestReport = "": mTestPassed = 0: mTestFailed = 0
    On Error GoTo Failed
    TestSnapshotGeometryHashes
    GoTo Finished
Failed:
    TestSnapshotCheck "hash.runtime " & CStr(Err.Number) & ": " & Err.Description, False
Finished:
    RunGeometryHashTests = mTestReport & "TOTAL_GEOMETRY_HASH: passed=" & CStr(mTestPassed) & "; failed=" & CStr(mTestFailed)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет три единицы, реальные дуги/отверстие/острова, все физические поля подписи и отсутствие геометрического разбора.
Private Sub TestSnapshotGeometryHashes()
    Dim checksum As CFileChecksum: Set checksum = New CFileChecksum
    TestSnapshotCheck "hash.numeric.reference.utf16abc", checksum.TestGeometryHashText("abc") = "E2E0CC84EA7D2583"
    TestSnapshotCheck "hash.nativeNumber", checksum.TestGeometryHashNumber(0.5) = "4CFA5B42CA669328"
    Dim geometry As Variant, boundaries As Variant, expected As Collection, unit As Variant, map As Object
    Dim baseline As Object, query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim i As Long, row As Long, first As Long, last As Long, digest As String, info As Object, changed As Variant
    Dim region As CConcreteRegion, clone As CConcreteRegion, before As String
    For Each unit In Array("mm", "cm", "m")
        TestSnapshotBoundaryFixture CStr(unit), geometry, boundaries, expected
        Set baseline = ReadConcreteBoundaryMap(boundaries, geometry)
        For i = 1 To expected.Count
            first = 0: last = 0
            For row = 2 To UBound(boundaries, 1)
                If CStr(boundaries(row, 18)) = "C" & CStr(i) Then
                    If first = 0 Then first = row
                    last = row
                End If
            Next row
            digest = checksum.GeometryHash(geometry, i + 1, boundaries, first, last)
            geometry(i + 1, 16) = SectionOptionalJson("GeometryHash", digest)
        Next i
        Call TestSavedBoundaryReadCounts(True)
        Set map = ReadConcreteBoundaryMap(boundaries, geometry)
        TestSnapshotCheck CStr(unit) & ".hash.noFullGeometryParse", TestSavedBoundaryReadCounts() = "0/4"
        TestSnapshotCheck CStr(unit) & ".hash.count", map.Count = 4
        For i = 1 To expected.Count
            Set region = map.Item("C" & CStr(i))
            Set info = ReadSectionOptionalJson(CStr(geometry(i + 1, 16)))
            TestSnapshotCheck CStr(unit) & ".hash.object.C" & CStr(i), region.GeometryHash = SectionOptionalText(info, "GeometryHash")
            TestSnapshotCheck CStr(unit) & ".hash.shape.C" & CStr(i), query.RegionsCoincide(expected(i), region)
            TestSnapshotCheck CStr(unit) & ".hash.loopCount.C" & CStr(i), baseline.Item("C" & CStr(i)).LoopCount = region.LoopCount
            TestSnapshotCheck CStr(unit) & ".hash.area.C" & CStr(i), baseline.Item("C" & CStr(i)).Area = region.Area
            Set clone = region.Clone: clone.SetOwner "OTHER", "OTHER", "OTHER"
            TestSnapshotCheck CStr(unit) & ".hash.clone.C" & CStr(i), clone.GeometryHash = region.GeometryHash
        Next i
        first = 2: last = 2
        Do While last < UBound(boundaries, 1)
            If CStr(boundaries(last + 1, 18)) <> "C1" Then Exit Do
            last = last + 1
        Loop
        digest = checksum.GeometryHash(geometry, 2, boundaries, first, last)
        Dim column As Long
        For column = 2 To 14
            changed = geometry
            If VarType(changed(2, column)) = vbString Then changed(2, column) = CStr(changed(2, column)) & "x" Else changed(2, column) = 1.000000000001 + CDbl(changed(2, column))
            TestSnapshotCheck CStr(unit) & ".hash.geometryField." & CStr(column), checksum.GeometryHash(changed, 2, boundaries, first, last) <> digest
            changed = geometry: changed(1, column) = CStr(changed(1, column)) & "x"
            TestSnapshotCheck CStr(unit) & ".hash.geometryUnit." & CStr(column), checksum.GeometryHash(changed, 2, boundaries, first, last) <> digest
        Next column
        For column = 2 To 18
            If column <> 15 And column <> 16 Then
                changed = boundaries
                If VarType(changed(2, column)) = vbString Then changed(2, column) = CStr(changed(2, column)) & "x" Else changed(2, column) = 1.000000000001 + CDbl(changed(2, column))
                TestSnapshotCheck CStr(unit) & ".hash.boundaryField." & CStr(column), checksum.GeometryHash(geometry, 2, changed, first, last) <> digest
            End If
        Next column
        changed = geometry: changed(2, 1) = 45001#
        TestSnapshotCheck CStr(unit) & ".hash.runNotGeometry", checksum.GeometryHash(changed, 2, boundaries, first, last) = digest
        changed = geometry: changed(2, 6) = CDbl(changed(2, 6)) * 1.000000000001
        Call TestSavedBoundaryReadCounts(True)
        Set map = ReadConcreteBoundaryMap(boundaries, changed)
        TestSnapshotCheck CStr(unit) & ".hash.changedUsesFull", TestSavedBoundaryReadCounts() = "1/3"
        changed = geometry: changed(2, 16) = "{}"
        Call TestSavedBoundaryReadCounts(True)
        Set map = ReadConcreteBoundaryMap(boundaries, changed)
        TestSnapshotCheck CStr(unit) & ".hash.missingUsesFull", TestSavedBoundaryReadCounts() = "1/3"
        changed = geometry: changed(2, 16) = SectionOptionalJson("GeometryHash", String$(16, "0"))
        Call TestSavedBoundaryReadCounts(True)
        Set map = ReadConcreteBoundaryMap(boundaries, changed)
        TestSnapshotCheck CStr(unit) & ".hash.wrongUsesFull", TestSavedBoundaryReadCounts() = "1/3"
    Next unit
End Sub
'''
if rel == 'tests/modTestCalculationSnapshot.bas':
    s+='''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет фактическую сохранённую и повторно открытую книгу после штатного формирования новой Contour-сетки.
Public Function RunStoredGeometryHashTests() As String
    mTestReport = "": mTestPassed = 0: mTestFailed = 0
    On Error GoTo Failed
    Call TestSavedBoundaryReadCounts(True)
    Dim model As CSectionModel: Set model = ReadFormedSectionFromResults(ThisWorkbook, False)
    TestSnapshotCheck "storedHash.count", model.ConcreteCount > 0
    TestSnapshotCheck "storedHash.noFullParse", TestSavedBoundaryReadCounts() = "0/" & CStr(model.ConcreteCount)
    Dim i As Long, allSigned As Boolean: allSigned = True
    For i = 1 To model.ConcreteCount
        If Len(model.ConcreteElement(i).GeometryHash) <> 16 Then allSigned = False
    Next i
    TestSnapshotCheck "storedHash.allObjectsSigned", allSigned
    TestSnapshotCheck "storedHash.scopeReleased", TestCalculationSnapshotReadReleased()
    GoTo Finished
Failed:
    TestSnapshotCheck "storedHash.runtime " & CStr(Err.Number) & ": " & Err.Description, False
Finished:
    RunStoredGeometryHashTests = mTestReport & "TOTAL_STORED_GEOMETRY_HASH: passed=" & CStr(mTestPassed) & "; failed=" & CStr(mTestFailed)
End Function
'''
save(rel,s)

# Незавершённый пакет не переносится в проект.
(OUT/'DeferredSourceManifest.json').write_text(json.dumps({'Status':'PREPARED_NOT_VALIDATED','Changes':changes},ensure_ascii=False,indent=2),encoding='utf-8')
print('HASH_CORE_PREPARED',len(changes))
