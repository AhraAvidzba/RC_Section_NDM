"""ДЛЯ ТЕСТОВ: добавляет регрессии независимости и короткого контекста снимка в частный модуль."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[3]
OUT=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01/Candidate')
path=ROOT/'tests/modTestCalculationSnapshot.bas'
s=path.read_text(encoding='utf-8-sig')
needle='    TestSnapshotValidationReuse original'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    TestSnapshotPreparedReuse')
s+='''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отдельный короткий запуск тех же регрессий, включённых в общий набор снимков.
Public Function RunPreparedSnapshotReuseTests() As String
    mTestReport = "": mTestPassed = 0: mTestFailed = 0
    On Error GoTo Failed
    TestSnapshotPreparedReuse
    GoTo Finished
Failed:
    TestSnapshotCheck "prepared.runtime " & CStr(Err.Number) & ": " & Err.Description, False
Finished:
    RunPreparedSnapshotReuseTests = mTestReport & "TOTAL PREPARED SNAPSHOT REUSE: passed=" & CStr(mTestPassed) & "; failed=" & CStr(mTestFailed)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет реальный контекст Excel, точность входа и независимость возвращённых областей в мм/см/м.
Private Sub TestSnapshotPreparedReuse()
    Dim geometry As Variant, boundaries As Variant, expected As Collection, unit As Variant
    Dim snapshot As CCalculationSnapshot, current As CCalculationSnapshot
    Dim copied As Object, second As Object, region As CConcreteRegion, changed As Variant, i As Long
    Dim settings As CSystemSettingsReader: Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    Dim oldMode As String: oldMode = settings.GetRequiredString("Results.SnapshotStorage")
    Dim entered As Long, query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    On Error GoTo Failed
    TestSnapshotSetting "Results.SnapshotStorage", "Excel"
    For Each unit In Array("mm", "cm", "m")
        TestSnapshotBoundaryFixture CStr(unit), geometry, boundaries, expected
        Set snapshot = TestSnapshotPreparedPreview(geometry, boundaries, CStr(unit))
        snapshot.Validate
        TestSnapshotCheck CStr(unit) & ".prepared.cache", snapshot.TryCopyValidatedConcreteBoundaries(geometry, copied)
        TestSnapshotCheck CStr(unit) & ".prepared.count", copied.Count = expected.Count
        For i = 1 To expected.Count
            TestSnapshotCheck CStr(unit) & ".prepared.geometry.C" & CStr(i), query.RegionsCoincide(expected(i), copied.Item("C" & CStr(i)))
        Next i
        Set region = copied.Item("C1"): region.SetOwner "CHANGED_COPY", "CHANGED_STANDARD", "CHANGED_ANCHOR"
        copied.RemoveAll
        TestSnapshotCheck CStr(unit) & ".prepared.copyAgain", snapshot.TryCopyValidatedConcreteBoundaries(geometry, second)
        Set region = second.Item("C1")
        TestSnapshotCheck CStr(unit) & ".prepared.dictionaryIndependent", second.Count = expected.Count
        TestSnapshotCheck CStr(unit) & ".prepared.ownerIndependent", region.OwnerID <> "CHANGED_COPY" And region.Standard <> "CHANGED_STANDARD" And region.AnchorID <> "CHANGED_ANCHOR"
        changed = geometry: changed(2, 6) = CDbl(changed(2, 6)) * (1# + 0.000000000001)
        TestSnapshotCheck CStr(unit) & ".prepared.noRoundedAreaKey", Not snapshot.TryCopyValidatedConcreteBoundaries(changed, copied)
        changed = geometry: changed(2, 15) = "Changed metadata"
        TestSnapshotCheck CStr(unit) & ".prepared.metadataChange", Not snapshot.TryCopyValidatedConcreteBoundaries(changed, copied)
        changed = geometry: changed(1, 4) = "X, other"
        TestSnapshotCheck CStr(unit) & ".prepared.unitChange", Not snapshot.TryCopyValidatedConcreteBoundaries(changed, copied)
        changed = geometry: changed(2, 1) = CStr(changed(2, 1))
        TestSnapshotCheck CStr(unit) & ".prepared.variantTypeChange", Not snapshot.TryCopyValidatedConcreteBoundaries(changed, copied)
        BeginCalculationSnapshotRead ThisWorkbook, snapshot: entered = entered + 1
        Set current = CurrentCalculationSnapshot(ThisWorkbook)
        TestSnapshotCheck CStr(unit) & ".prepared.excelUsesPreparedObject", current Is snapshot
        changed = ReadAnchoredResultTable(ThisWorkbook, "rngNDMSectionGeometry")
        TestSnapshotCheck CStr(unit) & ".prepared.tablesFromPrepared", TestSnapshotSameMatrix(changed, geometry)
        Set copied = ReadSavedConcreteBoundaries(ThisWorkbook, geometry)
        TestSnapshotCheck CStr(unit) & ".prepared.boundaryConsumer", copied.Count = expected.Count
        BeginCalculationSnapshotRead ThisWorkbook: entered = entered + 1
        Set current = CurrentCalculationSnapshot(ThisWorkbook)
        TestSnapshotCheck CStr(unit) & ".prepared.nestedSameObject", current Is snapshot
        Call EndCalculationSnapshotRead: entered = entered - 1
        Call EndCalculationSnapshotRead: entered = entered - 1
        Set current = CurrentCalculationSnapshot(ThisWorkbook)
        TestSnapshotCheck CStr(unit) & ".prepared.noPersistentExcelCache", current Is Nothing
        snapshot.RunID = 45001#
        TestSnapshotCheck CStr(unit) & ".prepared.changedRunRejected", TestSnapshotValidationRejected(snapshot)
        snapshot.RunID = 45000#
        TestSnapshotCheck CStr(unit) & ".prepared.restoredRun", snapshot.TryCopyValidatedConcreteBoundaries(geometry, copied)
        snapshot.AddTable "Unexpected.Part", TestSnapshotPreparedHeader(1)
        TestSnapshotCheck CStr(unit) & ".prepared.invalidExtraPartRejected", TestSnapshotValidationRejected(snapshot)
        TestSnapshotCheck CStr(unit) & ".prepared.invalidContextRejected", TestSnapshotPreparedContextRejected(snapshot)
        TestSnapshotCheck CStr(unit) & ".prepared.invalidContextNoLeak", TestCalculationSnapshotReadReleased()
    Next unit
    TestSnapshotSetting "Results.SnapshotStorage", oldMode
    Exit Sub
Failed:
    Dim number As Long, origin As String, reason As String
    number = Err.Number: origin = Err.Source: reason = Err.Description
    On Error Resume Next
    Do While entered > 0: Call EndCalculationSnapshotRead: entered = entered - 1: Loop
    TestSnapshotSetting "Results.SnapshotStorage", oldMode
    On Error GoTo 0
    Err.Raise number, origin, reason
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Собирает минимальный законный GeometryPreview из независимого контурного fixture.
Private Function TestSnapshotPreparedPreview(ByRef geometry As Variant, ByRef boundaries As Variant, ByVal unit As String) As CCalculationSnapshot
    Dim snapshot As CCalculationSnapshot: Set snapshot = New CCalculationSnapshot
    snapshot.RunID = 45000#
    Dim kind(1 To 1, 1 To 1) As Variant: kind(1, 1) = "GeometryPreview"
    snapshot.AddTable "Snapshot.Kind", kind
    snapshot.AddTable "rngNDMSectionGeometry", geometry
    snapshot.AddTable "rngNDMElementGeometry", boundaries
    snapshot.AddTable "rngNDMElementResults", TestSnapshotPreparedHeader(9)
    snapshot.AddTable "rngNDMSectionContours", TestSnapshotPreparedHeader(17)
    snapshot.AddTable "rngNDMMaterialDiagrams", TestSnapshotPreparedHeader(11)
    snapshot.AddTable "rngNDMSectionAnnotations", TestSnapshotPreparedHeader(24)
    Dim properties(1 To 2, 1 To 6) As Variant
    properties(1, 1) = "RunID": properties(2, 1) = 45000#: properties(2, 2) = "ALL"
    properties(2, 3) = "Output.LengthUnit": properties(2, 4) = unit
    snapshot.AddTable "rngNDMSectionProperties", properties
    Set TestSnapshotPreparedPreview = snapshot
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает пустую техническую матрицу нужной ширины без расчётных состояний.
Private Function TestSnapshotPreparedHeader(ByVal columns As Long) As Variant
    Dim values() As Variant: ReDim values(1 To 1, 1 To columns)
    values(1, 1) = "RunID"
    TestSnapshotPreparedHeader = values
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Непригодный явно переданный снимок не должен оставлять открытый контекст чтения.
Private Function TestSnapshotPreparedContextRejected(ByVal snapshot As CCalculationSnapshot) As Boolean
    On Error GoTo Rejected
    BeginCalculationSnapshotRead ThisWorkbook, snapshot
    EndCalculationSnapshotRead
    Exit Function
Rejected:
    TestSnapshotPreparedContextRejected = True
End Function
'''
target=OUT/path.name
target.write_text(s,encoding='utf-8')
manifest_path=OUT/'DeferredSourceManifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
manifest['Changes']=[r for r in manifest['Changes'] if r['Path']!='tests/modTestCalculationSnapshot.bas']
manifest['Changes'].append({'Path':'tests/modTestCalculationSnapshot.bas','OriginalSHA256':hashlib.sha256(path.read_bytes()).hexdigest().upper(),'CandidateSHA256':hashlib.sha256(target.read_bytes()).hexdigest().upper()})
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('PREPARED_REUSE_REGRESSION: part of full Snapshot tests and separate short entrypoint')
