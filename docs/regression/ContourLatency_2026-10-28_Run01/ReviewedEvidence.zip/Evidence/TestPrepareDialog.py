"""ДЛЯ ТЕСТОВ: отмечает границы настоящего MessageBoxW в частном диагностическом проекте."""
from pathlib import Path
import re

SCRATCH=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')
BASE=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ActionLatency_2026-10-28_Run01')
out=SCRATCH/'DialogCode'
out.mkdir(exist_ok=True)
helper=(BASE/'modTestActionProfiler.bas').read_text(encoding='utf-8-sig')
helper=helper.replace('Private mTestStart As Object, mTestValue As Object, mTestCount As Object','Private mTestStart As Object, mTestValue As Object, mTestCount As Object\nPrivate mTestTimeline As String')
helper=helper.replace('Public Sub TestReset()','Public Sub TestReset()\n mTestTimeline = vbNullString')
helper+='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Метка QPC для сопоставления с внешним Stopwatch; не пишет файл в измеряемом участке.
Public Sub TestMark(ByVal name As String)
 mTestTimeline = mTestTimeline & name & vbTab & Replace$(CStr(TestNow()), ",", ".") & vbLf
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает последовательность фактических границ макроса и диалога.
Public Function TestTimeline() As String
 TestTimeline = mTestTimeline
End Function
'''
(out/'modTestActionProfiler.txt').write_text(helper,encoding='utf-8-sig')
s=(SCRATCH/'Instrumented/Contour/modWorkbookCalculation.txt').read_text(encoding='utf-8-sig')
m=re.search(r'(?ims)^Public Sub RunSectionCalculation\(\).*?^End Sub',s)
assert m
body=m[0].replace('Public Sub RunSectionCalculation()','Public Sub RunSectionCalculation()\n    modTestActionProfiler.TestMark "Button.Entry"')
body=body.replace('    Exit Sub','    modTestActionProfiler.TestMark "Button.End"\n    Exit Sub',1)
s=s[:m.start()]+body+s[m.end():]
(out/'modWorkbookCalculation.txt').write_text(s,encoding='utf-8-sig')
s=(SCRATCH/'NativeActual/Contour/modWorkbookMessages.txt').read_text(encoding='utf-8-sig')
s=s.replace('    displayText = WorkbookDialogText(message)','    modTestActionProfiler.TestMark "Dialog.Format.Begin"\n    displayText = WorkbookDialogText(message)\n    modTestActionProfiler.TestMark "Dialog.Format.End"\n    title = "NDM_DIAGNOSTIC_DIALOG"')
s=s.replace('#If VBA7 Then\n    response = MessageBoxUnicode', '    modTestActionProfiler.TestMark "Dialog.Show"\n#If VBA7 Then\n    response = MessageBoxUnicode')
s=s.replace('    If response = 0 Then', '    modTestActionProfiler.TestMark "Dialog.Returned"\n    If response = 0 Then')
(out/'modWorkbookMessages.txt').write_text(s,encoding='utf-8-sig')
print('DIALOG_CODE_READY: native MessageBoxW retained; only markers and private title added')
