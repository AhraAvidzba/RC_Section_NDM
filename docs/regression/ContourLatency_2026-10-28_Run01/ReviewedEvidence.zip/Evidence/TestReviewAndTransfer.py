"""ДЛЯ ТЕСТОВ: читает все первичные журналы и переносит проверенный патч по точным SHA."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent
P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')


def sha(data):
    """Подписывает точные байты файлов без текстовой нормализации."""
    return hashlib.sha256(data).hexdigest().upper()


logs=[]
entries=('RunPreparedSnapshotReuseTests','RunConcreteGeometrySnapshotTests','RunGeometryPreviewStorageTests','RunFileGeometryAuthorityTests','RunCalculationSnapshotTests')
for mode in ('No','Yes'):
    for entry in entries:
        path=P/'Directed04'/f'{entry}_{mode}.txt'
        data=path.read_bytes();text=data.decode('utf-8-sig')
        totals=re.findall(r'^TOTAL[^\r\n]*?(?:passed=)?(\d+)(?:; failed=|/)(\d+)\s*$',text,re.M)
        assert len(totals)==1,(path,totals)
        passed,failed=map(int,totals[0])
        assert failed==0 and not re.search(r'^(?:FAIL|RUNTIME|WATCHDOG_FAILURE)\b',text,re.M),path
        assert len(re.findall(r'^PASS\b',text,re.M))==passed,path
        logs.append(dict(Entry=entry,Mode=mode,Passed=passed,Failed=failed,Bytes=len(data),SHA256=sha(data)))
closures={}
for case in ('Directed01','Directed02','Directed03','Directed04','Paired01','ReadCounts01'):
    closure=json.loads((P/case/'Closure.json').read_text(encoding='utf-8-sig'))
    assert closure['Absent'] and not closure['ForceKilled'],case
    closures[case]=closure
acceptance=dict(Status='PASS_DIRECTED_ONLY',FullSuite=False,Logs=logs,Passed=sum(r['Passed'] for r in logs),Failed=0,
                OwnClosures=closures,CollectorIssue='Directed04 terminal JSON collector failed after all ten reports were saved. This independent review reads and counts every primary report; original Failure.json retained.')
(E/'DirectedAcceptance.json').write_text(json.dumps(acceptance,ensure_ascii=False,indent=2),encoding='utf-8')
manifest=json.loads((P/'Candidate/DeferredSourceManifest.json').read_text(encoding='utf-8'))
assert len(manifest['Changes'])==4
for item in manifest['Changes']:
    assert sha((ROOT/item['Path']).read_bytes())==item['OriginalSHA256'],item
    assert sha((P/'Candidate'/Path(item['Path']).name).read_bytes())==item['CandidateSHA256'],item
for item in manifest['Changes']:
    (ROOT/item['Path']).write_bytes((P/'Candidate'/Path(item['Path']).name).read_bytes())
(E/'SourceTransfer.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')

base=ROOT/'workbook/output/RC_Section_NDM.xlsm'
assert sha(base.read_bytes())=='3A2AF3DDCE17B67A93E354CD8988DEBBC39E63F4272118693DA33E7CBD199500','User book changed: recapture required'
target=P/'Publication01/RC_Section_NDM.xlsm';target.parent.mkdir(exist_ok=True)
(target.parent/'UserBase.xlsm').write_bytes(base.read_bytes())
with zipfile.ZipFile(P/'Directed04/RC_Section_NDM.xlsm') as z:
    vba=z.read('xl/vbaProject.bin')
with zipfile.ZipFile(base) as old,zipfile.ZipFile(target,'w') as new:
    for item in old.infolist():
        new.writestr(item,vba if item.filename=='xl/vbaProject.bin' else old.read(item.filename))
with zipfile.ZipFile(base) as old,zipfile.ZipFile(target) as new:
    assert old.namelist()==new.namelist()
    unchanged=[n for n in old.namelist() if n!='xl/vbaProject.bin' and old.read(n)==new.read(n)]
    assert len(unchanged)==len(old.namelist())-1
    assert new.testzip() is None
proof=dict(UserBaseSHA256=sha(base.read_bytes()),CandidateSHA256=sha(target.read_bytes()),VBASHA256=sha(vba),
           UnchangedParts=unchanged,ChangedParts=['xl/vbaProject.bin'],UserDataPreserved=True,
           HeavyBookTouched=False,BuildSync='Build-Workbook imports these same three source components and test module; layout/catalog unchanged.')
(E/'PackagePreservation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'DirectedPassed':acceptance['Passed'],'SourceFiles':4,'UnchangedZIPParts':len(unchanged),'CandidateSHA256':proof['CandidateSHA256']},ensure_ascii=False))
