"""ДЛЯ ТЕСТОВ: готовит изолированное повторное использование проверенного снимка."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
SCRATCH=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')
OUT=SCRATCH/'Candidate'
OUT.mkdir(exist_ok=True)
changes=[]


def save(rel, body):
    original=(ROOT/rel).read_bytes()
    candidate=body.encode('utf-8')
    target=OUT/Path(rel).name
    target.write_bytes(candidate)
    changes.append({'Path':rel,'OriginalSHA256':hashlib.sha256(original).hexdigest().upper(),'CandidateSHA256':hashlib.sha256(candidate).hexdigest().upper()})


path='src/Excel/modCalculationSnapshot.bas'
s=(ROOT/path).read_text(encoding='utf-8-sig')
s=s.replace('        Set mReadWorkbook = workbook: Set mReadSnapshot = snapshot\n        mReadSourceResolved = False','        If Not snapshot Is Nothing Then snapshot.Validate\n        Set mReadWorkbook = workbook: Set mReadSnapshot = snapshot\n        mReadSourceResolved = Not snapshot Is Nothing \' Готовый набор принадлежит текущему выводу в обоих режимах; ручное чтение без него по-прежнему выбирает Config.')
s=s.replace('        Set mReadSnapshot = snapshot\n        mReadSourceResolved = False','        snapshot.Validate\n        Set mReadSnapshot = snapshot\n        mReadSourceResolved = True')
save(path,s)

path='src/Excel/CCalculationSnapshot.cls'
s=(ROOT/path).read_text(encoding='utf-8-sig')
needle='Private mValidated As Boolean'
pos=s.index('\n',s.index(needle))
s=s[:pos]+"\nPrivate mValidatedBoundaries As Object ' Проверенные точные области принадлежат только неизменяемым таблицам этого снимка; наружу выдаются независимые копии."+s[pos:]
s=s.replace('mValidated = False','mValidated = False: Set mValidatedBoundaries = Nothing')
assert s.count('Set boundaryMap = ReadConcreteBoundaryMap(boundaries, geometry)')==2
s=s.replace('Set boundaryMap = ReadConcreteBoundaryMap(boundaries, geometry)','Set mValidatedBoundaries = ReadConcreteBoundaryMap(boundaries, geometry)')
s=s.replace('Dim geometry As Variant, boundaries As Variant, boundaryMap As Object, row As Long, propertyName As String','Dim geometry As Variant, boundaries As Variant, row As Long, propertyName As String')
s=s.replace('Dim geometry As Variant, boundaries As Variant, boundaryMap As Object','Dim geometry As Variant, boundaries As Variant')
addition='''
' Возвращает независимые области только для точной исходной матрицы этого снимка.
' Изменённая или посторонняя геометрия проходит прежний полный разбор, без округлённых ключей.
Friend Function TryCopyValidatedConcreteBoundaries(ByRef geometry As Variant, ByRef result As Object) As Boolean
    Validate
    If mValidatedBoundaries Is Nothing Then Exit Function
    Dim expected As Variant: expected = Table("rngNDMSectionGeometry")
    If Not SameConcreteGeometryMatrix(geometry, expected) Then Exit Function
    Dim copied As Object: Set copied = CreateObject("Scripting.Dictionary"): copied.CompareMode = vbBinaryCompare
    Dim key As Variant, region As CConcreteRegion
    For Each key In mValidatedBoundaries.Keys
        Set region = mValidatedBoundaries.Item(CStr(key))
        copied.Add CStr(key), region.Clone ' Получатель не может изменить сохранённый контур, владельца или словарь снимка.
    Next key
    Set result = copied
    TryCopyValidatedConcreteBoundaries = True
End Function

' Сравнивает размеры, типы и значения всех ячеек, включая единицы, ID и метаданные.
' При неопределённом значении выбирается безопасный обычный разбор вместо повторного использования.
Private Function SameConcreteGeometryMatrix(ByRef actual As Variant, ByRef expected As Variant) As Boolean
    On Error GoTo Different
    If Not IsArray(actual) Or Not IsArray(expected) Then Exit Function
    If LBound(actual, 1) <> 1 Or LBound(actual, 2) <> 1 Then Exit Function
    If UBound(actual, 1) <> UBound(expected, 1) Or UBound(actual, 2) <> UBound(expected, 2) Then Exit Function
    Dim row As Long, column As Long
    For row = 1 To UBound(actual, 1)
        For column = 1 To UBound(actual, 2)
            If VarType(actual(row, column)) <> VarType(expected(row, column)) Then Exit Function
            If IsError(actual(row, column)) Or IsNull(actual(row, column)) Or IsObject(actual(row, column)) Or IsArray(actual(row, column)) Then Exit Function
            If actual(row, column) <> expected(row, column) Then Exit Function
        Next column
    Next row
    SameConcreteGeometryMatrix = True
    Exit Function
Different:
    Err.Clear
End Function
'''
pos=s.index("' Проверяет запуск непосредственно")
s=s[:pos]+addition+'\n'+s[pos:]
save(path,s)

path='src/Excel/modSectionSnapshot.bas'
s=(ROOT/path).read_text(encoding='utf-8-sig')
needle='    Dim saved As CCalculationSnapshot: Set saved = CurrentCalculationSnapshot(workbook)\n    If Not anchor Is Nothing Or Not saved Is Nothing Then boundaryData = ReadAnchoredResultTable(workbook, "rngNDMElementGeometry")'
assert s.count(needle)==1
replacement='''    Dim saved As CCalculationSnapshot: Set saved = CurrentCalculationSnapshot(workbook)
    If Not saved Is Nothing Then
        Dim checked As Object
        If saved.TryCopyValidatedConcreteBoundaries(data, checked) Then
            Set ReadSavedConcreteBoundaries = checked
            Exit Function
        End If
    End If
    If Not anchor Is Nothing Or Not saved Is Nothing Then boundaryData = ReadAnchoredResultTable(workbook, "rngNDMElementGeometry")'''
s=s.replace(needle,replacement)
save(path,s)
(OUT/'DeferredSourceManifest.json').write_text(json.dumps({'Changes':changes,'Scope':'P1: immutable per-operation snapshot reuse only; no persistent cache or weaker validation'},ensure_ascii=False,indent=2),encoding='utf-8')
print(f'CANDIDATE_READY: {len(changes)} isolated source components')
