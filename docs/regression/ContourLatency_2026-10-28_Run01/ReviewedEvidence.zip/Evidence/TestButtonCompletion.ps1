﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет изолированные правки и старые контракты снимков без полного UI/ON-OFF-плана.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01'
$dir=Join-Path $scratch 'ButtonCompletion01';if(Test-Path -LiteralPath $dir){throw 'New directed directory required'};[void][IO.Directory]::CreateDirectory($dir)
$path=Join-Path $dir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $scratch 'Publication01/RC_Section_NDM.xlsm') -Destination $path
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestContourDirectedOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$project=$null;$code=$null;$compile=$null;$records=New-Object 'System.Collections.Generic.List[object]';$primaryError=''

# Повторяет тот же COM-вызов при кратком отказе занятого Excel; не создаёт второй экземпляр.
function Invoke-TestCom([scriptblock]$Action){$watch=[Diagnostics.Stopwatch]::StartNew();while($true){try{return & $Action}catch{if($_.Exception.HResult-notin@(-2147418111,-2147417846)-or$watch.Elapsed.TotalSeconds-gt20){throw};Start-Sleep -Milliseconds 250}}}

try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestContourDirectedOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.Visible=$true;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $scratch 'HashUiCandidate01') -File|Where-Object {$_.Extension-in@('.bas','.cls')}){
  $code=$project.VBComponents.Item($file.BaseName).CodeModule;$body=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  if($file.Extension-eq'.cls'){$body=$body.Substring($body.IndexOf('Option Explicit'))}else{$body=[regex]::Replace($body,'(?m)^Attribute [^\r\n]*\r?\n','')}
  $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
 }
 $code=$project.VBComponents.Item('modWorkbookMessages').CodeModule
 $text=[string]$code.Lines(1,$code.CountOfLines)
 $first=$text.IndexOf('Public Function ShowWorkbookMessage(');$last=$text.IndexOf('End Function',$first)+12
 $test=@'
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Заменяет только системное модальное ожидание, сохраняя всю работу перед показом окна.
Public Function ShowWorkbookMessage(ByVal message As String, Optional ByVal style As VbMsgBoxStyle = vbInformation, Optional ByVal title As String = "RC Section NDM") As VbMsgBoxResult
 Dim warning As String: warning = TryCompleteWorkbookDrawing(ThisWorkbook)
 If Len(warning) > 0 Then message = WorkbookMessageParagraph(message, warning)
 TestRecordButtonDialog WorkbookDialogText(message)
 ShowWorkbookMessage = vbOK
End Function
'@
 $text=$text.Substring(0,$first)+$test+$text.Substring($last)
 $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($text)
 $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule
 $text=@'
Private mTestDialogAt As Double, mTestDialogText As String, mTestBoundaryAtDialog As String

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует границу до ожидания пользователя, не вызывает геометрию или решатель.
Public Sub TestRecordButtonDialog(ByVal message As String)
 mTestDialogText = message: mTestBoundaryAtDialog = TestSavedBoundaryReadCounts(): mTestDialogAt = Timer
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вызывает настоящие публичные кнопки с подменой только MessageBoxW в диагностической копии.
Public Function RunButtonCompletionProbeTests() As String
 mTestReport = "": mTestPassed = 0: mTestFailed = 0
 On Error GoTo Failed
 TestSnapshotSetting "General.NonCriticalMessagesEnabled", "Yes"
 TestSnapshotSetting "Plot.Enabled", "Yes"
 TestSnapshotSetting "Results.SnapshotStorage", "Excel"
 Dim action As Variant, started As Double, returned As Double, position As Long, duration As Double
 For Each action In Array("Form", "Calculate")
  mTestDialogAt = 0#: mTestDialogText = "": Call TestSavedBoundaryReadCounts(True)
  started = Timer
  If CStr(action) = "Form" Then FormSection Else RunSectionCalculation
  returned = Timer
  TestSnapshotCheck CStr(action) & ".messagePresented", mTestDialogAt >= started
  TestSnapshotCheck CStr(action) & ".paintBeforeDialog", Not TestWorkbookDrawingPending(ThisWorkbook)
  TestSnapshotCheck CStr(action) & ".noGeometryAfterDialog", TestSavedBoundaryReadCounts() = mTestBoundaryAtDialog
  TestSnapshotCheck CStr(action) & ".noWorkAfterDialog", returned - mTestDialogAt < 0.05
  TestSnapshotCheck CStr(action) & ".noWarning", InStr(mTestDialogText, "Предупреждение:") = 0
  position = InStr(mTestDialogText, "Время ")
  position = InStr(position, mTestDialogText, ": ") + 2
  duration = CDbl(Split(Mid$(mTestDialogText, position), " с.")(0))
  TestSnapshotCheck CStr(action) & ".timeCoversButton", Abs(duration - (mTestDialogAt - started)) < 0.05
  mTestReport = mTestReport & "TIMING " & CStr(action) & ": beforeDialog=" & CStr(mTestDialogAt - started) & "; afterDialog=" & CStr(returned - mTestDialogAt) & "; displayed=" & CStr(duration) & vbCrLf
  mTestReport = mTestReport & "MESSAGE " & mTestDialogText & vbCrLf
 Next action
 GoTo Finished
Failed:
 TestSnapshotCheck "button.runtime " & CStr(Err.Number) & ": " & Err.Description, False
Finished:
 RunButtonCompletionProbeTests = mTestReport & "TOTAL_BUTTON_COMPLETION: passed=" & CStr(mTestPassed) & "; failed=" & CStr(mTestFailed)
End Function
'@
 $code.AddFromString($text)
 $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){$pane=$app.VBE.ActiveCodePane;[int]$sr=0;[int]$sc=0;[int]$er=0;[int]$ec=0;$pane.GetSelection([ref]$sr,[ref]$sc,[ref]$er,[ref]$ec);[ordered]@{Module=$pane.CodeModule.Parent.Name;StartLine=$sr;EndLine=$er;Text=$pane.CodeModule.Lines($sr,[Math]::Max(1,$er-$sr+1))}|ConvertTo-Json|Set-Content (Join-Path $dir 'CompileSelection.json') -Encoding UTF8;throw 'Candidate tests compilation failed'}
 $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $book.Save()
 foreach($mode in @('No','Yes')){
  $range=$book.Names.Item('rngSystemSettings').RefersToRange;$matrix=$range.Value2
  for($r=2;$r-le$matrix.GetLength(0);$r++){if([string]$matrix[$r,1]-ceq'General.DiagramExtension'){$range.Cells.Item($r,2).Value2=$mode}}
  $range=$null
  foreach($entry in @('RunButtonCompletionProbeTests')){
   [ordered]@{State='RUNNING';Mode=$mode;Entry=$entry;PID=$owned;StartTicksUTC=[string]$ticks;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $dir 'State.json') -Encoding UTF8
   $watch=[Diagnostics.Stopwatch]::StartNew();$report=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.$entry")
   [IO.File]::WriteAllText((Join-Path $dir ($entry+'_'+$mode+'.txt')),$report,[Text.Encoding]::UTF8)
   $matches=[regex]::Matches($report,'(?m)TOTAL[^\r\n]*?(?:passed=)?(\d+)(?:; failed=|/)(\d+)\s*$')
   if($matches.Count-ne1){throw ('Terminal total missing '+$entry)};$total=$matches[0]
   $passed=[int]$total.Groups[1].Value;$failed=[int]$total.Groups[2].Value
   $records.Add([ordered]@{Entry=$entry;Mode=$mode;Passed=$passed;Failed=$failed;Seconds=$watch.Elapsed.TotalSeconds;Bytes=[Text.Encoding]::UTF8.GetByteCount($report)})
   $records|ConvertTo-Json -Depth 5|Set-Content (Join-Path $dir 'Results.json') -Encoding UTF8
   Write-Output ('DIRECTED '+$entry+' '+$mode+': '+$passed+'/'+$failed)
   if($failed-or$report-match'(?m)^FAIL:'){throw ('Directed validation failed '+$entry+' '+$mode)}
  }
 }
 [int]$sum=0;foreach($record in $records){$sum += [int]$record['Passed']};[ordered]@{State='PASSED';Tests=$records.Count;Passed=$sum;Failed=0;FullSuite=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'State.json') -Encoding UTF8
}catch{
 $primaryError=$_.Exception.ToString()
 [ordered]@{State='REVIEW_REQUIRED';Error=$primaryError;Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $dir 'Failure.json') -Encoding UTF8
 throw
}finally{
 $compile=$null;$code=$null;$project=$null;$range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $closeError=''
 try{if($book){Invoke-TestCom {$book.Close($false)}}}catch{$closeError=$_.Exception.ToString()};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 try{if($app){Invoke-TestCom {$app.Quit()}}}catch{$closeError+=$_.Exception.ToString()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$w=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($w.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false;CloseError=$closeError;PrimaryError=$primaryError}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
