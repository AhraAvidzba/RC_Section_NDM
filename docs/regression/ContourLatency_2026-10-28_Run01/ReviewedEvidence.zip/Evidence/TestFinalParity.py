"""ДЛЯ ТЕСТОВ: сравнивает все значения Results и бинарных снимков без рабочего VBA."""
from pathlib import Path
import hashlib
import json
import re
import struct
import sys
import zipfile
import xml.etree.ElementTree as ET

P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}


def results(path):
    """Читает типы, значения и адреса колонок RunID/ExtraData из самого ZIP."""
    with zipfile.ZipFile(path) as z:
        strings = [''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        targets = {r.attrib['Id']: r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        sheet = next(s for s in wb.find('s:sheets', NS) if s.attrib['name'] == 'Results')
        target = targets[sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
        cells = {}
        for c in ET.fromstring(z.read('xl/' + target)).findall('.//s:sheetData/s:row/s:c', NS):
            v = c.find('s:v', NS)
            if v is None:
                continue
            typ = c.attrib.get('t', 'n')
            cells[c.attrib['r']] = (typ, strings[int(v.text)] if typ == 's' else float(v.text) if typ == 'n' else v.text)
        runcols = set()
        extra = set()
        for address, value in cells.items():
            if value == ('s', 'RunID'):
                runcols.add(re.match(r'[A-Z]+', address)[0])
            if value == ('s', 'ExtraData'):
                extra.add(re.match(r'[A-Z]+', address)[0])
        return cells, runcols, extra


def without_hash(value):
    """Исключает только новое производное поле, сохраняя все прежние метаданные."""
    data = json.loads(value)
    data.pop('GeometryHash', None)
    return data


class Reader:
    """Независимый строгий декодер существующего колоночного формата NDMSNP04/05."""
    def __init__(self, path):
        self.data = path.read_bytes()
        assert hashlib.sha256(self.data[:-72]).hexdigest().upper().encode() == self.data[-72:-8]
        self.p = 0

    def take(self, n):
        assert n >= 0 and self.p + n <= len(self.data)
        b = self.data[self.p:self.p+n]
        self.p += n
        return b

    def number(self, fmt):
        return struct.unpack('<' + fmt, self.take(struct.calcsize('<' + fmt)))[0]

    def text(self):
        n = self.number('i')
        assert n % 2 == 0
        return self.take(n).decode('utf-16le')

    def scalar(self):
        kind = self.number('B')
        if kind == 0:
            return None
        if kind == 1:
            return self.text()
        assert kind in (2, 3)
        n = self.number('d')
        return bool(n) if kind == 3 else n

    def matrix(self):
        rows, cols = self.number('i'), self.number('i')
        assert 0 < rows < 10000000 and 0 < cols <= 256
        result = [[None] * cols for _ in range(rows)]
        for c in range(cols):
            mask = self.number('B')
            if mask == 5:
                values = [self.scalar() for _ in range(rows)]
            elif mask == 4:
                values = []
                for _ in range(self.number('i')):
                    length = self.number('i')
                    assert length > 0
                    values += [self.scalar()] * length
                assert len(values) == rows
            else:
                assert mask <= 3
                flags = self.take(rows)
                numbers = struct.unpack('<' + 'd' * rows, self.take(8 * rows)) if mask & 1 else [0.] * rows
                codes = struct.unpack('<' + 'i' * rows, self.take(4 * rows)) if mask & 2 else [0] * rows
                strings = [self.text() for _ in range(self.number('i'))] if mask & 2 else []
                values = [None if f == 0 else strings[codes[i]-1] if f == 1 else numbers[i] if f == 2 else bool(numbers[i]) for i, f in enumerate(flags)]
                assert all(f <= 3 for f in flags)
            for r, v in enumerate(values):
                result[r][c] = v
        return result

    def tables(self):
        signature = self.take(8)
        assert signature in (b'NDMSNP04', b'NDMSNP05') and signature == self.data[-8:]
        assert self.number('i') in (4, 5)
        self.run = self.number('d')
        self.elapsed = self.number('d')
        count = self.number('i')
        result = {}
        for _ in range(count):
            key = self.text()
            result[key] = self.matrix()
        assert self.p == len(self.data) - 72
        return result


def compare(directory):
    """Не вводит допуска: физические числа, статусы, границы и комментарии должны совпасть точно."""
    left, runcols, extra = results(directory / 'Original.xlsm')
    right, run2, extra2 = results(directory / 'Candidate.xlsm')
    assert runcols == run2 and extra == extra2
    excluded = {'RunID': 0, 'Elapsed': 0, 'GeometryHash': 0}
    errors = []
    for a in left.keys() | right.keys():
        x, y = left.get(a), right.get(a)
        if x == y:
            continue
        col = re.match(r'[A-Z]+', a)[0]
        if col in runcols and x and y and x[0] == y[0] == 'n' and 46000 < x[1] < 47000 and 46000 < y[1] < 47000:
            excluded['RunID'] += 1
        elif a == 'A4' and x[0] == y[0] == 'n':
            excluded['Elapsed'] += 1
        elif col in extra and x and y and x[0] == y[0] == 's' and without_hash(x[1]) == without_hash(y[1]):
            excluded['GeometryHash'] += 1
        else:
            errors.append((a, x, y))
    file_count = 0
    files = [directory / f'TestBench_{c}.ndm' for c in ('Original', 'Candidate')]
    if all(p.exists() for p in files):
        a, b = (Reader(p) for p in files)
        x, y = a.tables(), b.tables()
        assert x.keys() == y.keys()
        for key in x:
            assert len(x[key]) == len(y[key])
            for r, (row, other) in enumerate(zip(x[key], y[key])):
                assert len(row) == len(other)
                for c, (v, w) in enumerate(zip(row, other)):
                    file_count += 1
                    if type(v) is type(w) and v == w:
                        continue
                    header = x[key][0][c]
                    if r and header == 'RunID' and v == a.run and w == b.run:
                        continue
                    if r and header == 'ExtraData' and without_hash(v) == without_hash(w):
                        continue
                    if key == 'Summary' and r == 3 and c == 0 and row[1] == other[1] == 'Время расчета, с':
                        continue
                    errors.append((key, r, c, v, w))
    proof = {'Passed': not errors, 'ExactNumericComparison': True, 'ResultsCells': len(left), 'FileValues': file_count, 'AllowedDerivedDifferences': excluded, 'OtherDifferences': errors}
    (directory / 'Parity.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2), encoding='utf-8')
    print(directory.name, json.dumps(proof, ensure_ascii=False))
    assert not errors


if __name__ == '__main__':
    for argument in sys.argv[1:]:
        compare(P / argument)
