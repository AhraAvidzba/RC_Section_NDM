"""ДЛЯ ТЕСТОВ: заменяет только модальное ожидание в диагностической копии Excel."""
from pathlib import Path

P = Path(__file__).resolve().parent
s = (P/'TestHashDirected06.ps1').read_text('utf-8-sig').replace('HashDirected06','ButtonCompletion02').replace("'HashCandidate01'","'HashUiCandidate02'")
pos = s.index(' $app.VBE.ActiveVBProject=')
body = r''' $code=$project.VBComponents.Item('modWorkbookMessages').CodeModule
 $text=[string]$code.Lines(1,$code.CountOfLines)
 $first=$text.IndexOf('Public Function ShowWorkbookMessage(');$last=$text.IndexOf('End Function',$first)+12
 $test=@'
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Заменяет только системное модальное ожидание, сохраняя всю работу перед показом окна.
Public Function ShowWorkbookMessage(ByVal message As String, Optional ByVal style As VbMsgBoxStyle = vbInformation, Optional ByVal title As String = "RC Section NDM") As VbMsgBoxResult
 Dim warning As String: warning = TryCompleteWorkbookDrawing(ThisWorkbook)
 If Len(warning) > 0 Then message = WorkbookMessageParagraph(message, warning)
 TestRecordButtonDialog WorkbookDialogText(message)
 ShowWorkbookMessage = vbOK
End Function
'@
 $text=$text.Substring(0,$first)+$test+$text.Substring($last)
 $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($text)
 $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule
 $text=@'
Private mTestDialogAt As Double, mTestDialogText As String, mTestBoundaryAtDialog As String

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует границу до ожидания пользователя, не вызывает геометрию или решатель.
Public Sub TestRecordButtonDialog(ByVal message As String)
 mTestDialogText = message: mTestBoundaryAtDialog = TestSavedBoundaryReadCounts(): mTestDialogAt = Timer
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вызывает настоящие публичные кнопки с подменой только MessageBoxW в диагностической копии.
Public Function RunButtonCompletionProbeTests() As String
 mTestReport = "": mTestPassed = 0: mTestFailed = 0
 On Error GoTo Failed
 TestSnapshotSetting "General.NonCriticalMessagesEnabled", "Yes"
 TestSnapshotSetting "Plot.Enabled", "Yes"
 TestSnapshotSetting "Results.SnapshotStorage", "Excel"
 Dim action As Variant, started As Double, returned As Double, position As Long, duration As Double
 For Each action In Array("Form", "Calculate")
  mTestDialogAt = 0#: mTestDialogText = "": Call TestSavedBoundaryReadCounts(True)
  started = Timer
  If CStr(action) = "Form" Then FormSection Else RunSectionCalculation
  returned = Timer
  TestSnapshotCheck CStr(action) & ".messagePresented", mTestDialogAt >= started
  TestSnapshotCheck CStr(action) & ".paintBeforeDialog", Not TestWorkbookDrawingPending(ThisWorkbook)
  TestSnapshotCheck CStr(action) & ".noGeometryAfterDialog", TestSavedBoundaryReadCounts() = mTestBoundaryAtDialog
  TestSnapshotCheck CStr(action) & ".noWorkAfterDialog", returned - mTestDialogAt < 0.05
  TestSnapshotCheck CStr(action) & ".noWarning", InStr(mTestDialogText, "Предупреждение:") = 0
  position = InStr(mTestDialogText, "Время ")
  position = InStr(position, mTestDialogText, ": ") + 2
  duration = CDbl(Split(Mid$(mTestDialogText, position), " с.")(0))
  TestSnapshotCheck CStr(action) & ".timeCoversButton", Abs(duration - (mTestDialogAt - started)) < 0.05
  mTestReport = mTestReport & "TIMING " & CStr(action) & ": beforeDialog=" & CStr(mTestDialogAt - started) & "; afterDialog=" & CStr(returned - mTestDialogAt) & "; displayed=" & CStr(duration) & vbCrLf
  mTestReport = mTestReport & "MESSAGE " & mTestDialogText & vbCrLf
 Next action
 GoTo Finished
Failed:
 TestSnapshotCheck "button.runtime " & CStr(Err.Number) & ": " & Err.Description, False
Finished:
 RunButtonCompletionProbeTests = mTestReport & "TOTAL_BUTTON_COMPLETION: passed=" & CStr(mTestPassed) & "; failed=" & CStr(mTestFailed)
End Function
'@
 $code.AddFromString($text)
'''
s = s[:pos]+body+s[pos:]
s = s.replace("@('RunGeometryHashTests')","@('RunButtonCompletionProbeTests')").replace('$app.Visible=$false','$app.Visible=$true')
(P/'TestButtonCompletion02.ps1').write_text(s,encoding='utf-8-sig')
s = (P/'TestHashReopen.ps1').read_text('utf-8-sig').replace('HashReopen02','HashUiReopen02').replace('HashDirected03/','HashUiDirected03/')
(P/'TestHashUiReopen02.ps1').write_text(s,encoding='utf-8-sig')
