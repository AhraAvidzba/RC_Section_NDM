"""ДЛЯ ТЕСТОВ: публикует точный проверенный пакет с защитой от новых пользовательских правок."""
from pathlib import Path
import hashlib
import json
import os
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[3]
E=Path(__file__).resolve().parent
P=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01')


def sha(path):
    """Проверяет точные байты перед заменой и после публикации."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


proof=json.loads((E/'FinalPackagePreservation.json').read_text(encoding='utf-8'))
native=json.loads((P/'SourceEquality_Final02.json').read_text(encoding='utf-8-sig'))
closure=json.loads((P/'NativeFinal02Closure.json').read_text(encoding='utf-8-sig'))
assert native['Passed'] and closure['Absent'] and not closure['ForceKilled']
target=ROOT/'workbook/output/RC_Section_NDM.xlsm'
candidate=P/'Publication02/RC_Section_NDM.xlsm'
other=ROOT/'workbook/output/NDM_Test_1232_30/RC_Section_NDM_ok.xlsm'
assert sha(target)==proof['UserBaseSHA256'],'User file changed after capture'
assert sha(candidate)==proof['CandidateSHA256']
assert sha(other)=='31F188692A01CC421A37CF962598778A5AD1FE6D9AB5D96DD41C29389C0919F7'
assert not list(target.parent.glob('~$*')),'Close the main workbook before replacement'
temporary=target.with_name(target.name+'.codex-contour-new')
assert not temporary.exists()
temporary.write_bytes(candidate.read_bytes())
assert sha(target)==proof['UserBaseSHA256'],'User file changed during staging'
os.replace(temporary,target)
allcode=ROOT/'workbook/output/VBA_All_Code.txt'
allcode.write_bytes((P/'NativeFinal02/Main/VBA_All_Code.txt').read_bytes())
assert sha(target)==proof['CandidateSHA256']
assert sha(other)=='31F188692A01CC421A37CF962598778A5AD1FE6D9AB5D96DD41C29389C0919F7'
result=dict(Status='PUBLISHED_DIRECTED_ACCEPTANCE',AtUTC=datetime.now(timezone.utc).isoformat(),
            Workbook=str(target),WorkbookSHA256=sha(target),AllCodeSHA256=sha(allcode),
            UserBackup=str(P/'Publication02/UserBase.xlsm'),HeavyOkUnchanged=True,
            NonVBAPartsByteIdentical=108,FullSuite=False)
(E/'FinalPublication.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
