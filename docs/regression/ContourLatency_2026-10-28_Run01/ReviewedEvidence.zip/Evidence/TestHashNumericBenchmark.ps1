﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сравнивает исходный и кандидатный код ABBA на одинаковых входах в одном собственном Excel.
param([ValidateSet('Contour','Adaptive')][string]$Mesh='Contour',[ValidateSet('Excel','File')][string]$Storage='Excel')
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ContourLatency_2026-10-28_Run01'
$dir=Join-Path $scratch ('HashNumericPaired_'+$Mesh+'_'+$Storage);if(Test-Path -LiteralPath $dir){throw 'New paired directory required'};[void][IO.Directory]::CreateDirectory($dir)
foreach($case in @('Original','Candidate')){Copy-Item -LiteralPath (Join-Path $scratch 'Publication01/RC_Section_NDM.xlsm') -Destination (Join-Path $dir ($case+'.xlsm'))}
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestPairedContourOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$books=@{};$project=$null;$component=$null;$code=$null;$compile=$null;$records=New-Object 'System.Collections.Generic.List[object]'
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestPairedContourOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 foreach($case in @('Original','Candidate')){
  $book=$app.Workbooks.Open((Join-Path $dir ($case+'.xlsm')),0,$false);$books[$case]=$book;$project=$book.VBProject
  $range=$book.Names.Item('rngSystemSettings').RefersToRange;$matrix=$range.Value2
  for($row=2;$row-le$matrix.GetLength(0);$row++){switch([string]$matrix[$row,1]){'Mesh.CellGeometry'{$range.Cells.Item($row,2).Value2=$Mesh};'Results.SnapshotStorage'{$range.Cells.Item($row,2).Value2=$Storage};'Results.SnapshotName'{$range.Cells.Item($row,2).Value2='TestBench_'+$case}}};$range=$null
  if($case-eq'Candidate'){
   $project=$book.VBProject
   foreach($file in Get-ChildItem -LiteralPath (Join-Path $scratch 'HashCandidate01') -File|Where-Object {$_.Extension-in@('.bas','.cls')}){
    $code=$project.VBComponents.Item($file.BaseName).CodeModule;$body=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
    if($file.Extension-eq'.cls'){$body=$body.Substring($body.IndexOf('Option Explicit'))}else{$body=[regex]::Replace($body,'(?m)^Attribute [^\r\n]*\r?\n','')}
    $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
   }
   $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Candidate compile failed'}
  }
  $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule
  $code.AddFromString("`r`n' -------------------- ДЛЯ ТЕСТОВ --------------------`r`n' Измеряет остаток очереди после возврата штатного действия.`r`nPublic Function TestDrainBenchmarkPaint() As Double`r`nDim started As Double: started = Timer`r`nDoEvents`r`nDoEvents`r`nDoEvents`r`nTestDrainBenchmarkPaint = Timer - started`r`nEnd Function`r`n")
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Benchmark compile failed'}
 }
 $compile=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $app.Visible=$true;$app.EnableEvents=$true;$app.Calculation=-4105
 $trial=0
 foreach($case in @('Original','Candidate','Candidate','Original','Original','Candidate','Candidate','Original')){
  $trial++;$book=$books[$case];$book.Activate();$book.Worksheets.Item('Расчет').Activate()
  foreach($action in @('FormSectionForWorkbook','RunSectionCalculationForWorkbook')){
   if($case-eq'Candidate'){[void]$app.Run("'$($book.Name)'!modSectionSnapshot.TestSavedBoundaryReadCounts",$true)}
   $watch=[Diagnostics.Stopwatch]::StartNew();$message=[string]$app.Run("'$($book.Name)'!$action",$book);$seconds=$watch.Elapsed.TotalSeconds
   $idle=[double]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestDrainBenchmarkPaint")
   $counts=if($case-eq'Candidate'){[string]$app.Run("'$($book.Name)'!modSectionSnapshot.TestSavedBoundaryReadCounts")}else{''}
   if($message-match'не выполнен|не сформирован|Ошибка|Предупреждение'){throw ('Unexpected paired message '+$message)}
   $records.Add([ordered]@{Case=$case;Trial=$trial;Action=$action;Seconds=$seconds;IdleSeconds=$idle;ThroughIdleSeconds=($seconds+$idle);BoundaryFullHashCounts=$counts;Mesh=$Mesh;Storage=$Storage;Message=$message;Ready=[bool]$app.Ready;CalculationState=[int]$app.CalculationState;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')})
   $records|ConvertTo-Json -Depth 5|Set-Content (Join-Path $dir 'Measurements.json') -Encoding UTF8
   Write-Output ('PAIRED '+$case+' #'+$trial+' '+$action+': '+('{0:N3}'-f$seconds)+'s')
  }
 }
 foreach($case in @('Original','Candidate')){$book=$books[$case];$book.Save()}
}finally{
 $compile=$null;$code=$null;$component=$null;$project=$null;$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 foreach($b in $books.Values){$b.Close($false)};$b=$null;$books.Clear();$books=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$w=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($w.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
