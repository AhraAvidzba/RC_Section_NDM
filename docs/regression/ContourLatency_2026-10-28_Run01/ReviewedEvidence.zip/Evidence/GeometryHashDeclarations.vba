' Две независимые числовые свёртки; каждый промежуточный целый меньше 2^49 и точно представим Double.
Private Const GEOMETRY_HASH_PRIME_A As Double = 4294967291#
Private Const GEOMETRY_HASH_PRIME_B As Double = 4294967279#
Private Type TGeometryHashNumber
    Value As Double
End Type
Private Type TGeometryHashBits
    Low As Long
    High As Long
End Type
Private mGeometrySeedA As Double, mGeometrySeedB As Double ' Подпись общей шапки одной неизменяемой пары матриц.
Private mGeometrySeedReady As Boolean ' Разрешает PreparedGeometryHash только после явной подготовки текущих заголовков.
Private mGeometryProvider As LongPtr ' Один штатный провайдер Windows на операцию, без открытия для каждого элемента.
Private Declare PtrSafe Function HashGeometryMemory Lib "advapi32" Alias "CryptHashData" (ByVal hash As LongPtr, ByVal data As LongPtr, ByVal count As Long, ByVal flags As Long) As Long
