﻿# Убирает только доказанно пустые строки прежнего собственного гайда в кандидате.
$ErrorActionPreference='Stop'
$root=(Get-Location).Path
. (Join-Path $root 'tools/build_workbook/HelpOutline.ps1')
. (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
$path=Join-Path $root 'docs/regression/GeometryReview_2026-10-12/Candidate.xlsm'
$areas=@(Get-WorkbookPrintAreas (Join-Path $root 'docs/regression/GeometryReview_2026-10-12/Baseline/RC_Section_NDM.xlsm'))
Copy-Item -LiteralPath $path -Destination (Join-Path $root 'docs/regression/GeometryReview_2026-10-12/BeforeGapRepair.xlsm')
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class ReviewResizeWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hWnd,out uint id);}'
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0
try {
 $excel=New-Object -ComObject Excel.Application
 $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=3
 [uint32]$id=0;[void][ReviewResizeWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
 $ownedPid=[int]$id;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
 Write-Output ('OWNED_EXCEL: id='+$ownedPid+'; utcStartTicks='+$ownedTicks)
 $book=$excel.Workbooks.Open($path,0,$false)
 if ($book.ReadOnly) {throw 'Candidate is read-only.'}
 $sheet=$book.Worksheets.Item('Справка')
 $range=$book.Names.Item('rngSectionRecipeGuide').RefersToRange
 if ($range.Row -ne 602 -or $range.Rows.Count -ne 60) {throw 'Unexpected candidate guide range.'}
 Resize-HelpEmptyRows $book $sheet 552 50 $false
 $range=$book.Names.Item('rngSectionRecipeGuide').RefersToRange
 if ($range.Row -ne 552 -or $range.Rows.Count -ne 60) {throw 'Guide did not move intact.'}
 $rows=Get-HelpMainRows $sheet;$config=[int]$rows['Справка по настройкам листа Config']
 Resize-HelpEmptyRows $book $sheet $config 2 $true
 $inserted=Get-HelpMainRows $sheet
 if ($inserted['Справка по настройкам листа Config'] -ne $config+2) {throw 'Insert mapping failed.'}
 Resize-HelpEmptyRows $book $sheet $config 2 $false
 $deleted=Get-HelpMainRows $sheet
 if ($deleted['Справка по настройкам листа Config'] -ne $config) {throw 'Delete mapping failed.'}
 Set-HelpSectionOrderAndOutline $book | Out-Null
 $book.Save()
 Write-Output 'OWNED_BLANK_GAP_REMOVED_AND_RESIZE_ROUNDTRIP_PASS'
} finally {
 if ($book) {$book.Close($false)}
 if ($excel) {$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if ($ownedPid) {
  $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
  if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks) {Stop-Process -Id $ownedPid -Force}
 }
}
Restore-WorkbookPrintAreas $path $areas
