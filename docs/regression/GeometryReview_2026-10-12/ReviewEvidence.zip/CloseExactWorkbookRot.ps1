﻿# Ищет только точную книгу среди зарегистрированных COM-объектов; Excel не завершает.
$ErrorActionPreference='Stop'
$path=[IO.Path]::GetFullPath((Join-Path (Get-Location).Path 'workbook/output/RC_Section_NDM.xlsm'))
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
public static class ReviewWorkbookRot {
 [DllImport("ole32.dll")] static extern int GetRunningObjectTable(int reserved,out IRunningObjectTable table);
 [DllImport("ole32.dll")] static extern int CreateBindCtx(int reserved,out IBindCtx context);
 public static object Find(string path) {
  IRunningObjectTable table; IBindCtx context;
  Marshal.ThrowExceptionForHR(GetRunningObjectTable(0,out table));
  Marshal.ThrowExceptionForHR(CreateBindCtx(0,out context));
  try {
   IEnumMoniker iterator;table.EnumRunning(out iterator);
   try {
    var items=new IMoniker[1];
    while(iterator.Next(1,items,IntPtr.Zero)==0) {
     try {
      string name;items[0].GetDisplayName(context,null,out name);
      if(name.IndexOf(path,StringComparison.OrdinalIgnoreCase)>=0) {object result;table.GetObject(items[0],out result);return result;}
     } finally {Marshal.ReleaseComObject(items[0]);}
    }
   } finally {Marshal.ReleaseComObject(iterator);}
   return null;
  } finally {Marshal.ReleaseComObject(context);Marshal.ReleaseComObject(table);}
 }
}
"@
$book=[ReviewWorkbookRot]::Find($path)
if ($null -eq $book) {throw 'Exact workbook is not registered in ROT.'}
try {
 if (-not [IO.Path]::GetFullPath([string]$book.FullName).Equals($path,[StringComparison]::OrdinalIgnoreCase)) {throw 'ROT object is not the target workbook.'}
 Write-Output ('EXACT_ROT_WORKBOOK: '+$book.FullName+'; readOnly='+$book.ReadOnly+'; saved='+$book.Saved)
 if ($book.ReadOnly -and -not $book.Saved) {throw 'Read-only target has unsaved changes; preserve them.'}
 if (-not $book.ReadOnly) {$book.Save()}
 $book.Close($false)
 Write-Output 'ONLY_TARGET_WORKBOOK_CLOSED; no Excel process terminated.'
} finally {[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
