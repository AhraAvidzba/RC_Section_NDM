﻿$ErrorActionPreference='Stop'
$components=@('CSectionInputTable','modTestDeclarativeGeometry','modTestSectionRecipes','modSectionRecipeApiGuide')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/GeometryReview_2026-10-12/Candidate.xlsm' -ModuleNames $components
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/GeometryReview_2026-10-12/FreshBuild/RC_Section_NDM.xlsm' -ModuleNames $components
& 'tools/build_workbook/Run-Audit02ModeTests.ps1' -SourceWorkbook 'docs/regression/GeometryReview_2026-10-12/Candidate.xlsm' -Mode No -ReportPath 'docs/regression/GeometryReview_2026-10-12/DirectedF04.txt' -Macro @('modTestDeclarativeGeometry.RunInputTableTests','modTestSectionRecipes.RunHollowRecipeInputTests','modTestSectionRecipes.RunRoundedRecipeInputTests','modTestSectionRecipes.RunWorkbookRecipeInputTests') -FailFast
