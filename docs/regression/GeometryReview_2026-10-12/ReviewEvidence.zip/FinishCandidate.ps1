﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-StandaloneWorkbookTexts.ps1' -WorkbookPath 'docs/regression/GeometryReview_2026-10-12/Candidate.xlsm' -ReportPath 'docs/regression/GeometryReview_2026-10-12/NormativeNamesReady.json'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath 'docs/regression/GeometryReview_2026-10-12/Candidate.xlsm' -OutputPath 'docs/regression/GeometryReview_2026-10-12/VBA_Ready.txt'
python tools/build_workbook/Verify-ReviewWorkbook.py --before docs/regression/GeometryReview_2026-10-12/Baseline/RC_Section_NDM.xlsm --after docs/regression/GeometryReview_2026-10-12/Candidate.xlsm --report docs/regression/GeometryReview_2026-10-12/UserDataAccepted.json
if ($LASTEXITCODE -ne 0) {throw 'User data gate failed.'}
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath 'docs/regression/GeometryReview_2026-10-12/VBA_Ready.txt' -ReferenceExportPath 'docs/regression/GeometryReview_2026-10-12/VBA_FreshAccepted.txt' -ReportPath 'docs/regression/GeometryReview_2026-10-12/SourceEqualityAccepted.json'
python -X utf8 tools/build_workbook/Verify-StandaloneHelp.py --book docs/regression/GeometryReview_2026-10-12/Candidate.xlsm --dump docs/regression/GeometryReview_2026-10-12/VBA_Ready.txt --report docs/regression/GeometryReview_2026-10-12/StandaloneHelpAccepted.json
if ($LASTEXITCODE -ne 0) {throw 'Standalone Help gate failed.'}
Write-Output 'READY_REVIEW_CANDIDATE_PASS'
