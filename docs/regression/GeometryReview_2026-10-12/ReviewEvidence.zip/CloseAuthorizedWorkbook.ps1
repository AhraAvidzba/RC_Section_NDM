﻿# По прямому разрешению пользователя закрывает только указанную книгу, не Excel.
$ErrorActionPreference='Stop'
$path=[IO.Path]::GetFullPath((Join-Path (Get-Location).Path 'workbook/output/RC_Section_NDM.xlsm'))
$excel=$null;$book=$null
try {
 $excel=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
 foreach ($item in $excel.Workbooks) {
  if ([IO.Path]::GetFullPath([string]$item.FullName).Equals($path,[StringComparison]::OrdinalIgnoreCase)) {$book=$item;break}
 }
 if ($null -eq $book) {throw 'Target workbook not found in the active Excel instance.'}
 Write-Output ('TARGET_WORKBOOK: '+$book.FullName+'; readOnly='+$book.ReadOnly+'; saved='+$book.Saved)
 if ($book.ReadOnly -and -not $book.Saved) {throw 'Read-only workbook has unsaved user changes; preserve it.'}
 if (-not $book.ReadOnly) {$book.Save()}
 $book.Close($false)
 Write-Output 'ONLY_TARGET_WORKBOOK_CLOSED: Excel and other workbooks left running.'
} finally {
 if ($book) {[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 if ($excel) {[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
}
