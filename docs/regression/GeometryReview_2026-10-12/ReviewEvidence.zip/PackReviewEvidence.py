from pathlib import Path
import hashlib,json,re,zipfile,subprocess,datetime
root=Path.cwd();directory=root/'docs/regression/GeometryReview_2026-10-12'
load=lambda name:json.loads((directory/name).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pub=load('Publication.json'); source=load('PublishedSourceEquality.json');data=load('PublishedUserData.json');standalone=load('PublishedStandaloneHelp.json')
assert pub['Published'] and source['AllPassed'] and data['status']=='REVIEW_XML_PRESERVATION_PASS' and standalone['status']=='STANDALONE_HELP_PASS'
assert sha(root/'workbook/output/RC_Section_NDM.xlsm')==pub['WorkbookSHA256']
assert sha(root/'workbook/output/VBA_All_Code.txt')==pub['ExportSHA256']
for item in pub['ForeignOutputFiles']: assert sha(root/item['Path'])==item['SHA256'],item['Path']
reports=[('Review','DirectedBoundaryAcceptanceFixed.txt','TOTAL_GEOMETRY_REVIEW',745),('Counter','DirectedFixes.txt','TOTAL REBAR COUNTER',33),('Executor','DirectedFixes.txt','TOTAL REBAR RULES',187),('Input','DirectedF04.txt','TOTAL INPUT TABLES',45),('Hollow','DirectedF04.txt','TOTAL HOLLOW INPUT',20),('Rounded','DirectedF04.txt','TOTAL ROUNDED INPUT',14),('Workbook','DirectedF04.txt','TOTAL WORKBOOK RECIPE INPUT',281)]
checks=[]
for name,filename,label,total in reports:
 text=(directory/filename).read_text(encoding='utf-8-sig')
 # Все итоговые строки дополнительно сохранены в manifest; отчёт не подменяется счётчиком.
 totals=re.findall(r'(?m)^TOTAL[^\n]*',text)
 matching=[x for x in totals if f'passed={total}' in x and 'failed=0' in x]
 assert matching,(name,total,totals)
 checks.append({'suite':name,'report':str((directory/filename).relative_to(root)),'passed':total,'failed':0,'totalLine':matching[-1],'sha256':sha(directory/filename)})
assert sum(x['passed'] for x in checks)==1325
source_files=sorted(p for folder in ('src','tests') for p in (root/folder).rglob('*') if p.suffix in ('.cls','.bas'))
snapshot={'status':'ACCEPTED_AND_PUBLISHED','dateUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Updated goal, F01-F04, latest Help and diameter decisions','sourceCodeCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'pushPerformed':False,'workbookSHA256':pub['WorkbookSHA256'],'vbaSHA256':pub['ExportSHA256'],'previousSavedWorkbookSHA256':pub['OriginalWorkbookSHA256'],'actualVBAComponents':149,'repositoryComponents':144,'classCommentCoverage':load('ClassCommentsRelease.json'),'tests':checks,'directedAssertions':1325,'failedAssertions':0,'fullOnOff':{'status':'NOT_RUN','reason':'User requested directed checks only'},'fullExcelUI':{'status':'NOT_RUN','reason':'User requested directed checks only'},'help':{'status':'PASS','guideRows':61,'apiMembers':275,'groups':8,'defaultExpanded':'Config','oneGuideGroup':True,'externalFileReferences':False,'normativeSources':'Only full names of SP63, SP35 and 2017 manual','importantRowRemoved':True},'userData':data,'foreignOutputFilesPreserved':len(pub['ForeignOutputFiles']),'decisions':{'F01':'FIXED','F02':'FIXED','F03':'REMOVED_AND_TESTS_TRANSFERRED','F04':'USER_CONFIRMED_NUMERIC_OR_EMPTY_ONLY; zero/empty disabled; dash and TODO rejected'},'reusedEvidence':'Previous accepted geometry matrices, stability, performance and native AutoCAD2023; untouched paths not rerun','sourceHashes':{p.relative_to(root).as_posix():sha(p) for p in source_files},'reportHashes':{p.relative_to(root).as_posix():sha(p) for p in sorted(directory.rglob('*')) if p.is_file() and p.suffix.lower() in ('.json','.txt','.png','.ps1')},'publication':pub}
(directory/'ReviewEvidenceManifest.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive=directory/'ReviewEvidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(directory.rglob('*')):
  if p.is_file() and p!=archive: z.write(p,p.relative_to(directory))
final={'status':snapshot['status'],'sourceCodeCommit':snapshot['sourceCodeCommit'],'workbookSHA256':snapshot['workbookSHA256'],'vbaSHA256':snapshot['vbaSHA256'],'directedAssertions':1325,'failedAssertions':0,'actualVBAComponents':149,'repositoryComponents':144,'apiMembers':275,'guideRows':61,'userCellsVerified':52003,'foreignFilesPreserved':412,'F01':'FIXED','F02':'FIXED','F03':'REMOVED','F04':'CLOSED_BY_USER_DECISION','fullOnOff':'NOT_RUN_BY_USER_CHOICE','fullExcelUI':'NOT_RUN_BY_USER_CHOICE','archive':archive.relative_to(root).as_posix(),'archiveSHA256':sha(archive),'manifest':'ReviewEvidenceManifest.json (inside archive)','publishedSourceEquality':'PASS','publishedUserData':'PASS','publishedStandaloneHelp':'PASS','pushPerformed':False}
(root/'docs/geometry_refactor/REVIEW_ACCEPTANCE_EVIDENCE.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':final['status'],'archiveBytes':archive.stat().st_size,'archiveSHA256':final['archiveSHA256'],'assertions':1325,'foreignFiles':412}))
