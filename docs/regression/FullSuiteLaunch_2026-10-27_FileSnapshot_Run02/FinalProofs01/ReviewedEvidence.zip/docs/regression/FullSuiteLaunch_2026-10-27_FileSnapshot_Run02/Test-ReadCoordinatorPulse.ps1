# ДЛЯ ТЕСТОВ: наблюдает тот же точный драйвер, не запускает и не останавливает расчеты.
$ErrorActionPreference='Stop'
$p=Get-Process -Id 39096 -ErrorAction Stop
if($null -eq $p.StartTime -or $p.ProcessName -ine 'powershell' -or [string]$p.StartTime.ToUniversalTime().Ticks -cne '639287338414535503'){throw 'Expected driver identity unavailable; do not restart'}
$null=$p.Handle
$finished=$p.WaitForExit(45000)
$e='docs/regression/FullSuiteLaunch_2026-10-27_FileSnapshot_Run02'
[ordered]@{CheckedUTC=[DateTimeOffset]::UtcNow.ToString('o');Classification='VERIFIED_WAIT';PID=39096;StartTicksUTC='639287338414535503';ExactHandleHeld=$true;ExitedDuringWait=$finished;RestartRequested=$false}|ConvertTo-Json|Set-Content ($e+'/VerifiedWaitLast.json') -Encoding UTF8
& 'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe' -NoProfile -ExecutionPolicy Bypass -File ($e+'/Read-CurrentStatus.ps1') -CheckAllHashes | Out-Null
if($LASTEXITCODE -ne 0){throw 'Observer incomplete'}
& 'C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' ($e+'/TestObserveCompleted.py') | Out-Null
if($LASTEXITCODE -ne 0){throw 'Closed observer incomplete'}
& 'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe' -NoProfile -ExecutionPolicy Bypass -File ($e+'/Read-UiProgressSupplement.ps1') | Out-Null
if($LASTEXITCODE -ne 0){throw 'Supplement read incomplete'}
$m=Get-Content ($e+'/MonitorLast.json') -Raw -Encoding UTF8|ConvertFrom-Json
$u=Get-Content ($e+'/UiProgressSupplementLast.json') -Raw -Encoding UTF8|ConvertFrom-Json
[pscustomobject]@{Checked=$m.Checked;Stage=$m.CurrentJob;Driver=$m.Driver;OwnExcel=$m.OwnedExcel;PrimaryErrors=$m.ErrorsInCurrentLog;ProgressErrors=$u.Errors;AllProgressRead=$u.AllProgressRead;Progress=@($m.ProgressFiles|ForEach-Object{[pscustomobject]@{Name=$_.Name;LastWrite=$_.LastWrite;Tail=$_.Tail}});Inputs=$m.InputsChecked;Changed=$m.ChangedInputs;HEAD=$m.HEADUnchanged;Memory=$m.Memory;CompletedJobs=$m.CompletedJobs;FailedClosed=$m.FailedCompletedJobs;Completion=$m.Completion}|ConvertTo-Json -Depth 6
$stdioRecords=@()
$previousStdio=$null
if(Test-Path -LiteralPath ($e+'/StdioObservationLast.json')){$previousStdio=Get-Content -LiteralPath ($e+'/StdioObservationLast.json') -Raw -Encoding UTF8|ConvertFrom-Json}
foreach($stdioName in @('FullLaunch.stdout.log','FullLaunch.stderr.log')){
 $stdioPath=Join-Path $e $stdioName
 $stdioStream=[IO.File]::Open($stdioPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
 try{$stdioMemory=New-Object IO.MemoryStream;try{$stdioStream.CopyTo($stdioMemory);$stdioBytes=$stdioMemory.ToArray()}finally{$stdioMemory.Dispose()}}finally{$stdioStream.Dispose()}
 $stdioEncoding=New-Object Text.UTF8Encoding($false,$true)
 if($stdioBytes.Length -ge 2 -and $stdioBytes[0] -eq 255 -and $stdioBytes[1] -eq 254){$stdioText=[Text.Encoding]::Unicode.GetString($stdioBytes)}elseif($stdioBytes.Length -ge 2 -and $stdioBytes[0] -eq 254 -and $stdioBytes[1] -eq 255){$stdioText=[Text.Encoding]::BigEndianUnicode.GetString($stdioBytes)}else{try{$stdioText=$stdioEncoding.GetString($stdioBytes)}catch [Text.DecoderFallbackException]{$stdioText=[Text.Encoding]::GetEncoding(1251).GetString($stdioBytes)}}
 $stdioSha=[Security.Cryptography.SHA256]::Create();try{$stdioHash=[BitConverter]::ToString($stdioSha.ComputeHash($stdioBytes)).Replace('-','')}finally{$stdioSha.Dispose()}
 $stdioOld=@($previousStdio.Records|Where-Object{$_.Name -eq $stdioName})
 $stdioChanged=$stdioOld.Count -ne 1 -or $stdioOld[0].SHA256 -cne $stdioHash
 $stdioRecords += [pscustomobject]@{Name=$stdioName;Bytes=$stdioBytes.Length;SHA256=$stdioHash;ChangedSincePrevious=$stdioChanged;ReadSucceeded=$true;Text=$stdioText;ErrorLines=@([regex]::Matches($stdioText,'(?im)^(?:Traceback[^\r\n]*|FAILED\b[^\r\n]*|RUNTIME ERROR[^\r\n]*|SCRIPT ERROR[^\r\n]*|WATCHDOG_FAILURE[^\r\n]*|CLEANUP ERROR[^\r\n]*|RESTORE ERROR[^\r\n]*)')|ForEach-Object{$_.Value})}
}
[ordered]@{Checked=$m.Checked;Records=$stdioRecords;ObservationIsNotAcceptance=$true}|ConvertTo-Json -Depth 7|Set-Content -LiteralPath ($e+'/StdioObservationLast.json') -Encoding UTF8
$stdioRecords|Select-Object Name,Bytes,ChangedSincePrevious,ErrorLines|ConvertTo-Json -Depth 5

