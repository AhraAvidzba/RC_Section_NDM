﻿# ==========================================================================
# ДЛЯ ТЕСТОВ: bounded source-only audit, один own Excel; ordinary exit ничего не убивает.
# ==========================================================================
param([string]$PlanJson='',[Parameter(Mandatory=$true)][string]$EvidenceDirectory,[ValidateRange(60,300)][int]$TimeoutSeconds=300)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required.'}
Import-Module ([IO.Path]::Combine($PSHOME,'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1')) -Global
Import-Module ([IO.Path]::Combine($PSHOME,'Modules/Microsoft.PowerShell.Management/Microsoft.PowerShell.Management.psd1')) -Global
if(-not$PlanJson){$PlanJson=Join-Path $PSScriptRoot 'Plan.json'}
$planPath=(Resolve-Path -LiteralPath $PlanJson).Path;$planSHA=(Get-FileHash -LiteralPath $planPath).Hash
$plan=Get-Content -LiteralPath $planPath -Raw -Encoding UTF8|ConvertFrom-Json

# -------------------- ДЛЯ ТЕСТОВ --------------------
# Новый readonly Excel допускается лишь после всей полной приёмки и fresh-проверки прежних владельцев.
function Test-FinalFullFence {
 foreach($item in @($plan.FullClosure,$plan.FullAcceptance)){
  if(-not$item.Path -or -not(Test-Path -LiteralPath $item.Path) -or (Get-FileHash -LiteralPath $item.Path).Hash -cne$item.SHA256){throw 'Actual complete full proofs required; no native worker allowed'}
 }
 $closed=Get-Content -LiteralPath $plan.FullClosure.Path -Raw -Encoding UTF8|ConvertFrom-Json
 $accepted=Get-Content -LiteralPath $plan.FullAcceptance.Path -Raw -Encoding UTF8|ConvertFrom-Json
 if(-not$closed.AllOwnIdentitiesTerminal -or -not$closed.PrimaryLogsReviewed -or $closed.CoreMacrosReviewed -ne178 -or $closed.FocusedSingleCasesReviewed -ne122 -or $closed.FocusedRecordCount -ne26){throw 'All full scope and all own closures required'}
 if($accepted.Status -cne'PASS' -or $accepted.SourceSHA256 -cne$closed.SourceSHA256 -or $accepted.SourceSHA256 -cne$plan.Cases[0].SHA256 -or $accepted.CoreSuites -ne178 -or $accepted.FocusedSingleCases -ne122 -or -not$accepted.SameWorkbookBytes){throw 'Complete same-SHA178+122 PASS required'}
 foreach($identity in $closed.Identities){
  $oldProcess=$null;try{$oldProcess=Get-Process -Id ([int]$identity.PID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -notmatch '^NoProcessFoundForGivenId(,|$)'){throw}}
  if($oldProcess){
   if([string]::IsNullOrWhiteSpace([string]$oldProcess.ProcessName)){throw 'Previous process name unknown'}
   if($oldProcess.ProcessName -ine$identity.Name){continue}
   if($null -eq$oldProcess.StartTime){throw 'Previous identity unknown'}
   if([string]$oldProcess.StartTime.ToUniversalTime().Ticks -ceq[string]$identity.StartTicksUTC){throw 'Full own process is still live'}
  }
 }
}
Test-FinalFullFence

$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$directory=[IO.Path]::GetFullPath($EvidenceDirectory);$control=$directory+'.Watchdog'
$allowed=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path+[IO.Path]::DirectorySeparatorChar
if(-not$directory.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $directory) -or (Test-Path -LiteralPath $control)){throw 'Fresh own evidence/control required.'}
[void][IO.Directory]::CreateDirectory($control)
function Proof([string]$Name,$Value){[IO.File]::WriteAllText((Join-Path $control $Name),(ConvertTo-Json -InputObject $Value -Depth 12),[Text.UTF8Encoding]::new($true))}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Только явный NotFound считается отсутствием; чужая/нечитаемая identity даёт Unknown.
function Test-ProcessState([int]$ID,[long]$Start,[string]$Name){
 $state=[ordered]@{State='Unknown';PID=$ID;ExpectedStartTicksUTC=[string]$Start;ExpectedName=$Name;Error=$null}
 if($ID -le0 -or $Start -le0){$state.Error='Missing process identity';return [pscustomobject]$state}
 try{$p=Get-Process -Id $ID -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -match'^NoProcessFoundForGivenId(,|$)'){$state.State='Absent'}else{$state.Error=$_.Exception.Message};return [pscustomobject]$state}
 try{if($null -eq$p -or $null -eq$p.StartTime){throw 'Process or StartTime unavailable'};$state['ObservedName']=$p.ProcessName;$state['ObservedStartTicksUTC']=[string]$p.StartTime.ToUniversalTime().Ticks;if($p.ProcessName -ieq$Name -and $p.StartTime.ToUniversalTime().Ticks -eq$Start){$state.State='Live'}else{$state.Error='PID identity mismatch'}}catch{$state.Error=$_.Exception.Message}
 return [pscustomobject]$state
}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Timeout останавливает лишь повторно проверенную identity через удержанный handle.
function Test-StopExactTimeout([int]$ID,[long]$Start,[string]$Name){
 if((Test-ProcessState $ID $Start $Name).State -ne'Live'){return}
 $p=Get-Process -Id $ID -ErrorAction Stop;$null=$p.Handle
 if($null -eq$p.StartTime -or $p.ProcessName -ine$Name -or $p.StartTime.ToUniversalTime().Ticks -ne$Start){throw 'Timeout identity changed.'}
 $p.Kill();[void]$p.WaitForExit(3000)
}
$worker=Join-Path $PSScriptRoot 'Test-RunSourceOnly.ps1';$workerSHA=(Get-FileHash -LiteralPath $worker).Hash
foreach($path in @($planPath,$worker,$directory)){if($path.Contains('"')){throw 'Unexpected path quote.'}}
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($null -eq$m -or $null -eq$m.AvailableMBytes -or $null -eq$m.CommitLimit -or $null -eq$m.CommittedBytes -or [double]$m.CommitLimit -le0){throw 'Actual memory unavailable; no worker/Excel created.'}
$ram=[double]$m.AvailableMBytes/1024;$commit=([double]$m.CommitLimit-[double]$m.CommittedBytes)/1GB
Proof 'MemoryBeforeWorker.json' ([ordered]@{RAMGiB=$ram;CommitGiB=$commit;RequiredRAMGiB=8;RequiredCommitGiB=14})
if([double]::IsNaN($ram) -or [double]::IsInfinity($ram) -or [double]::IsNaN($commit) -or [double]::IsInfinity($commit) -or $ram -lt8 -or $commit -lt14){throw '8RAM/14commit reserve required.'}
$arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$worker+'"'),'-PlanJson',('"'+$planPath+'"'),'-EvidenceDirectory',('"'+$directory+'"'))
$p=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $control 'stdout.txt') -RedirectStandardError (Join-Path $control 'stderr.txt')
$null=$p.Handle;$ticks=$p.StartTime.ToUniversalTime().Ticks
Proof 'Launch.json' ([ordered]@{WorkerPID=$p.Id;WorkerStartTicksUTC=[string]$ticks;WorkerSHA256=$workerSHA;PlanSHA256=$planSHA;TimeoutSeconds=$TimeoutSeconds;EvidenceDirectory=$directory})
$clock=[Diagnostics.Stopwatch]::StartNew();$timeout=$false
while(-not$p.WaitForExit(500)){if($clock.Elapsed.TotalSeconds -lt$TimeoutSeconds){continue};$timeout=$true;break}
if($timeout){
 Proof 'Timeout.json' ([ordered]@{ElapsedSeconds=$clock.Elapsed.TotalSeconds;Status='TIMEOUT_NOT_PASS'})
 $ownPath=Join-Path $directory 'Ownership.json'
 if(Test-Path -LiteralPath $ownPath){$own=Get-Content -LiteralPath $ownPath -Raw -Encoding UTF8|ConvertFrom-Json;Test-StopExactTimeout ([int]$own.PID) ([long]$own.StartTicksUTC) 'EXCEL'}
 Test-StopExactTimeout $p.Id $ticks 'powershell'
}else{$p.WaitForExit();$p.Refresh()}
$own=$null;$ownPath=Join-Path $directory 'Ownership.json';if(Test-Path -LiteralPath $ownPath){$own=Get-Content -LiteralPath $ownPath -Raw -Encoding UTF8|ConvertFrom-Json}
$deadline=[DateTimeOffset]::UtcNow.AddSeconds(3)
do{
 $child=Test-ProcessState $p.Id $ticks 'powershell';$excel=Test-ProcessState ([int]$own.PID) ([long]$own.StartTicksUTC) 'EXCEL'
 if(($child.State -eq'Absent' -and $excel.State -eq'Absent') -or [DateTimeOffset]::UtcNow -ge$deadline){break};Start-Sleep -Milliseconds 200
}while($true)
$exitCode=$null;if(-not$timeout){$p.WaitForExit();$p.Refresh();$exitCode=$p.ExitCode}
$acceptance=$null;$acceptPath=Join-Path $directory 'Acceptance.json';if(Test-Path -LiteralPath $acceptPath){$acceptance=Get-Content -LiteralPath $acceptPath -Raw -Encoding UTF8|ConvertFrom-Json}
$pass=-not$timeout -and $exitCode -eq0 -and $child.State -eq'Absent' -and $excel.State -eq'Absent' -and $acceptance -and $acceptance.Passed -and (Get-FileHash -LiteralPath $worker).Hash -ceq$workerSHA -and (Get-FileHash -LiteralPath $planPath).Hash -ceq$planSHA
Proof 'Completion.json' ([ordered]@{Passed=[bool]$pass;Timeout=$timeout;WorkerExitCode=$exitCode;Worker=$child;Excel=$excel;WorkerAcceptance=$acceptance;OrdinaryForceKilled=$false;FullRegressionPass=$false})
if(-not$pass){exit 1}
