"""ДЛЯ ТЕСТОВ: сводит реальные завершённые proofs; не запускает Office и не меняет книги."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
E = ROOT / 'docs/regression/FullSuiteLaunch_2026-10-27_FileSnapshot_Run02'
C = ROOT / 'docs/regression/FullOnOff_2026-10-27_FileSnapshot_Run02'


def TestRead(path):
    """ДЛЯ ТЕСТОВ: читает весь существующий JSON, сохраняя исходные файлы."""
    return json.loads(path.read_text(encoding='utf-8-sig'))


def TestSHA(path):
    """ДЛЯ ТЕСТОВ: хэширует точные байты принятого входа или доказательства."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def TestWrite(path, value):
    """ДЛЯ ТЕСТОВ: записывает только новый собственный итоговый proof."""
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def TestMain():
    """ДЛЯ ТЕСТОВ: требует полный same-SHA PASS и native/closures до архивирования."""
    request, complete = TestRead(E / 'LaunchRequest.json'), TestRead(C / 'CompleteCurrentAcceptance.json')
    scope, closed = TestRead(E / 'TerminalScopeReview.json'), TestRead(E / 'AllOwnClosuresReviewed.json')
    assert complete['Status'] == 'PASS' and complete['SourceSHA256'] == request['SourceSHA256']
    assert complete['CoreSuites'] == 178 and complete['FocusedSingleCases'] == 122
    assert complete['SameWorkbookBytes'] and complete['SingleInvocation']
    assert scope['PrimaryLogsReviewed'] and len(scope['Primary']) == 40 and not scope['InventoryErrors']
    assert closed['AllOwnIdentitiesTerminal'] and len(closed['Identities']) == 44
    assert all(x['State'] in ('Absent', 'ReusedByDifferentProcess') for x in closed['Identities'])
    independent = TestRead(C / 'Focused/Independent.json')
    assert independent['Passed'] and independent['IndependentIntegrals'] == 560 and not independent['Unsupported']
    assert len(independent['Controls']) == 560 and all(x['Passed'] for x in independent['Controls'])
    assert len(independent['Failures']) == 10 and all(x['Passed'] and x['Classification'] == 'ProvenImpossibleByNecessaryForceBounds' and x['StrictMarginN'] > 0 for x in independent['Failures'])
    native = TestRead(E / 'FinalNative01.Watchdog/Completion.json')
    assert native['Passed'] and not native['Timeout'] and native['WorkerExitCode'] == 0 and not native['OrdinaryForceKilled']
    assert native['Worker']['State'] == native['Excel']['State'] == 'Absent'
    cases = [x for group in native['WorkerAcceptance']['Cases'] for x in group if isinstance(x, dict)]
    assert len(cases) == 2 and all(x['Passed'] and x['ReadOnly'] and x['Components'] == 181 and x['SourceComponents'] == 175 and x['DocumentModules'] == 6 for x in cases)
    assert cases[0]['AllCodeComparison']['WorkbookHeaderAndAllBodyBytesEqual']
    assert cases[0]['AllCodeComparison']['OnlyExcludedHeader'] == 'Date'
    raw = TestRead(E / 'FinalNative01/RawNativeComponentComparison.json')
    assert raw['Passed'] and raw['ComponentsCompared'] == 181 and not raw['RawDifferences']
    frames = []
    for case in cases:
        folder = E / 'FinalNative01' / case['Case']
        equality = TestRead(folder / 'SourceEquality.json')
        assert equality['Passed'] and equality['SourceComponents'] == 175 and equality['ExportComponents'] == 181
        assert not equality['Differences'] and len(equality['DocumentSourceMatches']) == 6 and all(x['Equal'] for x in equality['DocumentSourceMatches'])
        interface = TestRead(folder / 'InterfaceReadOnly.json')
        assert interface['RequiredValuesAndInlineListsPassed'] and interface['SettingsKeyCount'] == 111
        assert not interface['FormattingChanged'] and len(interface['Lists']) == 3
        assert all(x['Inline'] and x['InputColor'] == 15135487 for x in interface['Lists'])
        assert len(interface['NativeFrameObservations']) == 5
        assert all(len(x['Edges']) == 4 and all(edge['LineStyle'] not in (-4142, None, 0) for edge in x['Edges']) for x in interface['NativeFrameObservations'])
        frames.append({'Case': case['Case'], 'Keys': 111, 'InlineLists': 3, 'FramedTables': 5})
        assert TestSHA(ROOT / Path(case['Book'])) == case['BookSHA256']
    memory = TestRead(E / 'FinalNative01/MemoryBeforeExcel.json')
    assert memory['RAMGiB'] >= 8 and memory['CommitGiB'] >= 14
    task = TestRead(E / 'ScheduledTaskCleanup.json')
    assert task['ExactTaskAbsent'] and not task['OtherTasksTouched'] and task['Triggers'] == 0
    inputs = request['ProtectedInputs'] + request['SourceComponents'] + request['ParticipatingScripts']
    assert len(inputs) == 502 and all(TestSHA(ROOT / x['Path']) == x['SHA256'] for x in inputs)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == request['SourceCommit']
    assert TestSHA(C / 'Source/RC_Section_NDM.xlsm') == request['SourceSHA256']
    output = E / 'FinalProofs01'
    assert not output.exists(), 'Preserve existing final archive'
    output.mkdir()
    TestWrite(output / 'PostRunInputs502.json', {'Inputs': 502, 'Unchanged': 502, 'Changed': [], 'SourceCommitAtFinalReview': request['SourceCommit'], 'RootAndFrozenSHA256': request['SourceSHA256'], 'AllCodeSHA256': request['AllCodeSHA256'], 'AllOwnFullIdentitiesTerminal': True, 'FinalNativeClosedNormally': True, 'BooksSavedOrModified': False})
    native_review = {'Passed': True, 'ComponentsEachBook': 181, 'SourceComponents': 175, 'DocumentModules': 6, 'BothNativeBodiesLiteralEqual': True, 'PublishedAllCodeBodyLiteralEqual': True, 'OnlyAllCodeHeaderExcluded': 'Date', 'Interface': frames, 'MemoryBeforeExcel': memory, 'OwnExcel': native['Excel'], 'OwnWorker': native['Worker'], 'ForceKilled': False, 'ReadyDataPreserved': True, 'MainSHA256': cases[0]['BookSHA256'], 'ReadySHA256': cases[1]['BookSHA256']}
    TestWrite(output / 'FinalNativeReview.json', native_review)
    primary = []
    for row in scope['Primary']:
        path = ROOT / row['Path']
        assert row['AllBytesRead'] and TestSHA(path) == row['SHA256'] and not row['Errors']
        assert row.get('ExactMacroOrder', True) and row.get('SourceMatches', True)
        primary.append(path)
    files = set(primary)
    for base in (E, C):
        for path in base.rglob('*'):
            if not path.is_file() or output in path.parents:
                continue
            if path.suffix.lower() in ('.json', '.txt', '.log', '.ps1', '.py', '.xml', '.bas', '.diff'):
                files.add(path)
    files.add(Path(__file__))
    manifest = []
    archive = output / 'ReviewedEvidence.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in sorted(files):
            relative = path.relative_to(ROOT).as_posix()
            assert relative.startswith(('docs/regression/', 'tmp/Test-PackRun02Acceptance.py'))
            data = path.read_bytes()
            zipped.writestr(relative, data)
            manifest.append({'Path': relative, 'SHA256': hashlib.sha256(data).hexdigest().upper(), 'Bytes': len(data)})
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None and len(zipped.namelist()) == len(manifest)
    TestWrite(output / 'ArchiveManifest.json', {'ArchiveSHA256': TestSHA(archive), 'ArchiveBytes': archive.stat().st_size, 'Count': len(manifest), 'Entries': manifest})
    TestWrite(output / 'Processed.json', {'Status': 'FULL_SAME_SHA_PASS_FINAL_NATIVE_ACCEPTED_PUBLICATION_PENDING', 'RecordedUTC': datetime.now(timezone.utc).isoformat(), 'SourceSHA256': request['SourceSHA256'], 'SourceCommit': request['SourceCommit'], 'CoreSuites': 178, 'CoreReports': 12, 'FocusedSingleCases': 122, 'FocusedRecords': 26, 'PrimaryFilesReviewed': 40, 'IndependentIntegrals': 560, 'ReviewedExpectedNumFail': 10, 'FullOwnIdentitiesTerminal': 44, 'FinalNativePassed': True, 'FullRegressionPass': True, 'OldRun01FailurePreserved': True, 'NoProductionChangeInThisRepeat': True, 'Inputs502Unchanged': True, 'ForeignOutputsIncluded': False, 'TaskRemoved': task['TaskName'], 'ArchiveSHA256': TestSHA(archive), 'PublicationProof': '../FinalPublication.json'})
    print(json.dumps({'Status': 'FULL_PASS_AND_FINAL_NATIVE_PROOFS_PACKED', 'Files': len(manifest), 'ArchiveBytes': archive.stat().st_size, 'ArchiveSHA256': TestSHA(archive)}))


if __name__ == '__main__':
    TestMain()
