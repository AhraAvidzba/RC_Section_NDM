﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет все точные собственные PID после направленного Focused; не утверждает полный ON/OFF PASS.
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path;Set-Location -LiteralPath $root
$review=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PrimaryReview.json') -Raw -Encoding UTF8|ConvertFrom-Json
$completion=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Completion.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $review.PrimaryLogsReviewed -or $review.FocusedRecordCount -ne 26 -or $review.FocusedSingleCasesReviewed -ne 122 -or @($review.ChangedInputs).Count -or -not $review.HEADUnchanged){throw 'Нет полной проверки первичных журналов precheck.'}
if($completion.Status -ne 'PASS_PENDING_PRIMARY_AND_OWN_CLOSURE_REVIEW' -or -not $completion.FinishedUTC){throw 'Драйвер не завершён.'}
foreach($row in $review.Primary){if((Get-FileHash -LiteralPath (Join-Path $root $row.Path)).Hash -cne $row.SHA256){throw 'Изменён первичный журнал.'}}
$inputs=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Inputs.json') -Raw -Encoding UTF8|ConvertFrom-Json
foreach($row in $inputs){if((Get-FileHash -LiteralPath (Join-Path $root $row.Path)).Hash -cne $row.SHA256){throw ('Изменён вход '+$row.Path)}}
if((& git rev-parse HEAD) -cne $review.SourceCommit){throw 'Изменился HEAD.'}
$states=@();$terminal=$true
foreach($row in $review.Identities){
 $state=[ordered]@{Name=$row.Name;PID=$row.PID;StartTicksUTC=$row.StartTicksUTC;State='Unknown';Provenance=$row.Provenance}
 try{
  $p=Get-Process -Id ([int]$row.PID) -ErrorAction Stop
  $state['ObservedName']=$p.ProcessName;$state['ObservedStartTicksUTC']=[string]$p.StartTime.ToUniversalTime().Ticks
  if($p.ProcessName -ieq $row.Name -and [string]$p.StartTime.ToUniversalTime().Ticks -ceq $row.StartTicksUTC){$state.State='Live'}else{$state.State='ReusedByDifferentProcess'}
 }catch{if($_.FullyQualifiedErrorId -match '^NoProcessFoundForGivenId(,|$)'){$state.State='Absent'}else{$state['Error']=$_.Exception.Message}}
 if($state.State -notin @('Absent','ReusedByDifferentProcess')){$terminal=$false}
 $states+=,$state
}
$result=[ordered]@{Status=$(if($terminal){'DIRECTED_FOCUSED_OWN_IDENTITIES_TERMINAL_NOT_FULL_ACCEPTANCE'}else{'WAITING_LIVE_OR_UNKNOWN'});CheckedUTC=[DateTimeOffset]::UtcNow.ToString('o');SourceSHA256=$review.SourceSHA256;SourceCommit=$review.SourceCommit;AllOwnIdentitiesTerminal=$terminal;InputsUnchanged=$true;InputsChecked=$inputs.Count;Identities=$states;FocusedRecordCount=26;FocusedSingleCasesReviewed=122;PrimaryLogsReviewed=$true;FullAcceptanceClaim=$false;AnyProcessClosed=$false}
$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot $(if($terminal){'AllOwnClosuresReviewed.json'}else{'AllOwnClosuresPending.json'})) -Encoding UTF8
[pscustomobject]@{Status=$result.Status;Identities=$states.Count;AllOwnIdentitiesTerminal=$terminal;FullAcceptanceClaim=$false}|ConvertTo-Json -Compress
if(-not $terminal){exit 1}
