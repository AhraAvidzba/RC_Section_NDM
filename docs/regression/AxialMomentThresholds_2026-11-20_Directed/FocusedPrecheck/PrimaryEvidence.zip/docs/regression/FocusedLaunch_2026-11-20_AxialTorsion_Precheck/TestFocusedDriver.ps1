﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Авторизованный Focused после исправления подготовки; не заменяет следующий полный ON/OFF.
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$repo=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path;Set-Location -LiteralPath $repo
$source=Join-Path $repo 'workbook/output/RC_Section_NDM.xlsm';$head=(& git rev-parse HEAD)
$deadline=[DateTimeOffset]::Parse('2026-11-20T10:00:00+03:00')
if([DateTimeOffset]::UtcNow.AddHours(7).AddMinutes(30) -ge $deadline){throw 'Focused и следующий полный набор с резервом не укладываются в срок.'}
$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($memory.AvailableMBytes/1024 -lt 4 -or ($memory.CommitLimit-$memory.CommittedBytes)/1GB -lt 8){throw 'Недостаточно памяти перед Focused.'}
$memory|Select-Object AvailableMBytes,CommitLimit,CommittedBytes|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'MemoryBefore.json') -Encoding UTF8
$old=Get-Content -LiteralPath (Join-Path $repo 'docs/regression/FullSuiteLaunch_2026-11-19_AxialTorsion_Run01/LaunchRequest.json') -Raw -Encoding UTF8|ConvertFrom-Json
$paths=@($old.ProtectedInputs.Path)+@($old.SourceComponents.Path)+@('src/Excel/CResultsLayoutValidator.cls')
$inputs=@($paths|ForEach-Object{[ordered]@{Path=$_;SHA256=(Get-FileHash -LiteralPath (Join-Path $repo $_)).Hash}})
$inputs|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Inputs.json') -Encoding UTF8
$process=Get-Process -Id $PID
$record=[ordered]@{Status='RUNNING';PID=$PID;StartTicksUTC=[string]$process.StartTime.ToUniversalTime().Ticks;StartedUTC=[DateTimeOffset]::UtcNow.ToString('o');SourceCommit=$head;SourceSHA256=(Get-FileHash -LiteralPath $source).Hash;EvidenceDirectory='docs/regression/FocusedAcceptance_2026-11-20_AxialTorsion_Precheck';Purpose='Directed focused verification; does not replace complete202+122 acceptance'}
$record|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'DriverRun.json') -Encoding UTF8
$code=999;$changed=@()
try{
 $env:PYTHONPATH=(Resolve-Path -LiteralPath 'outputs/AxialMomentThresholds_2026-11-19_Run01/test_dependencies').Path
 & (Join-Path $repo 'tools/build_workbook/Run-FocusedAcceptance.ps1') -SourceWorkbook $source -EvidenceDirectory $record.EvidenceDirectory -MaxSeconds 3600 -DeadlineUTC $deadline.ToString('o') -Python 'C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
 $code=$LASTEXITCODE
}finally{
 foreach($item in $inputs){if((Get-FileHash -LiteralPath (Join-Path $repo $item.Path)).Hash -cne $item.SHA256){$changed+=$item.Path}}
 $record['FinishedUTC']=[DateTimeOffset]::UtcNow.ToString('o');$record['ExitCode']=$code;$record['ChangedInputs']=$changed;$record['HEADUnchanged']=(& git rev-parse HEAD) -ceq $head
 $record.Status='REVIEW_REQUIRED'
 if($code -eq 0 -and -not $changed.Count -and $record.HEADUnchanged){$record.Status='PASS_PENDING_PRIMARY_AND_OWN_CLOSURE_REVIEW'}
 $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Completion.json') -Encoding UTF8
}
if($record.Status -ne 'PASS_PENDING_PRIMARY_AND_OWN_CLOSURE_REVIEW'){exit 1}
