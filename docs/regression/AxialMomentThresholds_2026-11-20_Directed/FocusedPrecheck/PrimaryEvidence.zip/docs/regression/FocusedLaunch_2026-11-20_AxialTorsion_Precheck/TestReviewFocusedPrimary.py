"""ДЛЯ ТЕСТОВ: читает все первичные доказательства precheck и записывает собственные PID; не присваивает полный PASS."""
from pathlib import Path
import hashlib, importlib.util, json, re, subprocess
from datetime import datetime, timezone

here=Path(__file__).resolve().parent; root=here.parents[2]
def test_read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def test_sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
driver=test_read(here/'DriverRun.json'); completion=test_read(here/'Completion.json')
directory=root/driver['EvidenceDirectory']; run=test_read(directory/'Run.json'); prep=test_read(directory/'Probe/Preparation.json')
spec=importlib.util.spec_from_file_location('observer',root/'docs/regression/FullSuiteLaunch_2026-11-19_AxialTorsion_Run01/TestObserveCompleted.py')
observer=importlib.util.module_from_spec(spec);spec.loader.exec_module(observer)
errors=[]; primary=[]; identities={}; cases={}
def test_identity(name,pid,ticks,proof):
    assert name in ('EXCEL','acad','powershell') and int(pid)>0 and int(ticks)>0
    value=identities.setdefault((name,int(pid),str(ticks)),{'Name':name,'PID':int(pid),'StartTicksUTC':str(ticks),'Provenance':[]})
    if proof not in value['Provenance']:value['Provenance'].append(proof)
def test_primary(path,macro=None,expected=None):
    assert path.resolve().is_relative_to(directory)
    raw=path.read_bytes(); text=observer.TestReadText(raw); relative=path.relative_to(root).as_posix()
    failures=observer.ERROR.findall(text)
    if failures:errors.extend(relative+': '+value for value in failures)
    if macro:
        assert re.findall(r'^SUITE_STARTED: ([^;\r\n]+)',text,re.M)==[macro]
        assert re.findall(r'^SUITE_FINISHED: ([^;\r\n]+)',text,re.M)==[macro]
        assert re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)\r?$',text,re.M)==[expected]
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    for pid,ticks in re.findall(r'TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)',text):test_identity('EXCEL',pid,ticks,relative)
    primary.append({'Path':relative,'Bytes':len(raw),'SHA256':test_sha(path),'AllBytesRead':True,'Errors':failures})
    return text

assert completion['Status']=='PASS_PENDING_PRIMARY_AND_OWN_CLOSURE_REVIEW'
assert run['SourceSHA256']==driver['SourceSHA256']==prep['SourceSHA256'] and prep['Compiled'] and not prep['ProductionChanged']
assert test_sha(directory/'Probe/RC_Section_NDM.xlsm')==prep['ProbeWorkbookSHA256']
assert test_read(directory/'Acceptance.json')['Status']=='PASS'
for record in run['Records']:
    assert record['Passed']; path=root/record['Report']
    if path.suffix=='.txt':
        text=test_primary(path,record['Macro'],prep['ProbeWorkbookSHA256']);assert test_sha(path)==record['ReportSHA256']
        if record['Macro']=='modTestBatchCalculation.TestRunFocusedAcceptanceCases':
            manifest=directory/'Probe'/(record['Argument1']+'_'+record['Argument2']+'_Manifest.txt')
            wanted=re.findall(r'^FOCUSED_INPUT\|id=([^|\r\n]+)',manifest.read_text(encoding='utf-8-sig'),re.M)
            actual=re.findall(r'^FOCUSED_TIME\|[^\r\n]*?\|id=([^|\r\n]+)',text,re.M)
            assert actual==wanted and len(actual)==len(set(actual));cases[record['ID']]=actual
    else:
        test_primary(path); value=test_read(path);assert value['Passed']
        if record['ID']=='Independent':
            assert value['SourceSHA256']==driver['SourceSHA256'] and not value.get('Unsupported')
            assert value['ModelCount']==5 and value['ReviewedNumFailStates']==len(value.get('Failures',[]))
            assert all(item['Passed'] for item in value.get('Failures',[]))
        if record['ID']=='NativeCAD':
            assert {item['Macro'] for item in value['Results']}=={'RunRealAutoCADFarOriginTests','RunRealAutoCADFarCapacityTests'}
            for item in value['Results']:
                folder=path.parent/item['Macro'];invocation=test_read(folder/'NativeInvocation.json')
                assert invocation['SourceSHA256']==driver['SourceSHA256'] and invocation['Passed'] and invocation['SourceUnchanged']
                child=folder/'NativeCAD.txt';test_primary(child);assert test_sha(child)==item['ReportSHA256']
for path in directory.rglob('*Ownership.json'):
    value=test_read(path); relative=path.relative_to(root).as_posix()
    if 'OwnedPID' in value:
        name='acad' if path.name=='NativeCADOwnership.json' else value.get('ProcessName')
        if name in ('EXCEL','acad'):test_identity(name,value['OwnedPID'],value['StartTicks'],relative)
    elif value.get('VerifiedNewOwner') is True and value.get('ProcessName')=='EXCEL':
        test_identity('EXCEL',value['PID'],value['StartTicksUTC'],relative)
test_identity('powershell',driver['PID'],driver['StartTicksUTC'],(here/'DriverRun.json').relative_to(root).as_posix())
# Два подготовительных owner-сообщения фактически получены из stdout tool session19728 до запуска gate-ов.
test_identity('EXCEL',13428,'639307224063591699','Observed tool session19728: Prepare OWNED_EXCEL')
test_identity('EXCEL',26252,'639307224304458697','Observed tool session19728: Describe OWNED_EXCEL')
inputs=test_read(here/'Inputs.json');changed=[item['Path'] for item in inputs if test_sha(root/item['Path'])!=item['SHA256']]
head_same=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==driver['SourceCommit']
assert len(run['Records'])==26 and sum(map(len,cases.values()))==122
assert not errors and not changed and head_same and completion['HEADUnchanged'] and not completion['ChangedInputs']
result={'Status':'DIRECTED_FOCUSED_PRIMARY_REVIEWED_NOT_FULL_ACCEPTANCE','CheckedUTC':datetime.now(timezone.utc).isoformat(),'SourceSHA256':driver['SourceSHA256'],'SourceCommit':driver['SourceCommit'],'PrimaryLogsReviewed':True,'FocusedRecordCount':26,'FocusedSingleCasesReviewed':122,'CaseIDs':cases,'Primary':primary,'Identities':list(identities.values()),'InputsChecked':len(inputs),'ChangedInputs':changed,'HEADUnchanged':head_same,'FullAcceptanceClaim':False}
(here/'PrimaryReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in result.items() if key not in ('Primary','Identities','CaseIDs')},ensure_ascii=False))
