﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Полный авторизованный набор, неизменность исходников и общий срок 20.11 10:00 МСК.
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global -ErrorAction Stop
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path;Set-Location -LiteralPath $root
$request=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'LaunchRequest.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $request.ExplicitUserConfirmation -or $request.ExpectedSuites -ne 202 -or $request.CoverageVersion -ne 8){throw 'Нет согласованного полного плана.'}
$driver=Get-Process -Id $PID
[ordered]@{Status='RUNNING';PID=$PID;StartTicksUTC=[string]$driver.StartTime.ToUniversalTime().Ticks;StartedUTC=[DateTimeOffset]::UtcNow.ToString('o');SourceCommit=$request.SourceCommit;SourceSHA256=$request.SourceSHA256}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'DriverRun.json') -Encoding UTF8
$runnerCode=999;$summaryCode=999;$finalCode=999;$reason='';$changed=@();$passed=$false
try{
 if((& git rev-parse HEAD) -cne $request.SourceCommit){throw 'Изменился коммит исходников.'}
 if([DateTimeOffset]::UtcNow.AddHours($request.ForecastHours).AddMinutes(15) -ge [DateTimeOffset]::Parse($request.Deadline)){throw 'Прогноз не укладывается в срок.'}
 foreach($item in @($request.ProtectedInputs)+@($request.SourceComponents)){
  if((Get-FileHash -LiteralPath (Join-Path $root $item.Path)).Hash -cne $item.SHA256){throw ('Изменён вход: '+$item.Path)}
 }
 $memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory -ErrorAction Stop
 $physical=[double]$memory.AvailableMBytes/1024;$commit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
 [ordered]@{CheckedUTC=[DateTimeOffset]::UtcNow.ToString('o');PhysicalFreeGiB=$physical;CommitFreeGiB=$commit}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'MemoryBeforeFull.json') -Encoding UTF8
 if($physical -lt $request.RequiredPhysicalGiB -or $commit -lt $request.RequiredCommitGiB){throw 'Недостаточен запас памяти перед полным набором.'}
 $env:PYTHONPATH=(Resolve-Path -LiteralPath (Join-Path $root $request.PythonDependencies)).Path
 & (Join-Path $PSHOME 'powershell.exe') -NoProfile -ExecutionPolicy Bypass -File tools/build_workbook/Run-FullOnOffAcceptance.ps1 -SourceWorkbook $request.SourceWorkbook -EvidenceDirectory $request.EvidenceDirectory -Deadline $request.Deadline -ForecastHours $request.ForecastHours -Python $request.Python
 $runnerCode=$LASTEXITCODE
 & $request.Python -X utf8 tools/build_workbook/Summarize-FullOnOffAcceptance.py --directory $request.EvidenceDirectory --check
 $summaryCode=$LASTEXITCODE
 & $request.Python -X utf8 tools/build_workbook/Finalize-CompleteAcceptance.py --core-directory $request.EvidenceDirectory --focused-directory ($request.EvidenceDirectory+'/Focused')
 $finalCode=$LASTEXITCODE
}catch{$reason=$_.Exception.Message;Write-Output ('FULL_DRIVER_ERROR: '+$reason)}
finally{
 foreach($item in @($request.ProtectedInputs)+@($request.SourceComponents)){
  if(-not(Test-Path -LiteralPath (Join-Path $root $item.Path)) -or (Get-FileHash -LiteralPath (Join-Path $root $item.Path)).Hash -cne $item.SHA256){$changed+=$item.Path}
 }
 $headChanged=(& git rev-parse HEAD) -cne $request.SourceCommit
 $completePath=Join-Path $root ($request.EvidenceDirectory+'/CompleteCurrentAcceptance.json');$completePass=$false
 if(Test-Path -LiteralPath $completePath){$complete=Get-Content -LiteralPath $completePath -Raw -Encoding UTF8|ConvertFrom-Json;$completePass=$complete.Status -eq 'PASS' -and $complete.SourceSHA256 -ceq $request.SourceSHA256 -and $complete.CoreSuites -eq 202 -and $complete.FocusedSingleCases -eq 122}
 $passed=$runnerCode -eq 0 -and $summaryCode -eq 0 -and $finalCode -eq 0 -and $completePass -and $changed.Count -eq 0 -and -not $headChanged -and -not $reason
 [ordered]@{Status=if($passed){'PASS_PENDING_PRIMARY_LOG_REVIEW'}else{'REVIEW_REQUIRED'};FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o');SourceSHA256=$request.SourceSHA256;SourceCommit=$request.SourceCommit;RunnerExit=$runnerCode;SummaryExit=$summaryCode;FinalizeExit=$finalCode;CompleteAcceptancePassed=$completePass;ExpectedSuites=202;CoverageVersion=8;PrimaryReviewStillRequired=$true;ChangedInputs=$changed;HeadChanged=$headChanged;DriverError=$reason;EvidenceDirectory=$request.EvidenceDirectory}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Completion.json') -Encoding UTF8
}
if(-not $passed){exit 1}
