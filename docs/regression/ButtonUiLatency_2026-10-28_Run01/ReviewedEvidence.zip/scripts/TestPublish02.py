"""ДЛЯ ТЕСТОВ: публикует готовый кандидат для запрошенной ручной проверки пользователя."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

ROOT=Path(__file__).resolve().parents[3]
E=Path(__file__).resolve().parent
P=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')
def sha(path):
    """Сравнивает фактические байты, чтобы не потерять новые пользовательские правки."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def read(path):
    """Читает собственный сохранённый результат приёмки без запуска Excel."""
    return json.loads(path.read_text('utf-8-sig'))
proof=read(E/'PackagePreservation02.json')
assert read(P/'SourceEqualityFinal02.json')['Passed']
for path in (P/'NativeExact02Closure.json',P/'ExactPackageSmoke02/Closure.json'):
    closure=read(path);assert closure['Absent'] and not closure['ForceKilled']
smoke=read(P/'ExactPackageSmoke02/State.json')
assert smoke['State']=='PASSED' and smoke['Failed']==0
target=ROOT/'workbook/output/RC_Section_NDM.xlsm'
candidate=P/'Publication02/RC_Section_NDM.xlsm'
assert sha(target)==proof['UserBaseSHA256'],'User file changed: do not replace'
assert sha(candidate)==proof['CandidateSHA256']
assert not list(target.parent.glob('~$*')),'Main workbook must be closed before replacement'
other=target.parent/'NDM_Test_1232_30/RC_Section_NDM_ok.xlsm'
other_before=sha(other) if other.exists() else None
allcode=target.parent/'VBA_All_Code.txt'
if allcode.exists():(P/'Publication02/UserAllCodeBefore.txt').write_bytes(allcode.read_bytes())
temporary=target.with_name(target.name+'.codex-new')
assert not temporary.exists()
temporary.write_bytes(candidate.read_bytes())
assert sha(target)==proof['UserBaseSHA256']
os.replace(temporary,target)
allcode.write_bytes((P/'NativeExact02/Main/VBA_All_Code.txt').read_bytes())
assert sha(target)==proof['CandidateSHA256']
assert (sha(other) if other.exists() else None)==other_before
result={'Status':'PUBLISHED_AWAITING_USER_BUTTON_TEST','AtUTC':datetime.now(timezone.utc).isoformat(),
        'WorkbookSHA256':sha(target),'AllCodeSHA256':sha(allcode),'Backup':str(P/'Publication02/UserBase.xlsm'),
        'OtherHeavyBookUnchanged':True,'SourceComponents':175,'DocumentComponents':6,
        'DirectedPassed':smoke['Passed'],'DirectedFailed':0,'FullSuite':False,
        'FurtherAutomatedTestsDeferredByUser':True}
(E/'Publication.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=True))
