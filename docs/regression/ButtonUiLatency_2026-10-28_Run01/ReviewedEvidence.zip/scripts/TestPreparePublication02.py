"""Р”Р›РЇ РўР•РЎРўРћР’: РѕР±РЅРѕРІР»СЏРµС‚ VBA Рё С‚РѕР»СЊРєРѕ РІРёРґРёРјРѕСЃС‚СЊ Р»РёРЅРёР№ СѓР¶Рµ СЃРѕС…СЂР°РЅС‘РЅРЅС‹С… РїСЂСЏРјРѕСѓРіРѕР»СЊРЅРёРєРѕРІ."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import re
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
E=Path(__file__).resolve().parent
P=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')
OUT=P/'Publication02'
OUT.mkdir(exist_ok=False)
base=ROOT/'workbook/output/RC_Section_NDM.xlsm'
assert hashlib.sha256(base.read_bytes()).hexdigest().upper()=='093D7D5DD76BB6DFF241B29E2F83796CB3B90C392083D17B90D06B1EF0F50A46','User file changed: recapture required'
closure=json.loads((P/'FinalBuild03/Closure.json').read_text('utf-8-sig'))
assert closure['Released'] and not closure['ForceKilled']
(OUT/'UserBase.xlsm').write_bytes(base.read_bytes())
with ZipFile(base) as z: parts={i.filename:z.read(i.filename) for i in z.infolist()};infos=z.infolist()
with ZipFile(P/'FinalBuild03/RC_Section_NDM.xlsm') as z: vba=z.read('xl/vbaProject.bin')
changes=[]

def patch_shape(match):
    """РњРµРЅСЏРµС‚ С‚РѕР»СЊРєРѕ РІС‹РєР»СЋС‡РµРЅРЅСѓСЋ Р»РёРЅРёСЋ РѕР±С‹С‡РЅРѕРіРѕ РїСЂСЏРјРѕСѓРіРѕР»СЊРЅРёРєР°, РЅРµ РµРіРѕ С„РѕСЂРјСѓ РёР»Рё С†РІРµС‚ Р·Р°Р»РёРІРєРё."""
    body=match.group(0)
    name=re.search(r'\bname="([^"]+)"',body)
    if not name or not name.group(1).startswith('NDMPlot_ElementConcrete'):return body
    main=re.search(r'<a:ln\b[^>]*>.*?</a:ln>',body,re.S)
    if not main or not re.search(r'<a:noFill\s*/>',main.group(0)):return body
    hidden=re.search(r'<a:ext\s+uri="\{91240B29-F687-4F45-9708-019B960494DF\}">\s*<a14:hiddenLine\b.*?</a14:hiddenLine>\s*</a:ext>',body,re.S)
    assert hidden is not None,name.group(1)
    color=re.search(r'<a:srgbClr\s+val="([0-9A-Fa-f]{6})"\s*/>',hidden.group(0))
    assert color is not None,name.group(1)
    fill=f'<a:solidFill><a:srgbClr val="{color.group(1)}"><a:alpha val="0"/></a:srgbClr></a:solidFill>'
    line,count=re.subn(r'<a:noFill\s*/>',lambda _:fill,main.group(0))
    assert count==1
    result=body[:main.start()]+line+body[main.end():]
    result=result.replace(hidden.group(0),'',1)
    # РџРѕСЃР»Рµ СѓРґР°Р»РµРЅРёСЏ РїРѕСЃР»РµРґРЅРµРіРѕ СЂР°СЃС€РёСЂРµРЅРёСЏ СЃРѕС…СЂР°РЅСЏС‚СЊ РїСѓСЃС‚РѕР№ extLst РЅРµ С‚СЂРµР±СѓРµС‚СЃСЏ.
    result=re.sub(r'<a:extLst\b[^>]*>\s*</a:extLst>','',result)
    changes.append({'Name':name.group(1),'OldSHA256':hashlib.sha256(body.encode()).hexdigest().upper(),'NewSHA256':hashlib.sha256(result.encode()).hexdigest().upper()})
    return result

updated=dict(parts);updated['xl/vbaProject.bin']=vba
drawings=[]
for name,data in parts.items():
    if not name.startswith('xl/drawings/') or not name.endswith('.xml'):continue
    text=data.decode('utf-8')
    changed=re.sub(r'<(?P<tag>(?:\w+:)?sp)\b[^>]*>.*?</(?P=tag)>',patch_shape,text,flags=re.S)
    if changed!=text:
        ET.fromstring(changed)
        updated[name]=changed.encode('utf-8');drawings.append(name)
target=OUT/'RC_Section_NDM.xlsm'
with ZipFile(target,'w') as z:
    for info in infos:z.writestr(info,updated[info.filename])
with ZipFile(target) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(parts)
    changed_parts=[n for n in parts if z.read(n)!=parts[n]]
    assert set(changed_parts)=={'xl/vbaProject.bin',*drawings}
    assert all(z.read(n)==parts[n] for n in parts if n not in changed_parts)
proof={'UserBaseSHA256':hashlib.sha256(base.read_bytes()).hexdigest().upper(),'CandidateSHA256':hashlib.sha256(target.read_bytes()).hexdigest().upper(),
       'TotalParts':len(parts),'ChangedParts':changed_parts,'UnchangedParts':len(parts)-len(changed_parts),'ElementLineChanges':changes,
       'DataFormulasSettingsLayoutsUnchanged':True,'OnlyVbaAndExistingConcreteLineVisibilityChanged':True,'ProductionMathChanged':False,'FullSuite':False}
(E/'PackagePreservation02.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in proof.items() if k!='ElementLineChanges'},ensure_ascii=True))
print('ELEMENT_LINE_CHANGES',len(changes))
