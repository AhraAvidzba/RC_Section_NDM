﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Подготавливает собственную видимую копию с первыми метками публичных кнопок, не заменяя MessageBoxW.
param([ValidateSet('Contour','Adaptive')][string]$Mesh='Contour')
$ErrorActionPreference='Stop'
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01'
$dir=Join-Path $scratch 'FinalBuild03'
if(Test-Path -LiteralPath $dir){throw 'Fresh diagnostic directory required'}
[void][IO.Directory]::CreateDirectory($dir)
$path=Join-Path $dir 'RC_Section_NDM.xlsm'
Copy-Item -LiteralPath (Join-Path $root 'workbook/output/RC_Section_NDM.xlsm') -Destination $path
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'RAM/commit reserve insufficient'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestButtonUiOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$project=$null;$code=$null;$compile=$null
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestButtonUiOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Mesh=$Mesh;SourceSHA256=(Get-FileHash -LiteralPath (Join-Path $root 'workbook/output/RC_Section_NDM.xlsm')).Hash;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
 [IO.File]::WriteAllText((Join-Path $dir 'Phase.txt'),'IMPORT')
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $scratch 'FinalCandidate03') -File|Where-Object {$_.Extension-in@('.bas','.cls')}){
  $code=$project.VBComponents.Item($file.BaseName).CodeModule;$body=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  if($file.Extension-eq'.cls'){$body=$body.Substring($body.IndexOf('Option Explicit'))}else{$body=[regex]::Replace($body,'(?m)^Attribute [^\r\n]*\r?\n','')}
  $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
 }
 [IO.File]::WriteAllText((Join-Path $dir 'Phase.txt'),'COMPILE');$app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578)
 if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Probe compilation failed'}
 $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$data=$range.Value2
 for($r=2;$r-le$data.GetLength(0);$r++){
  switch([string]$data[$r,1]){
   'Mesh.CellGeometry'{$range.Cells.Item($r,2).Value2=$Mesh}
   'General.NonCriticalMessagesEnabled'{$range.Cells.Item($r,2).Value2='Yes'}
  }
 }
 $range=$null;[IO.File]::WriteAllText((Join-Path $dir 'Phase.txt'),'SAVE');$book.Worksheets.Item('Расчет').Activate();$book.Save()
 Write-Output 'PHASE_CODE_COMPILED'
}catch{[ordered]@{PrimaryError=$_.Exception.ToString();Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $dir 'Failure.json') -Encoding UTF8;throw}finally{
 $compile=$null;$code=$null;$project=$null;$range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){$absent=$true;break}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Released=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
