﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сравнивает стоимость служебных переключений Excel на отдельных копиях одной схемы.
# Ничего не рассчитывает, рабочие книги не открывает и не сохраняет.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01'
$dir=Join-Path $scratch 'ExcelModeCosts01'
if(Test-Path -LiteralPath $dir){throw 'New evidence directory required'}
[void][IO.Directory]::CreateDirectory($dir)
$source=Join-Path $scratch 'PhaseContour01/ObservedState.xlsm'
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestModeCostOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
foreach($variant in @('Original','ElementsGrouped','ElementsRemoved','OtherSheet')){
 $caseDir=Join-Path $dir $variant;[void][IO.Directory]::CreateDirectory($caseDir)
 $path=Join-Path $caseDir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath $source -Destination $path
 $memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($memory.AvailableMBytes-lt8192-or($memory.CommitLimit-$memory.CommittedBytes)-lt14GB){throw 'RAM/commit reserve insufficient'}
 $app=$null;$book=$null;$chart=$null;$shape=$null;$group=$null;$primary='';$ticks=0;$owned=0
 try{
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][TestModeCostOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$memory.AvailableMBytes/1024;CommitFreeGiB=($memory.CommitLimit-$memory.CommittedBytes)/1GB;SourceSHA256=(Get-FileHash -LiteralPath $source).Hash}|ConvertTo-Json|Set-Content (Join-Path $caseDir 'Ownership.json') -Encoding UTF8
  $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
  $book=$app.Workbooks.Open($path,0,$false);$book.Worksheets.Item('Расчет').Activate()
  $app.ScreenUpdating=$false
  $chart=$book.Worksheets.Item('Расчет').ChartObjects('chtNDMSectionPlot').Chart
  $names=New-Object 'System.Collections.Generic.List[object]';$types=@{}
  for($i=1;$i-le$chart.Shapes.Count;$i++){
   $shape=$chart.Shapes.Item($i)
   $key=[string]$shape.Type;if(-not$types.ContainsKey($key)){$types[$key]=0};$types[$key]++
   if([string]$shape.Name-match'ElementConcrete|ElementRebar'){$names.Add([string]$shape.Name)}
  }
  $before=[int]$chart.Shapes.Count;$children=0;$groupError=''
  if($variant-eq'ElementsGrouped'){
   try{$group=$chart.Shapes.Range([object[]]$names.ToArray()).Group();$group.Name='NDM_Test_ElementGroup';$children=[int]$group.GroupItems.Count}catch{$groupError=$_.Exception.ToString()}
  }
  if($variant-eq'ElementsRemoved'){$chart.Shapes.Range([object[]]$names.ToArray()).Delete()}
  if($variant-eq'OtherSheet'){$book.Worksheets.Item('Config').Activate()}
  $after=[int]$chart.Shapes.Count;$shape=$null;$group=$null;$chart=$null
  $app.ScreenUpdating=$true;$app.Visible=$true;$app.Calculation=-4105
  $rows=@()
  for($iteration=1;$iteration-le3;$iteration++){
   $watch=[Diagnostics.Stopwatch]::StartNew();$app.Calculation=-4135;$manual=$watch.Elapsed.TotalMilliseconds
   $watch.Restart();$app.ScreenUpdating=$false;$screenOff=$watch.Elapsed.TotalMilliseconds
   $watch.Restart();$app.Calculation=-4105;$automatic=$watch.Elapsed.TotalMilliseconds
   $watch.Restart();$app.ScreenUpdating=$true;$screenOn=$watch.Elapsed.TotalMilliseconds
   $watch.Restart();$app.Calculate();$calculate=$watch.Elapsed.TotalMilliseconds
   $rows+=[ordered]@{Iteration=$iteration;ManualMs=$manual;AutomaticMs=$automatic;ScreenOffMs=$screenOff;ScreenOnMs=$screenOn;CalculateMs=$calculate}
  }
  [ordered]@{Variant=$variant;Before=$before;After=$after;ElementCount=$names.Count;GroupedChildren=$children;GroupError=$groupError;ShapeTypes=$types;Rows=$rows}|ConvertTo-Json -Depth 7|Set-Content (Join-Path $caseDir 'Result.json') -Encoding UTF8
  Write-Output ($variant+' '+($rows|ConvertTo-Json -Compress))
 }catch{$primary=$_.Exception.ToString();$primary|Set-Content (Join-Path $caseDir 'Failure.txt');throw}finally{
  $chart=$null;$shape=$null;$group=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  try{if($book){$book.Close($false)}}finally{$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()}
  $released=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
  do{try{$process=Get-Process -Id $owned -ErrorAction Stop;if($process.ProcessName-ne'EXCEL'-or$process.StartTime.ToUniversalTime().Ticks-ne$ticks){$released=$true;break}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$released=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Released=$released;ForceKilled=$false;PrimaryError=$primary}|ConvertTo-Json|Set-Content (Join-Path $caseDir 'Closure.json') -Encoding UTF8
  if(-not$released){throw 'Own process closure not proven'}
 }
}
