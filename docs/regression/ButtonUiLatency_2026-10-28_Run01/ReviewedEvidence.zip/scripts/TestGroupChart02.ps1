﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Изолированно проверяет поддержку группы отдельных элементов в Chart, сохраняя все дочерние фигуры.
$ErrorActionPreference='Stop'
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01'
$dir=Join-Path $scratch 'GroupFeasibility02';[void][IO.Directory]::CreateDirectory($dir)
$path=Join-Path $dir 'RC_Section_NDM.xlsm';if(Test-Path -LiteralPath $path){throw 'New experiment required'}
Copy-Item -LiteralPath (Join-Path $root 'workbook/output/RC_Section_NDM.xlsm') -Destination $path
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt10240-or($m.CommitLimit-$m.CommittedBytes)-lt16GB){throw 'RAM/commit reserve insufficient with visible observer'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestGroupChartOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$project=$null;$code=$null;$compile=$null
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestGroupChartOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($path,0,$false)
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$data=$range.Value2
 for($r=2;$r-le$data.GetLength(0);$r++){if([string]$data[$r,1]-ceq'Mesh.CellGeometry'){$range.Cells.Item($r,2).Value2='Contour'}};$range=$null
 $book.Worksheets.Item('Расчет').Activate()
 $message=[string]$app.Run("'$($book.Name)'!FormSectionForWorkbook",$book)
 $chart=$book.Worksheets.Item('Расчет').ChartObjects('chtNDMSectionPlot').Chart
 $shapeNames=New-Object 'System.Collections.Generic.List[object]'
 for($i=1;$i-le$chart.Shapes.Count;$i++){$shape=$chart.Shapes.Item($i);if($shape.Name-match'ElementConcrete|ElementRebar'){$shapeNames.Add([string]$shape.Name)}};$shape=$null
 [ordered]@{CountBefore=[int]$chart.Shapes.Count;ElementShapes=$shapeNames.Count;FormMessage=$message}|ConvertTo-Json -Depth 4|Set-Content (Join-Path $dir 'Before.json') -Encoding UTF8
 $names=[object[]]$shapeNames.ToArray()
 $watch=[Diagnostics.Stopwatch]::StartNew();$group=$chart.Shapes.Range($names).Group();$group.Name='NDM_Test_ElementGroup'
 [ordered]@{Supported=$true;GroupType=[int]$group.Type;Children=[int]$group.GroupItems.Count;CountAfter=[int]$chart.Shapes.Count;GroupSeconds=$watch.Elapsed.TotalSeconds}|ConvertTo-Json|Set-Content (Join-Path $dir 'Result.json') -Encoding UTF8
 $book.Save();Write-Output ('GROUP_SUPPORTED children='+$group.GroupItems.Count)
}catch{
 [ordered]@{Supported=$false;Error=$_.Exception.ToString();Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $dir 'Failure.json') -Encoding UTF8
 throw
}finally{
 $group=$null;$chart=$null;$shape=$null;$range=$null;$code=$null;$project=$null;$compile=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $released=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){$released=$true;break}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$released=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Released=$released;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$released){throw 'Own normal exit not proven'}
}
