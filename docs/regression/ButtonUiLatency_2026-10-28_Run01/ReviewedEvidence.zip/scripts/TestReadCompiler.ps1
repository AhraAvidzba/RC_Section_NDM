﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Читает фактическое место отказа собственного подготовщика; ничего не импортирует и не нажимает.
$ErrorActionPreference='Stop'
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCompilerOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$project=$null;$pane=$null;$code=$null
try{
 $app=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
 [uint32]$owner=0;[void][TestCompilerOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$owner)
 $identity=Get-Content -LiteralPath 'C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01/PhaseBuild01/Ownership.json' -Raw -Encoding UTF8|ConvertFrom-Json
 if($owner-ne$identity.PID-or(Get-Process -Id $owner).StartTime.ToUniversalTime().Ticks-ne[int64]$identity.StartTicksUTC){throw 'Wrong owner'}
 $pane=$app.VBE.ActiveCodePane;$code=$pane.CodeModule
 [int]$s=0;[int]$c=0;[int]$e=0;[int]$f=0;$pane.GetSelection([ref]$s,[ref]$c,[ref]$e,[ref]$f)
 $report=[ordered]@{PID=$owner;Module=$code.Parent.Name;StartLine=$s;EndLine=$e;Line=$code.Lines($s,[Math]::Max(1,$e-$s+1));Ready=$app.Ready;WorkbookCount=$app.Workbooks.Count}
 $report|ConvertTo-Json|Set-Content -LiteralPath 'docs/regression/ButtonUiLatency_2026-10-28_Run01/CompilerObservation01.json' -Encoding UTF8
 $report|ConvertTo-Json
}finally{$code=$null;$pane=$null;$project=$null;$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()}
