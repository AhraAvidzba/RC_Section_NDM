"""ДЛЯ ТЕСТОВ: изолированный числовой хеш без вызова Windows на каждый элемент."""
from pathlib import Path
import re
import json
import hashlib

ROOT = Path(__file__).resolve().parents[3]
P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')
OUT = P / 'NumericHashCandidate01'
OUT.mkdir(exist_ok=False)
source = ROOT / 'src/Excel/CFileChecksum.cls'
text = source.read_text('utf-8-sig')
start = text.index("' Передаёт весь массив чисел одним вызовом Windows")
end = text.index("' Сворачивает точные биты чисел либо UTF-16", start)
replacement = '''' Сворачивает точные IEEE64-слова и UTF-16 без системного вызова для каждого элемента.
' Каждое промежуточное целое меньше 2^49; числа не округляются и от локали не зависят.
Private Function NumericGeometryHash(ByRef values() As Double, ByVal text As String, ByVal pieces As Collection) As String
    Dim a As Double, b As Double: a = 2166136261#: b = 1315423911#
    Dim number As TGeometryHashNumber, bits As TGeometryHashBits, word As Double, i As Long
    GeometryMixWord a, b, CDbl(UBound(values))
    For i = LBound(values) To UBound(values)
        number.Value = values(i): LSet bits = number
        word = bits.Low: If word < 0# Then word = word + 4294967296#
        GeometryMixWord a, b, word
        word = bits.High: If word < 0# Then word = word + 4294967296#
        GeometryMixWord a, b, word
    Next i
    Dim piece As Variant, block As String
    If Not pieces Is Nothing Then
        For Each piece In pieces
            block = CStr(piece)
            For i = 1 To Len(block): GeometryMixWord a, b, CDbl(AscW(Mid$(block, i, 1)) And &HFFFF&): Next i
        Next piece
    End If
    For i = 1 To Len(text): GeometryMixWord a, b, CDbl(AscW(Mid$(text, i, 1)) And &HFFFF&): Next i
    NumericGeometryHash = GeometryHashHex(a) & GeometryHashHex(b)
End Function

'''
text = text[:start] + replacement + text[end:]
text = text.replace('NativeGeometryHash(', 'NumericGeometryHash(')
text = re.sub(r'^Private mGeometryProvider[^\n]*\n', '', text, flags=re.M)
text = re.sub(r'^Private Declare PtrSafe Function HashGeometryMemory[^\n]*\n', '', text, flags=re.M)
(OUT/source.name).write_text(text, encoding='utf-8')
(OUT/'Manifest.json').write_text(json.dumps({'TestOnly':True,'OriginalSHA256':hashlib.sha256(source.read_bytes()).hexdigest().upper(),'CandidateSHA256':hashlib.sha256((OUT/source.name).read_bytes()).hexdigest().upper()}, indent=2),encoding='utf-8')

compile_script = (ROOT/'docs/regression/ButtonUiLatency_2026-10-28_Run01/TestCompilePhases02.ps1').read_text('utf-8-sig')
compile_script = compile_script.replace("'PhaseBuild02'", "'NumericHashBuild01'")
compile_script = compile_script.replace("(Join-Path $scratch 'PhaseCandidate01')", "(Join-Path $scratch 'NumericHashCandidate01')")
compile_script = compile_script.replace("(Join-Path $root 'workbook/output/RC_Section_NDM.xlsm') -Destination $path", "(Join-Path $scratch 'PhaseBuild02/RC_Section_NDM.xlsm') -Destination $path")
(ROOT/'docs/regression/ButtonUiLatency_2026-10-28_Run01/TestCompileNumericHash01.ps1').write_text(compile_script,encoding='utf-8-sig')
observer=(ROOT/'docs/regression/ButtonUiLatency_2026-10-28_Run01/TestOpenPhases02.ps1').read_text('utf-8-sig')
observer=observer.replace('PhaseContour01','NumericHashContour01').replace('PhaseBuild02/','NumericHashBuild01/').replace('NDM_DIAGNOSTIC_Contour','NDM_DIAGNOSTIC_NumericHash')
old=" while(-not(Test-Path -LiteralPath (Join-Path $dir 'Close.flag'))){if($wait.Elapsed.TotalMinutes-gt25){throw 'Bounded observation expired'};Start-Sleep -Milliseconds 500}"
new=''' $samples=New-Object 'System.Collections.Generic.List[object]'
 $security=Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct | Select-Object displayName,productState
 $security|ConvertTo-Json|Set-Content (Join-Path $dir 'SecurityInventory.json') -Encoding UTF8
 while(-not(Test-Path -LiteralPath (Join-Path $dir 'Close.flag'))){
  if($wait.Elapsed.TotalMinutes-gt25){throw 'Bounded observation expired'}
  foreach($process in @(Get-Process -Id $owned -ErrorAction Stop)+@(Get-Process -Name avp,MsMpEng -ErrorAction SilentlyContinue)){
   $samples.Add([ordered]@{UnixMs=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();Name=$process.ProcessName;PID=$process.Id;CPU=$process.CPU;WorkingSet=$process.WorkingSet64})
  }
  Start-Sleep -Milliseconds 150
 }
 $samples|ConvertTo-Json -Depth 4|Set-Content (Join-Path $dir 'ProcessSamples.json') -Encoding UTF8'''
assert old in observer
observer=observer.replace(old,new)
(ROOT/'docs/regression/ButtonUiLatency_2026-10-28_Run01/TestOpenNumericHash01.ps1').write_text(observer,encoding='utf-8-sig')
print('NUMERIC_HASH_PRIVATE_SOURCES_READY')
