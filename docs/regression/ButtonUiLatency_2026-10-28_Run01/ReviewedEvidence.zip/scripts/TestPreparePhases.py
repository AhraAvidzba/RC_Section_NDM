"""ДЛЯ ТЕСТОВ: этапные метки и время последнего ввода только в частных исходниках."""
from pathlib import Path
import re
import json
import hashlib

ROOT=Path(__file__).resolve().parents[3]
P=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')
OUT=P/'PhaseCandidate01';OUT.mkdir(exist_ok=True)
methods={
 'modWorkbookCalculation':['FormSection','RunSectionCalculation','FormSectionForWorkbook','FormSectionCore','RunSectionCalculationForWorkbook','CalculateSectionCore','FinishWorkbookAction','UpdateSectionGeometryPreviewForWorkbook','UpdateSectionPlotForWorkbook','BuildWorkbookSectionModel','PrepareSectionSnapshot','CalculateResultsSheet','ClearSectionPlotForNoData'],
 'modWorkbookMessages':['CompleteWorkbookDrawing','ShowWorkbookMessage'],
 'CExcelAppStateGuard':['Enter','Restore'],
 
 'CSectionPlotter':['Draw','AddElementSeries','ClearGeneratedShapes'],
 'CNDMResultsWriter':['WriteGeometryPreview','PrepareGeometryPreviewSnapshot','RestoreSnapshotBase','WriteSectionGeometry','WriteElementGeometry'],
 'modSectionSnapshot':['ReadConcreteBoundaryMap'],
 'CSectionPlotDataReader':['LoadFromWorkbook','LoadGeometryPreviewFromWorkbook'],
}
changes=[]
for module,names in methods.items():
    paths=[p for parent in ('src','tests') for p in (ROOT/parent).rglob(module+'.*') if p.suffix in ('.bas','.cls')]
    assert len(paths)==1,(module,paths)
    path=paths[0];text=path.read_text('utf-8-sig')
    for name in names:
        pattern=rf'(?ims)^((?:Public |Private |Friend )?(Function|Sub) {re.escape(name)}\b.*?^End \2)'
        found=list(re.finditer(pattern,text));assert len(found)==1,(module,name)
        m=found[0];body=m.group(1);lines=body.splitlines();line=0
        while lines[line].rstrip().endswith('_'):line+=1
        tag=module+'.'+name
        lines.insert(line+1,f'    TestUiPhaseStamp "BEGIN.{tag}"')
        body='\n'.join(lines);kind=m.group(2)
        body=body.replace('Exit '+kind,f'TestUiPhaseStamp "END.{tag}": Exit {kind}')
        body=body.rsplit('End '+kind,1)[0]+f'    TestUiPhaseStamp "END.{tag}"\nEnd {kind}'
        text=text[:m.start()]+body+text[m.end():]
    if module=='CExcelAppStateGuard':
        text=text.replace('        WriteProperty i, fastValues(i)','        TestUiPhaseStamp "GUARD.ENTER.WRITE." & CStr(i)\n        WriteProperty i, fastValues(i)\n        TestUiPhaseStamp "GUARD.ENTER.WRITTEN." & CStr(i)')
        text=text.replace('                WriteProperty i, mValues(i)','                TestUiPhaseStamp "GUARD.RESTORE.WRITE." & CStr(i)\n                WriteProperty i, mValues(i)\n                TestUiPhaseStamp "GUARD.RESTORE.WRITTEN." & CStr(i)')
    (OUT/path.name).write_text(text,encoding='utf-8')
    changes.append(dict(Path=str(path.relative_to(ROOT)),OriginalSHA256=hashlib.sha256(path.read_bytes()).hexdigest().upper()))

path=ROOT/'tests/modTestCalculationSnapshot.bas';text=path.read_text('utf-8-sig')
declarations='''
Private Type TTestUiLastInput
    cbSize As Long
    tick As Long
End Type
Private Declare PtrSafe Sub TestUiPreciseTime Lib "kernel32" Alias "GetSystemTimePreciseAsFileTime" (ByRef value As Currency)
Private Declare PtrSafe Function TestUiGetTick Lib "kernel32" Alias "GetTickCount" () As Long
Private Declare PtrSafe Function TestUiLastInput Lib "user32" Alias "GetLastInputInfo" (ByRef value As TTestUiLastInput) As Long
Private Declare PtrSafe Function TestUiMessageTime Lib "user32" Alias "GetMessageTime" () As Long
'''
text=text.replace('Option Explicit','Option Explicit\n'+declarations,1)
text+='''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставляет время этапа с последним физическим вводом и сообщением потока; не посылает ввода и не читает геометрию.
Public Sub TestUiPhaseStamp(ByVal label As String)
    Dim value As Currency: TestUiPreciseTime value
    Dim nowTick As Double: nowTick = TestUiUnsignedTick(TestUiGetTick())
    Dim lastInput As TTestUiLastInput: lastInput.cbSize = LenB(lastInput)
    Dim inputDelay As Double, messageDelay As Double
    If TestUiLastInput(lastInput) <> 0 Then inputDelay = nowTick - TestUiUnsignedTick(lastInput.tick)
    If inputDelay < 0# Then inputDelay = inputDelay + 4294967296#
    messageDelay = nowTick - TestUiUnsignedTick(TestUiMessageTime())
    If messageDelay < 0# Then messageDelay = messageDelay + 4294967296#
    Dim channel As Integer: channel = FreeFile
    Open ThisWorkbook.Path & "\\Phases.txt" For Append As #channel
    Print #channel, label & "|" & Replace$(Format$(CDbl(value) - 11644473600000#, "0.000"), ",", ".") & "|" & CStr(inputDelay) & "|" & CStr(messageDelay)
    Close #channel
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Преобразует только двоичный счётчик Windows, без десятичной локали.
Private Function TestUiUnsignedTick(ByVal value As Long) As Double
    TestUiUnsignedTick = value
    If value < 0 Then TestUiUnsignedTick = CDbl(value) + 4294967296#
End Function
'''
(OUT/path.name).write_text(text,encoding='utf-8')
changes.append(dict(Path=str(path.relative_to(ROOT)),OriginalSHA256=hashlib.sha256(path.read_bytes()).hexdigest().upper()))
(OUT/'Manifest.json').write_text(json.dumps(dict(TestOnly=True,Changes=changes),ensure_ascii=False,indent=2),encoding='utf-8')
print('PRIVATE_PHASE_SOURCES',len(changes))
