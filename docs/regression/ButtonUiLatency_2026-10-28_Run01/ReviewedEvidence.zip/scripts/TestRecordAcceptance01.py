"""ДЛЯ ТЕСТОВ: сохраняет первичные наблюдения, сверку прочитанных журналов и компактный архив."""
from pathlib import Path
from datetime import datetime, timezone
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[3]
E=Path(__file__).resolve().parent
P=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')
def sha(path):
    """Подписывает первичный файл, не пересохраняя его содержимое."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def read(path):
    """Читает фактический результат собственного наблюдения."""
    return json.loads(path.read_text('utf-8-sig'))

observations=[
 {'Case':'PhaseContour01','Change':'Исходный Contour, подробные этапы','UserReportedDelay':True},
 {'Case':'PhaseAdaptive01','Change':'Adaptive на тех же входах','UserReportedDelay':False},
 {'Case':'NumericHashContour01','Change':'Хеш без Windows API; в рабочий код НЕ перенесён','StageDelayRemained':True},
 {'Case':'PhaseContourFile01','Change':'Тот же Contour, подробные таблицы в File','UserReportedDelay':True,'UserReply':'сделал. Задержки сохранились и до и после'},
 {'Case':'PhaseContourNoPlot01','Change':'Диаграмма удалена; геометрия Contour прежняя','UserReportedDelay':False,'UserReply':'задержек нет'},
 {'Case':'PhaseContourNoFreeform01','Change':'Удалена только одна сложная фигура; остальные451 сохранены','UserReportedDelay':True,'UserReply':'задержки есть и до и после'},
 {'Case':'PhaseContourNativeRects01','Change':'Все452 объекта; прямоугольникам включена обводка и нормализованы37 поворотов','UserReportedDelay':False,'UserReply':'задержки нет'},
 {'Case':'PhaseContourLineOn01','Change':'Только обводка341 прямоугольника; исходные повороты и сложная фигура сохранены','UserReportedDelay':False,'UserReply':'задержек не заметил'},
 {'Case':'PhaseContourTransparent01','Change':'Та же линия полностью прозрачна','UserReportedDelay':False,'UserReply':'задержек нет'},
]
for row in observations:
    folder=P/row['Case']
    if (folder/'Phases.txt').exists():row['PhasesSHA256']=sha(folder/'Phases.txt')
    if (folder/'ObservedState.xlsm').exists():row['ObservedWorkbookSHA256']=sha(folder/'ObservedState.xlsm')
    row['Ownership']=read(folder/'Ownership.json')
    row['Closure']=read(folder/'Closure.json')
    assert row['Closure']['Released'] and not row['Closure']['ForceKilled']
    if (folder/'Difference.json').exists():row['Difference']=read(folder/'Difference.json')

records=[]
for file in sorted((P/'ExactPackageSmoke02').glob('*.txt')):
    body=file.read_text('utf-8-sig')
    total=re.findall(r'(?m)TOTAL[^\r\n]*?(?:passed=)?(\d+)(?:; failed=|/)(\d+)\s*$',body)
    assert len(total)==1,(file.name,total)
    passed,failed=map(int,total[0])
    assert failed==0 and not re.search(r'(?m)^FAIL:',body),file.name
    records.append({'File':file.name,'SHA256':sha(file),'Bytes':file.stat().st_size,'Passed':passed,'Failed':failed})
assert len(records)==8 and sum(r['Passed'] for r in records)==418
source=read(P/'SourceEqualityFinal02.json');assert source['Passed']
publication=read(E/'Publication.json')
result={'Status':'PUBLISHED_AWAITING_USER_FINAL_BUTTON_TEST','AtUTC':datetime.now(timezone.utc).isoformat(),
 'ConfirmedCause':'Line.Visible=False on the saved Contour concrete shapes; enabling the line with full transparency removed reported UI pauses in controlled manual comparisons.',
 'UnderlyingExcelInternalCause':'Not determined; no general Excel/driver/security root-cause claim.',
 'UserObservations':observations,'PrimaryLogsFullyRead':records,'Passed':418,'Failed':0,
 'NativeSource':{'Passed':True,'SourceComponents':source['SourceComponents'],'ExportComponents':source['ExportComponents'],'ExportSHA256':source['ExportSHA256']},
 'FinalStyleScope':'All Contour concrete shapes, including rectangles, arcs, concave, opening and disconnected boundaries; no geometry change.',
 'NativeRastersInspected':['Hole','Disconnected','Concave'],'Publication':publication,
 'FurtherAutomatedTestsDeferredByUser':True,'AdaptiveFreshTimingComparison':'Deferred by user; no additional geometry operations added to Adaptive.',
 'FullSuite':False,'FinalAutomaticPlotButtonConfirmation':'Pending user test of published book'}
(E/'Acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')

files=[]
for case in [r['Case'] for r in observations]+['FinalBuild03','NativeExact02','ExactPackageSmoke02']:
    folder=P/case
    for file in folder.rglob('*'):
        if file.is_file() and file.suffix in ('.json','.txt','.png'):
            files.append((file,'native/'+str(file.relative_to(P)).replace('\\','/')))
files.extend((p,'scripts/'+p.name) for p in E.iterdir() if p.is_file() and p.suffix in ('.py','.ps1'))
files.extend((p,'proofs/'+p.name) for p in E.iterdir() if p.is_file() and p.suffix=='.json')
files.append((P/'SourceEqualityFinal02.json','native/SourceEqualityFinal02.json'))
archive=E/'ReviewedEvidence.zip'
with ZipFile(archive,'w',ZIP_DEFLATED) as z:
    for file,name in files:z.write(file,name)
manifest={'Files':len(files),'ArchiveSHA256':sha(archive),'Bytes':archive.stat().st_size,'ContainsWorkbooks':False,
          'RawWorkbooksRetainedAt':str(P),'PublicationSHA256':publication['WorkbookSHA256'],'FullSuite':False}
(E/'Processed.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=True))
