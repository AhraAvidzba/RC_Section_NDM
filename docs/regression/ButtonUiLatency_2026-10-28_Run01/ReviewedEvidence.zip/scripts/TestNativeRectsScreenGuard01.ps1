﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сохраняет отдельную копию результатов ручного опыта и разрешает штатное закрытие только своего наблюдателя.
$ErrorActionPreference='Stop'
$dir='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01/PhaseContourNativeRects01'
$identity=Get-Content -LiteralPath (Join-Path $dir 'Ownership.json') -Raw -Encoding UTF8|ConvertFrom-Json
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCaptureUiOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null
try{
 $app=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
 [uint32]$owner=0;[void][TestCaptureUiOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$owner)
 if($owner-ne$identity.PID-or(Get-Process -Id $owner).StartTime.ToUniversalTime().Ticks-ne[int64]$identity.StartTicksUTC){throw 'Wrong active owner'}
 $book=$app.Workbooks.Item('NDM_DIAGNOSTIC_NativeRects.xlsm')
 if([IO.Path]::GetFullPath([string]$book.Path)-cne[IO.Path]::GetFullPath($dir)){throw 'Wrong diagnostic book'}
 $originalScreen=[bool]$app.ScreenUpdating
 $app.ScreenUpdating=$false
 $watch=[Diagnostics.Stopwatch]::StartNew()
 while(-not(Test-Path -LiteralPath (Join-Path $dir 'State.json'))){if($watch.Elapsed.TotalSeconds-gt90){throw 'Bounded preparation wait expired'};Start-Sleep -Milliseconds 200}
 $app.ScreenUpdating=$originalScreen
 [ordered]@{PID=$owner;SavedOriginal=$originalScreen;Restored=[bool]$app.ScreenUpdating;Ready=[bool]$app.Ready;Seconds=$watch.Elapsed.TotalSeconds}|ConvertTo-Json|Set-Content (Join-Path $dir 'PreparationScreenGuard.json') -Encoding UTF8
}finally{$book=$null;$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()}
