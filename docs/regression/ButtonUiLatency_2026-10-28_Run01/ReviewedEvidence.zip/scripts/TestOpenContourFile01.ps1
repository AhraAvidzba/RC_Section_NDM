﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Повторно открывает заранее скомпилированную копию, без VBE и импорта, для ручного нажатия штатных кнопок.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01'
$dir=Join-Path $scratch 'PhaseContourFile01';if(Test-Path -LiteralPath $dir){throw 'New observer directory required'}
[void][IO.Directory]::CreateDirectory($dir)
$path=Join-Path $dir 'NDM_DIAGNOSTIC_ContourFile.xlsm';Copy-Item -LiteralPath (Join-Path $scratch 'PhaseBuild02/RC_Section_NDM.xlsm') -Destination $path
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve insufficient'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestReopenUiOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$primary=''
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestReopenUiOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;SourceSHA256=(Get-FileHash -LiteralPath $path).Hash;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($path,0,$false);$book.Worksheets.Item('Расчет').Activate()
 $settings=$book.Names.Item('rngSystemSettings').RefersToRange;$values=$settings.Value2
 for($row=2;$row-le$values.GetLength(0);$row++){if([string]$values[$row,1]-ceq'Results.SnapshotStorage'){$settings.Cells.Item($row,2).Value2='File'}}
 $settings=$null
 [void]$app.Run("'$($book.Name)'!FormSectionForWorkbook",$book)
 $book.Save()
 Remove-Item -LiteralPath (Join-Path $dir 'Phases.txt') -ErrorAction SilentlyContinue
 [void]$app.Run("'$($book.Name)'!TestUiPhaseStamp",'OBSERVER_READY')
 $app.Caption='NDM_DIAGNOSTIC_ContourFile';$app.Visible=$true;$app.EnableEvents=$true
 [ordered]@{State='READY_UI';PID=$owned;StartTicksUTC=[string]$ticks;Path=$path;ActiveSheet=[string]$book.ActiveSheet.Name;SourceCodeUnchanged=$true}|ConvertTo-Json|Set-Content (Join-Path $dir 'State.json') -Encoding UTF8
 Write-Output ('READY_UI PhaseContourFile01 PID='+$owned)
 $wait=[Diagnostics.Stopwatch]::StartNew()
 while(-not(Test-Path -LiteralPath (Join-Path $dir 'Close.flag'))){if($wait.Elapsed.TotalMinutes-gt25){throw 'Bounded observation expired'};Start-Sleep -Milliseconds 500}
}catch{$primary=$_.Exception.ToString();throw}finally{
 $closeError=''
 try{if($book){$book.Close($false)}}catch{$closeError=$_.Exception.ToString()}
 $book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 try{if($app){$app.Quit()}}catch{$closeError+=$_.Exception.ToString()}
 $app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $released=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){$released=$true;break}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$released=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Released=$released;ForceKilled=$false;PrimaryError=$primary;CloseError=$closeError}|ConvertTo-Json|Set-Content (Join-Path $dir 'Closure.json') -Encoding UTF8
 if(-not$released){throw 'Residual diagnostic identity needs review'}
}
