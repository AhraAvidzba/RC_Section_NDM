"""ДЛЯ ТЕСТОВ: сводит этапы настоящих кнопок, не выдаёт последний ввод за клик."""
from pathlib import Path
import json
import hashlib

P=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')
ROOT=Path(__file__).resolve().parents[3]
result={'Method':'Manual native button clicks; diagnostic VBA timestamps. Last input/message ages are observations, not measured mouse-click timestamps.','Cases':{}}
for case in ('PhaseContour01','PhaseAdaptive01','NumericHashContour01'):
    source=P/case/'Phases.txt'
    if not source.exists():continue
    rows=[]
    for line in source.read_text().splitlines():
        fields=line.split('|')
        if len(fields)==4:rows.append((fields[0],float(fields[1]),float(fields[2]),float(fields[3])))
    actions=[]
    for action in ('FormSection','RunSectionCalculation'):
        tag='modWorkbookCalculation.'+action
        starts=[i for i,r in enumerate(rows) if r[0]=='BEGIN.'+tag]
        for start in starts:
            end=next((i for i in range(start+1,len(rows)) if rows[i][0]=='END.'+tag),None)
            if end is None:continue
            part=rows[start:end+1]
            dialog_start=next((r[1] for r in part if r[0]=='BEGIN.modWorkbookMessages.ShowWorkbookMessage'),None)
            dialog_end=next((r[1] for r in part if r[0]=='END.modWorkbookMessages.ShowWorkbookMessage'),None)
            gaps=[{'From':a[0],'To':b[0],'Ms':round(b[1]-a[1],3)} for a,b in zip(part,part[1:]) if b[1]-a[1]>=80]
            actions.append({'Action':action,'EntryUnixMs':part[0][1],'EntryLastInputAgeMs':part[0][2],'EntryLastMessageAgeMs':part[0][3],
                'VbaEntryToDialogMs':None if dialog_start is None else round(dialog_start-part[0][1],3),
                'DialogWaitMs':None if dialog_end is None or dialog_start is None else round(dialog_end-dialog_start,3),
                'DialogReturnToHandlerReturnMs':None if dialog_end is None else round(part[-1][1]-dialog_end,3),'GapsOver80ms':gaps})
    result['Cases'][case]={'LogSHA256':hashlib.sha256(source.read_bytes()).hexdigest().upper(),'Actions':actions}
out=ROOT/'docs/regression/ButtonUiLatency_2026-10-28_Run01/ManualPhaseReview.json'
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for case,data in result['Cases'].items():
    for action in data['Actions']:print(case,action['Action'],'entry_to_dialog_ms',action['VbaEntryToDialogMs'],'after_dialog_ms',action['DialogReturnToHandlerReturnMs'])
