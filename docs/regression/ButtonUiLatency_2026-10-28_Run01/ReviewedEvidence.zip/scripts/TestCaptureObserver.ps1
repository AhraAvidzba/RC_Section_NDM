﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сохраняет отдельную копию результатов ручного опыта и разрешает штатное закрытие только своего наблюдателя.
$ErrorActionPreference='Stop'
$dir='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01/Contour02'
$identity=Get-Content -LiteralPath (Join-Path $dir 'Ownership.json') -Raw -Encoding UTF8|ConvertFrom-Json
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCaptureUiOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null
try{
 $app=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
 [uint32]$owner=0;[void][TestCaptureUiOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$owner)
 if($owner-ne$identity.PID-or(Get-Process -Id $owner).StartTime.ToUniversalTime().Ticks-ne[int64]$identity.StartTicksUTC){throw 'Wrong active owner'}
 $book=$app.Workbooks.Item('NDM_DIAGNOSTIC_Contour.xlsm')
 if([IO.Path]::GetFullPath([string]$book.Path)-cne[IO.Path]::GetFullPath($dir)){throw 'Wrong diagnostic book'}
 $book.SaveCopyAs((Join-Path $dir 'ObservedState.xlsm'))
 [ordered]@{PID=$owner;ActiveSheet=[string]$book.ActiveSheet.Name;Ready=[bool]$app.Ready;ChartShapes=[int]$book.Worksheets.Item('Расчет').ChartObjects('chtNDMSectionPlot').Chart.Shapes.Count;NativeTime=$book.Worksheets.Item('Results').Range('A4').Value2}|ConvertTo-Json|Set-Content (Join-Path $dir 'ObservedState.json') -Encoding UTF8
 [IO.File]::WriteAllText((Join-Path $dir 'Close.flag'),'close captured observer')
}finally{$book=$null;$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()}
