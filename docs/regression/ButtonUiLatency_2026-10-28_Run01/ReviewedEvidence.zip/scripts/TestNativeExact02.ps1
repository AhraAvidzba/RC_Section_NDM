﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Нативный read-only экспорт точных пакетов; не импортирует и не запускает VBA.
$ErrorActionPreference='Stop'
$directory='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01'
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestNativeFinalOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve insufficient'}
$app=$null;$book=$null;$project=$null;$component=$null;$code=$null
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestNativeFinalOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks}|ConvertTo-Json|Set-Content (Join-Path $directory 'NativeExact02Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 foreach($case in @('Main')){
  $path=Join-Path $directory 'Publication02/RC_Section_NDM.xlsm';$hash=(Get-FileHash -LiteralPath $path).Hash
  $book=$app.Workbooks.Open($path,0,$true);if(-not$book.ReadOnly){throw 'Readonly required'}
  $project=$book.VBProject;if($project.VBComponents.Count-ne181){throw '181 real components required'}
  $out=Join-Path $directory ('NativeExact02/'+$case);[void][IO.Directory]::CreateDirectory($out)
  $all=New-Object Text.StringBuilder;[void]$all.AppendLine('VBA PROJECT EXPORT');[void]$all.AppendLine('Workbook: '+$book.Name);[void]$all.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $names=@()
  for($i=1;$i-le$project.VBComponents.Count;$i++){
   $component=$project.VBComponents.Item($i);$code=$component.CodeModule;$n=[int]$code.CountOfLines;$body=if($n){[string]$code.Lines(1,$n)}else{''}
   [void]$all.AppendLine('='*100);[void]$all.AppendLine('COMPONENT: '+$component.Name);[void]$all.AppendLine('TYPE: '+$component.Type);[void]$all.AppendLine('LINES: '+$n);[void]$all.AppendLine('='*100);if($n){[void]$all.AppendLine($body)};[void]$all.AppendLine()
   [IO.File]::WriteAllText((Join-Path $out ($component.Name+'.txt')),$body,[Text.Encoding]::UTF8);$names+=[ordered]@{Name=[string]$component.Name;Type=[int]$component.Type;Lines=$n}
  }
  [IO.File]::WriteAllText((Join-Path $out 'VBA_All_Code.txt'),$all.ToString(),[Text.Encoding]::UTF8)
  [ordered]@{Case=$case;SHA256=$hash;ReadOnly=[bool]$book.ReadOnly;MacroRunImportSave=$false;Components=$names;ConfigPresent=($book.Worksheets.Item('Config').Name-eq'Config');GeometryAnchor=$book.Names.Item('rngNDMSectionGeometry').RefersTo;BoundariesAnchor=$book.Names.Item('rngNDMElementGeometry').RefersTo}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $out 'NativeVerification.json') -Encoding UTF8
  $code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $book.Close($false);$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if((Get-FileHash -LiteralPath $path).Hash-cne$hash){throw 'Readonly package changed'}
  Write-Output ('NATIVE_READONLY: '+$case+'; 181 components')
 }
}finally{
 $code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $directory 'NativeExact02Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own Excel normal exit not proven'}
}
