"""ДЛЯ ТЕСТОВ: фиксирует чистую публикацию и её границы приёмки без запуска Excel."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent
P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')

def sha(path):
    """Подписывает фактический артефакт публикации."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def read(path):
    """Читает собственное доказательство, сохраняя исторические статусы."""
    return json.loads(path.read_text('utf-8-sig'))

publication = read(E / 'CleanPublication01.json')
source = read(P / 'SourceEqualityCleanRebuild01.json')
structure = read(P / 'NativeCleanRebuild03/Main/CleanStructure.json')
assert source['Passed'] and source['SourceComponents'] == 175 and source['ExportComponents'] == 181
assert all(item['Equal'] for item in source['DocumentSourceMatches'])
target = ROOT / 'workbook/output/RC_Section_NDM.xlsm'
assert sha(target) == publication['WorkbookSHA256']
with ZipFile(target) as z:
    assert z.testzip() is None
    parts = len(z.namelist())
review = {
    'Status': 'CLEAN_REBUILD_PUBLISHED_AWAITING_USER_VISUAL_TEST',
    'AtUTC': datetime.now(timezone.utc).isoformat(),
    'Publication': publication,
    'SourceEquality': {'Passed': True, 'SourceComponents': 175, 'DocumentComponents': 6,
                       'ExportSHA256': source['ExportSHA256']},
    'SavedPackageZIPIntegrityPassed': True, 'ZIPParts': parts,
    'CleanStructure': structure,
    'UserFeedbackOnEarlierTransparentPublication': {
        'NoLargeDelays': True, 'ContourEdgesLookSoft': True,
        'Quote': 'задержек больших нет, только при режиме Contour все элементы какие-то размытые',
    },
    'CurrentStyle': {
        'OneCommonFormatter': True, 'ConcreteLineWeightPt': 0.15,
        'SingleLoopIncludingRectanglesAndCurves': 'Visible=True; Transparency=0; line color equals fill color',
        'MultipleLoops': 'Visible=True; Transparency=1 to hide doubled freeform bridges',
        'GeometryAndSolverChanged': False,
    },
    'CurrentFinalPackageManualTest': 'Pending user review',
    'CurrentFinalPackageCalculationsOrBehaviorTestsRun': False,
    'PreviousVariantOnlyDirectedChecks': {'Passed': 418, 'Failed': 0},
    'FullSuiteRun': False, 'FullPASS': False,
}
(E / 'CleanAcceptance01.json').write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding='utf-8')
(E / 'CleanSourceEquality01.json').write_bytes((P / 'SourceEqualityCleanRebuild01.json').read_bytes())

report = ROOT / 'docs/reports/ButtonUiLatency_2026-10-28.md'
body = report.read_text('utf-8-sig')
body = body.replace('PENDING_CLEAN_WORKBOOK_SHA256', publication['WorkbookSHA256'])
body = body.replace('PENDING_CLEAN_ALLCODE_SHA256', publication['AllCodeSHA256'])
report.write_text(body, encoding='utf-8')
progress = ROOT / 'docs/geometry_refactor/PROGRESS.md'
body = progress.read_text('utf-8-sig')
begin = body.index('## 28.10.2026 — Contour:')
end = body.index('\n## ', begin + 4)
entry = f'''## 28.10.2026 — Contour: устранение задержек и чистая сборка для ручной проверки

Ручные сравнения на листе «Расчет» локализовали паузы в Line.Visible=False бетонных фигур. File и удаление единственной сложной фигуры не помогли; включение линий прямоугольников убрало паузы. Пользователь подтвердил отсутствие больших задержек в опубликованном варианте с прозрачными линиями, но заметил мягкие края Contour. Теперь общий форматтер задаёт прямоугольникам, закруглённым и вогнутым одноконтурным фигурам тонкую линию 0,15 pt в цвет заливки, как Adaptive. Только несколько контуров одной фигуры сохраняют прозрачность, чтобы не показать служебные перемычки через отверстия. Решатель, геометрия, хеши и CAD не менялись; сборочный исходник синхронизирован.

По прямому указанию пользователя основная книга полностью собрана заново из Workbooks.Add без переноса его данных, нагрузок, Results и схемы. Книга {publication['WorkbookSHA256'][:12]}…, AllCode {publication['AllCodeSHA256'][:12]}…; VBE 578 и нативная read-only сверка 175+6 компонентов прошли, прежняя основная книга сохранена резервно, тяжёлая _ok побайтно не изменена. Собственные сборочный и проверочный Excel вышли нормально без kill. По просьбе пользователя расчётные/поведенческие тесты этой сборки отложены до его ручной проверки. Ранее завершённые 418/0 относятся к предыдущему варианту прозрачных линий. Нового полного набора и общего PASS нет; main не менялась. Отчёт: [ButtonUiLatency_2026-10-28.md](../reports/ButtonUiLatency_2026-10-28.md).
'''
progress.write_text(body[:begin] + entry + body[end:], encoding='utf-8')

files = []
for name in ['Build.json', 'BuildOwnership.json', 'MemoryBefore.json', 'Closure.json']:
    files.append((E / 'CleanRebuild01' / name, 'build/' + name))
for file in (P / 'NativeCleanRebuild03').rglob('*'):
    if file.is_file() and file.suffix in ('.txt', '.json'):
        files.append((file, 'native/' + str(file.relative_to(P / 'NativeCleanRebuild03')).replace('\\', '/')))
for name in ['NativeCleanRebuild03Ownership.json', 'NativeCleanRebuild03Closure.json', 'SourceEqualityCleanRebuild01.json']:
    files.append((P / name, 'native/' + name))
for name in ['NativeCleanRebuild01Closure.json', 'NativeCleanRebuild02Failure.json', 'NativeCleanRebuild02Closure.json']:
    files.append((P / name, 'preparation/' + name))
files.append((E / 'ReadOnlyPreparationAudit01.json', 'preparation/ReadOnlyPreparationAudit01.json'))
for name in ['CleanRebuildBefore.json', 'CleanPublication01.json', 'CleanAcceptance01.json']:
    files.append((E / name, 'proofs/' + name))
for name in ['TestCleanRebuild01.ps1', 'TestNativeCleanRebuild03.ps1', 'TestPublishCleanRebuild01.py', 'TestFinalizeCleanRebuild01.py']:
    files.append((E / name, 'scripts/' + name))
archive = E / 'CleanRebuildReviewedEvidence01.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED) as z:
    for file, name in files:
        z.write(file, name)
manifest = read(E / 'Processed.json')
manifest['FinalPublication'] = publication
manifest['CleanRebuildArchive'] = {'Path': archive.name, 'Files': len(files), 'SHA256': sha(archive), 'Bytes': archive.stat().st_size}
manifest['Earlier418ChecksApplyToEarlierVariantOnly'] = True
manifest['CurrentManualTestPending'] = True
(E / 'Processed.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'Status': review['Status'], 'WorkbookSHA256': publication['WorkbookSHA256'],
                  'AllCodeSHA256': publication['AllCodeSHA256'], 'ArchiveFiles': len(files)}, ensure_ascii=True))
