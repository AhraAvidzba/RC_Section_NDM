"""ДЛЯ ТЕСТОВ: публикует чистую полную сборку для первоочередной ручной проверки пользователя."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[3]
E = Path(__file__).resolve().parent
P = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ButtonUiLatency_2026-10-28_Run01')

def sha(path):
    """Вычисляет подпись без открытия книги приложением Excel."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def read(path):
    """Читает собственное первичное доказательство в исходной кодировке."""
    return json.loads(path.read_text('utf-8-sig'))

before = read(E / 'CleanRebuildBefore.json')
build = read(E / 'CleanRebuild01/Build.json')
assert build['Status'] == 'CLEAN_BUILD_COMPILED' and build['CompileCommand'] == 578
assert read(E / 'CleanRebuild01/Closure.json')['ExactIdentityAbsent']
assert read(P / 'SourceEqualityCleanRebuild01.json')['Passed']
closure = read(P / 'NativeCleanRebuild03Closure.json')
assert closure['Absent'] and not closure['ForceKilled']
structure = read(P / 'NativeCleanRebuild03/Main/CleanStructure.json')
assert not structure['UserLoadsCopied'] and not structure['PreviousPlotCopied']
assert not structure['CalculationsOrBehaviorTestsRun']
target = ROOT / 'workbook/output/RC_Section_NDM.xlsm'
candidate = E / 'CleanRebuild01/RC_Section_NDM.xlsm'
assert sha(target) == before['RootSHA256'], 'Main workbook changed after user closed it'
assert sha(candidate) == build['BookSHA256']
assert sha(ROOT / 'src/Excel/CSectionPlotter.cls') == build['PlotterSHA256'] == before['PlotterSHA256']
assert not list(target.parent.glob('~$*')), 'Main workbook must be closed'
for book in before['HeavyBooks']:
    assert sha(Path(book['Path'])) == book['SHA256'], 'User heavy workbook changed; leave it alone'
backup = P / 'CleanRebuild01Backup'
assert not backup.exists()
backup.mkdir()
(backup / target.name).write_bytes(target.read_bytes())
allcode = target.parent / 'VBA_All_Code.txt'
(backup / allcode.name).write_bytes(allcode.read_bytes())
temporary = target.with_name(target.name + '.codex-new')
assert not temporary.exists()
temporary.write_bytes(candidate.read_bytes())
assert sha(target) == before['RootSHA256']
os.replace(temporary, target)
allcode.write_bytes((P / 'NativeCleanRebuild03/Main/VBA_All_Code.txt').read_bytes())
assert sha(target) == build['BookSHA256']
for book in before['HeavyBooks']:
    assert sha(Path(book['Path'])) == book['SHA256']
result = {
    'Status': 'CLEAN_REBUILD_PUBLISHED_AWAITING_USER_VISUAL_TEST',
    'AtUTC': datetime.now(timezone.utc).isoformat(),
    'WorkbookSHA256': sha(target), 'AllCodeSHA256': sha(allcode),
    'CreatedFrom': 'Excel.Workbooks.Add through tools/build_workbook/Build-Workbook.ps1',
    'UserDataCopied': False, 'Backup': str(backup),
    'SourceComponents': 175, 'DocumentComponents': 6,
    'NativeSourceEqualityPassed': True, 'VBECompileCommand': 578,
    'HeavyBooksUnchanged': before['HeavyBooks'],
    'FurtherCalculationsOrBehaviorTestsDeferredByUser': True,
    'Earlier418ChecksApplyTo': 'Earlier all-transparent-line variant, not final thin-line styling',
    'FullSuite': False,
}
(E / 'CleanPublication01.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=True))
