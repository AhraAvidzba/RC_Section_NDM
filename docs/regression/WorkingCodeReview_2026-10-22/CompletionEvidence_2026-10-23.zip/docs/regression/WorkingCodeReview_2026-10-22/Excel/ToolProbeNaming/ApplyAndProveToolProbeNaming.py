"""INACTIVE. Explicit reviewed plan only; no Excel/COM, VBA import, book edits or native execution.

Root may activate a fresh .py copy only after explicit GO and terminal Run02.
--verify-only writes only fresh evidence. --apply performs exact approved tools edits with durable backups.
"""
import argparse,ast,hashlib,json,os,re,subprocess,tempfile
from pathlib import Path
from datetime import datetime,timezone

def digest(data):return hashlib.sha256(data).hexdigest().upper()
def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def contained(root,path):
 path=path.resolve()
 if not path.is_relative_to(root):raise RuntimeError('Path escapes workspace: '+str(path))
 return path
def verify_guard(root,plan):
 guard=plan['Run02Guard'];run=load(root/guard['Run']);launch=load(root/guard['Launch'])
 if int(launch['PID'])!=guard['PID']or int(launch['ProcessStartTicks'])!=guard['StartTicks']:raise RuntimeError('Launch PID/startTicks differs from approved guard')
 if run['Status']not in['REVIEW_REQUIRED','COMPLETED_PENDING_LOG_REVIEW','DEADLINE_REACHED']:raise RuntimeError('Full Run02 has no recognized terminal status')
 if not run.get('FinishedUTC'):raise RuntimeError('FinishedUTC is mandatory')
 start=datetime.fromisoformat(run['StartedUTC'].replace('Z','+00:00'));end=datetime.fromisoformat(run['FinishedUTC'].replace('Z','+00:00'))
 if end<start or end>datetime.now(timezone.utc):raise RuntimeError('Inconsistent finish time')
 if run['SourceSHA256']!=launch['SourceSHA256']or run['SourceCommit']!=launch['SourceCommit']:raise RuntimeError('Run/Launch source identity mismatch')
 ps=Path(os.environ.get('SystemRoot','C:/Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
 command="try {$d=Get-Process -Id "+str(guard['PID'])+" -ErrorAction Stop; [Console]::Write($d.StartTime.ToUniversalTime().Ticks); exit 0} catch {if($_.FullyQualifiedErrorId -like 'NoProcessFoundForGivenId*'){exit 0};throw}"
 actual=subprocess.check_output([str(ps),'-NoProfile','-NonInteractive','-Command',command],text=True).strip()
 if actual and int(actual)==guard['StartTicks']:raise RuntimeError('Exact full-run driver remains alive')
 return dict(Status=run['Status'],FinishedUTC=run['FinishedUTC'],PID=guard['PID'],StartTicks=guard['StartTicks'],ExactDriverAlive=False)
def verify_protected(root,plan):
 result=[]
 for item in plan['ProtectedInputs']:
  p=contained(root,root/item['Path']);actual=digest(p.read_bytes())
  if actual!=item['SHA256']:raise RuntimeError('Protected artifact differs from plan: '+item['Path'])
  result.append(dict(Path=item['Path'],SHA256=actual))
 return result
def comment_only(text):return all(not line.strip()or line.lstrip().startswith("'")for line in text.splitlines())
def construct(root,item,mapping):
 p=contained(root,root/item['Path'])
 if not item['Path'].startswith('tools/build_workbook/'):raise RuntimeError('Only reviewed tools files may change')
 raw=p.read_bytes()
 if digest(raw)!=item['BeforeSHA256']:raise RuntimeError('Reviewed before SHA differs: '+item['Path'])
 before=raw.decode('utf-8-sig');parts=[];end=0;offset=0
 for edit in item['Edits']:
  a=edit['Start'];b=edit['End'];old=edit['Before'];new=edit['After'];kind=edit['Kind']
  if a<end or before[a:b]!=old:raise RuntimeError('Overlapping/stale position edit: '+item['Path'])
  if kind in['VbaHeader','VbaModuleHeader','VbaModuleAndMethodHeader']:
   if not comment_only(old)or not comment_only(new):raise RuntimeError('Header edit contains executable VBA')
  elif kind in['VbaIdentifier','ExternalReference']:
   if mapping.get(old.lower())!=new:raise RuntimeError('Identifier edit is outside approved map')
   if kind=='VbaIdentifier':
    qualifier=re.search(r'([A-Za-z_][A-Za-z_0-9]*)\s*\.\s*$',before[max(0,a-80):a])
    if qualifier and qualifier.group(1).lower()not in['modplateauslopeprobe','modtestbatchcalculation','modtestsectionrecipes','oldreport','newreport']:raise RuntimeError('Foreign dotted API cannot be renamed')
   if old.lower()=='number':
    prefix=before[max(0,a-60):a]
    if re.search(r'\bErr\s*\.\s*$',prefix,re.I):raise RuntimeError('Err.Number cannot be renamed')
    if not item['Path'].endswith('PlateauSlopeProbe.bas')and not re.search(r'\bmodPlateauSlopeProbe\s*\.\s*$',prefix):raise RuntimeError('Number rename escaped its own module')
  elif kind=='ModuleName':
   if old!='"modPlateauSlopeProbe"'or new!='"modTestPlateauSlopeProbe"':raise RuntimeError('Unexpected attribute rename')
  elif kind=='GeneratedVbaHeader':
   if item['Path']!='tools/build_workbook/Compare-FocusedReportFormatting.ps1'or old not in new.replace('"\' ==========================================================================`r`n\' ДЛЯ ТЕСТОВ — исходный formatter для независимого сравнения.`r`n\' ==========================================================================`r`n"+',''):raise RuntimeError('Unexpected generated-header edit')
  elif kind=='OfflineMacroCompatibility':
   if item['Path']!='tools/build_workbook/Verify-FocusedAcceptance.py':raise RuntimeError('Offline compatibility escaped its reviewed verifier')
  else:raise RuntimeError('Unknown edit kind: '+kind)
  if edit['AfterStart']!=a+offset or edit['AfterEnd']!=a+offset+len(new):raise RuntimeError('Invalid inverse offsets')
  parts.extend([before[end:a],new]);end=b;offset+=len(new)-(b-a)
 parts.append(before[end:]);after=''.join(parts);inverse=after
 for edit in reversed(item['Edits']):
  a=edit['AfterStart'];b=edit['AfterEnd']
  if inverse[a:b]!=edit['After']:raise RuntimeError('Inverse edit mismatch')
  inverse=inverse[:a]+edit['Before']+inverse[b:]
 if inverse!=before:raise RuntimeError('Strict full-text inverse equivalence failed')
 strip=lambda t:re.sub(r"(?m)^[ \t]*'[^\r\n]*",'',t)
 if len(re.findall(r'\bErr\.Number\b',strip(before),re.I))!=len(re.findall(r'\bErr\.Number\b',strip(after),re.I)):raise RuntimeError('Err.Number occurrences changed')
 if re.search(r'\bErr\.Test\w*Number\b',after,re.I):raise RuntimeError('Invalid external Err API')
 data=(b'\xef\xbb\xbf'if item['UTF8BOM']else b'')+after.encode('utf-8')
 if digest(data)!=item['AfterSHA256']:raise RuntimeError('Constructed after SHA differs from reviewed plan')
 if p.suffix=='.py':
  tree=ast.parse(after,filename=item['Path'])
  if p.name=='Verify-FocusedAcceptance.py':
   expected={'FOCUSED_CASE_MACROS':{'modTestBatchCalculation.RunFocusedAcceptanceCases','modTestBatchCalculation.TestRunFocusedAcceptanceCases'},'FOCUSED_BOUNDS_MACROS':{'modTestBatchCalculation.DumpFocusedForceBoundsExact','modTestBatchCalculation.TestDumpFocusedForceBoundsExact'}}
   actual={}
   for node in tree.body:
    if isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)and node.targets[0].id in expected:
     if not isinstance(node.value,ast.Call)or not isinstance(node.value.func,ast.Name)or node.value.func.id!='frozenset'or len(node.value.args)!=1:raise RuntimeError('Unexpected compatibility set expression')
     actual[node.targets[0].id]=ast.literal_eval(node.value.args[0])
   if actual!=expected:raise RuntimeError('Offline verifier aliases must be exactly two historical/two current qualified macros')
 return p,raw,data,after
def method_body(text,name):
 start=re.search(r'(?m)^[ \t]*(?:Public|Private|Friend)\s+(Sub|Function|Property\s+(?:Get|Let|Set))\s+'+re.escape(name)+r'\b',text,re.I)
 if not start:raise RuntimeError('Method declaration missing: '+name)
 kind='Property'if start.group(1).lower().startswith('property')else start.group(1)
 end=re.search(r'(?m)^[ \t]*End '+kind+r'\b',text[start.end():],re.I)
 if not end:raise RuntimeError('Method end missing: '+name)
 return text[start.start():start.end()+end.end()]
def code_tokens(text,inverse=None):
 result=[]
 pattern=re.compile(r'"(?:""|[^"\r\n])*"|\x27[^\r\n]*|[A-Za-z_][A-Za-z_0-9]*|[^\s]')
 for match in pattern.finditer(text):
  word=match.group()
  if word.startswith("'"):continue
  if re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',word):word=(inverse or{}).get(word.lower(),word.lower())
  result.append(word)
 return result
def verify_method_bodies(plan,candidates):
 before={item['Path']:old.decode('utf-8-sig')for item,path,old,new,text in candidates}
 after={item['Path']:text for item,path,old,new,text in candidates}
 inverse={v.lower():k.lower()for k,v in(plan['MethodRenameMap']|plan['ModuleRenameMap']).items()};result=[]
 for method in plan['Methods']:
  old=method['Name'];new=plan['MethodRenameMap'].get(old,old)
  left=code_tokens(method_body(before[method['Path']],old));right=code_tokens(method_body(after[method['Path']],new),inverse)
  if left!=right:raise RuntimeError('Original executable body changed: '+method['Path']+' '+old)
  result.append(dict(Path=method['Path'],Old=old,New=new,OriginalBodyTokensEqualAfterInverseRenames=True))
 return result
def atomic_write(path,data):
 handle,tmp=tempfile.mkstemp(prefix=path.name+'.rename-',suffix='.tmp',dir=path.parent)
 try:
  with os.fdopen(handle,'wb')as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.replace(tmp,path)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--workspace',required=True);parser.add_argument('--plan',required=True);parser.add_argument('--expected-plan-sha',required=True);parser.add_argument('--label',required=True)
 mode=parser.add_mutually_exclusive_group(required=True);mode.add_argument('--verify-only',action='store_true');mode.add_argument('--apply',action='store_true');args=parser.parse_args()
 root=Path(args.workspace).resolve();p=contained(root,root/args.plan);planbytes=p.read_bytes()
 if digest(planbytes)!=args.expected_plan_sha.upper():raise RuntimeError('Plan SHA differs from explicit reviewed SHA')
 plan=json.loads(planbytes.decode('utf-8-sig'))
 if plan['Schema']!='NDM.ToolProbeNamingPlan/1':raise RuntimeError('Unexpected plan schema')
 if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,60}',args.label):raise RuntimeError('Fresh safe label required')
 guard=verify_guard(root,plan);protected=verify_protected(root,plan)
 directory=contained(root,root/'docs/regression/WorkingCodeReview_2026-10-22/Excel/ToolProbeNaming'/args.label)
 if directory.exists():raise RuntimeError('Evidence label already exists; never overwrite evidence')
 mapping={k.lower():v for k,v in(plan['MethodRenameMap']|plan['ModuleRenameMap']).items()};candidates=[]
 for item in plan['Files']:candidates.append((item,*construct(root,item,mapping)))
 directory.mkdir();beforeDir=directory/'Before';afterDir=directory/'After';beforeDir.mkdir();afterDir.mkdir()
 methodproof=verify_method_bodies(plan,candidates)
 report=dict(Status='VERIFIED_IN_MEMORY_PENDING_NATIVE',PlanSHA256=digest(planbytes),NativeExecuted=False,Guard=guard,ProtectedInputs=protected,Summary=plan['Summary'],OriginalMethodBodyEquivalence=methodproof,Files=[],Applied=False,NoOverallAcceptanceClaimed=True)
 committed=[]
 try:
  for item,path,before,after,text in candidates:
   for folder,data in[(beforeDir,before),(afterDir,after)]:
    target=folder/item['Path'];target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb')as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
   report['Files'].append(dict(Path=item['Path'],BeforeSHA256=digest(before),AfterSHA256=digest(after),StrictFullTextAfterInverse=True,Edits=len(item['Edits'])))
  # Parse only. Staged .ps1 files are never invoked and no Excel is created.
  ps=Path(os.environ.get('SystemRoot','C:/Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
  parseScript=directory/'ParseOnly.ps1'
  parseScript.write_text("$ErrorActionPreference='Stop'\n$fail=@(); Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'After') -Filter '*.ps1' -Recurse | ForEach-Object {$tok=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$tok,[ref]$errors);foreach($e in $errors){$fail+=($_.FullName+': '+$e.Message)}};if($fail.Count){$fail|Write-Output;exit 1};Write-Output 'POWERSHELL_PARSE_ONLY_PASS'\n",encoding='utf-8-sig')
  result=subprocess.run([str(ps),'-NoProfile','-NonInteractive','-File',str(parseScript)],capture_output=True,text=True)
  report['PowerShellParser']=dict(ExitCode=result.returncode,Stdout=result.stdout,Stderr=result.stderr)
  if result.returncode:raise RuntimeError('Proposed PowerShell5.1 parser failed')
  if args.apply:
   verify_guard(root,plan);verify_protected(root,plan)
   for item,path,before,after,text in candidates:
    if digest(path.read_bytes())!=digest(before):raise RuntimeError('Concurrent tools change before apply')
   for item,path,before,after,text in candidates:
    verify_guard(root,plan)
    atomic_write(path,after);committed.append((item,path,before,after))
   verify_protected(root,plan);report['Applied']=True;report['Status']='APPLIED_PENDING_NATIVE_COMPILE_AND_AFFECTED_FOCUSED_VALIDATION'
  report['ProtectedInputsAfter']=verify_protected(root,plan)
 except BaseException as error:
  report['Status']='FAILED';report['Error']=repr(error);report['Rollback']=[]
  for item,path,before,after in reversed(committed):
   if digest(path.read_bytes())==digest(after):atomic_write(path,before);report['Rollback'].append(dict(Path=item['Path'],Restored=True))
   else:report['Rollback'].append(dict(Path=item['Path'],Restored=False,Reason='Foreign concurrent change; preserve it'))
  raise
 finally:
  (directory/'Proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(dict(Status=report['Status'],Report=str(directory/'Proof.json'),Files=len(candidates),NativeExecuted=False)))
if __name__=='__main__':main()
