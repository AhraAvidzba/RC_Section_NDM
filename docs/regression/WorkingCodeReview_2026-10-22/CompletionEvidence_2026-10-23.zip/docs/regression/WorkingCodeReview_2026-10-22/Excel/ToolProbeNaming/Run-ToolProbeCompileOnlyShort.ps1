﻿# НЕАКТИВНЫЙ текст: root активирует отдельную .ps1-копию только после текущего focused.
# ДЛЯ ТЕСТОВ: компиляция 23 естественных контекстов без вызова VBA/НДС/AutoCAD.
param(
    [Parameter(Mandatory=$true)][string]$SourceWorkbook,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{64}$')][string]$ExpectedSourceSHA256,
    [Parameter(Mandatory=$true)][string]$ManifestPath,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{64}$')][string]$ExpectedManifestSHA256,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9_-]+$')][string]$Label,
    [string]$ProjectRoot=(Get-Location).Path,
    [ValidateRange(20,180)][int]$CaseTimeoutSeconds=90,
    [switch]$InternalWorker,
    [string]$CaseId=''
)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath $ProjectRoot).Path
$workspace=$root.TrimEnd('\')+'\'
function Resolve-WorkspaceFile([string]$Path){
    if(-not [IO.Path]::IsPathRooted($Path)){$Path=Join-Path $root $Path}
    $resolved=(Resolve-Path -LiteralPath $Path).Path
    if(-not $resolved.StartsWith($workspace,[StringComparison]::OrdinalIgnoreCase)){throw 'Путь выходит из рабочей папки.'}
    return $resolved
}
function Test-ProcessIdentity([int]$ProcessId,[long]$StartTicks,[string]$Name){
    if($ProcessId -le 0 -or $StartTicks -le 0){return $false}
    $current=Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    return ($null -ne $current -and $current.ProcessName -eq $Name -and $current.StartTime.ToUniversalTime().Ticks -eq $StartTicks)
}
function Quote-Argument([string]$Value){
    if($Value.Contains('"')){throw 'Кавычка в аргументе не поддерживается.'}
    return '"'+$Value+'"'
}
$source=Resolve-WorkspaceFile $SourceWorkbook
$manifestFile=Resolve-WorkspaceFile $ManifestPath
$sourceHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$manifestHash=(Get-FileHash -LiteralPath $manifestFile -Algorithm SHA256).Hash
if($sourceHash -cne $ExpectedSourceSHA256.ToUpperInvariant()){throw 'Не совпал SHA256 явно указанной исходной книги.'}
if($manifestHash -cne $ExpectedManifestSHA256.ToUpperInvariant()){throw 'Не совпал SHA256 compile-only manifest.'}
$manifest=Get-Content -LiteralPath $manifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
if($manifest.CaseCount -ne 23 -or @($manifest.Cases).Count -ne 23 -or $manifest.BasFiles -ne 13 -or $manifest.EmbeddedScripts -ne 10){throw 'Неожиданный состав compile-only manifest.'}
foreach($item in $manifest.Cases){
    $current=Resolve-WorkspaceFile ([string]$item.Source)
    if((Get-FileHash -LiteralPath $current -Algorithm SHA256).Hash -cne [string]$item.SourceSHA256){throw ('Изменился tool source: '+$item.Source)}
    foreach($action in $item.Actions){
        if($action.Body){$bodyPath=Resolve-WorkspaceFile ([string]$action.Body);if((Get-FileHash -LiteralPath $bodyPath -Algorithm SHA256).Hash -cne [string]$action.BodySHA256){throw ('Изменился compile-only overlay: '+$action.Body)}}
    }
}
$protected=@{}
foreach($relative in @('workbook/output/RC_Section_NDM.xlsm','workbook/output/VBA_All_Code.txt','workbook/output/RC_Section_NDM_execution_report.txt')){
    $path=Join-Path $root $relative
    if(Test-Path -LiteralPath $path){$protected[$path]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
}
$output=Join-Path (Split-Path -Parent $manifestFile) ('Native_'+$Label)
if(-not $InternalWorker){
    if(Test-Path -LiteralPath $output){throw 'Нужен новый Label: старое доказательство не перезаписывается.'}
    New-Item -ItemType Directory -Path $output | Out-Null
    $records=@()
    foreach($item in $manifest.Cases){
        $directory=Join-Path $output $item.Id
        $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Quote-Argument $PSCommandPath),'-SourceWorkbook',(Quote-Argument $source),'-ExpectedSourceSHA256',$sourceHash,'-ManifestPath',(Quote-Argument $manifestFile),'-ExpectedManifestSHA256',$manifestHash,'-Label',$Label,'-ProjectRoot',(Quote-Argument $root),'-CaseTimeoutSeconds',[string]$CaseTimeoutSeconds,'-InternalWorker','-CaseId',$item.Id) -join ' '
        $process=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -WorkingDirectory $root -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $output ($item.Id+'.stdout.log')) -RedirectStandardError (Join-Path $output ($item.Id+'.stderr.log'))
        $null=$process.Handle
        $workerTicks=$process.StartTime.ToUniversalTime().Ticks
        $timedOut=-not $process.WaitForExit($CaseTimeoutSeconds*1000)
        if($timedOut){
            if(Test-ProcessIdentity $process.Id $workerTicks 'powershell'){Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue}
            $identityPath=Join-Path $directory 'OwnExcel.json'
            if(Test-Path -LiteralPath $identityPath){
                $identity=Get-Content -LiteralPath $identityPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if(Test-ProcessIdentity ([int]$identity.PID) ([long]$identity.StartTicks) 'EXCEL'){Stop-Process -Id ([int]$identity.PID) -Force -ErrorAction SilentlyContinue}
            }
            [void]$process.WaitForExit(5000);$process.Refresh()
        }else{$process.WaitForExit();$process.Refresh()}
        $resultPath=Join-Path $directory 'Result.json'
        $result=$null
        if(Test-Path -LiteralPath $resultPath){$result=Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8 | ConvertFrom-Json}
        $exitCode=$null;if($process.HasExited){$exitCode=$process.ExitCode}
        $passed=(-not $timedOut -and $exitCode -eq 0 -and $null -ne $result -and $result.Compiled -and $result.SourceUnchanged -and $result.ProtectedUnchanged -and -not $result.VbaEntrypointExecuted)
        $records+=@{Case=$item.Id;Source=$item.Source;Passed=$passed;TimedOut=$timedOut;ExitCode=$exitCode;Result=$resultPath}
        [ordered]@{SourceSHA256=$sourceHash;ManifestSHA256=$manifestHash;Cases=$records;AllCompiled=($records.Count -eq 23 -and @($records | Where-Object {-not $_.Passed}).Count -eq 0);NoVbaEntrypointExecuted=$true;NoRuntimeAcceptanceClaimed=$true} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $output 'Progress.json') -Encoding UTF8
        Write-Output ('COMPILE_CONTEXT: '+$item.Id+'; passed='+$passed+'; timeout='+$timedOut)
    }
    if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -cne $sourceHash){throw 'Исходная книга изменилась.'}
    foreach($path in $protected.Keys){if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -cne $protected[$path]){throw ('Защищённый файл изменился: '+$path)}}
    if(@($records | Where-Object {-not $_.Passed}).Count){throw 'Не все compile-only контексты прошли; см. Progress.json.'}
    Write-Output 'ALL_23_TOOL_CONTEXTS_COMPILED_NO_MACROS_EXECUTED'
    exit 0
}

$selected=@($manifest.Cases | Where-Object {$_.Id -ceq $CaseId})
if($selected.Count -ne 1 -or $CaseId -notmatch '^[A-Za-z0-9_-]+$'){throw 'Неизвестный compile-only контекст.'}
$item=$selected[0]
if(-not (Test-Path -LiteralPath $output)){throw 'Родительский fresh-output каталог не создан.'}
$directory=Join-Path $output $CaseId
if(Test-Path -LiteralPath $directory){throw 'Private case уже существует.'}
New-Item -ItemType Directory -Path $directory | Out-Null
$privateRoot=Join-Path $root ('docs/regression/_ToolCompile_'+$Label)
if(-not ([IO.Path]::GetFullPath($privateRoot)).StartsWith($workspace,[StringComparison]::OrdinalIgnoreCase)){throw 'Private compile path leaves workspace.'}
[void][IO.Directory]::CreateDirectory($privateRoot)
$private=Join-Path $privateRoot ($CaseId+'.xlsm') # Короткий собственный путь книги; длинные имена контекстов остаются в evidence, а не в пути Excel.
if(Test-Path -LiteralPath $private){throw 'Private compile workbook already exists.'}
Copy-Item -LiteralPath $source -Destination $private
if((Get-FileHash -LiteralPath $private -Algorithm SHA256).Hash -cne $sourceHash){throw 'Не совпала исходная частная копия.'}
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0;$compiled=$false;$failure='';$modules=@()
try{
    Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class ToolCompileWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
    $preexisting=@([Diagnostics.Process]::GetProcessesByName('EXCEL') | ForEach-Object {$_.Id})
    $excel=New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][ToolCompileWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    if($id -eq 0 -or $preexisting -contains [int]$id){throw 'Существующий или неопределённый Excel: свойства не изменяются, Quit запрещён.'}
    $newProcess=Get-Process -Id $id -ErrorAction Stop
    $ticks=$newProcess.StartTime.ToUniversalTime().Ticks
    if(-not (Test-ProcessIdentity ([int]$id) $ticks 'EXCEL')){throw 'Не подтверждена новая Excel identity.'}
    $ownedPid=[int]$id;$ownedTicks=$ticks
    [ordered]@{PID=$ownedPid;StartTicks=$ownedTicks} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $directory 'OwnExcel.json') -Encoding UTF8
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=3
    $book=$excel.Workbooks.Open($private,0,$false)
    if($book.ReadOnly -or [string]$book.FullName -cne $private){throw 'Открыта не своя private-книга.'}
    foreach($action in $item.Actions){
        $body=''
        if($action.Body){$body=[IO.File]::ReadAllText((Resolve-WorkspaceFile ([string]$action.Body)),[Text.Encoding]::UTF8)}
        switch([string]$action.Mode){
            'CloneClass'{
                $original=$book.VBProject.VBComponents.Item([string]$action.CloneFrom).CodeModule
                $component=$book.VBProject.VBComponents.Add(2);$component.Name=[string]$action.Module
                $component.CodeModule.AddFromString($original.Lines(1,$original.CountOfLines))
            }
            'AddStandard'{
                $component=$book.VBProject.VBComponents.Add(1);$component.Name=[string]$action.Module
                $component.CodeModule.AddFromString($body)
            }
            'Append'{$book.VBProject.VBComponents.Item([string]$action.Module).CodeModule.AddFromString($body)}
            'Declarations'{
                $module=$book.VBProject.VBComponents.Item([string]$action.Module).CodeModule
                $original=$module.Lines(1,$module.CountOfLines)
                if([regex]::Matches($original,'(?im)^Option Explicit\s*$').Count -ne 1){throw 'Неоднозначный блок Option Explicit.'}
                $updated=[regex]::Replace($original,'(?im)^Option Explicit\s*$','Option Explicit'+"`r`n"+$body)
                $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($updated)
            }
            default{throw ('Неизвестная операция manifest: '+$action.Mode)}
        }
        $modules+=@{Module=$action.Module;Mode=$action.Mode;BodySHA256=$action.BodySHA256}
    }
    $excel.VBE.ActiveVBProject=$book.VBProject
    $compile=$excel.VBE.CommandBars.FindControl(1,578)
    if($null -eq $compile){throw 'Команда VBE Compile недоступна.'}
    if($compile.Enabled){$compile.Execute()}
    if($compile.Enabled){throw 'VBE Compile не завершился успешно.'}
    $compiled=$true
}catch{$failure=$_.Exception.Message}finally{
    try{if($book -and (Test-ProcessIdentity $ownedPid $ownedTicks 'EXCEL')){$book.Close($false)}}finally{
        try{if($excel){try{if(Test-ProcessIdentity $ownedPid $ownedTicks 'EXCEL'){$excel.Quit()}}finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}}}finally{
            [GC]::Collect();[GC]::WaitForPendingFinalizers()
            if(Test-ProcessIdentity $ownedPid $ownedTicks 'EXCEL'){Stop-Process -Id $ownedPid -Force -ErrorAction SilentlyContinue}
            $sourceUnchanged=((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ceq $sourceHash)
            $protectedUnchanged=$true
            foreach($path in $protected.Keys){if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -cne $protected[$path]){$protectedUnchanged=$false}}
            [ordered]@{Case=$CaseId;SourceSHA256=$sourceHash;ManifestSHA256=$manifestHash;Compiled=$compiled;Failure=$failure;OwnPID=$ownedPid;OwnStartTicks=$ownedTicks;Modules=$modules;VbaEntrypointExecuted=$false;Saved=$false;SourceUnchanged=$sourceUnchanged;ProtectedUnchanged=$protectedUnchanged;HistoricalRuntimeAcceptanceClaimed=$false} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $directory 'Result.json') -Encoding UTF8
        }
    }
}
if(-not $compiled -or $failure -or -not $sourceUnchanged -or -not $protectedUnchanged){throw ('Compile-only case failed: '+$failure)}
