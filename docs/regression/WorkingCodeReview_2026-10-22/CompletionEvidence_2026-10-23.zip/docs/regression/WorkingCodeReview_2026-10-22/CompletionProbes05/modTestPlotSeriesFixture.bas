Attribute VB_Name = "modTestPlotSeriesFixture"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: НЕАКТИВНЫЙ физический fixture для предела Chart series.
' Подключать только после terminal Run02 в доказанной частной книге root-runner.
' Геометрия, нагрузка и НДС создаются публичным API; Results вручную не меняются.
' ==========================================================================
Private Const TEST_SERIES_LC As String = "LC_SERIES_GAP"

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создаёт 272 разных квадрата и 5000 малых плиток; каждый материальный участок имеет достоверный Outer.
' Масштаб берётся из предварительной схемы, но не меняет никакие правила материалов или расчёта.
Public Function TestCreateSeriesGapModel(ByVal pointsPerMm As Double) As CSectionModel
    If pointsPerMm < 2# Or pointsPerMm > 16# Then Err.Raise vbObjectError + 4980, _
        "modTestPlotSeriesFixture", "Нужен фактический масштаб от 2 до 16 pt/mm; измените размер частной диаграммы и повторите preview."
    Dim model As CSectionModel, col As Long, row As Long, side As Double, area As Double, ownI As Double
    Dim x As Double, y As Double, id As String
    Set model = New CSectionModel: model.SourceType = "TestSeriesGapFiber"
    For col = 0 To 16
        For row = 1 To 16
            side = (3# * CDbl(row)) / (0.7 * pointsPerMm) ' Середины размерных групп 3,6,...48 points при переданном масштабе.
            area = side * side: ownI = area * side * side / 12#
            x = 100# * CDbl(col): y = 100# * CDbl(row)
            id = "BUCKET_" & CStr(col) & "_" & CStr(row)
            model.AddConcreteElement x, y, area, sourceName:=id, width:=side, height:=side, _
                localIx:=ownI, localIy:=ownI, localIxy:=0#
            TestSeriesOuterRectangle model, id, x - side / 2#, y - side / 2#, x + side / 2#, y + side / 2#
        Next row
    Next col
    For row = 0 To 49
        For col = 0 To 99
            x = 750.5 + CDbl(col): y = 1700.5 + CDbl(row)
            model.AddConcreteElement x, y, 1#, sourceName:="FILLER", width:=1#, height:=1#, _
                localIx:=1# / 12#, localIy:=1# / 12#, localIxy:=0#
        Next col
    Next row
    TestSeriesOuterRectangle model, "FILLER_RECT", 750#, 1700#, 850#, 1750# ' 5000 плиток точно покрывают один отдельный прямоугольник.
    If model.ConcreteCount <> 5272 Or model.RebarCount <> 0 Or model.Contours.Count <> 1092 Then _
        Err.Raise vbObjectError + 4981, "modTestPlotSeriesFixture", "Не выполнена геометрическая опись fixture."
    Set TestCreateSeriesGapModel = model
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Решает одно обычное StrengthState; вызывающий observer заранее настраивает только частный профиль PR1.
' Нагрузка интегрируется по центрам волокон, как в штатном НДС; собственные инерции остаются истинными для свойств.
Public Function TestSolveSeriesGapFixture(ByVal model As CSectionModel, ByVal settings As CSystemSettingsReader, _
        ByVal units As CUnitSystem, ByRef snapshot As CSectionPropertiesCalculator, _
        Optional ByVal profileId As String = "PR1", Optional ByVal workbook As Object = Nothing) As CBatchSectionCalculator
    Dim book As Object, catalog As CCalculationProfileCatalog, profile As CCalculationProfile
    Dim provider As CMaterialModelProvider, concrete As CMaterialDiagram, batch As CBatchSectionCalculator
    Dim state As CSectionStateResult, n As Double, mx As Double, my As Double, epsMax As Double
    If workbook Is Nothing Then Set book = ThisWorkbook Else Set book = workbook
    If model Is Nothing Or settings Is Nothing Or units Is Nothing Then Err.Raise vbObjectError + 4982, _
        "modTestPlotSeriesFixture", "Передайте модель, фактические настройки и единицы частной книги."
    Set catalog = New CCalculationProfileCatalog: catalog.LoadFromWorkbook book
    Set profile = catalog.ProfileById(profileId)
    If Not profile.StrengthDirectStateEnabled Or profile.StrengthCapacityEnabled Or profile.CrackWidthEnabled Or profile.StabilityEnabled Then _
        Err.Raise vbObjectError + 4983, "modTestPlotSeriesFixture", "Для fixture включите только DirectState; Capacity, Crack.Width и Stability должны быть выключены."
    If profile.VisualizationStateText <> "StrengthState" Or profile.VisualizationQuantityText <> "Stress" Then _
        Err.Raise vbObjectError + 4983, "modTestPlotSeriesFixture", "Выберите для частного профиля StrengthState и Stress."
    Set provider = New CMaterialModelProvider: provider.Initialize settings, units
    Set concrete = provider.ConcreteMaterialFromSpec(profile.StrengthSpec)
    TestSeriesIntegrateLoad model, concrete, n, mx, my, epsMax
    Set batch = New CBatchSectionCalculator
    batch.Initialize model, provider: batch.ApplySettings settings, units
    Set batch.ProfileCatalog = catalog
    batch.AddCombination TEST_SERIES_LC, n, mx, my, profileId, "Допустимое упругое сжатие для адресного Chart fixture."
    batch.ApplyLoadReference 0#, 0# ' Интегрированные M уже относятся к исходному WCS-началу, повторный перенос не нужен.
    If Abs(batch.N(1) - n) > Abs(n) * 0.000000000001 Or Abs(batch.Mx(1) - mx) > Abs(mx) * 0.000000000001 Or _
            Abs(batch.My(1) - my) > Abs(my) * 0.000000000001 Then Err.Raise vbObjectError + 4984, _
        "modTestPlotSeriesFixture", "Фильтр/настройки нагрузки изменили интегрированные N/M; настройте отдельный case без такого изменения."
    batch.Execute
    Set state = batch.ResultAt(1).StateRepository.FindState(sstStrengthState)
    If state Is Nothing Then Err.Raise vbObjectError + 4985, "modTestPlotSeriesFixture", "Пакет не создал StrengthState."
    If Not state.Converged Or Not state.WithinPhysicalRange Or state.ExtensionUsed Then Err.Raise vbObjectError + 4985, _
        "modTestPlotSeriesFixture", "Требуется равновесное физическое НДС без extension: " & state.StopReason
    If Abs(state.Epsilon0 + epsMax / 64#) > epsMax * 0.000001 Or Abs(state.KappaX) > epsMax / 1750# * 0.000001 Or _
            Abs(state.KappaY + (63# / 64#) * epsMax / 1600#) > epsMax / 1600# * 0.000001 Then _
        Err.Raise vbObjectError + 4985, "modTestPlotSeriesFixture", "Найденное поле отличается от независимого упругого fixture."
    TestSeriesVerifyRealSnapshot model, state
    Set snapshot = PrepareSectionSnapshot(model, provider)
    Set TestSolveSeriesGapFixture = batch
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Независимо суммирует реальные напряжения допустимого поля; первая линейная ветвь проверяется по всем центрам и углам.
Private Sub TestSeriesIntegrateLoad(ByVal model As CSectionModel, ByVal concrete As CMaterialDiagram, _
        ByRef n As Double, ByRef mx As Double, ByRef my As Double, ByRef epsMax As Double)
    Dim i As Long, nearest As Double, value As Double, slope As Double, eps As Double, stress As Double
    Dim width As Double, height As Double, rotation As Double, force As Double, corner As Long, cornerEps As Double
    nearest = 1#
    For i = 1 To concrete.PointCount
        value = concrete.PointStrain(i)
        If value < 0# And Abs(value) < nearest Then nearest = Abs(value)
    Next i
    epsMax = nearest / 4#: If epsMax > 0.0001 Then epsMax = 0.0001
    If epsMax <= 0# Or concrete.GetStress(0#) <> 0# Then Err.Raise vbObjectError + 4986, _
        "modTestPlotSeriesFixture", "У материала нет пригодной линейной сжатой ветви от нуля."
    slope = concrete.GetTangentModulus(-epsMax / 2#)
    If slope <= 0# Then Err.Raise vbObjectError + 4986, "modTestPlotSeriesFixture", "Требуется положительная начальная упругая жесткость."
    n = 0#: mx = 0#: my = 0#
    For i = 1 To model.ConcreteCount
        eps = -epsMax / 64# - (63# / 64#) * epsMax * model.ConcreteX(i) / 1600#
        stress = concrete.GetStress(eps)
        If stress >= -0.000000001 Or Not concrete.IsInPhysicalRange(eps) Or _
                Abs(stress - slope * eps) > Abs(stress) * 0.0000000001 Then Err.Raise vbObjectError + 4986, _
            "modTestPlotSeriesFixture", "Волокно не находится на одной действительной упругой ветви сжатия."
        model.ConcreteBoundaryRectangle i, width, height, rotation
        For corner = -1 To 1 Step 2
            cornerEps = -epsMax / 64# - (63# / 64#) * epsMax * (model.ConcreteX(i) + CDbl(corner) * width / 2#) / 1600#
            If cornerEps >= 0# Or Not concrete.IsInPhysicalRange(cornerEps) Then Err.Raise vbObjectError + 4986, _
                "modTestPlotSeriesFixture", "Угол бетонного квадрата выходит из физического сжатого диапазона."
        Next corner
        force = stress * model.ConcreteArea(i)
        n = n + force: mx = mx + force * model.ConcreteY(i): my = my + force * model.ConcreteX(i)
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет настоящий snapshot НДС до записи: все5272 элемента сжаты, а первые272 дают17 фактических цветовых ratios.
' Размеры и окончательный RGB/scale observer считает отдельно по реальному reader и Chart, не по выдуманному Results.
Private Sub TestSeriesVerifyRealSnapshot(ByVal model As CSectionModel, ByVal state As CSectionStateResult)
    Dim data As Variant, i As Long, maxAbs As Double, bucket As Long, seen As Object
    data = state.PrepareElementSnapshot(model)
    If Not IsArray(data) Then Err.Raise vbObjectError + 4987, "modTestPlotSeriesFixture", "Отсутствует реальный snapshot элементов."
    For i = 1 To UBound(data, 1)
        If data(i, 2) <> "Concrete" Or data(i, 5) <> "Compression" Then Err.Raise vbObjectError + 4987, _
            "modTestPlotSeriesFixture", "Fixture требует только действительные сжатые бетонные элементы."
        If Abs(CDbl(data(i, 4))) > maxAbs Then maxAbs = Abs(CDbl(data(i, 4)))
    Next i
    Set seen = CreateObject("Scripting.Dictionary")
    For i = 1 To 272
        bucket = CLng(Int(16# * Abs(CDbl(data(i, 4))) / maxAbs + 0.5))
        seen(CStr(bucket)) = True
    Next i
    If UBound(data, 1) <> 5272 Or seen.Count <> 17 Then Err.Raise vbObjectError + 4987, _
        "modTestPlotSeriesFixture", "Реальное НДС не охватило17 цветовых ступеней на272 разных квадратах."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Описывает фактическую границу одного материального прямоугольника, без фиктивного бетона между отдельными частями.
Private Sub TestSeriesOuterRectangle(ByVal model As CSectionModel, ByVal id As String, _
        ByVal minX As Double, ByVal minY As Double, ByVal maxX As Double, ByVal maxY As Double)
    model.Contours.AddContourLine id & "_B", minX, minY, maxX, minY, loopID:=id, loopRole:="Outer", sourceID:="TestSeriesGap"
    model.Contours.AddContourLine id & "_R", maxX, minY, maxX, maxY, loopID:=id, loopRole:="Outer", sourceID:="TestSeriesGap"
    model.Contours.AddContourLine id & "_T", maxX, maxY, minX, maxY, loopID:=id, loopRole:="Outer", sourceID:="TestSeriesGap"
    model.Contours.AddContourLine id & "_L", minX, maxY, minX, minY, loopID:=id, loopRole:="Outer", sourceID:="TestSeriesGap"
End Sub
