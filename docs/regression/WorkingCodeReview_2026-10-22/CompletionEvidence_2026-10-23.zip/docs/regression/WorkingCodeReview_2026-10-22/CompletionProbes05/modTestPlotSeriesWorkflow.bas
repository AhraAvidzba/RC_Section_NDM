Attribute VB_Name = "modTestPlotSeriesWorkflow"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ — НЕАКТИВНЫЙ публичный workflow проверки групповой схемы
' ==========================================================================
' Только после terminal Run02, в собственной private Probes-книге, без Save.
' Требуется отдельный modTestPlotSeriesFixture. Только в private копии готовит
' PR1 DirectState-only/StrengthState/Stress и различимые цвета бетона.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Формирует достоверный preview, измеряет реальный масштаб, решает обычное НДС
' и проверяет независимые bucket keys до наблюдения публичного Draw.
Public Function TestRunSeriesGapWorkflow() As String
    Dim guard As CExcelAppStateGuard, settings As CSystemSettingsReader, units As CUnitSystem
    Dim writer As CNDMResultsWriter, data As CSectionPlotDataReader, plotter As CSectionPlotter
    Dim model As CSectionModel, snapshot As CSectionPropertiesCalculator, batch As CBatchSectionCalculator
    Dim chartObject As Object, chart As Object, testChartScaleValue As Double, pass As Long, expectedKeys As Long, lowKeys As Long, highKeys As Long
    Dim stage As String, record As String, errCode As Long, reason As String, calibrationScale As Double, keyInventory As String
    Dim afterScale As Double, afterKeys As Long, restoreCode As Long, restoreReason As String
    On Error GoTo Failed
    If InStr(1, ThisWorkbook.Name, "_Probes", vbTextCompare) = 0 Then Err.Raise 5, "modTestPlotSeriesWorkflow", "Требуется собственная private Probes-книга."
    Set guard = New CExcelAppStateGuard: guard.Enter ThisWorkbook.Application
    TestPrepareSeriesPrivateSettings
    ThisWorkbook.Application.Calculate ' Подготавливаем реальные формулы частной книги до снимка настроек.
    Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    If Not settings.GetRequiredBoolean("Plot.ResultGradient") Or settings.GetRequiredChoice("Plot.LegendMode", Array("Separate", "Common")) <> "Separate" Then _
        Err.Raise 5, "modTestPlotSeriesWorkflow", "Для case нужны gradient=Yes и Separate."
    If settings.GetString("Plot.LoadCase") <> "LC_SERIES_GAP" Then Err.Raise 5, "modTestPlotSeriesWorkflow", "Выберите частное сочетание LC_SERIES_GAP."
    Set units = New CUnitSystem: units.LoadFromSettings settings
    Set writer = New CNDMResultsWriter: Set plotter = New CSectionPlotter
    testChartScaleValue = 3#: stage = "preview"
    For pass = 1 To 3 ' Повторяем только частный preview для согласования размеров регионов с фактическим ChartScale.
        Set model = modTestPlotSeriesFixture.TestCreateSeriesGapModel(testChartScaleValue)
        Set snapshot = PrepareSectionSnapshot(model)
        writer.WriteGeometryPreview ThisWorkbook, model, snapshot, units, False
        Set data = New CSectionPlotDataReader: data.LoadGeometryPreviewFromWorkbook ThisWorkbook, settings
        If data.LengthUnit <> "mm" Or data.AreaUnit <> "mm2" Then Err.Raise 5, "modTestPlotSeriesWorkflow", "Preview reader должен вернуть внутренние мм/мм2 независимо от OUTPUT книги."
        plotter.Draw ThisWorkbook, data, settings
        Set chartObject = ThisWorkbook.Worksheets("Расчет").ChartObjects("chtNDMSectionPlot")
        chartObject.Width = 8000#: chartObject.Height = 8000# ' Штатное масштабирование контейнера только в private книге; расчётные размеры остаются прежними.
        plotter.Draw ThisWorkbook, data, settings
        Set chart = chartObject.Chart
        testChartScaleValue = TestSeriesActualChartScale(chart)
        If testChartScaleValue < 2# Or testChartScaleValue > 16# Then Err.Raise 5, "modTestPlotSeriesWorkflow", "Масштаб preview вне проверенного геометрического диапазона 2..16 pt/mm."
    Next pass
    stage = "normal-batch"
    Set batch = modTestPlotSeriesFixture.TestSolveSeriesGapFixture(model, settings, units, snapshot, "PR1", ThisWorkbook)
    writer.WriteResults ThisWorkbook, model, snapshot, batch, units, False, False
    Set data = New CSectionPlotDataReader: data.LoadFromWorkbook ThisWorkbook, settings
    If data.GeometryOnly Or data.Count <> 5272 Or data.LengthUnit <> "mm" Or data.AreaUnit <> "mm2" Then Err.Raise 5, "modTestPlotSeriesWorkflow", "Требуется действительное сохранённое НДС 5272 элементов во внутренних мм/мм2."
    stage = "gradient-off-control"
    TestSetSeriesPrivateSetting "Plot.ResultGradient", "No"
    settings.LoadFromWorkbook ThisWorkbook
    plotter.Draw ThisWorkbook, data, settings ' Без градиента число series ограничено размерами, но данные и границы именно расчётного НДС.
    calibrationScale = TestSeriesActualChartScale(chart)
    If chart.SeriesCollection.Count > 17 Then Err.Raise 5, "modTestPlotSeriesWorkflow", "Контроль без градиента неожиданно создал больше 17 групп сжатого бетона."
    TestSetSeriesPrivateSetting "Plot.ResultGradient", "Yes"
    settings.LoadFromWorkbook ThisWorkbook
    testChartScaleValue = calibrationScale
    expectedKeys = TestCountSeriesCompressionKeys(data, testChartScaleValue, settings.GetRequiredRgbColor("Plot.Color.ConcreteCompression"), keyInventory)
    lowKeys = TestCountSeriesCompressionKeys(data, testChartScaleValue * 0.99, settings.GetRequiredRgbColor("Plot.Color.ConcreteCompression"))
    highKeys = TestCountSeriesCompressionKeys(data, testChartScaleValue * 1.01, settings.GetRequiredRgbColor("Plot.Color.ConcreteCompression"))
    record = "SERIES_GAP_PRECONDITIONS: elements=" & CStr(data.Count) & "; pointsPerMm=" & CStr(testChartScaleValue) & "; independentKeys=" & CStr(expectedKeys) & "; independentKeysMinus1pct=" & CStr(lowKeys) & "; independentKeysPlus1pct=" & CStr(highKeys)
    record = record & vbCrLf & "SERIES_GAP_UNITS: savedOutputLength=" & settings.GetRequiredString("Units.Length.Output") & "; savedOutputArea=" & settings.GetRequiredString("Units.Area.Output") & "; savedOutputStress=" & settings.GetRequiredString("Units.Stress.Output") & "; readerLength=" & data.LengthUnit & "; readerArea=" & data.AreaUnit & "; chartScaleUnit=pt/mm"
    record = record & vbCrLf & "SERIES_GAP_KEY_INVENTORY: " & keyInventory
    If expectedKeys <= 255 Or lowKeys <= 255 Or highKeys <= 255 Then
        TestRunSeriesGapWorkflow = record & vbCrLf & "NOT_EXERCISED: независимая опись не превысила 255 ключей; предел не проверен."
        GoTo Finished
    End If
    stage = "public-draw"
    plotter.Draw ThisWorkbook, data, settings
    TestRunSeriesGapWorkflow = record & vbCrLf & "SERIES_GAP_DRAW_COMPLETED: actualSeries=" & CStr(chart.SeriesCollection.Count) & vbCrLf & _
        "NO_OVERALL_PASS: это наблюдение одного достоверного case, а не общая приёмка."
    GoTo Finished
Failed:
    errCode = Err.Number: reason = Err.Source & ": " & Err.Description
    TestRunSeriesGapWorkflow = record & vbCrLf & "SERIES_GAP_OBSERVATION_ERROR: stage=" & stage & "; error=" & CStr(errCode) & "; reason=" & reason
Finished:
    On Error Resume Next ' После исходного сбоя наблюдаем уже оставшийся Chart; ошибка диагностики не подменяет исходную причину.
    If stage = "public-draw" Then
        Err.Clear: afterScale = TestSeriesActualChartScale(chart)
        If Err.Number = 0 Then
            afterKeys = TestCountSeriesCompressionKeys(data, afterScale, settings.GetRequiredRgbColor("Plot.Color.ConcreteCompression"))
            TestRunSeriesGapWorkflow = TestRunSeriesGapWorkflow & vbCrLf & "SERIES_GAP_POST_METRICS: pointsPerMm=" & CStr(afterScale) & "; independentKeys=" & CStr(afterKeys) & "; actualSeries=" & CStr(chart.SeriesCollection.Count)
            If Abs(afterScale / calibrationScale - 1#) > 0.01 Or afterKeys <= 255 Then _
                TestRunSeriesGapWorkflow = TestRunSeriesGapWorkflow & vbCrLf & "NOT_EXERCISED: масштаб после Draw вышел за проверенную окрестность или число ключей недостаточно."
        Else
            TestRunSeriesGapWorkflow = TestRunSeriesGapWorkflow & vbCrLf & "METRICS_UNAVAILABLE: финальное число ключей не доказано."
        End If
    End If
    Err.Clear
    If Not guard Is Nothing Then guard.Restore True
    restoreCode = Err.Number: restoreReason = Err.Description
    On Error GoTo 0
    If restoreCode <> 0 Then TestRunSeriesGapWorkflow = TestRunSeriesGapWorkflow & vbCrLf & "APPSTATE_RESTORE_ERROR: " & CStr(restoreCode) & "; " & restoreReason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет только разрешённые настройки частной копии; материальную диаграмму берёт из исходного PR1 без подмены коэффициентов.
Private Sub TestPrepareSeriesPrivateSettings()
    Dim pairs As Variant, pair As Variant
    pairs = Array(Array("Calculation.Strength.DirectState", "Yes"), Array("Calculation.Strength.Capacity", "No"), _
        Array("Calculation.Crack.Width", "No"), Array("Calculation.Stability.Enabled", "No"), _
        Array("Visualization.State", "StrengthState"), Array("Visualization.Quantity", "Stress"))
    For Each pair In pairs
        TestSetSeriesPrivateProfile "PR1", CStr(pair(0)), CStr(pair(1))
    Next pair
    pairs = Array(Array("Plot.ResultGradient", "Yes"), Array("Plot.LegendMode", "Separate"), _
        Array("Plot.Color.ConcreteCompression", "'64,112,192"), Array("Plot.LoadCase", "LC_SERIES_GAP"), _
        Array("Plot.ContourEnabled", "No"), Array("Plot.ResultLabelsEnabled", "No"), Array("Plot.LegendEnabled", "No"), _
        Array("Plot.NeutralLineEnabled", "No"), Array("Plot.AxisLabelsEnabled", "No"), Array("Plot.PrincipalAxesMode", "None"), _
        Array("Plot.LoadApplicationPointEnabled", "No"), Array("Plot.Dimensions.Enabled", "No"), Array("Plot.RebarLabels.Enabled", "No"))
    For Each pair In pairs
        TestSetSeriesPrivateSetting CStr(pair(0)), CStr(pair(1))
    Next pair
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ищет точный ключ по блочно прочитанным двум таблицам оформления; чужие значения и форматирование не меняет.
Private Sub TestSetSeriesPrivateSetting(ByVal key As String, ByVal value As String)
    Dim rangeName As Variant, area As Object, values As Variant, row As Long, targetColumn As Long
    For Each rangeName In Array("rngSystemSettings", "rngPlotAnnotationSettings")
        Set area = ThisWorkbook.Names.Item(CStr(rangeName)).RefersToRange: values = area.Value2
        For row = 2 To UBound(values, 1)
            If CStr(values(row, 1)) = key Then area.Cells(row, 2).Value2 = value: Exit Sub
            If CStr(rangeName) = "rngPlotAnnotationSettings" And CStr(values(row, 1)) = "Enabled" Then
                targetColumn = 0
                If key = "Plot.RebarLabels.Enabled" Then targetColumn = 2
                If key = "Plot.Dimensions.Enabled" Then targetColumn = 3
                If targetColumn > 0 Then area.Cells(row, targetColumn).Value2 = value: Exit Sub
            End If
        Next row
    Next rangeName
    Err.Raise 5, "modTestPlotSeriesWorkflow", "В частной копии не найден ключ " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Находит PR1 по ProfileId, а параметр по столбцу Key; не привязывает fixture к адресам исходной книги.
Private Sub TestSetSeriesPrivateProfile(ByVal profileId As String, ByVal key As String, ByVal value As String)
    Dim area As Object, values As Variant, row As Long, column As Long, profileColumn As Long
    Set area = ThisWorkbook.Names.Item("rngCalculationProfiles").RefersToRange: values = area.Value2
    For row = 1 To UBound(values, 1)
        If CStr(values(row, 2)) = "Key" Then
            For column = 3 To UBound(values, 2)
                If CStr(values(row, column)) = profileId Then profileColumn = column: Exit For
            Next column
            Exit For
        End If
    Next row
    If profileColumn = 0 Then Err.Raise 5, "modTestPlotSeriesWorkflow", "В частной таблице профилей нет " & profileId
    For row = 1 To UBound(values, 1)
        If CStr(values(row, 2)) = key Then area.Cells(row, profileColumn).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, "modTestPlotSeriesWorkflow", "В частном профиле не найден ключ " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считывает только публичные размеры PlotArea и диапазоны двух осей.
Private Function TestSeriesActualChartScale(ByVal chart As Object) As Double
    Dim sx As Double, sy As Double
    sx = chart.PlotArea.InsideWidth / (chart.Axes(1, 1).MaximumScale - chart.Axes(1, 1).MinimumScale)
    sy = chart.PlotArea.InsideHeight / (chart.Axes(2, 1).MaximumScale - chart.Axes(2, 1).MinimumScale)
    If sx < sy Then TestSeriesActualChartScale = sx Else TestSeriesActualChartScale = sy
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Независимо воспроизводит только известные Concrete/Compression ключи данного
' физического fixture; неизвестные состояния не используются для умножения групп.
Private Function TestCountSeriesCompressionKeys(ByVal data As CSectionPlotDataReader, ByVal testChartScaleValue As Double, ByVal endColor As Long, _
        Optional ByRef inventory As String = vbNullString) As Long
    Dim keys As Object, index As Long, maxAbs As Double, ratio As Double, size As Long, color As Long
    Dim length As Double, key As String
    Set keys = CreateObject("Scripting.Dictionary")
    For index = 1 To data.Count
        If data.MaterialType(index) <> "Concrete" Or data.PhysicalState(index) <> "Compression" Then Err.Raise 5, _
            "modTestPlotSeriesWorkflow", "Нужны только настоящие сжатые бетонные элементы."
        If Abs(data.ResultValue(index)) > maxAbs Then maxAbs = Abs(data.ResultValue(index))
    Next index
    If maxAbs <= 0# Then Err.Raise 5, "modTestPlotSeriesWorkflow", "Отсутствует ненулевое напряжение сжатия."
    For index = 1 To data.Count
        If data.Width(index) <= 0# Or data.Height(index) <= 0# Then Err.Raise 5, "modTestPlotSeriesWorkflow", "У квадратов должны быть сохранены обе положительные стороны."
        length = Sqr(data.Width(index) * data.Height(index))
        size = CLng(Int(TestSeriesClamp(0.7 * length * testChartScaleValue, 2#, 48#) + 0.5))
        If size > 2 Then size = CLng(Int(CDbl(size) / 3# + 0.5)) * 3
        size = CLng(TestSeriesClamp(CDbl(size), 2#, 48#))
        ratio = CDbl(CLng(Int(TestSeriesClamp(Abs(data.ResultValue(index)) / maxAbs, 0#, 1#) * 16# + 0.5))) / 16#
        color = TestSeriesBlendColor(endColor, ratio)
        key = "1|" & CStr(size) & "|" & CStr(color) & "|Concrete|Compression"
        keys(key) = True
    Next index
    TestCountSeriesCompressionKeys = keys.Count
    inventory = Join(keys.Keys, ";")
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет RGB той же линейной цветовой шкалы без чтения private plotter state.
Private Function TestSeriesBlendColor(ByVal endColor As Long, ByVal ratio As Double) As Long
    Dim r As Long, g As Long, b As Long
    r = CLng(218# + (CDbl(endColor Mod 256) - 218#) * ratio)
    g = CLng(218# + (CDbl((endColor \ 256) Mod 256) - 218#) * ratio)
    b = CLng(218# + (CDbl((endColor \ 65536) Mod 256) - 218#) * ratio)
    TestSeriesBlendColor = RGB(r, g, b)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ограничивает только отображаемый размер/ratio; входы модели не округляются.
Private Function TestSeriesClamp(ByVal value As Double, ByVal low As Double, ByVal high As Double) As Double
    TestSeriesClamp = value
    If value < low Then TestSeriesClamp = low
    If value > high Then TestSeriesClamp = high
End Function
