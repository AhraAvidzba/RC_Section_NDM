Attribute VB_Name = "modTestPlotSeriesFallback"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: НЕАКТИВНЫЙ наблюдатель исправления предела 255 series.
' Только частная Probes-книга после terminal Run02. Сначала выполнить обычный
' modTestPlotSeriesWorkflow.TestRunSeriesGapWorkflow с настоящим НДС fixture.
' Не пишет Results, не решает НДС и не вызывает private API plotter-а.
' ==========================================================================
Private mPassed As Long, mFailed As Long, mReport As String
Private Type TTestFallbackDouble
    Value As Double
End Type
Private Type TTestFallbackWords
    Low As Long
    High As Long
End Type

' -------------------- ДЛЯ ТЕСТОВ --------------------
' На тех же5272 действительных элементах проверяет series->Shapes->повтор->series->Shapes.
' Все размеры, центры, цвета и углы сравниваются с публичным reader; исходный Results перечитывается после каждого Draw.
Public Function TestObserveSeriesFallback() As String
    Dim settings As CSystemSettingsReader, data As CSectionPlotDataReader, plotter As CSectionPlotter
    Dim guard As CExcelAppStateGuard, chartObject As Object, chart As Object, sentinel As Object
    Dim inputSignature As String, firstShapes As String, repeatedShapes As String, stage As String
    Dim number As Long, reason As String, originalGradient As String, beforeKeys As Long
    mPassed = 0: mFailed = 0: mReport = vbNullString
    On Error GoTo Failed
    If InStr(1, ThisWorkbook.Name, "_Probes", vbTextCompare) = 0 Then Err.Raise 5, , "Требуется собственная частная Probes-книга."
    Set guard = New CExcelAppStateGuard: guard.Enter ThisWorkbook.Application
    Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    originalGradient = settings.GetRequiredString("Plot.ResultGradient")
    If originalGradient <> "Yes" Then Err.Raise 5, , "Нужен исходный gradient=Yes после адресного workflow."
    Set data = New CSectionPlotDataReader: data.LoadFromWorkbook ThisWorkbook, settings
    If data.GeometryOnly Or data.Count <> 5272 Or data.LoadCase <> "LC_SERIES_GAP" Or data.LengthUnit <> "mm" Then _
        Err.Raise 5, , "Сначала подготовьте настоящее сохраненное LC_SERIES_GAP/5272 через обычный workflow."
    inputSignature = TestFallbackDataSignature(data)
    Set plotter = New CSectionPlotter
    Set chartObject = ThisWorkbook.Worksheets("Расчет").ChartObjects("chtNDMSectionPlot")
    Set chart = chartObject.Chart
    stage = "series-before"
    TestFallbackSetGradient "No": settings.LoadFromWorkbook ThisWorkbook
    plotter.Draw ThisWorkbook, data, settings
    TestFallbackNormalSeries chart, stage
    TestFallbackInputUnchanged settings, inputSignature, stage
    beforeKeys = TestFallbackKeyCount(data, TestFallbackGroupedScale(chart), settings.GetRequiredRgbColor("Plot.Color.ConcreteCompression"))
    TestFallbackCheck beforeKeys > 255, "actualGroupedKeyPrecondition=" & CStr(beforeKeys)
    If beforeKeys <= 255 Then Err.Raise 5, , "Не достигнут реальный предел групп, поэтому fallback case не проверен."
    Set sentinel = chart.Shapes.AddShape(1, 3#, 3#, 2#, 2#)
    sentinel.Name = "SeriesFallback_UserKeep" ' Нет NDMPlot_ префикса: обычная очистка должна сохранить чужую фигуру.
    stage = "fallback-first"
    TestFallbackSetGradient "Yes": settings.LoadFromWorkbook ThisWorkbook
    plotter.Draw ThisWorkbook, data, settings
    firstShapes = TestFallbackInspect(chartObject, data, settings, stage)
    TestFallbackInputUnchanged settings, inputSignature, stage
    stage = "fallback-repeat"
    plotter.Draw ThisWorkbook, data, settings
    repeatedShapes = TestFallbackInspect(chartObject, data, settings, stage)
    TestFallbackCheck firstShapes = repeatedShapes, "repeatShapePropertiesBitwiseStable"
    TestFallbackInputUnchanged settings, inputSignature, stage
    stage = "series-after-fallback"
    TestFallbackSetGradient "No": settings.LoadFromWorkbook ThisWorkbook
    plotter.Draw ThisWorkbook, data, settings
    TestFallbackNormalSeries chart, stage
    TestFallbackInputUnchanged settings, inputSignature, stage
    stage = "fallback-after-series"
    TestFallbackSetGradient "Yes": settings.LoadFromWorkbook ThisWorkbook
    plotter.Draw ThisWorkbook, data, settings
    repeatedShapes = TestFallbackInspect(chartObject, data, settings, stage)
    TestFallbackCheck firstShapes = repeatedShapes, "roundTripShapePropertiesBitwiseStable"
    TestFallbackInputUnchanged settings, inputSignature, stage
    GoTo Finished
Failed:
    number = Err.Number: reason = Err.Source & ": " & Err.Description
    mFailed = mFailed + 1
    mReport = mReport & "FAIL: fallback.runtime; stage=" & stage & "; error=" & CStr(number) & "; " & reason & vbCrLf
Finished:
    On Error Resume Next ' Восстановление не должно скрыть исходный COM/проверочный отказ.
    Err.Clear
    If Len(originalGradient) > 0 Then TestFallbackSetGradient originalGradient
    If Not sentinel Is Nothing Then sentinel.Delete
    If Err.Number <> 0 Then mFailed = mFailed + 1: mReport = mReport & "FAIL: fallback.privateCleanup; " & Err.Description & vbCrLf
    Err.Clear
    If Not guard Is Nothing Then guard.Restore True
    If Err.Number <> 0 Then mFailed = mFailed + 1: mReport = mReport & "FAIL: fallback.appStateRestore; " & Err.Description & vbCrLf
    On Error GoTo 0
    TestObserveSeriesFallback = mReport & "TOTAL_SERIES_FALLBACK: passed=" & CStr(mPassed) & "; failed=" & CStr(mFailed)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет все5272 фигуры в порядке создания и сохраняет точные native-биты их фактических свойств для повтора.
' Рамка28/36/(Width-180)/(Height-72) является контрактом существующего Shape renderer, а не живой PlotArea.
Private Function TestFallbackInspect(ByVal chartObject As Object, ByVal data As CSectionPlotDataReader, _
        ByVal settings As CSystemSettingsReader, ByVal stage As String) As String
    Dim chart As Object, shape As Object, shapes As Object, userCount As Long, elementCount As Long
    Dim i As Long, name As String, colors As Object, maxAbs As Double, endColor As Long
    Dim minX As Double, maxX As Double, minY As Double, maxY As Double, frameW As Double, frameH As Double
    Dim sx As Double, sy As Double, cx As Double, cy As Double, expectedW As Double, expectedH As Double
    Dim color As Long, ratio As Double, expectedRotation As Double, rotationError As Double
    Dim maxCenterError As Double, maxSizeError As Double, maxAngleError As Double, colorErrors As Long
    Dim lines() As String, value As Double
    Set chart = chartObject.Chart: Set shapes = CreateObject("Scripting.Dictionary"): Set colors = CreateObject("Scripting.Dictionary")
    For Each shape In chart.Shapes
        name = shape.Name
        If Left$(name, 23) = "NDMPlot_ElementConcrete" Then elementCount = elementCount + 1
        If Left$(name, 8) <> "NDMPlot_" Then userCount = userCount + 1
        shapes.Add name, shape
    Next shape
    TestFallbackCheck elementCount = data.Count, stage & ".elementShapes=" & CStr(elementCount)
    TestFallbackCheck chart.SeriesCollection.Count = 0, stage & ".elementSeries=0"
    TestFallbackCheck shapes.Exists("SeriesFallback_UserKeep"), stage & ".userShapePreserved"
    If elementCount <> data.Count Then Err.Raise 5, , "Не созданы все реальные бетонные фигуры."
    minX = chart.Axes(1, 1).MinimumScale: maxX = chart.Axes(1, 1).MaximumScale
    minY = chart.Axes(2, 1).MinimumScale: maxY = chart.Axes(2, 1).MaximumScale
    frameW = chartObject.Width - 180#: frameH = chartObject.Height - 72#
    sx = frameW / (maxX - minX): sy = frameH / (maxY - minY)
    TestFallbackCheck Abs(sx / sy - 1#) <= 0.000000001, stage & ".equalFrameAxisScale"
    For i = 1 To data.Count
        If Abs(data.ResultValue(i)) > maxAbs Then maxAbs = Abs(data.ResultValue(i))
    Next i
    endColor = settings.GetRequiredRgbColor("Plot.Color.ConcreteCompression")
    ReDim lines(1 To data.Count)
    For i = 1 To data.Count
        If data.MaterialType(i) <> "Concrete" Or data.PhysicalState(i) <> "Compression" Then Err.Raise 5, , "Fixture содержит неожиданный материал/состояние."
        name = "NDMPlot_ElementConcrete" & CStr(userCount + i)
        If Not shapes.Exists(name) Then Err.Raise 5, , "Нарушено взаимно-однозначное соответствие фигуры и элемента: " & name
        Set shape = shapes(name)
        cx = 28# + (data.X(i) - minX) * sx: cy = 36# + frameH - (data.Y(i) - minY) * sy
        expectedW = 0.7 * data.Width(i) * sx: expectedH = 0.7 * data.Height(i) * sy
        value = Abs((shape.Left + shape.Width / 2#) - cx): If value > maxCenterError Then maxCenterError = value
        value = Abs((shape.Top + shape.Height / 2#) - cy): If value > maxCenterError Then maxCenterError = value
        value = Abs(shape.Width - expectedW): If value > maxSizeError Then maxSizeError = value
        value = Abs(shape.Height - expectedH): If value > maxSizeError Then maxSizeError = value
        expectedRotation = -data.Rotation(i) * 180# / GEOM_PI
        rotationError = Abs(shape.Rotation - expectedRotation): rotationError = rotationError - 360# * Int(rotationError / 360#)
        If rotationError > 180# Then rotationError = 360# - rotationError
        If rotationError > maxAngleError Then maxAngleError = rotationError
        ratio = CDbl(CLng(Int(16# * Abs(data.ResultValue(i)) / maxAbs + 0.5))) / 16#
        color = TestFallbackColor(endColor, ratio)
        If shape.Fill.ForeColor.RGB <> color Or shape.Line.ForeColor.RGB <> color Then colorErrors = colorErrors + 1
        colors(CStr(shape.Fill.ForeColor.RGB)) = True
        lines(i) = name & "|" & TestFallbackBits(shape.Left) & "|" & TestFallbackBits(shape.Top) & "|" & _
            TestFallbackBits(shape.Width) & "|" & TestFallbackBits(shape.Height) & "|" & TestFallbackBits(shape.Rotation) & "|" & CStr(shape.Fill.ForeColor.RGB)
    Next i
    TestFallbackCheck maxCenterError <= 0.005, stage & ".allCenters; maxErrorPt=" & CStr(maxCenterError)
    TestFallbackCheck maxSizeError <= 0.005, stage & ".allSizes; maxErrorPt=" & CStr(maxSizeError)
    TestFallbackCheck maxAngleError <= 0.0001, stage & ".allRotations; maxErrorDeg=" & CStr(maxAngleError)
    TestFallbackCheck colorErrors = 0 And colors.Count = 17, stage & ".allColors; mismatches=" & CStr(colorErrors) & "; distinct=" & CStr(colors.Count)
    mReport = mReport & "FALLBACK_FRAME: stage=" & stage & "; checkedElements=" & CStr(data.Count) & "; sx=" & CStr(sx) & "; sy=" & CStr(sy) & "; rotationsFromSavedData=True" & vbCrLf
    TestFallbackInspect = Join(lines, vbCrLf)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль на тех же реальных Results: без градиента возвращаются не более17 бетонных групп, Shapes удалены.
Private Sub TestFallbackNormalSeries(ByVal chart As Object, ByVal stage As String)
    Dim shape As Object, count As Long
    For Each shape In chart.Shapes
        If Left$(shape.Name, 23) = "NDMPlot_ElementConcrete" Then count = count + 1
    Next shape
    TestFallbackCheck count = 0, stage & ".noStaleElementShapes"
    TestFallbackCheck chart.SeriesCollection.Count > 0 And chart.SeriesCollection.Count <= 17, stage & ".normalSeries=" & CStr(chart.SeriesCollection.Count)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Перечитывает настоящий Results, поэтому сравнение защищает не только уже загруженный reader.
Private Sub TestFallbackInputUnchanged(ByVal settings As CSystemSettingsReader, ByVal originalSignature As String, ByVal stage As String)
    Dim current As CSectionPlotDataReader
    Set current = New CSectionPlotDataReader: current.LoadFromWorkbook ThisWorkbook, settings
    TestFallbackCheck TestFallbackDataSignature(current) = originalSignature, stage & ".savedInputUnchanged"
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет порядок, ID, все координаты/размеры/площади/углы и реальные значения НДС без десятичного округления.
Private Function TestFallbackDataSignature(ByVal data As CSectionPlotDataReader) As String
    Dim rows() As String, i As Long
    ReDim rows(0 To data.Count)
    rows(0) = data.LoadCase & "|" & data.StateType & "|" & data.ResultUnit & "|" & data.ResultCaption & "|" & _
        CStr(data.ResultPrecision) & "|" & data.LengthUnit & "|" & data.AreaUnit & "|" & CStr(data.Count) & "|" & _
        TestFallbackBits(data.MinX) & "|" & TestFallbackBits(data.MaxX) & "|" & TestFallbackBits(data.MinY) & "|" & TestFallbackBits(data.MaxY)
    For i = 1 To data.Count
        rows(i) = data.ElementID(i) & "|" & data.MaterialType(i) & "|" & data.PhysicalState(i) & "|" & _
            TestFallbackBits(data.X(i)) & "|" & TestFallbackBits(data.Y(i)) & "|" & TestFallbackBits(data.Area(i)) & "|" & _
            TestFallbackBits(data.Width(i)) & "|" & TestFallbackBits(data.Height(i)) & "|" & _
            TestFallbackBits(data.Rotation(i)) & "|" & TestFallbackBits(data.ResultValue(i))
    Next i
    TestFallbackDataSignature = Join(rows, vbCrLf)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' До fallback независимо считает настоящие marker/color keys через публичную grouped PlotArea.
Private Function TestFallbackKeyCount(ByVal data As CSectionPlotDataReader, ByVal pointsPerMm As Double, ByVal endColor As Long) As Long
    Dim keys As Object, i As Long, maxAbs As Double, size As Long, ratio As Double
    Set keys = CreateObject("Scripting.Dictionary")
    For i = 1 To data.Count
        If Abs(data.ResultValue(i)) > maxAbs Then maxAbs = Abs(data.ResultValue(i))
    Next i
    For i = 1 To data.Count
        size = CLng(Int(TestFallbackClamp(0.7 * Sqr(data.Width(i) * data.Height(i)) * pointsPerMm, 2#, 48#) + 0.5))
        If size > 2 Then size = CLng(Int(CDbl(size) / 3# + 0.5)) * 3
        size = CLng(TestFallbackClamp(CDbl(size), 2#, 48#))
        ratio = CDbl(CLng(Int(16# * Abs(data.ResultValue(i)) / maxAbs + 0.5))) / 16#
        keys(CStr(size) & "|" & CStr(TestFallbackColor(endColor, ratio)) & "|Concrete|Compression") = True
    Next i
    TestFallbackKeyCount = keys.Count
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает меньший фактический масштаб осей обычного grouped Chart.
Private Function TestFallbackGroupedScale(ByVal chart As Object) As Double
    Dim sx As Double, sy As Double
    sx = chart.PlotArea.InsideWidth / (chart.Axes(1, 1).MaximumScale - chart.Axes(1, 1).MinimumScale)
    sy = chart.PlotArea.InsideHeight / (chart.Axes(2, 1).MaximumScale - chart.Axes(2, 1).MinimumScale)
    If sx < sy Then TestFallbackGroupedScale = sx Else TestFallbackGroupedScale = sy
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет только Plot.ResultGradient в исходных данных частной Probes-копии; расчетные таблицы не записываются.
Private Sub TestFallbackSetGradient(ByVal value As String)
    Dim area As Object, values As Variant, row As Long
    Set area = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange: values = area.Value2
    For row = 2 To UBound(values, 1)
        If values(row, 1) = "Plot.ResultGradient" Then area.Cells(row, 2).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, , "Не найдено частное поле Plot.ResultGradient."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит прежние17 ступеней RGB сжатия; отсутствие grouping flag выявляется сравнением каждого элемента.
Private Function TestFallbackColor(ByVal endColor As Long, ByVal ratio As Double) As Long
    TestFallbackColor = RGB(CLng(218# + (CDbl(endColor Mod 256) - 218#) * ratio), _
        CLng(218# + (CDbl((endColor \ 256) Mod 256) - 218#) * ratio), _
        CLng(218# + (CDbl((endColor \ 65536) Mod 256) - 218#) * ratio))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ограничивает только тестовое вычисление визуального размера, не исходные координаты.
Private Function TestFallbackClamp(ByVal value As Double, ByVal low As Double, ByVal high As Double) As Double
    TestFallbackClamp = value
    If value < low Then TestFallbackClamp = low
    If value > high Then TestFallbackClamp = high
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет именно биты Double, включая знак нуля; сравнение не использует округление CStr.
Private Function TestFallbackBits(ByVal value As Double) As String
    Dim number As TTestFallbackDouble, words As TTestFallbackWords
    number.Value = value: LSet words = number
    TestFallbackBits = Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает компактный протокол фактических проверок; не объявляет PASS без всех проверок.
Private Sub TestFallbackCheck(ByVal condition As Boolean, ByVal label As String)
    If condition Then
        mPassed = mPassed + 1: mReport = mReport & "OK: fallback." & label & vbCrLf
    Else
        mFailed = mFailed + 1: mReport = mReport & "FAIL: fallback." & label & vbCrLf
    End If
End Sub
