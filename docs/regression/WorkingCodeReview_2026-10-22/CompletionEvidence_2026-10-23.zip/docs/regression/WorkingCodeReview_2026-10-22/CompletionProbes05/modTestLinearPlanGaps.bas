Attribute VB_Name = "modTestLinearPlanGaps"
Option Explicit

' ======================================================================
' ДЛЯ ТЕСТОВ: НЕАКТИВНЫЙ probe трёх буквальных пробелов исходного TestPlan.
' Импортировать только в отдельную копию ПОСЛЕ terminal Run02 по решению root.
' Не обращается к Excel, материалам, геометрии, Results или настройкам книги.
' Проверяет прежний линейный API без изменения pivot и допусков production.
' ======================================================================

Private Type TTestLinearGapDouble
    Value As Double
End Type

Private Type TTestLinearGapWords
    Low As Long
    High As Long
End Type

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет zero/rank boundary и независимое масштабирование строк на известных векторах.
' Возвращает компактные CASE и все фактические отказы; подготовка файла не означает запуск.
Public Function TestRunLinearPlanGapProbe() As String
    Dim system As CLinearSystem3x3, report As String, passed As Long, failed As Long, cases As Long
    Dim rhs As Variant, sign As Variant, factor As Variant, scales As Variant, deltaUlps As Variant
    Dim solved As Boolean, pivot As Double, prefix As String
    On Error GoTo FailedRun
    Set system = New CLinearSystem3x3
    For Each rhs In Array(0#, 1#)
        prefix = "linearGap.zero.rhs" & CStr(rhs)
        solved = system.Solve(0#, 0#, 0#, 0#, 0#, 0#, 0#, 0#, 0#, CDbl(rhs), CDbl(rhs), CDbl(rhs))
        TestLinearGapCheck report, passed, failed, prefix & ".rejected", Not solved And Not system.Solved
        TestLinearGapCheck report, passed, failed, prefix & ".code", system.FailureCode = sfcSingularTangent
        TestLinearGapCheck report, passed, failed, prefix & ".cleared", system.X1 = 0# And system.X2 = 0# And system.X3 = 0#
        TestLinearGapRecovery system, report, passed, failed, prefix
        cases = cases + 1
        report = report & "CASE|" & prefix & vbCrLf
    Next rhs
    For Each sign In Array(-1#, 1#)
        For Each factor In Array(0.5, 1#, 2#)
            pivot = CDbl(sign) * 1E-18 * CDbl(factor) ' Точно та же существующая граница Abs(pivot)<=1E-18; меняется только тестовый вход.
            prefix = "linearGap.near.sign" & CStr(sign) & ".factor" & CStr(factor)
            solved = system.Solve(1#, 0#, 0#, 0#, pivot, 0#, 0#, 0#, 1#, 1#, -2# * pivot, 3#)
            If CDbl(factor) <= 1# Then
                TestLinearGapCheck report, passed, failed, prefix & ".rejected", Not solved And Not system.Solved
                TestLinearGapCheck report, passed, failed, prefix & ".code", system.FailureCode = sfcSingularTangent
                TestLinearGapCheck report, passed, failed, prefix & ".cleared", system.X1 = 0# And system.X2 = 0# And system.X3 = 0#
                TestLinearGapRecovery system, report, passed, failed, prefix
            Else
                TestLinearGapCheck report, passed, failed, prefix & ".solved", solved And system.Solved
                TestLinearGapCheck report, passed, failed, prefix & ".code", system.FailureCode = sfcNone
                TestLinearGapVector system, report, passed, failed, prefix, 1#, -2#, 3#
                TestLinearGapCheck report, passed, failed, prefix & ".originalEq1", Abs(system.X1 - 1#) <= 0.000000000001
                TestLinearGapCheck report, passed, failed, prefix & ".originalEq2", Abs((pivot * system.X2 + 2# * pivot) / Abs(pivot)) <= 0.000000000001
                TestLinearGapCheck report, passed, failed, prefix & ".originalEq3", Abs(system.X3 - 3#) <= 0.000000000001
            End If
            cases = cases + 1
            report = report & "CASE|" & prefix & "|pivot=" & CStr(pivot) & "|solved=" & CStr(solved) & vbCrLf
        Next factor
    Next sign
    For Each scales In Array(Array(1#, 1#, 1#), Array(2# ^ -40, 1#, 2# ^ 40), _
            Array(2# ^ 40, 2# ^ -40, 1#), Array(1#, 2# ^ 40, 2# ^ -40))
        prefix = "linearGap.rowScale." & CStr(cases - 7)
        TestLinearGapScaledRows system, report, passed, failed, prefix, CDbl(scales(0)), CDbl(scales(1)), CDbl(scales(2))
        cases = cases + 1
    Next scales
    For Each deltaUlps In Array(4, 8)
        prefix = "linearGap.dependentRows.ULP" & CStr(deltaUlps)
        TestLinearGapDependentRows system, report, passed, failed, prefix, CLng(deltaUlps)
        cases = cases + 1
    Next deltaUlps
    TestRunLinearPlanGapProbe = report & "TOTAL_LINEAR_PLAN_GAPS: cases=" & CStr(cases) & "; passed=" & CStr(passed) & "; failed=" & CStr(failed)
    Exit Function
FailedRun:
    TestRunLinearPlanGapProbe = report & "FAIL: linearGap.runtime; " & CStr(Err.Number) & "; " & Err.Description & vbCrLf & _
        "TOTAL_LINEAR_PLAN_GAPS: cases=" & CStr(cases) & "; passed=" & CStr(passed) & "; failed=" & CStr(failed + 1)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Почти одинаковые строки дают точную разность четырёх/восьми ULP около a=0.001.
' Проверяет обе стороны прежнего pivot1e-18 без подмены вырождения малой диагональю.
Private Sub TestLinearGapDependentRows(ByVal system As CLinearSystem3x3, ByRef report As String, _
        ByRef passed As Long, ByRef failed As Long, ByVal prefix As String, ByVal deltaUlps As Long)
    Dim a As Double, delta As Double, secondA As Double, b1 As Double, b2 As Double, solved As Boolean
    Dim r1 As Double, r2 As Double, r3 As Double
    a = 0.001: delta = CDbl(deltaUlps) * 2# ^ -62 ' Около данного Double a один ULP равен2^-62; оба входа точно представимы.
    secondA = a + delta: b1 = -a: b2 = -a - 2# * delta
    TestLinearGapCheck report, passed, failed, prefix & ".exactDelta", secondA - a = delta
    TestLinearGapCheck report, passed, failed, prefix & ".exactRhsDifference", b2 - b1 = -2# * delta
    solved = system.Solve(a, a, 0#, a, secondA, 0#, 0#, 0#, 1#, b1, b2, 3#)
    If deltaUlps = 4 Then
        TestLinearGapCheck report, passed, failed, prefix & ".rejected", Not solved And Not system.Solved
        TestLinearGapCheck report, passed, failed, prefix & ".code", system.FailureCode = sfcSingularTangent
        TestLinearGapCheck report, passed, failed, prefix & ".cleared", system.X1 = 0# And system.X2 = 0# And system.X3 = 0#
        TestLinearGapRecovery system, report, passed, failed, prefix
    Else
        TestLinearGapCheck report, passed, failed, prefix & ".solved", solved And system.Solved
        TestLinearGapCheck report, passed, failed, prefix & ".code", system.FailureCode = sfcNone
        TestLinearGapVector system, report, passed, failed, prefix, 1#, -2#, 3#
        r1 = (a * system.X1 + a * system.X2 - b1) / a ' Каждое исходное уравнение проверяем отдельно, в его первоначальном масштабе.
        r2 = (a * system.X1 + secondA * system.X2 - b2) / a
        r3 = system.X3 - 3#
        TestLinearGapCheck report, passed, failed, prefix & ".originalEq1", TestLinearGapFinite(r1) And Abs(r1) <= 0.000000000001
        TestLinearGapCheck report, passed, failed, prefix & ".originalEq2", TestLinearGapFinite(r2) And Abs(r2) <= 0.000000000001
        TestLinearGapCheck report, passed, failed, prefix & ".originalEq3", TestLinearGapFinite(r3) And Abs(r3) <= 0.000000000001
    End If
    report = report & "CASE|" & prefix & "|a=" & TestLinearGapBits(a) & "|secondA=" & TestLinearGapBits(secondA) & _
        "|delta=" & TestLinearGapBits(delta) & "|b1=" & TestLinearGapBits(b1) & "|b2=" & TestLinearGapBits(b2) & _
        "|solved=" & CStr(solved) & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Умножает каждое исходное уравнение на свой масштаб; известный вектор остаётся (1;-2;3).
' Обратную подстановку считает по исходным коэффициентам отдельно от residual самого класса.
Private Sub TestLinearGapScaledRows(ByVal system As CLinearSystem3x3, ByRef report As String, _
        ByRef passed As Long, ByRef failed As Long, ByVal prefix As String, _
        ByVal row1 As Double, ByVal row2 As Double, ByVal row3 As Double)
    Dim a11 As Double, a12 As Double, a21 As Double, a22 As Double, a23 As Double, a32 As Double, a33 As Double
    Dim b1 As Double, b2 As Double, b3 As Double, solved As Boolean, r1 As Double, r2 As Double, r3 As Double
    a11 = 3# * row1: a12 = row1: b1 = row1
    a21 = row2: a22 = 4# * row2: a23 = row2: b2 = -4# * row2
    a32 = row3: a33 = 2# * row3: b3 = 4# * row3
    solved = system.Solve(a11, a12, 0#, a21, a22, a23, 0#, a32, a33, b1, b2, b3)
    TestLinearGapCheck report, passed, failed, prefix & ".solved", solved And system.Solved
    TestLinearGapCheck report, passed, failed, prefix & ".code", system.FailureCode = sfcNone
    TestLinearGapVector system, report, passed, failed, prefix, 1#, -2#, 3#
    r1 = (a11 * system.X1 + a12 * system.X2 - b1) / row1 ' Нормировка возвращает исходное уравнение, не скрывает малую строку суммой больших.
    r2 = (a21 * system.X1 + a22 * system.X2 + a23 * system.X3 - b2) / row2
    r3 = (a32 * system.X2 + a33 * system.X3 - b3) / row3
    TestLinearGapCheck report, passed, failed, prefix & ".originalEq1", TestLinearGapFinite(r1) And Abs(r1) <= 0.000000000001
    TestLinearGapCheck report, passed, failed, prefix & ".originalEq2", TestLinearGapFinite(r2) And Abs(r2) <= 0.000000000001
    TestLinearGapCheck report, passed, failed, prefix & ".originalEq3", TestLinearGapFinite(r3) And Abs(r3) <= 0.000000000001
    report = report & "CASE|" & prefix & "|scales=" & CStr(row1) & "," & CStr(row2) & "," & CStr(row3) & _
        "|solved=" & CStr(solved) & "|r=" & CStr(r1) & "," & CStr(r2) & "," & CStr(r3) & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Следующий исправный вызов того же объекта обязан очистить старый отказ и вернуть известный вектор.
Private Sub TestLinearGapRecovery(ByVal system As CLinearSystem3x3, ByRef report As String, _
        ByRef passed As Long, ByRef failed As Long, ByVal prefix As String)
    TestLinearGapCheck report, passed, failed, prefix & ".recovery", system.Solve(1#, 0#, 0#, 0#, 1#, 0#, 0#, 0#, 1#, 1#, -2#, 3#) And system.Solved
    TestLinearGapCheck report, passed, failed, prefix & ".recoveryCode", system.FailureCode = sfcNone
    TestLinearGapVector system, report, passed, failed, prefix & ".recovery", 1#, -2#, 3#
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет конечность до арифметического сравнения; допуск1e-12 совпадает с прежним known-vector тестом.
Private Sub TestLinearGapVector(ByVal system As CLinearSystem3x3, ByRef report As String, _
        ByRef passed As Long, ByRef failed As Long, ByVal prefix As String, _
        ByVal x1 As Double, ByVal x2 As Double, ByVal x3 As Double)
    Dim finite As Boolean
    finite = TestLinearGapFinite(system.X1) And TestLinearGapFinite(system.X2) And TestLinearGapFinite(system.X3)
    TestLinearGapCheck report, passed, failed, prefix & ".finite", finite
    If Not finite Then Exit Sub
    TestLinearGapCheck report, passed, failed, prefix & ".x1", Abs(system.X1 - x1) <= 0.000000000001
    TestLinearGapCheck report, passed, failed, prefix & ".x2", Abs(system.X2 - x2) <= 0.000000000001
    TestLinearGapCheck report, passed, failed, prefix & ".x3", Abs(system.X3 - x3) <= 0.000000000001
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает exponent IEEE754 без арифметики над возможными NaN/Infinity.
Private Function TestLinearGapFinite(ByVal value As Double) As Boolean
    Dim number As TTestLinearGapDouble, words As TTestLinearGapWords
    number.Value = value: LSet words = number
    TestLinearGapFinite = (words.High And &H7FF00000) <> &H7FF00000
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет все биты новых almost-dependent входов без десятичного округления CStr.
Private Function TestLinearGapBits(ByVal value As Double) As String
    Dim number As TTestLinearGapDouble, words As TTestLinearGapWords
    number.Value = value: LSet words = number
    TestLinearGapBits = "F64:" & Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает все assertions, а в короткий текст добавляет только фактические отказы.
Private Sub TestLinearGapCheck(ByRef report As String, ByRef passed As Long, ByRef failed As Long, _
        ByVal label As String, ByVal condition As Boolean)
    If condition Then
        passed = passed + 1
    Else
        failed = failed + 1
        report = report & "FAIL: " & label & vbCrLf
    End If
End Sub
