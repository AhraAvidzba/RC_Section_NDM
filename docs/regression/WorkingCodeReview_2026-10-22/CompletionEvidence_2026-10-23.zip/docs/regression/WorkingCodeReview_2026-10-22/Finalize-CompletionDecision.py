"""Связывает завершённые проверки с точными версиями книги; не исполняет Excel."""
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CORE = ROOT / 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run02'
FOCUSED = ROOT / 'docs/regression/WorkingCodeReview_2026-10-23_CompletionFocused_Run01'
NAMING = HERE / 'Excel/ToolProbeNaming'
CURRENT = 'B23D48898C60F44C0AFB10EF52617277C8442E08C8FAFFAEA3F4B61629A0AEC9'
OLD = 'A1688F6EC7D7B62B46103AAF591C73C99C60348C1ED4629008B4424C34F06A5A'
DUMP = '55711608D8C1E6AECA7D65BF20EB74071CE2EE0A1AACA3A4B940390146E49924'
FOREIGN = 'C3E3C907F5F8B634D4ECBD1218F1EC3BDAD6F9FE807744D4845D62D06ABA978E'


def read(path):
    return json.loads(path.read_text('utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    destination = HERE / 'CompletionDecision.json'
    assert not destination.exists(), 'Preserve previous decision'
    core = read(CORE / 'Summary.json')
    combined = read(CORE / 'Focused/CombinedAcceptance.json')
    assert core['status'] == combined['Status'] == 'PASS'
    assert combined['SourceSHA256'] == OLD and core['sourceSHA256'].upper() == OLD
    assert core['completedSuites'] == combined['CoreSuites'] == 156
    assert core['failedAssertions'] == 0 and combined['CorePassedAssertions'] == 534712
    assert combined['FocusedSingleCases'] == 122 and combined['FocusedPassedAssertions'] == 13952
    assert combined['IndependentIntegrals'] == 560 and combined['SameWorkbookBytes']
    focused = read(FOCUSED / 'Acceptance.json')
    assert focused['Status'] == 'PASS' and focused['SourceSHA256'] == CURRENT
    assert focused['IndividualCases'] == 122 and focused['PassedAssertions'] == 13952
    assert len(focused['Stages']) == 19 and all(x['Passed'] for x in focused['Stages'])
    focused_run = read(FOCUSED / 'Run.json')
    assert len(focused_run['Records']) == 26 and focused_run['ProtectedInputsUnchanged']
    assert all(record['Passed'] for record in focused_run['Records'])
    independent = read(FOCUSED / 'Independent.json')
    assert independent['Passed'] and independent['SourceSHA256'] == CURRENT
    assert independent['IndependentIntegrals'] == 560 and independent['ReviewedNumFailStates'] == 10
    assert not focused['Errors']
    integrity = read(HERE / 'CompletionFocusedFinalIntegrity.json')
    assert integrity['ChangedScripts'] == integrity['ChangedComponents'] == 0
    assert all(integrity[k] for k in ('SourceMatches', 'PublishedMatches', 'DumpMatches'))
    native_path = NAMING / 'CompileOnlyContexts/Native_RootNative02/Progress.json'
    native = read(native_path)
    assert native['AllCompiled'] and native['NoVbaEntrypointExecuted']
    assert len(native['Cases']) == 23 and native['SourceSHA256'] == CURRENT
    for case in native['Cases']:
        assert case['Passed'] and not case['TimedOut'] and case['ExitCode'] == 0
        result = read(Path(case['Result']))
        assert result['Compiled'] and not result['Failure']
        assert not result['Saved'] and not result['VbaEntrypointExecuted']
        assert result['SourceUnchanged'] and result['ProtectedUnchanged']
    legacy = read(NAMING / 'LegacyToolClosureProof.json')
    assert legacy['MethodCount'] == 81 and legacy['All81NamesHeadersDividersPassed']
    assert legacy['All77OwnRenamesIndependentlyReviewed']
    rectangles = []
    for mode in ('No', 'Yes'):
        report = ROOT / f'docs/regression/Rect23_{mode}02.txt'
        metadata = read(Path(str(report) + '.json'))
        text = report.read_text('utf-8-sig')
        total = re.search(r'TOTAL_RECTANGLES_OFFSET: passed=(\d+); failed=0\b', text)
        assert total and not re.search(r'(?m)^FAIL:|RUNTIME ERROR|WATCHDOG_FAILURE', text)
        assert metadata['Compiled'] and metadata['ExitCode'] == 0
        assert metadata['SourceSHA256'] == CURRENT and metadata['Mode'] == mode
        assert all(metadata[k] for k in ('SourceUnchanged', 'PrivateUnchanged', 'ProtectedUnchanged'))
        rectangles.append({'Mode': mode, 'PassedAssertions': int(total.group(1)),
                           'Report': report.relative_to(ROOT).as_posix(), 'SHA256': digest(report)})
    coverage = read(HERE / 'CompletionCoverageProof.json')
    assert coverage['AllPassed']
    matrix = read(HERE / 'CompletionMatrixFinal.json')
    assert matrix['MatrixRowCount'] == len(matrix['Rows']) == 12
    assert digest(ROOT / 'workbook/output/RC_Section_NDM.xlsm') == CURRENT
    assert digest(ROOT / 'workbook/output/VBA_All_Code.txt') == DUMP
    assert digest(ROOT / 'workbook/output/RC_Section_NDM_execution_report.txt') == FOREIGN
    assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'src', 'tests',
                                       'workbook/output/RC_Section_NDM.xlsm',
                                       'workbook/output/VBA_All_Code.txt'], cwd=ROOT).strip()
    data = {
        'Status': 'AUDIT_COMPLETED_WITH_VERSIONED_ACCEPTANCE', 'RequiredWorkComplete': True,
        'AtUTC': datetime.now(timezone.utc).isoformat(), 'NewFocusedStatus': focused['Status'],
        'PublishedSourceCommit': '26aeba586d84d19b877f6c00bb4a7e4b15dbb72f',
        'PublishedSHA256': CURRENT, 'PublishedDumpSHA256': DUMP,
        'FullRun': {'SHA256': OLD, 'Status': 'PASS', 'CoreSuites': 156,
                    'CorePassedAssertions': 534712, 'FocusedCases': 122,
                    'FocusedPassedAssertions': 13952, 'IndependentIntegrals': 560,
                    'HistoricalFailuresPreserved': True},
        'CurrentBookFocused': {'SHA256': CURRENT, 'Status': 'PASS', 'Cases': 122,
                              'PassedAssertions': 13952, 'RunRecords': 26, 'AssertionStages': 19,
                              'ElapsedSeconds': focused['ElapsedSeconds']},
        'CurrentBookDirectedEachMode': {'PlotAndAnnotations': 4305,
                                       'AdditionalLinearCases': 130, 'PlotFallback': 36},
        'ExternalTools': {'Methods': 81, 'RenamedMethods': 77, 'CompiledContexts': 23,
                          'CompileOnlyWasNotRuntimeAcceptance': True,
                          'CurrentRectanglesRuntime': rectangles,
                          'HistoricalMissingFixturesExplicitlyArchived': True},
        'MatrixRows': 12, 'CoverageProof': 'CompletionCoverageProof.json',
        'MatrixProof': 'CompletionMatrixFinal.json', 'ForeignReportUnchanged': True,
        'Limits': ['Full 156-suite PASS belongs to A168, not B23.',
                   'B23 has the UI-only delta plus affected ON/OFF and a fresh full focused plan.',
                   'No universal absence-of-defects or final normative verification is claimed.',
                   'Full mesh/rebar translation checked to 1e10 mm; 1e12 is area orientation only.',
                   'Permanent COM failure, VBE Reset/End or process kill can bypass cleanup.'],
        'PermanentMonitoring': 'ACTIVE; do not disable without explicit user request',
    }
    destination.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'Status': data['Status'], 'RequiredWorkComplete': True,
                      'CurrentRectanglesRuntime': rectangles}))


if __name__ == '__main__':
    main()
