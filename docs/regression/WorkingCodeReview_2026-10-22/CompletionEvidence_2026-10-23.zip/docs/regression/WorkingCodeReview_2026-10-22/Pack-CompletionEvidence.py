"""Сохраняет выбранные проверяемые доказательства без приватных книг и чужих outputs."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CORE = ROOT / 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run02'
FOCUSED = ROOT / 'docs/regression/WorkingCodeReview_2026-10-23_CompletionFocused_Run01'
read = lambda p: json.loads(p.read_text('utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest().upper()


def main():
    final = read(HERE / 'CompletionDecision.json')
    assert final['RequiredWorkComplete'] and final['NewFocusedStatus'] == 'PASS'
    assert read(CORE / 'Summary.json')['status'] == 'PASS'
    assert read(FOCUSED / 'Acceptance.json')['Status'] == 'PASS'
    archive = HERE / 'CompletionEvidence_2026-10-23.zip'
    sidecar = archive.with_suffix('.json')
    assert not archive.exists() and not sidecar.exists(), 'Preserve existing evidence'
    files = set()

    def add(path, required=True):
        assert path.resolve().is_relative_to(ROOT)
        if not path.is_file():
            assert not required, str(path)
            return
        assert path.suffix.lower() != '.xlsm' and not path.is_relative_to(ROOT / 'outputs')
        assert path.name != 'RC_Section_NDM_execution_report.txt'
        files.add(path)

    for name in ('CompletionDecision.json', 'CompletionCoverageProof.json', 'CompletionMatrixFinal.json',
                 'CompletionFocusedLaunch.json', 'FullLaunchRun02.json', 'Run02Core156Receipt.json',
                 'CompletionFocusedMonitor.jsonl', 'CompletionFocusedFinalIntegrity.json',
                 'CompletionReleaseRunnerAdaptation.json', 'Finalize-CompletionDecision.py',
                 'Finalize-CompletionDirected.py', 'Run-CompletionProbes.ps1', 'Launch-CompletionFocused.ps1',
                 'Pack-CompletionEvidence.py'):
        add(HERE / name)
    for label in ('CompletionDirectedOff01', 'CompletionDirectedOff03', 'CompletionDirectedOff04',
                  'CompletionCandidateOff05', 'CompletionReleasePlotOff01', 'CompletionReleasePlotOn01',
                  'CompletionFallbackOff01', 'CompletionFallbackOn01'):
        add(HERE / (label + '_Probes.json'))
    for name in ('CleanCompile.json', 'RepoManifest.json', 'PartPreservation.json', 'DirectedAcceptance.json',
                 'Publication.json', 'ActualReleaseVBA.txt.ReadOnly.json', 'SourceProof01/NativeSourceEquality.json',
                 'SourceProof01/ProofSelfChecks.json', 'SourceProof01/VbeNumericCanonicalization.json'):
        add(HERE / 'CompletionRelease01' / name)
    for file in (HERE / 'CompletionProbes05').glob('*.bas'):
        add(file)
    for name in ('SeriesGapPhysicalFixtureProof.json', 'PlotSeriesFallbackReview.json'):
        add(HERE / 'Geometry' / name)
    add(HERE / 'Math/InactiveLinearGapTestPlan.json')
    naming = HERE / 'Excel/ToolProbeNaming'
    add(naming / 'Run-ToolProbeCompileOnlyShort.ps1')
    for name in ('ToolProbeNamingPlan.json', 'ToolProbeNamingReview.json', 'OfflineCompatibilityProof.json',
                 'FinalToolNamingAudit.json', 'ApplyAndProveToolProbeNaming.py', 'RootApply01/Proof.json'):
        add(naming / name)
    # Поздние отдельные исправления legacy-сценариев имеют свои proof/context-файлы.
    for file in naming.rglob('*'):
        if file.is_file() and file.suffix in ('.json', '.txt') and not any(p in ('Before', 'After') for p in file.relative_to(naming).parts):
            add(file)
    for label in ('Rect23_No', 'Rect23_No02', 'Rect23_Yes02'):
        report = ROOT / 'docs/regression' / (label + '.txt')
        add(report, required=label != 'Rect23_No')
        add(Path(str(report) + '.json'))
        for name in ('Preparation.json', 'OwnExcel.json', 'Prepare.stderr.log', 'Prepare.stdout.log'):
            add(Path(str(report) + '.fixture') / name)
    for directory in (CORE, CORE / 'Focused', FOCUSED):
        for file in directory.iterdir():
            if file.is_file() and (file.suffix == '.json' or file.suffix == '.bas' or
                                  file.suffix == '.ps1' or (file.suffix == '.txt' and not file.name.endswith(('.stdout.log', '.stderr.log')))):
                add(file)
    for directory in (CORE / 'Focused', FOCUSED):
        for name in ('Probe/Preparation.json', 'Probe/InputManifest.json', 'NativeCAD/Stage.json'):
            add(directory / name)
        for file in (directory / 'NativeCAD').rglob('*'):
            if file.is_file() and file.suffix in ('.json', '.txt', '.ps1'):
                add(file)
    manifest = []
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as output:
        for file in sorted(files):
            relative = file.relative_to(ROOT).as_posix()
            raw = file.read_bytes()
            output.writestr(relative, raw)
            manifest.append({'Path': relative, 'Bytes': len(raw), 'SHA256': sha(raw)})
        metadata = {'Status': 'SELECTED_COMPLETION_EVIDENCE', 'Files': manifest,
                    'Meaning': 'Compact review evidence. Large private source/probe workbooks remain locally; production releases are in Git. Foreign outputs are excluded.'}
        output.writestr('MANIFEST.json', json.dumps(metadata, ensure_ascii=False, indent=2).encode('utf-8'))
    with ZipFile(archive) as check:
        assert check.testzip() is None
        assert len(check.namelist()) == len(manifest) + 1
        assert all(sha(check.read(item['Path'])) == item['SHA256'] for item in manifest)
    result = {'Status': 'ARCHIVE_INTEGRITY_PASS', 'ArchiveSHA256': sha(archive.read_bytes()),
              'Bytes': archive.stat().st_size, 'Files': len(manifest), 'AllEntriesSHA256Checked': True,
              'NoPrivateWorkbooksOrForeignOutputs': True, 'Manifest': manifest}
    sidecar.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'Manifest'}))


if __name__ == '__main__':
    main()
