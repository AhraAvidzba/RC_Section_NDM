"""Проверяет фактические адресные ON/OFF на чистом UI-кандидате; не общий полный PASS."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DIRECTORY = HERE / 'CompletionRelease01'
read = lambda p: json.loads(p.read_text('utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest().upper()


def totals(probe, expected):
    body = probe['Actual']
    assert not re.search(r'(?mi)^(?:FAIL:|RUNTIME ERROR|SCRIPT ERROR|RESTORE ERROR|CLEANUP ERROR|NOT_EXERCISED|SERIES_GAP_OBSERVATION_ERROR|METRICS_UNAVAILABLE|APPSTATE_RESTORE_ERROR)', body)
    actual = re.findall(r'(?m)^TOTAL[^\r\n]*?passed=(\d+);\s*failed=(\d+)', body)
    assert actual and tuple(map(int, actual[-1])) == (expected, 0)
    return {'Macro': probe['Macro'], 'Passed': expected, 'Failed': 0, 'Seconds': probe['Seconds']}


def main():
    target = DIRECTORY / 'DirectedAcceptance.json'
    assert not target.exists(), 'Never overwrite completed evidence'
    part = read(DIRECTORY / 'PartPreservation.json')
    source = read(DIRECTORY / 'SourceProof01/NativeSourceEquality.json')
    opened = read(DIRECTORY / 'ActualReleaseVBA.txt.ReadOnly.json')
    assert part['Status'] == 'VBA_ONLY_MERGE_PASS' and part['NonVBAPartsByteExact'] and part['PreservedParts'] == 111
    assert part['AllowedChangedParts'] == ['xl/vbaProject.bin'] and sha(Path(part['ReleaseWorkbook'])) == part['ReleaseSHA256']
    assert source['AllPassed'] and source['ActualNativeDumpVerified'] and source['NoExtrasOrPrivateProbeModules']
    assert source['ActualComponents'] == 170 and source['RepositoryComponents'] == 164 and source['DocumentComponents'] == 6
    assert sha(DIRECTORY / 'ActualReleaseVBA.txt') == source['DumpSHA256']
    assert opened['SourceSHA256'] == part['ReleaseSHA256'] and opened['ReadOnly'] and opened['Automatic'] and not opened['MacrosExecuted']
    for item in source['Checks']:
        assert sha(ROOT / item['Path']) == item['SourceSHA256']
    modes = {}
    for mode, label in [('No', 'Off'), ('Yes', 'On')]:
        path = HERE / ('CompletionReleasePlot' + label + '01_Probes.json')
        run = read(path)
        assert run['Status'] == 'PROBES_COMPLETED' and run['SourceUnchanged'] and run['PublishedUnchanged'] and not run['CleanupErrors']
        assert run['SourceSHA256'] == part['ReleaseSHA256'] and run['NoCodeImported'] and not run['Imports'] and run['DiagramExtension'] == mode
        assert [p['Macro'] for p in run['Probes']] == ['modTestPlotConfig.RunAudit03GeneralPlotTests', 'modTestPlotConfig.RunArbitraryAnnotationLayoutTests']
        normal = [totals(p, n) for p, n in zip(run['Probes'], [3377, 928])]
        fallback_path = HERE / ('CompletionFallback' + label + '01_Probes.json')
        fallback = read(fallback_path)
        assert fallback['Status'] == 'PROBES_COMPLETED' and fallback['SourceUnchanged'] and fallback['PublishedUnchanged'] and not fallback['CleanupErrors']
        assert fallback['SourceSHA256'] == part['ReleaseSHA256'] and fallback['OnlyTestModulesImported'] and not fallback['PrivateCandidateImported']
        assert fallback['DiagramExtension'] == mode and len(fallback['Probes']) == 3
        assert [p['Macro'] for p in fallback['Probes']] == ['modTestLinearPlanGaps.TestRunLinearPlanGapProbe', 'modTestPlotSeriesWorkflow.TestRunSeriesGapWorkflow', 'modTestPlotSeriesFallback.TestObserveSeriesFallback']
        linear = totals(fallback['Probes'][0], 130)
        observed = totals(fallback['Probes'][2], 36)
        workflow = fallback['Probes'][1]['Actual']
        assert 'SERIES_GAP_DRAW_COMPLETED: actualSeries=0' in workflow
        assert 'independentKeys=274; independentKeysMinus1pct=274; independentKeysPlus1pct=274' in workflow
        assert not any(word in workflow for word in ('OBSERVATION_ERROR', 'NOT_EXERCISED', 'METRICS_UNAVAILABLE', 'APPSTATE_RESTORE_ERROR'))
        assert fallback['Probes'][2]['Actual'].count('checkedElements=5272;') == 3
        modes[label] = {'NormalGroups': normal, 'NormalPassed': 4305, 'OnlyTestModuleProbes': [linear, observed],
                        'NormalEvidenceSHA256': sha(path), 'FallbackEvidenceSHA256': sha(fallback_path),
                        'RealElementsCheckedPerFallbackDraw': 5272, 'StableColors': 17, 'FallbackDraws': 3}
    result = {'Status': 'DIRECTED_ACCEPTANCE_PASS', 'FullAcceptanceClaimed': False, 'ReleaseSHA256': part['ReleaseSHA256'],
              'DumpSHA256': source['DumpSHA256'], 'GroupsPerMode': 2, 'Modes': modes, 'NoCodeImportedDuringDirectedTests': True,
              'FallbackImportedOnlyTestModules': True, 'SourceEqualitySHA256': sha(DIRECTORY / 'SourceProof01/NativeSourceEquality.json'),
              'PartPreservationSHA256': sha(DIRECTORY / 'PartPreservation.json'), 'All111NonVBAPartsPreserved': True,
              'NativeProbeModulesExcludedFromRelease': True, 'ReadyForPublication': True,
              'Meaning': 'Current UI-only patch is covered by directed ON/OFF; full156 PASS belongs to A168 and is retained separately.'}
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'Modes'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
