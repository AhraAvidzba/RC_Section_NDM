' ДЛЯ ТЕСТОВ: добавляется только в modTestBatchCalculation независимой копии.
' Использует штатную кнопку расчета, не меняя solver, материалы или допуски.

Public Sub CaptureFocusedCalculation(ByVal section As CSectionModel, ByVal batch As CBatchSectionCalculator)
    Set mFocusedSection = section
    Set mFocusedBatch = batch
End Sub

' ДЛЯ ТЕСТОВ: фиксирует состав без запуска НДС, Search и записи Results.
Public Function DescribeFocusedAcceptance(ByVal shapeName As String, ByVal groupName As String) As String
    Dim oldRebars As Variant
    oldRebars = ThisWorkbook.Worksheets("Сечения").UsedRange.Formula
    On Error GoTo Failed
    Dim oldSystem As Variant, settings As CSystemSettingsReader, units As CUnitSystem
    Dim section As CSectionModel, cases As Collection, item As Variant, output As String
    oldSystem = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange.Formula
    FocusedSelectGeometry shapeName
    Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    Set units = New CUnitSystem: units.LoadFromSettings settings
    Set section = BuildWorkbookSectionModel(ThisWorkbook, settings, units)
    Set cases = FocusedSelectedLoads(section, groupName)
    output = "FOCUSED_MANIFEST|shape=" & shapeName & "|group=" & groupName & "|cases=" & CStr(cases.Count) & _
        "|fibers=" & CStr(section.ConcreteCount) & "|rebars=" & CStr(section.RebarCount) & vbCrLf
    For Each item In cases
        output = output & "FOCUSED_INPUT|id=" & CStr(item(0)) & "|N=" & TestFormatNumberInvariant(CDbl(item(1))) & _
            "|Mx=" & TestFormatNumberInvariant(CDbl(item(2))) & "|My=" & TestFormatNumberInvariant(CDbl(item(3))) & _
            "|path=" & CStr(item(4)) & vbCrLf
    Next item
    output = output & "FOCUSED_MANIFEST_COMPLETE: no calculation executed" & vbCrLf
    GoTo Restore
Failed:
    output = output & "RUNTIME ERROR: " & CStr(Err.Number) & "; " & Err.Description
Restore:
    If IsArray(oldRebars) Then ThisWorkbook.Worksheets("Сечения").UsedRange.Formula = oldRebars
    If IsArray(oldSystem) Then ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange.Formula = oldSystem
    DescribeFocusedAcceptance = output
End Function

' ДЛЯ ТЕСТОВ: одна форма и выбранные нагрузки, без матрицы всех настроек.
Public Function RunFocusedAcceptanceCases(ByVal shapeName As String, ByVal groupName As String, _
        Optional ByVal selectedLoadName As String = "") As String
    On Error GoTo Failed
    Dim oldRebars As Variant
    oldRebars = ThisWorkbook.Worksheets("Сечения").UsedRange.Formula
    Dim stats As TBatchTestStats, oldSystem As Variant, oldProfiles As Variant, oldLoads As Variant
    Dim systemRange As Object, profileRange As Object, loadRange As Object
    Dim settings As CSystemSettingsReader, units As CUnitSystem, section As CSectionModel
    Dim cases As Collection, item As Variant, values() As Variant, path As String
    Dim start As Double, elapsed As Double, message As String, completed As Long, maxSeconds As Double
    Dim report As String, result As CCombinationResult, meta As Variant, prefix As String
    Set systemRange = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    Set profileRange = ThisWorkbook.Names.Item("rngCalculationProfiles").RefersToRange
    Set loadRange = ThisWorkbook.Names.Item("rngLoadCombinations").RefersToRange
    oldSystem = systemRange.Formula: oldProfiles = profileRange.Formula: oldLoads = loadRange.Formula
    FocusedSelectGeometry shapeName
    TestSetSystemSetting "Load.ReferenceOffsetX", "0"
    TestSetSystemSetting "Load.ReferenceOffsetY", "0"
    TestSetSystemSetting "Calculation.ZeroMomentPerDepth", "0"
    TestSetSystemSetting "General.ExecutionReportEnabled", "Yes"
    TestSetSystemSetting "SLS.Crack.Code", "SP35"
    TestSetSystemSetting "Plot.Enabled", "Yes"
    TestSetSystemSetting "Plot.AutoUpdateAfterCalculation", "Yes"
    TestSetSystemSetting "Plot.LoadCase", "Worst"
    TestSetProfileValue "Calculation.Strength.DirectState", "PR3", "Yes"
    TestSetProfileValue "Calculation.Strength.Capacity", "PR3", "Yes"
    TestSetProfileValue "Calculation.Crack.Width", "PR3", "Yes"
    TestSetProfileValue "Calculation.Stability.Enabled", "PR3", "No"
    TestSetProfileValue "Visualization.State", "PR3", "StrengthState"
    Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    Set units = New CUnitSystem: units.LoadFromSettings settings
    TestSetSystemSetting "Load.ReferenceOffsetX", TestFormatNumberInvariant(10# / units.InputLengthToInternal(1#))
    TestSetSystemSetting "Load.ReferenceOffsetY", TestFormatNumberInvariant(-7# / units.InputLengthToInternal(1#))
    settings.LoadFromWorkbook ThisWorkbook
    Set section = BuildWorkbookSectionModel(ThisWorkbook, settings, units)
    Set cases = FocusedSelectedLoads(section, groupName)
    If Len(selectedLoadName) > 0 Then
        Dim selected As New Collection
        For Each item In cases
            If CStr(item(0)) = selectedLoadName Then selected.Add item
        Next item
        If selected.Count <> 1 Then Err.Raise 5, , "Selected focused load was not found uniquely."
        Set cases = selected
    End If
    TestAppendLine stats, "FOCUSED_SETUP|shape=" & shapeName & "|group=" & groupName & "|mode=" & _
        settings.GetRequiredString("General.DiagramExtension") & "|cases=" & CStr(cases.Count) & _
        "|fibers=" & CStr(section.ConcreteCount) & "|rebars=" & CStr(section.RebarCount) & "|offsetX=10|offsetY=-7|profile=PR3|code=SP35"
    For Each item In cases
        prefix = "focused." & shapeName & "." & CStr(item(0))
        path = CStr(item(4)): If path <> "Auto" Then path = ChrW$(&H3BB) & "*" & path
        ReDim values(1 To loadRange.Rows.Count - 1, 1 To loadRange.Columns.Count)
        values(1, 1) = CStr(item(0))
        values(1, 2) = CDbl(item(1)) / units.InputForceToInternal(1#)
        values(1, 3) = CDbl(item(2)) / units.InputMomentMxToInternal(1#)
        values(1, 4) = CDbl(item(3)) / units.InputMomentMyToInternal(1#)
        values(1, 5) = "PR3": values(1, 6) = path
        loadRange.Offset(1, 0).Resize(loadRange.Rows.Count - 1, loadRange.Columns.Count).Value2 = values
        Set mFocusedBatch = Nothing: Set mFocusedSection = Nothing
        ResetSectionEquilibriumSolveCount
        start = Timer
        If CDbl(item(1)) = 0# And CDbl(item(2)) = 0# And CDbl(item(3)) = 0# Then
            FocusedCheckZeroInput stats, prefix
        Else
            message = TestFixtureRunSectionWorkflow(ThisWorkbook, False)
        End If
        elapsed = Timer - start: If elapsed < 0# Then elapsed = elapsed + 86400#
        If elapsed > maxSeconds Then maxSeconds = elapsed
        TestAssertTrue stats, prefix & ".within10Seconds", elapsed <= 10#
        TestAppendLine stats, "FOCUSED_TIME|shape=" & shapeName & "|id=" & CStr(item(0)) & _
            "|elapsedSec=" & TestFormatNumberInvariant(elapsed) & "|solverCalls=" & CStr(SectionEquilibriumSolveCount())
        If Not mFocusedBatch Is Nothing Then
            TestAssertTrue stats, prefix & ".oneCombination", mFocusedBatch.Count = 1
            TestAssertTrue stats, prefix & ".preparationReleased", mFocusedBatch.TestRunPreparationReleased
            ' ULS и SLS имеют отдельные точные кэши; устойчивость в этом профиле отключена.
            TestAssertTrue stats, prefix & ".mechanicalNoRepeatedMaterialPreparation", _
                mFocusedBatch.TestMechanicalPreparationBuildCount > 0 And mFocusedBatch.TestMechanicalPreparationBuildCount <= 2
            TestAssertTrue stats, prefix & ".crackDomainPreparedOnce", mFocusedBatch.TestCrackDomainBuildCount <= 1
            TestAppendLine stats, "FOCUSED_PREPARATION|id=" & CStr(item(0)) & _
                "|mechanicalBuilds=" & CStr(mFocusedBatch.TestMechanicalPreparationBuildCount) & _
                "|crackDomainBuilds=" & CStr(mFocusedBatch.TestCrackDomainBuildCount)
            Set result = mFocusedBatch.ResultAt(1)
            TestAudit03CheckResultComments stats, mFocusedBatch, 1
            Dim cx As Double, cy As Double, area As Double
            mFocusedSection.ConcreteMeshCentroid cx, cy, area
            TestAudit03CheckCapacityPath stats, result.StrengthResult.Capacity, prefix, CStr(item(4)), _
                Array(item(1), item(2), item(3)), cx, cy, True
            TestAudit03CheckFormationPath stats, result.CrackResult.Formation, prefix, path, Array(item(1), item(2), item(3))
            FocusedCheckStates stats, result, settings, units, prefix
            TestAppendLine stats, FocusedComparisonRecord(result, CStr(item(0)))
            For Each meta In Array(result.DirectStateMeta, result.CapacityMeta, result.CrackFormationMeta, _
                    result.CrackCurrentStateMeta, result.CrackWidthMeta, result.LongitudinalCrackMeta, result.OverallMeta)
                TestAssertTrue stats, prefix & ".noInputOrInternalError." & CStr(meta.ResultKind), _
                    meta.InternalStatus <> rsInvalidInput And meta.InternalStatus <> rsInvalidConfiguration And _
                    meta.InternalStatus <> rsInternalError
                If meta.InternalStatus = rsNumericalFailure Then TestAppendLine stats, _
                    "FOCUSED_UNRESOLVED|shape=" & shapeName & "|id=" & CStr(item(0)) & _
                    "|kind=" & CStr(meta.ResultKind) & "|reason=" & meta.ResultComment
            Next meta
            FocusedCheckOutputRow stats, "rngStrengthSummaryAnchor", CStr(item(0)), prefix
            FocusedCheckOutputRow stats, "rngCrackSummaryAnchor", CStr(item(0)), prefix
            TestAppendLine stats, "FOCUSED_RESULT|id=" & CStr(item(0)) & "|overall=" & result.Status & _
                "|capacity=" & result.StrengthResult.Capacity.Status & "|cracks=" & result.CrackSummaryStatus
        ElseIf CStr(item(0)) <> "zero" Then
            TestAssertTrue stats, prefix & ".capturedCalculation", False
        End If
        completed = completed + 1
        TestAudit03SaveMatrixProgress stats.Report
    Next item
    TestAssertTrue stats, "focused.complete", completed = cases.Count
    TestAppendLine stats, "TOTAL_FOCUSED_ACCEPTANCE: shape=" & shapeName & "; group=" & groupName & _
        "; cases=" & CStr(completed) & "; maxSeconds=" & TestFormatNumberInvariant(maxSeconds) & _
        "; passed=" & CStr(stats.Passed) & "; failed=" & CStr(stats.Failed)
    GoTo Restore
Failed:
    stats.Failed = stats.Failed + 1
    TestAppendLine stats, "FAIL: focused.runtime; " & CStr(Err.Number) & "; " & Err.Description
Restore:
    On Error GoTo RestoreFailed
    If IsArray(oldRebars) Then ThisWorkbook.Worksheets("Сечения").UsedRange.Formula = oldRebars
    If IsArray(oldSystem) Then systemRange.Formula = oldSystem
    If IsArray(oldProfiles) Then profileRange.Formula = oldProfiles
    If IsArray(oldLoads) Then loadRange.Formula = oldLoads
    Set mFocusedBatch = Nothing: Set mFocusedSection = Nothing
    RunFocusedAcceptanceCases = stats.Report
    Exit Function
RestoreFailed:
    RunFocusedAcceptanceCases = stats.Report & "RESTORE ERROR: " & CStr(Err.Number) & "; " & Err.Description
End Function

' ДЛЯ ТЕСТОВ: одинаковая запись чисел и typed-статусов для сравнения двух сборок.
Private Function FocusedComparisonRecord(ByVal result As CCombinationResult, ByVal id As String) As String
    Dim output As String, meta As Variant, numbers As Variant, i As Long
    output = "FOCUSED_COMPARE|id=" & id & "|path=" & result.StrengthResult.Capacity.PathResolved
    For Each meta In Array(result.DirectStateMeta, result.CapacityMeta, result.CrackFormationMeta, _
            result.CrackCurrentStateMeta, result.CrackWidthMeta, result.LongitudinalCrackMeta, result.OverallMeta)
        output = output & "|meta" & CStr(meta.ResultKind) & "=" & CStr(meta.InternalStatus) & ":" & CStr(meta.ResultCode)
    Next meta
    numbers = Array(result.StrengthResult.Capacity.LambdaCapacity, result.StrengthResult.Capacity.NUltimate, _
        result.StrengthResult.Capacity.MxUltimate, result.StrengthResult.Capacity.MyUltimate, _
        result.CrackResult.Formation.LambdaCrc, result.CrackResult.Formation.Ncrc, result.CrackResult.Formation.Mcrc, _
        result.CrackResult.Width.CrackWidth, result.CrackResult.Width.Utilization, result.CrackResult.Width.CrackSpacing, _
        result.CrackResult.Longitudinal.Utilization, result.GoverningUtil)
    For i = LBound(numbers) To UBound(numbers)
        output = output & "|number" & CStr(i) & "=" & Replace$(Trim$(Str$(CDbl(numbers(i)))), ",", ".")
    Next i
    FocusedComparisonRecord = output
End Function

' ДЛЯ ТЕСТОВ: воспроизводит один замер с теми же данными и проверками.
Public Function RunFocusedSingleLoad(ByVal shapeName As String, ByVal loadName As String) As String
    RunFocusedSingleLoad = RunFocusedAcceptanceCases(shapeName, "Generated", loadName)
End Function

' ДЛЯ ТЕСТОВ: генерируемые формы читаются настоящим реестром из Config.
Private Sub FocusedSelectGeometry(ByVal shapeName As String)
    Select Case shapeName
        Case "SavedWorkbook": TestSetSystemSetting "Geometry.Source", "AutoCAD"
        Case "Rectangles", "Circle", "PointedSection", "HollowRectangle"
            TestSetSystemSetting "Geometry.Source", "Generated"
            TestSetSystemSetting "Geometry.Type", shapeName
            ' Общая таблица не хранит четыре независимых набора армирования.
            ' Перед каждой формой задаём явный контрольный набор прежних исходных данных.
            TestFixtureResetReinforcement shapeName
        Case Else: Err.Raise 5, "FocusedSelectGeometry", "Unknown focused geometry: " & shapeName
    End Select
End Sub

' ДЛЯ ТЕСТОВ: выбирает нагрузки по именам, не по положению в старой матрице.
Private Function FocusedSelectedLoads(ByVal section As CSectionModel, ByVal groupName As String) As Collection
    Dim result As New Collection, item As Variant, path As Variant, names As Variant
    names = Array("axialSmall-1", "axialSmall1", "Mx-1", "Mx1", "My-1", "My1", "mixedC1_-1", "mixedT-1_1")
    If groupName = "Paths" Then
        For Each item In TestAudit03NormalizedLoads(section, "Light")
            If CStr(item(0)) = "mixedC1_-1" Then
                For Each path In Array("Auto", "Mx", "My", "Mxy", "N", "NMxy")
                    result.Add Array("path" & CStr(path), item(1), item(2), item(3), CStr(path))
                Next path
                Exit For
            End If
        Next item
        If result.Count <> 6 Then Err.Raise 5, , "Incomplete LoadPath selection."
    ElseIf groupName = "Generated" Or groupName = "Saved" Then
        If groupName = "Saved" Then names = Array("axialSmall-1", "axialSmall1", "Mx-1", "Mx1", "My-1", "My1", _
            "mixedC1_-1", "mixedT-1_1", "zero", "tinyMx1", "biaxial1_-1_10", "biaxial1_-1_1000000", "biaxial1_-1_" & CStr(0.000001))
        For Each item In TestAudit03NormalizedLoads(section, "Light")
            If FocusedNameIn(CStr(item(0)), names) Then result.Add Array(item(0), item(1), item(2), item(3), "Auto")
        Next item
        If groupName = "Saved" Then
            For Each item In TestAudit03NormalizedLoads(section, "Stress")
                If FocusedNameIn(CStr(item(0)), Array("axialC" & CStr(0.95), "axialC1", "axialC" & CStr(1.05), "axialC2", _
                        "overloadMixed1", "overloadMixed1000000")) Then _
                    result.Add Array(item(0), item(1), item(2), item(3), "Auto")
            Next item
            result.Add Array("N500", -500# * 9806.65, 0#, 0#, "Auto")
            result.Add Array("N1000", -1000# * 9806.65, 0#, 0#, "Auto")
            result.Add Array("N2098Plateau", -2098.694 * 9806.65, 0#, 0#, "Auto")
            result.Add Array("N500TinyMoment", -500# * 9806.65, 1#, 0#, "Auto")
            If result.Count <> 23 Then Err.Raise 5, , "Incomplete saved-load selection: " & CStr(result.Count)
        Else
            If result.Count <> 8 Then Err.Raise 5, , "Incomplete generated-load selection."
        End If
    Else
        Err.Raise 5, "FocusedSelectedLoads", "Unknown focused group: " & groupName
    End If
    Set FocusedSelectedLoads = result
End Function

Private Function FocusedNameIn(ByVal name As String, ByVal names As Variant) As Boolean
    Dim item As Variant
    For Each item In names
        If name = CStr(item) Then FocusedNameIn = True: Exit Function
    Next item
End Function

' ДЛЯ ТЕСТОВ: reader намеренно не запускает расчет для полностью нулевой строки.
Private Sub FocusedCheckZeroInput(ByRef stats As TBatchTestStats, ByVal prefix As String)
    On Error GoTo Rejected
    Dim message As String
    message = TestFixtureRunSectionWorkflow(ThisWorkbook, False)
    TestAssertTrue stats, prefix & ".zeroRejected", False
    Exit Sub
Rejected:
    Dim errorNumber As Long
    errorNumber = Err.Number: Err.Clear
    TestAssertTrue stats, prefix & ".zeroRejectedBeforeSolve", errorNumber = vbObjectError + 4101
    TestAssertTrue stats, prefix & ".zeroNoSolverCalls", SectionEquilibriumSolveCount() = 0
End Sub

' ДЛЯ ТЕСТОВ: повторное интегрирование по фактическим диаграммам каждого state.
Private Sub FocusedCheckStates(ByRef stats As TBatchTestStats, ByVal result As CCombinationResult, _
        ByVal settings As CSystemSettingsReader, ByVal units As CUnitSystem, ByVal prefix As String)
    Dim i As Long, state As CSectionStateResult, probe As CSectionSolver
    Dim n As Double, mx As Double, my As Double, cx As Double, cy As Double, area As Double
    Dim toleranceN As Double, toleranceMx As Double, toleranceMy As Double, extensionEnabled As Boolean
    toleranceN = Abs(units.InputForceToInternal(settings.GetDouble("Solver.ToleranceN")))
    toleranceMx = Abs(units.InputMomentMxToInternal(settings.GetDouble("Solver.ToleranceMx")))
    toleranceMy = Abs(units.InputMomentMyToInternal(settings.GetDouble("Solver.ToleranceMy")))
    extensionEnabled = settings.GetRequiredBoolean("General.DiagramExtension")
    mFocusedSection.ConcreteMeshCentroid cx, cy, area
    For i = 1 To result.StateRepository.StateCount
        Set state = result.StateRepository.StateAt(i)
        TestAppendLine stats, "FOCUSED_STATE|id=" & prefix & "|type=" & state.StateTypeText & _
            "|converged=" & CStr(state.Converged) & "|physical=" & CStr(state.WithinPhysicalRange) & _
            "|extension=" & CStr(state.ExtensionUsed) & "|status=" & state.Status & _
            "|N=" & FocusedExactNumber(state.TargetN) & "|Mx=" & FocusedExactNumber(state.TargetMx) & _
            "|My=" & FocusedExactNumber(state.TargetMy) & "|eps0=" & FocusedExactNumber(state.Epsilon0) & _
            "|kx=" & FocusedExactNumber(state.KappaX) & "|ky=" & FocusedExactNumber(state.KappaY)
        If state.Converged Then
            TestAssertTrue stats, prefix & ".snapshot." & CStr(i), state.HasMaterialSnapshot
            Set probe = New CSectionSolver
            probe.EvaluateStrainPlane mFocusedSection, state.ConcreteDiagramSnapshot, state.SteelDiagramSnapshot, _
                state.Epsilon0, state.KappaX, state.KappaY
            TestAssertClose stats, prefix & ".originalN." & CStr(i), probe.Nint, state.TargetN, toleranceN
            TestAssertClose stats, prefix & ".originalMx." & CStr(i), probe.Mxint, state.TargetMx, toleranceMx
            TestAssertClose stats, prefix & ".originalMy." & CStr(i), probe.Myint, state.TargetMy, toleranceMy
            probe.NumericalEfforts n, mx, my
            TestAssertClose stats, prefix & ".centerN." & CStr(i), n, state.TargetN, toleranceN
            TestAssertClose stats, prefix & ".centerMx." & CStr(i), mx, state.TargetMx - cy * state.TargetN, toleranceMx
            TestAssertClose stats, prefix & ".centerMy." & CStr(i), my, state.TargetMy - cx * state.TargetN, toleranceMy
            TestAssertTrue stats, prefix & ".physicalStatus." & CStr(i), _
                state.WithinPhysicalRange Or state.InternalStatus = rsCheckFailed
        Else
            TestAssertTrue stats, prefix & ".failureNotPhysical." & CStr(i), Not state.WithinPhysicalRange
        End If
        If Not extensionEnabled Then TestAssertTrue stats, prefix & ".noHiddenExtension." & CStr(i), Not state.ExtensionUsed
    Next i
End Sub

 ' ДЛЯ ТЕСТОВ: независимый интеграл использует полную точность сохранённой плоскости.
Private Function FocusedExactNumber(ByVal value As Double) As String
    Dim number As TFocusedDouble, words As TFocusedWords
    number.Value = value: LSet words = number
    FocusedExactNumber = "F64:" & Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

Private Sub FocusedCheckOutputRow(ByRef stats As TBatchTestStats, ByVal rangeName As String, _
        ByVal id As String, ByVal prefix As String)
    Dim anchor As Object
    Set anchor = ThisWorkbook.Names.Item(rangeName).RefersToRange.Cells(1, 1)
    TestAssertEquals stats, prefix & ".output." & rangeName, CStr(anchor.Value2), id
End Sub
