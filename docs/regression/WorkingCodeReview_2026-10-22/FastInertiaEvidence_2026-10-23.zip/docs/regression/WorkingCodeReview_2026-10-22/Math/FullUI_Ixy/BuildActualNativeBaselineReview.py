"""Read-only independent review of completed native baseline and Ixy proposal."""
from pathlib import Path
from decimal import Decimal, localcontext
import hashlib
import json
import math
import struct

ROOT = Path(__file__).resolve().parents[5]
HERE = Path(__file__).resolve().parent
CAPTURE = ROOT / 'docs/regression/WorkingCodeReview_2026-10-22/PostFullNativeBaseline01_Probes.json'
ORACLE = HERE / 'NativeBaselineExactOracle.json'
PATCH = HERE / 'CenteredMomentsProposal_NOT_APPLIED.patch'
EXPECTED_SOURCE = 'A3F2F4544820CB684139D25C8DA452A439B2AEBAE99B34A2570F422CA3D9C200'
D = Decimal.from_float


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def fields(line):
    result = {}
    for part in line.strip().split('|')[1:]:
        if '=' not in part:
            continue
        key, value = part.split('=', 1)
        if value.startswith('F64:'):
            value = struct.unpack('>d', bytes.fromhex(value[4:]))[0]
            assert math.isfinite(value)
        result[key] = value
    return result


def parse_models(text):
    models, current = [], None
    for line in text.splitlines():
        if line.startswith('IXY_MODEL|'):
            assert current is None
            current = {'Header': fields(line), 'Concrete': [], 'Steel': []}
        elif line.startswith('IXY_C|'):
            current['Concrete'].append(fields(line))
        elif line.startswith('IXY_S|'):
            current['Steel'].append(fields(line))
        elif line.startswith('IXY_PROPS|'):
            current['Native'] = fields(line)
        elif line == 'IXY_MODEL_END':
            assert len(current['Concrete']) == int(current['Header']['fibers'])
            assert len(current['Steel']) == int(current['Header']['bars'])
            models.append(current)
            current = None
    assert current is None and len(models) == 6
    return models


def independent_decimal(model):
    # Independent raw global first/second sums, then parallel-axis central check.
    # Unlike the supplied oracle, this does not sum centered terms for reference.
    with localcontext() as context:
        context.prec = 120
        ratio = D(model['Header']['Es']) / D(model['Header']['Eb']) - 1
        elements = [{k: D(v) for k, v in e.items()} for e in model['Concrete']]
        for bar in model['Steel']:
            a = D(bar['A'])
            own = ratio * a * a / (4 * D(math.pi))
            elements.append(dict(A=ratio * a, x=D(bar['x']), y=D(bar['y']),
                                 Ix=own, Iy=own, Ixy=Decimal(0)))
        zero = Decimal(0)
        area = sum((e['A'] for e in elements), zero)
        sx = sum((e['A'] * e['y'] for e in elements), zero)
        sy = sum((e['A'] * e['x'] for e in elements), zero)
        cx, cy = sy / area, sx / area
        ix = sum((e['Ix'] + e['A'] * e['y'] * e['y'] for e in elements), zero)
        iy = sum((e['Iy'] + e['A'] * e['x'] * e['x'] for e in elements), zero)
        ixy = sum((e['Ixy'] + e['A'] * e['x'] * e['y'] for e in elements), zero)
        return dict(A=area, Cx=cx, Cy=cy, Ix=ix, Iy=iy, Ixy=ixy,
                    Ixc=ix-area*cy*cy, Iyc=iy-area*cx*cx, Ixyc=ixy-area*cx*cy)


def neumaier(terms):
    total = correction = 0.0
    for value in terms:
        updated = total + value
        correction += ((total-updated)+value if abs(total) >= abs(value)
                       else (value-updated)+total)
        total = updated
    return total + correction


def independent_candidate(model):
    # Preserve the current binary64 first-pass A/S order exactly, as the patch.
    ratio = model['Header']['Es']/model['Header']['Eb']-1.0
    elements = [dict(e) for e in model['Concrete']]
    for e in model['Steel']:
        own = ratio * (e['A'] * e['A'] / (4.0 * math.pi))
        elements.append(dict(x=e['x'], y=e['y'], A=ratio*e['A'], Ix=own, Iy=own, Ixy=0.0))
    ox, oy = elements[0]['x'], elements[0]['y']
    a = sx = sy = 0.0
    for e in elements:
        x, y = e['x']-ox, e['y']-oy
        a = a + e['A']
        sx = sx + e['A']*y
        sy = sy + e['A']*x
    lx, ly = sy/a, sx/a
    cx, cy = ox+lx, oy+ly
    tx, ty, txy = [], [], []
    for e in elements:
        x, y = (e['x']-ox)-lx, (e['y']-oy)-ly
        tx.append(e['Ix']+e['A']*y*y)
        ty.append(e['Iy']+e['A']*x*x)
        txy.append(e['Ixy']+e['A']*x*y)
    ixc, iyc, ixyc = neumaier(tx), neumaier(ty), neumaier(txy)
    return dict(A=a, Cx=cx, Cy=cy, Ixc=ixc, Iyc=iyc, Ixyc=ixyc,
                Ix=ixc+a*cy*cy, Iy=iyc+a*cx*cx, Ixy=ixyc+a*cx*cy)


def main():
    cap = json.loads(CAPTURE.read_text(encoding='utf-8-sig'))
    oracle = json.loads(ORACLE.read_text(encoding='utf-8-sig'))
    assert cap['Status'] == 'PROBES_COMPLETED'
    assert cap['SourceSHA256'] == cap['SourceSHA256After'] == EXPECTED_SOURCE
    assert cap['PublishedSHA256'] == cap['PublishedSHA256After'] == EXPECTED_SOURCE
    assert cap['SourceUnchanged'] and cap['PublishedUnchanged']
    assert not cap['ProductionCodeChanged'] and not cap['PrivateCandidateImported']
    assert cap['OnlyTestModulesImported'] and not cap['CleanupErrors']
    assert oracle['NativeCaptureSHA256'] == sha(CAPTURE)
    for item in cap['Imports']:
        assert not item['Candidate']
        assert item['SHA256'] == sha(ROOT/item['Path'])
    probe = next(p for p in cap['Probes'] if p['Macro'] == 'modTestInputIxyBaseline.TestProbeInputIxy')
    assert 'TOTAL_INPUT_IXY_BASELINE: cases=6; passed=6; failed=0' in probe['Actual']
    assert 'FAIL:' not in probe['Actual']
    models = parse_models(probe['Actual'])
    checks, maxima = [], {}
    for model in models:
        h = model['Header']
        item = next(m for m in oracle['Models'] if m['Shape'] == h['shape'] and m['Stress'] == h['stress'])
        ref, candidate = independent_decimal(model), independent_candidate(model)
        assert item['Algorithms']['NativeCurrent'] == model['Native']
        assert all(candidate[k] == item['Algorithms']['CenteredSecondPassNeumaier'][k] for k in candidate)
        max_reference_delta = 0.0
        for algorithm, values in item['Errors'].items():
            for field, error in values.items():
                with localcontext() as context:
                    context.prec = 120
                    delta = abs(Decimal(error['DecimalReference']) - ref[field])
                    assert delta < Decimal('1e-70')
                    max_reference_delta = max(max_reference_delta, float(delta))
                key = algorithm + '.' + ('Central' if field.endswith('c') else 'Global')
                current = maxima.get(key, {})
                if error['ErrorInEpsTimesGlobalInertiaScale'] > current.get('EpsScale', -1):
                    maxima[key] = dict(Shape=h['shape'], Stress=h['stress'], Field=field,
                                       EpsScale=error['ErrorInEpsTimesGlobalInertiaScale'],
                                       AbsoluteError=abs(error['Error']))
        checks.append(dict(Shape=h['shape'], Stress=h['stress'], Fibers=len(model['Concrete']),
                           Bars=len(model['Steel']), Decimal120ReferenceMaxDelta=max_reference_delta,
                           Binary64CandidateExactlyMatches=True,
                           IxyNative=model['Native']['Ixy'], IxyCandidate=candidate['Ixy'],
                           DecimalIxy=str(ref['Ixy']), Eb=h['Eb'], Es=h['Es']))
    identical_arrays = []
    for shape in ('PointedSection', 'HollowRectangle'):
        subset = [m for m in models if m['Header']['shape'] == shape]
        assert all(m['Concrete'] == subset[0]['Concrete'] and m['Steel'] == subset[0]['Steel'] for m in subset)
        identical_arrays.append(dict(Shape=shape, AllThreeStressPhysicalArraysBitwiseEqual=True))
    pairs = [p for p in oracle['UnitPairs'] if p['Method'] in ('NativeCurrent', 'CenteredSecondPassNeumaier')]
    failures = {method: sum(not p['WithinExisting8Eps'] for p in pairs if p['Method'] == method)
                for method in ('NativeCurrent', 'CenteredSecondPassNeumaier')}
    assert failures == dict(NativeCurrent=4, CenteredSecondPassNeumaier=0)
    perf = next(p for p in cap['Probes'] if p['Macro'] == 'modTestIxyPerformance.TestProbeIxyPerformance')
    assert 'TOTAL_IXY_PERF_PROBE: cases=4; passed=4; failed=0' in perf['Actual']
    timings = []
    for line in perf['Actual'].splitlines():
        if line.startswith('IXY_PERF|'):
            f = fields(line)
            assert f['timersFinite'] == f['nonnegativeElapsed'] == 'True'
            assert int(f['actualPreparationBuildDelta']) == 3*int(f['iterations'])
            timings.append(dict(Case=f['case'], Fibers=int(f['fibers']), Bars=int(f['bars']),
                                MedianSecondsPerCall=float(f['medianSecondsPerCall']),
                                Iterations=int(f['iterations']), ActualBuildDelta=int(f['actualPreparationBuildDelta']),
                                MedianWindowMet=f['medianBlockWithin0.2To0.5Seconds'] == 'True'))
    result = dict(
        Status='REVIEW_COMPLETE_BASELINE_CONFIRMED_CANDIDATE_NATIVE_PENDING',
        NativeCapture=str(CAPTURE.relative_to(ROOT)), NativeCaptureSHA256=sha(CAPTURE),
        OracleSHA256=sha(ORACLE), ProposedPatchSHA256=sha(PATCH),
        SourceSHA256=EXPECTED_SOURCE, ProductionUnmodifiedBaseline=True,
        IndependentChecks=dict(DecimalPrecision=120, IndependentFormula='Raw global moment sums then parallel-axis central moments',
                               F64DecodedDirectly=True, ImportsHashesMatch=True, SourceAndPublishedUnchanged=True,
                               AllSixOracleModelsRecomputed=True, ModelChecks=checks,
                               PhysicalArrayIdentity=identical_arrays),
        ExistingUnitRoundtripContract=dict(Limit='8*2^-52*sqrt(abs(Ix))*sqrt(abs(Iy))',
                                          LimitsChanged=False, FailuresByMethod=failures, Pairs=pairs),
        AbsoluteOracleErrors=maxima,
        ResidualGlobalIyAssessment=dict(
            NewPerFieldDecimal8EpsGateIsNotAnAcceptedContract=True,
            Mechanism='First-pass A/S/local center and reconstructed public WCS centroid remain unchanged. The global Iy restored as Iyc+A*Cx^2 inherits its pre-existing centroid rounding. Central Iyc is far closer to Decimal; no raw Q-A*c*c cancellation remains.',
            ScopeDecision='Do not alter the proposal to compensate first-pass A/S or change the authoritative concrete/load reference center solely for a newly invented per-field gate.',
            NumericalConclusion='Existing unit-pair 8eps gate passes for all four predicted pairs; all global and central inertia formulas and signed weights remain the same mathematical quantities. This is not proof that every absolute Decimal error is below8eps.'),
        BaselinePerformance=dict(Cases=timings, WallSeconds=perf['Seconds'],
                                 CandidateTimingAvailable=False, CandidateBaselineRatio=None,
                                 Interpretation='Baseline kernel costs only. Dense positive block exceeded the target0.5s window; sufficient nonzero duration remains. No speedup, end-to-end gain, or candidate overhead is established.'),
        ProposalDecision=dict(ApplyReviewedPatchForPrivateNativeCandidate=True, ProposalChangeRequiredBeforeNative=False,
                              Why='Native F64 reproduces all four unit-pair failures on identical physical arrays; independent Decimal120 and binary64 replay confirm centered local two-pass Neumaier fixes them without reader/input/tolerance changes. Current A/S and public-center compatibility retained.',
                              NativeCandidateStillRequired=True,
                              Checks=['Same six F64 models and unchanged unit-pair8eps', 'Translated/rotated own-tensor and signed(n-1) regressions',
                                      'Actual native performance against these four baselines', 'Affected UI/geometry/units ON/OFF; original full FAIL retained']),
        WorkPerformedReadOnly=True, SrcTestsModified=False, ExcelExecuted=False,
        OverallAcceptanceClaimed=False)
    target = HERE/'ActualNativeBaselineReview.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(Report=str(target), Failures=failures, Decimal120='PASS',
                         ProposalChangeRequired=False, BaselineCases=len(timings)), ensure_ascii=False))


if __name__ == '__main__':
    main()
