Attribute VB_Name = "modTestInputIxyBaseline"
Option Explicit

' ======================================================================
' ДЛЯ ТЕСТОВ: неактивный probe для отдельной копии ПОСЛЕ полного прогона.
' Выгружает исходные элементы и свойства двух форм при трёх INPUT Stress.
' Не решает НДС, не записывает Results, не меняет рабочие формулы или допуски.
' ======================================================================

Private Type TTestIxyDouble
    Value As Double
End Type

Private Type TTestIxyWords
    Low As Long
    High As Long
End Type

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит шесть механических моделей без расчёта сочетаний. Входные таблицы
' возвращает целиком, включая формулы, при успехе и при ошибке probe.
Public Function TestProbeInputIxy() As String
    Dim names As Variant, name As Variant, old As Collection
    Dim shapes As Variant, shape As Variant, stresses As Variant, factors As Variant
    Dim stressIndex As Long, i As Long, cases As Long, key As String, row As Long, column As Long
    Dim table As Object, settings As CSystemSettingsReader, units As CUnitSystem
    Dim provider As CMaterialModelProvider, section As CSectionModel
    Dim props As CSectionPropertiesCalculator, eb As Double, es As Double
    Dim output As String, reason As String
    On Error GoTo Failed
    names = Array("rngSystemSettings", "rngUnitSettings", _
        "rngConcreteMaterialParameters", "rngSteelMaterialParameters")
    Set old = New Collection
    For Each name In names
        old.Add ThisWorkbook.Names.Item(CStr(name)).RefersToRange.Formula
    Next name
    shapes = Array("PointedSection", "HollowRectangle")
    stresses = Array("MPa", "kgf/cm2", "tf/m2")
    factors = Array(1#, 0.0980665, 0.00980665)
    For Each shape In shapes
        For stressIndex = 0 To 2
            For i = 0 To UBound(names)
                ThisWorkbook.Names.Item(CStr(names(i))).RefersToRange.Formula = old.Item(i + 1)
            Next i
            TestIxySetSystem "Geometry.Source", "Generated"
            TestIxySetSystem "Geometry.Type", CStr(shape)
            TestIxySetSystem "Mesh.StepX", 50#
            TestIxySetSystem "Mesh.StepY", 50#
            TestIxySetSystem "Mesh.BoundarySubdivisions", 1
            TestIxySetUnit "Length", "mm"
            TestIxySetUnit "Stress", CStr(stresses(stressIndex))
            For Each name In Array("rngConcreteMaterialParameters", "rngSteelMaterialParameters")
                Set table = ThisWorkbook.Names.Item(CStr(name)).RefersToRange
                For row = 2 To table.Rows.Count
                    key = CStr(table.Cells(row, 1).Value2)
                    If InStr(key, ".R") > 0 Or key = "Concrete.E" Or key = "Steel.E" Then
                        For column = 2 To 3
                            If IsNumeric(table.Cells(row, column).Value2) And Len(CStr(table.Cells(row, column).Value2)) > 0 Then _
                                table.Cells(row, column).Value2 = CDbl(table.Cells(row, column).Value2) / CDbl(factors(stressIndex))
                        Next column
                    End If
                Next row
            Next name
            Set settings = New CSystemSettingsReader
            settings.LoadFromWorkbook ThisWorkbook
            Set units = New CUnitSystem: units.LoadFromSettings settings
            Set provider = New CMaterialModelProvider: provider.Initialize settings, units
            Set section = BuildWorkbookSectionModel(ThisWorkbook, settings, units)
            eb = provider.ConcreteElasticModulusFromValueSet(mvsULS)
            es = provider.SteelElasticModulusFromValueSet(mvsULS)
            Set props = New CSectionPropertiesCalculator
            props.CalculateTransformedByModuli section, eb, es
            output = output & "IXY_MODEL|shape=" & CStr(shape) & "|stress=" & CStr(stresses(stressIndex)) & _
                "|Eb=" & TestIxyBits(eb) & "|Es=" & TestIxyBits(es) & _
                "|fibers=" & CStr(section.ConcreteCount) & "|bars=" & CStr(section.RebarCount) & vbCrLf
            TestIxyDumpProperties output, props
            TestIxyDumpElements output, section
            output = output & "IXY_MODEL_END" & vbCrLf
            cases = cases + 1
        Next stressIndex
    Next shape
    GoTo Restore
Failed:
    reason = CStr(Err.Number) & "; " & Err.Description
Restore:
    On Error GoTo RestoreFailed
    If Not old Is Nothing Then
        For i = 0 To old.Count - 1
            ThisWorkbook.Names.Item(CStr(names(i))).RefersToRange.Formula = old.Item(i + 1)
        Next i
    End If
    If Len(reason) > 0 Then
        output = output & "FAIL: inputIxy.probe.runtime; " & reason & vbCrLf
        output = output & "TOTAL_INPUT_IXY_BASELINE: cases=" & CStr(cases) & "; passed=0; failed=1"
    Else
        output = output & "TOTAL_INPUT_IXY_BASELINE: cases=" & CStr(cases) & "; passed=" & CStr(cases) & "; failed=0"
    End If
    TestProbeInputIxy = output
    Exit Function
RestoreFailed:
    TestProbeInputIxy = output & "FAIL: inputIxy.probe.restore; " & CStr(Err.Number) & "; " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Изменяет одну пользовательскую ячейку через текущий именованный диапазон.
Private Sub TestIxySetSystem(ByVal key As String, ByVal value As Variant)
    Dim table As Object, row As Long
    Set table = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    For row = 2 To table.Rows.Count
        If CStr(table.Cells(row, 1).Value2) = key Then
            table.Cells(row, 2).Value2 = value
            Exit Sub
        End If
    Next row
    Err.Raise vbObjectError + 4499, "modTestInputIxyBaseline", "Не найден ключ " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Назначает INPUT-единицу; OUTPUT не участвует в чтении модели этого probe.
Private Sub TestIxySetUnit(ByVal quantity As String, ByVal value As String)
    Dim table As Object, row As Long
    Set table = ThisWorkbook.Names.Item("rngUnitSettings").RefersToRange
    For row = 2 To table.Rows.Count
        If CStr(table.Cells(row, 1).Value2) = quantity Then
            table.Cells(row, 2).Value2 = value
            Exit Sub
        End If
    Next row
    Err.Raise vbObjectError + 4499, "modTestInputIxyBaseline", "Не найдена строка единиц " & quantity
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет все биты Double, чтобы Decimal-контроль не зависел от CStr.
Private Function TestIxyBits(ByVal value As Double) As String
    Dim number As TTestIxyDouble, words As TTestIxyWords
    number.Value = value: LSet words = number
    TestIxyBits = "F64:" & Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает физические центры, площади и собственные инерции без JSON/единиц вывода.
Private Sub TestIxyDumpElements(ByRef output As String, ByVal section As CSectionModel)
    Dim i As Long, ix As Double, iy As Double, ixy As Double
    For i = 1 To section.ConcreteCount
        section.ConcreteLocalInertiaComponents i, ix, iy, ixy
        output = output & "IXY_C|x=" & TestIxyBits(section.ConcreteX(i)) & _
            "|y=" & TestIxyBits(section.ConcreteY(i)) & "|A=" & TestIxyBits(section.ConcreteArea(i)) & _
            "|Ix=" & TestIxyBits(ix) & "|Iy=" & TestIxyBits(iy) & "|Ixy=" & TestIxyBits(ixy) & vbCrLf
    Next i
    For i = 1 To section.RebarCount
        output = output & "IXY_S|x=" & TestIxyBits(section.RebarX(i)) & _
            "|y=" & TestIxyBits(section.RebarY(i)) & "|A=" & TestIxyBits(section.RebarArea(i)) & vbCrLf
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает действующие глобальные и центральные свойства для сравнения алгоритмов.
Private Sub TestIxyDumpProperties(ByRef output As String, ByVal props As CSectionPropertiesCalculator)
    output = output & "IXY_PROPS|A=" & TestIxyBits(props.Area) & _
        "|Cx=" & TestIxyBits(props.CentroidX) & "|Cy=" & TestIxyBits(props.CentroidY) & _
        "|Ix=" & TestIxyBits(props.Ix) & "|Iy=" & TestIxyBits(props.Iy) & "|Ixy=" & TestIxyBits(props.Ixy) & _
        "|Ixc=" & TestIxyBits(props.Ixc) & "|Iyc=" & TestIxyBits(props.Iyc) & "|Ixyc=" & TestIxyBits(props.Ixyc) & _
        "|I1=" & TestIxyBits(props.PrincipalI1) & "|I2=" & TestIxyBits(props.PrincipalI2) & _
        "|Angle=" & TestIxyBits(props.PrincipalAngleRad) & vbCrLf
End Sub
