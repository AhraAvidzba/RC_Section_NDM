Attribute VB_Name = "modTestIxyPerformance"
Option Explicit

' ======================================================================
' ДЛЯ ТЕСТОВ: неактивный замер для копий старого и кандидатного VBA после full.
' Собирает одинаковые модели в памяти до замеров. Явно пересчитывает свойства,
' не вызывает Solver, Results, Excel IO и не меняет настройки приложения.
' ======================================================================

Private Const TEST_TARGET_BLOCK_SECONDS As Double = 0.25 ' Длинный блок уменьшает относительную погрешность Timer.
Private Const TEST_CALIBRATION_CAP_SECONDS As Double = 1.5 ' Soft cap между блоками; уже начатый вызов класса завершается.
Private Const TEST_MAX_ITERATIONS As Long = 16384 ' Защита от слишком большого числа сверхбыстрых повторений.
Private Const TEST_PROBE_CAP_SECONDS As Double = 30# ' Проверяется между блоками; один вызов класса не прерывается.

Private Type TTestIxyPerfDouble
    Value As Double
End Type

Private Type TTestIxyPerfWords
    Low As Long
    High As Long
End Type

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает стоимость четырёх пересчётов: малая/плотная сетка и Es/Eb выше/ниже 1.
' Один и тот же модуль запускается root-runner-ом отдельно в baseline и candidate.
Public Function TestProbeIxyPerformance() As String
    Dim started As Double, modelsBuilt As Double, output As String, reason As String
    Dim small As CSectionModel, dense As CSectionModel, model As CSectionModel
    Dim sizeIndex As Long, materialIndex As Long, cases As Long
    Dim es As Double, label As String, modelRevision As Long
    On Error GoTo Failed
    started = Timer
    Set small = TestIxyPerfBuildModel(20, 15)
    Set dense = TestIxyPerfBuildModel(300, 300)
    modelsBuilt = TestIxyPerfElapsed(started, Timer)
    output = "IXY_PERF_SETUP|smallFibers=" & CStr(small.ConcreteCount) & _
        "|denseFibers=" & CStr(dense.ConcreteCount) & "|bars=64|modelsBuiltOutsideMeasured=True" & _
        "|modelBuildSeconds=" & TestIxyPerfNumber(modelsBuilt) & _
        "|targetBlockSeconds=0.25|maxIterations=16384|probeSoftCapSeconds=30" & vbCrLf
    output = output & "IXY_PERF_MODEL|case=small|signature=" & TestIxyPerfModelSignature(small) & vbCrLf
    output = output & "IXY_PERF_MODEL|case=dense|signature=" & TestIxyPerfModelSignature(dense) & vbCrLf
    For sizeIndex = 0 To 1
        If sizeIndex = 0 Then Set model = small Else Set model = dense
        modelRevision = model.Revision
        For materialIndex = 0 To 1
            TestIxyPerfCheckBudget started
            If materialIndex = 0 Then es = 200000# Else es = 16250#
            label = IIf(sizeIndex = 0, "small", "dense") & IIf(materialIndex = 0, ".positive", ".signed")
            TestIxyPerfCase output, label, model, 32500#, es, started
            If model.Revision <> modelRevision Then Err.Raise vbObjectError + 4990, _
                "modTestIxyPerformance", "Пересчёт свойств изменил исходную модель."
            cases = cases + 1
        Next materialIndex
    Next sizeIndex
    output = output & "TOTAL_IXY_PERF_PROBE: cases=" & CStr(cases) & "; passed=" & CStr(cases) & _
        "; failed=0; totalSeconds=" & TestIxyPerfNumber(TestIxyPerfElapsed(started, Timer))
    TestProbeIxyPerformance = output
    Exit Function
Failed:
    reason = CStr(Err.Number) & "; " & Err.Description
    TestProbeIxyPerformance = output & "FAIL: ixy.performance.probe; " & reason & vbCrLf & _
        "TOTAL_IXY_PERF_PROBE: cases=" & CStr(cases) & "; passed=" & CStr(cases) & "; failed=1"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создаёт повёрнутую сетку прямоугольника 1000x600 и 64 стержня диаметром 16 мм без Excel и рецептов.
' Поворот 0.23 рад даёт ненулевой собственный Ixy; резерв исключает лишний рост массивов.
Private Function TestIxyPerfBuildModel(ByVal nx As Long, ByVal ny As Long) As CSectionModel
    Dim result As CSectionModel, ix As Long, iy As Long, i As Long
    Dim width As Double, height As Double, area As Double, x As Double, y As Double
    Dim angle As Double, c As Double, s As Double, barAngle As Double
    Set result = New CSectionModel
    result.SourceType = "TestIxyPerformance"
    result.ReserveElements nx * ny, 64
    width = 1000# / CDbl(nx): height = 600# / CDbl(ny): area = width * height
    angle = 0.23: c = Cos(angle): s = Sin(angle)
    For iy = 0 To ny - 1
        y = -300# + (CDbl(iy) + 0.5) * height
        For ix = 0 To nx - 1
            x = -500# + (CDbl(ix) + 0.5) * width
            result.AddConcreteElement 13.5 + c * x - s * y, -21.25 + s * x + c * y, area, _
                width:=width, height:=height, rotation:=angle, rotationKnown:=True
        Next ix
    Next iy
    For i = 0 To 63
        barAngle = 2# * GEOM_PI * CDbl(i) / 64#
        result.AddRebarElement 13.5 + 180# * Cos(barAngle), -21.25 + 180# * Sin(barAngle), 16#, 0#, "A400"
    Next i
    Set TestIxyPerfBuildModel = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прогревает класс, подбирает блок от 0.25 с и берёт медиану трёх равных блоков.
' В измеряемом цикле есть только явный CalculateTransformedByModuli и Next.
Private Sub TestIxyPerfCase(ByRef output As String, ByVal label As String, _
        ByVal model As CSectionModel, ByVal eb As Double, ByVal es As Double, ByVal probeStarted As Double)
    Dim props As CSectionPropertiesCalculator, iterations As Long, calibrationStarted As Double
    Dim seconds As Double, calibrationSeconds As Double, sample(1 To 3) As Double
    Dim sampleIndex As Long, beforeBuilds As Long, buildDelta As Long, median As Double
    Dim rawClassSeconds As Double, normalizedClassSeconds As Double
    Set props = New CSectionPropertiesCalculator
    props.CalculateTransformedByModuli model, eb, es
    props.CalculateTransformedByModuli model, eb, es
    iterations = 1: calibrationStarted = Timer
    Do
        TestIxyPerfCheckBudget probeStarted
        seconds = TestIxyPerfTimedBlock(props, model, eb, es, iterations)
        If seconds >= TEST_TARGET_BLOCK_SECONDS Then Exit Do
        If iterations >= TEST_MAX_ITERATIONS Or _
                TestIxyPerfElapsed(calibrationStarted, Timer) >= TEST_CALIBRATION_CAP_SECONDS Then _
            Err.Raise vbObjectError + 4991, "modTestIxyPerformance", "Калибровка не достигла 0.25 с в пределах cap; замер неполон."
        iterations = iterations * 2
    Loop
    calibrationSeconds = TestIxyPerfElapsed(calibrationStarted, Timer)
    beforeBuilds = props.TestPreparationBuildCount
    For sampleIndex = 1 To 3
        TestIxyPerfCheckBudget probeStarted
        sample(sampleIndex) = TestIxyPerfTimedBlock(props, model, eb, es, iterations)
        TestIxyPerfCheckBudget probeStarted
        If sample(sampleIndex) <= 0# Then Err.Raise vbObjectError + 4992, _
            "modTestIxyPerformance", "Измеряемый блок округлился в 0; сравнение скорости недостоверно."
    Next sampleIndex
    buildDelta = props.TestPreparationBuildCount - beforeBuilds
    If buildDelta <> iterations * 3 Then Err.Raise vbObjectError + 4993, _
        "modTestIxyPerformance", "Число явных пересчётов отличается от измеряемых вызовов."
    median = TestIxyPerfMedian(sample(1), sample(2), sample(3))
    rawClassSeconds = props.TestLastCalculationSeconds
    normalizedClassSeconds = TestIxyPerfElapsed(0#, rawClassSeconds)
    output = output & "IXY_PERF|case=" & label & "|fibers=" & CStr(model.ConcreteCount) & _
        "|bars=" & CStr(model.RebarCount) & "|Eb=" & TestIxyPerfNumber(eb) & "|Es=" & TestIxyPerfNumber(es) & _
        "|replacementFactor=" & TestIxyPerfNumber(es / eb - 1#) & "|warmupCalls=2|iterations=" & CStr(iterations) & _
        "|samples=3|calibrationSeconds=" & TestIxyPerfNumber(calibrationSeconds) & _
        "|sample1Seconds=" & TestIxyPerfNumber(sample(1)) & "|sample2Seconds=" & TestIxyPerfNumber(sample(2)) & _
        "|sample3Seconds=" & TestIxyPerfNumber(sample(3)) & "|medianSecondsPerCall=" & TestIxyPerfNumber(median / iterations) & _
        "|medianBlockWithin0.2To0.5Seconds=" & CStr(median >= 0.2 And median <= 0.5) & _
        "|actualPreparationBuildDelta=" & CStr(buildDelta) & "|timersFinite=True|nonnegativeElapsed=True" & _
        "|classLastSecondsRaw=" & TestIxyPerfNumber(rawClassSeconds) & _
        "|classLastSecondsNormalized=" & TestIxyPerfNumber(normalizedClassSeconds) & vbCrLf
    TestIxyPerfProperties output, label, props
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Измеряет только повторное вычисление реальным классом; Ensure/cache-входы не используются.
Private Function TestIxyPerfTimedBlock(ByVal props As CSectionPropertiesCalculator, ByVal model As CSectionModel, _
        ByVal eb As Double, ByVal es As Double, ByVal iterations As Long) As Double
    Dim i As Long, started As Double
    started = Timer
    For i = 1 To iterations
        props.CalculateTransformedByModuli model, eb, es
    Next i
    TestIxyPerfTimedBlock = TestIxyPerfElapsed(started, Timer)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Учитывает единственный переход через полночь в коротком probe; отрицательное время не публикуется.
Private Function TestIxyPerfElapsed(ByVal started As Double, ByVal finished As Double) As Double
    Dim result As Double
    If Not TestIxyPerfFinite(started) Or Not TestIxyPerfFinite(finished) Then _
        Err.Raise vbObjectError + 4994, "modTestIxyPerformance", "Таймер вернул неконечное значение."
    result = finished - started
    If result < 0# Then result = result + 86400#
    If Not TestIxyPerfFinite(result) Or result < 0# Then _
        Err.Raise vbObjectError + 4995, "modTestIxyPerformance", "Недопустимая длительность блока."
    TestIxyPerfElapsed = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ограничивает суммарное время между блоками. Не прерывает единственный вызов расчёта свойств.
Private Sub TestIxyPerfCheckBudget(ByVal started As Double)
    If TestIxyPerfElapsed(started, Timer) >= TEST_PROBE_CAP_SECONDS Then _
        Err.Raise vbObjectError + 4996, "modTestIxyPerformance", "Достигнут 30 с cap короткого performance probe."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает медиану без сортировки модели или дополнительных измеряемых проходов.
Private Function TestIxyPerfMedian(ByVal a As Double, ByVal b As Double, ByVal c As Double) As Double
    If a > b Then TestIxyPerfSwap a, b
    If b > c Then TestIxyPerfSwap b, c
    If a > b Then TestIxyPerfSwap a, b
    TestIxyPerfMedian = b
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет местами два результата измерений для медианы трёх блоков.
Private Sub TestIxyPerfSwap(ByRef a As Double, ByRef b As Double)
    Dim value As Double
    value = a: a = b: b = value
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет показатель IEEE754 до CStr/арифметики, поэтому NaN/Infinity не становятся замером.
Private Function TestIxyPerfFinite(ByVal value As Double) As Boolean
    Dim number As TTestIxyPerfDouble, words As TTestIxyPerfWords
    number.Value = value: LSet words = number
    TestIxyPerfFinite = ((words.High And &H7FF00000) <> &H7FF00000)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает точные биты конечного числа для последующего сравнения двух копий.
Private Function TestIxyPerfBits(ByVal value As Double) As String
    Dim number As TTestIxyPerfDouble, words As TTestIxyPerfWords
    If Not TestIxyPerfFinite(value) Then Err.Raise vbObjectError + 4997, _
        "modTestIxyPerformance", "Неконечное свойство модели."
    number.Value = value: LSet words = number
    TestIxyPerfBits = "F64:" & Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает компактное десятичное время без локальной запятой; свойства сохраняются отдельно в F64.
Private Function TestIxyPerfNumber(ByVal value As Double) As String
    If Not TestIxyPerfFinite(value) Then Err.Raise vbObjectError + 4997, _
        "modTestIxyPerformance", "Неконечное число в отчёте performance probe."
    TestIxyPerfNumber = Replace$(Trim$(Str$(value)), ",", ".")
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует параметры и крайние элементы модели вне замеров; совпавший код строит одинаковые данные.
Private Function TestIxyPerfModelSignature(ByVal model As CSectionModel) As String
    TestIxyPerfModelSignature = "grid1000x600,angle0.23,origin13.5_-21.25,ringR180d16n64" & _
        ",firstX=" & TestIxyPerfBits(model.ConcreteX(1)) & ",firstY=" & TestIxyPerfBits(model.ConcreteY(1)) & _
        ",lastX=" & TestIxyPerfBits(model.ConcreteX(model.ConcreteCount)) & _
        ",lastY=" & TestIxyPerfBits(model.ConcreteY(model.ConcreteCount)) & _
        ",firstArea=" & TestIxyPerfBits(model.ConcreteArea(1))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает конечный тензор, центр и checksum вне измеряемого блока; нулём Ixy не подменяется.
Private Sub TestIxyPerfProperties(ByRef output As String, ByVal label As String, ByVal props As CSectionPropertiesCalculator)
    Dim checksum As Double
    checksum = props.Area / 600000# + props.CentroidX / 1000# + props.CentroidY / 1000# + _
        props.Ixc / 10000000000# + props.Iyc / 10000000000# + props.Ixyc / 10000000000# + _
        props.PrincipalI1 / 10000000000# + props.PrincipalI2 / 10000000000#
    If props.Area <= 0# Or props.PrincipalI2 <= 0# Then Err.Raise vbObjectError + 4998, _
        "modTestIxyPerformance", "У performance fixture неположительная площадь или главная инерция."
    output = output & "IXY_PERF_PROPERTIES|case=" & label & "|checksum=" & TestIxyPerfBits(checksum) & _
        "|A=" & TestIxyPerfBits(props.Area) & "|Cx=" & TestIxyPerfBits(props.CentroidX) & "|Cy=" & TestIxyPerfBits(props.CentroidY) & _
        "|Ix=" & TestIxyPerfBits(props.Ix) & "|Iy=" & TestIxyPerfBits(props.Iy) & "|Ixy=" & TestIxyPerfBits(props.Ixy) & _
        "|Ixc=" & TestIxyPerfBits(props.Ixc) & "|Iyc=" & TestIxyPerfBits(props.Iyc) & "|Ixyc=" & TestIxyPerfBits(props.Ixyc) & _
        "|I1=" & TestIxyPerfBits(props.PrincipalI1) & "|I2=" & TestIxyPerfBits(props.PrincipalI2) & _
        "|angle=" & TestIxyPerfBits(props.PrincipalAngleRad) & vbCrLf
End Sub
