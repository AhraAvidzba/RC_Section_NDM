"""Read-only audit of completed native two-pass/one-pass captures.

No Excel execution, source changes or replacement of historical acceptance.
The Decimal oracle is diagnostic; the approved gate is the unit-pair comparison.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import hashlib
import json
import math
import struct
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[5]
EVIDENCE = ROOT / 'docs/regression/WorkingCodeReview_2026-10-22'
sys.path.insert(0, str(HERE.parent))
from BuildActualNativeBaselineReview import parse_models, independent_decimal
from BuildActualNativeCandidateReview import get_probe, get_perf, bit_equal
from AnalyzeNativeIxyArrays import numeric_algorithm

BASELINE = EVIDENCE / 'FastInertiaBaseline01_Probes.json'
CANDIDATE = EVIDENCE / 'FastInertiaCandidate02_Probes.json'
FAILED_HARNESS = EVIDENCE / 'FastInertiaCandidate01_Probes.json'
BASELINE_SOURCE = 'B23D48898C60F44C0AFB10EF52617277C8442E08C8FAFFAEA3F4B61629A0AEC9'
CANDIDATE_SOURCE = '8E1A22F6A50539CA6FDB3AF9EBE9D8BF7D8CC3CD81156461159D451F94784040'
EPS = 2.0**-52
ENGINEERING_RELATIVE = 1.0e-9
FIELDS = ('Ix', 'Iy', 'Ixy', 'Ixc', 'Iyc', 'Ixyc')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def relative(path):
    return path.relative_to(ROOT).as_posix()


def validate_capture(path, source):
    data = read(path)
    assert data['Status'] == 'PROBES_COMPLETED', 'Only terminal successful captures may be compared'
    assert data['SourceSHA256'] == data['SourceSHA256After'] == data['ExpectedSourceSHA256'] == source
    assert data['PublishedSHA256'] == data['PublishedSHA256After'] == BASELINE_SOURCE
    assert data['SourceUnchanged'] and data['PublishedUnchanged']
    assert data['OnlyTestModulesImported'] and not data['PrivateCandidateImported']
    assert not data['ProductionCodeChanged'] and not data['CleanupErrors']
    for item in data['Imports']:
        assert not item['Candidate']
        assert item['SHA256'] == sha(ROOT / item['Path'])
    return data


def input_hash(model):
    """Hash every input float as IEEE754 bytes, including signed zero and moduli."""
    digest = hashlib.sha256()
    for key in ('Eb', 'Es'):
        digest.update(key.encode('ascii') + struct.pack('>d', model['Header'][key]))
    count = 2
    for kind in ('Concrete', 'Steel'):
        digest.update(kind.encode('ascii'))
        digest.update(struct.pack('>Q', len(model[kind])))
        for element in model[kind]:
            for key in sorted(element):
                digest.update(key.encode('ascii') + struct.pack('>d', element[key]))
                count += 1
    return digest.hexdigest().upper(), count


def decimal_error(value, reference):
    with localcontext() as context:
        context.prec = 120
        return float(Decimal.from_float(value) - reference)


def compare_models(before, after):
    assert len(before) == len(after) == 6
    checks, extrema = [], {}
    for left, right in zip(before, after):
        assert left['Header'] == right['Header']
        lh, count = input_hash(left)
        rh, other_count = input_hash(right)
        assert lh == rh and count == other_count
        for field in ('A', 'Cx', 'Cy'):
            assert bit_equal(left['Native'][field], right['Native'][field])
        reference = independent_decimal(right)
        replay_input = dict(Header=right['Header'], Concrete=right['Concrete'], Steel=right['Steel'])
        replay = numeric_algorithm(replay_input)
        result = {}
        for version, model in (('BaselineTwoPass', left), ('CandidateOnePass', right)):
            errors = {}
            for field in FIELDS:
                suffix = 'c' if field.endswith('c') else ''
                scale = math.sqrt(abs(model['Native']['Ix'+suffix])) * math.sqrt(abs(model['Native']['Iy'+suffix]))
                error = decimal_error(model['Native'][field], reference[field])
                errors[field] = dict(Actual=model['Native'][field], Decimal120Reference=str(reference[field]),
                                     NativeMinusDecimal=error, RelativeToInertiaScale=abs(error)/scale,
                                     EpsTimesInertiaScale=abs(error)/(EPS*scale), InertiaScale=scale)
                scope = version + ('.Central' if suffix else '.Global')
                if errors[field]['RelativeToInertiaScale'] > extrema.get(scope, {}).get('RelativeToInertiaScale', -1):
                    extrema[scope] = dict(Shape=right['Header']['shape'], Stress=right['Header']['stress'],
                                         Field=field, **errors[field])
            result[version] = errors
        checks.append(dict(Shape=right['Header']['shape'], Stress=right['Header']['stress'],
                           ConcreteCount=len(right['Concrete']), RebarCount=len(right['Steel']),
                           InputF64SHA256=lh, InputFloatFields=count,
                           AllInputArraysAndModuliBitwiseEqual=True, NativeAreaAndCentersBitwiseEqual=True,
                           Errors=result,
                           OnePassBinary64Replay={k: dict(Replay=replay[k], Native=right['Native'][k],
                                                        NativeMinusReplay=right['Native'][k]-replay[k]) for k in FIELDS}))
    return checks, extrema


def unit_pairs(models, label):
    result = []
    for shape in ('PointedSection', 'HollowRectangle'):
        expected = next(m for m in models if m['Header']['shape'] == shape and m['Header']['stress'] == 'MPa')
        for actual in models:
            if actual['Header']['shape'] != shape or actual['Header']['stress'] == 'MPa':
                continue
            for field in ('Ixy', 'Ixyc'):
                suffix = 'c' if field.endswith('c') else ''
                scale = math.sqrt(abs(expected['Native']['Ix'+suffix]))*math.sqrt(abs(expected['Native']['Iy'+suffix]))
                difference = abs(actual['Native'][field]-expected['Native'][field])
                generic = ENGINEERING_RELATIVE*(1+abs(expected['Native'][field]))
                historical = max(generic, 8*EPS*scale)
                engineering = max(generic, ENGINEERING_RELATIVE*scale)
                result.append(dict(Version=label, Shape=shape, Stress=actual['Header']['stress'], Field=field,
                                   Expected=expected['Native'][field], Actual=actual['Native'][field],
                                   AbsoluteDifference=difference, RelativeToInertiaScale=difference/scale,
                                   Historical8EpsFloor=8*EPS*scale, HistoricalEffectiveLimit=historical,
                                   WithinHistorical8Eps=difference <= historical,
                                   Engineering1e9Floor=ENGINEERING_RELATIVE*scale,
                                   EngineeringEffectiveLimit=engineering, WithinApprovedEngineeringGate=difference <= engineering))
    assert len(result) == 8
    return result


def performance(baseline, candidate):
    bt, bs, bp = get_perf(baseline)
    ct, cs, cp = get_perf(candidate)
    assert bs == cs
    result = []
    for case, before in bt.items():
        after = ct[case]
        for field in ('fibers', 'bars', 'Eb', 'Es', 'replacementFactor', 'warmupCalls'):
            assert before[field] == after[field]
        for field in ('A', 'Cx', 'Cy'):
            assert bit_equal(bp[case][field], cp[case][field])
        slow, fast = float(before['medianSecondsPerCall']), float(after['medianSecondsPerCall'])
        assert slow > 0 and fast > 0
        changes = {}
        for field in FIELDS:
            suffix = 'c' if field.endswith('c') else ''
            scale = math.sqrt(abs(bp[case]['Ix'+suffix]))*math.sqrt(abs(bp[case]['Iy'+suffix]))
            delta = cp[case][field]-bp[case][field]
            changes[field] = dict(Baseline=bp[case][field], Candidate=cp[case][field],
                                  CandidateMinusBaseline=delta, RelativeToInertiaScale=abs(delta)/scale)
        result.append(dict(Case=case, Fibers=int(before['fibers']), Bars=int(before['bars']),
                           BaselineTwoPassMilliseconds=1000*slow, CandidateOnePassMilliseconds=1000*fast,
                           SavedMillisecondsPerRebuild=1000*(slow-fast), CandidateOverBaseline=fast/slow,
                           KernelSpeedup=slow/fast, PercentTimeReduction=100*(1-fast/slow),
                           BaselineIterations=int(before['iterations']), CandidateIterations=int(after['iterations']),
                           BaselineSampleMilliseconds=[1000*float(before['sample'+str(i)+'Seconds'])/int(before['iterations']) for i in (1,2,3)],
                           CandidateSampleMilliseconds=[1000*float(after['sample'+str(i)+'Seconds'])/int(after['iterations']) for i in (1,2,3)],
                           BaselineTargetWindowMet=before['medianBlockWithin0.2To0.5Seconds'] == 'True',
                           CandidateTargetWindowMet=after['medianBlockWithin0.2To0.5Seconds'] == 'True',
                           NativeAreaAndCentersBitwiseEqual=True, NativePropertyDeltas=changes))
    return result


def main():
    baseline, candidate = validate_capture(BASELINE, BASELINE_SOURCE), validate_capture(CANDIDATE, CANDIDATE_SOURCE)
    shared = {item['Name']: item for item in baseline['Imports']}
    assert all(next(i for i in candidate['Imports'] if i['Name'] == name) == item for name, item in shared.items())
    equality_path = EVIDENCE/'FastInertiaRelease01/SourceProof01/NativeSourceEquality.json'
    equality = read(equality_path)
    assert equality['AllPassed'] and equality['ActualNativeDumpVerified'] and equality['ActualComponents'] == 170
    assert equality['NoExtrasOrPrivateProbeModules']
    for item in equality['Checks']:
        assert item['Passed'] and item['SourceSHA256'] == sha(ROOT/item['Path'])
    assert sha(Path(equality['Dump'])) == equality['DumpSHA256']
    preservation_path = EVIDENCE/'FastInertiaRelease01/PartPreservation.json'
    preservation = read(preservation_path)
    assert preservation['SourceSHA256'] == BASELINE_SOURCE and preservation['ReleaseSHA256'] == CANDIDATE_SOURCE
    assert preservation['NonVBAPartsByteExact'] and preservation['PreservedParts'] == 111
    assert preservation['AllowedChangedParts'] == ['xl/vbaProject.bin']
    assert sha(Path(preservation['ReleaseWorkbook'])) == CANDIDATE_SOURCE
    bm = parse_models(get_probe(baseline, 'modTestInputIxyBaseline.TestProbeInputIxy')['Actual'])
    cm = parse_models(get_probe(candidate, 'modTestInputIxyBaseline.TestProbeInputIxy')['Actual'])
    for capture in (baseline, candidate):
        assert 'TOTAL_INPUT_IXY_BASELINE: cases=6; passed=6; failed=0' in get_probe(capture, 'modTestInputIxyBaseline.TestProbeInputIxy')['Actual']
    models, extrema = compare_models(bm, cm)
    pairs = unit_pairs(bm, 'BaselineTwoPass') + unit_pairs(cm, 'CandidateOnePass')
    assert all(p['WithinApprovedEngineeringGate'] for p in pairs)
    timings = performance(baseline, candidate)
    edge = get_probe(candidate, 'modTestFastInertiaEdges.TestRunFastInertiaEdges')
    assert 'TOTAL_FAST_INERTIA_EDGES: passed=880; failed=0' in edge['Actual']
    failed = read(FAILED_HARNESS)
    assert failed['Status'] == 'PROBE_ERROR' and failed['CompileLocation'].startswith('module=modTestFastInertiaEdges;')
    histories = {version: dict(Historical8EpsFailures=sum(not p['WithinHistorical8Eps'] for p in pairs if p['Version'] == version),
                              ApprovedEngineeringGateFailures=sum(not p['WithinApprovedEngineeringGate'] for p in pairs if p['Version'] == version))
                 for version in ('BaselineTwoPass', 'CandidateOnePass')}
    report = dict(
        Status='READ_ONLY_NATIVE_COMPARISON_COMPLETED', Scope='Directed property-kernel evidence; not full acceptance',
        BaselineCapture=relative(BASELINE), BaselineCaptureSHA256=sha(BASELINE), BaselineSourceSHA256=BASELINE_SOURCE,
        CandidateCapture=relative(CANDIDATE), CandidateCaptureSHA256=sha(CANDIDATE), CandidateSourceSHA256=CANDIDATE_SOURCE,
        SourceAndPublishedUnchanged=True, TestHarnessImportsOnly=True, SameSharedHarnessBytes=True,
        CandidateNativeSourceEquality=dict(Path=relative(equality_path), SHA256=sha(equality_path), Components=170),
        CandidateNonVBAPreservation=dict(Path=relative(preservation_path), SHA256=sha(preservation_path), ByteExactParts=111),
        InputAndCenterChecks=models, Decimal120ErrorExtrema=extrema,
        ApprovedGate=dict(EngineeringRelative=ENGINEERING_RELATIVE, Expression='max(original generic limit, 1e-9*sqrt(abs(Ix))*sqrt(abs(Iy)))',
                          OnlyOptInTransformedIxyIxyc=True, SolverCrackStabilityTolerancesChanged=False,
                          NoRoundingOrClipping=True, DecimalPerFieldErrorsAreDiagnosticNotAcceptance=True),
        UnitPairs=pairs, UnitPairGateCounts=histories,
        Historical8EpsFailuresRetained=True,
        Performance=timings,
        PerformanceLimits=['Explicit CalculateTransformedByModuli property rebuild only; no cache hits.',
                           'Same harness bytes and constructor endpoint signature; not full-array hash of dense90000-element models.',
                           'One paired run with3samples per case; no claim of end-to-end generation/calculation acceleration.',
                           'A false target-window flag remains visible; it is not relabeled as target-window success.'],
        GeometryEdges=dict(Macro=edge['Macro'], Passed=880, Failed=0, Seconds=edge['Seconds'],
                           Cases='Asymmetric own tensors, concrete-only and n=.5/1/6; WCS0,+/-1e9,+/-1e10 per actual native harness.'),
        FailedCandidate01=dict(Path=relative(FAILED_HARNESS), SHA256=sha(FAILED_HARNESS), Status=failed['Status'],
                               CompileLocation=failed['CompileLocation'], ProductionFailure=False,
                               Classification='External test harness reserved UDT member; corrected harness in Candidate02.'),
        HistoricalRun01RemainsFailed=True, OverallAcceptanceClaimed=False,
        WorkingCodeEditedByReviewer=False, ExcelExecutedByReviewer=False,
        FurtherAcceptance='Root owns affected UI/input-unit, geometry/solver/stability directed ON/OFF and publication/source checks.')
    output = HERE/'FastInertiaNativeComparison.json'
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    compact = dict(Status=report['Status'], Comparison=relative(output), ComparisonSHA256=sha(output),
                   BaselineSourceSHA256=BASELINE_SOURCE, CandidateSourceSHA256=CANDIDATE_SOURCE,
                   FullInputArraysAndModuliBitwiseEqual=True, AllNativeAreaAndCentersBitwiseEqual=True,
                   ModelCount=6, UnitPairGateCounts=histories, Performance=timings,
                   NativeGeometryEdgeAssertions=880, NativeGeometryEdgeFailures=0,
                   Historical8EpsFailuresRetained=True, OverallAcceptanceClaimed=False)
    (HERE/'FastInertiaNativeComparisonCompact.json').write_text(json.dumps(compact, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in compact.items() if k != 'Performance'}, ensure_ascii=False, indent=2))
    for timing in timings:
        print(timing['Case'], timing['BaselineTwoPassMilliseconds'], timing['CandidateOnePassMilliseconds'], timing['SavedMillisecondsPerRebuild'], timing['KernelSpeedup'])


if __name__ == '__main__':
    main()
