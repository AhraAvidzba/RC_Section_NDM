"""Read-only proof and offline tolerance evidence after the explicitly approved2-file change."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[5]
sys.path.insert(0,str(HERE.parents[1]))
from BuildPostFullMathCoverage import methods

SRC = 'src/Section/CSectionPropertiesCalculator.cls'
TEST = 'tests/modTestWorkbookInterface.bas'
EXISTING = {'CalculateConcrete','CalculateTransformedByModuli','AddWeightedArea','AddConcreteWeightedArea','FinalizeProperties'}
REMOVED = {'CalculateCenteredMoments','AccumulateCompensatedMoment'}
COEFFICIENT = 1e-9


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def ref(path):
    return dict(Path=path.relative_to(ROOT).as_posix(),SHA256=sha(path.read_bytes()))


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    before = load(HERE/'BeforeApplySnapshot.json')
    actual = {p.relative_to(ROOT).as_posix():p for folder in ('src','tests') for p in (ROOT/folder).rglob('*') if p.suffix.lower() in ('.bas','.cls')}
    assert actual.keys() == before.keys() and len(actual) == 164
    changed_files, details = [], []
    src_before_count = src_after_count = unchanged_src_methods = all_before = all_after = unchanged_all_methods = 0
    for rel,path in sorted(actual.items()):
        text = path.read_text(encoding='utf-8-sig')
        bm,am = methods(before[rel]['Text']),methods(text)
        added = am.keys()-bm.keys(); removed = bm.keys()-am.keys()
        changed = [am[k]['Name'] for k in am.keys() & bm.keys() if am[k]['ExecutableSHA256'] != bm[k]['ExecutableSHA256']]
        unchanged = sum(am[k]['BodySHA256'] == bm[k]['BodySHA256'] for k in am.keys() & bm.keys())
        all_before += len(bm);all_after += len(am);unchanged_all_methods += unchanged
        if rel.startswith('src/'):
            src_before_count += len(bm);src_after_count += len(am);unchanged_src_methods += unchanged
        if sha(path.read_bytes()) != before[rel]['SHA256']:
            changed_files.append(rel)
            if rel == SRC:
                assert set(changed) == EXISTING and not added
                assert {bm[k]['Name'] for k in removed} == REMOVED
                assert len(bm) == 56 and len(am) == 54 and unchanged == 49
            elif rel == TEST:
                assert changed == ['TestAudit03InertiaRoundoffLimit'] and not added and not removed
                assert unchanged == len(bm)-1
            else:
                raise AssertionError(('Unexpected file change',rel))
            details.append(dict(Path=rel,BeforeSHA256=before[rel]['SHA256'],CurrentSHA256=sha(path.read_bytes()),
                                BeforeMethodCount=len(bm),CurrentMethodCount=len(am),BodyUnchangedMethods=unchanged,
                                ChangedExistingMethods=changed,RemovedMethods=[bm[k]['Name'] for k in removed],
                                AddedMethods=[am[k]['Name'] for k in added],
                                ChangedCurrentBindings=[am[k] for k in am if am[k]['Name'] in changed]))
        else:
            assert bm == am
    assert set(changed_files) == {SRC,TEST}
    assert src_before_count == 3711 and src_after_count == 3709 and unchanged_src_methods == 3704
    old = subprocess.check_output(['git','show','9ff37714930f55724a9fdc23d445b4ff7f617ead:'+SRC],cwd=ROOT).decode('utf-8-sig').replace('\r\n','\n')
    needle = '    mLastCalculationSeconds = Timer - t0\n'
    assert old.count(needle) == 1
    exact = old.replace(needle,needle+"    If mLastCalculationSeconds < 0# Then mLastCalculationSeconds = mLastCalculationSeconds + 86400# ' Timer обнуляется в полночь; длительность не бывает отрицательной.\n")
    assert actual[SRC].read_text(encoding='utf-8-sig') == exact
    old_test=before[TEST]['Text']
    old_comment="' около нулевого Ixy сравниваем round-trip округление относительно\n' sqrt(Ix*Iy), а не самого исчезающе малого Ixy. Восемь машинных epsilon\n' ограничивают только ошибку представления модулей; solver tolerance не меняется.\n' Исторический unit-sign тест не включает это дополнительное правило."
    new_comment="' Около нулевого Ixy сравниваем unit-roundtrip относительно sqrt(Ix*Iy).\n' Инженерный относительный порог 1e-9 совпадает с общим сравнением Properties:\n' машинный шум не требует дополнительного прохода расчёта геометрии.\n' Правило включается только для Transformed.Ixy/Ixyc при compareInertiaRoundoff=True;\n' пороги solver/прочности/трещин/устойчивости и исторический unit-sign тест не меняются."
    old_formula='    TestAudit03InertiaRoundoffLimit = 8# * (2# ^ -52#) * Sqr(Abs(ix)) * Sqr(Abs(iy))'
    new_formula='    TestAudit03InertiaRoundoffLimit = 0.000000001 * Sqr(Abs(ix)) * Sqr(Abs(iy))'
    assert old_test.count(old_comment)==old_test.count(old_formula)==1
    assert old_test.replace(old_comment,new_comment,1).replace(old_formula,new_formula,1)==actual[TEST].read_text(encoding='utf-8-sig')
    bm,am=methods(before[TEST]['Text']),methods(actual[TEST].read_text(encoding='utf-8-sig'))
    comparer=next(k for k in am if am[k]['Name']=='TestAudit03CompareUnitSnapshot')
    assert bm[comparer]==am[comparer]  # Existing Ixy/Ixyc opt-in dispatch itself is untouched.
    baseline=load(HERE.parent/'NativeBaselineExactOracle.json')
    evidence=[]

    def effective_limit(parameter,opt_in,expected,ix,iy):
        limit=1e-9*(1+abs(expected))
        if opt_in and parameter in ('Transformed.Ixy','Transformed.Ixyc'):
            limit=max(limit,COEFFICIENT*math.sqrt(abs(ix))*math.sqrt(abs(iy)))
        return limit

    for pair in baseline['UnitPairs']:
        if pair['Method'] != 'NativeCurrent':continue
        base=next(m for m in baseline['Models'] if m['Shape']==pair['Shape'] and m['Stress']=='MPa')
        current=next(m for m in baseline['Models'] if m['Shape']==pair['Shape'] and m['Stress']==pair['Stress'])
        a,b=base['Algorithms']['NativeCurrent'],current['Algorithms']['NativeCurrent']
        for parameter,field,ixfield,iyfield in [('Transformed.Ixy','Ixy','Ix','Iy'),('Transformed.Ixyc','Ixyc','Ixc','Iyc')]:
            scale=math.sqrt(abs(a[ixfield]))*math.sqrt(abs(a[iyfield])); delta=abs(b[field]-a[field])
            limit=effective_limit(parameter,True,a[field],a[ixfield],a[iyfield])
            assert delta<=limit
            perturbation=1e-6*scale; perturbed=a[field]+perturbation
            assert abs(perturbed-a[field])>limit
            old_nonopt=1e-9*(1+abs(a[field]))
            assert effective_limit(parameter,False,a[field],a[ixfield],a[iyfield])==old_nonopt
            evidence.append(dict(Shape=pair['Shape'],Stress=pair['Stress'],Parameter=parameter,
                                 CapturedMachineDifference=delta,RelativeDifference=delta/scale,
                                 EngineeringFloor=COEFFICIENT*scale,EffectiveLimit=limit,MachineNoiseAccepted=True,
                                 MeaningfulRelativePerturbation=1e-6,MeaningfulDelta=abs(perturbed-a[field]),MeaningfulRejected=True,
                                 NonOptInEffectiveLimit=old_nonopt,NonOptInLimitUnchanged=True))
        for parameter,field in [('Transformed.Ix','Ix'),('Transformed.Iy','Iy'),('Transformed.Area','A')]:
            assert effective_limit(parameter,True,a[field],a['Ix'],a['Iy'])==1e-9*(1+abs(a[field]))
    assert len(evidence)==8
    proof=dict(Status='APPROVED_TWO_FILE_ONE_PASS_RESTORE_SCOPE_AND_OFFLINE_GATE_PROOF',AllPassed=True,
               AsOfUTC=datetime.now(timezone.utc).isoformat(),
               UserDirection='Не увеличивать время ради инженерно ничтожной неточности; использовать простой быстрый алгоритм и инженерный допуск.',
               ExactChangedFiles=changed_files,BeforeSnapshot=ref(HERE/'BeforeApplySnapshot.json'),Files=details,
               AuditedModuleCount=164,UnchangedModuleFiles=162,BeforeSrcMethods=3711,CurrentSrcMethods=3709,
               UnchangedExistingSrcMethodBodies=3704,BeforeAllMethods=all_before,CurrentAllMethods=all_after,
               UnchangedAllMethodBodies=unchanged_all_methods,
               SourceEqualsExact9ffPlusMidnightGuard=True,TestFileOnlyCommentAndOneCoefficientChanged=True,
               IxyOptInDispatchMethodEntireBodyUnchanged=True,
               Preserved=['First-element local origin and local centralization beforeWCS restore',
                          'Same physical tensors/coordinates, concrete authoritative center, signedEs/Eb-1 and circle ownI',
                          'Same public/friendAPI/cache/revision behavior',
                          'Approved coreDistance sign guard and all other accepted fixes already in9ff',
                          'Timer-midnight protection froma84',
                          'All Solver/Cracks/Stability production coefficients/tolerances and material decisions unchanged'],
               EngineeringTestPolicy=dict(Coefficient=COEFFICIENT,Scale='sqrt(abs(Ix))*sqrt(abs(Iy)); c suffix forIxyc',
                                           AppliesOnlyTo=['compareInertiaRoundoff=True','Properties column4','Transformed.Ixy orTransformed.Ixyc'],
                                           NormativeRequirementClaimed=False,
                                           Meaning='Same1e-9 engineering relative precision as the existing generic Properties unit comparator, with a nonvanishing scale nearIxy0; not a runtime solver tolerance or a universal condition-number guarantee.',
                                           Boundaries='Near-singular/cancelling signed tensors or arbitrarily remote negligible first fibers have no universal relative error bound. Existing geometry/equilibrium/status tests are retained; this change does not classify substantial discrepancies as rounding.'),
               OfflineEvidenceSource=ref(HERE.parent/'NativeBaselineExactOracle.json'),OfflineThresholdChecks=evidence,
               NonIxyOptInFieldsRetainGenericLimit=True,NonOptInRetainsGenericLimit=True,
               MeaningfulOneEMinus6PerturbationsAllRejected=True,
               NativeOrCOMExecuted=False,FullTestsExecuted=False,NativeAcceptancePending=True,OverallPassClaimed=False)
    (HERE/'StrictDiffAndOfflineThresholdProof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    plan=dict(Status='SOURCE_FROZEN_FOR_ROOT_NATIVE',Files=[SRC,TEST],
              SourceSHA256=sha(actual[SRC].read_bytes()),TestSHA256=sha(actual[TEST].read_bytes()),
              NativeStages=[
                  dict(Stage='Exact six arrays and property-kernel timing',Entrypoints=['modTestInputIxyBaseline.TestProbeInputIxy','modTestIxyPerformance.TestProbeIxyPerformance'],
                       Cases='Pointed/Hollow MPa/kgf/cm2/tf/m2, sameF64arrays;300/90000fibers positive andsignedn=.5',
                       Criterion='Samephysicalarrays/A/S/centers; recordIxy noise againstengineeringfloor, kernel should return toward the existing single-pass baseline, no new loop/getter overhead.'),
                  dict(Stage='Focused translated/rotated/signed mechanics',Entrypoints=['modTestGeometry.RunGeometryTests','modTestSectionSolver.RunSectionSolverTests'],Modes=['No','Yes'],
                       Cases='Existing farWCS/core/local-ownI tests unchanged; add a short isolated asymmetric2fiber+2bar check forEs/Eb=.5,1 and positive smallratio because normal translation suite only exercisesn>1.',
                       Criterion='Retain geometry assertions, actual signed barcorrection, finite properties and N/Mx/My equilibrium.'),
                  dict(Stage='Exact affected user-path unit cases',Entrypoints=['modTestWorkbookInterface.RunAudit03InputUnitConsumerTests','modTestWorkbookInterface.RunAudit03UnitSignEquivalenceTests'],Modes=['No','Yes'],
                       Cases='Explicitly confirm actualPointed/Hollow MPa/kgf/cm2/tf/m2 Results paths, all existing120unitconsumers and opt-out historicalunit/sign path.',
                       Criterion='Only nearzeroIxy/Ixyc comparison floor changes. Otherproperties/geometry/strains/forces/statuses remain accepted by existingunchanged tests.'),
                  dict(Stage='Stability consumer guard',Entrypoints=['modTestConfiguration.RunAudit03StabilityConfigTests'],Modes=['No','Yes'],
                       Criterion='ZeroSign fixture remains exactlycentered, SP35/SP63 Ncr/eta/branch status checks unchanged; root may first use alreadyexisting known-rectangle targetedcases before the larger10k configuration group.')],
              PerformanceEvidenceAlreadyObserved=dict(BaselineDenseMilliseconds=[147.216796875,147.4609375],
                                                      TwoPassDenseMilliseconds=[245.1171875,259.765625],
                                                      AddedMillisecondsRemovedByDesign=[97.900390625,112.3046875],
                                                      NewNativeTimingPending=True),
              NoAutomaticFullRerun=True,ExecutionOwner='root',SourcesFrozen=True)
    (HERE/'NativeValidationPlan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(AllPassed=True,ChangedFiles=changed_files,CurrentSrcMethods=3709,
                         UnchangedSrcBodies=3704,OfflineActualChecks=8,MeaningfulPerturbationsRejected=8,
                         SourceFrozen=True,NativeExecuted=False),ensure_ascii=False))


if __name__=='__main__':
    main()
