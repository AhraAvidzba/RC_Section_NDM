"""Independent Decimal oracle for exact F64 arrays captured after the full run.

Reads the inactive modTestInputIxyBaseline output only. No VBA/Excel execution,
input changes, clipping to zero, widened test tolerance or source patching.
"""
from __future__ import annotations

import argparse
from decimal import Decimal, localcontext
import hashlib
import json
import math
from pathlib import Path
import struct


EPS = 2.0 ** -52
D = Decimal.from_float


def values(line):
    result = {}
    for part in line.split("|")[1:]:
        if "=" not in part:
            continue
        key, value = part.split("=", 1)
        if value.startswith("F64:"):
            value = struct.unpack(">d", bytes.fromhex(value[4:]))[0]
            if not math.isfinite(value):
                raise ValueError("Nonfinite native input: " + line)
        result[key] = value
    return result


def models(text):
    result, current = [], None
    for line in text.splitlines():
        if line.startswith("IXY_MODEL|"):
            if current is not None:
                raise ValueError("Unclosed native model")
            current = {"Header": values(line), "Concrete": [], "Steel": []}
        elif line.startswith("IXY_C|"):
            current["Concrete"].append(values(line))
        elif line.startswith("IXY_S|"):
            current["Steel"].append(values(line))
        elif line.startswith("IXY_PROPS|"):
            current["NativeProperties"] = values(line)
        elif line == "IXY_MODEL_END":
            if (len(current["Concrete"]) != int(current["Header"]["fibers"]) or
                    len(current["Steel"]) != int(current["Header"]["bars"])):
                raise ValueError("Incomplete native arrays")
            result.append(current)
            current = None
    if current is not None:
        raise ValueError("Truncated final native model")
    return result


def neumaier(items):
    total, correction = 0.0, 0.0
    for value in items:
        updated = total + value
        if abs(total) >= abs(value):
            correction += (total - updated) + value
        else:
            correction += (value - updated) + total
        total = updated
    return total + correction


def prepared_elements(model):
    ratio = model["Header"]["Es"] / model["Header"]["Eb"]
    result = list(model["Concrete"])
    for bar in model["Steel"]:
        local_i = (ratio - 1.0) * (bar["A"] * bar["A"] / (4.0 * math.pi))
        result.append({"x": bar["x"], "y": bar["y"],
                       "A": (ratio - 1.0) * bar["A"],
                       "Ix": local_i, "Iy": local_i, "Ixy": 0.0})
    return result


def numeric_algorithm(model, centered=False, compensated=False):
    elements = prepared_elements(model)
    ox, oy = elements[0]["x"], elements[0]["y"]
    area = sx = sy = ix = iy = ixy = 0.0
    for e in elements:
        x, y, a = e["x"] - ox, e["y"] - oy, e["A"]
        area = area + a
        sx = sx + a * y
        sy = sy + a * x
        ix = ix + e["Ix"] + a * y * y
        iy = iy + e["Iy"] + a * x * x
        ixy = ixy + e["Ixy"] + a * x * y
    local_x, local_y = sy / area, sx / area
    cx, cy = ox + local_x, oy + local_y
    if centered:
        sum_function = neumaier if compensated else sum
        terms = [[], [], []]
        for e in elements:
            dx = (e["x"] - ox) - local_x
            dy = (e["y"] - oy) - local_y
            terms[0].append(e["Ix"] + e["A"] * dy * dy)
            terms[1].append(e["Iy"] + e["A"] * dx * dx)
            terms[2].append(e["Ixy"] + e["A"] * dx * dy)
        ixc, iyc, ixyc = map(sum_function, terms)
    else:
        ixc = ix - area * local_y * local_y
        iyc = iy - area * local_x * local_x
        ixyc = ixy - area * local_x * local_y
    return {"A": area, "Cx": cx, "Cy": cy,
            "Ixc": ixc, "Iyc": iyc, "Ixyc": ixyc,
            "Ix": ixc + area * cy * cy,
            "Iy": iyc + area * cx * cx,
            "Ixy": ixyc + area * cx * cy}


def decimal_oracle(model):
    with localcontext() as context:
        context.prec = 90
        ratio = D(model["Header"]["Es"]) / D(model["Header"]["Eb"])
        elements = [{key: D(value) for key, value in e.items()}
                    for e in model["Concrete"]]
        for bar in model["Steel"]:
            a = D(bar["A"])
            local_i = (ratio - 1) * a * a / (4 * D(math.pi))
            elements.append({"x": D(bar["x"]), "y": D(bar["y"]),
                             "A": (ratio - 1) * a,
                             "Ix": local_i, "Iy": local_i,
                             "Ixy": Decimal(0)})
        zero = Decimal(0)
        area = sum((e["A"] for e in elements), zero)
        cx = sum((e["A"] * e["x"] for e in elements), zero) / area
        cy = sum((e["A"] * e["y"] for e in elements), zero) / area
        ixc = sum((e["Ix"] + e["A"] * (e["y"] - cy) ** 2 for e in elements), zero)
        iyc = sum((e["Iy"] + e["A"] * (e["x"] - cx) ** 2 for e in elements), zero)
        ixyc = sum((e["Ixy"] + e["A"] * (e["x"] - cx) * (e["y"] - cy)
                    for e in elements), zero)
        # Direct global sums independently check the parallel-axis reconstruction.
        ix = sum((e["Ix"] + e["A"] * e["y"] * e["y"] for e in elements), zero)
        iy = sum((e["Iy"] + e["A"] * e["x"] * e["x"] for e in elements), zero)
        ixy = sum((e["Ixy"] + e["A"] * e["x"] * e["y"] for e in elements), zero)
        return {"A": area, "Cx": cx, "Cy": cy, "Ix": ix, "Iy": iy,
                "Ixy": ixy, "Ixc": ixc, "Iyc": iyc, "Ixyc": ixyc}


def analyze(model):
    exact = decimal_oracle(model)
    candidates = {
        "NativeCurrent": model["NativeProperties"],
        "PythonCurrentLocalFirstPass": numeric_algorithm(model),
        "CenteredSecondPass": numeric_algorithm(model, True, False),
        "CenteredSecondPassNeumaier": numeric_algorithm(model, True, True),
    }
    scale = math.sqrt(abs(model["NativeProperties"]["Ix"])) * math.sqrt(
        abs(model["NativeProperties"]["Iy"]))
    errors = {}
    for name, candidate in candidates.items():
        errors[name] = {
            field: {"Actual": candidate[field], "DecimalReference": str(exact[field]),
                    "Error": float(D(candidate[field]) - exact[field]),
                    "ErrorInEpsTimesGlobalInertiaScale": float(
                        abs(D(candidate[field]) - exact[field])) / (EPS * scale)}
            for field in ("Ix", "Iy", "Ixy", "Ixc", "Iyc", "Ixyc")
        }
    return {"Shape": model["Header"]["shape"], "Stress": model["Header"]["stress"],
            "Eb": model["Header"]["Eb"], "Es": model["Header"]["Es"],
            "ConcreteCount": len(model["Concrete"]), "RebarCount": len(model["Steel"]),
            "GlobalInertiaScale": scale, "Existing8EpsLimit": 8.0 * EPS * scale,
            "Algorithms": candidates, "Errors": errors}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("native_capture", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = args.native_capture.read_bytes()
    content = raw.decode("utf-8-sig")
    provenance = {}
    if args.native_capture.suffix.lower() == ".json":
        capture = json.loads(content)
        if capture.get("Status") != "PROBES_COMPLETED" or not capture.get("SourceUnchanged"):
            raise ValueError("Native capture is incomplete or its source changed")
        found = [p for p in capture["Probes"]
                 if p["Macro"] == "modTestInputIxyBaseline.TestProbeInputIxy"]
        if len(found) != 1:
            raise ValueError("Exactly one matching native probe is required")
        content = found[0]["Actual"]
        provenance = {k: capture.get(k) for k in ("SourceSHA256", "Imports", "RunnerSHA256")}
    if "FAIL:" in content or "TOTAL_INPUT_IXY_BASELINE: cases=6; passed=6; failed=0" not in content:
        raise ValueError("Native probe failed or did not finish all six models")
    data = models(content)
    if {(m["Header"]["shape"], m["Header"]["stress"]) for m in data} != {
            (shape, stress) for shape in ("PointedSection", "HollowRectangle")
            for stress in ("MPa", "kgf/cm2", "tf/m2")} or len(data) != 6:
        raise ValueError("Native coverage differs from the six-model plan")
    comparisons = [analyze(m) for m in data]
    pairs = []
    for shape in ("PointedSection", "HollowRectangle"):
        baseline = next(c for c in comparisons if c["Shape"] == shape and c["Stress"] == "MPa")
        for other in (c for c in comparisons if c["Shape"] == shape and c["Stress"] != "MPa"):
            for method in baseline["Algorithms"]:
                delta = abs(other["Algorithms"][method]["Ixy"] - baseline["Algorithms"][method]["Ixy"])
                pairs.append({"Shape": shape, "Stress": other["Stress"], "Method": method,
                              "IxyDifference": delta, "Unchanged8EpsLimit": baseline["Existing8EpsLimit"],
                              "WithinExisting8Eps": delta <= baseline["Existing8EpsLimit"]})
    result = {"Scope": "Exact captured binary64 input arrays; Decimal precision90 independent oracle",
              "NativeCapture": str(args.native_capture),
              "NativeCaptureSHA256": hashlib.sha256(raw).hexdigest().upper(),
              "Provenance": provenance, "Models": comparisons, "UnitPairs": pairs,
              "ReaderOrInputChanged": False, "TestLimitsChanged": False,
              "ProductionCodeChanged": False, "OverallAcceptanceClaimed": False}
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"Models": len(comparisons), "UnitPairs": len(pairs),
                      "OutsideExisting8EpsByMethod": {
                          name: sum(not p["WithinExisting8Eps"] for p in pairs if p["Method"] == name)
                          for name in comparisons[0]["Algorithms"]}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
