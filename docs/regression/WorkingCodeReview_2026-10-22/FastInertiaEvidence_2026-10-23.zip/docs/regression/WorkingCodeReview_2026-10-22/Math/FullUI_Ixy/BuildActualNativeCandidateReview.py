"""Read-only baseline/candidate native comparison; no Excel or working edits."""
from pathlib import Path
from decimal import Decimal, localcontext
import json
import math
import struct
from BuildActualNativeBaselineReview import (
    ROOT, HERE, EXPECTED_SOURCE, sha, fields, parse_models,
    independent_decimal, independent_candidate,
)

BASELINE = ROOT/'docs/regression/WorkingCodeReview_2026-10-22/PostFullNativeBaseline01_Probes.json'
CANDIDATE = ROOT/'docs/regression/WorkingCodeReview_2026-10-22/PostFullNativeCandidate01_Probes.json'
ORACLE = HERE/'NativeCandidateExactOracle.json'
EPS = 2.0**-52


def get_probe(data, name):
    found = [p for p in data['Probes'] if p['Macro'] == name]
    assert len(found) == 1 and 'FAIL:' not in found[0]['Actual']
    return found[0]


def bit_equal(a, b):
    return struct.pack('>d', a) == struct.pack('>d', b)


def get_perf(data):
    probe = get_probe(data, 'modTestIxyPerformance.TestProbeIxyPerformance')
    assert 'TOTAL_IXY_PERF_PROBE: cases=4; passed=4; failed=0' in probe['Actual']
    result, signatures, properties = {}, {}, {}
    for line in probe['Actual'].splitlines():
        if line.startswith('IXY_PERF|'):
            f = fields(line)
            assert f['timersFinite'] == f['nonnegativeElapsed'] == 'True'
            assert int(f['actualPreparationBuildDelta']) == 3*int(f['iterations'])
            result[f['case']] = f
        elif line.startswith('IXY_PERF_MODEL|'):
            f = fields(line)
            signatures[f['case']] = f['signature']
        elif line.startswith('IXY_PERF_PROPERTIES|'):
            f = fields(line)
            properties[f['case']] = {k: v for k, v in f.items() if k != 'case'}
    assert len(result) == len(properties) == 4 and len(signatures) == 2
    return result, signatures, properties


def main():
    baseline = json.loads(BASELINE.read_text(encoding='utf-8-sig'))
    candidate = json.loads(CANDIDATE.read_text(encoding='utf-8-sig'))
    oracle = json.loads(ORACLE.read_text(encoding='utf-8-sig'))
    assert oracle['NativeCaptureSHA256'] == sha(CANDIDATE)
    for capture in (baseline, candidate):
        assert capture['Status'] == 'PROBES_COMPLETED' and not capture['CleanupErrors']
        assert capture['SourceSHA256'] == capture['SourceSHA256After'] == EXPECTED_SOURCE
        assert capture['PublishedSHA256'] == capture['PublishedSHA256After'] == EXPECTED_SOURCE
        assert capture['SourceUnchanged'] and capture['PublishedUnchanged']
    assert candidate['PrivateCandidateImported']
    prod_imports = [i for i in candidate['Imports'] if i['Candidate']]
    assert len(prod_imports) == 1 and prod_imports[0]['Name'] == 'CSectionPropertiesCalculator'
    assert prod_imports[0]['SHA256'] == sha(ROOT/prod_imports[0]['Path'])
    old_probes = [i for i in baseline['Imports'] if not i['Candidate']]
    new_probes = [i for i in candidate['Imports'] if not i['Candidate']]
    assert old_probes == new_probes
    for item in new_probes:
        assert item['SHA256'] == sha(ROOT/item['Path'])
    bm = parse_models(get_probe(baseline, 'modTestInputIxyBaseline.TestProbeInputIxy')['Actual'])
    cm = parse_models(get_probe(candidate, 'modTestInputIxyBaseline.TestProbeInputIxy')['Actual'])
    checks, maxima = [], {}
    for before, after in zip(bm, cm):
        assert before['Header'] == after['Header']
        array_fields = 0
        for kind in ('Concrete', 'Steel'):
            assert len(before[kind]) == len(after[kind])
            for left, right in zip(before[kind], after[kind]):
                assert left.keys() == right.keys()
                for key in left:
                    assert bit_equal(left[key], right[key])
                    array_fields += 1
        for field in ('A', 'Cx', 'Cy'):
            assert bit_equal(before['Native'][field], after['Native'][field])
        ref = independent_decimal(after)
        predicted = independent_candidate(after)
        h = after['Header']
        scale = math.sqrt(abs(after['Native']['Ix']))*math.sqrt(abs(after['Native']['Iy']))
        errors, prediction = {}, {}
        for field in ('Ix', 'Iy', 'Ixy', 'Ixc', 'Iyc', 'Ixyc'):
            with localcontext() as context:
                context.prec = 120
                error = float(Decimal.from_float(after['Native'][field])-ref[field])
            normalized = abs(error)/(EPS*scale)
            errors[field] = dict(Absolute=error, EpsScale=normalized)
            prediction[field] = dict(Native=after['Native'][field], Binary64Replay=predicted[field],
                                     NativeMinusReplay=after['Native'][field]-predicted[field])
            scope = 'Central' if field.endswith('c') else 'Global'
            if normalized > maxima.get(scope, {}).get('EpsScale', -1):
                maxima[scope] = dict(Shape=h['shape'], Stress=h['stress'], Field=field,
                                    EpsScale=normalized, AbsoluteError=abs(error))
        # The public-global Iy error is decomposed rather than gated arbitrarily.
        with localcontext() as context:
            context.prec = 120
            native = after['Native']
            restored = Decimal.from_float(native['A'])*Decimal.from_float(native['Cx'])**2
            exact_restore = ref['A']*ref['Cx']**2
            restore_residual = float(restored-exact_restore)
        checks.append(dict(Shape=h['shape'], Stress=h['stress'], ArrayF64FieldsBitwiseCompared=array_fields,
                           ArraysAndModuliBitwiseIdentical=True, AreaCenterBitwiseIdentical=True,
                           NativeVsDecimal120=errors, NativeVsBinary64Replay=prediction,
                           IyRestoreCenterAndAreaResidual=restore_residual))
        existing = next(m for m in oracle['Models'] if m['Shape'] == h['shape'] and m['Stress'] == h['stress'])
        assert existing['Algorithms']['NativeCurrent'] == after['Native']
        for algorithm, errs in existing['Errors'].items():
            for field, e in errs.items():
                with localcontext() as context:
                    context.prec = 120
                    assert abs(Decimal(e['DecimalReference'])-ref[field]) < Decimal('1e-70')
    pairs = []
    for shape in ('PointedSection', 'HollowRectangle'):
        base = next(m for m in cm if m['Header']['shape'] == shape and m['Header']['stress'] == 'MPa')
        limit = 8.0*EPS*math.sqrt(abs(base['Native']['Ix']))*math.sqrt(abs(base['Native']['Iy']))
        for m in cm:
            if m['Header']['shape'] == shape and m['Header']['stress'] != 'MPa':
                delta = abs(m['Native']['Ixy']-base['Native']['Ixy'])
                assert delta <= limit
                pairs.append(dict(Shape=shape, Stress=m['Header']['stress'], NativeIxyDifference=delta,
                                  Existing8EpsLimit=limit, WithinExistingContract=True))
    bt, bs, bp = get_perf(baseline)
    ct, cs, cp = get_perf(candidate)
    assert bs == cs
    timings = []
    for case in bt:
        b, c = bt[case], ct[case]
        for key in ('fibers', 'bars', 'Eb', 'Es', 'replacementFactor', 'warmupCalls'):
            assert b[key] == c[key]
        for key in ('A', 'Cx', 'Cy'):
            assert bit_equal(bp[case][key], cp[case][key])
        t0, t1 = float(b['medianSecondsPerCall']), float(c['medianSecondsPerCall'])
        timings.append(dict(Case=case, Fibers=int(b['fibers']), Bars=int(b['bars']),
                            BaselineMillisecondsPerCall=1000*t0, CandidateMillisecondsPerCall=1000*t1,
                            DeltaMillisecondsPerCall=1000*(t1-t0), CandidateOverBaseline=t1/t0,
                            PercentIncrease=100*(t1/t0-1),
                            BaselineWindowMet=b['medianBlockWithin0.2To0.5Seconds'] == 'True',
                            CandidateWindowMet=c['medianBlockWithin0.2To0.5Seconds'] == 'True',
                            BaselineSamples=[float(b['sample'+str(i)+'Seconds'])/int(b['iterations']) for i in (1,2,3)],
                            CandidateSamples=[float(c['sample'+str(i)+'Seconds'])/int(c['iterations']) for i in (1,2,3)]))
    result = dict(
        Status='READ_ONLY_NATIVE_CANDIDATE_REVIEW_COMPLETE',
        BaselineCaptureSHA256=sha(BASELINE), CandidateCaptureSHA256=sha(CANDIDATE),
        CandidateOracleSHA256=sha(ORACLE), SourceWorkbookSHA256=EXPECTED_SOURCE,
        CandidateClassImport=prod_imports[0], SameTestHarnessBytes=True, SourceAndPublishedUnchanged=True,
        IndependentDecimalPrecision=120, ModelComparisons=checks,
        ActualNativeUnitPairs=pairs, ActualNativeUnitPairFailures=0,
        MaxAbsoluteDecimalErrors=maxima,
        NativeVsReplayInterpretation='Both are centered compensated algorithms on identical F64 inputs. Minor differences are consistent with native/VBE intermediate evaluation versus Python binary64, but that mechanism was not separately isolated. Actual native results and the independent Decimal reference, not Python bit identity, decide unit-pair acceptance.',
        GlobalIyResidual='First-pass A/S and the public center are deliberately bitwise preserved. Public Iy=Iyc+A*Cx^2 inherits that center/area rounding; a new per-field8eps-vs-Decimal criterion is not the existing unit-roundtrip contract. Central tensors and native unit-pairs improved. No widening/clipping was used.',
        PerformanceComparison=timings,
        PerformanceAssessment='Additional O(n) pass and compensation cost is measurable: approximately1.53–1.85x this property kernel in these four cases. Dense absolute increment is about0.10–0.11s per explicit rebuild. This does not measure full NDM elapsed time; geometry/material preparation and cache contexts were not changed. Preserve numerical correctness and assess directed end-to-end results separately.',
        RequiredBeforeOverallAcceptance=['Directed affected ON/OFF unit/geometry/sign/stability and far-WCS regressions',
                                         'Current release/source equivalence and protected data preservation',
                                         'Keep original74FAIL full run as failed historical evidence; targeted correction does not rewrite its outcome'],
        WorkingCodeEditedByReviewer=False, TestsEditedByReviewer=False, ExcelExecutedByReviewer=False,
        OverallAcceptanceClaimed=False)
    target = HERE/'ActualNativeCandidateReview.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    compact = dict(ActualNativeUnitPairFailures=0, ArraysBitwiseIdentical=True, AreaCenterBitwiseIdentical=True,
                   DecimalPrecision=120, MaxAbsoluteDecimalErrors=maxima, PerformanceComparison=timings,
                   CandidateClassSHA256=prod_imports[0]['SHA256'], OverallAcceptanceClaimed=False)
    (HERE/'ActualNativeBaselineCandidateComparison.json').write_text(json.dumps(compact, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(compact, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
