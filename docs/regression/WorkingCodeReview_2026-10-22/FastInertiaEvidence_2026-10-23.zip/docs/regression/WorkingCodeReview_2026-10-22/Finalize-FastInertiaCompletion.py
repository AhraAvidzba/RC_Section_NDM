"""Фиксирует завершение только после публикации и официальной приёмки той же книги."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RELEASE = HERE / 'FastInertiaRelease01'
FOCUSED = ROOT / 'docs/regression/WorkingCodeReview_2026-10-23_FastInertiaFocused_Run01'
BOOK = '8E1A22F6A50539CA6FDB3AF9EBE9D8BF7D8CC3CD81156461159D451F94784040'
DUMP = '2FE407257CAEF204C0AA81EE5AE814B9D541BBBC298F8BCF5400B14EC67EA905'
read = lambda path: json.loads(path.read_text('utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    destination = HERE / 'FastInertiaFinalDecision.json'
    assert not destination.exists(), 'Preserve earlier decisions'
    publication = read(RELEASE / 'Publication.json')
    directed = read(RELEASE / 'DirectedAcceptance.json')
    focused = read(FOCUSED / 'Acceptance.json')
    independent = read(FOCUSED / 'Independent.json')
    run = read(FOCUSED / 'Run.json')
    launch = read(HERE / 'FastInertiaFocusedLaunch.json')
    assert publication['Status'] == 'CODE_ONLY_PUBLISHED'
    assert publication['WorkbookSHA256'] == BOOK and publication['DumpSHA256'] == DUMP
    assert publication['ForeignOutputsPreserved'] and publication['All111NonVBAPartsByteExact']
    assert directed['Status'] == 'DIRECTED_ACCEPTANCE_PASS' and directed['ReleaseSHA256'] == BOOK
    assert directed['DumpSHA256'] == DUMP and directed['AssertionsPerMode'] == 18968
    assert set(directed['Modes']) == {'No', 'Yes'}
    assert focused['Status'] == 'PASS' and focused['SourceSHA256'] == BOOK
    assert focused['IndividualCases'] == 122 and focused['PassedAssertions'] == 13952
    assert not focused['Errors'] and len(focused['Stages']) == 19
    assert all(x['Passed'] for x in focused['Stages'])
    assert independent['Passed'] and independent['SourceSHA256'] == BOOK
    assert independent['IndependentIntegrals'] == 560 and independent['ReviewedNumFailStates'] == 10
    assert run['Status'] == 'COMPLETED_PENDING_REVIEW' and run['FinishedUTC']
    assert run['SourceSHA256'] == BOOK and run['ProtectedInputsUnchanged']
    assert len(run['Records']) == 26 and all(x['Passed'] for x in run['Records'])
    assert launch['SourceSHA256'] == BOOK and launch['AllCodeSHA256'] == DUMP
    assert run['SourceCommit'] == launch['SourceCommit']
    changed = [x['Path'] for x in launch['ParticipatingScripts'] + launch['SourceComponents']
               if sha(Path(x['Path'])) != x['SHA256']]
    assert not changed
    assert len(launch['ParticipatingScripts']) == 19 and len(launch['SourceComponents']) == 164
    assert sha(ROOT / 'workbook/output/RC_Section_NDM.xlsm') == BOOK
    assert sha(ROOT / 'workbook/output/VBA_All_Code.txt') == DUMP
    assert sha(ROOT / 'workbook/output/RC_Section_NDM_execution_report.txt') == 'C3E3C907F5F8B634D4ECBD1218F1EC3BDAD6F9FE807744D4845D62D06ABA978E'
    assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'src', 'tests',
                                       'workbook/output/RC_Section_NDM.xlsm',
                                       'workbook/output/VBA_All_Code.txt'], cwd=ROOT).strip()
    result = {
        'Complete': True, 'Status': 'AUDIT_AND_ONE_PASS_FOLLOWUP_COMPLETE',
        'AtUTC': datetime.now(timezone.utc).isoformat(),
        'WorkbookSHA256': BOOK, 'DumpSHA256': DUMP,
        'DirectedGateSHA256': sha(RELEASE / 'DirectedAcceptance.json'),
        'PublicationSHA256': sha(RELEASE / 'Publication.json'),
        'FocusedAcceptanceSHA256': sha(FOCUSED / 'Acceptance.json'),
        'PublishedSourceCommit': launch['SourceCommit'],
        'DirectedAssertionsEachMode': 18968, 'AnalyticAdditionalAssertions': 880,
        'FocusedCases': 122, 'FocusedAssertions': 13952, 'IndependentIntegrals': 560,
        'FocusedElapsedSeconds': focused['ElapsedSeconds'],
        'FrozenScripts': 19, 'FrozenComponents': 164, 'Changed': changed,
        'EngineeringPolicy': 'User explicitly rejected extra runtime for insignificant roundoff. One local pass restored; only unit Ixy/Ixyc test floor is 1e-9 of inertia scale.',
        'SolverCrackStabilityTolerancesChanged': False,
        'HistoricalFull156': 'Run02/A168 PASS retained; no full156 PASS is claimed for the new book.',
        'PermanentMonitoring': 'ACTIVE; do not disable automatically',
        'ForeignOutputsExcluded': True, 'OriginalCoordinatesPreserved': True,
        'Performance': directed['Performance'], 'PerformanceIsPropertiesKernelOnly': True,
        'Limit': 'No universal absence of bugs or final normative verification is claimed; arbitrary nearly singular signed tensors retain conditioning limits.',
    }
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k != 'Performance'}))


if __name__ == '__main__':
    main()
