# ДЛЯ ТЕСТОВ: адресные ON/OFF чистого однопроходного выпуска, без импорта кода.
param([ValidateSet('No','Yes')][string[]]$Modes=@('No','Yes'))
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -ne 'Desktop'){throw 'Use Windows PowerShell5.1.'}
$source='docs/regression/WorkingCodeReview_2026-10-22/FastInertiaRelease01/Release/RC_Section_NDM.xlsm'
$hash='8E1A22F6A50539CA6FDB3AF9EBE9D8BF7D8CC3CD81156461159D451F94784040'
$macros=@('modTestGeometry.RunGeometryTests','modTestConfiguration.RunAudit03StabilityConfigTests',
          'modTestWorkbookInterface.RunAudit03InputUnitConsumerTests','modTestSectionSolver.RunSectionSolverTests')
foreach($mode in $Modes){
    $label=if($mode -eq 'No'){'FastInertiaDirectedOff01'}else{'FastInertiaDirectedOn01'}
    & (Join-Path $PSScriptRoot 'Run-CompletionProbes.ps1') -SourceWorkbook $source -ExpectedSourceSHA256 $hash -Label $label -Mode $mode -Macro $macros
    $result=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($label+'_Probes.json')) -Raw -Encoding UTF8|ConvertFrom-Json
    if($result.Status -ne 'PROBES_COMPLETED' -or -not $result.NoCodeImported -or -not $result.SourceUnchanged -or -not $result.PublishedUnchanged -or $result.CleanupErrors.Count){throw 'Native directed run incomplete or changed protected inputs.'}
    if($result.Probes.Count -ne $macros.Count){throw 'Missing directed group.'}
    foreach($probe in $result.Probes){
        if($probe.Actual -match '(?mi)^(FAIL:|RUNTIME ERROR|RESTORE ERROR|CLEANUP ERROR)' -or $probe.Actual -notmatch '(?m)^TOTAL[^\r\n]*passed=\d+;\s*failed=0\b'){throw ('Directed group failed: '+$probe.Macro)}
    }
}
Write-Output 'FAST_INERTIA_DIRECTED_BOTH_MODES_COMPLETED'
