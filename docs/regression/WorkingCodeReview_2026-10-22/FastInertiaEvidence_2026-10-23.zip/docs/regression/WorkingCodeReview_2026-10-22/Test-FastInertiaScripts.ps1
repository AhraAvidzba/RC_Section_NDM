# ДЛЯ ТЕСТОВ: разбирает синтаксис вспомогательных сценариев без их исполнения.
$ErrorActionPreference='Stop'
$records=@()
foreach($name in @('Run-FastInertiaDirected.ps1','Launch-FastInertiaFocused.ps1','Publish-FastInertiaRelease.ps1')){
    $tokens=$null;$errors=$null;$path=Join-Path $PSScriptRoot $name
    $null=[System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
    if($errors.Count){throw ($name+': '+($errors.Message -join ' | '))}
    $records+=,[ordered]@{File=$name;SHA256=(Get-FileHash -LiteralPath $path).Hash;Errors=0}
}
[ordered]@{PowerShell=$PSVersionTable.PSVersion.ToString();NoNativeOrCOM=$true;Records=$records}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'FastInertiaScriptsPreflight.json') -Encoding UTF8
Write-Output 'FAST_INERTIA_SCRIPTS_PARSE_PASS'
