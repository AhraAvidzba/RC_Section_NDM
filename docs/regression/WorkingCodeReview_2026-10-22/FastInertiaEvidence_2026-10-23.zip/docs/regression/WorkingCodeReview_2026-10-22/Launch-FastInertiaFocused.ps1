﻿# Запускает только повтор затронутого целевого плана; полный156 не перезапускает.
param([Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{40}$')][string]$ExpectedCommit)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global -ErrorAction Stop
if($PSVersionTable.PSEdition -ne 'Desktop'){throw 'Use Windows PowerShell5.1.'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$head=$ExpectedCommit
$expected='8E1A22F6A50539CA6FDB3AF9EBE9D8BF7D8CC3CD81156461159D451F94784040'
$expectedDump='2FE407257CAEF204C0AA81EE5AE814B9D541BBBC298F8BCF5400B14EC67EA905'
$relative='docs/regression/WorkingCodeReview_2026-10-23_FastInertiaFocused_Run01'
$source=Join-Path $PSScriptRoot 'FastInertiaRelease01/Release/RC_Section_NDM.xlsm'
$launchFile=Join-Path $PSScriptRoot 'FastInertiaFocusedLaunch.json'
$stdout=Join-Path $PSScriptRoot 'FastInertiaFocused.stdout.log'
$stderr=Join-Path $PSScriptRoot 'FastInertiaFocused.stderr.log'
foreach($file in @((Join-Path $root $relative),$launchFile,$stdout,$stderr)){if(Test-Path -LiteralPath $file){throw 'Fresh launch paths required.'}}
if((& git rev-parse HEAD) -cne $head){throw 'Source commit changed.'}
foreach($file in @($source,(Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'))){if((Get-FileHash -LiteralPath $file).Hash -cne $expected){throw 'Workbook differs from reviewed release.'}}
if((Get-FileHash -LiteralPath (Join-Path $root 'workbook/output/VBA_All_Code.txt')).Hash -cne $expectedDump){throw 'Published dump differs.'}
$old=Get-Content -LiteralPath (Join-Path $root 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run02/Run.json') -Raw|ConvertFrom-Json
$driver=Get-Process -Id 159136 -ErrorAction SilentlyContinue
if(($driver -and $driver.StartTime.ToUniversalTime().Ticks -eq [long]639283145055645344) -or -not $old.FinishedUTC -or $old.Status -ne 'COMPLETED_PENDING_LOG_REVIEW'){throw 'Full Run02 must have ended normally.'}
$deadline=[DateTimeOffset]::Parse('2026-10-23T10:00:00+03:00')
if(([DateTimeOffset]::Now.AddSeconds(1200)) -gt $deadline){throw 'Conservative focused forecast plus reserve does not fit the user deadline.'}
$previous=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'FullLaunchRun02.json') -Raw|ConvertFrom-Json
$scripts=@($previous.ParticipatingScripts|ForEach-Object {[ordered]@{Path=$_.Path;SHA256=(Get-FileHash -LiteralPath $_.Path).Hash}})
$components=@($previous.SourceComponents|ForEach-Object {[ordered]@{Path=$_.Path;SHA256=(Get-FileHash -LiteralPath $_.Path).Hash}})
$runner=Join-Path $root 'tools/build_workbook/Run-FocusedAcceptance.ps1'
$python='C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$exe=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$arguments=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',('"'+$runner+'"'),'-SourceWorkbook',('"'+$source+'"'),'-EvidenceDirectory',$relative,'-MaxSeconds','3600','-DeadlineUTC','2026-10-23T07:00:00Z','-Python',('"'+$python+'"'))
$process=Start-Process -FilePath $exe -ArgumentList $arguments -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
$process.Refresh()
$result=[ordered]@{Status='STARTED';PID=$process.Id;ProcessStartTicks=$process.StartTime.ToUniversalTime().Ticks.ToString();Observed=(Get-Date).ToString('o');SourceCommit=$head;SourceWorkbook=$source;SourceSHA256=$expected;AllCodeSHA256=$expectedDump;EvidenceDirectory=$relative;ExpectedSingleCases=122;IncludesBatch15BothModes=$true;IncludesStabilitySteelRealCADIndependentAndReopen=$true;ForecastSeconds=900;MaximumSeconds=3600;Deadline=$deadline.ToString('o');Stdout=$stdout;Stderr=$stderr;ParticipatingScripts=$scripts;SourceComponents=$components;Full156Repeated=$false;LaunchScriptSHA256=(Get-FileHash -LiteralPath $PSCommandPath).Hash}
$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $launchFile -Encoding utf8
Write-Output ('FOCUSED_LAUNCHED: pid='+$process.Id+'; ticks='+$result.ProcessStartTicks+'; source='+$expected)
