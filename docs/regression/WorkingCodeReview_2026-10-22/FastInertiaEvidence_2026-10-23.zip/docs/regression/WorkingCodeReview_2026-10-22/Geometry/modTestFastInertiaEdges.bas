Attribute VB_Name = "modTestFastInertiaEdges"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: внешняя аналитическая проверка быстрого локального суммирования.
' Четыре раздельных повернутых прямоугольника и два стержня имеют истинные A/I.
' Oracle работает с собственными массивами в локальной системе координат;
' Excel, материалы, solver, Results и пользовательская книга не используются.
' ==========================================================================
Private Type TTestFastFixture
    A(1 To 6) As Double
    X(1 To 6) As Double
    Y(1 To 6) As Double
    OwnIx(1 To 6) As Double
    OwnIy(1 To 6) As Double
    OwnIxy(1 To 6) As Double
    FiberWidths(1 To 4) As Double
    FiberHeights(1 To 4) As Double
    Angle(1 To 4) As Double
End Type

Private Type TTestFastExpected
    Area As Double
    Cx As Double
    Cy As Double
    Ix As Double
    Iy As Double
    Ixy As Double
    P1 As Double
    P2 As Double
    Rx As Double
    Ry As Double
    R1 As Double
    R2 As Double
End Type

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет 20 малых моделей, включая отрицательную добавку Es/Eb-1 и n=1.
' Возвращает фактические ошибки и итог; исполнение поручается только root.
Public Function TestRunFastInertiaEdges() As String
    Dim fixture As TTestFastFixture, expected As TTestFastExpected
    Dim variantIndex As Long, shiftValue As Variant, ratioValue As Double, includeBars As Boolean
    Dim passed As Long, failed As Long, report As String, started As Double, elapsed As Double
    On Error GoTo TestFailed
    started = Timer
    TestInitFastFixture fixture
    For variantIndex = 0 To 3
        includeBars = variantIndex <> 0
        Select Case variantIndex
            Case 0: ratioValue = 1#
            Case 1: ratioValue = 0.5
            Case 2: ratioValue = 1#
            Case 3: ratioValue = 6#
        End Select
        TestFastExpected fixture, includeBars, ratioValue, expected
        For Each shiftValue In Array(0#, 1000000000#, -1000000000#, 10000000000#, -10000000000#)
            TestFastOneModel fixture, expected, includeBars, ratioValue, CDbl(shiftValue), passed, failed, report
        Next shiftValue
    Next variantIndex
    elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    TestRunFastInertiaEdges = report & "TOTAL_FAST_INERTIA_EDGES: passed=" & CStr(passed) & "; failed=" & CStr(failed) & "; seconds=" & CStr(elapsed)
    Exit Function
TestFailed:
    TestRunFastInertiaEdges = report & "FAIL: fastInertia.runtime=" & CStr(Err.Number) & "; " & Err.Description & vbCrLf & _
        "TOTAL_FAST_INERTIA_EDGES: passed=" & CStr(passed) & "; failed=" & CStr(failed + 1)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задает непересекающиеся реальные прямоугольники; стержни лежат внутри 1 и 4.
' Поворот собственного тензора вычисляется непосредственно из интегралов прямоугольника.
Private Sub TestInitFastFixture(ByRef f As TTestFastFixture)
    f.X(1) = -100#: f.Y(1) = -60#: f.FiberWidths(1) = 60#: f.FiberHeights(1) = 40#: f.Angle(1) = 0.2
    f.X(2) = 120#: f.Y(2) = -40#: f.FiberWidths(2) = 70#: f.FiberHeights(2) = 30#: f.Angle(2) = -0.35
    f.X(3) = -70#: f.Y(3) = 90#: f.FiberWidths(3) = 50#: f.FiberHeights(3) = 60#: f.Angle(3) = 0.6
    f.X(4) = 130#: f.Y(4) = 100#: f.FiberWidths(4) = 80#: f.FiberHeights(4) = 50#: f.Angle(4) = -0.1
    Dim i As Long, alongIx As Double, alongIy As Double, cosineValue As Double, sineValue As Double
    For i = 1 To 4
        f.A(i) = f.FiberWidths(i) * f.FiberHeights(i)
        alongIx = f.A(i) * f.FiberHeights(i) ^ 2 / 12#: alongIy = f.A(i) * f.FiberWidths(i) ^ 2 / 12#
        cosineValue = Cos(f.Angle(i)): sineValue = Sin(f.Angle(i))
        f.OwnIx(i) = alongIx * cosineValue ^ 2 + alongIy * sineValue ^ 2
        f.OwnIy(i) = alongIx * sineValue ^ 2 + alongIy * cosineValue ^ 2
        f.OwnIxy(i) = (alongIy - alongIx) * sineValue * cosineValue
    Next i
    f.X(5) = -105#: f.Y(5) = -60#: f.A(5) = 64# * TestFastPi()
    f.X(6) = 130#: f.Y(6) = 100#: f.A(6) = 100# * TestFastPi()
    For i = 5 To 6
        f.OwnIx(i) = f.A(i) * f.A(i) / (4# * TestFastPi()): f.OwnIy(i) = f.OwnIx(i)
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает независимый двухпроходный oracle по аналитическим A/I, не по модели.
' Отрицательный коэффициент стержня умножает и площадь, и собственный тензор.
Private Sub TestFastExpected(ByRef f As TTestFastFixture, ByVal includeBars As Boolean, _
        ByVal ratioValue As Double, ByRef result As TTestFastExpected)
    Dim i As Long, lastIndex As Long, factor As Double, weight As Double, dx As Double, dy As Double
    Dim averageValue As Double, differenceValue As Double
    result.Area = 0#: result.Cx = 0#: result.Cy = 0#: result.Ix = 0#: result.Iy = 0#: result.Ixy = 0#
    lastIndex = 4
    If includeBars Then lastIndex = 6
    For i = 1 To lastIndex
        factor = 1#
        If i > 4 Then factor = ratioValue - 1#
        weight = factor * f.A(i)
        result.Area = result.Area + weight
        result.Cx = result.Cx + weight * f.X(i): result.Cy = result.Cy + weight * f.Y(i)
    Next i
    result.Cx = result.Cx / result.Area: result.Cy = result.Cy / result.Area
    For i = 1 To lastIndex
        factor = 1#
        If i > 4 Then factor = ratioValue - 1#
        weight = factor * f.A(i): dx = f.X(i) - result.Cx: dy = f.Y(i) - result.Cy
        result.Ix = result.Ix + factor * f.OwnIx(i) + weight * dy * dy
        result.Iy = result.Iy + factor * f.OwnIy(i) + weight * dx * dx
        result.Ixy = result.Ixy + factor * f.OwnIxy(i) + weight * dx * dy
    Next i
    averageValue = (result.Ix + result.Iy) / 2#
    differenceValue = Sqr(((result.Ix - result.Iy) / 2#) ^ 2 + result.Ixy ^ 2)
    result.P1 = averageValue + differenceValue: result.P2 = averageValue - differenceValue
    result.Rx = Sqr(result.Ix / result.Area): result.Ry = Sqr(result.Iy / result.Area)
    result.R1 = Sqr(result.P1 / result.Area): result.R2 = Sqr(result.P2 / result.Area)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создает модель без изменения локальной формы и проверяет свойства/перенос.
' Допуск центральных I равен 1e-9 относительного масштаба; это тест, не порог solver.
Private Sub TestFastOneModel(ByRef f As TTestFastFixture, ByRef expected As TTestFastExpected, _
        ByVal includeBars As Boolean, ByVal ratioValue As Double, ByVal shiftValue As Double, _
        ByRef passed As Long, ByRef failed As Long, ByRef report As String)
    Dim model As CSectionModel, props As CSectionPropertiesCalculator, reference As CSectionPropertiesCalculator
    Dim zeroModel As CSectionModel, prefix As String, i As Long, revisionBefore As Long
    Dim dx As Double, dy As Double, expectedCore As Double, actualCore As Double, referenceCore As Double
    Set model = TestFastModel(f, includeBars, shiftValue)
    Set zeroModel = TestFastModel(f, includeBars, 0#)
    revisionBefore = model.Revision
    Set props = New CSectionPropertiesCalculator: Set reference = New CSectionPropertiesCalculator
    If includeBars Then
        props.CalculateTransformedByModuli model, 30000#, 30000# * ratioValue
        reference.CalculateTransformedByModuli zeroModel, 30000#, 30000# * ratioValue
    Else
        props.CalculateConcrete model: reference.CalculateConcrete zeroModel
    End If
    prefix = "fastInertia.bars=" & CStr(includeBars) & ".n=" & CStr(ratioValue) & ".WCS=" & CStr(shiftValue)
    TestFastClose passed, failed, report, prefix & ".area", props.Area, expected.Area, 0.000000001, 0.000000001
    TestFastClose passed, failed, report, prefix & ".cx", props.CentroidX, shiftValue + expected.Cx, 0#, 0.000004
    TestFastClose passed, failed, report, prefix & ".cy", props.CentroidY, -shiftValue + expected.Cy, 0#, 0.000004
    TestFastClose passed, failed, report, prefix & ".Ix", props.Ixc, expected.Ix, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".Iy", props.Iyc, expected.Iy, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".Ixy", props.Ixyc, expected.Ixy, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".P1", props.PrincipalI1, expected.P1, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".P2", props.PrincipalI2, expected.P2, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".Rx", props.RadiusX, expected.Rx, 0.000000001, 0.0000001
    TestFastClose passed, failed, report, prefix & ".Ry", props.RadiusY, expected.Ry, 0.000000001, 0.0000001
    TestFastClose passed, failed, report, prefix & ".R1", props.PrincipalRadius1, expected.R1, 0.000000001, 0.0000001
    TestFastClose passed, failed, report, prefix & ".R2", props.PrincipalRadius2, expected.R2, 0.000000001, 0.0000001
    TestFastClose passed, failed, report, prefix & ".transfer.Ix", props.Ixc, reference.Ixc, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".transfer.Iy", props.Iyc, reference.Iyc, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".transfer.Ixy", props.Ixyc, reference.Ixyc, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".transfer.P1", props.PrincipalI1, reference.PrincipalI1, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".transfer.P2", props.PrincipalI2, reference.PrincipalI2, 0.000000001, 0.000001
    TestFastClose passed, failed, report, prefix & ".transfer.Rx", props.RadiusX, reference.RadiusX, 0.000000001, 0.0000001
    TestFastClose passed, failed, report, prefix & ".transfer.Ry", props.RadiusY, reference.RadiusY, 0.000000001, 0.0000001
    TestFastClose passed, failed, report, prefix & ".transfer.R1", props.PrincipalRadius1, reference.PrincipalRadius1, 0.000000001, 0.0000001
    TestFastClose passed, failed, report, prefix & ".transfer.R2", props.PrincipalRadius2, reference.PrincipalRadius2, 0.000000001, 0.0000001
    For i = 1 To 3
        dx = 0#: dy = 0#
        Select Case i
            Case 1: dx = 1#
            Case 2: dy = 1#
            Case 3: dx = 1#: dy = 1#
        End Select
        expectedCore = TestFastCore(f, expected, dx, dy)
        actualCore = props.CoreDistanceAlong(model, dx, dy, False)
        referenceCore = reference.CoreDistanceAlong(zeroModel, dx, dy, False)
        TestFastClose passed, failed, report, prefix & ".core." & CStr(i), actualCore, expectedCore, 0.0000001, 0.00003
        TestFastClose passed, failed, report, prefix & ".transfer.core." & CStr(i), actualCore, referenceCore, 0.0000001, 0.00003
    Next i
    For i = 1 To 4
        TestFastClose passed, failed, report, prefix & ".sourceX." & CStr(i), model.ConcreteX(i), shiftValue + f.X(i), 0#, 0#
        TestFastClose passed, failed, report, prefix & ".sourceY." & CStr(i), model.ConcreteY(i), -shiftValue + f.Y(i), 0#, 0#
        TestFastCheck passed, failed, report, prefix & ".sourceOwnI." & CStr(i), _
            model.ConcreteLocalIx(i) = f.OwnIx(i) And model.ConcreteLocalIy(i) = f.OwnIy(i) And model.ConcreteLocalIxy(i) = f.OwnIxy(i)
    Next i
    If includeBars Then
        For i = 1 To 2
            TestFastClose passed, failed, report, prefix & ".sourceBarX." & CStr(i), model.RebarX(i), shiftValue + f.X(i + 4), 0#, 0#
            TestFastClose passed, failed, report, prefix & ".sourceBarY." & CStr(i), model.RebarY(i), -shiftValue + f.Y(i + 4), 0#, 0#
        Next i
    End If
    TestFastCheck passed, failed, report, prefix & ".revision", model.Revision = revisionBefore
    TestFastCheck passed, failed, report, prefix & ".nonzeroOwnIxy", Abs(f.OwnIxy(1)) > 100# And Abs(expected.Ixy) > 100#
    report = report & "MODEL_FAST_INERTIA: " & prefix & "; Ixy=" & CStr(props.Ixyc) & "; P2=" & CStr(props.PrincipalI2) & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передает явные истинные тензоры повернутых прямоугольников общему public API.
Private Function TestFastModel(ByRef f As TTestFastFixture, ByVal includeBars As Boolean, ByVal shiftValue As Double) As CSectionModel
    Dim model As CSectionModel, i As Long
    Set model = New CSectionModel
    For i = 1 To 4
        model.AddConcreteElement shiftValue + f.X(i), -shiftValue + f.Y(i), f.A(i), 1, _
            shapeType:="Rectangle", width:=f.FiberWidths(i), height:=f.FiberHeights(i), rotation:=f.Angle(i), _
            localIx:=f.OwnIx(i), localIy:=f.OwnIy(i), localIxy:=f.OwnIxy(i), rotationKnown:=True
    Next i
    If includeBars Then
        model.AddRebarElement shiftValue + f.X(5), -shiftValue + f.Y(5), 16#, f.A(5), "A400"
        model.AddRebarElement shiftValue + f.X(6), -shiftValue + f.Y(6), 20#, f.A(6), "A500"
    End If
    Set TestFastModel = model
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Независимая граница ядра: инверсия аналитической центральной матрицы и
' минимум формы на 16 фактических вершинах бетонных прямоугольников.
Private Function TestFastCore(ByRef f As TTestFastFixture, ByRef e As TTestFastExpected, _
        ByVal directionX As Double, ByVal directionY As Double) As Double
    Dim vectorNorm As Double, nx As Double, ny As Double, determinantValue As Double
    Dim coefficientX As Double, coefficientY As Double, i As Long, sx As Long, sy As Long
    Dim cornerX As Double, cornerY As Double, value As Double, minValue As Double, firstValue As Boolean
    vectorNorm = Sqr(directionX ^ 2 + directionY ^ 2): nx = directionX / vectorNorm: ny = directionY / vectorNorm
    determinantValue = e.Ix * e.Iy - e.Ixy * e.Ixy
    coefficientX = (-e.Ixy * ny + e.Ix * nx) / determinantValue
    coefficientY = (e.Iy * ny - e.Ixy * nx) / determinantValue
    firstValue = True
    For i = 1 To 4
        For sx = -1 To 1 Step 2
            For sy = -1 To 1 Step 2
                cornerX = f.X(i) + sx * f.FiberWidths(i) / 2# * Cos(f.Angle(i)) - sy * f.FiberHeights(i) / 2# * Sin(f.Angle(i))
                cornerY = f.Y(i) + sx * f.FiberWidths(i) / 2# * Sin(f.Angle(i)) + sy * f.FiberHeights(i) / 2# * Cos(f.Angle(i))
                value = coefficientX * (cornerX - e.Cx) + coefficientY * (cornerY - e.Cy)
                If firstValue Or value < minValue Then minValue = value: firstValue = False
            Next sy
        Next sx
    Next i
    If minValue >= 0# Then Err.Raise vbObjectError + 1690, "modTestFastInertiaEdges", "Analytical core has no compressed extreme."
    TestFastCore = -1# / (e.Area * minValue)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает только тестовый результат с независимым инженерным допуском.
Private Sub TestFastClose(ByRef passed As Long, ByRef failed As Long, ByRef report As String, _
        ByVal label As String, ByVal actual As Double, ByVal expected As Double, ByVal relativeLimit As Double, ByVal absoluteLimit As Double)
    Dim limitValue As Double
    limitValue = absoluteLimit
    If Abs(expected) * relativeLimit > limitValue Then limitValue = Abs(expected) * relativeLimit
    TestFastCheck passed, failed, report, label & "; actual=" & CStr(actual) & "; expected=" & CStr(expected) & "; limit=" & CStr(limitValue), Abs(actual - expected) <= limitValue
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Счетчики и отчет принадлежат только этому внешнему probe; рабочие тесты не меняет.
Private Sub TestFastCheck(ByRef passed As Long, ByRef failed As Long, ByRef report As String, ByVal label As String, ByVal condition As Boolean)
    If condition Then
        passed = passed + 1
    Else
        failed = failed + 1
        report = report & "FAIL: " & label & vbCrLf
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Локальная константа pi исключает зависимость oracle от общего helper проекта.
Private Function TestFastPi() As Double
    TestFastPi = 4# * Atn(1#)
End Function
