"""Упаковывает выбранные доказательства только после завершённого решения root.

Книги, полные снимки VBA, большой BeforeApplySnapshot и чужие outputs не входят.
Скрипт не запускает проверки и не заменяет официальный focused verifier.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
FOCUSED = ROOT / 'docs/regression/WorkingCodeReview_2026-10-23_FastInertiaFocused_Run01'
RELEASE = HERE / 'FastInertiaRelease01'
ONE_PASS = HERE / 'Math/FullUI_Ixy/OnePassEngineeringTolerance'
ALLOWED_EXTENSIONS = {'.json', '.jsonl', '.txt', '.md', '.bas', '.ps1', '.py', '.patch', '.log'}
FORBIDDEN_NAMES = {
    'BeforeApplySnapshot.json', 'ActualReleaseVBA.txt', 'VBA_All_Code.txt',
    'RC_Section_NDM_execution_report.txt',
}
MAX_FILE_BYTES = 4 * 1024 * 1024
EXPECTED_DIRECTED = [
    ('modTestGeometry.RunGeometryTests', 4051),
    ('modTestConfiguration.RunAudit03StabilityConfigTests', 10024),
    ('modTestWorkbookInterface.RunAudit03InputUnitConsumerTests', 1553),
    ('modTestSectionSolver.RunSectionSolverTests', 3340),
]


def require(condition, message):
    """Останавливает упаковку до объявления целостности при неполном доказательстве."""
    if not condition:
        raise RuntimeError(message)


def read(path):
    """Читает исходный JSON без перезаписи или нормализации доказательства."""
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(raw):
    """Считает SHA256 именно тех байтов, которые будут помещены в архив."""
    return hashlib.sha256(raw).hexdigest().upper()


def file_sha(path):
    """Привязывает gate или выбранный файл к его неизменённым байтам."""
    return digest(path.read_bytes())


def workspace_path(value):
    """Не допускает выхода явных дополнительных путей из рабочей папки."""
    path = Path(value)
    if not path.is_absolute():
        path = ROOT / path
    path = path.resolve()
    require(path.is_relative_to(ROOT), 'Evidence path escapes the workspace: ' + str(path))
    return path


def expect_hash(value):
    """Требует явно передать полную идентичность выпуска, а не название папки."""
    value = value.upper()
    if not re.fullmatch(r'[A-F0-9]{64}', value):
        raise argparse.ArgumentTypeError('Expected a full SHA256')
    return value


def validate_gates(args):
    """Сверяет завершённые receipts одной книги; не запускает их verifier повторно."""
    decision_path = workspace_path(args.decision)
    decision = read(decision_path)
    require(decision.get('Complete') is True,
            'FastInertiaFinalDecision.json must have Complete=true after all actual stages finish')

    directed_path = workspace_path(args.directed_gate)
    publication_path = workspace_path(args.publication_gate)
    equality_path = RELEASE / 'SourceProof01/NativeSourceEquality.json'
    part_path = RELEASE / 'PartPreservation.json'
    directed, publication = read(directed_path), read(publication_path)
    equality, part = read(equality_path), read(part_path)
    expected, dump = args.expected_workbook_sha, args.expected_dump_sha
    require(decision.get('WorkbookSHA256') == expected and decision.get('DumpSHA256') == dump,
            'Complete decision belongs to a different workbook or dump')

    require(directed.get('Status') == 'DIRECTED_ACCEPTANCE_PASS' and
            directed.get('ReleaseSHA256') == expected and directed.get('DumpSHA256') == dump,
            'Directed receipt does not accept the explicitly selected release')
    require(directed.get('ReadyForPublication') is True and
            directed.get('NoCodeImportedDuringDirectedTests') is True,
            'Directed receipt is not the clean-release acceptance gate')
    require(set(directed.get('Modes', {})) == {'No', 'Yes'}, 'Both directed modes are required')
    for mode, groups in directed['Modes'].items():
        require([(g.get('Macro'), g.get('Passed'), g.get('Failed')) for g in groups] ==
                [(macro, count, 0) for macro, count in EXPECTED_DIRECTED],
                'Directed groups incomplete or failed: ' + mode)

    require(publication.get('Status') == 'CODE_ONLY_PUBLISHED' and
            publication.get('WorkbookSHA256') == expected and publication.get('DumpSHA256') == dump,
            'Publication receipt has a different or unfinished release')
    require(publication.get('SourceEqualitySHA256') == file_sha(equality_path) and
            publication.get('DirectedAcceptanceSHA256') == file_sha(directed_path),
            'Publication gate hashes do not match the actual selected receipts')
    require(publication.get('AllowedChangedParts') == ['xl/vbaProject.bin'] and
            publication.get('All111NonVBAPartsByteExact') is True and
            publication.get('NoProbeModules') is True and
            publication.get('ForeignOutputsPreserved') is True,
            'Publication did not preserve the required clean-release/data contract')
    require(part.get('ReleaseSHA256') == expected and part.get('NonVBAPartsByteExact') is True and
            part.get('PreservedParts') == 111 and part.get('AllowedChangedParts') == ['xl/vbaProject.bin'],
            'The 111-part preservation proof does not belong to this release')
    require(equality.get('AllPassed') is True and equality.get('ActualNativeDumpVerified') is True and
            equality.get('DumpSHA256') == dump and equality.get('ActualComponents') == 170 and
            equality.get('RepositoryComponents') == 164 and equality.get('DocumentComponents') == 6 and
            equality.get('NoExtrasOrPrivateProbeModules') is True,
            'Actual native component/source equality proof is missing or mismatched')

    acceptance_path, independent_path, run_path = [FOCUSED / name for name in
                                                   ('Acceptance.json', 'Independent.json', 'Run.json')]
    acceptance, independent, run = map(read, (acceptance_path, independent_path, run_path))
    for field, path in (('DirectedGateSHA256', directed_path), ('PublicationSHA256', publication_path),
                        ('FocusedAcceptanceSHA256', acceptance_path)):
        require(decision.get(field) == file_sha(path), 'Complete decision hash differs: ' + field)
    require(acceptance.get('Status') == 'PASS' and acceptance.get('SourceSHA256') == expected and
            acceptance.get('IndividualCases') == 122 and acceptance.get('PassedAssertions') == 13952 and
            not acceptance.get('Errors') and len(acceptance.get('Stages', [])) == 19 and
            all(stage.get('Passed') is True for stage in acceptance['Stages']),
            'Official focused acceptance is incomplete, failed, or for a different release')
    require(independent.get('Passed') is True and independent.get('SourceSHA256') == expected and
            independent.get('ModelCount') == 5 and independent.get('IndependentIntegrals') == 560 and
            not independent.get('Unsupported'), 'Independent focused control is incomplete or mismatched')
    # Failures содержит также доказанные невозможные нагрузки с Passed=True; это не список сбоев verifier.
    require(all(item.get('Passed') is True for item in independent.get('Failures', [])),
            'Independent negative-case control contains an unaccepted outcome')
    require(run.get('SourceSHA256') == expected and run.get('FinishedUTC') and
            run.get('Status') == 'COMPLETED_PENDING_REVIEW' and run.get('ProtectedInputsUnchanged') is True,
            'Focused runner has no terminal unchanged-input receipt')

    directed_raw = []
    require(set(directed.get('RawReports', {})) == {'No', 'Yes'}, 'Missing directed raw-report identities')
    for label, mode in (('Off', 'No'), ('On', 'Yes')):
        path = HERE / ('FastInertiaDirected' + label + '01_Probes.json')
        identity = directed['RawReports'][mode]
        require(workspace_path(identity['Path']) == path and identity.get('SHA256') == file_sha(path),
                'Directed receipt raw-report path/hash mismatch: ' + mode)
        raw = read(path)
        require(raw.get('Status') == 'PROBES_COMPLETED' and raw.get('SourceSHA256') == expected and
                raw.get('DiagramExtension') == mode and raw.get('NoCodeImported') is True and
                not raw.get('Imports') and raw.get('SourceUnchanged') is True and
                raw.get('PublishedUnchanged') is True and not raw.get('CleanupErrors') and
                len(raw.get('Probes', [])) == 4,
                'Actual directed raw report is unfinished or mismatched: ' + label)
        require([probe.get('Macro') for probe in raw['Probes']] == [m for m, _ in EXPECTED_DIRECTED],
                'Actual directed raw report contains the wrong macros')
        for probe, (macro, count) in zip(raw['Probes'], EXPECTED_DIRECTED):
            actual = probe.get('Actual', '')
            require(not re.search(r'(?mi)^(?:FAIL:|RUNTIME ERROR|RESTORE ERROR|CLEANUP ERROR)', actual),
                    'Raw directed report contains an error: ' + macro)
            totals = re.findall(r'(?m)^TOTAL[^\r\n]*?passed=(\d+);\s*failed=(\d+)', actual)
            require(totals and tuple(map(int, totals[-1])) == (count, 0),
                    'Raw directed report total mismatch: ' + macro)
        directed_raw.append(path)

    require(file_sha(ROOT / 'workbook/output/RC_Section_NDM.xlsm') == expected and
            file_sha(ROOT / 'workbook/output/VBA_All_Code.txt') == dump,
            'Current published bytes differ from the explicit selected release')
    return [decision_path, directed_path, publication_path, equality_path, part_path,
            acceptance_path, independent_path, run_path, *directed_raw]


def collect_files(args, gates):
    """Выбирает компактные raw/proof-файлы; исторические неудачи сохраняет без смены статуса."""
    files = set()

    def add(path, required=True):
        path = path.resolve()
        require(path.is_relative_to(ROOT), 'Selected path escapes workspace: ' + str(path))
        if not path.is_file():
            require(not required, 'Missing selected evidence: ' + str(path))
            return
        require(path.suffix.lower() in ALLOWED_EXTENSIONS and path.name not in FORBIDDEN_NAMES,
                'Forbidden workbook/snapshot/binary entry: ' + str(path))
        require(not path.is_relative_to(ROOT / 'outputs') and
                not path.is_relative_to(ROOT / 'workbook/output'), 'Foreign published output selected')
        require(path.stat().st_size <= MAX_FILE_BYTES, 'Oversized raw snapshot is not compact evidence')
        files.add(path)

    for gate in gates:
        add(gate)
    report = workspace_path(args.root_final_report)
    require(report.is_relative_to(ROOT / 'docs/reports'), 'Root final report must be under docs/reports')
    add(report) # Исходный отчёт root сохраняется байт-в-байт, без пересказа или очистки.
    for value in args.required_gate:
        path = workspace_path(value)
        require(path.is_relative_to(HERE) or path.is_relative_to(FOCUSED),
                'Extra gate must belong to this evidence scope')
        add(path)

    for pattern in ('FastInertia*.json', '*FastInertia*.ps1', '*FastInertia*.py'):
        for path in HERE.glob(pattern):
            add(path)
    for name in ('CleanCompile.json', 'RepoManifest.json', 'PartPreservation.json',
                 'DirectedAcceptance.json', 'Publication.json', 'ActualReleaseVBA.txt.ReadOnly.json',
                 'SourceProof01/NativeSourceEquality.json', 'SourceProof01/ProofSelfChecks.json',
                 'SourceProof01/VbeNumericCanonicalization.json'):
        add(RELEASE / name)
    for path in ONE_PASS.rglob('*'):
        if path.is_file() and path.name != 'BeforeApplySnapshot.json' and path.suffix.lower() in ALLOWED_EXTENSIONS:
            add(path)
    for name in ('StrictDiffAndOfflineThresholdProof.json', 'NativeValidationPlan.json',
                 'BuildOnePassProof.py', 'ApprovedOnePassAndTestGate.patch'):
        add(ONE_PASS / name)
    for name in ('BuildActualNativeBaselineReview.py', 'BuildActualNativeCandidateReview.py',
                 'AnalyzeNativeIxyArrays.py', 'modTestIxyPerformance.bas', 'modTestInputIxyBaseline.bas'):
        add(ONE_PASS.parent / name)
    add(HERE / 'Run-CompletionProbes.ps1') # Общий private-native runner, на который ссылается новый FastInertia-сценарий.
    for name in ('modTestFastInertiaEdges.bas', 'FastInertiaEdgesPreparation.json', 'FastInertiaEdgesCompileFix.json'):
        add(HERE / 'Geometry' / name)
    add(HERE / 'Excel/ToolProbeNaming/LegacyToolFinalHandoff.json')
    add(Path(__file__))

    for path in FOCUSED.iterdir():
        if path.is_file() and path.suffix.lower() in ALLOWED_EXTENSIONS and not path.name.endswith(
                ('.progress.txt', '.stdout.log', '.stderr.log')):
            add(path)
    for name in ('Probe/Preparation.json', 'Probe/InputManifest.json', 'NativeCAD/Stage.json'):
        add(FOCUSED / name)
    for path in (FOCUSED / 'NativeCAD').rglob('*'):
        if path.is_file() and path.suffix.lower() in ALLOWED_EXTENSIONS:
            add(path)
    return sorted(files)


def main():
    """Создаёт только новый архив и sidecar после всех guards; прежние архивы не трогает."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-workbook-sha', required=True, type=expect_hash)
    parser.add_argument('--expected-dump-sha', required=True, type=expect_hash)
    parser.add_argument('--decision', default=str(HERE / 'FastInertiaFinalDecision.json'))
    parser.add_argument('--directed-gate', default=str(RELEASE / 'DirectedAcceptance.json'))
    parser.add_argument('--publication-gate', default=str(RELEASE / 'Publication.json'))
    parser.add_argument('--root-final-report', default='docs/reports/OnePassInertia_2026-10-23.md')
    parser.add_argument('--required-gate', action='append', default=[])
    parser.add_argument('--archive', default=str(HERE / 'FastInertiaEvidence_2026-10-23.zip'))
    args = parser.parse_args()

    gates = validate_gates(args) # Ни файл архива, ни каталог не создаются до Complete и реальных receipts.
    files = collect_files(args, gates)
    archive = workspace_path(args.archive)
    require(archive.parent == HERE and archive.suffix.lower() == '.zip', 'Archive must be a fresh ZIP in the evidence root')
    sidecar = archive.with_suffix('.json')
    require(not archive.exists() and not sidecar.exists(), 'Preserve existing archive/receipt; choose a fresh filename')

    payload = [(path, path.read_bytes()) for path in files]
    manifest = [dict(Path=path.relative_to(ROOT).as_posix(), Bytes=len(raw), SHA256=digest(raw))
                for path, raw in payload]
    metadata = dict(Status='SELECTED_FAST_INERTIA_EVIDENCE',
                    CreatedUTC=datetime.now(timezone.utc).isoformat(),
                    WorkbookSHA256=args.expected_workbook_sha, DumpSHA256=args.expected_dump_sha,
                    CompleteDecision=workspace_path(args.decision).relative_to(ROOT).as_posix(),
                    RootFinalReport=workspace_path(args.root_final_report).relative_to(ROOT).as_posix(),
                    Files=manifest, NoPrivateWorkbooksOrForeignOutputs=True,
                    BeforeApplySnapshotExcluded=True, NoNewFull156AcceptanceClaimed=True,
                    CompactArchiveIsNotStandaloneExperimentRegeneration=True,
                    HistoricalFailedAttemptsPreservedUnchanged=True,
                    Meaning='Archive integrity and identity binding only; actual native and official focused receipts are preserved raw. No test or Excel process is executed by this packer.')
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as output:
        for item, (_, raw) in zip(manifest, payload):
            output.writestr(item['Path'], raw)
        output.writestr('MANIFEST.json', json.dumps(metadata, ensure_ascii=False, indent=2).encode('utf-8'))
    with ZipFile(archive) as check:
        require(check.testzip() is None, 'ZIP CRC verification failed')
        require(len(check.namelist()) == len(manifest) + 1, 'ZIP entry count differs')
        require(all(digest(check.read(item['Path'])) == item['SHA256'] for item in manifest),
                'ZIP entry SHA256 verification failed')
    require(all(file_sha(path) == item['SHA256'] for (path, _), item in zip(payload, manifest)),
            'Selected evidence changed while packing; archive must not be accepted')
    receipt = dict(Status='ARCHIVE_INTEGRITY_PASS', Archive=archive.relative_to(ROOT).as_posix(),
                   ArchiveSHA256=file_sha(archive), Bytes=archive.stat().st_size, Files=len(manifest),
                   AllEntriesSHA256Checked=True, SelectedFilesUnchangedDuringPacking=True,
                   NoPrivateWorkbooksOrForeignOutputs=True, BeforeApplySnapshotExcluded=True,
                   NoNewFull156AcceptanceClaimed=True, Manifest=manifest)
    with sidecar.open('x', encoding='utf-8') as output:
        output.write(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'Manifest'}))


if __name__ == '__main__':
    main()
