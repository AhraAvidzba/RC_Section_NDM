"""Проверяет адресные протоколы и измеренный отказ от лишнего прохода; не запускает Excel."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DIRECTORY = HERE / 'FastInertiaRelease01'
CURRENT = '8E1A22F6A50539CA6FDB3AF9EBE9D8BF7D8CC3CD81156461159D451F94784040'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest().upper()
read = lambda path: json.loads(path.read_text('utf-8-sig'))


def totals(probe, count):
    text = probe['Actual']
    assert not re.search(r'(?mi)^(?:FAIL:|RUNTIME ERROR|RESTORE ERROR|CLEANUP ERROR)', text)
    matches = re.findall(r'(?m)^TOTAL[^\r\n]*?passed=(\d+);\s*failed=(\d+)', text)
    assert matches and tuple(map(int, matches[-1])) == (count, 0), probe['Macro']
    return {'Macro': probe['Macro'], 'Passed': count, 'Failed': 0, 'Seconds': probe['Seconds']}


def capture(label):
    run = read(HERE / (label + '_Probes.json'))
    assert run['Status'] == 'PROBES_COMPLETED' and run['SourceUnchanged'] and run['PublishedUnchanged']
    assert not run['CleanupErrors']
    return run


def perf_rows(probe, prefix):
    rows = {}
    for line in probe['Actual'].splitlines():
        if line.startswith(prefix + '|'):
            row = dict(part.split('=', 1) for part in line.split('|')[1:])
            rows[row['case']] = row
    return rows


def main():
    target = DIRECTORY / 'DirectedAcceptance.json'
    assert not target.exists(), 'Preserve earlier receipts'
    part = read(DIRECTORY / 'PartPreservation.json')
    equality = read(DIRECTORY / 'SourceProof01/NativeSourceEquality.json')
    opened = read(DIRECTORY / 'ActualReleaseVBA.txt.ReadOnly.json')
    assert part['ReleaseSHA256'] == CURRENT and sha(Path(part['ReleaseWorkbook'])) == CURRENT
    assert part['NonVBAPartsByteExact'] and part['PreservedParts'] == 111
    assert part['AllowedChangedParts'] == ['xl/vbaProject.bin']
    assert equality['AllPassed'] and equality['ActualNativeDumpVerified']
    assert equality['ActualComponents'] == 170 and equality['NoExtrasOrPrivateProbeModules']
    assert opened['Automatic'] and opened['ReadOnly'] and not opened['MacrosExecuted']
    for item in equality['Checks']:
        assert sha(ROOT / item['Path']) == item['SourceSHA256']
    expected = [('modTestGeometry.RunGeometryTests', 4051),
                ('modTestConfiguration.RunAudit03StabilityConfigTests', 10024),
                ('modTestWorkbookInterface.RunAudit03InputUnitConsumerTests', 1553),
                ('modTestSectionSolver.RunSectionSolverTests', 3340)]
    modes = {}
    evidence = {}
    for label, mode in [('Off', 'No'), ('On', 'Yes')]:
        run = capture('FastInertiaDirected' + label + '01')
        assert run['SourceSHA256'] == CURRENT and run['NoCodeImported'] and not run['Imports']
        assert run['DiagramExtension'] == mode
        assert [p['Macro'] for p in run['Probes']] == [m for m, _ in expected]
        modes[mode] = [totals(p, n) for p, (_, n) in zip(run['Probes'], expected)]
        path = HERE / ('FastInertiaDirected' + label + '01_Probes.json')
        evidence[mode] = {'Path': path.relative_to(ROOT).as_posix(), 'SHA256': sha(path)}
    baseline = capture('FastInertiaBaseline01')
    candidate = capture('FastInertiaCandidate02')
    assert candidate['SourceSHA256'] == CURRENT and candidate['OnlyTestModulesImported']
    totals(candidate['Probes'][0], 4)
    totals(candidate['Probes'][1], 6)
    totals(candidate['Probes'][2], 880)
    before = perf_rows(baseline['Probes'][0], 'IXY_PERF')
    after = perf_rows(candidate['Probes'][0], 'IXY_PERF')
    before_values = perf_rows(baseline['Probes'][0], 'IXY_PERF_PROPERTIES')
    after_values = perf_rows(candidate['Probes'][0], 'IXY_PERF_PROPERTIES')
    assert len(before) == len(after) == 4 and before.keys() == after.keys()
    assert perf_rows(baseline['Probes'][0], 'IXY_PERF_MODEL') == perf_rows(candidate['Probes'][0], 'IXY_PERF_MODEL')
    performance = []
    for case, row in before.items():
        old = float(row['medianSecondsPerCall'])
        new = float(after[case]['medianSecondsPerCall'])
        assert old > 0 and 0 < new <= old
        assert all(before_values[case][key] == after_values[case][key] for key in ('A', 'Cx', 'Cy'))
        performance.append({'Case': case, 'BeforeMilliseconds': old * 1000,
                            'AfterMilliseconds': new * 1000, 'SavedMilliseconds': (old-new) * 1000,
                            'SpeedRatio': old/new})
    result = {'Status': 'DIRECTED_ACCEPTANCE_PASS', 'FullAcceptanceClaimed': False,
              'ReleaseSHA256': CURRENT, 'DumpSHA256': equality['DumpSHA256'],
              'ReadyForPublication': True, 'NoCodeImportedDuringDirectedTests': True,
              'SourceEqualitySHA256': sha(DIRECTORY / 'SourceProof01/NativeSourceEquality.json'),
              'PartPreservationSHA256': sha(DIRECTORY / 'PartPreservation.json'),
              'Modes': modes, 'RawReports': evidence, 'AssertionsPerMode': 18968, 'NativeAnalyticEdges': 880,
              'CandidateCaptureSHA256': sha(HERE / 'FastInertiaCandidate02_Probes.json'),
              'BaselineCaptureSHA256': sha(HERE / 'FastInertiaBaseline01_Probes.json'),
              'Performance': performance, 'PerformanceIsPropertiesKernelOnly': True,
              'UserApprovedEngineeringTolerance': '1e-9 * sqrt(abs(Ix)) * sqrt(abs(Iy)), unit Ixy/Ixyc comparison only',
              'SolverCrackStabilityTolerancesChanged': False,
              'Meaning': 'Measured one-pass speed restored; critical local WCS protection retained. Full historical run remains versioned separately.'}
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k != 'Modes'}))


if __name__ == '__main__':
    main()
