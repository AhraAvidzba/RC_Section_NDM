"""Заменяет только VBA в защищённой книге; пользовательские ZIP payloads сохраняет точно."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest().upper()


def stopped():
    run = json.loads((ROOT / 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01/Run.json').read_text('utf-8-sig'))
    if not run.get('FinishedUTC') or run['Status'] not in ('REVIEW_REQUIRED', 'COMPLETED_PENDING_LOG_REVIEW', 'DEADLINE_REACHED'):
        raise ValueError('The participating full run must have terminal evidence.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--expected-base-sha256', required=True)
    args = parser.parse_args()
    stopped()
    directory = args.directory.resolve()
    assert directory.is_relative_to(HERE)
    clean = json.loads((directory / 'CleanCompile.json').read_text('utf-8-sig'))
    assert clean['Status'] == 'CLEAN_COMPILED' and clean['PublicationSourceEligible']
    assert clean['SourceUnchanged'] and clean['PublishedUnchanged']
    assert clean['MacrosExecuted'] is False and clean['ProbeModulesImported'] is False
    assert clean['ExactRepositoryInventory'] and clean['RepositoryComponents'] == 164 and clean['DocumentComponents'] == 6
    compiled = Path(clean['CompiledWorkbook'])
    assert compiled.resolve().is_relative_to(directory)
    assert sha(compiled.read_bytes()) == clean['CompiledSHA256']
    for item in clean['Imports']:
        assert sha((ROOT / item['Path']).read_bytes()) == item['SHA256'], item['Name']
    base = args.base.resolve()
    assert base == (ROOT / 'workbook/output/RC_Section_NDM.xlsm').resolve()
    before = base.read_bytes()
    assert sha(before) == args.expected_base_sha256.upper() == clean['PublishedSHA256']
    release = directory / 'Release'
    release.mkdir(exist_ok=False)
    output = release / 'RC_Section_NDM.xlsm'
    with ZipFile(compiled) as incoming:
        vba = incoming.read('xl/vbaProject.bin')
    with ZipFile(base) as old, ZipFile(output, 'w') as new:
        new.comment = old.comment
        assert old.namelist().count('xl/vbaProject.bin') == 1
        assert old.read('xl/vbaProject.bin') != vba
        for member in old.infolist():
            new.writestr(member, vba if member.filename == 'xl/vbaProject.bin' else old.read(member.filename))
    checks = []
    with ZipFile(base) as old, ZipFile(output) as new:
        assert old.namelist() == new.namelist() and old.comment == new.comment
        for name in old.namelist():
            a, b = old.read(name), new.read(name)
            checks.append({'Part': name, 'BeforeSHA256': sha(a), 'AfterSHA256': sha(b), 'Preserved': a == b})
            assert name == 'xl/vbaProject.bin' or a == b, name
    assert base.read_bytes() == before
    result = {'Status': 'VBA_ONLY_MERGE_PASS', 'SourceSHA256': sha(before),
              'CompiledSHA256': clean['CompiledSHA256'], 'CleanCompileSHA256': sha((directory / 'CleanCompile.json').read_bytes()),
              'ReleaseWorkbook': str(output), 'ReleaseSHA256': sha(output.read_bytes()), 'VBASHA256': sha(vba),
              'AllowedChangedParts': ['xl/vbaProject.bin'], 'NonVBAPartsByteExact': True,
              'PreservedParts': sum(c['Preserved'] for c in checks), 'Parts': checks,
              'NativeSourceEqualityPending': True, 'Published': False}
    (directory / 'PartPreservation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'Parts'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
