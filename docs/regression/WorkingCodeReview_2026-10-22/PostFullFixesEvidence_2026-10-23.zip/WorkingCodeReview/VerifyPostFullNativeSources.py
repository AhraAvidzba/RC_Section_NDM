"""Проверяет actual native dump выпуска; не обращается к Excel и не меняет VBA.

--dump FILE --output FRESH_DIRECTORY: actual source equality.
--self-checks-only --output FRESH_DIRECTORY: только проверки строгости verifier.
Каталог результата должен быть новым, чтобы не перезаписать прежние доказательства.
"""
from pathlib import Path
from decimal import Decimal
import argparse
import copy
import hashlib
import importlib.util
import json
import re
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = '9ff37714930f55724a9fdc23d445b4ff7f617ead'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('post_full_prior_source_rules', HERE / 'PriorSourceVerifier.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
GEOMETRY_PAIRS = [
    ('TestAssertClose stats, prefix & ".coordinateDeviation", difference, 0#, GeomMax(0.000001, Abs(shift) * 0.0000000000000005)',
     'TestAssertClose stats, prefix & ".coordinateDeviation", difference, 0#, GeomMax(0.000001, Abs(shift) * 5E-16)'),
    ('coordinateTolerance = GeomMax(0.00000001, (Abs(x) + Abs(y)) * 0.0000000000000004)',
     'coordinateTolerance = GeomMax(0.00000001, (Abs(x) + Abs(y)) * 4E-16)'),
    ('deltas = Array(-2# * GEOM_TOLERANCE, -GEOM_TOLERANCE / 2#, -1E-14, 0#, 1E-14, GEOM_TOLERANCE / 2#, 2# * GEOM_TOLERANCE)',
     'deltas = Array(-2# * GEOM_TOLERANCE, -GEOM_TOLERANCE / 2#, -0.00000000000001, 0#, 0.00000000000001, GEOM_TOLERANCE / 2#, 2# * GEOM_TOLERANCE)')
]
RULES = copy.deepcopy(prior.RULES)
assert len(RULES) == 7 and sum(map(len, RULES.values())) == 7
assert 'modTestGeometry' not in RULES
RULES['modTestGeometry'] = GEOMETRY_PAIRS
HEADER = re.compile(r'^={100}\nCOMPONENT: ([^\n]+)\nTYPE: (\d+)\nLINES: (\d+)\n={100}\n', re.M)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def parse_dump(text):
    """Сохраняет типы и запрещает повторные или неполные COMPONENT-заголовки."""
    text = text.lstrip('\ufeff').replace('\r\n', '\n')
    headers = list(HEADER.finditer(text))
    require(headers and text.startswith('VBA PROJECT EXPORT\n'), 'Not a native project export')
    require(len(headers) == len(re.findall(r'^COMPONENT: ', text, re.M)), 'Malformed component header')
    result = {}
    for index, match in enumerate(headers):
        name = match[1]
        require(name not in result, 'Duplicate component: ' + name)
        end = headers[index + 1].start() if index + 1 < len(headers) else len(text)
        result[name] = {'Type': int(match[2]), 'DeclaredLines': int(match[3]),
                        'Body': text[match.end():end].rstrip('\n')}
    return result


def split_comment_exact(line):
    """Игнорирует padding перед апострофом, но сохраняет сам текст комментария точно."""
    quoted = False
    index = 0
    while index < len(line):
        if line[index] == '"':
            if quoted and index + 1 < len(line) and line[index + 1] == '"':
                index += 2
                continue
            quoted = not quoted
        elif line[index] == "'" and not quoted:
            return line[:index].rstrip(), line[index + 1:]
        index += 1
    return line.rstrip(), None


def canonical_code(text, module):
    """Регистр VBE, прежний дробный Double-# и только десять закрытых полных операторов."""
    replacements = {a.casefold(): b.casefold() for a, b in RULES.get(module, [])}
    lines = []
    for line in text.strip().splitlines():
        code = prior.strip_redundant_double_suffix(split_comment_exact(line)[0]).casefold()
        statement = code.strip()
        if statement in replacements:
            code = code[:len(code) - len(code.lstrip())] + replacements[statement]
        lines.append(code)
    return '\n'.join(lines)


def literal_parts(text):
    comments = []
    strings = []
    for line in text.splitlines():
        code, comment = split_comment_exact(line)
        if comment is not None:
            comments.append(comment)
        strings.extend(prior.LITERAL.findall(code))
    return comments, strings


def compare_body(expected, actual, module):
    require(canonical_code(expected, module) == canonical_code(actual, module), 'Code mismatch: ' + module)
    e_comments, e_strings = literal_parts(expected)
    a_comments, a_strings = literal_parts(actual)
    require(e_comments == a_comments, 'Exact comment/Unicode mismatch: ' + module)
    require(e_strings == a_strings, 'Exact string literal mismatch: ' + module)


def inventory(actual, repository, documents):
    expected = set(repository) | set(documents)
    require(len(repository) == 164, 'Current repository count is not164')
    require(len(documents) == 6, 'Baseline document count is not6')
    require(len(actual) == 170 and set(actual) == expected,
            'Exact170-component inventory mismatch; missing=' + repr(sorted(expected - set(actual))) +
            '; extra=' + repr(sorted(set(actual) - expected)))
    for name, record in repository.items():
        require(actual[name]['Type'] == record['Type'], 'Repository component type mismatch: ' + name)
    for name in documents:
        require(actual[name]['Type'] == 100, 'Document type mismatch: ' + name)


def load_sources():
    files = sorted(p for folder in ('src', 'tests') for p in (ROOT / folder).rglob('*')
                   if p.suffix.lower() in ('.bas', '.cls'))
    repository = {}
    for path in files:
        text = path.read_text(encoding='utf-8-sig')
        name = path.stem
        match = re.search(r'^Attribute VB_Name = "([^"]+)"', text, re.M)
        require(match and match[1] == name and name not in repository, 'Invalid source name: ' + str(path))
        repository[name] = {'Path': path.relative_to(ROOT).as_posix(), 'SourceSHA256': sha(path),
                            'Type': 2 if path.suffix.lower() == '.cls' else 1,
                            'Body': prior.source_body(text, name)}
    baseline_bytes = subprocess.check_output(['git', 'show', BASE + ':workbook/output/VBA_All_Code.txt'], cwd=ROOT)
    baseline = parse_dump(baseline_bytes.decode('utf-8-sig'))
    documents = {name: item for name, item in baseline.items() if item['Type'] == 100}
    require(len(repository) == 164 and len(documents) == 6, 'Source or document count changed')
    return files, repository, documents, hashlib.sha256(baseline_bytes).hexdigest().upper()


def self_checks(repository, documents):
    """Позитивные правила и отрицательные perturbations используют те же функции, что actual dump."""
    checks = {}
    def rejected(label, action):
        try:
            action()
        except (ValueError, AssertionError):
            checks[label] = True
        else:
            checks[label] = False
    for module, pairs in RULES.items():
        for index, (left, right) in enumerate(pairs):
            compare_body(left, right, module)
            checks[module + '.knownPair' + str(index)] = True
            rejected(module + '.wrongModule' + str(index), lambda a=left, b=right: compare_body(a, b, 'Unrelated'))
            rejected(module + '.changedStatement' + str(index), lambda a=left, b=right, m=module: compare_body('z = 1: ' + a, 'z = 1: ' + b, m))
    rejected('UnknownMaxDoubleContext', lambda: compare_body('x=1.797693134862315E+308', 'x=1.79769313486231E+308', 'CStabilityCalculator'))
    rejected('PerturbedThreshold', lambda: compare_body('If mRelativeResidual > 1E-8 Then', 'If mRelativeResidual > 0.00000001000001 Then', 'CLinearSystem3x3'))
    rejected('IntegerDoubleSuffix', lambda: compare_body('x=1#', 'x=1', 'Unrelated'))
    rejected('NumericStringSuffix', lambda: compare_body('x="1.25#"', 'x="1.25"', 'Unrelated'))
    rejected('StringCase', lambda: compare_body('x="Config"', 'x="config"', 'Unrelated'))
    rejected('EscapedString', lambda: compare_body('x="a""B"', 'x="a""b"', 'Unrelated'))
    rejected('CommentUnicode', lambda: compare_body("x=1 ' Арматура", "x=1 ' Арматурa", 'Unrelated'))
    rejected('CommentCase', lambda: compare_body("x=1 ' Арматура", "x=1 ' арматура", 'Unrelated'))
    rejected('CommentWhitespace', lambda: compare_body("x=1 ' Текст", "x=1 '  Текст", 'Unrelated'))
    rejected('StringUnicode', lambda: compare_body('x="Сечения"', 'x="Сeчения"', 'Unrelated'))
    rejected('ExecutableOperation', lambda: compare_body('x=y+z', 'x=y-z', 'Unrelated'))
    compare_body('x=1.25#', 'x=1.25', 'Unrelated')
    checks['ExistingFractionalDoubleMarkerAccepted'] = True
    compare_body('Dim value As Double', 'Dim Value As Double', 'Unrelated')
    checks['VbeIdentifierCaseAccepted'] = True
    template = {name: {'Type': value['Type'], 'Body': value['Body']} for name, value in {**repository, **documents}.items()}
    inventory(template, repository, documents)
    checks['ExactInventoryAccepted'] = True
    extra = dict(template)
    extra['modTestIxyPerformance'] = {'Type': 1, 'Body': 'Option Explicit'}
    rejected('PrivateProbeExtraRejected', lambda: inventory(extra, repository, documents))
    missing = dict(template)
    del missing[next(iter(repository))]
    rejected('MissingSourceRejected', lambda: inventory(missing, repository, documents))
    replaced = dict(template)
    first = next(iter(repository))
    del replaced[first]
    replaced['PrivateUnlistedProbe'] = {'Type': repository[first]['Type'], 'Body': 'Option Explicit'}
    rejected('SameCountExtraReplacementRejected', lambda: inventory(replaced, repository, documents))
    wrong_type = copy.deepcopy(template)
    wrong_type[first]['Type'] = 100
    rejected('SourceTypeMutationRejected', lambda: inventory(wrong_type, repository, documents))
    document = next(iter(documents))
    rejected('DocumentBodyMutationRejected', lambda: compare_body(documents[document]['Body'], documents[document]['Body'] + '\nx=1', document))
    fake = 'VBA PROJECT EXPORT\n' + '='*100 + '\nCOMPONENT: One\nTYPE: 1\nLINES: 1\n' + '='*100 + '\nx=1\n'
    rejected('DuplicateExportComponentRejected', lambda: parse_dump(fake + fake.split('\n', 1)[1]))
    rejected('MalformedExportHeaderRejected', lambda: parse_dump(fake.replace('TYPE: 1', 'TYPE: bad')))
    require(all(checks.values()), 'Verifier negative controls failed: ' + repr(checks))
    return {'AllPassed': True, 'MechanismChecksOnly': True, 'ActualNativeDumpVerified': False,
            'Checks': checks, 'CheckCount': len(checks)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dump', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--self-checks-only', action='store_true')
    args = parser.parse_args()
    require(args.dump is not None or args.self_checks_only, '--dump required outside self-checks-only')
    output = args.output.resolve()
    require(output.is_relative_to(HERE) and not output.exists(), 'Output must be a fresh evidence subdirectory')
    output.mkdir(parents=True)
    report = {'AllPassed': False, 'Baseline': BASE, 'NativeExcelExecuted': False,
              'SourceFilesChanged': False, 'VerifierSHA256': sha(Path(__file__))}
    try:
        files, repository, documents, baseline_sha = load_sources()
        controls = self_checks(repository, documents)
        write_json(output / 'ProofSelfChecks.json', controls)
        if args.self_checks_only:
            report.update({'AllPassed': True, 'Mode': 'SELF_CHECKS_ONLY', 'ActualNativeDumpVerified': False,
                           'ProofSelfChecks': 'ProofSelfChecks.json', 'CheckCount': controls['CheckCount']})
        else:
            dump = args.dump.resolve(strict=True)
            initial_dump_sha = sha(dump)
            actual = parse_dump(dump.read_text(encoding='utf-8-sig'))
            inventory(actual, repository, documents)
            # numeric_evidence сохраняет только существующие семь пар и пишет исключительно в fresh output.
            prior.HERE = output
            prior.BASE = BASE
            legacy = prior.numeric_evidence(files, {name: item['Body'] for name, item in actual.items()})
            new_pairs = []
            statements = lambda text: [prior.code_line(line).strip().casefold() for line in text.splitlines()]
            for left, right in GEOMETRY_PAIRS:
                require(statements(repository['modTestGeometry']['Body']).count(left.casefold()) == 1, 'New pair source statement missing/duplicated')
                require(statements(actual['modTestGeometry']['Body']).count(right.casefold()) == 1, 'New pair native statement missing/duplicated')
                a, b = prior.NUMBER.findall(left), prior.NUMBER.findall(right)
                require(len(a) == len(b), 'Numeric token count differs')
                for old, new in zip(a, b):
                    require(Decimal(old.rstrip('#')) == Decimal(new.rstrip('#')), 'New pair Decimal differs')
                    require(struct.pack('<d', float(old.rstrip('#'))) == struct.pack('<d', float(new.rstrip('#'))), 'New pair binary64 differs')
                    if old != new:
                        require(not any(c in old + new for c in '@!%&^#'), 'Changed numeric type suffix')
                new_pairs.append({'SourceStatement': left, 'NativeStatement': right,
                                  'ExactlyEqualDecimal': True, 'ExactlyEqualBinary64': True})
            checks = []
            for name, source in repository.items():
                compare_body(source['Body'], actual[name]['Body'], name)
                checks.append({key: source[key] for key in ('Path', 'SourceSHA256', 'Type')} | {'Component': name, 'Passed': True})
            document_checks = []
            for name, baseline in documents.items():
                compare_body(baseline['Body'], actual[name]['Body'], name)
                document_checks.append({'Component': name, 'Type': 100, 'Baseline': BASE,
                                        'BaselineBodySHA256': hashlib.sha256(baseline['Body'].encode('utf-8')).hexdigest().upper(), 'Passed': True})
            events_path = ROOT / 'tools/build_workbook/WorkbookHelpEvents.vba'
            events_sha = sha(events_path)
            workbook = [name for name in documents if re.search(r'^Private Sub Workbook_Open\(\)', actual[name]['Body'], re.M | re.I)]
            require(len(workbook) == 1, 'Expected exactly one workbook events component')
            compare_body(events_path.read_text('utf-8-sig'), actual[workbook[0]]['Body'], workbook[0])
            for path in files:
                require(sha(path) == repository[path.stem]['SourceSHA256'], 'Source changed during verification: ' + path.stem)
            require(sha(events_path) == events_sha and sha(dump) == initial_dump_sha, 'Inputs changed during verification')
            report.update({'AllPassed': True, 'Mode': 'ACTUAL_NATIVE_DUMP', 'ActualNativeDumpVerified': True,
                           'Dump': str(dump), 'DumpSHA256': initial_dump_sha,
                           'ActualComponents': len(actual), 'RepositoryComponents': len(repository), 'DocumentComponents': len(documents),
                           'NoExtrasOrPrivateProbeModules': True, 'Checks': checks, 'GeneratedDocumentChecks': document_checks,
                           'BaselinePublishedDumpSHA256': baseline_sha, 'WorkbookEventsComponent': workbook[0],
                           'WorkbookHelpEventsSHA256': events_sha, 'WorkbookHelpEventsChecked': True,
                           'CommentUnicodeAndWhitespaceExact': True, 'StringLiteralsExact': True,
                           'VbeIdentifierCaseAndExistingFractionalDoubleMarkerOnly': True,
                           'NoGeneralNumericRounding': True, 'ClosedLegacyPairsWithBaselineProof': legacy['RuleCount'],
                           'ExactNewTestStatementPairs': new_pairs, 'ProofSelfChecks': 'ProofSelfChecks.json',
                           'NumericEvidence': 'VbeNumericCanonicalization.json'})
    except Exception as error:
        report['Error'] = type(error).__name__ + ': ' + str(error)
    write_json(output / 'NativeSourceEquality.json', report)
    print(json.dumps({key: value for key, value in report.items() if key not in ('Checks', 'GeneratedDocumentChecks', 'ExactNewTestStatementPairs')}, ensure_ascii=False))
    return 0 if report['AllPassed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
