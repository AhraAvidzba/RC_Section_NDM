"""Упаковывает компактные доказательства без книг, полного VBA и нормативных текстов."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RUN = ROOT / 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01'
read = lambda p: json.loads(p.read_text('utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest().upper()


def main():
    target = HERE / 'PostFullFixesEvidence_2026-10-23.zip'
    assert not target.exists(), 'Do not overwrite prior evidence'
    summary = read(RUN / 'Summary.json')
    assert summary['status'] == 'INCOMPLETE_OR_FAILED' and summary['completedSuites'] == summary['expectedSuites'] == 156
    groups = {key: [] for key in ('ZeroMomentFixture', 'NearZeroIxy', 'ImportMessageFixture', 'ManualFormulaFixture')}
    for job in summary['jobs']:
        for failure in job['failures']:
            if '.zeroSign.ea' in failure:
                key = 'ZeroMomentFixture'
            elif 'parameter=Transformed.Ixy' in failure:
                key = 'NearZeroIxy'
            elif 'audit03.importUnits.' in failure:
                key = 'ImportMessageFixture'
            elif 'offset.input.formula.manual.recalculated' in failure:
                key = 'ManualFormulaFixture'
            else:
                raise ValueError('Unclassified original failure: ' + failure)
            groups[key].append({'Report': job['name'], 'Mode': job['mode'], 'Failure': failure})
    counts = {key: len(value) for key, value in groups.items()}
    assert counts == {'ZeroMomentFixture': 4, 'NearZeroIxy': 48, 'ImportMessageFixture': 20, 'ManualFormulaFixture': 2}
    publication = read(HERE / 'PostFullRelease01/Publication.json')
    directed = read(HERE / 'PostFullRelease01/DirectedAcceptance.json')
    assert publication['Status'] == 'CODE_ONLY_PUBLISHED' and directed['Status'] == 'DIRECTED_ACCEPTANCE_PASS'
    assert publication['WorkbookSHA256'] == directed['ReleaseSHA256']
    closure = {'OriginalRunStatus': summary['status'], 'OriginalRunSHA256': summary['sourceSHA256'],
               'Original156SuitesFinished': True, 'OriginalFailures': counts, 'OriginalRunNotRelabelledPass': True,
               'OriginalFocused': read(RUN / 'Focused/Acceptance.json'), 'CorrectionsApplied': True,
               'NewReleaseSHA256': publication['WorkbookSHA256'], 'DirectedModes': directed['Modes'],
               'FullAcceptanceOfNewReleaseClaimed': False, 'NextFullRunRequiresSuccessfulPushBeforeLaunch': True,
               'FailureEvidence': groups}
    closure_path = HERE / 'PostFullFixClosure.json'
    assert not closure_path.exists()
    closure_path.write_text(json.dumps(closure, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    names = [
        'FullLaunch.json', 'PostFullFixPlan.json', 'PostFullFixClosure.json', 'FullRunMonitorSnapshots.jsonl',
        'Run-PostFullProbes.ps1', 'Compile-PostFullRelease.ps1', 'Prepare-PostFullRelease.py',
        'Publish-PostFullRelease.ps1', 'Launch-CorrectedFullRun02.ps1', 'Finalize-PostFullDirected.py',
        'VerifyPostFullNativeSources.py', 'PriorSourceVerifier.py', 'Pack-PostFullFixEvidence.py',
        'PostFullDocumentationAudit.json', 'PostFullCoverageProof.json', 'BuildPostFullCoverageProof.py',
        'PostFullNativeBaseline01_Probes.json', 'PostFullNativeCandidate01_Probes.json',
        'Math/PostFullMathCoverage.json', 'Math/FullUI_Ixy/NativeBaselineExactOracle.json',
        'Math/FullUI_Ixy/NativeCandidateExactOracle.json', 'Math/FullUI_Ixy/ActualNativeBaselineReview.json',
        'Math/FullUI_Ixy/ActualNativeCandidateReview.json', 'Math/FullUI_Ixy/ActualNativeBaselineCandidateComparison.json',
        'Math/FullUI_Ixy/RootApplyDecision.json', 'Math/FullUI_Ixy/CenteredMomentsProposal_NOT_APPLIED.patch',
        'Math/FullUI_Ixy/modTestInputIxyBaseline.bas', 'Math/FullUI_Ixy/modTestIxyPerformance.bas',
        'Math/FullUI_Ixy/AnalyzeNativeIxyArrays.py', 'Math/ZeroMomentSign_FullOff/FixtureOnlyProposal_NOT_APPLIED.patch',
        'Excel/FullUI_ImportUnits/FixtureOnlyProposal_NOT_APPLIED.patch',
        'Excel/FullRecipes_ManualFormula/FixtureOnlyProposal_NOT_APPLIED.patch',
        'Excel/PostFullPublicationToolsReview.json', 'Excel/CorrectedFullRun02LaunchReview.json',
        'PostFullRelease01/CleanCompile.json', 'PostFullRelease01/RepoManifest.json',
        'PostFullRelease01/PartPreservation.json', 'PostFullRelease01/SourceProof01/NativeSourceEquality.json',
        'PostFullRelease01/SourceProof01/ProofSelfChecks.json', 'PostFullRelease01/SourceProof01/VbeNumericCanonicalization.json',
        'PostFullRelease01/ActualReleaseVBA.txt.ReadOnly.json', 'PostFullRelease01/DirectedAcceptance.json',
        'PostFullRelease01/Publication.json',
    ]
    paths = [(HERE / name, 'WorkingCodeReview/' + name) for name in names]
    for name in ('Run.json', 'Summary.json', 'FullRunner.ps1', 'ModeRunner.ps1', 'Focused/Run.json',
                 'Focused/Acceptance.json', 'Focused/Independent.json', 'Focused/NativeCAD/Stage.json'):
        paths.append((RUN / name, 'OriginalRun01/' + name))
    manifest = []
    with ZipFile(target, 'x', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for path, name in paths:
            assert path.is_file(), str(path)
            assert path.suffix.lower() not in ('.xlsm', '.xlsx', '.pdf') and 'NormText' not in str(path)
            data = path.read_bytes()
            archive.writestr(name, data)
            manifest.append({'Path': name, 'Bytes': len(data), 'SHA256': sha(data)})
        archive.writestr('Manifest.json', json.dumps({'Files': manifest, 'FullPassClaimed': False}, ensure_ascii=False, indent=2))
    proof = {'Archive': target.name, 'SHA256': sha(target.read_bytes()), 'Bytes': target.stat().st_size,
             'Files': len(manifest), 'NoWorkbooksOrNormativeTexts': True, 'FullPassClaimed': False}
    (HERE / 'PostFullFixesEvidence_2026-10-23.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof))


if __name__ == '__main__':
    main()
