"""Связывает адресные ON/OFF и фактический VBA с точными байтами кандидата; не общий PASS."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DIRECTORY = HERE / 'PostFullRelease01'
MACROS = [
    'modTestGeometry.RunGeometryTests',
    'modTestConfiguration.RunAudit03StabilityConfigTests',
    'modTestWorkbookInterface.RunAudit03InputUnitConsumerTests',
    'modTestWorkbookInterface.RunAudit03ImportedSnapshotUnitChangeTests',
    'modTestAudit02Api.RunIndependentRowOffsetWorkbookTests',
    'modTestSectionSolver.RunSectionSolverTests',
]
read = lambda p: json.loads(p.read_text('utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest().upper()


def main():
    output = DIRECTORY / 'DirectedAcceptance.json'
    assert not output.exists(), 'Preserve existing evidence'
    part = read(DIRECTORY / 'PartPreservation.json')
    workbook = Path(part['ReleaseWorkbook'])
    assert sha(workbook) == part['ReleaseSHA256'] and part['NonVBAPartsByteExact']
    assert part['AllowedChangedParts'] == ['xl/vbaProject.bin']
    source = read(DIRECTORY / 'SourceProof01/NativeSourceEquality.json')
    opened = read(DIRECTORY / 'ActualReleaseVBA.txt.ReadOnly.json')
    assert source['AllPassed'] and source['ActualNativeDumpVerified'] and source['NoExtrasOrPrivateProbeModules']
    assert source['ActualComponents'] == 170 and source['RepositoryComponents'] == 164 and source['DocumentComponents'] == 6
    assert source['DumpSHA256'] == sha(DIRECTORY / 'ActualReleaseVBA.txt')
    assert opened['SourceSHA256'] == part['ReleaseSHA256'] and opened['ReadOnly'] and opened['Automatic'] and not opened['MacrosExecuted']
    for item in source['Checks']:
        assert sha(ROOT / item['Path']) == item['SourceSHA256'], item['Component']
    documentation = read(HERE / 'PostFullDocumentationAudit.json')
    assert not any(value for key, value in documentation.items() if key.startswith('Missing'))
    assert documentation['ModuleCount'] == 169 and documentation['MethodCount'] == 5781
    native = read(HERE / 'PostFullNativeCandidate01_Probes.json')
    assert native['Status'] == 'PROBES_COMPLETED' and native['SourceUnchanged'] and native['PublishedUnchanged']
    production = [x for x in native['Imports'] if x['Candidate']]
    assert len(production) == 1 and production[0]['Name'] == 'CSectionPropertiesCalculator'
    assert sha(ROOT / production[0]['Path']) == production[0]['SHA256']
    oracle = read(HERE / 'Math/FullUI_Ixy/NativeCandidateExactOracle.json')
    unit_pairs = [p for p in oracle['UnitPairs'] if p['Method'] == 'NativeCurrent']
    assert len(unit_pairs) == 4 and all(p['WithinExisting8Eps'] for p in unit_pairs)
    counts = {}
    for mode, label in [('No', 'Off'), ('Yes', 'On')]:
        path = HERE / ('PostFullDirected' + label + '01_Probes.json')
        run = read(path)
        assert run['Status'] == 'PROBES_COMPLETED' and run['SourceUnchanged'] and run['PublishedUnchanged']
        assert run['SourceSHA256'] == part['ReleaseSHA256'] and run['NoCodeImported'] and not run['Imports']
        assert run['DiagramExtension'] == mode and [p['Macro'] for p in run['Probes']] == MACROS
        checks = []
        for probe in run['Probes']:
            assert not re.search(r'(?mi)^(?:FAIL:|RUNTIME ERROR|SCRIPT ERROR|RESTORE ERROR|CLEANUP ERROR)', probe['Actual']), probe['Macro']
            totals = re.findall(r'(?m)^TOTAL[^\r\n]*?passed=(\d+);\s*failed=(\d+)', probe['Actual'])
            assert totals and all(int(failed) == 0 for _, failed in totals), probe['Macro']
            checks.append({'Macro': probe['Macro'], 'Passed': int(totals[-1][0]), 'Failed': 0, 'Seconds': probe['Seconds']})
        counts[label] = {'Groups': checks, 'Passed': sum(p['Passed'] for p in checks), 'EvidenceSHA256': sha(path)}
    result = {'Status': 'DIRECTED_ACCEPTANCE_PASS', 'FullAcceptanceClaimed': False,
              'ReleaseSHA256': part['ReleaseSHA256'], 'DumpSHA256': source['DumpSHA256'],
              'GroupsPerMode': len(MACROS), 'Modes': counts, 'NoCodeImportedDuringDirectedTests': True,
              'NativeExactInputUnitPairsWithinUnchanged8Eps': True, 'SourceEqualitySHA256': sha(DIRECTORY / 'SourceProof01/NativeSourceEquality.json'),
              'PartPreservationSHA256': sha(DIRECTORY / 'PartPreservation.json'), 'DocumentationAuditSHA256': sha(HERE / 'PostFullDocumentationAudit.json'),
              'NativeProbeModulesExcludedFromRelease': True, 'All111NonVBAPartsPreserved': part['PreservedParts'] == 111,
              'ReadyForPublicationAndAuthorizedFullRun': True}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key != 'Modes'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
