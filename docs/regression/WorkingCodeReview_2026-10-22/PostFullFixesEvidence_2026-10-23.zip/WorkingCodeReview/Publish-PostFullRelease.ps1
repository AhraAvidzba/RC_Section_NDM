﻿# Публикует проверенную пару XLSM/VBA dump с эксклюзивными блокировками, backup и откатом при обычной ошибке.
param(
    [Parameter(Mandatory=$true)][string]$Directory,
    [Parameter(Mandatory=$true)][string]$ExpectedOldWorkbookSHA256,
    [Parameter(Mandatory=$true)][string]$ExpectedOldDumpSHA256
)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
function Hash([string]$path){(Get-FileHash -LiteralPath $path).Hash}
function ReadJson([string]$path){Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json}
function BytesHash([byte[]]$bytes){$s=[Security.Cryptography.SHA256]::Create();try{[BitConverter]::ToString($s.ComputeHash($bytes)).Replace('-','')}finally{$s.Dispose()}}
function ReadBytes($stream){$m=New-Object IO.MemoryStream;try{$stream.Position=0;$stream.CopyTo($m);return ,$m.ToArray()}finally{$m.Dispose()}}
function WriteBytes($stream,[byte[]]$bytes){$stream.Position=0;$stream.SetLength(0);$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}
function BackupBytes([string]$path,[byte[]]$bytes){$stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}}
$run=ReadJson (Join-Path $root 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01/Run.json')
$launch=ReadJson (Join-Path $PSScriptRoot 'FullLaunch.json')
if($launch.PID -ne 201048 -or [long]$launch.ProcessStartTicks -ne 639283000561781001){throw 'Reviewed full-run identity changed.'}
$driver=Get-Process -Id 201048 -ErrorAction SilentlyContinue
if(($driver -and $driver.StartTime.ToUniversalTime().Ticks -eq 639283000561781001) -or -not $run.FinishedUTC -or $run.Status -notin @('REVIEW_REQUIRED','COMPLETED_PENDING_LOG_REVIEW','DEADLINE_REACHED')){throw 'Participating full run must have stopped completely.'}
$directoryPath=if([IO.Path]::IsPathRooted($Directory)){$Directory}else{Join-Path $root $Directory}
$directoryPath=(Resolve-Path -LiteralPath $directoryPath).Path
if(-not $directoryPath.StartsWith($PSScriptRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Release evidence must stay in the owned directory.'}
$part=ReadJson (Join-Path $directoryPath 'PartPreservation.json')
$sourcePath=Join-Path $directoryPath 'SourceProof01/NativeSourceEquality.json';$source=ReadJson $sourcePath
$gatePath=Join-Path $directoryPath 'DirectedAcceptance.json';$gate=ReadJson $gatePath
$coveragePath=Join-Path $PSScriptRoot 'PostFullCoverageProof.json';$coverage=ReadJson $coveragePath
if($part.Status -ne 'VBA_ONLY_MERGE_PASS' -or -not $part.NonVBAPartsByteExact -or $part.PreservedParts -ne 111 -or @($part.AllowedChangedParts).Count -ne 1 -or $part.AllowedChangedParts[0] -cne 'xl/vbaProject.bin'){throw 'Code-only preservation proof is incomplete.'}
if(-not $source.AllPassed -or -not $source.ActualNativeDumpVerified -or -not $source.NoExtrasOrPrivateProbeModules -or $source.ActualComponents -ne 170){throw 'Actual VBA equality proof is incomplete.'}
if($gate.Status -ne 'DIRECTED_ACCEPTANCE_PASS' -or $gate.FullAcceptanceClaimed -or -not $gate.ReadyForPublicationAndAuthorizedFullRun -or -not $gate.NoCodeImportedDuringDirectedTests){throw 'Directed acceptance proof is incomplete.'}
if(-not $coverage.AllPassed -or $coverage.CurrentSrcFileCount -ne 117 -or $coverage.CurrentMethodCount -ne 3711){throw 'Current audit coverage proof is incomplete.'}
$candidate=Join-Path $directoryPath 'Release/RC_Section_NDM.xlsm';$dump=Join-Path $directoryPath 'ActualReleaseVBA.txt'
if((Hash $candidate) -cne $part.ReleaseSHA256 -or $gate.ReleaseSHA256 -cne $part.ReleaseSHA256 -or (Hash $dump) -cne $source.DumpSHA256 -or $gate.DumpSHA256 -cne $source.DumpSHA256){throw 'Reviewed release bytes changed.'}
if((Hash $sourcePath) -cne $gate.SourceEqualitySHA256 -or (Hash (Join-Path $directoryPath 'PartPreservation.json')) -cne $gate.PartPreservationSHA256){throw 'Reviewed release evidence changed.'}
foreach($check in $source.Checks){if((Hash (Join-Path $root $check.Path)) -cne $check.SourceSHA256){throw ('Source changed after equality proof: '+$check.Component)}}
if((Hash (Join-Path $root 'tools/build_workbook/WorkbookHelpEvents.vba')) -cne $source.WorkbookHelpEventsSHA256){throw 'Workbook events source changed.'}
$target=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$targetDump=Join-Path $root 'workbook/output/VBA_All_Code.txt'
if($part.SourceSHA256 -cne $ExpectedOldWorkbookSHA256.ToUpperInvariant()){throw 'Publication base does not match the preserved workbook.'}
$foreignRoots=@((Join-Path $root 'workbook/output'),(Join-Path $root 'outputs'))|Where-Object {Test-Path -LiteralPath $_}
$foreign=@(Get-ChildItem -LiteralPath $foreignRoots -Recurse -File|Where-Object {$_.FullName -notin @($target,$targetDump)}|ForEach-Object {[ordered]@{Path=$_.FullName.Substring($root.Length+1);SHA256=Hash $_.FullName}})
$backup=Join-Path $directoryPath 'PublicationBackup';$report=Join-Path $directoryPath 'Publication.json'
if((Test-Path -LiteralPath $backup) -or (Test-Path -LiteralPath $report)){throw 'Publication evidence already exists.'}
$bookStream=$null;$dumpStream=$null;$written=$false
try{
    $bookStream=[IO.File]::Open($target,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $dumpStream=[IO.File]::Open($targetDump,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    [byte[]]$oldBook=ReadBytes $bookStream;[byte[]]$oldDump=ReadBytes $dumpStream
    if((BytesHash $oldBook) -cne $ExpectedOldWorkbookSHA256.ToUpperInvariant() -or (BytesHash $oldDump) -cne $ExpectedOldDumpSHA256.ToUpperInvariant()){throw 'User output changed; do not overwrite.'}
    [void][IO.Directory]::CreateDirectory($backup)
    BackupBytes (Join-Path $backup 'RC_Section_NDM.xlsm') $oldBook
    BackupBytes (Join-Path $backup 'VBA_All_Code.txt') $oldDump
    $written=$true
    WriteBytes $bookStream ([IO.File]::ReadAllBytes($candidate));WriteBytes $dumpStream ([IO.File]::ReadAllBytes($dump))
    if((BytesHash (ReadBytes $bookStream)) -cne $part.ReleaseSHA256 -or (BytesHash (ReadBytes $dumpStream)) -cne $source.DumpSHA256){throw 'Published bytes do not match the candidate.'}
    foreach($item in $foreign){if((Hash (Join-Path $root $item.Path)) -cne $item.SHA256){throw ('Foreign output changed: '+$item.Path)}}
    [ordered]@{Status='CODE_ONLY_PUBLISHED';PublishedUTC=(Get-Date).ToUniversalTime().ToString('o');BeforeWorkbookSHA256=$ExpectedOldWorkbookSHA256.ToUpperInvariant();BeforeDumpSHA256=$ExpectedOldDumpSHA256.ToUpperInvariant();WorkbookSHA256=$part.ReleaseSHA256;DumpSHA256=$source.DumpSHA256;AllowedChangedParts=@('xl/vbaProject.bin');All111NonVBAPartsByteExact=$true;Actual170ComponentInventory=$true;NoProbeModules=$true;SourceEqualitySHA256=Hash $sourcePath;DirectedAcceptanceSHA256=Hash $gatePath;CoverageProofSHA256=Hash $coveragePath;ForeignOutputsPreserved=$true;ForeignOutputs=$foreign;BackupDirectory=$backup;RunnerSHA256=Hash $PSCommandPath;FullAcceptanceClaimed=$false}|ConvertTo-Json -Depth 7|Set-Content -LiteralPath $report -Encoding UTF8
}catch{
    if($written){WriteBytes $bookStream $oldBook;WriteBytes $dumpStream $oldDump}
    throw
}finally{if($dumpStream){$dumpStream.Dispose()};if($bookStream){$bookStream.Dispose()}}
Write-Output ('CODE_ONLY_PUBLISHED: '+(Hash $target))
