﻿# ДЛЯ ТЕСТОВ: НЕАКТИВНЫЙ шаблон. Root проверяет текст и создаёт .ps1 только после завершения полного прогона.
# Источник и ожидаемый SHA256 задаются явно; приватные probe-книги никогда не являются выпуском для публикации.
# COM/import/compile/probe ядро основано на Run-BaselineProbes.ps1; старый runner и участвующие сценарии не меняются.
param(
    [Parameter(Mandatory=$true)][string]$SourceWorkbook,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{64}$')][string]$ExpectedSourceSHA256,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_.-]{0,70}$')][string]$Label,
    [Alias('ModulePathTest')][string[]]$ModulePath=@(),
    [string[]]$Macro=@(),
    [Alias('CandidateModulePathsrc')][string[]]$CandidateModulePath=@(),
    [switch]$SavePrivateCandidate,
    [ValidateSet('','Yes','No')][string]$Mode=''
)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$launchPath=Join-Path $PSScriptRoot 'FullLaunch.json'
$runPath=Join-Path $root 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01/Run.json'
$published=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$expectedDriverPID=201048
$expectedDriverTicks=[long]639283000561781001
$expectedRunDirectory='docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01'

# Проверяет обязательную пару журналов и точную идентичность драйвера, а не только наличие процесса с таким PID.
function Assert-FullAcceptanceStopped {
    $launch=Get-Content -LiteralPath $launchPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $run=Get-Content -LiteralPath $runPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if([int]$launch.PID -ne $expectedDriverPID -or [long]$launch.ProcessStartTicks -ne $expectedDriverTicks){throw 'FullLaunch driver identity differs from the reviewed launch; review this runner before use.'}
    if(([string]$launch.EvidenceDirectory).Replace('\','/') -cne $expectedRunDirectory){throw 'FullLaunch evidence directory does not identify the guarded full run.'}
    $driver=Get-Process -Id $expectedDriverPID -ErrorAction SilentlyContinue
    if($driver -and $driver.StartTime.ToUniversalTime().Ticks -eq $expectedDriverTicks){throw 'The exact full-acceptance driver is still alive; post-full probes are prohibited.'}
    if([string]$run.Status -eq 'RUNNING'){throw 'Full acceptance is RUNNING; post-full probes are prohibited.'}
    if([string]$run.Status -notin @('REVIEW_REQUIRED','COMPLETED_PENDING_LOG_REVIEW','DEADLINE_REACHED')){throw ('Full run has no recognized terminal status: '+[string]$run.Status)}
    if(-not $run.FinishedUTC){throw 'Full run has no FinishedUTC; do not infer completion from a missing driver.'}
    $finished=[DateTimeOffset]::Parse([string]$run.FinishedUTC)
    $started=[DateTimeOffset]::Parse([string]$run.StartedUTC)
    if($finished -lt $started -or $finished -gt [DateTimeOffset]::UtcNow.AddSeconds(5)){throw 'Full-run finish timestamp is inconsistent.'}
    if([string]$run.SourceSHA256 -cne [string]$launch.SourceSHA256 -or [string]$run.SourceCommit -cne [string]$launch.SourceCommit){throw 'FullRun/FullLaunch source identities disagree.'}
    return [ordered]@{Status=[string]$run.Status;FinishedUTC=[string]$run.FinishedUTC;DriverPID=$expectedDriverPID;DriverStartTicks=$expectedDriverTicks;RunManifest=$runPath;FullLaunch=$launchPath}
}

# Ограничивает входы рабочим деревом: источник, тесты и candidate-модули не должны разрешаться вне проекта.
function Resolve-WorkspaceFile([string]$Path) {
    $resolved=(Resolve-Path -LiteralPath $(if([IO.Path]::IsPathRooted($Path)){$Path}else{Join-Path $root $Path})).Path
    if(-not $resolved.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw ('Path must be inside the project workspace: '+$Path)}
    if(-not [IO.File]::Exists($resolved)){throw ('Expected a file: '+$resolved)}
    return $resolved
}

# Возвращает true только для собственного всё ещё существующего Excel с исходным временем старта.
function Test-OwnedExcelIdentity {
    if(-not $ownedPid -or -not $ownedTicks){return $false}
    $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
    return [bool]($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks)
}

# Перед каждым этапом Excel повторяет запрет пересечения с полным прогоном; cleanup собственного PID остаётся обязательным.
function Assert-ProbeExcelStage {
    $null=Assert-FullAcceptanceStopped
    if(-not (Test-OwnedExcelIdentity)){throw 'Owned Excel process identity changed; no further COM actions are permitted.'}
}

$fullGuard=Assert-FullAcceptanceStopped # До Copy/COM проверяем не только имя папки, но статус, finish и живой точный драйвер.
$source=Resolve-WorkspaceFile $SourceWorkbook
if([IO.Path]::GetExtension($source) -ine '.xlsm'){throw 'SourceWorkbook must be an explicit xlsm file inside the workspace.'}
$hash=(Get-FileHash -LiteralPath $source).Hash
if($hash -cne $ExpectedSourceSHA256.ToUpperInvariant()){throw 'SourceWorkbook SHA256 differs from the explicit expected hash.'}
$publishedHash=(Get-FileHash -LiteralPath $published).Hash
if(-not $Macro.Count){throw 'At least one explicit module.entrypoint probe is required.'}
foreach($entry in $Macro){if($entry -notmatch '^[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*$'){throw ('Invalid qualified probe entrypoint: '+$entry)}}
$imports=@()
$importNames=@{}
foreach($relativeFile in @($CandidateModulePath)+@($ModulePath | Select-Object -Unique)){
    $file=Resolve-WorkspaceFile $relativeFile
    if([IO.Path]::GetExtension($file) -notin @('.bas','.cls')){throw ('Only bas/cls probe imports are supported: '+$relativeFile)}
    $text=[IO.File]::ReadAllText($file,[Text.Encoding]::UTF8)
    $name=[regex]::Match($text,'(?m)^Attribute VB_Name = "([^"]+)"').Groups[1].Value
    if(-not $name -or $name.Length -gt 31){throw ('Invalid VBA component name (maximum 31 characters): '+$name)}
    if($importNames.ContainsKey($name)){throw ('Duplicate VBA component import: '+$name)}
    $importNames[$name]=$true
    $isCandidate=$relativeFile -in $CandidateModulePath
    if(-not $isCandidate -and -not $name.Contains('Test')){throw 'Probe module must have an explicit Test name.'}
    if($isCandidate -and -not $file.StartsWith((Join-Path $root 'src')+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Candidate import must be a working source file inside src.'}
    $body=if($text -match '(?m)^VERSION 1.0 CLASS'){[regex]::Match($text,'(?ms)^Option Explicit.*').Value}else{[regex]::Replace($text,'(?m)^Attribute .*(\r?\n|$)','')}
    if(-not $body){throw ('Empty VBA import body: '+$relativeFile)}
    $imports+=,[ordered]@{Name=$name;Path=$relativeFile;SHA256=(Get-FileHash -LiteralPath $file).Hash;Body=$body;Type=$(if($file.EndsWith('.cls',[StringComparison]::OrdinalIgnoreCase)){2}else{1});Candidate=$isCandidate}
}
$private=Join-Path $PSScriptRoot ($Label+'_Probes.xlsm')
$report=Join-Path $PSScriptRoot ($Label+'_Probes.json')
if((Test-Path -LiteralPath $private) -or (Test-Path -LiteralPath $report)){throw 'Label is not fresh; existing private workbook or evidence must never be overwritten.'}
if($private -ieq $source -or $private -ieq $published){throw 'Private probe path must differ from protected workbooks.'}
[IO.File]::Copy($source,$private,$false) # overwrite=false дополнительно защищает от одновременного запуска с тем же Label.
if((Get-FileHash -LiteralPath $private).Hash -cne $hash){throw 'Private workbook copy does not match the verified source.'}
if(-not ('WorkingReviewExcelWindow' -as [type])){Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class WorkingReviewExcelWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint id);}'}
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0;$failure=$null
$result=[ordered]@{Status='RUNNING';SourceWorkbook=$source;SourceSHA256=$hash;ExpectedSourceSHA256=$ExpectedSourceSHA256.ToUpperInvariant();PublishedWorkbook=$published;PublishedSHA256=$publishedHash;ProductionCodeChanged=$false;PrivateCandidateImported=($CandidateModulePath.Count -gt 0);OnlyTestModulesImported=($ModulePath.Count -gt 0 -and $CandidateModulePath.Count -eq 0);NoCodeImported=($imports.Count -eq 0);PrivateArtifactOnly=$true;PublicationEligible=$false;FullRunGuard=$fullGuard;Imports=@($imports | ForEach-Object {[ordered]@{Name=$_.Name;Path=$_.Path;SHA256=$_.SHA256;Candidate=$_.Candidate}});Probes=@()}
$result.StartedUTC=(Get-Date).ToUniversalTime().ToString('o')
$result.RunnerSHA256=(Get-FileHash -LiteralPath $PSCommandPath).Hash
try{
    $null=Assert-FullAcceptanceStopped
    $existingExcelIds=@(Get-Process -Name EXCEL -ErrorAction SilentlyContinue | ForEach-Object Id)
    $excel=New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][WorkingReviewExcelWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    if([int]$id -in $existingExcelIds){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null;throw 'Excel reused a pre-existing user process; no settings or workbooks were changed.'}
    if(-not $id){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null;throw 'Cannot resolve the new Excel process; no settings or workbooks were changed.'}
    $ownedPid=[int]$id;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
    Assert-ProbeExcelStage
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=1
    $result.OwnPID=$ownedPid;$result.OwnStartTicks=$ownedTicks
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $report -Encoding UTF8
    Write-Output "OWNED_EXCEL: id=$ownedPid; utcStartTicks=$ownedTicks"
    Assert-ProbeExcelStage
    $book=$excel.Workbooks.Open($private,0,$false)
    if($book.ReadOnly){throw 'Private probe workbook must be writable in memory.'}
    $components=@{}
    foreach($present in $book.VBProject.VBComponents){$components[$present.Name]=$present}
    foreach($import in $imports){
        Assert-ProbeExcelStage
        $file=Resolve-WorkspaceFile $import.Path
        if((Get-FileHash -LiteralPath $file).Hash -cne $import.SHA256){throw ('Import file changed after preflight: '+$import.Path)}
        $component=$components[$import.Name]
        if(-not $component){$component=$book.VBProject.VBComponents.Add($import.Type);$component.Name=$import.Name;$components[$import.Name]=$component}
        if($component.Type -ne $import.Type){throw ('Component type mismatch: '+$import.Name)}
        if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
        $component.CodeModule.AddFromString($import.Body)
    }
    Assert-ProbeExcelStage
    $excel.VBE.ActiveVBProject=$book.VBProject
    $compile=$excel.VBE.CommandBars.FindControl(1,578)
    if($compile.Enabled){$compile.Execute()}
    if($compile.Enabled){
        $pane=$excel.VBE.ActiveCodePane
        [int]$firstLine=0;[int]$firstColumn=0;[int]$lastLine=0;[int]$lastColumn=0
        $pane.GetSelection([ref]$firstLine,[ref]$firstColumn,[ref]$lastLine,[ref]$lastColumn)
        $location='module='+$pane.CodeModule.Parent.Name+'; line='+$firstLine+'; column='+$firstColumn
        $result.CompileLocation=$location
        Write-Output ('COMPILE_LOCATION: '+$location)
        Write-Output $pane.CodeModule.Lines([Math]::Max(1,$firstLine-2),5)
        throw 'Probe module compilation failed.'
    }
    if($SavePrivateCandidate){
        Assert-ProbeExcelStage
        $book.Save() # Только приватный compiled artifact ДО fixtures; даже он непригоден для публикации probe-модулей.
        $result.SavedPrivateCandidate=$private
    }
    if($Mode){
        Assert-ProbeExcelStage
        $modeRange=$book.Names.Item('rngSystemSettings').RefersToRange
        $modeData=$modeRange.Value2;$modeRow=0
        for($r=2;$r -le $modeRange.Rows.Count;$r++){
            if([string]$modeData[$r,1] -ceq 'General.DiagramExtension'){
                if($modeRow){throw 'Duplicated test mode setting.'};$modeRow=$r
            }
        }
        if(-not $modeRow){throw 'Missing test mode setting.'}
        $modeRange.Cells.Item($modeRow,2).Value2=$Mode
        $result.DiagramExtension=$Mode
    }
    foreach($entry in $Macro){
        Assert-ProbeExcelStage
        Write-Output ('PROBE_STARTED: '+$entry)
        $probeWatch=[Diagnostics.Stopwatch]::StartNew()
        $actual=[string]$excel.Run("'"+$book.Name.Replace("'","''")+"'!"+$entry)
        $probeWatch.Stop()
        $result.Probes+=,[ordered]@{Macro=$entry;Actual=$actual;Seconds=$probeWatch.Elapsed.TotalSeconds}
        $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $report -Encoding UTF8
        $actual -split '\r?\n' | Where-Object {$_ -match '^(TOTAL|FAIL:|CASE\||SHIFT\||REPRO_|ANNOTATION_BENCH|LAYOUT_BENCH|RAW_AREA|RELATIVE_PERCENT|Platform=)'} | Write-Output
    }
    Assert-ProbeExcelStage
    $book.Close($false);$book=$null
    if($SavePrivateCandidate){$result.SavedPrivateSHA256=(Get-FileHash -LiteralPath $private).Hash}
    $result.Status='PROBES_COMPLETED'
    $result.CompletedUTC=(Get-Date).ToUniversalTime().ToString('o')
}catch{
    $failure=$_
    $result.Status='PROBE_ERROR';$result.Error=$_.Exception.Message
}finally{
    $cleanupErrors=@()
    if($book -and (Test-OwnedExcelIdentity)){
        try{$book.Close($false)}catch{$cleanupErrors+=('Book.Close: '+$_.Exception.Message)}
    }
    $book=$null
    if($excel){
        try{if(Test-OwnedExcelIdentity){$excel.Quit()}}catch{$cleanupErrors+=('Excel.Quit: '+$_.Exception.Message)}
        finally{try{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}catch{$cleanupErrors+=('ReleaseComObject: '+$_.Exception.Message)}}
    }
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if(Test-OwnedExcelIdentity){try{Stop-Process -Id $ownedPid -Force}catch{$cleanupErrors+=('Stop owned Excel: '+$_.Exception.Message)}}
    $result.CleanupErrors=$cleanupErrors
    foreach($check in @(@{Kind='Source';Path=$source;Before=$hash},@{Kind='Published';Path=$published;Before=$publishedHash})){
        try{
            $afterHash=(Get-FileHash -LiteralPath $check.Path).Hash
            $result[($check.Kind+'SHA256After')]=$afterHash
            $result[($check.Kind+'Unchanged')]=($afterHash -ceq $check.Before)
            if($afterHash -cne $check.Before){throw ($check.Kind+' workbook changed during isolated probes.')}
        }catch{
            if(-not $failure){$failure=$_}
            $result.Status='PROBE_ERROR';$result[($check.Kind+'IntegrityError')]=$_.Exception.Message
        }
    }
    if($cleanupErrors.Count){$result.Status='PROBE_ERROR';if(-not $failure){$failure='Owned Excel cleanup failed; inspect CleanupErrors.'}}
    $result.FinishedUTC=(Get-Date).ToUniversalTime().ToString('o')
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $report -Encoding UTF8
}
if($failure){throw $failure}
