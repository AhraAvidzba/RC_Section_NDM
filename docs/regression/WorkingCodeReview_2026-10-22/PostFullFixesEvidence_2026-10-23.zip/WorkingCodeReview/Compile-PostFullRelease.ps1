﻿# Собирает только VBA в свежей копии: без тестовых fixtures, запуска макросов и изменений опубликованной книги.
param(
    [Parameter(Mandatory=$true)][string]$SourceWorkbook,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{64}$')][string]$ExpectedSourceSHA256,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_.-]{0,70}$')][string]$Label
)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -ne 'Desktop'){throw 'Use Windows PowerShell 5.1.'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
function Assert-Stopped {
    $run=Get-Content -LiteralPath (Join-Path $root 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01/Run.json') -Raw -Encoding UTF8|ConvertFrom-Json
    $launch=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'FullLaunch.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if($launch.PID -ne 201048 -or [long]$launch.ProcessStartTicks -ne 639283000561781001){throw 'Reviewed full-run identity changed.'}
    $process=Get-Process -Id 201048 -ErrorAction SilentlyContinue
    if($process -and $process.StartTime.ToUniversalTime().Ticks -eq 639283000561781001){throw 'Full-run driver is still alive.'}
    if(-not $run.FinishedUTC -or $run.Status -notin @('REVIEW_REQUIRED','COMPLETED_PENDING_LOG_REVIEW','DEADLINE_REACHED')){throw 'Full-run terminal evidence is required.'}
    if($run.SourceSHA256 -cne $launch.SourceSHA256 -or $run.SourceCommit -cne $launch.SourceCommit){throw 'Full-run provenance differs.'}
}
function Hash([string]$path){(Get-FileHash -LiteralPath $path).Hash}
function TextHash([string]$text){$h=[Security.Cryptography.SHA256]::Create();try{[BitConverter]::ToString($h.ComputeHash([Text.Encoding]::UTF8.GetBytes($text))).Replace('-','')}finally{$h.Dispose()}}
function CodeText($component){if($component.CodeModule.CountOfLines){return [string]$component.CodeModule.Lines(1,$component.CodeModule.CountOfLines)};return ''}
function Test-Owned {
    if(-not $ownedPid -or -not $ownedTicks){return $false}
    $p=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
    return [bool]($p -and $p.ProcessName -eq 'EXCEL' -and $p.StartTime.ToUniversalTime().Ticks -eq $ownedTicks)
}
function Assert-Stage {Assert-Stopped;if(-not (Test-Owned)){throw 'Owned Excel identity changed.'}}
Assert-Stopped
$sourcePath=if([IO.Path]::IsPathRooted($SourceWorkbook)){$SourceWorkbook}else{Join-Path $root $SourceWorkbook}
$source=(Resolve-Path -LiteralPath $sourcePath).Path
if(-not $source.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Source must stay inside the workspace.'}
if((Hash $source) -cne $ExpectedSourceSHA256.ToUpperInvariant()){throw 'Explicit source hash differs.'}
$published=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$dump=Join-Path $root 'workbook/output/VBA_All_Code.txt'
$publishedHash=Hash $published;$dumpHash=Hash $dump
$directory=Join-Path $PSScriptRoot $Label
if(Test-Path -LiteralPath $directory){throw 'A fresh label is required.'}
$imports=@();$names=@{}
foreach($file in Get-ChildItem -LiteralPath (Join-Path $root 'src'),(Join-Path $root 'tests') -Recurse -File|Where-Object {$_.Extension -in @('.bas','.cls')}|Sort-Object FullName){
    $text=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
    $name=[regex]::Match($text,'(?m)^Attribute VB_Name = "([^"]+)"').Groups[1].Value
    if(-not $name -or $name -cne $file.BaseName -or $name.Length -gt 31 -or $names.ContainsKey($name)){throw ('Invalid or duplicated repository component: '+$file.Name)}
    $names[$name]=$true
    $body=if($file.Extension -eq '.cls'){[regex]::Match($text,'(?ms)^Option Explicit.*').Value}else{[regex]::Replace($text,'(?m)^Attribute .*(\r?\n|$)','')}
    if(-not $body){throw ('Empty repository component: '+$name)}
    $imports+=,[ordered]@{Name=$name;Path=$file.FullName.Substring($root.Length+1);SHA256=Hash $file.FullName;Type=$(if($file.Extension -eq '.cls'){2}else{1});Body=$body}
}
if($imports.Count -ne 164){throw 'The reviewed repository component count changed; review the release manifest.'}
[void][IO.Directory]::CreateDirectory($directory)
$private=Join-Path $directory 'CleanCompiled.xlsm';$report=Join-Path $directory 'CleanCompile.json'
[IO.File]::Copy($source,$private,$false)
if((Hash $private) -cne $ExpectedSourceSHA256.ToUpperInvariant()){throw 'Clean source copy differs.'}
$manifest=@($imports|ForEach-Object {[ordered]@{Name=$_.Name;Path=$_.Path;SHA256=$_.SHA256;Type=$_.Type}})
$manifest|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $directory 'RepoManifest.json') -Encoding UTF8
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class CleanReleaseExcelWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint id);}'
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0;$failure=$null
$result=[ordered]@{Status='RUNNING';SourceWorkbook=$source;SourceSHA256=$ExpectedSourceSHA256.ToUpperInvariant();PublishedSHA256=$publishedHash;PublishedDumpSHA256=$dumpHash;MacrosExecuted=$false;ProbeModulesImported=$false;RepositoryComponents=$imports.Count;Imports=$manifest;StartedUTC=(Get-Date).ToUniversalTime().ToString('o')}
try{
    Assert-Stopped
    $previous=@(Get-Process -Name EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
    $excel=New-Object -ComObject Excel.Application
    [uint32]$fresh=0;[void][CleanReleaseExcelWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$fresh)
    if(-not $fresh -or [int]$fresh -in $previous){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null;throw 'Refusing to change a pre-existing or unidentified Excel.'}
    $ownedPid=[int]$fresh;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
    Assert-Stage
    $result.PID=$ownedPid;$result.StartTicks=$ownedTicks
    Write-Output ('OWNED_EXCEL: id='+$ownedPid+'; utcStartTicks='+$ownedTicks)
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=3
    $book=$excel.Workbooks.Open($private,0,$false)
    if($book.ReadOnly){throw 'Private clean candidate must be writable.'}
    $components=@{};$documents=@{}
    foreach($component in $book.VBProject.VBComponents){
        $components[$component.Name]=$component
        if($component.Type -eq 100){$documents[$component.Name]=TextHash (CodeText $component)}
        elseif(-not $names.ContainsKey($component.Name)){throw ('Non-repository component in the clean source: '+$component.Name)}
    }
    if($documents.Count -ne 6){throw 'Expected six preserved document components.'}
    foreach($import in $imports){
        Assert-Stage
        if((Hash (Join-Path $root $import.Path)) -cne $import.SHA256){throw ('Repository source changed: '+$import.Name)}
        $component=$components[$import.Name]
        if(-not $component){$component=$book.VBProject.VBComponents.Add($import.Type);$component.Name=$import.Name;$components[$import.Name]=$component}
        if($component.Type -ne $import.Type){throw ('Component type differs: '+$import.Name)}
        if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
        $component.CodeModule.AddFromString($import.Body)
    }
    Assert-Stage
    if($book.VBProject.VBComponents.Count -ne $imports.Count+$documents.Count){throw 'Clean component inventory differs.'}
    $excel.VBE.ActiveVBProject=$book.VBProject;$compile=$excel.VBE.CommandBars.FindControl(1,578)
    if($compile.Enabled){$compile.Execute()}
    if($compile.Enabled){throw 'Clean VBA compilation did not complete.'}
    foreach($name in $documents.Keys){$component=$components[$name];if((TextHash (CodeText $component)) -cne $documents[$name]){throw ('Document source changed: '+$name)}}
    Assert-Stage
    $book.Save();$book.Close($false);$book=$null
    $result.Status='CLEAN_COMPILED';$result.CompiledWorkbook=$private;$result.CompiledSHA256=Hash $private;$result.DocumentComponents=$documents.Count;$result.Documents=$documents;$result.ExactRepositoryInventory=$true;$result.PublicationSourceEligible=$true
}catch{$failure=$_;$result.Status='COMPILE_ERROR';$result.Error=$_.Exception.Message}
finally{
    if($book -and (Test-Owned)){try{$book.Close($false)}catch{if(-not $failure){$failure=$_}}}
    if($excel){try{if(Test-Owned){$excel.Quit()}}catch{if(-not $failure){$failure=$_}}finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if(Test-Owned){Stop-Process -Id $ownedPid -Force}
    if($failure -and $result.Status -eq 'CLEAN_COMPILED'){$result.Status='CLEANUP_ERROR';$result.PublicationSourceEligible=$false}
    $result.SourceUnchanged=(Hash $source) -ceq $ExpectedSourceSHA256.ToUpperInvariant();$result.PublishedUnchanged=(Hash $published) -ceq $publishedHash -and (Hash $dump) -ceq $dumpHash
    if(-not $result.SourceUnchanged -or -not $result.PublishedUnchanged){$failure='Protected source or published output changed.';$result.Status='PROTECTION_ERROR'}
    if($failure -or $result.Status -ne 'CLEAN_COMPILED'){$result.PublicationSourceEligible=$false}
    $result.FinishedUTC=(Get-Date).ToUniversalTime().ToString('o');$result.RunnerSHA256=Hash $PSCommandPath
    $result|ConvertTo-Json -Depth 7|Set-Content -LiteralPath $report -Encoding UTF8
}
if($failure){throw $failure}
Write-Output ('CLEAN_COMPILED: components='+($imports.Count+$documents.Count)+'; sha256='+$result.CompiledSHA256)
