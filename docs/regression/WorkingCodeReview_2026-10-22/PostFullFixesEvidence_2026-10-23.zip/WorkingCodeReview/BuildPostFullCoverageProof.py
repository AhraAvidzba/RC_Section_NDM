"""Bind current post-full sources to the completed audit plus one reviewed overlay.

Writes only its new coverage proof. It does not repeat the semantic audit, execute
VBA, or modify old coverage evidence, sources, tests, workbook or native probes.
"""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = "9ff37714930f55724a9fdc23d445b4ff7f617ead"
OVERLAY_PATH = "src/Section/CSectionPropertiesCalculator.cls"
EVENTS_PATH = "tools/build_workbook/WorkbookHelpEvents.vba"
DECL = re.compile(r"^\s*(?:(?:Public|Private|Friend|Static)\s+)*(Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)\b", re.I)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest().upper()


def digest(path: Path) -> str:
    return sha(path.read_bytes())


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def lf(raw: bytes) -> bytes:
    """Only map CRLF to LF: no BOM, comment, whitespace, literal or token changes."""
    return raw.replace(b"\r\n", b"\n")


def uncomment(line: str) -> str:
    quoted = False
    index = 0
    while index < len(line):
        if line[index] == '"':
            if quoted and index + 1 < len(line) and line[index + 1] == '"':
                index += 2
                continue
            quoted = not quoted
        elif line[index] == "'" and not quoted:
            return line[:index]
        index += 1
    return line


def methods(raw: bytes) -> dict:
    lines = raw.decode("utf-8-sig").splitlines()
    result, active = {}, None
    for index, line in enumerate(lines):
        code = uncomment(line)
        match = DECL.match(code)
        if match:
            assert active is None, (active, index + 1)
            active = {"Name": match[2], "Kind": re.sub(r"\s+", " ", match[1]), "Line": index + 1}
        if active is not None and (re.match(r"^\s*End\s+(Sub|Function|Property)\b", code, re.I)
                                   or re.search(r":\s*End\s+(Sub|Function|Property)\b", code, re.I)):
            active["EndLine"] = index + 1
            body = "\n".join(lines[active["Line"] - 1:index + 1])
            active["BodySHA256"] = sha(body.encode("utf-8"))
            executable = "\n".join(uncomment(item).strip() for item in body.splitlines() if uncomment(item).strip())
            active["ExecutableSHA256"] = sha(executable.encode("utf-8"))
            key = (active["Name"].casefold(), active["Kind"].casefold())
            assert key not in result
            result[key] = active
            active = None
    assert active is None
    return result


def documentation_executable(raw: bytes) -> str:
    lines = []
    for line in raw.decode("utf-8-sig").splitlines():
        code = uncomment(line).rstrip()
        if code.strip() and not re.match(r"^\s*Rem(?:\s|$)", code, re.I):
            lines.append(code)
    return "\n".join(lines)


def binding_hash(rows: dict) -> str:
    ordered = [rows[key] for key in sorted(rows)]
    return sha(json.dumps(ordered, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))


def main() -> None:
    protected = [HERE / name for name in (
        "Inventory.json", "IndependentCoverageSummary.json", "RootCoverage.json",
        "Math/MathCoverage.json", "Geometry/ReviewCoverage.json", "Excel/Coverage.json",
        "Math/PostFullMathCoverage.json", "PostFullDocumentationAudit.json",
    )]
    old_hashes = {path: digest(path) for path in protected}
    inventory_path, summary_path = HERE / "Inventory.json", HERE / "IndependentCoverageSummary.json"
    overlay_path, documentation_path = HERE / "Math/PostFullMathCoverage.json", HERE / "PostFullDocumentationAudit.json"
    inventory, summary, overlay, documentation = map(load, (inventory_path, summary_path, overlay_path, documentation_path))
    inventory_by_path = {row["Path"]: row for row in inventory}
    previous_by_path = {row["Path"]: row for row in summary["Files"]}
    sources = {path.relative_to(ROOT).as_posix(): path for path in (ROOT / "src").rglob("*")
               if path.suffix.lower() in (".bas", ".cls")}
    assert len(inventory_by_path) == len(inventory) == len(previous_by_path) == len(sources) == 117
    assert set(inventory_by_path) == set(previous_by_path) == set(sources)
    assert not summary["SubstantiveCoverageBindingIssues"]
    assert not summary["MissingActualFiles"] and not summary["AdditionalActualSrcFiles"]
    assert len(overlay["Files"]) == 1 and overlay["SupersedesFileRecordsFor"] == [OVERLAY_PATH]
    reviewed_overlay = overlay["Files"][0]
    assert reviewed_overlay["Path"] == OVERLAY_PATH and reviewed_overlay["StaticReviewComplete"]
    assert reviewed_overlay["MethodCount"] == 56 and reviewed_overlay["ChangedExistingMethodCount"] == 5
    assert reviewed_overlay["NewPrivateMethodCount"] == 2
    doc_by_path = {row["Path"]: row for row in documentation["Files"]}
    assert documentation["ModuleCount"] == len(doc_by_path) == 169
    assert documentation["MethodCount"] == 5781
    for field in ("MissingModuleHeaders", "MissingMethodHeaders", "MissingTestMarkers", "MissingTestNames", "MissingTestModuleNames", "MissingTestModuleMarkers", "MissingTestDividers"):
        assert not documentation[field], field
    tree = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", BASE, "--", "src", "tests", EVENTS_PATH], cwd=ROOT)
    paths = [path for path in tree.decode("utf-8").splitlines() if Path(path).suffix.lower() in (".bas", ".cls") or path == EVENTS_PATH]
    request = "".join(f"{BASE}:{path}\n" for path in paths).encode("utf-8")
    batch = subprocess.check_output(["git", "cat-file", "--batch"], cwd=ROOT, input=request)
    baseline, offset = {}, 0
    for path in paths:
        end = batch.index(b"\n", offset)
        header = batch[offset:end].split()
        assert len(header) == 3 and header[1] == b"blob"
        size = int(header[2])
        baseline[path] = batch[end + 1:end + 1 + size]
        offset = end + 1 + size + 1
    assert offset == len(batch)
    baseline_src = {name for name in baseline if name.startswith("src/") and Path(name).suffix.lower() in (".bas", ".cls")}
    assert baseline_src == set(sources)
    rows, current_count, previous_count = [], 0, 0
    changed_files = []
    for name, path in sorted(sources.items()):
        raw, old_raw = path.read_bytes(), baseline[name]
        current, old = methods(raw), methods(old_raw)
        current_count += len(current)
        previous_count += len(old)
        prior = previous_by_path[name]
        assert prior["CurrentMethodCount"] == len(old)
        assert prior["CurrentSHA256"] in (sha(old_raw), sha(lf(old_raw)), sha(lf(old_raw).replace(b"\n", b"\r\n"))), (name, prior["CurrentSHA256"], sha(old_raw))
        assert all(record["ReportedComplete"] and not record["CurrentMethodsMissingFromCoverage"]
                   and not record["ObsoleteMethodsInCoverage"] and not record["MethodReviewNotComplete"]
                   and not record["MethodBodyHashMismatches"] for record in prior["CoverageRecords"])
        doc = doc_by_path[name]
        assert doc["Lines"] == len(raw.decode("utf-8-sig").splitlines())
        assert doc["ExecutableSHA256"].upper() == sha(documentation_executable(raw).encode("utf-8"))
        doc_methods = {(method["Name"].casefold(), method["Kind"].casefold()): method for method in doc["Methods"]}
        assert current.keys() == doc_methods.keys()
        assert all(method["Line"] == doc_methods[key]["Line"] for key, method in current.items())
        unchanged = lf(raw) == lf(old_raw)
        row = {
            "Path": name, "PreviousOwner": prior["ExpectedOwner"], "CurrentSHA256": sha(raw),
            "CurrentLFOnlySHA256": sha(lf(raw)), "Baseline9ffGitSHA256": sha(old_raw),
            "Baseline9ffLFOnlySHA256": sha(lf(old_raw)), "LineCount": len(raw.decode("utf-8-sig").splitlines()),
            "Baseline9ffMethodCount": len(old), "CurrentMethodCount": len(current),
            "CurrentMethodBindingSHA256": binding_hash(current),
        }
        if name != OVERLAY_PATH:
            assert unchanged, name
            assert current == old, name
            row.update(Binding="UNCHANGED_FROM_COMPLETE_PREVIOUS_AUDIT_AT_9FF", LFOnlyBytesEqual=True,
                       MethodNamesKindsLinesAndBodiesUnchanged=True)
        else:
            assert not unchanged
            assert reviewed_overlay["CurrentSHA256"] == sha(raw)
            overlay_methods = {(method["Name"].casefold(), method["Kind"].casefold()): method for method in reviewed_overlay["Methods"]}
            assert current.keys() == overlay_methods.keys()
            for key, method in current.items():
                actual = overlay_methods[key]
                assert all(actual[field] == method[field] for field in ("Name", "Kind", "Line", "EndLine", "BodySHA256", "ExecutableSHA256"))
                assert actual["StaticReview"] == "READ_AND_TRACED_IN_FILE_CONTEXT"
            changed = {current[key]["Name"] for key in old.keys() & current.keys() if old[key]["ExecutableSHA256"] != current[key]["ExecutableSHA256"]}
            added = {current[key]["Name"] for key in current.keys() - old.keys()}
            assert changed == set(overlay["ChangedExistingMethods"]) and len(changed) == 5
            assert added == set(overlay["NewPrivateMethods"]) and len(added) == 2
            assert not old.keys() - current.keys()
            inherited = [key for key in old.keys() & current.keys() if current[key]["Name"] not in changed]
            assert len(inherited) == 49 and all(current[key]["BodySHA256"] == old[key]["BodySHA256"] for key in inherited)
            row.update(Binding="REPLACE_EXISTING_GEOMETRY_RECORD_BY_REVIEWED_MATH_OVERLAY", LFOnlyBytesEqual=False,
                       OverlayPath=overlay_path.relative_to(ROOT).as_posix(), OverlaySHA256=digest(overlay_path),
                       ExistingMethodsReviewedAgain=5, NewPrivateMethodsReviewed=2,
                       BodyUnchangedMethodsRetainingPreviousGeometryReview=49,
                       ChangedMethods=[overlay_methods[key] for key in current if current[key]["Name"] in changed | added])
        rows.append(row)
        if not unchanged:
            changed_files.append(name)
    assert changed_files == [OVERLAY_PATH]
    assert previous_count == summary["CurrentMethodCount"] == 3709
    assert current_count == 3711
    events_raw = (ROOT / EVENTS_PATH).read_bytes()
    assert lf(events_raw) == lf(baseline[EVENTS_PATH])
    events_methods = methods(events_raw)
    assert len(events_methods) == 5 and sha(events_raw) == summary["WorkbookHelpEvents"]["CurrentSHA256"]
    assert doc_by_path[EVENTS_PATH]["ExecutableSHA256"].upper() == sha(documentation_executable(events_raw).encode("utf-8"))
    executable_changes = []
    for path in sorted(name for name in baseline if name.startswith(("src/", "tests/")) and Path(name).suffix.lower() in (".bas", ".cls")):
        current_raw = (ROOT / path).read_bytes()
        if documentation_executable(current_raw) != documentation_executable(baseline[path]):
            executable_changes.append(path)
    assert executable_changes == documentation["ChangedExecutableFiles"]
    assert len(executable_changes) == 4 and sum(path.startswith("src/") for path in executable_changes) == 1
    assert all(digest(path) == old_hashes[path] for path in protected)
    result = {
        "Status": "POST_FULL_COVERAGE_BINDING_COMPLETE_NATIVE_ACCEPTANCE_SEPARATE",
        "AllPassed": True, "CurrentSrcFileCount": 117, "CurrentMethodCount": current_count,
        "NoOverallAcceptanceClaimed": True,
        "AsOfUTC": datetime.now(timezone.utc).isoformat(), "BaselineAuditedCommit": BASE,
        "Meaning": "Это обновление привязки прежнего полного смыслового аудита к текущим исходникам после отдельной ревизии5 изменённых методов и2 новых helpers. Повторный смысловой аудит всех117 файлов не заявляется. Общий PASS native/full приёмки этим документом не устанавливается.",
        "Inventory": {"InputFileCount": 117, "CurrentSrcFileCount": 117, "Git9ffSrcFileCount": 117,
                      "ExactSamePathSet": True, "Missing": [], "Extra": []},
        "MethodCounts": {"PreviousAudited9ff": previous_count, "CurrentSrc": current_count,
                         "AddedPrivateHelpers": 2, "ChangedExistingMethods": 5,
                         "WorkbookHelpEventsOutside117": 5, "CombinedSrcAndEvents": current_count + 5},
        "NewlineRule": "Equality of unchanged files maps only CRLF to LF at byte level; no BOM stripping, whitespace trimming, case folding, comment removal or executable-token normalization is used for that equality. Exact file SHA and LF-only SHA are both recorded.",
        "PreviousEvidence": [{"Path": path.relative_to(ROOT).as_posix(), "SHA256": old_hashes[path], "Preserved": True} for path in protected],
        "UnchangedSourceFileCount": 116,
        "Overlay": {"Path": OVERLAY_PATH, "ReplacesOwner": "Geometry", "CurrentReviewOwner": "Math",
                    "ReplacesExistingEntryNotAdditionalFile": True, "MethodCount": 56,
                    "ChangedExistingMethods": overlay["ChangedExistingMethods"], "NewPrivateMethods": overlay["NewPrivateMethods"],
                    "PreviousBodyUnchangedMethods": 49, "OverlaySHA256": digest(overlay_path)},
        "Files": rows,
        "WorkbookHelpEvents": {"Path": EVENTS_PATH, "Outside117SourceInventory": True,
                               "CurrentSHA256": sha(events_raw), "Baseline9ffSHA256": sha(baseline[EVENTS_PATH]),
                               "LFOnlyBytesEqual": True, "LineCount": len(events_raw.decode("utf-8-sig").splitlines()),
                               "MethodCount": 5, "CurrentMethodBindingSHA256": binding_hash(events_methods),
                               "Binding": "UNCHANGED_COMPLETE_EXCEL_REVIEW"},
        "DocumentationBinding": {"Path": documentation_path.relative_to(ROOT).as_posix(), "SHA256": digest(documentation_path),
                                 "All169Files": documentation["ModuleCount"], "AllMethodCount": documentation["MethodCount"],
                                 "MissingHeadersMarkersNamesOrDividers": 0, "CurrentSrcAndEventsCheckedAgainstReport": True,
                                 "ExecutableChangesSince9ff": executable_changes, "ChangedSrcFiles": 1, "ChangedTestFiles": 3},
        "PendingSeparateGates": ["Root final directed ON/OFF results", "Native final compiled/source equality and VBA-only part preservation", "Root publication and push"],
        "OldCoverageAndIndependentSummaryOverwritten": False, "SourceTestsBooksModified": False,
        "COMExecuted": False, "OverallAcceptancePassClaimed": False,
        "BuilderSHA256": digest(Path(__file__)),
    }
    target = HERE / "PostFullCoverageProof.json"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    assert all(digest(path) == old_hashes[path] for path in protected)
    print(json.dumps({"Proof": str(target), "SourceFiles": 117, "UnchangedFiles": 116,
                      "SrcMethods": current_count, "WorkbookHelpEvents": 5, "OverlayMethods": 56,
                      "Changed": 5, "Added": 2, "OldEvidencePreserved": True}, ensure_ascii=False))


if __name__ == "__main__":
    main()
