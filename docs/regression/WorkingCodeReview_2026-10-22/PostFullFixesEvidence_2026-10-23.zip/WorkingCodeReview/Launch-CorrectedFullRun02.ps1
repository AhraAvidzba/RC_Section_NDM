﻿# Запускает отдельную полную проверку исправленного и уже отправленного выпуска; старый Run01 не меняется.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$old=Get-Content -LiteralPath (Join-Path $root 'docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01/Run.json') -Raw -Encoding UTF8|ConvertFrom-Json
$oldProcess=Get-Process -Id 201048 -ErrorAction SilentlyContinue
if(-not $old.FinishedUTC -or $old.Status -eq 'RUNNING' -or ($oldProcess -and $oldProcess.StartTime.ToUniversalTime().Ticks -eq 639283000561781001)){throw 'The preceding full run has not stopped.'}
$publication=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PostFullRelease01/Publication.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($publication.Status -ne 'CODE_ONLY_PUBLISHED' -or $publication.FullAcceptanceClaimed){throw 'Verified corrected publication is required.'}
$book=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$dump=Join-Path $root 'workbook/output/VBA_All_Code.txt'
if((Get-FileHash -LiteralPath $book).Hash -cne $publication.WorkbookSHA256 -or (Get-FileHash -LiteralPath $dump).Hash -cne $publication.DumpSHA256){throw 'Published bytes changed.'}
$commit=(& git rev-parse HEAD).Trim();if($LASTEXITCODE -ne 0){throw 'Cannot identify source commit.'}
$upstream=(& git rev-parse '@{upstream}').Trim();if($LASTEXITCODE -ne 0 -or $upstream -cne $commit){throw 'Commit must be successfully pushed before launch.'}
& git diff --quiet HEAD -- src tests tools/build_workbook workbook/output/RC_Section_NDM.xlsm workbook/output/VBA_All_Code.txt
if($LASTEXITCODE -ne 0){throw 'Participating source, tools or workbook are not committed.'}
$deadline='2026-10-23T10:00:00+03:00';$forecast=5
if([DateTimeOffset]::UtcNow.AddHours($forecast).AddMinutes(15) -ge [DateTimeOffset]::Parse($deadline)){throw 'Full forecast does not fit the agreed deadline.'}
$evidence='docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run02'
$record=Join-Path $PSScriptRoot 'FullLaunchRun02.json';$stdout=Join-Path $PSScriptRoot 'FullLaunchRun02.stdout.log';$stderr=Join-Path $PSScriptRoot 'FullLaunchRun02.stderr.log'
foreach($path in @((Join-Path $root $evidence),$record,$stdout,$stderr)){if(Test-Path -LiteralPath $path){throw 'Launch artifacts must be fresh.'}}
$previous=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'FullLaunch.json') -Raw -Encoding UTF8|ConvertFrom-Json
$scripts=@($previous.ParticipatingScripts|ForEach-Object {[ordered]@{Path=$_.Path;SHA256=(Get-FileHash -LiteralPath (Join-Path $root $_.Path)).Hash}})
$components=@(Get-ChildItem -LiteralPath (Join-Path $root 'src'),(Join-Path $root 'tests') -Recurse -File|Where-Object {$_.Extension -in @('.bas','.cls')}|Sort-Object FullName|ForEach-Object {[ordered]@{Component=$_.BaseName;Path=$_.FullName.Substring($root.Length+1);SHA256=(Get-FileHash -LiteralPath $_.FullName).Hash}})
if($scripts.Count -ne 19 -or $components.Count -ne 164){throw 'Participating manifest count changed; review it before launch.'}
$python=Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$argsList=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-FullOnOffAcceptance.ps1','-SourceWorkbook','workbook/output/RC_Section_NDM.xlsm','-EvidenceDirectory',$evidence,'-Deadline',$deadline,'-ForecastHours',[string]$forecast,'-Python',('"'+$python+'"'))
$started=[DateTimeOffset]::Now
$process=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $argsList -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
$ticks=$process.StartTime.ToUniversalTime().Ticks
[ordered]@{Started=$started.ToString('o');PID=$process.Id;ProcessStartTicks=$ticks;EvidenceDirectory=$evidence;SourceSHA256=$publication.WorkbookSHA256;AllCodeSHA256=$publication.DumpSHA256;SourceCommit=$commit;Deadline=$deadline;ForecastHours=$forecast;Python=$python;Stdout=$stdout;Stderr=$stderr;Authorization='User explicitly requested full runs after fixes and push in the same active goal, and correction of discrepancies';ExpectedCoreSuites=156;ExpectedFocused='122 single cases, batch15 in both modes, stability, asymmetric steel, real AutoCAD, independent NDS';PrecedingRun='docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01';PrecedingRunPreserved=$true;PublicationProofSHA256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'PostFullRelease01/Publication.json')).Hash;ParticipatingScripts=$scripts;SourceComponents=$components}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $record -Encoding UTF8
Write-Output ('FULL_RUN02_STARTED: pid='+$process.Id+'; startTicks='+$ticks+'; commit='+$commit+'; sourceSHA256='+$publication.WorkbookSHA256)
