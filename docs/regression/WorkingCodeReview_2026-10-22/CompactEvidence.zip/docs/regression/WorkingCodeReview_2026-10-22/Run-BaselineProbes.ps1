# ДЛЯ ТЕСТОВ: исследует найденные края на неизменённом рабочем VBA в приватной копии.
# По умолчанию импортируются только тестовые модули. Явный CandidateModulePath
# заменяет рабочие модули только в несохраняемой приватной копии, с фиксацией хешей.
param([string[]]$ModulePath=@(),[string[]]$Macro=@(),[string]$Label='Baseline',[string[]]$CandidateModulePath=@(),[switch]$SavePrivateCandidate,[ValidateSet('','Yes','No')][string]$Mode='',[string]$FrozenSource='')
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$source=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$baseline=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Baseline.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if($FrozenSource){
    $source=(Resolve-Path -LiteralPath (Join-Path $root $FrozenSource)).Path
    $frozenProof=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'FinalDirected14_Probes.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if($source -cne $frozenProof.SavedPrivateCandidate -or $frozenProof.Status -ne 'PROBES_COMPLETED' -or $ModulePath.Count -or $CandidateModulePath.Count){throw 'Frozen run must use exactly the completed final14 artifact, without imports.'}
}
$hash=(Get-FileHash -LiteralPath $source).Hash
if($FrozenSource){if($hash -cne $frozenProof.SavedPrivateSHA256){throw 'Frozen workbook changed.'}}
elseif($hash -cne $baseline.WorkbookSHA256){throw 'Published source differs from the frozen review baseline.'}
if((-not $ModulePath.Count -and -not $FrozenSource) -or -not $Macro.Count){throw 'Test modules and entrypoints are required for isolated probes.'}
$imports=@()
foreach($relativeFile in @($CandidateModulePath)+@($ModulePath | Select-Object -Unique)){
    $file=(Resolve-Path -LiteralPath (Join-Path $root $relativeFile)).Path
    $text=[IO.File]::ReadAllText($file,[Text.Encoding]::UTF8)
    $name=[regex]::Match($text,'(?m)^Attribute VB_Name = "([^"]+)"').Groups[1].Value
    if(-not $name -or $name.Length -gt 31){throw ('Invalid VBA component name (maximum 31 characters): '+$name)}
    $isCandidate=$relativeFile -in $CandidateModulePath
    if(-not $isCandidate -and -not $name.Contains('Test')){throw 'Probe module must have an explicit Test name.'}
    if($isCandidate -and -not $file.StartsWith((Join-Path $root 'src')+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Candidate import must be a working source file inside src.'}
    $body=if($text -match '(?m)^VERSION 1.0 CLASS'){[regex]::Match($text,'(?ms)^Option Explicit.*').Value}else{[regex]::Replace($text,'(?m)^Attribute .*(\r?\n|$)','')}
    $imports+=,[ordered]@{Name=$name;Path=$relativeFile;SHA256=(Get-FileHash -LiteralPath $file).Hash;Body=$body;Type=$(if($file.EndsWith('.cls')){2}else{1});Candidate=$isCandidate}
}
$private=Join-Path $PSScriptRoot ($Label+'_Probes.xlsm')
Copy-Item -LiteralPath $source -Destination $private
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class WorkingReviewExcelWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint id);}'
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0
$result=[ordered]@{Status='RUNNING';SourceSHA256=$hash;ProductionCodeChanged=$false;PrivateCandidateImported=($CandidateModulePath.Count -gt 0);OnlyTestModulesImported=($CandidateModulePath.Count -eq 0);Imports=@($imports | ForEach-Object {[ordered]@{Name=$_.Name;Path=$_.Path;SHA256=$_.SHA256;Candidate=$_.Candidate}});Probes=@()}
$result.StartedUTC=(Get-Date).ToUniversalTime().ToString('o')
$result.RunnerSHA256=(Get-FileHash -LiteralPath $PSCommandPath).Hash
if($FrozenSource){$result.FrozenSource=$FrozenSource;$result.FrozenSourceProof='FinalDirected14_Probes.json';$result.NoCodeImported=$true;$result.OnlyTestModulesImported=$false}
$report=Join-Path $PSScriptRoot ($Label+'_Probes.json')
try{
    $existingExcelIds=@(Get-Process -Name EXCEL -ErrorAction SilentlyContinue | ForEach-Object Id)
    $excel=New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][WorkingReviewExcelWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    if([int]$id -in $existingExcelIds){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null;throw 'Excel reused a pre-existing user process; no settings or workbooks were changed.'}
    $ownedPid=[int]$id;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=1
    $result.OwnPID=$ownedPid;$result.OwnStartTicks=$ownedTicks
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $report -Encoding UTF8
    Write-Output "OWNED_EXCEL: id=$ownedPid; utcStartTicks=$ownedTicks"
    $book=$excel.Workbooks.Open($private,0,$false)
    if($book.ReadOnly){throw 'Private probe workbook must be writable in memory.'}
    $components=@{}
    foreach($present in $book.VBProject.VBComponents){$components[$present.Name]=$present}
    foreach($import in $imports){
        $component=$components[$import.Name]
        if(-not $component){$component=$book.VBProject.VBComponents.Add($import.Type);$component.Name=$import.Name;$components[$import.Name]=$component}
        if($component.Type -ne $import.Type){throw ('Component type mismatch: '+$import.Name)}
        if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
        $component.CodeModule.AddFromString($import.Body)
    }
    $excel.VBE.ActiveVBProject=$book.VBProject
    $compile=$excel.VBE.CommandBars.FindControl(1,578)
    if($compile.Enabled){$compile.Execute()}
    if($compile.Enabled){
        $pane=$excel.VBE.ActiveCodePane
        [int]$firstLine=0;[int]$firstColumn=0;[int]$lastLine=0;[int]$lastColumn=0
        $pane.GetSelection([ref]$firstLine,[ref]$firstColumn,[ref]$lastLine,[ref]$lastColumn)
        $location='module='+$pane.CodeModule.Parent.Name+'; line='+$firstLine+'; column='+$firstColumn
        $result.CompileLocation=$location
        Write-Output ('COMPILE_LOCATION: '+$location)
        Write-Output $pane.CodeModule.Lines([Math]::Max(1,$firstLine-2),5)
        throw 'Probe module compilation failed.'
    }
    if($SavePrivateCandidate){
        # Сохраняем только компилированный кандидат ДО макросов/fixtures.
        # Дальнейшее тестирование закрывает эту копию без Save.
        $book.Save()
        $result.SavedPrivateCandidate=$private
    }
    if($Mode){
        $modeRange=$book.Names.Item('rngSystemSettings').RefersToRange
        $modeData=$modeRange.Value2;$modeRow=0
        for($r=2;$r -le $modeRange.Rows.Count;$r++){
            if([string]$modeData[$r,1] -ceq 'General.DiagramExtension'){
                if($modeRow){throw 'Duplicated test mode setting.'};$modeRow=$r
            }
        }
        if(-not $modeRow){throw 'Missing test mode setting.'}
        $modeRange.Cells.Item($modeRow,2).Value2=$Mode
        $result.DiagramExtension=$Mode
    }
    foreach($entry in $Macro){
        Write-Output ('PROBE_STARTED: '+$entry)
        $probeWatch=[Diagnostics.Stopwatch]::StartNew()
        $actual=[string]$excel.Run("'"+$book.Name.Replace("'","''")+"'!"+$entry)
        $probeWatch.Stop()
        $result.Probes+=,[ordered]@{Macro=$entry;Actual=$actual;Seconds=$probeWatch.Elapsed.TotalSeconds}
        $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $report -Encoding UTF8
        # Полные assertions сохраняются в JSON; в журнал идут итоги и ошибки,
        # чтобы тысячами строк не скрывать новые существенные события.
        $actual -split '\r?\n' | Where-Object {$_ -match '^(TOTAL|FAIL:|CASE\||SHIFT\||REPRO_|ANNOTATION_BENCH|LAYOUT_BENCH|RAW_AREA|RELATIVE_PERCENT|Platform=)'} | Write-Output
    }
    $book.Close($false);$book=$null
    if($SavePrivateCandidate){$result.SavedPrivateSHA256=(Get-FileHash -LiteralPath $private).Hash}
    if((Get-FileHash -LiteralPath $source).Hash -cne $hash){throw 'Published workbook changed during isolated probes.'}
    $result.Status='PROBES_COMPLETED';$result.SourceUnchanged=$true
    $result.CompletedUTC=(Get-Date).ToUniversalTime().ToString('o')
}catch{
    $result.Status='PROBE_ERROR';$result.Error=$_.Exception.Message
    throw
}finally{
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $report -Encoding UTF8
    if($book){$book.Close($false)}
    if($excel){$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if($ownedPid){
        $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
        if($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks){Stop-Process -Id $ownedPid -Force}
    }
}
