# ДЛЯ ТЕСТОВ: адресная приёмка финальных изменений, не полный ON/OFF-набор.
param([ValidateSet('Yes','No')][string]$Mode='No',[string]$Label='FinalDirected07',[switch]$SavePrivateCandidate,[string]$FrozenSource='')
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$production=@(& git diff --name-only -- src | Where-Object {$_ -match '\.(bas|cls)$'})
$tests=@(& git diff --name-only -- tests | Where-Object {$_ -match '\.(bas|cls)$'})+@('tests/CTestWorkflowWorkbook.cls')
if($FrozenSource){$production=@();$tests=@()}
$macros=@(
 'modTestGeometry.RunGeometryTests',
 'modTestCrackWidth.RunCrackTranslationTests',
 'modTestMaterialDiagrams.RunMaterialPointOrderTests',
 'modTestCapacitySolver.RunLimitRequestLifecycleTests',
 'modTestSectionSolver.RunSectionSolverTests',
 'modTestCrackWidth.RunCrackGeometryTests',
 'modTestSP35CrackWidth.RunSP35FormulaTests',
 'modTestSP35CrackWidth.RunSP35PipelineTests',
 'modTestBatchCalculation.RunAudit03LifecycleTests',
 'modTestProfileConfig.RunStabilityDurationMatchingTests',
 'modTestSectionRecipes.RunWorkbookRecipeInputTests',
 'modTestLoadTableConfig.RunAudit03LoadTableTests',
 'modTestLoadTableConfig.RunTestMultiAreaLoadValidation',
 'modTestWorkbookInterface.RunAudit03GeometrySnapshotTests',
 'modTestPlotConfig.RunArbitraryAnnotationLayoutTests',
 'modTestPlotConfig.RunAudit03NamedAnnotationTests',
 'modTestWorkbookInterface.RunTestCalculationFreshnessWorkflow',
 'modTestWorkbookInterface.RunAudit03ExcelGuardTests',
 'modTestWorkbookInterface.RunExcelGuardWorkflowTests',
 'modTestWorkbookInterface.RunSectionWorkflowUiTests',
 'modTestWorkbookInterface.RunSectionWorkflowCalculationTests'
)
& (Join-Path $PSScriptRoot 'Run-BaselineProbes.ps1') -CandidateModulePath $production -ModulePath $tests -Macro $macros -Label $Label -Mode $Mode -SavePrivateCandidate:$SavePrivateCandidate -FrozenSource $FrozenSource
