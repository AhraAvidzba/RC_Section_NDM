"""Упаковывает компактные доказательства; приватные книги и PDF не включаются."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import subprocess
import sys

here = Path(__file__).resolve().parent
root = here.parents[2]
extras = set(here.glob('*.py')) | set(here.glob('*.ps1'))
names = ['FinalDirectedAcceptance.json','Publication.json','ReleasePreservation.json','ReleaseSourceEquality.json',
         'ReleaseLiteralSourceEquality.json','ReleaseVBA.txt.ReadOnly.json','IndependentReleaseVerifierReview.json',
         'VbeNumericCanonicalization.json','CompiledCandidate05_Artifact.json',
         'Geometry/FinalGeometryNativeResults.json','Geometry/CornerTangentFix.json',
         'Excel/ScopeSummary.json','Excel/MultiAreaValidationAcceptance.json','Excel/FullLaunchSafety.json',
         'Excel/SavedCalculationHistory.json','Excel/SavedCalculationMode.json',
         'FocusedPreflight18/Probe/Preparation.json','FocusedPreflight18/Probe/InputManifest.json','ModeRunnerSafety17.txt']
extras |= {here/n for n in names if (here/n).exists()}
extras |= set((here/'NativeCADFinal16').glob('*'))
extras |= set((here/'FocusedProbeBindings').glob('*'))
extras |= {here/'Math/FocusedToolsReadOnlyPreflight.json'}
extras |= set((here/'FocusedPreflight18/Probe').glob('*_Manifest.txt'))
extras |= {root/'docs/reports/WorkingCodeReview_2026-10-22.md', root/'docs/reports/WorkingCodeReview_2026-10-22_TestPlan.md'}
args = [sys.executable, str(here/'BuildCompactEvidenceFileList.py'), '--final']
for p in sorted(extras):
    if p.is_file():
        args += ['--additional-file', p.relative_to(root).as_posix()]
subprocess.run(args, cwd=root, check=True)
manifest = json.loads((here/'CompactArchiveFiles.json').read_text('utf-8-sig'))
archive = here/'CompactEvidence.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=9) as z:
    for record in manifest['Files']:
        p = root/record['Path']
        assert hashlib.sha256(p.read_bytes()).hexdigest().upper() == record['SHA256']
        z.write(p, record['Path'])
    z.write(here/'CompactArchiveFiles.json', (here/'CompactArchiveFiles.json').relative_to(root).as_posix())
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(Path(n).suffix.lower() in ('.xlsm','.xlsx','.xlsb','.pdf') for n in z.namelist())
summary = {'Files': len(manifest['Files'])+1, 'Bytes': archive.stat().st_size,
           'SHA256': hashlib.sha256(archive.read_bytes()).hexdigest().upper(),
           'BooksIncluded': False, 'Status': 'COMPACT_EVIDENCE_READY'}
(here/'CompactEvidence.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
