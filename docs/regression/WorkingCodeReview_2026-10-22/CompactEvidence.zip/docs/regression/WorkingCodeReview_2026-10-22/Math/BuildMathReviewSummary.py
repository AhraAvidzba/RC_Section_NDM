"""Компактные факты ревизии и уже выполненного root native-проверочного запуска."""
from pathlib import Path
import hashlib, json, re

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
REVIEW=OUT.parent
BASE='1c037a463bcdbd794601e47d1d77300fdc53cc60'

def write(name,data):
    (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

norms=[]
for name in ('SP_63','SP_35'):
    data=json.loads((OUT/'NormText'/f'{name}.json').read_text(encoding='utf-8'))
    source=ROOT/data['Source']
    norms.append({'Source':data['Source'],'PDFSHA256':data['SHA256'],'CurrentPDFSHA256':hashlib.sha256(source.read_bytes()).hexdigest().upper(),'ReadOnly':True})

rows=[
 {'SourceClause':'СП63 6.1.19–6.1.25, 6.2: диаграммы материалов; PDF с.27–29,34',
  'AgreedDecision':'ONQ001/002 закрыты пользователем: TwoLine/ThreeLine по Config и расчетному профилю; финальная независимая нормативная сверка остается за пользователем. ONQ007: alpha=.001 по умолчанию является согласованным изменением sigma(epsilon), alpha0 дает горизонтальное плато.',
  'Implementation':'CMaterialModelProvider выбирает активные характеристики I/II и ветви; CMaterialDiagram отделяет физические пределы от численного extension. Новый одобренный guard проверяет порядок именно активных epsilon до сортировки/PlateauSlope; исходные формулы и alpha не меняет.',
  'Conclusion':'Расхождения с согласованной постановкой не найдены. Нельзя считать закрытие ONQ001/002 нормативной верификацией всех формул; эти вопросы не открываются повторно в этой ревизии.'},
 {'SourceClause':'СП63 8.2.13–8.2.14, формулы8.53–8.54; PDF с.76–77',
  'AgreedDecision':'ONQ004: N+Mx+My и поиск lambda_crc для произвольной геометрии — принятая инженерная постановка. NotCracked не равен numerical failure; другой физический предел обрабатывается отдельно.',
  'Implementation':'CCrackFormationCalculator разделяет Ncrc=Ared*Rbt при центральном растяжении и подходящую одноименную крайнюю арматуру для изгиба; Pre/Post состояния независимо подтверждаются. Техническое ограничение поиска не выдается за отсутствие трещины.',
  'Conclusion':'Новая ошибка нормативной формулы не обнаружена. Cache/стартер не обходят конечную проверку N/Mx/My и физических пределов.'},
 {'SourceClause':'СП63 8.2.15–8.2.17: ширина, расстояние между трещинами, psi_s; PDF с.76,79',
  'AgreedDecision':'ONQ004: взаимодействие произвольной области и эквивалентный диаметр — инженерное обобщение. При недоступном уточнении разрешен psi_s1 с предупреждением только при использовании; пользовательское psi_s не менять.',
  'Implementation':'CCrackWidthCalculator использует phi1*phi2*phi3*psi_s*sigma_s/Es*ls; ls=.5*Abt/As*d с нижней границей max(10d,100мм) и верхней min(40d,400мм). AutoPsi=1-.8*sigma_crc/sigma. MATH002 исправляет только near-uniform branch, не формулы.',
  'Conclusion':'Сверенные формулы и конверсия совпадают с читаемым PDF. Сложные геометрические обобщения остаются принятым контрактом, не объявляются буквальным требованием СП.'},
 {'SourceClause':'СП35 7.105, 7.109–7.110; PDF с.121,123',
  'AgreedDecision':'ONQ004 и согласованные правила СП35: группы неделимы, ряды от границы к НЛ, beta четвертого и следующих рядов=.75, неполный крайний ряд сравнивается со всеми иными рядами; соседние стороны отдельно t/L. Это принятые решения, не новые ошибки.',
  'Implementation':'Rr=Ar/sum(beta*n*d), реальные диаметры в знаменателе; Periodic psi=1.5*sqrt(Rr[см]), Smooth=.35*Rr[см], width=sigma_s/Es*psi[см]*10 в мм. В СП35 нет psi_s. RowTolerance отделяет ряды и не меняет боковую границу.',
  'Conclusion':'Сверены размерности и коэффициенты по PDF. MATH002 устраняет WCS-зависимость central/Prepare по одному критерию; геометрию групп и формулы не меняет.'},
 {'SourceClause':'СП63 8.1.15, формулы8.1–8.6; PDF с.43–44',
  'AgreedDecision':'ONQ005: устойчивость произвольного сечения, выбранные главные плоскости и способы phi_l сохраняются; окончательная независимая сверка не входит в закрытие вопроса.',
  'Implementation':'CStabilityCalculator: eta=1/(1-N/Ncr), Ncr=pi²*D/l0²; kb=.15/[phi_l*(.3+delta_e)], D=kb*Eb*Ib+ks*Es*Is; ks и границы delta доступны в настройках. Знаки длительных моментов и reference по арматуре прочитаны; стройность<=14 отдельная ветка.',
  'Conclusion':'Нормативная арифметика в этой зоне не менялась. Дефект радиуса ядра и central inertia находится в Section и сопровождается отдельной проверкой geometry-агента.'},
 {'SourceClause':'СП35 7.52–7.55, таблицы7.9–7.11, формулы7.7–7.15; PDF с.90–92,100',
  'AgreedDecision':'ONQ005 сохраняет обобщение на произвольные контуры, принятые Auto/floor/cap phi_l и параметризованные таблицы. Не заменять согласованные решения новыми трактовками по памяти.',
  'Implementation':'CStabilityCalculator: ветви ec/r, случайный эксцентриситет, длительное сочетание; Ncr=6.4Eb/l0²*[Ib/phi_l*(.11/(.1+delta/phi_p)+.1)+n1Is]; delta_min=.5-.01*l0/h-.01*Rb; знакопеременные моменты phi_l1/1.05. Табличная ветка: вычитание площади стали при превышении3%, положительные строгие узлы, bilinear interpolation/clamp.',
  'Conclusion':'Сверенные формулы/размерности и контрольные границы соответствуют используемому локальному PDF с учетом принятых ONQ005 решений. Нельзя этим отчетом закрывать будущую независимую нормативную проверку.'},
 {'SourceClause':'docs/CoordinateSystem.md и AGENTS.md; физическая плоскость epsilon=epsilon0+kX*y+kY*x',
  'AgreedDecision':'Единая задача N+Mx+My; внутри мм/Н/Нмм/МПа, растяжениеN положительно. Жесткий перенос координат не меняет физический ответ.',
  'Implementation':'CSectionNumericalFrame центрирует solver, LoadPath масштабирует N вместе с моментом его эксцентриситета. Подтвержденное нарушение было только в выборе near-uniform crack fallback по WCS epsilon0; заменено actual center strain по кэшированному центру бетона.',
  'Conclusion':'MATH002 подтвержден исходным native repro и исправлен после одобрения. Boundary center0/±1e-11 с тем же порогом1e-12 не превращается в ошибку Prepare.'},
]
write('NormReview.json',{'Baseline':BASE,'Sources':norms,'AgreedSources':['docs/OpenNormativeQuestions.md ONQ001–007','docs/CoordinateSystem.md','docs/reports/performance/PlateauSlope_2026-10-11.md','docs/reports/cracks/NDM_SP35_Implementation_Final_Report_2026-10-06.md','docs/NormativeTraceability.md'],'Review':rows,'NewNormativeQuestions':[],'FullIndependentNormativeVerificationClaimed':False,'Meaning':'Статическая сверка фактической реализации с прочитанными пунктами и ранее принятыми решениями; не замена независимому инженерному контролю.'})

write('Findings.json',{'Baseline':BASE,'Findings':[
 {'ID':'MATH-001','Status':'RejectedFalsePositive_RegressionAdded','Location':'CLinearSystem3x3.Solve','Hypothesis':'NaN мог пройти отрицательное-only сравнение residual.','NativeEvidence':'Initial_Probes.json','Observed':'Все6 NaN/±Inf в матрице/RHS: Solved=False, FailureCode1, конечные очищенные X/residual; после каждого recovery solved/correctVector=True.','Resolution':'Рабочий алгоритм не менялся. Добавлены30 регрессионных assertions для воспроизводимого поведения native VBA.'},
 {'ID':'MATH-002','Status':'UserApprovedFixed_DirectedNativePassed','Location':['CCrackWidthCalculator.CalculateGeneralBending','CCrackWidthCalculator.CalculateSP35','CSP35CrackData.Prepare'],'Repro':'Центр деформации1e-4, kappaY5e-13/мм, сечение300×200: WCS0 иX1e9 имеют одинаковые физические strains/equilibrium, но epsilon0 становится-.0004. Исходный СП63: width.0336→0/NotApplicable; СП35:.0129903869024→0.','BaselineNativeEvidence':['CrackTranslation_Probes.json','SP35AndInertiaBaseline_Run03_Probes.json'],'Approval':'Да, исправить и проверить переносы координат','Fix':'Одинаковая деформация в центре бетонной сетки вместо WCS epsilon0 для near-uniform ветки и SP35 guard. Кэшированный centroid, без нового обхода элементов. Коэффициенты/порог1e-12/формулы не менялись.','Tests':'RunCrackTranslationTests432/0: center±1e-4/0/±1e-11, k5e-13, обе оси и WCS0/±1e9, обе методики, analytic width и boundary status/code/branch invariance.','Boundary':'Результат согласован с прежним размещением центра в начале координат. Новая трактовка пересекающей ноль almost-uniform плоскости не вводилась.'},
 {'ID':'MATH-003','Status':'UserApprovedFixed_DirectedNativePassed','Location':'CMaterialModelProvider: четыре построителя TwoLine/ThreeLine','Repro':'Исходный native принимал ultimate concrete.001 и получал physical -.0015/-.002, steel.001 получал±.00175: универсальная сортировка скрывала противоречивый порядок именованных узлов.','BaselineNativeEvidence':'MaterialAndAnnotationBaseline_Probes.json','Approval':'Да, проверять и отклонять противоречивые значения','Fix':'Проверить eps(i)>eps(i-1) активных узлов до DiagramFromArrays/PlateauSlope. При равенстве универсальная диаграмма уже не допускает совпадения; понятная причина и оба ключа с фактическими адресами. Immutable string-address snapshot, без mutable reader/COM.','Tests':'RunMaterialPointOrderTests640/0:10 соседних пар, I/II, below/equal/above, alpha0/.001 и extensionon/off. Дополнительно полный MaterialDiagram31097/0.','Boundary':'Не добавлены нормативные пределы на ввод, alpha или отключенные растянутые ветви; формулы/сопротивления/физические пределы исправных входов не менялись.'},
 {'ID':'MATH-004','Status':'RoutineLifecycleFixed_DirectedNativePassed','Location':'CSectionSolver.ClearResult','Repro':'После ошибки пустого Solver.Method и последующего успешного решения сохранялся прежний FailureSettingKeys, хотя FailureCode ужеNone.','Fix':'Очищать FailureSettingKeys вместе с остальным результатом.','Tests':'4 новых assertions: исходный ключ, recovery converged, codeNone и empty key; RunSectionSolverTests3340/0.','NumericalChange':False},
 {'ID':'MATH-005','Status':'LowLevelLifecycleFixed_DirectedNativePassed','Location':'CLimitSearchRequest.InitializeCrackFormation','Repro':'Переиспользование Capacity→Crack оставляло capacity offsets/base и ForceOnly/PureAxialForMethod; low-level явный Ultimate path может читать ForceOnly до SelectLoadPath. Обычная книга строит New request, сбой ее штатного пути не заявлен.','Fix':'Сбросить только поля прежней capacity-задачи при полной инициализации crack request; новый request и переиспользованный должны быть идентичны.','Tests':'RunLimitRequestLifecycleTests66/0:3 предшествующих осевых режима×22 точных сравнения полей и object identity.','Boundary':'Нет изменения норм/уравнений/новых ограничений; штатный fresh-object путь получает те же значения.'},
 ],'NonDefectObservations':[{'Location':'CStateSolutionRunner retry cache','Observation':'Низкоуровневый Object API теоретически допускает чужой mutable материал при той же ссылке. Штатный provider передает frozen диаграммы; воспроизводимого сбоя книги нет.','Action':'Рабочий cache не менялся; не объявлено подтвержденной ошибкой.'},{'Location':'CSP35CrackData.BuildGroups','Observation':'Попарная проверка соседства O(n²) читает только массивы и нужна для транзитивных connected components. Без профиля реального bottle-neck не вводилась сложная пространственная архитектура.','Action':'Сохраняется простота и инженерная воспроизводимость; новый crack guard не добавляет циклы.'}],'CrossScopeFindings':'Радиус ядра, central inertia и экстремальные координаты находятся в отчете Geometry. Не дублировать их как независимые ошибки Math.'})

edge=[
 ('IEEE arithmetic','NaN/+Inf/-Inf в coeff/RHS каждого из двух мест','Отказ численного решателя; finite очищенный vector; после каждого исправный recovery','RunAudit03ExtremeLinearSystemTests','Native baseline и candidate подтверждены; CLinearSystem unchanged'),
 ('Coordinate invariance crack','center±1e-4; tiny k5e-13; WCS0/±1e9 поX/Y; СП63/СП35','Одинаковые strains/physical/width/status/code; analytic tension widths, compressionNotCracked','RunCrackTranslationTests','432/0 вместе с boundary cases'),
 ('Near-zero boundary','center0/±1e-11, плоскость пересекает0; те же координаты/методики','Нет InvalidInput/InternalError; одинаковый критерий центра и Prepare, результат как при центре в0','RunCrackTranslationTests','Направленный native подтвердил432/0'),
 ('Material active nodes','10пар×I/II×below/equal/above×alpha0/.001×extensionon/off','below/equal отвергаются с причиной и обоими активными ключами; above физические limitsточно','RunMaterialPointOrderTests','640/0; independent fixture preflight0unexpected'),
 ('Material plateau','alpha0/.001, физическое плато и численный extension, tensionIgnore/UseDiagram','Принятый ONQ007; extensionне расширяет физическую допустимость; cache immutable/full spec','RunMaterialDiagramTests','31097/0; не полная нормативная приемка'),
 ('Solver lifecycle','invalidSolverMethod→Newton на том же solver','Code/key от прежней ошибки очищаются; повтор сходится','RunSectionSolverTests','3340/0,4 новых lifecycle assertions'),
 ('Request lifecycle','Capacity→Crack,3 предыдущих ForceOnly/PureAxial режима','22поля/ссылки равны свежему объекту; от capacityне остается путевых данных','RunLimitRequestLifecycleTests','66/0'),
 ('N+Mx+My paths','0/small/largeN/M, mixedsign, Auto и явныеM/N/NMxy, eccentricN','Все3компоненты, момент эксцентриситета масштабируется сN; явный путь не меняется; lambda<1stop','RunCapacitySolverTests; существующие LoadPath/coordinator группы','Полностью статически прочитано; широкие направленные прогоны централизует root'),
 ('Plateau/singular/nonconvergence','alpha0 plateau, rank deficient, finite-difference degeneracy, step retries','Численный отказ не становится физическим пределом или NotCracked; финальные усилия проверяются независимо','RunSectionSolverTests; RunCapacitySolverTests','Solver3340/0; прочие широкие группы по плану root'),
 ('Crack dependency','Formation unavailable/NotCracked, userPsi/Auto/AlwaysCalc, longitudinal compression','Fallbackpsi1 только при использовании, пользовательское не менять; longitudinal независимо','RunCrackWidthTests; RunCrackGeometryTests','Полный статический обзор; дальнейший directed runtime root'),
 ('SP35 grouping','connected A-B-C, разныеd, ряд ровно/рядtolerance, center на boundary, left/rightt/L equality','Неделимость по центру; реальные beta*n*d; RowToleranceне расширяет область; side boundaries независимы','Действующие SP35 группы и RunCrackGeometryTests','Контракт прочитан; принятые инженерные правила не пересматривались'),
 ('Stability','l0/h boundary14, ec/r1, N/Ncr.7, steelarea3%, signed sustained moments, tableboundary','Верная ветка, фактическая методика/источник, равновесие и strength независимы; no division byzero','Действующие Stability/SP35 группы','Полная статическая и точечная PDF сверка; root централизует runtime'),
 ('Cache integrity','same exact inputs vs changed section/material revision/options/strainplane','Никакого округленного key; newrevision invalidates; cloned/frozen results не изменяются','RunAudit02RepositoryContextTests и существующие cache-группы','Repository context48/0; весь cache код просмотрен'),
 ('Result ownership','reuse/clear/freeze, missingpoint vs analyticpoint, failed/current/pre/post','Без stale чисел/адресов и ложного finished; meta/region snapshots независимы','Существующие capacity/crack/stability result-группы','Полностью статически просмотрено; root directed runtime'),
 ]
write('EdgeCasePlan.json',{'Baseline':BASE,'Cases':[dict(zip(('Area','Inputs','ExpectedInvariant','NativeEntrypointOrGroup','EvidenceStatus'),r)) for r in edge],'LongFullRunsStartedByMathAgent':False,'RuntimeOwner':'root','AcceptanceBoundary':'Направленные группы не заменяют все действующие ON/OFF и часовой план; общий PASS полных прогонов здесь не заявлен.'})

native_path=REVIEW/'CandidateDirected04_Probes.json'
if native_path.exists():
    d=json.loads(native_path.read_text(encoding='utf-8-sig'))
    selected=[]
    for p in d.get('Probes',[]):
        name=p.get('Macro',p.get('Name',p.get('Test','')))
        if any(m in name for m in ('RunCrackTranslationTests','RunMaterialPointOrderTests','RunLimitRequestLifecycleTests','RunAudit03ExtremeLinearSystemTests','RunSectionSolverTests','RunMaterialDiagramTests')):
            actual=str(p.get('Actual',''))
            selected.append({'Macro':name,'Totals':re.findall(r'TOTAL[^\r\n]*',actual),'Failures':re.findall(r'(?:^|\n)(?:FAIL:|RUNTIME ERROR:)[^\r\n]*',actual)})
    imports=[]
    for imp in d.get('Imports',[]):
        if imp.get('Path','').startswith(('src/Crack/','src/Materials/','src/Solver/')) or imp.get('Path','') in ['tests/'+n for n in ('modTestCrackWidth.bas','modTestMaterialDiagrams.bas','modTestSectionSolver.bas','modTestCapacitySolver.bas')]:
            current=hashlib.sha256((ROOT/imp['Path']).read_bytes()).hexdigest().upper()
            imports.append({'Path':imp['Path'],'NativeImportedSHA256':imp['SHA256'],'CurrentSHA256':current,'Matches':current==imp['SHA256'].upper()})
    write('NativeMathDirectedSummary.json',{'Evidence':native_path.relative_to(ROOT).as_posix(),'EvidenceSHA256':hashlib.sha256(native_path.read_bytes()).hexdigest().upper(),'Status':d['Status'],'OriginalPublishedSourceSHA256':d['SourceSHA256'],'PrivateCandidateImported':d.get('PrivateCandidateImported'),'SourceUnchanged':d.get('SourceUnchanged'),'Macros':selected,'AllImportedMathFilesMatchCurrent':all(p['Matches'] for p in imports),'ImportedFiles':imports,'NoFailuresInSelectedGroups':all(not m['Failures'] for m in selected),'FullOnOffAcceptanceClaimed':False})
    assert len(selected)==6,(len(selected),selected)
    assert all(not m['Failures'] for m in selected)
    assert all(p['Matches'] for p in imports),imports
print('NormReview, Findings, EdgeCasePlan and native summary prepared.')
