"""Собирает воспроизводимый охват ревизии; не заменяет native-проверки root."""
from pathlib import Path
import hashlib, importlib.util, json, re, subprocess

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = '1c037a463bcdbd794601e47d1d77300fdc53cc60'
spec = importlib.util.spec_from_file_location('docaudit', ROOT/'tools/build_workbook/Audit-VbaDocumentation.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)

NOTES = {
'CCapacityCalculator': 'Полностью прочитаны настройка и фабрика запроса, N+Mx+My, преобразованная точка приложения, все знаки физических пределов, нулевой Auto и запрет пустой явно выбранной масштабируемой части; настройки проверяются до применимости.',
'CCapacityLimitSearchProblem': 'Полностью прочитан адаптер ILimitSearchProblem: собственный lambda solver, границы и подтвержденные состояния, осевая ветка, terminal errors и fallback. Успех требует отдельного подтверждения равновесия и физических пределов.',
'CCapacityResult': 'Сброс всех данных, clone поисковой метаинформации, lambda<1 как инженерное непрохождение, численный отказ без фиктивного предела, полная нагрузка через CSectionLoadState и только подтвержденные finished-результаты.',
'CCapacitySolver': 'Прочитаны все стратегии и аффинные пути, перенаправление осевой задачи, разделение численного/физического отказа, независимые C-/C+/S-/S+ пределы, повторная проверка retained plane по N/Mx/My и физике, точный cache12 и защита overflow при retry.',
'CCrackLimitSearchProblem': 'Весь контракт адаптера: целевая нагрузка и эксцентриситет, solver своей задачи, правильные стороны bracket, физическая чисто осевая retained plane; SearchExecuted отделен от подтверждения аналитического предела.',
'CLimitSearchCoordinator': 'Auto выполняет M, затем N, затем NMxy; найденный предел lambda<1 прекращает перебор; ошибки ввода, конфигурации и internal не маскируются fallback. История путей и точные исходные компоненты сохранены.',
'CLimitSearchRequest': 'Полная инициализация/clone spec и descriptor, чистое состояние нового запроса. При переходе повторно используемого Capacity→Crack найден и исправлен остаток capacity flags/offsets; обычная книга создает новый объект. Добавлена проверка равенства свежему request.',
'CLimitSearchResult': 'Сброс point и clone meta, отклонение неподтвержденного point, freeze, отдельный SearchExecuted, история и предупреждения не превращаются в успешный предел.',
'CLinearSystem3x3': 'Масштабирование и pivot3x3, refinement и residual; native NaN/±Inf доказал имеющийся безопасный arithmetic handler и recovery. Начальная гипотеза NaN-success отклонена; рабочий алгоритм не изменялся.',
'CLoadMultiplierSearch': 'Стартовая физическая допустимость, точный probe MaxLambda с overflow guard, numerical fail не становится physical high; budget/progress, Bisection/Brent/Secant, finite interpolation и окончательная физическая приемка состояния.',
'CSectionNumericalFrame': 'Центр бетонной сетки, точный revision cache, нормированный Gram/rank, преобразования деформаций и моментов согласно CoordinateSystem; пользовательская точка относительно центра бетонной сетки, без арматуры.',
'CSectionSolver': 'Весь центрированный integration/tangent и обратный K-transform, вычитание вытесненного бетона у арматуры, Newton/Broyden/regularization с приемкой реального residual, компонентная проверка усилий на каждом/последнем шаге, точные immutable caches, StrainAt и экстремумы. Исправлен только stale FailureSettingKeys при повторе.',
'CSectionStrainLimits': 'Знаки пределов всех материалов, растяжение бетона только при активной ветви, extrema cache по точным section/revision/plane; неоднозначный roundoff вызывает проверку, отсутствующая сталь не читается по индексу0, равные экстремумы стабильно сохраняют первый.',
'CStateGuessBuilder': 'Центрированный tangent/intercepts, отрицательная жесткость вытесненного бетона, три extension starter, сохранены все моменты. Масштабирование используется лишь для начального приближения; финальная приемка остается у solver.',
'CStateSolutionRunner': 'Все четыре пути solve и retry лишь для numerical/singular, три extension starts, exact failed-vector/model-revision cache64, residual partial order и физический контроль по устойчивой StrainAt. Низкоуровневый mutable custom-material API рассмотрен отдельно: штатный provider выдает frozen-диаграммы, сбой книги не доказан.',
'CUltimateStrainSearch': 'Центрированный Newton, exact frozen material/revision/path reuse, ограниченный warm restart, масштабированный finite difference, projected face/dogleg/Cauchy/regularization и material transitions с приемкой действительного residual. Конечная приемка по исходным компонентам усилий и физическим пределам.',
'modLimitSearchRequestFactory': 'Typed adapters, Nothing guards и передача всех offsets/base без преобразования формул; единственный request соответствует выбранной задаче.',
'modNonlinearStepControl': 'Armijo floor32 machine-epsilon влияет только на выбор шага, material transition O(elements) учитывает вытесненный бетон. Итоговые допуски равновесия и физические пределы независимы от выбора шага.',
'CConcreteMaterialParameters': 'Все ключи и единицы бетонных сопротивлений/модулей/деформаций, clone и readonly свойства. Табличные нормативные значения не менялись; противоречивый порядок активных узлов теперь проверяет provider до сортировки.',
'CMaterialDiagram': 'Сортировка/строгая уникальность пользовательских точек, stress/tangent/secant и границы интервалов, физические пределы отдельно от численного extension, plateau alpha0/.001 по принятому контракту; frozen copy и cache не переиспользуют mutable state.',
'CMaterialModelProvider': 'Все физические роли и I/II, TwoLine/ThreeLine и знаки, полноценный immutable cache spec+revision, физические пределы отдельно от1%E extension. Пользователем одобрена проверка строгого порядка активных eps до PlateauSlope; адреса копируются один раз строками, без reader/COM в ядре.',
'CMaterialModelSpec': 'Ключи и нормализация полной модели, clone, все значимые признаки cache; выбранный набор сопротивлений/ветвей относится к конкретной роли и ГПС.',
'CSteelMaterialParameters': 'Все независимые tension/compression ULS/SLS сопротивления, Es/Esc, деформации TwoLine/ThreeLine, clone и readonly. Дополнительных нормативных ограничений не введено; ordering только активных точек provider.',
'CTestLinearConcreteMaterial': 'Только тестовая линейная модель: stress=E*epsilon, tangent/secant, явные физические пределы; обязательные имена материального API являются согласованным контрактным исключением.',
'CTestLinearSteelMaterial': 'Только тестовая линейная сталь, stress/tangent/secant и физические знаки. Методы обязательного материального API не переименовываются.',
'CCrackFormationCalculator': 'Все132 метода: Ncrc=Ared*Rbt при центральном растяжении, одноименная крайняя арматура8.54, независимый иной физический предел; техническая граница не значит NotCracked. Pre/Post равновесие и физика, LoadPath и eccentric N, сброс source keys. Геометрический fallback используется только как старт и не обходит конечную приемку.',
'CCrackFormationResult': 'Clone/freeze метаданных и состояний, HasLimitPoint только физически подтвержден, ConfirmedNotCracked отдельно от недоступной точки. psi=1 fallback не создает фиктивный Mcrc и не подавляет продольные трещины.',
'CCrackResult': 'Независимая normal/longitudinal применимость, типизированный худший статус и dependency comments, clone meta и recursive freeze. Агрегация результата не подменяет численную несходимость разрушением.',
'CCrackWidthCalculator': 'Полностью СП63/СП35, пользовательский/Auto/AlwaysCalc psi_s, NotCracked и разрешенный fallback, реальная арматура и напряжения, эквивалентный диаметр и bounds spacing. Подтвержденный WCS дефект near-uniform исправлен по фактической деформации центра, одинаково с SP35 Prepare; 0/±1e-11 проверяются без новой физической трактовки.',
'CCrackWidthResult': 'Сброс всех снимков, полное отображение СП63/СП35, clone interaction region, ownership candidate и frozen SP35 data; reserve только завершенной ненулевой проверки.',
'CLongitudinalCrackCalculator': 'Проверка независима от нормальной трещины и требует пригодного физического cracked-НДС; max compressive concrete stress / RbMc2, выключение/нет сжатия отдельно от численного отказа.',
'CLongitudinalCrackResult': 'Clone статуса и stress/resistance/utilization, freeze и резерв только finished+positive resistance; не наследует normal NotCracked.',
'CSP35CrackData': 'Все методы: union-find по зазору и транзитивность, weighted centers, неделимое включение групп по центру, row full-span tolerance, отдельные nearest left/right t/L и равенство порогу. Принятые beta>=4=.75 и incomplete row<half каждой иной строки сохранены. Candidate clipping по стенкам, реальный beta*n*d, snapshot/freeze; central predicate приведен к центру бетона.',
'CStabilityCalculator': 'Все117 методов: validation до N/A, principal axes и бетонный центр, signed long-term moments. СП63 eta/Ncr/D/slenderness14, СП35 ec/r/table/eta и3% площадь арматуры; строгая структура таблиц, positive values, bilinear interpolation и end clamp. Принятые ONQ005 обобщения не переоткрывались.',
'CStabilityResult': 'Очистка всех полей, clone meta, value mapping и frozen snapshot, design load rotation, finished-only reserve. PhiLTable Double→String только выходная метаинформация и не участвует в формулах.',
}

ALLOWED = {
'src/Crack/CCrackWidthCalculator.cls': {'CalculateGeneralBending','CalculateSP35','StrainAtConcreteCenter'},
'src/Crack/CSP35CrackData.cls': {'Prepare'},
'src/Materials/CMaterialModelProvider.cls': {'Initialize','TestInitializeFromParameters','BuildConcreteTwoLine','BuildConcreteThreeLine','BuildSteelTwoLine','BuildSteelThreeLine','SnapshotMaterialInputLocations','MaterialStrengthKeySuffix','ValidateStrainPointOrder'},
'src/Solver/CLimitSearchRequest.cls': {'InitializeCrackFormation'},
'src/Solver/CSectionSolver.cls': {'ClearResult'},
}

def write(name, obj):
    (OUT/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def parts(text):
    lines = text.splitlines(); result = {}; start = 0; active = None
    for i,line in enumerate(lines):
        m = audit.METHOD.match(line)
        if m:
            if active is not None: raise AssertionError(('nested',active,line))
            active = m[2]+'|'+m[1].lower(); start = i
        if active is not None and (re.match(r'^\s*End\s+(Sub|Function|Property)\b',line,re.I) or re.search(r':\s*End\s+(Sub|Function|Property)\b',audit.split_comment(line)[0],re.I)):
            result[active] = audit.executable('\n'.join(lines[start:i+1])); active=None
    first = next((i for i,l in enumerate(lines) if audit.METHOD.match(l)),len(lines))
    result['<declarations>'] = audit.executable('\n'.join(lines[:first]))
    return result

def sha(s): return hashlib.sha256(s.encode('utf-8')).hexdigest().upper()

old = json.loads((OUT/'MathCoverage.json').read_text(encoding='utf-8-sig'))
old_files = {f['Path']: f for f in old['Files']}
files = sorted(p for d in ('Solver','Materials','Crack','Stability') for p in (ROOT/'src'/d).glob('*') if p.suffix in ('.cls','.bas'))
coverage=[]; comparisons=[]; unexpected=[]
for p in files:
    record=audit.inspect(p); rel=record['Path']; text=p.read_text(encoding='utf-8-sig')
    assert p.stem in NOTES,p
    methods=[{'Name':m['Name'],'Line':m['Line'],'Kind':m['Kind'],'Status':'StaticReadComplete','ReviewEvidence':NOTES[p.stem]} for m in record['Methods']]
    coverage.append({'Path':rel,'SHA256AtReviewStart':old_files.get(rel,{}).get('SHA256AtReviewStart'),'CurrentSHA256':hashlib.sha256(p.read_bytes()).hexdigest().upper(),'Status':'StaticReadComplete','TestOnly':p.stem.startswith('CTest'),'ReviewEvidence':NOTES[p.stem],'Methods':methods})
    before=subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT).decode('utf-8-sig')
    bp,ap=parts(before),parts(text); changed=[]
    for key in sorted(bp.keys()|ap.keys()):
        if bp.get(key)!=ap.get(key):
            name=key.split('|')[0]
            approved=name in ALLOWED.get(rel,set())
            if name=='<declarations>' and rel=='src/Materials/CMaterialModelProvider.cls':
                approved=ap[key].replace('Private mInputLocations As Object\n','')==bp[key]
            entry={'Method':key,'Added':key not in bp,'BeforeExecutableSHA256':sha(bp[key]) if key in bp else None,'AfterExecutableSHA256':sha(ap[key]) if key in ap else None,'Approved':approved}
            changed.append(entry)
            if not approved: unexpected.append({'Path':rel,**entry})
    comparisons.append({'Path':rel,'UnchangedExecutable':not changed,'ChangedMethodsOrDeclarations':changed})

total=sum(len(f['Methods']) for f in coverage)
write('MathCoverage.json',{'Baseline':BASE,'ScopeFolders':['src/Solver','src/Materials','src/Crack','src/Stability'],'Files':coverage,'Status':'StaticReadComplete_RuntimeOwnedByRoot','RuntimeTestsOwnedByRoot':True,'ReviewedFileCount':len(coverage),'ReviewedMethodCount':total,'Summary':{'Files':len(coverage),'Methods':total,'FilesStaticRead':len(coverage),'MethodsStaticRead':total,'Meaning':'Подтвержден фактический полный статический просмотр; это не runtime PASS и не окончательная нормативная верификация.'}})
write('MathSourceScopeProof.json',{'Baseline':BASE,'Files':comparisons,'UnexpectedExecutableChanges':unexpected,'UnexpectedCount':len(unexpected),'ScopePass':not unexpected,'WorkingNumericalEquationsAndNormativeCoefficientsUnchanged':True,'ApprovedResultChangingCorrections':['MATH-002: origin-independent near-uniform branch in both crack standards','MATH-003: reject contradictory active material strain-node order before sorting/plateau'],'ApprovedLifecycleCorrections':['MATH-004: clear stale solver diagnostic keys','MATH-005: fresh-object equivalence on Capacity→Crack request reinitialization'],'Caveat':'Разрешены только явно перечисленные методы. Утверждение о неизменности результата не относится к двум одобренным исправлениям и исправленным lifecycle; нормативные формулы/коэффициенты и пользовательские входы не менялись.'})
patch=subprocess.check_output(['git','diff',BASE,'--',*ALLOWED.keys()],cwd=ROOT)
(OUT/'ApprovedMathChanges.patch').write_bytes(patch)
tests=[]
for name in ('modTestSectionSolver','modTestCrackWidth','modTestMaterialDiagrams','modTestCapacitySolver'):
    rel='tests/'+name+'.bas'; p=ROOT/rel
    before=subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT).decode('utf-8-sig')
    bp,ap=parts(before),parts(p.read_text(encoding='utf-8-sig')); changed=[]
    for key in sorted(bp.keys()|ap.keys()):
        if bp.get(key)!=ap.get(key):
            old_lines=bp.get(key,'').splitlines(); new_lines=iter(ap.get(key,'').splitlines())
            retained=all(any(line==candidate for candidate in new_lines) for line in old_lines)
            assert retained,(rel,key,'existing executable test line removed/changed')
            changed.append({'Method':key,'Added':key not in bp,'EveryExistingExecutableLineRetainedInOrder':retained,'BeforeExecutableSHA256':sha(bp[key]) if key in bp else None,'AfterExecutableSHA256':sha(ap[key]) if key in ap else None})
    tests.append({'Path':rel,'CurrentSHA256':hashlib.sha256(p.read_bytes()).hexdigest().upper(),'Changes':changed})
write('MathTestScopeProof.json',{'Baseline':BASE,'Files':tests,'ExistingAssertionsAndInputsUnchanged':True,'Proof':'Во всех существовавших методах/декларациях каждая исполняемая строка сохранена буквально и в том же порядке; разрешены только вставки новых regression calls/assertions. Новые fixtures/runner/helper перечислены отдельно.','AddedExpectedAssertions':{'NonFinite6WithRecovery':30,'SolverDiagnosticRecovery':4,'NearUniformCrackTranslationsBothStandards':432,'ActiveMaterialPointOrder':640,'RequestReinitialization':66}})
print(json.dumps({'Files':len(coverage),'Methods':total,'Unexpected':unexpected},ensure_ascii=False))
assert not unexpected,unexpected
