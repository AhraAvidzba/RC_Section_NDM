Attribute VB_Name = "modTestOptionalNumberProbe"
Option Explicit

' ==================== ДЛЯ ТЕСТОВ ====================
' Нативная проверка разных грамматик IsNumeric/CDbl/Val только для
' необязательного числа оформления. Листы, настройки и рабочий код не меняет.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет roundtrip штатного writer и отдельно фиксирует результаты только
' реально принятых токенов. Отвергнутые произвольные строки не объявляет багами.
Public Function TestOptionalNumberGrammar() As String
    On Error GoTo Failed
    Dim report As String, passed As Long, failedCount As Long, mismatches As Long
    Dim guardReadThrows As Long, referenceThrows As Long, accepted As Long, rejected As Long
    Dim number As Variant, raw As Variant, text As String, currencyPositive As String, currencyNegative As String
    report = "OPTIONAL_NUMBER_LOCALE: decimal=" & Mid$(CStr(0.5), 2, 1) & vbCrLf
    For Each number In Array(0#, 1.25, -1.25, 0.000000000001, -0.000000000001, _
            1E-100, -1E-100, 1E+20, -1E+20, 1.23456789012345E+100, 1E+200, -1E+200)
        text = SectionOptionalNumber(CDbl(number))
        TestProbeOptionalString report, passed, failedCount, mismatches, guardReadThrows, referenceThrows, accepted, rejected, _
            "writer", text, True, CDbl(number)
    Next number
    currencyPositive = Replace$(FormatCurrency(10#, 0, vbTrue, vbFalse, vbFalse), ",", vbNullString)
    currencyNegative = Replace$(FormatCurrency(-10#, 0, vbTrue, vbFalse, vbFalse), ",", vbNullString)
    For Each raw In Array("$10", "10$", "&H10", "&O10", "1D2", "1d-2", "1E2", "1.25D+2", _
            "+1.25", "-1.25", "1.25E-6", "10%", "50.5%", "10&", "1.5!", "  1.25  ", "1,25", "10foo", currencyPositive, currencyNegative)
        TestProbeOptionalString report, passed, failedCount, mismatches, guardReadThrows, referenceThrows, accepted, rejected, _
            "raw", CStr(raw), False, 0#
    Next raw
    report = report & "OPTIONAL_NUMBER_SUMMARY: accepted=" & CStr(accepted) & "; rejected=" & CStr(rejected) & _
        "; silentMismatch=" & CStr(mismatches) & "; guardAcceptedReadThrows=" & CStr(guardReadThrows) & _
        "; readAcceptedCDblThrows=" & CStr(referenceThrows) & vbCrLf
    TestOptionalNumberGrammar = report & "TOTAL_OPTIONAL_NUMBER_GRAMMAR: passed=" & CStr(passed) & "; failed=" & CStr(failedCount)
    Exit Function
Failed:
    TestOptionalNumberGrammar = report & "RUNTIME ERROR: " & CStr(Err.Number) & "; " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставляет действующий guard, фактический reader, Val и CDbl от той же
' локализованной строки. Не принимает ошибку CDbl за известное истинное число.
Private Sub TestProbeOptionalString(ByRef report As String, ByRef passed As Long, ByRef failedCount As Long, _
        ByRef mismatches As Long, ByRef guardReadThrows As Long, ByRef referenceThrows As Long, _
        ByRef accepted As Long, ByRef rejected As Long, ByVal kind As String, ByVal text As String, _
        ByVal writerValue As Boolean, ByVal original As Double)
    Dim localized As String, guard As Boolean, actual As Double, reference As Double, viaVal As Double
    Dim readError As Long, referenceError As Long, valError As Long, readReason As String
    localized = Replace$(text, ".", Mid$(CStr(0.5), 2, 1))
    If Len(Trim$(text)) > 0 And InStr(text, ",") = 0 Then guard = IsNumeric(localized) ' Точно тот же допуск строк, что у production reader.
    On Error Resume Next
    Err.Clear
    actual = ReadSectionOptionalNumber(text, "native optional-number probe")
    readError = Err.Number: readReason = Err.Description
    Err.Clear
    reference = CDbl(localized)
    referenceError = Err.Number
    Err.Clear
    viaVal = Val(text)
    valError = Err.Number
    Err.Clear
    On Error GoTo 0
    report = report & "OPTIONAL_NUMBER_CASE: kind=" & kind & "; text=[" & text & "]; guard=" & CStr(guard) & _
        "; readErr=" & CStr(readError) & "; read=" & TestProbeNumber(actual) & _
        "; cdblErr=" & CStr(referenceError) & "; cdbl=" & TestProbeNumber(reference) & _
        "; valErr=" & CStr(valError) & "; val=" & TestProbeNumber(viaVal) & vbCrLf
    If readError <> 0 Then
        rejected = rejected + 1
        If writerValue Or guard Then ' Ошибка на постороннем уже отвергнутом токене не считается дефектом допустимого числа.
            guardReadThrows = guardReadThrows + 1
            TestProbeAssert report, passed, failedCount, kind & ".guardAcceptedReadThrow. [" & text & "]; cause=" & readReason, False
        End If
        Exit Sub
    End If
    accepted = accepted + 1
    TestProbeAssert report, passed, failedCount, kind & ".readerMatchesGuard. [" & text & "]", guard
    If writerValue Then TestProbeAssert report, passed, failedCount, "writer.roundtrip. [" & text & "]", TestProbeClose(actual, original)
    If referenceError = 0 Then
        If Not TestProbeClose(actual, reference) Then mismatches = mismatches + 1
        TestProbeAssert report, passed, failedCount, kind & ".acceptedMatchesCDbl. [" & text & "]", TestProbeClose(actual, reference)
    Else
        referenceThrows = referenceThrows + 1
        report = report & "ACCEPTED_REFERENCE_THROW: text=[" & text & "]; CDbl error=" & CStr(referenceError) & _
            "; no independent expected number asserted" & vbCrLf
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает только конечные числа выбранных проб; относительный допуск
' учитывает writer оформления и не применяется к расчетным критериям НДС.
Private Function TestProbeClose(ByVal actual As Double, ByVal expected As Double) As Boolean
    If expected = 0# Then
        TestProbeClose = (actual = 0#)
    Else
        TestProbeClose = Abs(actual - expected) <= Abs(expected) * 0.000000000001
    End If
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет число в отчёт с точкой; это только читаемый протокол, не вход parser.
Private Function TestProbeNumber(ByVal value As Double) As String
    TestProbeNumber = Replace$(CStr(value), ",", ".")
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отдельно учитывает assertions: непринятые произвольные строки сюда не попадают.
Private Sub TestProbeAssert(ByRef report As String, ByRef passed As Long, ByRef failedCount As Long, _
        ByVal name As String, ByVal condition As Boolean)
    If condition Then
        passed = passed + 1: report = report & "OK: " & name & vbCrLf
    Else
        failedCount = failedCount + 1: report = report & "FAIL: " & name & vbCrLf
    End If
End Sub
