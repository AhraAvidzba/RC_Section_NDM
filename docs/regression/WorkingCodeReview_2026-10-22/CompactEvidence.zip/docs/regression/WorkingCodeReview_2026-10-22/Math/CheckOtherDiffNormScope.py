"""Read-only проверка текущего diff остальных рабочих правок на нормативный scope.

Смысловая сверка описана в NOTES. Изменение метода вне явно прочитанного
набора требует новой ручной проверки, даже если существующие тесты проходят.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re,subprocess

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
BASE='1c037a463bcdbd794601e47d1d77300fdc53cc60'
METHOD=re.compile(r'^\s*(?:(?:Public|Private|Friend|Static)\s+)*(Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)\b',re.I)
ALLOWED={
 'src/Excel/CLoadCombinationReader.cls':{'LoadFromRange'},
 'src/Excel/CPlotAnnotationLayout.cls':{'AppendItem','EnsureItemCapacity','<declarations>'},
 'src/Excel/CSectionInputSnapshotReader.cls':{'Capture'},
 'src/Excel/CSectionPlotDataReader.cls':{'ReadBatchSummaryComment','ReadAnnotations','ReadMaterialContours','EnsureAnnotationCapacity','ResetReaderState','<declarations>'},
 'src/Excel/modWorkbookCalculation.bas':{'RunSectionCalculation','FormSection','FormSectionForWorkbook','RunSectionCalculationForWorkbook'},
 'src/Geometry/CFiberMeshBuilder.cls':{'BuildMesh'},
 'src/Geometry/CGeometryPath.cls':{'SegmentAtDistance'},
 'src/Geometry/CGeometryVariableOffset.cls':{'Build','EdgeArea'},
 'src/Section/CRebarOffsetContours.cls':{'Initialize'},
 'src/Section/CSectionGeometryQuery.cls':{'KeepOuterMeshContours'},
 'src/Section/CSectionModel.cls':{'AddConcreteElement','NormalizeAnglePi'},
 'src/Section/CSectionPropertiesCalculator.cls':{'AddWeightedArea','CoreDistanceAlong','FinalizeProperties','Clear','<declarations>'},
}
NOTES={
 'src/Excel/CLoadCombinationReader.cls':'До размеров/Value2 отвергает source.Areas.Count<>1 с понятным адресом и решением. Это routine исправление усечения многодиапазонного источника до первой области; успешная единая прямоугольная таблица и ее нагрузки/единицы/профили не меняются.',
 'src/Excel/CPlotAnnotationLayout.cls':'Только геометрический рост закрытых массивов с Count, прежние координаты/текст/стиль записываются в тот же индекс. Не затронуты расчет НДС, материалы или нормативные формулы.',
 'src/Excel/CSectionInputSnapshotReader.cls':'Reader больше не делает отдельный Range.Calculate; свежесть формул перенесена на границу пользовательского действия. Это политика чтения входов, результат dirty-cache может обоснованно измениться; не новая формула или нормативный коэффициент.',
 'src/Excel/CSectionPlotDataReader.cls':'Поиск summary comment теперь ограничен строками своей таблицы и пропускает пустые слоты; закрытые массивы аннотаций растут геометрически. Единицы, геометрические числа, НДС и формулы ширины/устойчивости не изменены.',
 'src/Excel/modWorkbookCalculation.bas':'Один Application.Calculate после guard и до LoadFromWorkbook/материалов/нагрузок; флаг сообщений возвращается из того же снимка вместо раннего чтения. Затрагивает все открытые книги данного Excel и требует своей явно принятой политики; нормативные формулы и роли профилей не меняет. Экспорт/повторная схема в этом diff не запускают новый расчет.',
 'src/Geometry/CFiberMeshBuilder.cls':'Сброс старой/частичной сетки только у изменяемого builder и восстановление elapsed через полночь. Геометрический критерий включения, порядок добавления и настройки разбиения не менялись; Frozen сохраняется при отклоненном изменении.',
 'src/Geometry/CGeometryPath.cls':'После согласования «Да, исправить и проверить углы» default outgoing применяет тот же существующий GEOM_TOLERANCE симметрично относительно внутреннего стыка; incoming уже использовал +tolerance. Не менялись сами stations, координаты CAD, длины, endpoints, очередность публикации и коллизии. Возможное изменение Extra у почти точного угла намеренное, не новая нормативная формула.',
 'src/Geometry/CGeometryVariableOffset.cls':'Сумма ориентированных площадей хорд считается относительно общей точки замкнутого кольца; до/после offset используется одна опора. В точной арифметике это тождественная формула площади, устраняющая потерю значащих разрядов при большом WCS. Радиус, swept-angle сегмента, допуски и величины отступов не менялись.',
 'src/Section/CRebarOffsetContours.cls':'Только общий origin исходного кольца при сумме площадей для выбора левой нормали; координаты ребер/расстояние axis/порядок армирования не меняются. Это согласованная с EdgeArea численная стабилизация, не новая нормативная трактовка.',
 'src/Section/CSectionGeometryQuery.cls':'Каждому кольцу сетки назначена своя опора суммы ориентированных площадей. Отбор Outer по положительной площади и QUERY_TOLERANCE сохранены; это алгебраическое центрирование, не смена области трещин или правил Outer/Opening.',
 'src/Section/CSectionModel.cls':'Огромный rotation сводится за постоянное время до тригонометрии; штатный диапазон до2pi прежний. Count публикуется только после успешной подготовки нового слота, чтобы отказ не оставлял видимый частичный элемент. Формулы собственных инерций, A, (Es/Eb-1)*As, имена элементов и координаты не менялись.',
 'src/Section/CSectionPropertiesCalculator.cls':'Одобренные radius-core и inertia fixes: размерно неверное сравнение 1/мм3 с длиной заменено проверкой знака; A/S/I накапливаются относительно первого элемента, центральные I вычисляются до возврата публичных глобальных S/I. Веса, собственные инерции и теорема переноса остаются прежними. Числа при ошибочном большом WCS/масштабе исправляются; новая формула СП не вводится.',
}

def code(line):
 q=False;i=0
 while i<len(line):
  if line[i]=='"':
   if q and i+1<len(line) and line[i+1]=='"':i+=2;continue
   q=not q
  elif line[i]=="'" and not q:return line[:i].rstrip()
  i+=1
 return line.rstrip()

def executable(lines):return '\n'.join(c for l in lines if (c:=code(l)).strip() and not re.match(r'^\s*Rem(?:\s|$)',c,re.I))
def parts(text):
 lines=text.splitlines();out={};active=None;first=None
 for i,line in enumerate(lines):
  c=code(line);m=METHOD.match(c)
  if m:
   assert active is None,(active,i)
   if first is None:first=i
   active=(m[2]+'|'+m[1].lower(),i)
  if active is not None and (re.match(r'^\s*End\s+(Sub|Function|Property)\b',c,re.I) or re.search(r':\s*End\s+(Sub|Function|Property)\b',c,re.I)):
   key,start=active;out[key]=executable(lines[start:i+1]);active=None
 out['<declarations>']=executable(lines[:first] if first is not None else lines)
 return out

changed=subprocess.check_output(['git','diff','--name-only',BASE,'--','src'],cwd=ROOT).decode('utf-8').splitlines()
math_folders=('src/Crack/','src/Materials/','src/Solver/','src/Stability/')
others=[p for p in changed if not p.startswith(math_folders)]
unknown=[];rows=[]
for rel in others:
 p=ROOT/rel
 before=subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT).decode('utf-8-sig')
 after=p.read_text(encoding='utf-8-sig');bp,ap=parts(before),parts(after);items=[]
 for key in sorted(bp.keys()|ap.keys()):
  if bp.get(key)!=ap.get(key):
   allowed=key.split('|')[0] in ALLOWED.get(rel,set())
   entry={'Method':key,'WithinReviewedScope':allowed,'BeforeExecutableSHA256':hashlib.sha256(bp[key].encode()).hexdigest().upper() if key in bp else None,'AfterExecutableSHA256':hashlib.sha256(ap[key].encode()).hexdigest().upper() if key in ap else None}
   items.append(entry)
   if not allowed:unknown.append({'Path':rel,**entry})
 patch=subprocess.check_output(['git','diff',BASE,'--',rel],cwd=ROOT)
 rows.append({'Path':rel,'CurrentSHA256':hashlib.sha256(p.read_bytes()).hexdigest().upper(),'DiffSHA256':hashlib.sha256(patch).hexdigest().upper(),'ChangedExecutableMethodsOrDeclarations':items,'AcceptedNormReview':NOTES.get(rel,'UNREVIEWED')})

protected_changed=subprocess.check_output(['git','diff','--name-only',BASE,'--','norms','reference','control_examples'],cwd=ROOT).decode('utf-8').splitlines()
formula_files=['src/Stability/CStabilityCalculator.cls','src/Crack/CCrackFormationCalculator.cls','src/Crack/CLongitudinalCrackCalculator.cls','src/Materials/CMaterialDiagram.cls','src/Materials/CConcreteMaterialParameters.cls','src/Materials/CSteelMaterialParameters.cls','src/Excel/CUnitSystem.cls']
formula_evidence=[]
for rel in formula_files:
 b=subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT).decode('utf-8-sig')
 a=(ROOT/rel).read_text(encoding='utf-8-sig')
 formula_evidence.append({'Path':rel,'ExecutableUnchanged':executable(b.splitlines())==executable(a.splitlines()),'CurrentSHA256':hashlib.sha256((ROOT/rel).read_bytes()).hexdigest().upper()})
report={'Baseline':BASE,'AsOfUTC':datetime.now(timezone.utc).isoformat(),'ReadOnlyReview':True,'FilesReviewed':rows,'UnexpectedChangedMethods':unknown,'ProtectedSourceChanges':protected_changed,'PrimaryNormativeImplementations':formula_evidence,'UnintendedAcceptedNormFormulaChangeDetected':False if not unknown and not protected_changed and all(x['ExecutableUnchanged'] for x in formula_evidence) else None,'ScopeBoundary':'Это независимое чтение конкретного текущего diff, не полный повтор всей ревизии, не доказательство отсутствия всех дефектов. SHA привязаны к моменту снимка; после новых правок нужен повтор.','AcceptedNormDecisionsChanged':False,'IntentionalBehaviorChanges':'Core/inertia/area coordinate invariance, отказ от противоречивых material узлов и выбор actual crack center — отдельные одобренные исправления. Manual input freshness — отдельное пользовательское решение. Их нельзя описывать как побитно неизменный общий результат.','OverallPassClaimed':False}
(OUT/'OtherWorkingDiffNormReview.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'OtherChangedFiles':len(rows),'UnknownChangedMethods':unknown,'ProtectedChanged':protected_changed,'PrimaryNormativeImplementationsUnchanged':all(x['ExecutableUnchanged'] for x in formula_evidence)},ensure_ascii=False))
assert not unknown and not protected_changed and all(x['ExecutableUnchanged'] for x in formula_evidence)
