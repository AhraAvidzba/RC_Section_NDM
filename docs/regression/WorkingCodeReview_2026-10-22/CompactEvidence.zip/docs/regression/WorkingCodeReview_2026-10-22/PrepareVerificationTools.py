"""ДЛЯ ТЕСТОВ: закрепляет безопасные локальные копии существующих проверок."""
from pathlib import Path
import hashlib
import json

directory = Path(__file__).resolve().parent
root = directory.parents[2]
tools = root / 'tools/build_workbook'
cad = (tools / 'Test-CADKernelRoundoff.ps1').read_text(encoding='utf-8-sig')
cad = cad.replace("Join-Path $PSScriptRoot '../..'", "Join-Path $PSScriptRoot '../../..'")
cad = cad.replace(" $excel=New-Object -ComObject Excel.Application", " $existingExcel=@(Get-Process EXCEL -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)\n $excel=New-Object -ComObject Excel.Application\n [uint32]$freshID=0;[void][CADMathWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$freshID)\n if([int]$freshID -in $existingExcel){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null;throw 'Refusing to change a pre-existing Excel process.'}")
cad = cad.replace("Join-Path $PSScriptRoot 'Compare-CADKernelEvidence.py'", "Join-Path $root 'tools/build_workbook/Compare-CADKernelEvidence.py'")
(directory / 'Test-OwnedCADRoundoff.ps1').write_text(cad, encoding='utf-8-sig')

export = (tools / 'Export-Audit03VbaSnapshot.ps1').read_text(encoding='utf-8-sig')
export = export.replace("Join-Path $PSScriptRoot '../..'", "Join-Path $PSScriptRoot '../../..'")
export = export.replace("$postAuditAllowed =", "$workingAllowed=[IO.Path]::GetFullPath((Join-Path $root 'docs/regression/WorkingCodeReview_2026-10-22'))+[IO.Path]::DirectorySeparatorChar\n$postAuditAllowed =", 1)
export = export.replace("if (-not $path.StartsWith($workflowAllowed", "if (-not $path.StartsWith($workingAllowed,[StringComparison]::OrdinalIgnoreCase) -and -not $path.StartsWith($workflowAllowed", 1)
export = export.replace("    $excel = New-Object -ComObject Excel.Application", "    $existingExcel=@(Get-Process EXCEL -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)\n    $excel = New-Object -ComObject Excel.Application\n    [uint32]$freshID=0;[void][VbaSnapshotWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$freshID)\n    if([int]$freshID -in $existingExcel){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null;throw 'Refusing to change a pre-existing Excel process.'}")
(directory / 'Export-OwnedVbaSnapshot.ps1').write_text(export, encoding='utf-8-sig')

book = directory / 'CompiledCandidate05_Probes.xlsm'
record = {'Artifact': str(book.relative_to(root)).replace('\\', '/'), 'SHA256AfterClose': hashlib.sha256(book.read_bytes()).hexdigest().upper(), 'Reason': 'Supplement: original run attempted to hash while Excel held the file; saved before macros, closed without saving fixtures.', 'OriginalRecordPreserved': True}
(directory / 'CompiledCandidate05_Artifact.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print('Prepared safe native verification tools and supplementary artifact hash.')
