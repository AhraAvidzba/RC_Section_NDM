"""Замыкает только адресную приёмку и сохранность выпуска; не полный ON/OFF."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
load = lambda n: json.loads((HERE/n).read_text('utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest().upper()
on, off = load('FinalDirected14_Probes.json'), load('FinalFrozen15_Probes.json')
assert on['Status'] == off['Status'] == 'PROBES_COMPLETED'
assert on['SourceUnchanged'] and off['SourceUnchanged']
assert on['DiagramExtension'] == 'Yes' and off['DiagramExtension'] == 'No'
assert [p['Macro'] for p in on['Probes']] == [p['Macro'] for p in off['Probes']]
assert len(on['Probes']) == 21
frozen = Path(on['SavedPrivateCandidate'])
assert sha(frozen) == on['SavedPrivateSHA256'] == off['SourceSHA256']
assert off['NoCodeImported'] and not off['Imports']
for record in on['Imports']:
    assert sha(ROOT/record['Path']) == record['SHA256'], record['Path']
counts = {}
for name, run in [('On', on), ('Off', off)]:
    counts[name] = []
    for p in run['Probes']:
        assert not re.search(r'(?mi)^(?:FAIL:|RUNTIME ERROR:)', p['Actual']), p['Macro']
        totals = re.findall(r'TOTAL[^\r\n]*?passed=(\d+);\s*failed=(\d+)', p['Actual'])
        assert totals and all(int(b) == 0 for a,b in totals), p['Macro']
        counts[name].append({'Macro': p['Macro'], 'Passed': int(totals[-1][0]), 'Failed': 0})
coverage = load('IndependentCoverageSummary.json')
for key in ('MissingActualFiles','AdditionalActualSrcFiles','UnexpectedCoverageFiles','BaselineInventoryErrors','SubstantiveCoverageBindingIssues','LineMetadataUpdatesNeeded'):
    assert not coverage[key], key
assert coverage['CurrentSrcFileCount'] == 117 and coverage['CurrentMethodCount'] == 3709
documentation = load('VbaDocumentationFinal.json')
assert not any(v for k,v in documentation.items() if k.startswith('Missing'))
preservation, equality = load('ReleasePreservation.json'), load('ReleaseSourceEquality.json')
release, dump = HERE/'ReleaseCandidate.xlsm', HERE/'ReleaseVBA.txt'
assert sha(release) == preservation['ReleaseSHA256']
assert preservation['AllUserDataFormulasStylesDrawingsNamesLinksPreserved']
assert equality['AllPassed'] and len(equality['Checks']) == 164
assert all(r['Passed'] for r in equality['GeneratedDocumentChecks'])
opened = load('ReleaseVBA.txt.ReadOnly.json')
assert opened['SourceSHA256'] == sha(release) and opened['Automatic'] and opened['ReadOnly']
cad, identity = load('NativeCADFinal16/Comparison.json'), load('NativeCADFinal16/Identity.json')
assert cad['Passed'] and identity['SourceHashes']['B'] == sha(release)
assert not identity['UserDocumentsUsed']
result = {'Status': 'DIRECTED_ACCEPTANCE_PASS', 'FullOnOffAcceptanceClaimed': False,
          'ReleaseSHA256': sha(release), 'ExportSHA256': sha(dump), 'FrozenTestBookSHA256': sha(frozen),
          'ProductionSourceImports': sum(r['Candidate'] for r in on['Imports']), 'CurrentImportHashesMatch': True,
          'GroupsPerMode': 21, 'TotalsPerMode': {k: sum(r['Passed'] for r in v) for k,v in counts.items()},
          'DirectedGroups': counts, 'NativeCADSolutions': 24, 'AllCodeMatchesSource': True,
          'UserDataAndFormattingPreserved': True, 'SavedDefaultAutomatic': True,
          'ReviewFiles': 117, 'ReviewMethods': 3709, 'UnresolvedConcreteFindings': [],
          'Limitations': ['Not the full156-suite and focused acceptance','Extreme WCS1e12 full geometry is not guaranteed','Persistent COM failure / Excel process reset cannot be recovered by VBA']}
(HERE/'FinalDirectedAcceptance.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'DirectedGroups'}, ensure_ascii=False))
