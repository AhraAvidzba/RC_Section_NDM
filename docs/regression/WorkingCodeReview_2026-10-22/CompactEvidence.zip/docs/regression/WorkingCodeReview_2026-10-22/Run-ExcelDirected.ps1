# ДЛЯ ТЕСТОВ: фактический пересчёт формул и восстановление Excel после отказов.
param([ValidateSet('Yes','No')][string]$Mode='No',[string]$Label='ExcelDirected09')
$ErrorActionPreference='Stop'
$production=@(git diff --name-only -- src)
$tests=@(git diff --name-only -- tests | Where-Object {$_ -match '\.(bas|cls)$'})+@('tests/CTestWorkflowWorkbook.cls')
& (Join-Path $PSScriptRoot 'Run-BaselineProbes.ps1') -CandidateModulePath $production -ModulePath $tests -Macro @(
 'modTestWorkbookInterface.RunTestCalculationFreshnessWorkflow',
 'modTestWorkbookInterface.RunAudit03ExcelGuardTests',
 'modTestWorkbookInterface.RunExcelGuardWorkflowTests',
 'modTestSectionRecipes.RunWorkbookRecipeInputTests'
) -Label $Label -Mode $Mode
