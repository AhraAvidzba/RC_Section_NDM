"""Строго сверяет VBA выпуска: строки/комментарии точны, числовые пары закрыты."""
from pathlib import Path
from decimal import Decimal
import importlib.util
import hashlib
import json
import subprocess
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
prior_file = HERE / 'PriorSourceVerifier.py'
spec = importlib.util.spec_from_file_location('prior_native_rules', prior_file)
rules = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rules)
rules.HERE = HERE
rules.BASE = '1c037a463bcdbd794601e47d1d77300fdc53cc60'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest().upper()
files = sorted(p for folder in ('src', 'tests') for p in (ROOT / folder).rglob('*') if p.suffix in ('.bas', '.cls'))
dump = HERE / 'ReleaseVBA.txt'
native = rules.components(dump.read_text('utf-8-sig'))
types = {name: int(kind) for name, kind in re.findall(r'^COMPONENT: ([^\r\n]+)\r?\nTYPE: (\d+)', dump.read_text('utf-8-sig'), re.M)}
legacy = rules.numeric_evidence(files, native)

# Новые пары ограничены полными операторами тестового модуля. Здесь только
# точно равные десятичные Double, без округления, допуска или изменения типа.
pairs = [
 ('TestAssertClose stats, prefix & ".coordinateDeviation", difference, 0#, GeomMax(0.000001, Abs(shift) * 0.0000000000000005)',
  'TestAssertClose stats, prefix & ".coordinateDeviation", difference, 0#, GeomMax(0.000001, Abs(shift) * 5E-16)'),
 ('coordinateTolerance = GeomMax(0.00000001, (Abs(x) + Abs(y)) * 0.0000000000000004)',
  'coordinateTolerance = GeomMax(0.00000001, (Abs(x) + Abs(y)) * 4E-16)'),
 ('deltas = Array(-2# * GEOM_TOLERANCE, -GEOM_TOLERANCE / 2#, -1E-14, 0#, 1E-14, GEOM_TOLERANCE / 2#, 2# * GEOM_TOLERANCE)',
  'deltas = Array(-2# * GEOM_TOLERANCE, -GEOM_TOLERANCE / 2#, -0.00000000000001, 0#, 0.00000000000001, GEOM_TOLERANCE / 2#, 2# * GEOM_TOLERANCE)')
]
geometry = (ROOT / 'tests/modTestGeometry.bas').read_text('utf-8-sig')
statements = lambda s: [rules.code_line(line).strip().casefold() for line in s.splitlines()]
records = []
for left, right in pairs:
    assert statements(geometry).count(left.casefold()) == 1
    assert statements(native['modTestGeometry']).count(right.casefold()) == 1
    old, new = rules.NUMBER.findall(left), rules.NUMBER.findall(right)
    assert len(old) == len(new)
    for a, b in zip(old, new):
        assert Decimal(a.rstrip('#')) == Decimal(b.rstrip('#')), (a, b)
        if a != b:
            assert ('.' in a or 'e' in a.lower()) and ('.' in b or 'e' in b.lower())
            assert not any(c in a+b for c in '@!%&^#')
    records.append({'SourceStatement': left, 'NativeStatement': right, 'ExactlyEqualDecimal': True, 'DoubleTypePreserved': True})
rules.RULES['modTestGeometry'] = pairs
literal_path = HERE / 'ReleaseSourceEquality.json'
literal = json.loads(literal_path.read_text('utf-8-sig'))
literal_backup = HERE / 'ReleaseLiteralSourceEquality.json'
if not literal_backup.exists():
    literal_backup.write_bytes(literal_path.read_bytes())
literal_checks = {r['Component']: r for r in literal['Checks']}
checks = []
comments = lambda s: [rules.audit.split_comment(line)[1] for line in s.splitlines() if rules.audit.split_comment(line)[1]]
strings = lambda s: [t for line in s.splitlines() for t in rules.LITERAL.findall(rules.audit.split_comment(line)[0])]
for path in files:
    name = path.stem
    source = rules.source_body(path.read_text('utf-8-sig'), name)
    actual = native[name]
    assert rules.canon(source, name) == rules.canon(actual, name), ('code', name)
    assert comments(source) == comments(actual), ('comments', name)
    assert strings(source) == strings(actual), ('strings', name)
    expected_type = 2 if path.suffix == '.cls' else 1
    assert types[name] == expected_type
    checks.append({'Component': name, 'SourceSHA256': sha(path), 'Type': expected_type, 'Passed': True})
baseline_dump = subprocess.check_output(['git', 'show', rules.BASE + ':workbook/output/VBA_All_Code.txt'], cwd=ROOT)
baseline = rules.components(baseline_dump.decode('utf-8-sig'))
documents = sorted(native.keys() - {p.stem for p in files})
assert len(documents) == 6
for name in documents:
    assert types[name] == 100
    assert name in baseline
    assert rules.canon(native[name]) == rules.canon(baseline[name]), ('document code', name)
    assert comments(native[name]) == comments(baseline[name])
    assert strings(native[name]) == strings(baseline[name])
events = (ROOT / 'tools/build_workbook/WorkbookHelpEvents.vba').read_text('utf-8-sig')
workbook = [n for n in documents if 'Private Sub Workbook_Open()' in native[n]]
assert len(workbook) == 1 and rules.canon(events) == rules.canon(native[workbook[0]])
assert comments(events) == comments(native[workbook[0]])
assert strings(events) == strings(native[workbook[0]])
assert len(native) == len(files) + 6
result = {'AllPassed': True, 'ActualComponents': len(native), 'RepositoryComponents': len(files), 'Checks': checks,
          'GeneratedDocumentChecks': [{'Component': n, 'Passed': True} for n in documents],
          'CommentsAndStringLiteralsExact': True, 'NoGeneralNumericRounding': True,
          'LegacyPairsWithBaselineProof': legacy['RuleCount'], 'NewExactTestPairs': records,
          'UnknownOrPerturbedNumberRejected': rules.canon('x=5E-16','modTestGeometry') != rules.canon('x=0.0000000000000006','modTestGeometry'),
          'DumpSHA256': sha(dump), 'BuildScriptSHA256': sha(ROOT / 'tools/build_workbook/Build-Workbook.ps1')}
assert result['UnknownOrPerturbedNumberRejected']
literal_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('Checks','GeneratedDocumentChecks','NewExactTestPairs')}))
