"""Готовит выпуск только VBA, побайтно сохраняя остальные части книги."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import io
import json
import re
import sys

directory = Path(__file__).resolve().parent
root = directory.parents[2]
source = root / 'workbook/output/RC_Section_NDM.xlsm'
candidate = directory / sys.argv[1]
baseline = json.loads((directory / 'Baseline.json').read_text('utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest().upper()
before = source.read_bytes()
if sha(before) != baseline['WorkbookSHA256']:
    raise SystemExit('Published user workbook changed; do not overwrite it.')
compiled = candidate.read_bytes()
with ZipFile(io.BytesIO(compiled)) as incoming:
    vba = incoming.read('xl/vbaProject.bin')
output = directory / 'ReleaseCandidate.xlsm'
if output.exists():
    raise SystemExit('Release candidate already exists; preserve previous evidence.')
with ZipFile(io.BytesIO(before)) as old, ZipFile(output, 'w') as new:
    new.comment = old.comment
    for member in old.infolist():
        data = old.read(member.filename)
        if member.filename == 'xl/vbaProject.bin':
            data = vba
        elif member.filename == 'xl/workbook.xml':
            # Единственное согласованное исключение сохранения структуры:
            # служебный Manual не должен включаться от открытия готового файла.
            data, count = re.subn(rb'(<calcPr\b[^>]*\bcalcMode=")manual(")', rb'\1auto\2', data)
            if count != 1:
                raise SystemExit('Expected exactly one saved manual calculation mode.')
        new.writestr(member, data)
checks = []
with ZipFile(io.BytesIO(before)) as old, ZipFile(output) as new:
    if old.namelist() != new.namelist():
        raise SystemExit('ZIP part inventory changed.')
    for name in old.namelist():
        a, b = old.read(name), new.read(name)
        allowed = name == 'xl/vbaProject.bin'
        if name == 'xl/workbook.xml':
            expected, count = re.subn(rb'(<calcPr\b[^>]*\bcalcMode=")manual(")', rb'\1auto\2', a)
            allowed = count == 1 and b == expected
        checks.append({'Part': name, 'BeforeSHA256': sha(a), 'AfterSHA256': sha(b), 'AuthorizedChange': allowed, 'Preserved': a == b})
    if any(not c['Preserved'] for c in checks if not c['AuthorizedChange']):
        raise SystemExit('User data or formatting changed.')
    if old.read('xl/vbaProject.bin') == new.read('xl/vbaProject.bin'):
        raise SystemExit('VBA was not updated.')
(directory / 'BaselineUserBook.xlsm').write_bytes(before)
result = {'Status': 'CODE_ONLY_PART_PRESERVATION_PASS', 'BaselineSHA256': sha(before), 'CompiledSourceSHA256': sha(compiled), 'ReleaseSHA256': sha(output.read_bytes()), 'Parts': checks, 'PreservedParts': sum(c['Preserved'] for c in checks), 'AuthorizedNonVBAChange': 'xl/workbook.xml/calcPr@calcMode: manual -> auto; all other bytes preserved', 'AllUserDataFormulasStylesDrawingsNamesLinksPreserved': True, 'Published': False}
(directory / 'ReleasePreservation.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'Parts'}))
