# ДЛЯ ТЕСТОВ: отдельное воспроизведение касательной без изменения рабочего VBA.
$ErrorActionPreference='Stop'
$production=@(git diff --name-only -- src)
& (Join-Path $PSScriptRoot 'Run-BaselineProbes.ps1') -CandidateModulePath $production -ModulePath @('docs/regression/WorkingCodeReview_2026-10-22/Geometry/modTestCornerTangentBaseline.bas') -Macro @('modTestCornerTangentBaseline.TestCornerTangentTranslation') -Label 'CornerTangent08'
