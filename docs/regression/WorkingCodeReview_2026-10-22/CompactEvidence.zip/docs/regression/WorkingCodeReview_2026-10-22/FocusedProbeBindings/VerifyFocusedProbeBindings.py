"""Read-only binding and rename-only proof for six focused acceptance VBA fragments."""
from pathlib import Path
import collections, hashlib, json, re, sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
NAMES=['FocusedAcceptanceProbe.bas','CoreRegressionBatchProbe.bas','FocusedSpecialProbe.bas','FocusedForceBounds.bas','FocusedBatch15Probe.bas','FocusedSnapshotDiagnostic.bas']
OLD=['SetSystemSetting','SetProfileValue','AssertTrue','AssertClose','AssertEquals','AppendLine','FormatNumberInvariant','FixtureRunSectionWorkflow','FixtureResetReinforcement','Audit03NormalizedLoads','Audit03CheckResultComments','Audit03CheckCapacityPath','Audit03CheckFormationPath','Audit03SaveMatrixProgress','RunPreparationReleased','MechanicalPreparationBuildCount','CrackDomainBuildCount']
LEX=re.compile(r'"(?:[^"\r\n]|"")*"|\x27[^\r\n]*|\bRem(?=\s|$)[^\r\n]*|[A-Za-z_][A-Za-z_0-9]*|\s+|.',re.M|re.I)
INVERSE={('Test'+x).lower():x for x in OLD}
TARGET={('Test'+x).lower() for x in OLD}
def code(t):
 return ''.join(' '*len(m.group()) if m.group().startswith("'") or re.match(r'^Rem(?:\s|$)',m.group(),re.I) else m.group() for m in LEX.finditer(t))
def logical(t):return re.sub(r'[ \t]+_[ \t]*\n[ \t]*',' ',code(t))
def arguments(s):
 depth=0;inside=False;parts=[];start=0;i=0
 while i<len(s):
  c=s[i]
  if c=='"':
   if inside and i+1<len(s) and s[i+1]=='"':i+=2;continue
   inside=not inside
  elif not inside:
   if c=='(':depth+=1
   elif c==')':depth-=1
   elif c==',' and depth==0:parts.append(s[start:i].strip());start=i+1
  i+=1
 if s.strip():parts.append(s[start:].strip())
 return parts
modules={'modTestBatchCalculation':ROOT/'tests/modTestBatchCalculation.bas','modTestGeometryFixtures':ROOT/'tests/modTestGeometryFixtures.bas','CBatchSectionCalculator':ROOT/'src/Batch/CBatchSectionCalculator.cls'}
declarations={}
for module,path in modules.items():
 for line in logical(path.read_text(encoding='utf-8-sig')).splitlines():
  m=re.match(r'^\s*(Public|Private|Friend)\s+(Sub|Function|Property\s+Get)\s+(\w+)\((.*)\)(.*)$',line,re.I)
  if m and m[3].lower() in TARGET:
   params=arguments(m[4]);declarations[m[3].lower()]={'Module':module,'Path':path.relative_to(ROOT).as_posix(),'Signature':line.strip(),'Kind':m[2].lower(),'Required':sum(not re.search(r'\bOptional\b',v,re.I) for v in params),'Maximum':len(params)}
assert set(declarations)==TARGET,(TARGET-set(declarations))
files=[];bindings=[]
for name in NAMES:
 path=ROOT/'tools/build_workbook'/name
 before=(HERE/(name+'.before.txt')).read_text(encoding='utf-8-sig')
 after=path.read_text(encoding='utf-8-sig')
 reverted=''.join(INVERSE.get(m.group().lower(),m.group()) for m in LEX.finditer(after))
 assert reverted==before,(name,'non-rename edit')
 text=logical(after)
 for line_no,line in enumerate(text.splitlines(),1):
  tokens=list(LEX.finditer(line))
  for token in tokens:
   key=token.group().lower()
   if key not in TARGET:continue
   decl=declarations[key];tail=line[token.end():].lstrip();count=0;receiver=''
   if decl['Kind']=='property get':
    recv=re.search(r'(\w+)\s*\.\s*$',line[:token.start()]);assert recv,(name,line_no,key)
    receiver=recv[1];assert receiver.lower()=='mfocusedbatch',(name,line_no,receiver)
   else:
    if tail.startswith('('):
     depth=0;inside=False;end=None;i=0
     while i<len(tail):
      c=tail[i]
      if c=='"':
       if inside and i+1<len(tail) and tail[i+1]=='"':i+=2;continue
       inside=not inside
      elif not inside:
       if c=='(':depth+=1
       elif c==')':
        depth-=1
        if depth==0:end=i;break
      i+=1
     assert end is not None,(name,line_no,key)
     params=tail[1:end]
    else:
     depth=0;inside=False;end=len(tail);i=0
     while i<len(tail):
      c=tail[i]
      if c=='"':
       if inside and i+1<len(tail) and tail[i+1]=='"':i+=2;continue
       inside=not inside
      elif not inside:
       if c=='(':depth+=1
       elif c==')':depth-=1
       elif c==':' and depth==0:end=i;break
      i+=1
     params=tail[:end]
    count=len(arguments(params))
   assert decl['Required']<=count<=decl['Maximum'],(name,line_no,key,count,decl)
   bindings.append({'File':name,'LogicalLine':line_no,'Name':token.group(),'Owner':decl['Module'],'ArgumentCount':count,'Receiver':receiver,'ArgumentCountMatches':True})
 files.append({'Path':path.relative_to(ROOT).as_posix(),'SHA256':hashlib.sha256(path.read_bytes()).hexdigest().upper(),'StrictFullTextAfterInverseRenames':True,'NoStringCommentLiteralChange':True})
assert len(bindings)==181,len(bindings)
# The full historical rename map is applied read-only with declaration/type inference.
# Existing working members (state.Converged, section.ConcreteArea, provider.Initialize)
# are resolved by receiver and are intentionally left unchanged.
sys.path.insert(0,str(ROOT/'docs/regression/HelpCommentReview_2026-10-22'))
import RenameTests as rename
plan=json.loads((ROOT/'docs/regression/HelpCommentReview_2026-10-22/TestRenamePlan.json').read_text(encoding='utf-8-sig'))
maps={m.lower():{old.lower():new for old,new in entries.items()} for m,entries in plan['Methods'].items()}
returns={}
for folder in ['src','tests']:
 for member_path in (ROOT/folder).rglob('*'):
  if member_path.suffix not in ('.bas','.cls'):continue
  for declaration in logical(member_path.read_text(encoding='utf-8-sig')).splitlines():
   decl=re.match(r'^\s*(?:(?:Public|Private|Friend)\s+)?(?:Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)\(.*\)\s+As\s+(\w+)',declaration,re.I)
   if decl:returns[(member_path.stem.lower(),decl[1].lower())]=decl[2]
rename.CLASS_MEMBER_MODULES={p.stem for d in ['src','tests'] for p in (ROOT/d).rglob('*.cls') if p.stem.lower() in maps}
public={}
for module,path in modules.items():
 if path.suffix!='.bas':continue
 current=path.read_text(encoding='utf-8-sig')
 for old,new in plan['Methods'].get(module,{}).items():
  if re.search(r'^\s*Public\s+(Sub|Function)\s+'+re.escape(new)+r'\b',current,re.M|re.I):public[old.lower()]=new
unique={} # Direct receiver/module binding is required; no ambiguous member-name fallback.
leftovers=[];unresolved=[]
for name in NAMES:
 text=(ROOT/'tools/build_workbook'/name).read_text(encoding='utf-8-sig')
 for start,end,method in rename.spans(text):
  transformed,logs=rename.transform_scope(text[start:end],'modTestBatchCalculation',maps['modtestbatchcalculation'],maps,public,returns,{'mfocusedbatch':'CBatchSectionCalculator','mfocusedsection':'CSectionModel','mfocusedbinarydump':'Boolean'},unique,unresolved)
  if transformed!=text[start:end]:leftovers.append({'File':name,'Method':method,'Changes':logs})
assert not leftovers,leftovers
assert not unresolved,unresolved
report={'Status':'STATIC_BINDING_SIGNATURE_ARITY_AND_RENAME_ONLY_PASS','NativeCompilation':'Not executed here; root owns Excel native preflight','Files':files,'BindingCount':len(bindings),'DeclaredTargetCount':len(declarations),'ActualTargetSignatures':declarations,'Bindings':bindings,'CompleteHistoricalRenameMapRemainingChanges':leftovers,'UnresolvedRenameReceivers':unresolved,'StrictFullTextAfterInverseRenames':True,'FormulaInputsExpectationsStringsCommentsUnchanged':True,'ProbeEntryPointsAndCaptureHookNamesUnchanged':True,'PrivateHelpersAccessibleBecauseFragmentsInjectedIntoModTestBatchCalculation':True,'WorkingVbaWorkbookExcelNotTouched':True}
report['Limits']=['This is a complete historical rename-map/target-signature/arity audit, not an independent VBA compiler.','Legacy FocusedBatch15Probe requires RunSavedCrackSearchProbe from a historical helper outside the current chain; that helper is absent in this workspace. No numerical fixture or historical scenario was recreated.']
report['LegacyExternalDependency']={'Probe':'FocusedBatch15Probe.bas','Symbol':'RunSavedCrackSearchProbe','ExpectedByPS':'docs/regression/PostAudit03/Axial1000_2026-10-09/SavedCrackSearchProbe.bas','Exists':(ROOT/'docs/regression/PostAudit03/Axial1000_2026-10-09/SavedCrackSearchProbe.bas').exists(),'CurrentFullChainUsesLegacyProbe':False,'NoUnapprovedRepairAttempted':True}
preflight=ROOT/'docs/regression/WorkingCodeReview_2026-10-22/FocusedPreflight18/Probe/Preparation.json'
if preflight.exists():
 preparation=json.loads(preflight.read_text(encoding='utf-8-sig'))
 assert preparation['Compiled'] is True
 assert preparation['HelperSHA256'].upper()==files[0]['SHA256']
 combined=preflight.parent.parent/'Combined.bas'
 expected='\n'.join((ROOT/'tools/build_workbook'/n).read_text(encoding='utf-8-sig') for n in NAMES[1:4])
 assert combined.read_text(encoding='utf-8-sig')==expected
 report['NativeMainFourCompilation']={'Evidence':preflight.relative_to(ROOT).as_posix(),'SHA256':hashlib.sha256(preflight.read_bytes()).hexdigest().upper(),'Compiled':True,'FourHelperFilesBoundToCurrentContent':True,'CalculationExecuted':preparation['CalculationExecuted'],'ProductionChanged':preparation['ProductionChanged'],'SourceWorkbookSHA256':preparation['SourceSHA256']}
(HERE/'ProbeHelperBindingAudit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'Status':report['Status'],'BindingCount':len(bindings),'TargetCount':17,'RemainingRenameChanges':0,'UnresolvedReceivers':0},ensure_ascii=False))
