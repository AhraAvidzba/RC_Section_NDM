# Запускает явно разрешённую полную приёмку только после успешного push выпуска.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$source=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$expected='A3F2F4544820CB684139D25C8DA452A439B2AEBAE99B34A2570F422CA3D9C200'
if((Get-FileHash -LiteralPath $source).Hash -cne $expected){throw 'Published workbook changed.'}
$commit=(& git -C $root rev-parse HEAD)
$upstream=(& git -C $root rev-parse '@{upstream}')
if($commit -cne $upstream){throw 'Commit is not confirmed in the upstream tracking branch.'}
$record=Join-Path $PSScriptRoot 'FullLaunch.json'
if(Test-Path -LiteralPath $record){throw 'Launch already recorded; do not restart automatically.'}
$evidence='docs/regression/FullOnOff_2026-10-23_WorkingCodeReview_Run01'
if(Test-Path -LiteralPath (Join-Path $root $evidence)){throw 'Full evidence directory already exists.'}
$active=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*Run-FullOnOffAcceptance.ps1*'})
if($active.Count){throw 'A full driver is already running; inspect its identity before starting another.'}
function Quote([string]$text){if($text.Contains('"')){throw 'Invalid quote in process argument.'};return '"'+$text+'"'}
$python=Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$sourceProof=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ReleaseSourceEquality.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$inputProof=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'FocusedPreflight18/Probe/InputManifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if(-not $sourceProof.AllPassed -or -not $inputProof.Passed -or $inputProof.SourceSHA256 -cne $expected){throw 'Final source/focused preflight proof is incomplete.'}
$sourceFiles=@($sourceProof.Checks | ForEach-Object {
 $file=Join-Path $root ('src/'+$_.Component)
 [ordered]@{Component=$_.Component;SHA256=$_.SourceSHA256}
})
$scriptNames=@('Run-FullOnOffAcceptance.ps1','Run-Audit03Watchdog.ps1','Run-Audit02ModeTests.ps1','Run-FocusedAcceptance.ps1','Prepare-FocusedAcceptance.ps1','Describe-FocusedAcceptance.ps1','FocusedAcceptanceProbe.bas','CoreRegressionBatchProbe.bas','FocusedSpecialProbe.bas','FocusedForceBounds.bas','Run-FocusedNativeAcceptance.ps1','Run-PostAudit03NativeCAD.ps1','Verify-FocusedAcceptance.py','Test-FocusedAcceptanceVerifier.py','Summarize-FullOnOffAcceptance.py','Finalize-CompleteAcceptance.py','SettingsCatalog.ps1','Verify-PostAudit03VbaEquality.ps1','fixtures/FocusedSavedSection.json')
$scriptProof=@($scriptNames | ForEach-Object {[ordered]@{Path=('tools/build_workbook/'+$_);SHA256=(Get-FileHash -LiteralPath (Join-Path $root ('tools/build_workbook/'+$_))).Hash}})
$stdout=Join-Path $PSScriptRoot 'FullLaunch.stdout.log';$stderr=Join-Path $PSScriptRoot 'FullLaunch.stderr.log'
$args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Quote (Join-Path $root 'tools/build_workbook/Run-FullOnOffAcceptance.ps1')),
 '-SourceWorkbook',(Quote $source),'-EvidenceDirectory',(Quote $evidence),'-Deadline','2026-10-23T10:00:00+03:00','-ForecastHours','5','-Python',(Quote $python)) -join ' '
$process=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $args -WorkingDirectory $root -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
[ordered]@{Started=[DateTimeOffset]::Now.ToString('o');PID=$process.Id;ProcessStartTicks=$process.StartTime.ToUniversalTime().Ticks;
 EvidenceDirectory=$evidence;SourceSHA256=$expected;SourceCommit=$commit;Deadline='2026-10-23T10:00:00+03:00';ForecastHours=5;Python=$python;Stdout=$stdout;Stderr=$stderr;
 Authorization='User explicitly requested full runs after fixes and push in the same goal, with correction of discrepancies';ExpectedCoreSuites=156;
 ExpectedFocused='122 single cases, batch15, stability, asymmetric steel, real AutoCAD, independent NDS';ParticipatingScripts=$scriptProof;SourceComponents=$sourceFiles} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $record -Encoding UTF8
Write-Output ('FULL_DRIVER_STARTED: PID='+$process.Id+'; utcStartTicks='+$process.StartTime.ToUniversalTime().Ticks+'; sourceCommit='+$commit)
