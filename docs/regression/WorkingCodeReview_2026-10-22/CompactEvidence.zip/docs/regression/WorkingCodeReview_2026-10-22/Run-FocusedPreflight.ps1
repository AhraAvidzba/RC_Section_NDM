# ДЛЯ ТЕСТОВ: компиляция всех focused probes и описание входов без решения НДС.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$relative='docs/regression/WorkingCodeReview_2026-10-22/FocusedPreflight18'
$directory=Join-Path $root $relative
if(Test-Path -LiteralPath $directory){throw 'Preflight evidence already exists.'}
[void][IO.Directory]::CreateDirectory($directory)
$helpers=@('CoreRegressionBatchProbe.bas','FocusedSpecialProbe.bas','FocusedForceBounds.bas')
$body=($helpers | ForEach-Object {[IO.File]::ReadAllText((Join-Path $root ('tools/build_workbook/'+$_)),[Text.Encoding]::UTF8)}) -join "`r`n"
[IO.File]::WriteAllText((Join-Path $directory 'Combined.bas'),$body,[Text.UTF8Encoding]::new($true))
& (Join-Path $root 'tools/build_workbook/Prepare-FocusedAcceptance.ps1') -SourceWorkbook 'workbook/output/RC_Section_NDM.xlsm' -OutputDirectory ($relative+'/Probe') -ExtraHelperFile ('../../'+$relative+'/Combined.bas') -SavedFixture (Join-Path $root 'tools/build_workbook/fixtures/FocusedSavedSection.json')
& (Join-Path $root 'tools/build_workbook/Describe-FocusedAcceptance.ps1') -ProbeDirectory ($relative+'/Probe')
$python=Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
& $python (Join-Path $root 'tools/build_workbook/Test-FocusedAcceptanceVerifier.py')
if($LASTEXITCODE -ne 0){throw 'Focused verifier controls failed.'}
