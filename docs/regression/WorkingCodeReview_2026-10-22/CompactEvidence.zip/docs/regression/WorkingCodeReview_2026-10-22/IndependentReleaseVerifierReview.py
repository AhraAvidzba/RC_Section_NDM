"""Read-only независимая проверка strict verifier и фактического ReleaseVBA.

Не запускает VerifyReleaseSources.py и не перезаписывает его отчеты.
TYPE берется непосредственно из заголовков фактического native dump.
"""
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
import ast,hashlib,importlib.util,json,re,subprocess

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
prior_file=ROOT/'docs/regression/HelpCommentReview_2026-10-22/VerifyNative.py'
spec=importlib.util.spec_from_file_location('prior_readonly_review',prior_file)
rules=importlib.util.module_from_spec(spec);spec.loader.exec_module(rules)
current_verifier=HERE/'VerifyReleaseSources.py'
tree=ast.parse(current_verifier.read_text(encoding='utf-8-sig'))
pairs=next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='pairs' for t in node.targets))
assert len(pairs)==3
legacy_rules={k:list(v) for k,v in rules.RULES.items()}
assert set(legacy_rules)=={'CLoadPathMath','CLinearSystem3x3','modNonlinearStepControl','CLoadMultiplierSearch','CUltimateStrainSearch','CCrackFormationCalculator','CStabilityCalculator'}
rules.RULES['modTestGeometry']=pairs
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
dump_path=HERE/'ReleaseVBA.txt';dump=dump_path.read_text(encoding='utf-8-sig');native=rules.components(dump)
types={m[1]:int(m[2]) for m in re.finditer(r'(?m)^COMPONENT: ([^\r\n]+)\r?\nTYPE: (\d+)\r?$',dump)}
assert len(types)==len(native)==170
files=sorted(p for d in ('src','tests') for p in (ROOT/d).rglob('*') if p.suffix in ('.cls','.bas'))
comments=lambda s:[rules.audit.split_comment(line)[1]for line in s.splitlines()if rules.audit.split_comment(line)[1]]
strings=lambda s:[t for line in s.splitlines()for t in rules.LITERAL.findall(rules.audit.split_comment(line)[0])]
def equal(left,right,module=''):
 return rules.canon(left,module)==rules.canon(right,module) and comments(left)==comments(right) and strings(left)==strings(right)
statements=lambda s:[rules.code_line(line).strip().casefold()for line in s.splitlines()]
baseline='1c037a463bcdbd794601e47d1d77300fdc53cc60'
old_dump=subprocess.check_output(['git','show',baseline+':workbook/output/VBA_All_Code.txt'],cwd=ROOT).decode('utf-8-sig')
old_native=rules.components(old_dump);legacy=[]
for module,known in legacy_rules.items():
 path=next(p for p in files if p.stem==module)
 old_source=subprocess.check_output(['git','show',baseline+':'+path.relative_to(ROOT).as_posix()],cwd=ROOT).decode('utf-8-sig')
 current_source=path.read_text(encoding='utf-8-sig')
 for left,right in known:
  for text,expected in ((old_source,left),(current_source,left),(old_native[module],right),(native[module],right)):
   assert statements(text).count(expected.casefold())==1,(module,expected)
  legacy.append({'Module':module,'SourceStatement':left,'NativeStatement':right,'SamePairInPublishedC31BaselineAndCurrent':True})
new=[]
for left,right in pairs:
 source=(ROOT/'tests/modTestGeometry.bas').read_text(encoding='utf-8-sig')
 assert statements(source).count(left.casefold())==1
 assert statements(native['modTestGeometry']).count(right.casefold())==1
 a,b=rules.NUMBER.findall(left),rules.NUMBER.findall(right)
 assert len(a)==len(b)
 differences=[]
 for x,y in zip(a,b):
  assert Decimal(x.rstrip('#'))==Decimal(y.rstrip('#')),(x,y)
  if x!=y:
   assert not any(c in x+y for c in '#!@%&^')
   assert ('.'in x or'e'in x.lower())and('.'in y or'e'in y.lower())
   assert float(x)==float(y)
   differences.append({'Source':x,'Native':y,'ExactDecimalEqual':True,'SameBinary64Conversion':True,'NoTypeSuffixChanged':True})
 assert differences
 new.append({'SourceStatement':left,'NativeStatement':right,'Differences':differences})
checks=[]
for p in files:
 expected=2 if p.suffix=='.cls' else 1
 assert types[p.stem]==expected,('actual native type',p.stem,types[p.stem],expected)
 assert equal(rules.source_body(p.read_text(encoding='utf-8-sig'),p.stem),native[p.stem],p.stem),p.stem
 checks.append({'Component':p.stem,'ActualNativeType':types[p.stem],'SourceSHA256':sha(p),'Passed':True})
docs=sorted(set(native)-{p.stem for p in files})
assert len(docs)==6
for name in docs:
 assert types[name]==100,(name,types[name])
 assert name in old_native and equal(native[name],old_native[name]),name
events=(ROOT/'tools/build_workbook/WorkbookHelpEvents.vba').read_text(encoding='utf-8-sig')
books=[n for n in docs if 'Private Sub Workbook_Open()'in native[n]]
assert len(books)==1 and equal(events,native[books[0]]),('exact events',books)
negative={
 'OtherModuleDoesNotAcceptNewSpelling':all(not equal(left,right,'Unrelated')for left,right in pairs),
 'UnknownContextDoesNotAcceptNewSpelling':not equal('x=0.0000000000000005','x=5E-16','modTestGeometry'),
 'PerturbedKnownOperatorRejected':not equal(pairs[0][0],pairs[0][1].replace('5E-16','6E-16'),'modTestGeometry'),
 'SingleSuffixRejected':not equal(pairs[0][0],pairs[0][1].replace('5E-16','5E-16!'),'modTestGeometry'),
 'IntegerDoubleMarkerPreserved':not equal('x=1#','x=1','modTestGeometry'),
 'NumericStringCaseStillExact':not equal('x="A5E-16"','x="a5E-16"','modTestGeometry'),
 'KnownOperatorStringCaseStillExact':not equal(pairs[0][0],pairs[0][1].replace('coordinateDeviation','coordinateDeviatioN'),'modTestGeometry'),
 'NumericTextInCommentStillExact':not equal("x=1 '5E-16","x=1 '0.0000000000000005",'modTestGeometry'),
 'MaxDoubleUnknownContextRejected':not equal('x=1.797693134862315E+308','x=1.79769313486231E+308','CStabilityCalculator'),
 'MaxDoubleOtherModuleRejected':not equal(legacy_rules['CStabilityCalculator'][0][0],legacy_rules['CStabilityCalculator'][0][1],'Unrelated'),
}
assert all(negative.values()),negative
result={'AsOfUTC':datetime.now(timezone.utc).isoformat(),'ReadOnly':True,'VerifierSHA256':sha(current_verifier),'PriorVerifierPath':prior_file.relative_to(ROOT).as_posix(),'PriorVerifierSHA256':sha(prior_file),'NativeDumpSHA256':sha(dump_path),'RepositoryComponents':len(files),'DocumentComponents':len(docs),'TotalActualComponents':len(native),'TypeSource':'TYPE headers parsed directly from actual ReleaseVBA, not from a previously generated equality report','AllActualTypesMatch':True,'AllCodeCommentsStringsExactUnderClosedRules':True,'WorkbookHelpEventsCodeCommentsStringsExact':True,'LegacyRulesCount':len(legacy),'LegacyBaseline':baseline,'LegacyRecords':legacy,'MaxDoubleCaveat':'Четыре старые maxDouble source/native пары не равны как Decimal. Разрешены только те же полные операторы в тех же модулях, уже существовавшие в C31; никакого нового округления или числовой эквивалентности не заявлено.','NewExactTestOperatorCount':len(new),'NewExactTestOperators':new,'NegativeControls':negative,'Checks':checks,'OverallFullOnOffPassClaimed':False}
(HERE/'IndependentReleaseVerifierReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k]for k in ('RepositoryComponents','DocumentComponents','TotalActualComponents','AllActualTypesMatch','AllCodeCommentsStringsExactUnderClosedRules','WorkbookHelpEventsCodeCommentsStringsExact','LegacyRulesCount','NewExactTestOperatorCount')}))
