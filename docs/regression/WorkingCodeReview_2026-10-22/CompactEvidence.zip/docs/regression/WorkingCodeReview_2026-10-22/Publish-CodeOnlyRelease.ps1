# Публикует проверенный VBA без изменения данных/оформления или чужих output-файлов.
# Блокировка книги не закрывает пользовательский Excel: занятый файл вызывает отказ.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
function Hash([string]$path){(Get-FileHash -LiteralPath $path).Hash}
function BytesHash([byte[]]$bytes){$s=[Security.Cryptography.SHA256]::Create();try{[BitConverter]::ToString($s.ComputeHash($bytes)).Replace('-','')}finally{$s.Dispose()}}
function ReadBytes($stream){$buffer=New-Object IO.MemoryStream;try{$stream.Position=0;$stream.CopyTo($buffer);return ,$buffer.ToArray()}finally{$buffer.Dispose()}}
function WriteBytes($stream,[byte[]]$bytes){$stream.Position=0;$stream.SetLength(0);$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}
$baseline=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Baseline.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$preserved=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ReleasePreservation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$source=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ReleaseSourceEquality.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$gate=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'FinalDirectedAcceptance.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$candidate=Join-Path $PSScriptRoot 'ReleaseCandidate.xlsm';$dump=Join-Path $PSScriptRoot 'ReleaseVBA.txt'
if($preserved.Status -ne 'CODE_ONLY_PART_PRESERVATION_PASS' -or -not $source.AllPassed -or $gate.Status -ne 'DIRECTED_ACCEPTANCE_PASS') {throw 'Publication evidence is incomplete.'}
if((Hash $candidate) -cne $preserved.ReleaseSHA256 -or (Hash $candidate) -cne $gate.ReleaseSHA256 -or (Hash $dump) -cne $gate.ExportSHA256){throw 'Reviewed artifacts changed.'}
foreach($check in $source.Checks){
 $files=@(Get-ChildItem -LiteralPath (Join-Path $root 'src'),(Join-Path $root 'tests') -Recurse -File | Where-Object BaseName -ceq $check.Component)
 if($files.Count -ne 1 -or (Hash $files[0].FullName) -cne $check.SourceSHA256){throw ('Source changed after equality proof: '+$check.Component)}
}
$output=Join-Path $root 'workbook/output';$target=Join-Path $output 'RC_Section_NDM.xlsm';$targetDump=Join-Path $output 'VBA_All_Code.txt'
$foreign=@(Get-ChildItem -LiteralPath $output -Recurse -File | Where-Object FullName -notin @($target,$targetDump) | ForEach-Object {[ordered]@{Path=$_.FullName.Substring($root.Length+1);SHA256=Hash $_.FullName}})
$bookStream=$null;$dumpStream=$null;$written=$false
try{
 $bookStream=[IO.File]::Open($target,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 $dumpStream=[IO.File]::Open($targetDump,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 [byte[]]$oldBook=ReadBytes $bookStream;[byte[]]$oldDump=ReadBytes $dumpStream
 if((BytesHash $oldBook) -cne $baseline.WorkbookSHA256 -or (BytesHash $oldDump) -cne $baseline.AllCodeSHA256){throw 'User output changed after baseline; do not overwrite.'}
 $backup=Join-Path $PSScriptRoot 'PublicationBackup'
 if(Test-Path -LiteralPath $backup){throw 'Publication backup already exists.'}
 [void][IO.Directory]::CreateDirectory($backup)
 [IO.File]::WriteAllBytes((Join-Path $backup 'RC_Section_NDM.xlsm'),$oldBook)
 [IO.File]::WriteAllBytes((Join-Path $backup 'VBA_All_Code.txt'),$oldDump)
 $written=$true
 WriteBytes $bookStream ([IO.File]::ReadAllBytes($candidate));WriteBytes $dumpStream ([IO.File]::ReadAllBytes($dump))
 if((BytesHash (ReadBytes $bookStream)) -cne $preserved.ReleaseSHA256 -or (BytesHash (ReadBytes $dumpStream)) -cne $gate.ExportSHA256){throw 'Published bytes differ.'}
 foreach($item in $foreign){if((Hash (Join-Path $root $item.Path)) -cne $item.SHA256){throw ('Foreign output changed during publication: '+$item.Path)}}
}catch{
 if($written){WriteBytes $bookStream $oldBook;WriteBytes $dumpStream $oldDump}
 throw
}finally{
 if($dumpStream){$dumpStream.Dispose()};if($bookStream){$bookStream.Dispose()}
}
[ordered]@{Status='CODE_ONLY_PUBLISHED';UTC=(Get-Date).ToUniversalTime().ToString('o');WorkbookSHA256=Hash $target;ExportSHA256=Hash $targetDump;AllUserDataFormulasStylesNamesDrawingsPreserved=$true;SavedCalculationDefaultAutomatic=$true;AuthorizedNonVBAChange='calcPr@calcMode manual -> auto';ForeignOutputsPreserved=$true;ForeignOutputs=$foreign;SourceCommitBeforeAudit=(& git -C $root rev-parse HEAD);FullOnOffRun=$false} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Publication.json') -Encoding UTF8
Write-Output ('CODE_ONLY_PUBLISHED: '+(Hash $target))
