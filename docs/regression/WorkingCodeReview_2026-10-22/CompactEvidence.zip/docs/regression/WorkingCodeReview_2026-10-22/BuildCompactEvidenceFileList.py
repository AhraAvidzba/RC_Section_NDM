"""Готовит только список компактного архива; не копирует книги и не создает ZIP.

Запускать после финального агрегатора. Private XLSM, NormText и старые большие
harness-копии остаются локально. Их хэши/статусы доступны в компактной selection.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
parser=argparse.ArgumentParser()
parser.add_argument('--final',action='store_true',help='Root подтвердил окончательный freeze; не означает общий PASS.')
parser.add_argument('--additional-file',action='append',default=[],help='Например итоговый docs/reports/...md или компактный release/preservation proof.')
args=parser.parse_args()

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(name,obj):(HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

files={}
def add(rel,role,required=True):
 p=HERE/rel
 if p.exists():files[p.resolve()]=role
 elif required:missing.append(rel)
missing=[]
for rel in ('Baseline.json','Inventory.json','RootCoverage.json','IndependentCoverageSummary.json','SelectedNativeEvidence.json'):
 add(rel,'Текущая опись, полная reviewer coverage и независимая привязка к исходникам/native evidence')
for rel in ('IndependentReviewSummary.py','BuildCompactEvidenceFileList.py','Run-BaselineProbes.ps1','Run-FinalDirected.ps1','Run-ExcelDirected.ps1','Test-OwnedCADRoundoff.ps1','Export-OwnedVbaSnapshot.ps1'):
 add(rel,'Небольшой воспроизводимый orchestration/summary script; рабочий код не заменяет')
for rel in ('Initial_Probes.json','Geometry_Probes.json','CrackTranslation_Probes.json','MaterialAndAnnotationBaseline_Probes.json','SP35AndInertiaBaseline_Run03_Probes.json','ConcreteAddStateBaseline_Probes.json','HugeWCSAndControlledBaseline_Probes.json','OptionalNumberBaseline13_Probes.json','MultiAreaBaseline12_Probes.json'):
 add(rel,'Точное небольшое baseline/closure evidence для подтвержденных или отклоненных гипотез',False)
for rel in ('FinalDirected14_Probes.json','FinalFrozen15_Probes.json','ReleasePreservation.json','ReleaseLiteralSourceEquality.json','ReleaseSourceEquality.json','ReleaseVBA.txt','VerifyReleaseSources.py','IndependentReleaseVerifierReview.py','IndependentReleaseVerifierReview.json','VbeNumericCanonicalization.json'):
 add(rel,'Финальные21-групповые ON/OFF на одном SHA; строгая native/source сверка и сохранение110частей пользовательской книги')
prior=ROOT/'docs/regression/HelpCommentReview_2026-10-22/VerifyNative.py'
if not prior.is_file():missing.append(prior.relative_to(ROOT).as_posix())
else:files[prior.resolve()]='Необходимая явная зависимость VerifyReleaseSources: прежние7строгих полных операторов, без общего округления'
for p in HERE.glob('*Acceptance*.json'):files[p.resolve()]='Итоговая ограниченная directed acceptance от root, не общий полный ON/OFF PASS'
for p in HERE.glob('*Publication*.json'):files[p.resolve()]='Фактическая публикация root с точным итоговым SHA'

math_files=('MathCoverage.json','NormReview.json','Findings.json','EdgeCasePlan.json','MathSourceScopeProof.json','MathTestScopeProof.json','NativeMathDirectedSummary.json','MaterialFixturePreflight.json','OtherWorkingDiffNormReview.json','JointStationContractProposal.json','OptionalSnapshotContractReview.json','FinalReportSection.md','ApprovedMathChanges.patch','BuildMathEvidence.py','BuildMathReviewSummary.py','CheckOtherDiffNormScope.py','modTestOptionalNumberProbe.bas')
for name in math_files:add('Math/'+name,'Math: охват, согласования, нормативная сверка, точный scope и regression evidence')
for rel in ('Math/Proposals/LinearSystemNonFinite.json','Math/Proposals/MaterialLimitOrderProposal.json'):
 add(rel,'История решения: отклоненная NaN-гипотеза или подтвержденный material-order defect')

geometry_files=('ReviewCoverage.json','Findings.json','TestPlan.json','ApprovedCoreInertiaNativeResult.json','AddConcreteAtomicCountFix.json','AddConcreteFailureStateReview.json','AddConcreteNativeBaselineManifest.json','MeshFailureStateFix.json','AreaLocalOriginFix.json','AreaNativeDirected07.json','NumericalInvariantReproduction.json','CornerTangentTranslationReview.json','CornerJointRegressionPlan.json')
for name in geometry_files:add('Geometry/'+name,'Geometry: охват, algebraic changes, исходный corner FAIL и его согласование/повтор',False)
# Новые компактные итоговые corner fix proofs могут появиться после составления плана.
for p in (HERE/'Geometry').glob('*Corner*Fix*.json'):files[p.resolve()]='Geometry: окончательный approved corner fix proof'

excel_files=('Coverage.json','Findings.json','EdgeCasePlan.json','SourceVerification.json','CacheSecondReview.json','GuardLifecycleAudit.json','SavedCalculationPolicy.json','NativeFreshnessAcceptance.json','AnnotationBenchmarkComparison.json','DocumentationAudit.json')
for name in excel_files:add('Excel/'+name,'Excel: актуальная политика чтения, coverage, надежность и ограничения производительности',False)

for folder in ('NativeCAD09','NativeCADFinal16'):
 for name in ('Identity.json','Comparison.json','Measurements.json'):
  add(folder+'/'+name,'Настоящий CAD: источники C31/C88 или окончательный releaseA3, собственные процессы и directed numerical comparison',False)
 for p in (HERE/folder).glob('*.txt'):files[p.resolve()]='Настоящий CAD: компактная подпись геометрии/расчетных полей для24 solutions'

audit=HERE/'VbaDocumentationFinal.json'
if audit.exists():
 data=load(audit)
 summary={k:v for k,v in data.items() if k!='Files'}
 summary['OriginalEvidence']='VbaDocumentationFinal.json';summary['OriginalSHA256']=sha(audit)
 summary['FullPerFileRecordsOmitted']=len(data.get('Files',[]))
 summary['Meaning']='Содержит все итоговые счетчики и замечания исходного аудита; массив Files остается локально, подробный reviewer coverage архивируется отдельно.'
 write('VbaDocumentationFinalSummary.json',summary)
 add('VbaDocumentationFinalSummary.json','Итоговый аудит шапок/Test-имен без многомегабайтных повторов всех комментариев')

for rel in args.additional_file:
 p=(ROOT/rel).resolve()
 if not p.is_relative_to(ROOT):raise ValueError(('Outside repository',rel))
 if not p.exists():missing.append(rel)
 else:files[p]='Добавленный root итоговый отчет/release/preservation proof'

selected=[]
for p,role in sorted(files.items(),key=lambda x:x[0].as_posix()):
 rel=p.relative_to(ROOT).as_posix()
 if p.suffix.lower() in ('.xlsm','.xlsx','.xlsb','.xls') or 'NormText' in p.parts:raise AssertionError(('Forbidden archive input',rel))
 selected.append({'Path':rel,'Bytes':p.stat().st_size,'SHA256':sha(p),'Purpose':role})

omitted=[]
for p in HERE.glob('*_Probes.json'):
 if p.resolve() not in files:
  d=load(p)
  omitted.append({'Path':p.relative_to(ROOT).as_posix(),'Bytes':p.stat().st_size,'SHA256':sha(p),'Status':d.get('Status'),'Reason':'Подробные repeated OK-строки не архивируются; Import SHA, totals, все FAIL и статус сохранены в SelectedNativeEvidence.json. Исходный JSON остается локально.'})

manifest={'AsOfUTC':datetime.now(timezone.utc).isoformat(),'Status':'FINAL_FILE_SELECTION_ROOT_CONFIRMED_FREEZE' if args.final else 'DRAFT_REPEAT_AFTER_FINAL_FREEZE','Files':selected,'FileCount':len(selected),'TotalUncompressedBytes':sum(f['Bytes']for f in selected),'MissingRequiredFiles':missing,'RawEvidenceKeptLocally':omitted,'ExplicitExclusions':['Все приватные XLSM/XLSX/XLSB и пользовательские книги','Math/NormText PDF derivatives и PNG','Старые крупные harness-копии Geometry/modTestWorkingGeometryReview.bas и исходные *_Pre*.txt','Неактивный отвергнутый LinearSystemNonFinite.patch и его старый proposal-module','Многомегабайтные полные repeated-OK native logs; их компактные проверяемые summaries сохраняются'],'TrackedRepositoryDependenciesNotDuplicated':['Текущие src/ и tests/ из коммита','norms/ PDF по хэшам NormReview.json','tools/build_workbook/Compare-CADKernelEvidence.py','Root финальный отчет и release/preservation proof добавить через --additional-file перед ZIP'],'NoArchiveCreated':True,'NoWorkbookIncluded':True,'OverallPassClaimed':False}
write('CompactArchiveFiles.json',manifest)
(HERE/'CompactArchivePaths.txt').write_text('\n'.join(f['Path']for f in selected)+'\n',encoding='utf-8')
print(json.dumps({'Files':len(selected),'Bytes':manifest['TotalUncompressedBytes'],'Missing':missing,'Status':manifest['Status']},ensure_ascii=False))
assert not missing,missing
