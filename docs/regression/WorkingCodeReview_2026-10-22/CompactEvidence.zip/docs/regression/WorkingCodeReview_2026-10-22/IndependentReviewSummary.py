"""Независимая read-only сверка описи, coverage и уже сохраненного native evidence.

Не открывает Excel/AutoCAD, не запускает VBA, не меняет coverage владельцев.
Пишет только компактные сводки в ignored каталоге доказательств.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib, json, re, subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
BASE='1c037a463bcdbd794601e47d1d77300fdc53cc60'
NOW=datetime.now(timezone.utc).isoformat()
DECL=re.compile(r'^\s*(?:(?:Public|Private|Friend|Static)\s+)*(Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)\b',re.I)

def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def write(name,obj): (HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def method_key(m): return (m['Name'].casefold(),re.sub(r'\s+',' ',m['Kind']).casefold())

def frozen_binding(data):
    """Привязывает run без импорта к доказанному SHA256 сохраненного кандидата."""
    if not data.get('NoCodeImported'):
        return None
    failures=[];proof_path=(HERE/str(data.get('FrozenSourceProof',''))).resolve()
    source_path=(ROOT/str(data.get('FrozenSource',''))).resolve()
    if not proof_path.is_relative_to(HERE) or not proof_path.is_file():failures.append('FrozenSourceProof path invalid')
    if not source_path.is_relative_to(ROOT) or not source_path.is_file():failures.append('FrozenSource path invalid')
    proof=load(proof_path) if not failures else {}
    if proof.get('Status')!='PROBES_COMPLETED':failures.append('Source proof not completed')
    if not proof.get('PrivateCandidateImported'):failures.append('Source proof lacks explicit candidate import')
    if data.get('Imports'):failures.append('NoCodeImported run unexpectedly has imports')
    expected=data.get('SourceSHA256');stated=proof.get('SavedPrivateSHA256')
    observed=digest(source_path) if source_path.is_file() else None
    if not expected or expected!=stated:failures.append('Run source SHA differs from proof saved SHA')
    if expected!=observed:failures.append('Frozen source actual SHA differs')
    stated_path=Path(proof.get('SavedPrivateCandidate','')).resolve()
    if stated_path!=source_path:failures.append('Proof saved source path differs')
    return {'Verified':not failures,'Failures':failures,'FrozenSource':data.get('FrozenSource'),'SourceSHA256':expected,'ActualFrozenSourceSHA256':observed,'ProofEvidence':data.get('FrozenSourceProof'),'ProofEvidenceSHA256':digest(proof_path) if proof_path.is_file() else None,'ProofStatus':proof.get('Status'),'ProofSavedSHA256':stated,'ProofSavedPath':proof.get('SavedPrivateCandidate'),'NoCodeImported':data.get('NoCodeImported'),'InheritedImports':proof.get('Imports',[]) if not failures else [],'Meaning':'SHA256-anchored transitive code binding, не сертификат цифровой подписи и не общий PASS.'}

def code_without_comment(line):
    quoted=False;i=0
    while i<len(line):
        if line[i]=='"':
            if quoted and i+1<len(line) and line[i+1]=='"': i+=2;continue
            quoted=not quoted
        elif line[i]=="'" and not quoted: return line[:i]
        i+=1
    return line

def methods(text):
    """Различает Get/Let/Set и однострочные методы; комментарий не закрывает тело."""
    lines=text.splitlines();out=[];active=None
    for i,line in enumerate(lines):
        code=code_without_comment(line)
        m=DECL.match(code)
        if m:
            if active is not None: raise AssertionError(('nested method',active,i+1))
            active={'Name':m[2],'Kind':re.sub(r'\s+',' ',m[1]),'Line':i+1}
        if active is not None and (re.match(r'^\s*End\s+(Sub|Function|Property)\b',code,re.I) or re.search(r':\s*End\s+(Sub|Function|Property)\b',code,re.I)):
            active['EndLine']=i+1
            active['BodySHA256']=hashlib.sha256('\n'.join(lines[active['Line']-1:i+1]).encode('utf-8')).hexdigest().upper()
            out.append(active);active=None
    if active is not None: raise AssertionError(('unterminated',active))
    return out

inventory=load(HERE/'Inventory.json')
inventory_by_path={f['Path']:f for f in inventory}
coverage_paths={'Root':'RootCoverage.json','Geometry':'Geometry/ReviewCoverage.json','Excel':'Excel/Coverage.json','Math':'Math/MathCoverage.json'}
coverage={};records=defaultdict(list)
for owner,path in coverage_paths.items():
    data=load(HERE/path);coverage[owner]=data
    for file in data['Files']:
        rel=file.get('Path',file.get('File'))
        records[rel].append((owner,file))

actual_paths={p.relative_to(ROOT).as_posix() for p in (ROOT/'src').rglob('*') if p.suffix in ('.cls','.bas')}
extra_actual=sorted(actual_paths-inventory_by_path.keys())
missing_actual=sorted(inventory_by_path.keys()-actual_paths)
file_reports=[];issues=[];line_updates=[];baseline_errors=[]

for rel,initial in sorted(inventory_by_path.items()):
    p=ROOT/rel
    if not p.exists():
        issues.append({'Path':rel,'Issue':'Inventory file missing from working tree'});continue
    current_methods=methods(p.read_text(encoding='utf-8-sig'));current_by_key={method_key(m):m for m in current_methods}
    original_bytes=subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT)
    original=original_bytes.decode('utf-8-sig')
    baseline_methods={method_key(m):m for m in methods(original)}
    baseline_sha=hashlib.sha256(original_bytes).hexdigest().upper()
    crlf_bytes=original_bytes.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
    crlf_sha=hashlib.sha256(crlf_bytes).hexdigest().upper()
    representation='GitBlobAsIs' if baseline_sha==initial['SHA256'].upper() else 'GitLFToWorkingTreeCRLF' if crlf_sha==initial['SHA256'].upper() else None
    if representation is None: baseline_errors.append({'Path':rel,'InventorySHA':initial['SHA256'],'GitBaselineSHA':baseline_sha,'GitLFToCRLFSHA':crlf_sha})
    inv_keys={method_key(m) for m in initial['Methods']}
    if inv_keys!=baseline_methods.keys(): baseline_errors.append({'Path':rel,'Issue':'Inventory method set differs from git baseline','MissingFromInventory':[list(k) for k in baseline_methods.keys()-inv_keys],'NotInBaseline':[list(k) for k in inv_keys-baseline_methods.keys()]})
    record_list=records.get(rel,[])
    row={'Path':rel,'ExpectedOwner':initial['Owner'],'BaselineSHA256':initial['SHA256'],'BaselineSHARepresentation':representation,'CurrentSHA256':digest(p),'BaselineMethodCount':len(initial['Methods']),'CurrentMethodCount':len(current_methods),'AddedSinceInventory':[m for k,m in current_by_key.items() if k not in inv_keys],'RemovedSinceInventory':[m for m in initial['Methods'] if method_key(m) not in current_by_key],'CoverageRecords':[]}
    if not record_list: issues.append({'Path':rel,'Issue':'No reviewer coverage record'})
    if len(record_list)>1: issues.append({'Path':rel,'Issue':'Duplicate reviewer ownership','Owners':[o for o,_ in record_list]})
    for owner,f in record_list:
        if owner!=initial['Owner']: issues.append({'Path':rel,'Issue':'Reviewer differs from inventory owner','Expected':initial['Owner'],'Actual':owner})
        stated=f.get('CurrentSHA256',f.get('ReviewedSHA256'))
        complete=f.get('StaticReviewComplete',f.get('Status') in ('StaticReadComplete','CompleteStaticReview'))
        current_keys=set(current_by_key);covered={method_key(m):m for m in f.get('Methods',[])}
        missing=current_keys-covered.keys();obsolete=covered.keys()-current_keys
        entry={'Owner':owner,'ReportedComplete':bool(complete),'StatedReviewedFileSHA256':stated,'FullFileHashMatches':None if stated is None else stated.upper()==row['CurrentSHA256'],'CurrentMethodsMissingFromCoverage':[current_by_key[k] for k in sorted(missing)],'ObsoleteMethodsInCoverage':[covered[k] for k in sorted(obsolete)],'MethodReviewNotComplete':[],'MethodBodyHashMismatches':[],'NonBaselineLineMismatches':[]}
        if not complete: issues.append({'Path':rel,'Issue':'Reviewer file not marked complete'})
        if stated and not entry['FullFileHashMatches']: issues.append({'Path':rel,'Issue':'Stale reviewed file SHA256','Owner':owner,'RecordedSHA256':stated,'CurrentSHA256':row['CurrentSHA256']})
        if missing or obsolete: issues.append({'Path':rel,'Issue':'Method coverage set differs','Missing':[list(k) for k in sorted(missing)],'Obsolete':[list(k) for k in sorted(obsolete)]})
        for key,m in covered.items():
            review=m.get('StaticReview',m.get('Review',m.get('Status',m.get('Reviewed'))))
            is_complete=review is True or review in ('READ_AND_TRACED_IN_FILE_CONTEXT','StaticReadComplete')
            if not is_complete:
                entry['MethodReviewNotComplete'].append({'Name':m['Name'],'Kind':m['Kind'],'Status':review})
                issues.append({'Path':rel,'Issue':'Method not explicitly complete','Method':m['Name'],'Kind':m['Kind'],'Review':review})
            actual=current_by_key.get(key)
            if actual and m.get('CodeSHA256') and m['CodeSHA256'].upper()!=actual['BodySHA256']:
                bad={'Name':m['Name'],'Kind':m['Kind'],'Recorded':m['CodeSHA256'],'Current':actual['BodySHA256']}
                entry['MethodBodyHashMismatches'].append(bad);issues.append({'Path':rel,'Issue':'Stale reviewed method body SHA256',**bad})
            if 'BaselineLine' in m and key in baseline_methods and m['BaselineLine']!=baseline_methods[key]['Line']:
                baseline_errors.append({'Path':rel,'Method':m['Name'],'Issue':'BaselineLine differs','Recorded':m['BaselineLine'],'GitBaseline':baseline_methods[key]['Line']})
            elif actual and 'Line' in m and m['Line']!=actual['Line']:
                line={'Path':rel,'Owner':owner,'Name':m['Name'],'Kind':m['Kind'],'RecordedLine':m['Line'],'CurrentLine':actual['Line']}
                entry['NonBaselineLineMismatches'].append(line);line_updates.append(line)
        row['CoverageRecords'].append(entry)
    file_reports.append(row)

event_rel='tools/build_workbook/WorkbookHelpEvents.vba'
event_path=ROOT/event_rel;event_methods=methods(event_path.read_text(encoding='utf-8-sig'))
event_rows=records.get(event_rel,[]);event_report={'Path':event_rel,'Outside117SourceInventory':True,'CurrentSHA256':digest(event_path),'CurrentMethodCount':len(event_methods),'Coverage':[]}
for owner,f in event_rows:
    by_key={method_key(m):m for m in f['Methods']}
    er={'Owner':owner,'Status':f.get('Status'),'MissingMethods':[],'BodyHashMismatches':[],'AllMethodsReviewed':all(m.get('Reviewed') for m in f['Methods'])}
    for method in event_methods:
        old=by_key.get(method_key(method))
        if old is None: er['MissingMethods'].append(method)
        elif old.get('CodeSHA256','').upper()!=method['BodySHA256']: er['BodyHashMismatches'].append({'Name':method['Name'],'Recorded':old.get('CodeSHA256'),'Current':method['BodySHA256']})
    event_report['Coverage'].append(er)
    if er['MissingMethods'] or er['BodyHashMismatches'] or not er['AllMethodsReviewed']: issues.append({'Path':event_rel,'Issue':'Event coverage mismatch','Details':er})
if not event_rows: issues.append({'Path':event_rel,'Issue':'No event coverage record'})
unexpected_coverage=sorted(set(records)-set(inventory_by_path)-{event_rel})
counts=Counter(r['ExpectedOwner'] for r in file_reports)
coverage_summary={'AsOfUTC':NOW,'Baseline':BASE,'Meaning':'Это сверка описи и текущей привязки доказательств к исходникам; не новый смысловой обзор всех методов и не общий PASS.','InventoryFileCount':len(inventory),'CurrentSrcFileCount':len(actual_paths),'InventoryPendingIsInitialInventoryOnly':True,'SourceFileCountsByOwner':dict(counts),'BaselineMethodCount':sum(len(f['Methods']) for f in inventory),'CurrentMethodCount':sum(f['CurrentMethodCount'] for f in file_reports),'AddedCurrentMethods':sum(len(f['AddedSinceInventory']) for f in file_reports),'MissingActualFiles':missing_actual,'AdditionalActualSrcFiles':extra_actual,'UnexpectedCoverageFiles':unexpected_coverage,'BaselineInventoryErrors':baseline_errors,'SubstantiveCoverageBindingIssues':issues,'LineMetadataUpdatesNeeded':line_updates,'WorkbookHelpEvents':event_report,'Files':file_reports,'EvidenceHashes':{path:digest(HERE/path) for path in ('Inventory.json',*coverage_paths.values())},'Limitations':['Excel coverage содержит SHA каждого тела метода, но не полный SHA большинства файлов; декларации и шапки нельзя привязать к review одним только method hash. Текущий полный SHA вычислен независимо.','Начальный Inventory хранит исходные SHA и PENDING; они не должны переписываться в текущий статус. Новые методы сопоставлены с актуальными coverage отдельно.','Manual-политика, окончательная сохранность пользовательской книги, публикация и финальная приемка остаются у root.'],'OverallPassClaimed':False}
write('IndependentCoverageSummary.json',coverage_summary)

# Для одинакового макроса выбираем последнее фактически сохраненное кандидатное evidence.
candidate_data={}
for p in HERE.glob('*_Probes.json'):
    data=load(p)
    if data.get('PrivateCandidateImported') or data.get('NoCodeImported') or p.name in ('OptionalNumberBaseline13_Probes.json','MultiAreaBaseline12_Probes.json'):
        candidate_data[p.name]=data
evidence_order=[p.name for p in sorted((HERE/name for name in candidate_data),key=lambda p:(p.stat().st_mtime_ns,p.name))]
native=[];latest={}
changed_inventory_sources={r['Path'] for r in file_reports if r['CurrentSHA256']!=r['BaselineSHA256']}
for filename in evidence_order:
    path=HERE/filename
    if not path.exists(): native.append({'Evidence':filename,'Status':'PENDING_NO_FILE'});continue
    data=candidate_data[filename];imports=[];transitive=frozen_binding(data)
    effective_imports=transitive['InheritedImports'] if transitive and transitive['Verified'] else data.get('Imports',[])
    for imported in effective_imports:
        relative=imported['Path'];p=ROOT/relative;current=digest(p) if p.exists() else None
        imports.append({'Path':relative,'Candidate':imported.get('Candidate'),'ImportedSHA256':imported['SHA256'],'CurrentSHA256':current,'MatchesCurrent':current==imported['SHA256'].upper()})
    record={'Evidence':filename,'EvidenceSHA256':digest(path),'EvidenceModifiedUTC':datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat(),'Status':data.get('Status'),'PrivateCandidateImported':data.get('PrivateCandidateImported'),'OriginalSourceBookSHA256':data.get('SourceSHA256'),'OriginalSourceUnchangedReported':data.get('SourceUnchanged'),'Error':data.get('Error'),'Imports':imports,'AllImportedHashesCurrent':all(i['MatchesCurrent'] for i in imports),'MismatchedImportedPaths':[i['Path'] for i in imports if not i['MatchesCurrent']],'CompletedMacros':[]}
    production=[i for i in imports if i['Path'].startswith('src/')]
    record['EvidenceKind']='CandidateDirected' if data.get('PrivateCandidateImported') else 'UnchangedBaselineDiagnostic'
    if transitive:
        record['EvidenceKind']='FrozenSourceDirected'
        record['FrozenSourceBinding']=transitive
        record['DeclaredImportCount']=len(data.get('Imports',[]))
        record['EffectiveImportCount']=len(imports)
        record['AllImportedHashesCurrent']=record['AllImportedHashesCurrent'] and transitive['Verified']
    record['DiagramExtension']=data.get('DiagramExtension')
    record['StartedUTC']=data.get('StartedUTC');record['CompletedUTC']=data.get('CompletedUTC')
    record['RunnerSHA256']=data.get('RunnerSHA256')
    record['AllImportedProductionHashesCurrent']=all(i['MatchesCurrent'] for i in production)
    record['MismatchedImportedProductionPaths']=[i['Path'] for i in production if not i['MatchesCurrent']]
    record['MismatchedImportedTestOrHarnessPaths']=[i['Path'] for i in imports if not i['MatchesCurrent'] and not i['Path'].startswith('src/')]
    record['ProbeSummaries']=[]
    imported_paths={i['Path'] for i in imports}
    record['CurrentChangedSourceFilesNotInImportManifest']=sorted(changed_inventory_sources-imported_paths)
    record['AllCurrentChangedSourceFilesImportedWithCurrentSHA']=not record['CurrentChangedSourceFilesNotInImportManifest'] and record['AllImportedHashesCurrent']
    for probe in data.get('Probes',[]):
        macro=probe.get('Macro','');actual=str(probe.get('Actual',''))
        totals=re.findall(r'TOTAL[^\r\n]*',actual)
        failures=re.findall(r'(?:^|\n)(?:FAIL:|RUNTIME ERROR:)[^\r\n]*',actual)
        counts=re.findall(r'TOTAL[^\r\n]*?passed=(\d+);\s*failed=(\d+)',actual)
        macro_record={'Macro':macro,'Evidence':filename,'EvidenceStatus':data.get('Status'),'Totals':totals,'Passed':int(counts[-1][0]) if counts else None,'Failed':int(counts[-1][1]) if counts else None,'Failures':failures,'CompletedWithoutReportedFailure':bool(counts) and all(int(c[1])==0 for c in counts) and not failures,'AllEvidenceImportHashesCurrent':record['AllImportedHashesCurrent'],'MismatchedImportedPaths':record['MismatchedImportedPaths'],'OtherCurrentChangedSourceFilesNotImported':record['CurrentChangedSourceFilesNotInImportManifest']}
        macro_record['AllImportedProductionHashesCurrent']=record['AllImportedProductionHashesCurrent']
        macro_record['MismatchedImportedProductionPaths']=record['MismatchedImportedProductionPaths']
        macro_record['MismatchedImportedTestOrHarnessPaths']=record['MismatchedImportedTestOrHarnessPaths']
        macro_record['EvidenceKind']=record['EvidenceKind'];macro_record['DiagramExtension']=record['DiagramExtension']
        if transitive:macro_record['FrozenSourceBindingVerified']=transitive['Verified']
        record['ProbeSummaries'].append(macro_record)
        record['CompletedMacros'].append(macro)
        latest[macro]=macro_record
    if data.get('SavedPrivateCandidate'):
        private_path=Path(data['SavedPrivateCandidate'])
        record['SavedPrivateCandidate']=data['SavedPrivateCandidate']
        record['NativeReportedSavedPrivateSHA256']=data.get('SavedPrivateSHA256')
        record['ObservedSavedPrivateSHA256']=digest(private_path) if private_path.exists() else None
    native.append(record)

cad_records={}
for cad_folder in ('NativeCAD09','NativeCADFinal16'):
    cad_comparison=HERE/cad_folder/'Comparison.json'
    if not cad_comparison.exists():continue
    comparison=load(cad_comparison);identity=load(HERE/cad_folder/'Identity.json')
    signatures=[]
    for p in sorted((HERE/cad_folder).glob('*.txt')):
        text=p.read_text(encoding='utf-8-sig')
        ids=sorted(set(int(m) for m in re.findall(r'^(\d+)\.',text,re.M))) if '.calc.' in p.name else []
        signatures.append({'Path':p.relative_to(HERE).as_posix(),'SHA256':digest(p),'Rows':len(text.splitlines()),'CalculationCaseIDs':ids,'CaseCount':len(ids)})
    native07=next((r for r in native if r['Evidence']=='FinalDirected07_Probes.json'),{})
    native07_data=candidate_data.get('FinalDirected07_Probes.json',{})
    record={'Status':'DIRECTED_CAD_NUMERICAL_COMPARISON_COMPLETED' if comparison.get('Passed') else 'DIRECTED_CAD_COMPARISON_FAILED','Comparison':comparison,'SourceIdentity':identity,'Measurements':load(HERE/cad_folder/'Measurements.json'),'CaseCount':sum(s['CaseCount'] for s in signatures),'SignatureFiles':signatures,'EvidenceHashes':{f'{cad_folder}/{p}':digest(HERE/cad_folder/p) for p in ('Comparison.json','Identity.json','Measurements.json')},'CalculationKernelScope':'Test-OwnedCADRoundoff.ps1 вызывает TestMeasureCADRoundoffCalculation из книгиB для обоих CAD documentsA/B: сравнивается влияние различий экспорта/импорта геометрии при одном candidate kernel, а не весь старый solver против нового.','Scope':'24 directed solutions=6LC×2extension modes×2imported geometries; own real AutoCAD/Excel, UserDocumentsUsed=false. Это не весь состав ON/OFF.','OverallPassClaimed':False}
    if cad_folder=='NativeCAD09':
        record.update({'BookBMatchesNative07SavedBeforeFixtures':identity.get('SourceHashes',{}).get('B')==native07_data.get('SavedPrivateSHA256'),'Native07SavedBookSHA256':native07_data.get('SavedPrivateSHA256'),'BookBSourceImportManifest':'FinalDirected07_Probes.json','Native07AllImportedProductionHashesCurrent':native07.get('AllImportedProductionHashesCurrent')})
    elif (HERE/'ReleasePreservation.json').exists():
        release=load(HERE/'ReleasePreservation.json')
        record.update({'ReleasePreservationEvidence':'ReleasePreservation.json','BookBMatchesReleaseSHA':identity.get('SourceHashes',{}).get('B')==release.get('ReleaseSHA256'),'CompiledSourceSHA256':release.get('CompiledSourceSHA256'),'ReleaseSHA256':release.get('ReleaseSHA256'),'ReleasePreservationStatus':release.get('Status'),'Meaning':'Final candidate release comparison; source/native equality and publication are separate root proofs.'})
    cad_records[cad_folder]=record

corner_owner=load(HERE/'Geometry/CornerTangentTranslationReview.json') if (HERE/'Geometry/CornerTangentTranslationReview.json').exists() else {}
corner_runs=[]
for evidence in native:
    if any(i['Path']=='src/Geometry/CGeometryPath.cls' and i['MatchesCurrent'] for i in evidence['Imports']):
        for probe in evidence['ProbeSummaries']:
            if probe['Macro']=='modTestGeometry.RunGeometryTests':
                corner_runs.append({'Evidence':evidence['Evidence'],'DiagramExtension':evidence['DiagramExtension'],'Totals':probe['Totals'],'Passed':probe['Passed'],'Failed':probe['Failed'],'Failures':probe['Failures']})
closure={'ApprovalQuote':'Да, исправить и проверить углы','ApprovalRelayedByRoot':True,'CurrentGeometryPathSHA256':digest(ROOT/'src/Geometry/CGeometryPath.cls'),'OwnerRecord':corner_owner,'CurrentSourceDirectedGeometryRuns':corner_runs,'Status':'APPROVED_APPLIED_PENDING_DIRECTED_RECHECK' if not corner_runs or any(p['Failed'] for p in corner_runs) else 'APPROVED_APPLIED_DIRECTED_RECHECK_COMPLETED','Meaning':'Отдельное исправление детерминированного выбора касательной. Даже successful directed recheck не является общей ON/OFF приемкой или разрешением публикации.'}

# Доказываем покрытие короткой geometry-группы более новым общим runner-ом по общим private calls.
geometry_text=(ROOT/'tests/modTestGeometry.bas').read_text(encoding='utf-8-sig')
geometry_methods={m['Name']:m for m in methods(geometry_text)};geometry_lines=geometry_text.splitlines()
def geometry_calls(name):
    m=geometry_methods[name];body='\n'.join(geometry_lines[m['Line']:m['EndLine']-1])
    return set(re.findall(r'^\s*(Test\w+)\s+stats\b',body,re.M))
short_calls=geometry_calls('TestRunWorkingGeometryReviewTests');wide_calls=geometry_calls('RunGeometryTests')
superseding={'OlderMacro':'modTestGeometry.TestRunWorkingGeometryReviewTests','CurrentRunner':'modTestGeometry.RunGeometryTests','ShortRunnerPrivateCalls':sorted(short_calls),'AllShortPrivateCallsInCurrentRunner':short_calls<=wide_calls,'CurrentRunnerEvidence':latest.get('modTestGeometry.RunGeometryTests'),'Meaning':'Более новый RunGeometryTests содержит все private случаи короткого runner; старый1351 результат сам по себе относится к старым imported hashes и не переименовывается в текущий.'}
selected={'AsOfUTC':NOW,'Baseline':BASE,'Selection':'Последний записанный результат каждого макроса среди файлов с PrivateCandidateImported=true, упорядоченных по фактическому времени сохранения evidence; не baseline probes. Частичный PROBE_ERROR остается видимым, его выполненные макросы не выдают за завершенный общий запуск.','Evidence':native,'SelectedMacros':[latest[k] for k in sorted(latest)],'GeometrySupersedingRunner':superseding,'CompiledCandidate05Status':next((r['Status'] for r in native if r['Evidence']=='CompiledCandidate05_Probes.json'),'PENDING_NO_FILE'),'AcceptanceOutsideThisReadOnlyCheck':['Решение пользователя о Manual-политике/его реализация: по поручению root ожидалось на начало этой сверки; здесь не выводится из наличия diff','Итоговая проверка root полного сохранения пользовательских данных/настроек и финального output','Компиляция и native binding окончательной версии после всех последних изменений','Публикация, коммит и push root; отдельная полная ON/OFF-приемка только по явной авторизации'],'CurrentImportMismatchIsNotTestFailure':True,'OverallPassClaimed':False,'FullOnOffAcceptanceClaimed':False}
selected['Selection']='Последний записанный результат каждого макроса среди candidate evidence по фактическому времени сохранения. Два явно обозначенных baseline diagnostic закрывают R01/R03 и не считаются candidate acceptance. Все исторические FAIL/throws/PROBE_ERROR сохранены в Evidence.ProbeSummaries; исправленные test fixture counters не выдаются за исправление production.'
selected['KnownCornerClosure']=closure
selected['NativeCAD09DirectedEvidence']=cad_records.get('NativeCAD09',{})
selected['FinalReleaseCADDirectedEvidence']=cad_records.get('NativeCADFinal16',{})
selected['FreshnessHistoricalFailureDisposition']={'FailedEvidence':'FinalDirected07_Probes.json','FailedTotals':'326/3','Cause':'Тест ошибочно требовал монотонного роста глобального счетчика между batch Execute, хотя Execute его сбрасывает.','ProductionFixToMaskFailure':False,'LatestMacro':latest.get('modTestWorkbookInterface.RunTestCalculationFreshnessWorkflow'),'ExpectedCorrectedTotals':'344/0; прочие guard/capture результаты см. отдельные macro entries.'}
on=next((e for e in native if e['Evidence']=='FinalDirected14_Probes.json'),{})
off=next((e for e in native if e['Evidence']=='FinalFrozen15_Probes.json'),{})
on_data=candidate_data.get('FinalDirected14_Probes.json',{});off_data=candidate_data.get('FinalFrozen15_Probes.json',{})
on_macros=set(on.get('CompletedMacros',[]));off_macros=set(off.get('CompletedMacros',[]))
selected['FinalDirectedFrozenPair']={'OnEvidence':'FinalDirected14_Probes.json','OffEvidence':'FinalFrozen15_Probes.json','OnStatus':on.get('Status','PENDING'),'OffStatus':off.get('Status','PENDING'),'SavedArtifactSHA256':on_data.get('SavedPrivateSHA256'),'OffSourceSHA256':off_data.get('SourceSHA256'),'SameSavedArtifactByReportedSHA':bool(on_data.get('SavedPrivateSHA256')) and on_data.get('SavedPrivateSHA256')==off_data.get('SourceSHA256'),'OffFrozenSourceBinding':off.get('FrozenSourceBinding'),'OnMacroCount':len(on_macros),'OffMacroCount':len(off_macros),'SameMacroSet':on_macros==off_macros and bool(on_macros),'MissingOffMacros':sorted(on_macros-off_macros),'OnFailedAssertions':sum(p['Failed'] or 0 for p in on.get('ProbeSummaries',[])),'OffFailedAssertions':sum(p['Failed'] or 0 for p in off.get('ProbeSummaries',[])),'OnAllImportedHashesCurrent':on.get('AllImportedHashesCurrent'),'OffEffectiveImportedHashesCurrent':off.get('AllImportedHashesCurrent'),'OffSourceUnchangedReported':off_data.get('SourceUnchanged'),'BothCompleted':on.get('Status')=='PROBES_COMPLETED' and off.get('Status')=='PROBES_COMPLETED','Scope':'Только эти21 directed groups на одном frozen compiled artifact. Это не полный перечень ON/OFF и не обязательный часовой план.','OverallPassClaimed':False}
release_path=HERE/'ReleasePreservation.json'
if release_path.exists():
    preservation=load(release_path)
    selected['RootReleasePreservation']={'Evidence':'ReleasePreservation.json','SHA256':digest(release_path),'Status':preservation.get('Status'),'BaselineSHA256':preservation.get('BaselineSHA256'),'CompiledSourceSHA256':preservation.get('CompiledSourceSHA256'),'ReleaseSHA256':preservation.get('ReleaseSHA256'),'PreservedParts':preservation.get('PreservedParts'),'AuthorizedNonVBAChange':preservation.get('AuthorizedNonVBAChange'),'AllUserDataFormulasStylesDrawingsNamesLinksPreservedReported':preservation.get('AllUserDataFormulasStylesDrawingsNamesLinksPreserved'),'PublishedReported':preservation.get('Published'),'CompiledSourceMatchesFinalPairArtifact':preservation.get('CompiledSourceSHA256')==on_data.get('SavedPrivateSHA256'),'Meaning':'Read-only сводка proof root; фактический native/source export и публикацию выполняет root.'}
selected['AcceptanceOutsideThisReadOnlyCheck']=['Итоговая сохранность пользовательских данных/настроек и финальная опубликованная книга — root','Финальная native code/source binding после всех последних исправлений — root','Коммит/push и упаковка компактных доказательств — root','Самые долгие полные ON/OFF и обязательный часовой план требуют отдельной явной авторизации; directed numerical/CAD сравнения их не заменяют.']
write('SelectedNativeEvidence.json',selected)
print(json.dumps({'Files':len(inventory),'CurrentMethods':coverage_summary['CurrentMethodCount'],'AddedMethods':coverage_summary['AddedCurrentMethods'],'SubstantiveIssues':len(issues),'LineMetadataUpdates':len(line_updates),'BaselineErrors':len(baseline_errors),'NativeSelectedMacros':len(latest),'CompiledCandidate05':selected['CompiledCandidate05Status']},ensure_ascii=False))
