# SECTION_RECIPE_API: каталог текущих сигнатур

Сигнатуры, defaults и каждый контекстный вызов синхронизированы с source; native entrypoint/журнал указан у каждого члена. Workbook-расположение фиксирует NativeMap.json, итоговая приёмка книги — отдельный отчёт.

Все Public члены фасада, его options/результатов и общего ввода/единиц; общие query/region и build diagnostics для проверок. Private/Friend не API рецепта.

Внутри мм/мм²/Н/Н*мм/МПа; углы в радианах. ByRef/Optional/default приведены в точной сигнатуре. Полный общий фасад и исходный класс представлены в ADDING_SECTION_TYPE.md.

## ISectionRecipe

Вызывается реестром с готовым context; создаёт новое definition. Не выполняет mesh/layout/solver/Excel output.

<a id="api-isectionrecipe-createdefinition"></a>
### ISectionRecipe.CreateDefinition

Интерфейс единственного класса типа. Возвращает опубликованное definition через общий фасад, без сетки/баров/Shapes в рецепте.

```vb
Public Function CreateDefinition(ByVal context As CSectionRecipeContext) As CSectionDefinition
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| context | CSectionRecipeContext; ByVal; обязательный | Подготовленный снимок CSectionRecipeContext, не live Excel. |

Тип результата: CSectionDefinition. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Вызывается реестром с готовым context; создаёт новое definition. Не выполняет mesh/layout/solver/Excel output.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/ISectionRecipe.cls:14

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.CircleInputCase с его подготовленными локальными объектами/входом.

```vb
    Set recipe = New CSectionRecipeCircle: Set definition = recipe.CreateDefinition(context)
```

Полный контекст: tests/modTestSectionRecipes.bas:640.

Native entrypoint: modTestSectionRecipes.RunCircleRecipeInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CircleEvidencePack/Actual/InputTests.txt.

## CSectionDefinitionBuilder

New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

<a id="api-csectiondefinitionbuilder-initialize"></a>
### CSectionDefinitionBuilder.Initialize

Открывает один новый фасад с TypeID и версией схемы. Повторная инициализация запрещена.

```vb
Public Sub Initialize(ByVal typeID As String, Optional ByVal schemaVersion As Long = 1)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| typeID | String; ByVal; обязательный | Смысловое имя зарегистрированного типа; непустой текст. |
| schemaVersion | Long; ByVal; Optional; default=1 | Положительная целая версия схемы определения. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:18

Минимальный вызов; требуемый контекст: В теле modTestRegressionBaseline.RunBaselineCase с его подготовленными локальными объектами/входом.

```vb
    facade.Initialize "BaselineCirclePaths"
```

Полный контекст: tests/modTestRegressionBaseline.bas:64.

Native entrypoint: modTestRegressionBaseline.RunRegressionBaselineTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/NumericalRegression.txt.

<a id="api-csectiondefinitionbuilder-circlepath"></a>
### CSectionDefinitionBuilder.CirclePath

Создаёт замкнутую окружность CCW от точки +X; один сегмент с тем же ID, что путь.

```vb
Public Function CirclePath(ByVal pathID As String, ByVal centerX As Double, ByVal centerY As Double, ByVal radius As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| centerX | Double; ByVal; обязательный | Модельная координата centerX, мм; знаки соответствуют section XY/WCS. |
| centerY | Double; ByVal; обязательный | Модельная координата centerY, мм; знаки соответствуют section XY/WCS. |
| radius | Double; ByVal; обязательный | Положительный радиус, мм. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:24

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.CirclePath("Hole", 0#, -250#, 50#)
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:43.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-csectiondefinitionbuilder-linepath"></a>
### CSectionDefinitionBuilder.LinePath

Создаёт непрерывный открытый путь из одной прямой от первого конца ко второму.

```vb
Public Function LinePath(ByVal pathID As String, ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| x1 | Double; ByVal; обязательный | Модельная координата x1, мм; знаки соответствуют section XY/WCS. |
| y1 | Double; ByVal; обязательный | Модельная координата y1, мм; знаки соответствуют section XY/WCS. |
| x2 | Double; ByVal; обязательный | Модельная координата x2, мм; знаки соответствуют section XY/WCS. |
| y2 | Double; ByVal; обязательный | Модельная координата y2, мм; знаки соответствуют section XY/WCS. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:33

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.DiagnosticFacade с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.LinePath("Row", 0#, 0#, 100#, 0#)
```

Полный контекст: tests/modTestRecipeOperations.bas:192.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-arcpath"></a>
### CSectionDefinitionBuilder.ArcPath

Создаёт точную дугу по центру/радиусу/startAngle/signed sweep; полный оборот замкнут.

```vb
Public Function ArcPath(ByVal pathID As String, ByVal centerX As Double, ByVal centerY As Double, ByVal radius As Double, ByVal startAngle As Double, ByVal sweep As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| centerX | Double; ByVal; обязательный | Модельная координата centerX, мм; знаки соответствуют section XY/WCS. |
| centerY | Double; ByVal; обязательный | Модельная координата centerY, мм; знаки соответствуют section XY/WCS. |
| radius | Double; ByVal; обязательный | Положительный радиус, мм. |
| startAngle | Double; ByVal; обязательный | Начальный угол, радианы; от +X. |
| sweep | Double; ByVal; обязательный | Signed sweep, радианы: CCW положителен, CW отрицателен, 0 запрещён, \|sweep\|≤2*pi. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:42

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestAnnotationMeasurements с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.ArcPath("Curve", 0#, 0#, 100#, 0#, GEOM_PI / 2#)
```

Полный контекст: tests/modTestSectionRecipes.bas:328.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-roundedpolygon"></a>
### CSectionDefinitionBuilder.RoundedPolygon

Создаёт согласованную границу по вершинам/радиусам/ID. Edge.ID начинается у указанной вершины, Corner.ID существует только при R>0.

```vb
Public Function RoundedPolygon(ByVal pathID As String, ByVal vertices As Variant, ByVal radii As Variant, ByVal vertexIDs As Variant) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| vertices | Variant; ByVal; обязательный | Двумерные вершины: Array(Array(x,y),...); координаты во внутренних мм. |
| radii | Variant; ByVal; обязательный | Массив неотрицательных радиусов вершин в мм, длина равна vertices; clamp бетонного радиуса отсутствует. |
| vertexIDs | Variant; ByVal; обязательный | Массив уникальных смысловых ID вершин; определяет Edge.ID/Corner.ID. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:52

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeExamples.RoundedFrameDefinition с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.RoundedPolygon("Outer", outerVertices, Array(80#, 80#, 80#, 80#), outerCorners)
```

Полный контекст: tests/modTestDeclarativeExamples.bas:61.

Native entrypoint: modTestDeclarativeExamples.RunRoundedFrameExampleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/OneClassExample/InputAndBuild.txt.

<a id="api-csectiondefinitionbuilder-offsetroundedpolygon"></a>
### CSectionDefinitionBuilder.OffsetRoundedPolygon

Смещает весь скруглённый многоугольник с согласованными стыками. Положительное расстояние внутрь площади; отрицательное наружу, из Opening в бетон.

```vb
Public Function OffsetRoundedPolygon(ByVal pathID As String, ByVal vertices As Variant, ByVal radii As Variant, ByVal vertexIDs As Variant, ByVal distance As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| vertices | Variant; ByVal; обязательный | Двумерные вершины: Array(Array(x,y),...); координаты во внутренних мм. |
| radii | Variant; ByVal; обязательный | Массив неотрицательных радиусов вершин в мм, длина равна vertices; clamp бетонного радиуса отсутствует. |
| vertexIDs | Variant; ByVal; обязательный | Массив уникальных смысловых ID вершин; определяет Edge.ID/Corner.ID. |
| distance | Double; ByVal; обязательный | Signed offset, мм: положительно внутрь площади, отрицательно наружу; это не left-offset обхода. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:59

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeExamples.RoundedFrameDefinition с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.OffsetRoundedPolygon("Outer.Axis", outerVertices, Array(80#, 80#, 80#, 80#), outerCorners, 60#)
```

Полный контекст: tests/modTestDeclarativeExamples.bas:65.

Native entrypoint: modTestDeclarativeExamples.RunRoundedFrameExampleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/OneClassExample/InputAndBuild.txt.

<a id="api-csectiondefinitionbuilder-addpath"></a>
### CSectionDefinitionBuilder.AddPath

Добавляет уже опубликованный непрерывный CGeometryPath в определение; не включает его автоматически в бетон.

```vb
Public Sub AddPath(ByVal path As CGeometryPath)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| path | CGeometryPath; ByVal; обязательный | Существующий непрерывный опубликованный CGeometryPath. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:66

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    path.Seal: facade.AddPath path
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:53.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-csectiondefinitionbuilder-anchor"></a>
### CSectionDefinitionBuilder.Anchor

Объявляет именованную модельную точку. Данные копируются как два скаляра.

```vb
Public Sub Anchor(ByVal anchorID As String, ByVal x As Double, ByVal y As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| anchorID | String; ByVal; обязательный | Непустой уникальный ID модельной привязки. |
| x | Double; ByVal; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. |
| y | Double; ByVal; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:72

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.AnnotationFacade с его подготовленными локальными объектами/входом.

```vb
        facade.Anchor "TextNote", 200#, 0#
```

Полный контекст: tests/modTestRecipeAnnotations.bas:154.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-pathanchor"></a>
### CSectionDefinitionBuilder.PathAnchor

Получает точку конкретного сегмента по ID и параметру [0;1], объявляет именованную привязку.

```vb
Public Sub PathAnchor(ByVal anchorID As String, ByVal pathID As String, ByVal segmentID As String, Optional ByVal parameter As Double = 0#)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| anchorID | String; ByVal; обязательный | Непустой уникальный ID модельной привязки. |
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| segmentID | String; ByVal; обязательный | Устойчивый ID существующего сегмента; исчезнувший Corner не подменяется индексом. |
| parameter | Double; ByVal; Optional; default=0# | Нормированный параметр точки сегмента [0;1], не расстояние по всему пути. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:77

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.AnnotationFacade с его подготовленными локальными объектами/входом.

```vb
    facade.PathAnchor "East", "Boundary", "Boundary", 0#
```

Полный контекст: tests/modTestRecipeAnnotations.bas:156.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-source"></a>
### CSectionDefinitionBuilder.Source

Связывает смысловой ID со строкой источника/адреса без сохранения объекта Excel.

```vb
Public Sub Source(ByVal entityID As String, ByVal sourceReference As String)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| entityID | String; ByVal; обязательный | Смысловой ID сущности для SourceMap. |
| sourceReference | String; ByVal; обязательный | Строка исходного адреса/программного параметра; без объекта Excel. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:85

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.RunRecipeAnnotationTests с его подготовленными локальными объектами/входом.

```vb
    facade.Source "Diagonal", "ProgramInputs.PointB"
```

Полный контекст: tests/modTestRecipeAnnotations.bas:13.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

<a id="api-csectiondefinitionbuilder-transformanchor"></a>
### CSectionDefinitionBuilder.TransformAnchor

Создаёт новую привязку из существующей: отражение по локальной X, поворот вокруг (0,0), перенос.

```vb
Public Sub TransformAnchor(ByVal anchorID As String, ByVal sourceAnchorID As String, ByVal shiftX As Double, ByVal shiftY As Double, Optional ByVal rotation As Double = 0#, Optional ByVal reflectX As Boolean = False)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| anchorID | String; ByVal; обязательный | Непустой уникальный ID модельной привязки. |
| sourceAnchorID | String; ByVal; обязательный | ID существующей исходной привязки. |
| shiftX | Double; ByVal; обязательный | Перенос по X, мм. |
| shiftY | Double; ByVal; обязательный | Перенос по Y, мм. |
| rotation | Double; ByVal; Optional; default=0# | Угол поворота вокруг (0,0), радианы, CCW положителен. |
| reflectX | Boolean; ByVal; Optional; default=False | Отражение относительно локальной оси X перед поворотом и переносом. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:90

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeOperationTests с его подготовленными локальными объектами/входом.

```vb
    facade.Anchor "CornerAnchor", 100#, 0#: facade.TransformAnchor "MovedAnchor", "CornerAnchor", 500#, -200#, GEOM_PI / 2#, True
```

Полный контекст: tests/modTestRecipeOperations.bas:43.

Native entrypoint: modTestRecipeOperations.RunRecipeOperationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-offset"></a>
### CSectionDefinitionBuilder.Offset

Смещает линию/аналитическую цепочку слева от обхода при положительном signedLeftDistance. Line/line стыки miter; arc стыки должны быть гладкими.

```vb
Public Function Offset(ByVal pathID As String, ByVal sourcePathID As String, ByVal signedLeftDistance As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| sourcePathID | String; ByVal; обязательный | ID ранее объявленного пути, который читается без изменения. |
| signedLeftDistance | Double; ByVal; обязательный | Поперечное смещение, мм; положительно слева от направления пути, отрицательно справа. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:99

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.Offset("Lost", "Small", 20#)
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:152.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinitionbuilder-constrainline"></a>
### CSectionDefinitionBuilder.ConstrainLine

Ограничивает или продлевает одну прямую двумя поперечными плоскостями nX*x+nY*y=bound; направление исходного пути сохраняется.

```vb
Public Function ConstrainLine(ByVal pathID As String, ByVal sourcePathID As String, ByVal startNX As Double, ByVal startNY As Double, ByVal startBound As Double, ByVal endNX As Double, ByVal endNY As Double, ByVal endBound As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| sourcePathID | String; ByVal; обязательный | ID ранее объявленного пути, который читается без изменения. |
| startNX | Double; ByVal; обязательный | X-компонента начальной поперечной нормали; линия не должна быть параллельна плоскости. |
| startNY | Double; ByVal; обязательный | Y-компонента начальной поперечной нормали. |
| startBound | Double; ByVal; обязательный | Значение начальной плоскости startNX*x+startNY*y=startBound; мм при единичной нормали. |
| endNX | Double; ByVal; обязательный | X-компонента конечной поперечной нормали. |
| endNY | Double; ByVal; обязательный | Y-компонента конечной поперечной нормали. |
| endBound | Double; ByVal; обязательный | Значение конечной плоскости endNX*x+endNY*y=endBound; мм при единичной нормали. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:109

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeOperationTests с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.ConstrainLine("Trimmed", "Axis", 1#, 0#, 10#, 1#, 0#, 80#)
```

Полный контекст: tests/modTestRecipeOperations.bas:24.

Native entrypoint: modTestRecipeOperations.RunRecipeOperationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-lastgeometrydiagnostic"></a>
### CSectionDefinitionBuilder.LastGeometryDiagnostic

Возвращает последнюю диагностику query фасада с SourceMap. Nothing означает отсутствие записанного отказа.

```vb
Public Property Get LastGeometryDiagnostic() As CGeometryDiagnostic
```

Тип результата: CGeometryDiagnostic. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:121

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set diagnostic = facade.LastGeometryDiagnostic
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:155.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinitionbuilder-chain"></a>
### CSectionDefinitionBuilder.Chain

Выбирает непрерывный участок между двумя именованными сегментными привязками. Направление обхода явно; fullLoopIfSame задаёт полный оборот при совпавших концах.

```vb
Public Function Chain(ByVal pathID As String, ByVal sourcePathID As String, ByVal startSegmentID As String, ByVal startParameter As Double, ByVal endSegmentID As String, ByVal endParameter As Double, Optional ByVal forward As Boolean = True, Optional ByVal fullLoopIfSame As Boolean = False) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| sourcePathID | String; ByVal; обязательный | ID ранее объявленного пути, который читается без изменения. |
| startSegmentID | String; ByVal; обязательный | Сегмент начальной привязки цепочки. |
| startParameter | Double; ByVal; обязательный | Параметр начальной точки выбранного сегмента [0;1]. |
| endSegmentID | String; ByVal; обязательный | Сегмент конечной привязки цепочки. |
| endParameter | Double; ByVal; обязательный | Параметр конечной точки выбранного сегмента [0;1]. |
| forward | Boolean; ByVal; Optional; default=True | Явное направление следования исходному обходу; False — противоположное. |
| fullLoopIfSame | Boolean; ByVal; Optional; default=False | Полный оборот при совпавших привязках замкнутого пути; иначе нулевая цепочка недопустима. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:131

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Set part = facade.Chain("Side", "Outer", "Edge.BR", 0#, "Edge.TR", 0#)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:86.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-transform"></a>
### CSectionDefinitionBuilder.Transform

Создаёт новый путь из существующего изометрией; сохраняет сегментные ID и происхождение, отражение меняет знак sweep.

```vb
Public Function Transform(ByVal pathID As String, ByVal sourcePathID As String, ByVal shiftX As Double, ByVal shiftY As Double, Optional ByVal rotation As Double = 0#, Optional ByVal reflectX As Boolean = False) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| sourcePathID | String; ByVal; обязательный | ID ранее объявленного пути, который читается без изменения. |
| shiftX | Double; ByVal; обязательный | Перенос по X, мм. |
| shiftY | Double; ByVal; обязательный | Перенос по Y, мм. |
| rotation | Double; ByVal; Optional; default=0# | Угол поворота вокруг (0,0), радианы, CCW положителен. |
| reflectX | Boolean; ByVal; Optional; default=False | Отражение относительно локальной оси X перед поворотом и переносом. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:141

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Set changed = facade.Transform("MovedSide", "Side", 1000000#, -1000000#)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:87.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-rectanglepath"></a>
### CSectionDefinitionBuilder.RectanglePath

Создаёт замкнутую наружную границу одного прямоугольника от (x,y) с положительными width/height.

```vb
Public Function RectanglePath(ByVal pathID As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal height As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| x | Double; ByVal; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. |
| y | Double; ByVal; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. |
| width | Double; ByVal; обязательный | Координата/размер width, мм; размеры width/height положительны. |
| height | Double; ByVal; обязательный | Координата/размер height, мм; размеры width/height положительны. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:149

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestNewGeometryWithMultipleOpenings с его подготовленными локальными объектами/входом.

```vb
        Set path = facade.RectanglePath("Boundary", 0#, 0#, 100#, 100#)
```

Полный контекст: tests/modTestGeometryQuery.bas:816.

Native entrypoint: modTestGeometryQuery.RunGeneratedContourOwnershipTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiondefinitionbuilder-adjacentrectangles"></a>
### CSectionDefinitionBuilder.AdjacentRectangles

Создаёт одну границу смежных неперекрывающихся прямоугольников. Произвольное пересекающееся CAD Union не выполняется.

```vb
Public Function AdjacentRectangles(ByVal pathID As String, ByVal rectangles As Variant) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| rectangles | Variant; ByVal; обязательный | Array(Array(x,y,width,height),...); мм, размеры положительные, прямоугольники смежные без перекрытий. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:155

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set path = facade.AdjacentRectangles("Concrete", Array(Array(-200#, -200#, 400#, 400#)))
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:99.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinitionbuilder-pathgroup"></a>
### CSectionDefinitionBuilder.PathGroup

Объявляет массив ID независимых путей; порядок значим, фиктивные соединения отсутствуют.

```vb
Public Sub PathGroup(ByVal groupID As String, ByVal pathIDs As Variant)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| groupID | String; ByVal; обязательный | Смысловой ID группы; путь и арматурная annotation-group — разные контракты. |
| pathIDs | Variant; ByVal; обязательный | Массив ID существующих независимых путей; без повторов. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:161

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    facade.PathGroup "Rows", Array("Row", "Row2")
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:103.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinitionbuilder-outer"></a>
### CSectionDefinitionBuilder.Outer

Назначает замкнутому пути роль наружной границы материала. Не требует наличия арматуры.

```vb
Public Sub Outer(ByVal loopID As String, ByVal pathID As String, Optional ByVal comment As String = "", Optional ByVal contourIDs As Variant, Optional ByVal arcComment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| loopID | String; ByVal; обязательный | Непустой устойчивый ID контура; у CConcreteRegion численный индекс loop 1..LoopCount. |
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |
| contourIDs | Variant; ByVal; Optional; пропущенный Variant=Missing | Необязательный массив ID сегментов сохранённого контура, по одному на каждый сегмент пути. |
| arcComment | String; ByVal; Optional; default="" | Отдельный комментарий аналитических дуг; пустой использует обычный comment. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:166

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestHollowRectangleGeometry с его подготовленными локальными объектами/входом.

```vb
    facade.Outer "OUTER", path.ID
```

Полный контекст: tests/modTestGeometry.bas:1911.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-opening"></a>
### CSectionDefinitionBuilder.Opening

Назначает замкнутому пути роль отверстия с конкретным parentOuterID. Действительное вложение проверяется при Finish.

```vb
Public Sub Opening(ByVal loopID As String, ByVal pathID As String, ByVal parentOuterID As String, Optional ByVal comment As String = "", Optional ByVal contourIDs As Variant, Optional ByVal arcComment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| loopID | String; ByVal; обязательный | Непустой устойчивый ID контура; у CConcreteRegion численный индекс loop 1..LoopCount. |
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| parentOuterID | String; ByVal; обязательный | ID ранее объявленной наружной границы для Opening; проверяется реальное вложение. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |
| contourIDs | Variant; ByVal; Optional; пропущенный Variant=Missing | Необязательный массив ID сегментов сохранённого контура, по одному на каждый сегмент пути. |
| arcComment | String; ByVal; Optional; default="" | Отдельный комментарий аналитических дуг; пустой использует обычный comment. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:175

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestHollowRectangleGeometry с его подготовленными локальными объектами/входом.

```vb
    facade.Opening "VOID", path.ID, "OUTER"
```

Полный контекст: tests/modTestGeometry.bas:1914.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-rebarbycount"></a>
### CSectionDefinitionBuilder.RebarByCount

Объявляет n станций на всём рабочем пути с выбранным EndMode; для группы n применяется к каждому пути. n=0 или d=0 выключает правило.

```vb
Public Sub RebarByCount(ByVal ruleID As String, ByVal target As String, ByVal count As Long, ByVal diameter As Double, Optional ByVal options As CRebarRuleOptions = Nothing, Optional ByVal steelClass As String = "Rebar")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| count | Long; ByVal; обязательный | Целый неотрицательный счётчик; для ByCount применяется отдельно к каждому пути. |
| diameter | Double; ByVal; обязательный | Диаметр стержня, мм; отрицательный запрещён, ноль выключает ряд. |
| options | CRebarRuleOptions; ByVal; Optional; default=Nothing | CRebarRuleOptions; поля копируются при объявлении. Nothing создаёт реальные default options. |
| steelClass | String; ByVal; Optional; default="Rebar" | Строка принадлежности материала арматуры; совпадения разных материалов требуют явной политики. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:185

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    facade.RebarByCount "Base", "Row", 3, 10#
```

Полный контекст: tests/modTestRecipeOperations.bas:131.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-rebarbymaxstep"></a>
### CSectionDefinitionBuilder.RebarByMaxStep

Объявляет распределение с достаточным количеством станций для ограничения максимального шага. Фактический шаг может быть меньше заданного.

```vb
Public Sub RebarByMaxStep(ByVal ruleID As String, ByVal target As String, ByVal step As Double, ByVal diameter As Double, Optional ByVal options As CRebarRuleOptions = Nothing, Optional ByVal steelClass As String = "Rebar")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| step | Double; ByVal; обязательный | Положительный шаг вдоль аналитического пути, мм. |
| diameter | Double; ByVal; обязательный | Диаметр стержня, мм; отрицательный запрещён, ноль выключает ряд. |
| options | CRebarRuleOptions; ByVal; Optional; default=Nothing | CRebarRuleOptions; поля копируются при объявлении. Nothing создаёт реальные default options. |
| steelClass | String; ByVal; Optional; default="Rebar" | Строка принадлежности материала арматуры; совпадения разных материалов требуют явной политики. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:194

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    facade.RebarByMaxStep "Step", "Row", 30#, 10#, options
```

Полный контекст: tests/modTestSectionRecipes.bas:177.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-rebarbyfixedstep"></a>
### CSectionDefinitionBuilder.RebarByFixedStep

Объявляет точный шаг и явное размещение остатка. IncludeBoth/ClosedUniform требуют совместимости рабочей длины с шагом.

```vb
Public Sub RebarByFixedStep(ByVal ruleID As String, ByVal target As String, ByVal step As Double, ByVal diameter As Double, Optional ByVal options As CRebarRuleOptions = Nothing, Optional ByVal steelClass As String = "Rebar")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| step | Double; ByVal; обязательный | Положительный шаг вдоль аналитического пути, мм. |
| diameter | Double; ByVal; обязательный | Диаметр стержня, мм; отрицательный запрещён, ноль выключает ряд. |
| options | CRebarRuleOptions; ByVal; Optional; default=Nothing | CRebarRuleOptions; поля копируются при объявлении. Nothing создаёт реальные default options. |
| steelClass | String; ByVal; Optional; default="Rebar" | Строка принадлежности материала арматуры; совпадения разных материалов требуют явной политики. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:201

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    facade.RebarByFixedStep "Fixed", "Row", 30#, 10#, options
```

Полный контекст: tests/modTestSectionRecipes.bas:184.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-rebaratstations"></a>
### CSectionDefinitionBuilder.RebarAtStations

Объявляет явные станции по длине пути. Порядок массива задаёт исходные ordinals.

```vb
Public Sub RebarAtStations(ByVal ruleID As String, ByVal target As String, ByVal stations As Variant, ByVal diameter As Double, Optional ByVal options As CRebarRuleOptions = Nothing, Optional ByVal steelClass As String = "Rebar")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| stations | Variant; ByVal; обязательный | Массив численных станций вдоль полного пути, мм; порядок задаёт ordinals. |
| diameter | Double; ByVal; обязательный | Диаметр стержня, мм; отрицательный запрещён, ноль выключает ряд. |
| options | CRebarRuleOptions; ByVal; Optional; default=Nothing | CRebarRuleOptions; поля копируются при объявлении. Nothing создаёт реальные default options. |
| steelClass | String; ByVal; Optional; default="Rebar" | Строка принадлежности материала арматуры; совпадения разных материалов требуют явной политики. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:208

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    facade.RebarAtStations "Dense", "Row", dense, 20#
```

Полный контекст: tests/modTestRecipeOperations.bas:156.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-rebardependent"></a>
### CSectionDefinitionBuilder.RebarDependent

Получает связанные позиции по TangentOffset/NormalOffset исходного ряда; не выполняет независимое перераспределение на новом пути.

```vb
Public Sub RebarDependent(ByVal ruleID As String, ByVal sourceRuleID As String, ByVal diameter As Double, ByVal options As CRebarRuleOptions, Optional ByVal steelClass As String = "Rebar")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| sourceRuleID | String; ByVal; обязательный | ID исходного правила зависимости; циклы запрещены. |
| diameter | Double; ByVal; обязательный | Диаметр стержня, мм; отрицательный запрещён, ноль выключает ряд. |
| options | CRebarRuleOptions; ByVal; обязательный | CRebarRuleOptions; поля копируются при объявлении. Nothing создаёт реальные default options. |
| steelClass | String; ByVal; Optional; default="Rebar" | Строка принадлежности материала арматуры; совпадения разных материалов требуют явной политики. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:215

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    facade.RebarDependent "Extra", "Base", 10#, options
```

Полный контекст: tests/modTestSectionRecipes.bas:198.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-rebarprojected"></a>
### CSectionDefinitionBuilder.RebarProjected

Проецирует исходные позиции на конечный target. Setbacks фильтруют целевой участок; отсутствие hit обрабатывается явно.

```vb
Public Sub RebarProjected(ByVal ruleID As String, ByVal target As String, ByVal sourceRuleID As String, ByVal diameter As Double, ByVal options As CRebarRuleOptions, Optional ByVal steelClass As String = "Rebar")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| sourceRuleID | String; ByVal; обязательный | ID исходного правила зависимости; циклы запрещены. |
| diameter | Double; ByVal; обязательный | Диаметр стержня, мм; отрицательный запрещён, ноль выключает ряд. |
| options | CRebarRuleOptions; ByVal; обязательный | CRebarRuleOptions; поля копируются при объявлении. Nothing создаёт реальные default options. |
| steelClass | String; ByVal; Optional; default="Rebar" | Строка принадлежности материала арматуры; совпадения разных материалов требуют явной политики. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:222

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    facade.RebarProjected "Projected", "Target", "Base", 10#, options
```

Полный контекст: tests/modTestRecipeOperations.bas:135.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-verticalextent"></a>
### CSectionDefinitionBuilder.VerticalExtent

Измеряет полный вертикальный габарит выбранного пути/группы с точными экстремумами дуг. placementX и normalX задают сторону отображения.

```vb
Public Sub VerticalExtent(ByVal annotationID As String, ByVal target As String, ByVal name As String, ByVal placementX As Double, Optional ByVal normalX As Double = -1#, Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| name | String; ByVal; обязательный | Обозначение измерения или имя контейнера. |
| placementX | Double; ByVal; обязательный | Модельная X размерной линии, мм. |
| normalX | Double; ByVal; Optional; default=-1# | X-компонента стороны размерной/подписной линии; layout нормирует вектор. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:240

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    facade.VerticalExtent "Height", "Concrete", "H", 740#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:84.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-csectiondefinitionbuilder-horizontalextent"></a>
### CSectionDefinitionBuilder.HorizontalExtent

Измеряет полный горизонтальный габарит выбранного пути/группы. Это не длина пути и не исходная ширина до скругления.

```vb
Public Sub HorizontalExtent(ByVal annotationID As String, ByVal target As String, ByVal name As String, ByVal placementY As Double, Optional ByVal normalY As Double = 1#, Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| name | String; ByVal; обязательный | Обозначение измерения или имя контейнера. |
| placementY | Double; ByVal; обязательный | Модельная Y размерной линии, мм. |
| normalY | Double; ByVal; Optional; default=1# | Y-компонента стороны размерной/подписной линии. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:249

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestGeneratedContoursWithoutAnnotations с его подготовленными локальными объектами/входом.

```vb
        facade.HorizontalExtent "DIM_B", "Boundary", "B", 0#
```

Полный контекст: tests/modTestGeometryQuery.bas:775.

Native entrypoint: modTestGeometryQuery.RunGeneratedContourOwnershipTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiondefinitionbuilder-horizontaldistance"></a>
### CSectionDefinitionBuilder.HorizontalDistance

Объявляет размер между двумя заданными X на уровне placementY. DisplayIncrement округляет только подпись, не геометрию.

```vb
Public Sub HorizontalDistance(ByVal annotationID As String, ByVal name As String, ByVal startX As Double, ByVal endX As Double, ByVal placementY As Double, Optional ByVal normalY As Double = 1#, Optional ByVal comment As String = "", Optional ByVal displayIncrement As Double = 0#)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| name | String; ByVal; обязательный | Обозначение измерения или имя контейнера. |
| startX | Double; ByVal; обязательный | Модельная координата startX, мм; знаки соответствуют section XY/WCS. |
| endX | Double; ByVal; обязательный | Модельная координата endX, мм; знаки соответствуют section XY/WCS. |
| placementY | Double; ByVal; обязательный | Модельная Y размерной линии, мм. |
| normalY | Double; ByVal; Optional; default=1# | Y-компонента стороны размерной/подписной линии. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |
| displayIncrement | Double; ByVal; Optional; default=0# | Неотрицательный шаг округления только видимого справочного значения, мм; 0 означает отсутствие такого округления. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:258

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestAnnotationMeasurements с его подготовленными локальными объектами/входом.

```vb
    facade.HorizontalDistance "EXACT", "Exact", 0#, 123.6, 200#
```

Полный контекст: tests/modTestSectionRecipes.bas:334.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-verticaldistance"></a>
### CSectionDefinitionBuilder.VerticalDistance

Объявляет вертикальный размер между двумя Y на линии placementX; значение — модуль разности.

```vb
Public Sub VerticalDistance(ByVal annotationID As String, ByVal name As String, ByVal startY As Double, ByVal endY As Double, ByVal placementX As Double, Optional ByVal normalX As Double = -1#, Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| name | String; ByVal; обязательный | Обозначение измерения или имя контейнера. |
| startY | Double; ByVal; обязательный | Модельная координата startY, мм; знаки соответствуют section XY/WCS. |
| endY | Double; ByVal; обязательный | Модельная координата endY, мм; знаки соответствуют section XY/WCS. |
| placementX | Double; ByVal; обязательный | Модельная X размерной линии, мм. |
| normalX | Double; ByVal; Optional; default=-1# | X-компонента стороны размерной/подписной линии; layout нормирует вектор. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:270

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.AnnotationFacade с его подготовленными локальными объектами/входом.

```vb
    If previewPlacement Then facade.VerticalDistance "VerticalExplicit", "v", -100#, 0#, 150#, 1# Else facade.VerticalDistance "VerticalExplicit", "v", -100#, 0#, -50#
```

Полный контекст: tests/modTestRecipeAnnotations.bas:160.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-dimension"></a>
### CSectionDefinitionBuilder.Dimension

Измеряет между двумя именованными точками: Horizontal/Vertical проекция или Aligned расстояние. Проекция размещается через первую точку.

```vb
Public Sub Dimension(ByVal annotationID As String, ByVal startAnchorID As String, ByVal endAnchorID As String, ByVal name As String, Optional ByVal measurement As String = "Aligned", Optional ByVal normalX As Double = 0#, Optional ByVal normalY As Double = 0#, Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| startAnchorID | String; ByVal; обязательный | ID начальной модельной точки измерения. |
| endAnchorID | String; ByVal; обязательный | ID конечной модельной точки измерения. |
| name | String; ByVal; обязательный | Обозначение измерения или имя контейнера. |
| measurement | String; ByVal; Optional; default="Aligned" | Ровно Horizontal, Vertical или Aligned; значение чувствительно к указанному контракту. |
| normalX | Double; ByVal; Optional; default=0# | X-компонента стороны размерной/подписной линии; layout нормирует вектор. |
| normalY | Double; ByVal; Optional; default=0# | Y-компонента стороны размерной/подписной линии. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:282

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.AnnotationFacade с его подготовленными локальными объектами/входом.

```vb
    facade.Dimension "Diagonal", "A", "B", "s"
```

Полный контекст: tests/modTestRecipeAnnotations.bas:159.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-pathlength"></a>
### CSectionDefinitionBuilder.PathLength

Объявляет точную суммарную длину target-путей и текстовую привязку; не создаёт фиктивную соединяющую линию группы.

```vb
Public Sub PathLength(ByVal annotationID As String, ByVal target As String, ByVal placementAnchorID As String, Optional ByVal name As String = "L", Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| placementAnchorID | String; ByVal; обязательный | ID точки размещения текстового измерения. |
| name | String; ByVal; Optional; default="L" | Обозначение измерения или имя контейнера. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:295

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.AnnotationFacade с его подготовленными локальными объектами/входом.

```vb
    facade.PathLength "Length", "Boundary", "LengthNote"
```

Полный контекст: tests/modTestRecipeAnnotations.bas:171.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-radius"></a>
### CSectionDefinitionBuilder.Radius

Измеряет радиус конкретной Arc/Circle; параметр выбирает конечную точку радиуса. Прямая — ошибка.

```vb
Public Sub Radius(ByVal annotationID As String, ByVal pathID As String, ByVal segmentID As String, Optional ByVal parameter As Double = 0.5, Optional ByVal name As String = "R", Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| segmentID | String; ByVal; обязательный | Устойчивый ID существующего сегмента; исчезнувший Corner не подменяется индексом. |
| parameter | Double; ByVal; Optional; default=0.5 | Нормированный параметр точки сегмента [0;1], не расстояние по всему пути. |
| name | String; ByVal; Optional; default="R" | Обозначение измерения или имя контейнера. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:304

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.InvalidAnnotation с его подготовленными локальными объектами/входом.

```vb
        Case 2: facade.Radius "LineRadius", "Row", "Row"
```

Полный контекст: tests/modTestRecipeAnnotations.bas:190.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

<a id="api-csectiondefinitionbuilder-diameter"></a>
### CSectionDefinitionBuilder.Diameter

Измеряет диаметр конкретной Arc/Circle с противоположным концом на той же окружности. Прямая — ошибка.

```vb
Public Sub Diameter(ByVal annotationID As String, ByVal pathID As String, ByVal segmentID As String, Optional ByVal parameter As Double = 0.5, Optional ByVal name As String = "D", Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| segmentID | String; ByVal; обязательный | Устойчивый ID существующего сегмента; исчезнувший Corner не подменяется индексом. |
| parameter | Double; ByVal; Optional; default=0.5 | Нормированный параметр точки сегмента [0;1], не расстояние по всему пути. |
| name | String; ByVal; Optional; default="D" | Обозначение измерения или имя контейнера. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:309

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.AnnotationFacade с его подготовленными локальными объектами/входом.

```vb
        facade.Diameter "Diameter", "Boundary", "Boundary", 0#
```

Полный контекст: tests/modTestRecipeAnnotations.bas:169.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-text"></a>
### CSectionDefinitionBuilder.Text

Объявляет простой текст на именованной модельной привязке; пиксели/шрифт задаёт общий layout.

```vb
Public Sub Text(ByVal annotationID As String, ByVal anchorID As String, ByVal textValue As String, Optional ByVal comment As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| annotationID | String; ByVal; обязательный | Непустой уникальный ID аннотации. |
| anchorID | String; ByVal; обязательный | Непустой уникальный ID модельной привязки. |
| textValue | String; ByVal; обязательный | Текст подписи; Unicode сохраняется. |
| comment | String; ByVal; Optional; default="" | Пояснение происхождения/инженерного смысла; не управляющий статус. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:325

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.AnnotationFacade с его подготовленными локальными объектами/входом.

```vb
    facade.Text "Note", "TextNote", "Проверка привязки"
```

Полный контекст: tests/modTestRecipeAnnotations.bas:172.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiondefinitionbuilder-rebarlabel"></a>
### CSectionDefinitionBuilder.RebarLabel

Привязывает фактическую подпись группы к габариту target-пути, со стороны normalX/Y.

```vb
Public Sub RebarLabel(ByVal groupID As String, ByVal target As String, ByVal normalX As Double, ByVal normalY As Double, Optional ByVal axisDistance As Double = 0#)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| groupID | String; ByVal; обязательный | Смысловой ID группы; путь и арматурная annotation-group — разные контракты. |
| target | String; ByVal; обязательный | ID пути/PathGroup, разрешаемый в этом определении. |
| normalX | Double; ByVal; обязательный | X-компонента стороны размерной/подписной линии; layout нормирует вектор. |
| normalY | Double; ByVal; обязательный | Y-компонента стороны размерной/подписной линии. |
| axisDistance | Double; ByVal; Optional; default=0# | Положительное расстояние до оси, мм; не защитный слой до поверхности и не продольный setback. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:334

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeExamples.RoundedFrameDefinition с его подготовленными локальными объектами/входом.

```vb
    facade.RebarLabel "OuterBars", "Outer.Axis", 0#, 1#, 60#
```

Полный контекст: tests/modTestDeclarativeExamples.bas:79.

Native entrypoint: modTestDeclarativeExamples.RunRoundedFrameExampleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/OneClassExample/InputAndBuild.txt.

<a id="api-csectiondefinitionbuilder-rebarrowlabel"></a>
### CSectionDefinitionBuilder.RebarRowLabel

Привязывает фактическую подпись группы к концам исполненного ruleID.

```vb
Public Sub RebarRowLabel(ByVal groupID As String, ByVal ruleID As String, ByVal normalX As Double, ByVal normalY As Double, Optional ByVal axisDistance As Double = 0#)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| groupID | String; ByVal; обязательный | Смысловой ID группы; путь и арматурная annotation-group — разные контракты. |
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| normalX | Double; ByVal; обязательный | X-компонента стороны размерной/подписной линии; layout нормирует вектор. |
| normalY | Double; ByVal; обязательный | Y-компонента стороны размерной/подписной линии. |
| axisDistance | Double; ByVal; Optional; default=0# | Положительное расстояние до оси, мм; не защитный слой до поверхности и не продольный setback. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:343

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestPublicationAndCoincidence с его подготовленными локальными объектами/входом.

```vb
    facade.RebarRowLabel "Base", "Base", 0#, -1#
```

Полный контекст: tests/modTestSectionRecipes.bas:362.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-rebarrowextentlabel"></a>
### CSectionDefinitionBuilder.RebarRowExtentLabel

Привязывает подпись к фактическому габариту позиций правила; reverseDirection меняет ориентацию anchor-линии.

```vb
Public Sub RebarRowExtentLabel(ByVal groupID As String, ByVal ruleID As String, ByVal normalX As Double, ByVal normalY As Double, Optional ByVal axisDistance As Double = 0#, Optional ByVal reverseDirection As Boolean = False)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| groupID | String; ByVal; обязательный | Смысловой ID группы; путь и арматурная annotation-group — разные контракты. |
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| normalX | Double; ByVal; обязательный | X-компонента стороны размерной/подписной линии; layout нормирует вектор. |
| normalY | Double; ByVal; обязательный | Y-компонента стороны размерной/подписной линии. |
| axisDistance | Double; ByVal; Optional; default=0# | Положительное расстояние до оси, мм; не защитный слой до поверхности и не продольный setback. |
| reverseDirection | Boolean; ByVal; Optional; default=False | Обращает направление линии привязки подписи; физический ряд не меняется. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:353

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestAnnotationMeasurements с его подготовленными локальными объектами/входом.

```vb
    facade.RebarRowExtentLabel "CurveBars", "CurveMain", -1#, 0#, 20#, True
```

Полный контекст: tests/modTestSectionRecipes.bas:331.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-finish"></a>
### CSectionDefinitionBuilder.Finish

Проверяет контуры, ссылки, зависимости и аннотации; публикует неизменяемое CSectionDefinition. Фасад после этого закрыт.

```vb
Public Function Finish() As CSectionDefinition
```

Тип результата: CSectionDefinition. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:362

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Set definition = facade.Finish
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:88.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinitionbuilder-rebarrowextremelabel"></a>
### CSectionDefinitionBuilder.RebarRowExtremeLabel

Выбирает крайние созданные позиции в directionX/Y; сторона текста normalX/Y независима от выбора ряда.

```vb
Public Sub RebarRowExtremeLabel(ByVal groupID As String, ByVal ruleID As String, ByVal directionX As Double, ByVal directionY As Double, ByVal normalX As Double, ByVal normalY As Double, Optional ByVal axisDistance As Double = 0#)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| groupID | String; ByVal; обязательный | Смысловой ID группы; путь и арматурная annotation-group — разные контракты. |
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| directionX | Double; ByVal; обязательный | X-компонента направления проекции/выбора экстремума; вектор не нулевой, у RebarRowExtremeLabel единичный. |
| directionY | Double; ByVal; обязательный | Y-компонента направления проекции/выбора экстремума. |
| normalX | Double; ByVal; обязательный | X-компонента стороны размерной/подписной линии; layout нормирует вектор. |
| normalY | Double; ByVal; обязательный | Y-компонента стороны размерной/подписной линии. |
| axisDistance | Double; ByVal; Optional; default=0# | Положительное расстояние до оси, мм; не защитный слой до поверхности и не продольный setback. |

Жизненный цикл: New→Initialize один раз→декларации→Finish. Ссылки требуют ранее объявленных путей/привязок; правило зависимости разрешается при Finish. После Finish новые декларации запрещены.

Ошибки/исправление: 5530: пустые/повторные ID, неверный режим, отрицательные d/count/setbacks, незакрытый фасад. Query/path ошибки связывайте SourceMap; геометрию/направление исправляйте по диагностике.

Source: src/Section/CSectionDefinitionBuilder.cls:371

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestProjectionNormalsAndOrdinals с его подготовленными локальными объектами/входом.

```vb
    facade.RebarRowExtremeLabel "CurveBars", "CurveMain", 0#, 1#, 0#, 1#
```

Полный контекст: tests/modTestSectionRecipes.bas:265.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

## CGeometryPath

New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

<a id="api-cgeometrypath-lastdiagnostic"></a>
### CGeometryPath.LastDiagnostic

Последняя машинная диагностика; Nothing при отсутствии записанного события.

```vb
Public Property Get LastDiagnostic() As CGeometryDiagnostic
```

Тип результата: CGeometryDiagnostic. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:26

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set diagnostic = path.LastDiagnostic: Check "path.reason", Len(diagnostic.Reason) > 0
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:143.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-cgeometrypath-initialize"></a>
### CGeometryPath.Initialize

Создаёт mutable путь с непустым ID один раз.

```vb
Public Sub Initialize(ByVal pathID As String)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:30

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    Set path = New CGeometryPath: path.Initialize "Nose"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:47.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-cgeometrypath-addline"></a>
### CGeometryPath.AddLine

Добавляет прямой сегмент с устойчивым ID; начало совпадает с предыдущим концом.

```vb
Public Sub AddLine(ByVal segmentID As String, ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| segmentID | String; ByVal; обязательный | Устойчивый ID существующего сегмента; исчезнувший Corner не подменяется индексом. |
| x1 | Double; ByVal; обязательный | Модельная координата x1, мм; знаки соответствуют section XY/WCS. |
| y1 | Double; ByVal; обязательный | Модельная координата y1, мм; знаки соответствуют section XY/WCS. |
| x2 | Double; ByVal; обязательный | Модельная координата x2, мм; знаки соответствуют section XY/WCS. |
| y2 | Double; ByVal; обязательный | Модельная координата y2, мм; знаки соответствуют section XY/WCS. |

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:37

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.CompoundPath с его подготовленными локальными объектами/входом.

```vb
    path.AddLine "Bottom", 0#, 0#, 100#, 0#
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:585.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-addarc"></a>
### CGeometryPath.AddArc

Добавляет аналитическую дугу по центру/R/startAngle/sweep, без хордовой аппроксимации.

```vb
Public Sub AddArc(ByVal segmentID As String, ByVal centerX As Double, ByVal centerY As Double, ByVal radius As Double, ByVal startAngle As Double, ByVal sweep As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| segmentID | String; ByVal; обязательный | Устойчивый ID существующего сегмента; исчезнувший Corner не подменяется индексом. |
| centerX | Double; ByVal; обязательный | Модельная координата centerX, мм; знаки соответствуют section XY/WCS. |
| centerY | Double; ByVal; обязательный | Модельная координата centerY, мм; знаки соответствуют section XY/WCS. |
| radius | Double; ByVal; обязательный | Положительный радиус, мм. |
| startAngle | Double; ByVal; обязательный | Начальный угол, радианы; от +X. |
| sweep | Double; ByVal; обязательный | Signed sweep, радианы: CCW положителен, CW отрицателен, 0 запрещён, \|sweep\|≤2*pi. |

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:46

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidPathRejected с его подготовленными локальными объектами/входом.

```vb
        Case 3: path.AddArc "ZeroSweep", 0#, 0#, 1#, 0#, 0#
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:601.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-seal"></a>
### CGeometryPath.Seal

Публикует путь. closed=True проверяет совпадение концов, не достраивает соединение.

```vb
Public Sub Seal(Optional ByVal closed As Boolean = False)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| closed | Boolean; ByVal; Optional; default=False | Явный Boolean режима замыкания/касательной; не исправляет геометрию автоматически. |

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:61

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestJointTangents с его подготовленными локальными объектами/входом.

```vb
    path.Seal
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:517.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-id"></a>
### CGeometryPath.ID

Смысловой ID этого пути.

```vb
Public Property Get ID() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:76

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestHollowRectangleGeometry с его подготовленными локальными объектами/входом.

```vb
    facade.Outer "OUTER", path.ID
```

Полный контекст: tests/modTestGeometry.bas:1911.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-segmentcount"></a>
### CGeometryPath.SegmentCount

Число аналитических line/arc сегментов.

```vb
Public Property Get SegmentCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:77

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunRoundedPolygonTests с его подготовленными локальными объектами/входом.

```vb
    For i = 1 To path.SegmentCount
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:162.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunRoundedPolygonTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/RoundedPolygons.txt.

<a id="api-cgeometrypath-issealed"></a>
### CGeometryPath.IsSealed

Опубликован ли объект; published геометрия не изменяется.

```vb
Public Property Get IsSealed() As Boolean
```

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:78

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestLine с его подготовленными локальными объектами/входом.

```vb
    Check "line.sealed", changed.IsSealed And path.IsSealed
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:430.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-isclosed"></a>
### CGeometryPath.IsClosed

Замкнут ли фактический путь, без фиктивного соединения.

```vb
Public Property Get IsClosed() As Boolean
```

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:79

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestArcs с его подготовленными локальными объектами/входом.

```vb
    Check "circle.closed", path.IsClosed
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:472.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-length"></a>
### CGeometryPath.Length

Точная суммарная длина пути, мм.

```vb
Public Property Get Length() As Double
```

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:80

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidPathRejected с его подготовленными локальными объектами/входом.

```vb
        Case 6: value = path.Length
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:604.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-segmentid"></a>
### CGeometryPath.SegmentID

Возвращает смысловой ID сегмента по индексу.

```vb
Public Property Get SegmentID(ByVal index As Long) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:81

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestCompoundPath с его подготовленными локальными объектами/входом.

```vb
    Check "compound.slice.id", part.SegmentID(2) = "Corner"
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:499.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-sourcepathid"></a>
### CGeometryPath.SourcePathID

ID исходного пути сегмента после slice/transform/offset.

```vb
Public Property Get SourcePathID(ByVal index As Long) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:85

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Check "anchor.facade.source", changed.SourcePathID(1) = "Outer" And changed.SourceSegmentID(1) = "Edge.BR"
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:90.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-sourcesegmentid"></a>
### CGeometryPath.SourceSegmentID

Смысловой исходный ID сегмента, сохраняемый при распаде/переименовании результата.

```vb
Public Property Get SourceSegmentID(ByVal index As Long) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:89

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunAdvancedGuideExamples с его подготовленными локальными объектами/входом.

```vb
        Check "advanced.chain.namedNose." & CStr(useMaxStep), path.SourceSegmentID(3) = "NoseArc"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:18.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-cgeometrypath-sourcestartparameter"></a>
### CGeometryPath.SourceStartParameter

Начальный параметр исходного сегмента; может выйти за [0;1] при явном продлении прямой.

```vb
Public Property Get SourceStartParameter(ByVal index As Long) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:93

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Near "anchor.reverse.first", part.SourceStartParameter(1), 0.75
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:64.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-sourceendparameter"></a>
### CGeometryPath.SourceEndParameter

Конечный параметр исходного сегмента, включая обращённый обход.

```vb
Public Property Get SourceEndParameter(ByVal index As Long) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:97

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Near "anchor.wrap.first.end", part.SourceEndParameter(1), 1#
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:56.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-segmentindex"></a>
### CGeometryPath.SegmentIndex

Разрешает существующий смысловой ID в текущий индекс; исчезнувшая дуга даёт MISSING_SEGMENT.

```vb
Public Function SegmentIndex(ByVal segmentID As String) As Long
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| segmentID | String; ByVal; обязательный | Устойчивый ID существующего сегмента; исчезнувший Corner не подменяется индексом. |

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:101

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestTaperedRoundedRectangle с его подготовленными локальными объектами/входом.

```vb
    path.CopySegment path.SegmentIndex("Edge.TL"), top
```

Полный контекст: tests/modTestGeometry.bas:1707.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-anchorstation"></a>
### CGeometryPath.AnchorStation

Переводит ID сегмента и параметр [0;1] в станцию вдоль полного пути, мм.

```vb
Public Function AnchorStation(ByVal segmentID As String, Optional ByVal parameter As Double = 0#) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| segmentID | String; ByVal; обязательный | Устойчивый ID существующего сегмента; исчезнувший Corner не подменяется индексом. |
| parameter | Double; ByVal; Optional; default=0# | Нормированный параметр точки сегмента [0;1], не расстояние по всему пути. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:110

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidAnchorRejected с его подготовленными локальными объектами/входом.

```vb
            station = path.AnchorStation("Corner.BL")
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:121.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-withid"></a>
### CGeometryPath.WithID

Копирует опубликованный путь с новым ID, сохраняя сегментные ссылки и исходное происхождение.

```vb
Public Function WithID(ByVal pathID As String) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:118

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidAnchorRejected с его подготовленными локальными объектами/входом.

```vb
        Case 9: Set part = path.WithID("")
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:122.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-betweenanchors"></a>
### CGeometryPath.BetweenAnchors

Возвращает точную цепочку между привязками с явным направлением и правилом полного обхода.

```vb
Public Function BetweenAnchors(ByVal pathID As String, ByVal startSegmentID As String, ByVal startParameter As Double, ByVal endSegmentID As String, ByVal endParameter As Double, Optional ByVal forward As Boolean = True, Optional ByVal fullLoopIfSame As Boolean = False) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| startSegmentID | String; ByVal; обязательный | Сегмент начальной привязки цепочки. |
| startParameter | Double; ByVal; обязательный | Параметр начальной точки выбранного сегмента [0;1]. |
| endSegmentID | String; ByVal; обязательный | Сегмент конечной привязки цепочки. |
| endParameter | Double; ByVal; обязательный | Параметр конечной точки выбранного сегмента [0;1]. |
| forward | Boolean; ByVal; Optional; default=True | Явное направление следования исходному обходу; False — противоположное. |
| fullLoopIfSame | Boolean; ByVal; Optional; default=False | Полный оборот при совпавших привязках замкнутого пути; иначе нулевая цепочка недопустима. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:130

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Set part = path.BetweenAnchors("Chain", "Bottom", 0.25, "Corner", 0.5)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:27.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-atdistance"></a>
### CGeometryPath.AtDistance

Возвращает точку и единичную касательную на станции. На стыке можно явно выбрать входящую касательную.

```vb
Public Sub AtDistance(ByVal distance As Double, ByRef x As Double, ByRef y As Double, ByRef tangentX As Double, ByRef tangentY As Double, Optional ByVal incomingTangentAtJoint As Boolean = False)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| distance | Double; ByVal; обязательный | Длина/станция/граница distance, внутренние мм; направление и пределы задаёт выбранный запрос. |
| x | Double; ByRef; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| y | Double; ByRef; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| tangentX | Double; ByRef; обязательный | Компонента единичной касательной, без размерности. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| tangentY | Double; ByRef; обязательный | Компонента единичной касательной, без размерности. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| incomingTangentAtJoint | Boolean; ByVal; Optional; default=False | Явный Boolean режима замыкания/касательной; не исправляет геометрию автоматически. |

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:158

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    part.AtDistance 0#, x, y, tx, ty
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:46.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-projectionbounds"></a>
### CGeometryPath.ProjectionBounds

Возвращает действительные min/max проекции по нормированному направлению, с экстремумами дуг.

```vb
Public Sub ProjectionBounds(ByVal directionX As Double, ByVal directionY As Double, ByRef minimum As Double, ByRef maximum As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| directionX | Double; ByVal; обязательный | X-компонента направления проекции/выбора экстремума; вектор не нулевой, у RebarRowExtremeLabel единичный. |
| directionY | Double; ByVal; обязательный | Y-компонента направления проекции/выбора экстремума. |
| minimum | Double; ByRef; обязательный | Длина/станция/граница minimum, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| maximum | Double; ByRef; обязательный | Длина/станция/граница maximum, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:180

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestLine с его подготовленными локальными объектами/входом.

```vb
    path.ProjectionBounds 2#, 0#, minimum, maximum
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:418.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-slice"></a>
### CGeometryPath.Slice

Обрезает полный непрерывный путь по длине; точные дуги и source parameters сохраняются.

```vb
Public Function Slice(ByVal startDistance As Double, ByVal endDistance As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| startDistance | Double; ByVal; обязательный | Станция вдоль полного пути, мм, в [0;Length]; endDistance строго больше startDistance. |
| endDistance | Double; ByVal; обязательный | Станция вдоль полного пути, мм, в [0;Length]; endDistance строго больше startDistance. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:195

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Set part = changed.Slice(10#, 50#)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:38.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cgeometrypath-reversed"></a>
### CGeometryPath.Reversed

Копирует путь с обратным порядком сегментов/обходом; signed sweep и source parameters обращаются.

```vb
Public Function Reversed() As CGeometryPath
```

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:238

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestLine с его подготовленными локальными объектами/входом.

```vb
    Set changed = path.Reversed
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:420.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-transformed"></a>
### CGeometryPath.Transformed

Копирует путь изометрией: отражение по локальной X, поворот, перенос; длина сохраняется.

```vb
Public Function Transformed(ByVal shiftX As Double, ByVal shiftY As Double, Optional ByVal rotation As Double = 0#, Optional ByVal reflectX As Boolean = False) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| shiftX | Double; ByVal; обязательный | Перенос по X, мм. |
| shiftY | Double; ByVal; обязательный | Перенос по Y, мм. |
| rotation | Double; ByVal; Optional; default=0# | Угол поворота вокруг (0,0), радианы, CCW положителен. |
| reflectX | Boolean; ByVal; Optional; default=False | Отражение относительно локальной оси X перед поворотом и переносом. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:252

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestLine с его подготовленными локальными объектами/входом.

```vb
    Set changed = path.Transformed(10#, 20#, GEOM_PI / 2#)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:424.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

<a id="api-cgeometrypath-rayhit"></a>
### CGeometryPath.RayHit

Находит ближайшее положительное пересечение луча с конечным путём; False не экстраполирует линию.

```vb
Public Function RayHit(ByVal originX As Double, ByVal originY As Double, ByVal directionX As Double, ByVal directionY As Double, ByRef pathDistance As Double, ByRef rayDistance As Double) As Boolean
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| originX | Double; ByVal; обязательный | Модельная координата originX, мм; знаки соответствуют section XY/WCS. |
| originY | Double; ByVal; обязательный | Модельная координата originY, мм; знаки соответствуют section XY/WCS. |
| directionX | Double; ByVal; обязательный | X-компонента направления проекции/выбора экстремума; вектор не нулевой, у RebarRowExtremeLabel единичный. |
| directionY | Double; ByVal; обязательный | Y-компонента направления проекции/выбора экстремума. |
| pathDistance | Double; ByRef; обязательный | Длина/станция/граница pathDistance, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| rayDistance | Double; ByRef; обязательный | Длина/станция/граница rayDistance, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New→Initialize→AddLine/AddArc→Seal. Методы чтения/slice/transform требуют Seal. Они возвращают отдельные опубликованные пути; исходный не меняется.

Ошибки/исправление: 5520: пустой ID/сегмент, разрыв, невалидный R/sweep, незамкнутые концы, отсутствие сегмента, станция вне пути. Исправьте геометрию/ID/рабочий интервал.

Source: src/Geometry/CGeometryPath.cls:274

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.TestRays с его подготовленными локальными объектами/входом.

```vb
    Check "ray.circle.hit", path.RayHit(-20#, 0#, 2#, 0#, station, distance)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:554.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunPathTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/AnalyticPaths.txt.

## CSectionDefinition

Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

<a id="api-csectiondefinition-lastdiagnostic"></a>
### CSectionDefinition.LastDiagnostic

Последняя машинная диагностика; Nothing при отсутствии записанного события.

```vb
Public Property Get LastDiagnostic() As CGeometryDiagnostic
```

Тип результата: CGeometryDiagnostic. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:23

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set diagnostic = definition.LastDiagnostic: Check "definition.successDiagnostic", diagnostic Is Nothing
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:117.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinition-anchorcoordinates"></a>
### CSectionDefinition.AnchorCoordinates

Возвращает координаты именованной привязки в скалярные переменные вызывающего кода.

```vb
Public Sub AnchorCoordinates(ByVal anchorID As String, ByRef x As Double, ByRef y As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| anchorID | String; ByVal; обязательный | Непустой уникальный ID модельной привязки. |
| x | Double; ByRef; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| y | Double; ByRef; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:44

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.RunRecipeAnnotationTests с его подготовленными локальными объектами/входом.

```vb
    definition.AnchorCoordinates "B", x, y
```

Полный контекст: tests/modTestRecipeAnnotations.bas:17.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

<a id="api-csectiondefinition-sourcereference"></a>
### CSectionDefinition.SourceReference

Читает скалярный SourceMap по ID; отсутствующая связь возвращает пустую строку.

```vb
Public Function SourceReference(ByVal entityID As String) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| entityID | String; ByVal; обязательный | Смысловой ID сущности для SourceMap. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:55

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.RunRecipeAnnotationTests с его подготовленными локальными объектами/входом.

```vb
    Check "source.scalar", definition.SourceReference("Diagonal") = "ProgramInputs.PointB"
```

Полный контекст: tests/modTestRecipeAnnotations.bas:15.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

<a id="api-csectiondefinition-typeid"></a>
### CSectionDefinition.TypeID

Смысловое имя типа опубликованного определения.

```vb
Public Property Get TypeID() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:59

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "definition.type", definition.TypeID = "ApiRead"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:113.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinition-schemaversion"></a>
### CSectionDefinition.SchemaVersion

Положительная версия схемы определения.

```vb
Public Property Get SchemaVersion() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:60

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "definition.schema", definition.SchemaVersion = 2
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:114.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinition-issealed"></a>
### CSectionDefinition.IsSealed

Опубликован ли объект; published геометрия не изменяется.

```vb
Public Property Get IsSealed() As Boolean
```

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:61

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeDefinitionTests с его подготовленными локальными объектами/входом.

```vb
    Check "definition.sealed", definition.IsSealed
```

Полный контекст: tests/modTestSectionRecipes.bas:555.

Native entrypoint: modTestSectionRecipes.RunRecipeDefinitionTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinition-pathcount"></a>
### CSectionDefinition.PathCount

Число зарегистрированных путей.

```vb
Public Property Get PathCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:62

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunPathAnchorTests с его подготовленными локальными объектами/входом.

```vb
    Check "anchor.facade.registered", definition.PathCount = 3 And definition.IsSealed
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:89.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinition-loopcount"></a>
### CSectionDefinition.LoopCount

Число подготовленных материальных loops.

```vb
Public Property Get LoopCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:63

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeDefinitionTests с его подготовленными локальными объектами/входом.

```vb
    Check "definition.loops", definition.LoopCount = 3 And region.LoopCount = 3
```

Полный контекст: tests/modTestSectionRecipes.bas:556.

Native entrypoint: modTestSectionRecipes.RunRecipeDefinitionTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinition-rulecount"></a>
### CSectionDefinition.RuleCount

Число объявленных правил, включая выключенные.

```vb
Public Property Get RuleCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:64

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.CircleInputCase с его подготовленными локальными объектами/входом.

```vb
    If scenario = 3 Then CircleInputCase = (definition.RuleCount = 0): Exit Function
```

Полный контекст: tests/modTestSectionRecipes.bas:641.

Native entrypoint: modTestSectionRecipes.RunCircleRecipeInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CircleEvidencePack/Actual/InputTests.txt.

<a id="api-csectiondefinition-annotationcount"></a>
### CSectionDefinition.AnnotationCount

Число объявленных annotation rules.

```vb
Public Property Get AnnotationCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:65

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "definition.annotationCount", definition.AnnotationCount = 1
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:115.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinition-path"></a>
### CSectionDefinition.Path

Читает опубликованный неизменяемый путь по ID.

```vb
Public Function Path(ByVal pathID As String) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:67

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set path = definition.Path("Row")
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:137.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinition-targetpaths"></a>
### CSectionDefinition.TargetPaths

Возвращает ID одного пути или массив независимых путей группы.

```vb
Public Function TargetPaths(ByVal targetID As String) As Variant
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| targetID | String; ByVal; обязательный | ID пути или группы путей. |

Тип результата: Variant. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:73

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    ids = definition.TargetPaths("Rows"): Check "group.independent", UBound(ids) - LBound(ids) + 1 = 2
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:116.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiondefinition-concretedomain"></a>
### CSectionDefinition.ConcreteDomain

Возвращает clone подготовленной бетонной области, без Excel или повторной интерпретации рецепта.

```vb
Public Function ConcreteDomain() As CConcreteRegion
```

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:83

Минимальный вызов; требуемый контекст: В теле modTestRecipeSetbacks.RunRecipeSetbackInputTests с его подготовленными локальными объектами/входом.

```vb
    geometryArea = def.ConcreteDomain.Area
```

Полный контекст: tests/modTestRecipeSetbacks.bas:202.

Native entrypoint: modTestRecipeSetbacks.RunRecipeSetbackInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalGeometry.txt.

<a id="api-csectiondefinition-materialcontours"></a>
### CSectionDefinition.MaterialContours

Возвращает отдельный контейнер аналитических материальных Outer/Opening.

```vb
Public Function MaterialContours() As CSectionContours
```

Тип результата: CSectionContours. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:280

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeDefinitionTests с его подготовленными локальными объектами/входом.

```vb
    Set contours = definition.MaterialContours
```

Полный контекст: tests/modTestSectionRecipes.bas:561.

Native entrypoint: modTestSectionRecipes.RunRecipeDefinitionTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiondefinition-writecontours"></a>
### CSectionDefinition.WriteContours

Записывает единственный контурный snapshot в переданный контейнер; destination предварительно очищается.

```vb
Public Sub WriteContours(ByVal result As CSectionContours)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| result | CSectionContours; ByVal; обязательный | Подготовленный объект/контейнер выбранного запроса, без повторного чтения Excel или назначения типа. |

Жизненный цикл: Получается из Finish. Геометрия, правила и SourceMap неизменяемы; наружу возвращаются скаляры, копии массивов или sealed paths/clones.

Ошибки/исправление: 5530 либо исходный query/path код: топология Outer/Opening, отсутствующий target/anchor/rule, циклы зависимостей. Не выбирать соседний сегмент или fallback тип молча.

Source: src/Section/CSectionDefinition.cls:287

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestRoundedRectangleContourAnnotations с его подготовленными локальными объектами/входом.

```vb
    geom.WriteContours model.Contours
```

Полный контекст: tests/modTestGeometry.bas:1741.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

## CRebarRuleOptions

New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

<a id="api-crebarruleoptions-startsetback"></a>
### CRebarRuleOptions.StartSetback

Начальное отсечение вдоль каждого target-пути, мм≥0; у полного ClosedUniform 0.

```vb
Public StartSetback As Double
```

Default после New: 0#. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:14

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    options.StartSetback = 10#: options.EndSetback = 20#
```

Полный контекст: tests/modTestSectionRecipes.bas:163.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-endsetback"></a>
### CRebarRuleOptions.EndSetback

Конечное отсечение вдоль каждого target-пути, мм≥0; ProjectFrom фильтрует hit без перераспределения.

```vb
Public EndSetback As Double
```

Default после New: 0#. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:15

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    options.StartSetback = 10#: options.EndSetback = 20#
```

Полный контекст: tests/modTestSectionRecipes.bas:163.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-endmode"></a>
### CRebarRuleOptions.EndMode

IncludeBoth/ExcludeBoth/IncludeStart/IncludeEnd/ClosedUniform; последние требуют соответствующей замкнутости.

```vb
Public EndMode As ERebarEndMode
```

Default после New: IncludeBoth. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERebarEndMode. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:16

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    options.EndMode = ExcludeBoth
```

Полный контекст: tests/modTestSectionRecipes.bas:183.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-distributionscope"></a>
### CRebarRuleOptions.DistributionScope

Только PerPath: количество/шаг/setbacks отдельно для каждого пути группы.

```vb
Public DistributionScope As ERebarDistributionScope
```

Default после New: PerPath. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERebarDistributionScope. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:17

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    options.DistributionScope = PerPath: options.StartSetback = 20#: options.EndSetback = 30#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:61.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-crebarruleoptions-remainderplacement"></a>
### CRebarRuleOptions.RemainderPlacement

RemainderStart/End/Center: положение остатка для точного шага.

```vb
Public RemainderPlacement As ERemainderPlacement
```

Default после New: RemainderCenter. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERemainderPlacement. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:18

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "defaults.remainder", options.RemainderPlacement = RemainderCenter
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:105.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-crebarruleoptions-tangentoffset"></a>
### CRebarRuleOptions.TangentOffset

Локальное связанное смещение вдоль касательной, мм; signed, не независимый шаг ряда.

```vb
Public TangentOffset As Double
```

Default после New: 0#. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:19

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "defaults.tangent", options.TangentOffset = 0#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:106.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-crebarruleoptions-normaloffset"></a>
### CRebarRuleOptions.NormalOffset

Локальное связанное смещение по левой нормали (-ty,tx), мм; signed.

```vb
Public NormalOffset As Double
```

Default после New: 0#. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:20

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestRuleJointTangents с его подготовленными локальными объектами/входом.

```vb
        Set options = New CRebarRuleOptions: options.NormalOffset = 10#
```

Полный контекст: tests/modTestSectionRecipes.bas:312.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-everysecond"></a>
### CRebarRuleOptions.EverySecond

Брать каждую вторую исходную позицию по SourceOrdinal, начиная с первой.

```vb
Public EverySecond As Boolean
```

Default после New: False. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:21

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    options.NormalOffset = 10#: options.EverySecond = True: options.SourceSuffix = "_Extra"
```

Полный контекст: tests/modTestSectionRecipes.bas:197.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-incomingtangentatjoint"></a>
### CRebarRuleOptions.IncomingTangentAtJoint

На станции стыка брать входящую касательную вместо default outgoing.

```vb
Public IncomingTangentAtJoint As Boolean
```

Default после New: False. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:22

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestRuleJointTangents с его подготовленными локальными объектами/входом.

```vb
        options.IncomingTangentAtJoint = Not options.IncomingTangentAtJoint
```

Полный контекст: tests/modTestSectionRecipes.bas:311.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-directionx"></a>
### CRebarRuleOptions.DirectionX

Глобальная X направления ProjectFrom, используется при SourceNormalSign=0.

```vb
Public DirectionX As Double
```

Default после New: 0#. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:23

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "defaults.projectionDirection", options.DirectionX = 0# And options.DirectionY = 0#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:107.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-crebarruleoptions-directiony"></a>
### CRebarRuleOptions.DirectionY

Глобальная Y направления ProjectFrom; направление не нулевое.

```vb
Public DirectionY As Double
```

Default после New: 0#. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:24

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.InvalidRuleRejected с его подготовленными локальными объектами/входом.

```vb
            options.DirectionY = -1#
```

Полный контекст: tests/modTestSectionRecipes.bas:525.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-sourcenormalsign"></a>
### CRebarRuleOptions.SourceNormalSign

-1/0/+1: локальная нормаль исходного ряда или глобальное DirectionX/Y при 0.

```vb
Public SourceNormalSign As Double
```

Default после New: 0#. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:25

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestProjectionNormalsAndOrdinals с его подготовленными локальными объектами/входом.

```vb
    options.SourceNormalSign = 1#
```

Полный контекст: tests/modTestSectionRecipes.bas:264.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-successfulprojectionordinal"></a>
### CRebarRuleOptions.SuccessfulProjectionOrdinal

Нумеровать SourceOrdinal успешных hit подряд; False сохраняет исходные ordinals с пропусками.

```vb
Public SuccessfulProjectionOrdinal As Boolean
```

Default после New: False. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:26

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestProjectionNormalsAndOrdinals с его подготовленными локальными объектами/входом.

```vb
        options.SuccessfulProjectionOrdinal = Not options.SuccessfulProjectionOrdinal
```

Полный контекст: tests/modTestSectionRecipes.bas:283.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-newpublicationroot"></a>
### CRebarRuleOptions.NewPublicationRoot

У ProjectFrom начинает новый корень публикации по успешным позициям.

```vb
Public NewPublicationRoot As Boolean
```

Default после New: False. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:27

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestProjectionNormalsAndOrdinals с его подготовленными локальными объектами/входом.

```vb
        options.SuccessfulProjectionOrdinal = (mode = 1): options.NewPublicationRoot = True
```

Полный контекст: tests/modTestSectionRecipes.bas:280.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-skipmissingprojection"></a>
### CRebarRuleOptions.SkipMissingProjection

Разрешить пропуск без hit с PROJECTION_MISSING; False выдаёт ошибку.

```vb
Public SkipMissingProjection As Boolean
```

Default после New: False. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:28

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    options.DirectionY = 1#: options.SkipMissingProjection = True
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:78.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-crebarruleoptions-publication"></a>
### CRebarRuleOptions.Publication

PublishByRule или PublishPerSourcePosition; влияет на вывод, не геометрический шаг.

```vb
Public Publication As ERebarPublication
```

Default после New: PublishByRule. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERebarPublication. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:29

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestProjectionNormalsAndOrdinals с его подготовленными локальными объектами/входом.

```vb
        options.Publication = PublishPerSourcePosition
```

Полный контекст: tests/modTestSectionRecipes.bas:281.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-positionorder"></a>
### CRebarRuleOptions.PositionOrder

AlongPath или FromPathMiddle; геометрические станции/исходные ordinals сохраняются.

```vb
Public PositionOrder As ERebarPositionOrder
```

Default после New: AlongPath. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERebarPositionOrder. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:30

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestPublicationAndCoincidence с его подготовленными локальными объектами/входом.

```vb
    options.PositionOrder = FromPathMiddle: options.Publication = PublishPerSourcePosition
```

Полный контекст: tests/modTestSectionRecipes.bas:356.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-coincidence"></a>
### CRebarRuleOptions.Coincidence

RejectCoincidence/MergeIdentical/KeepPublishedOwner; последнее сохраняет явно выбранного опубликованного владельца.

```vb
Public Coincidence As ERebarCoincidence
```

Default после New: RejectCoincidence. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERebarCoincidence. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:31

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestPublicationAndCoincidence с его подготовленными локальными объектами/входом.

```vb
    options.AnnotationGroup = "Second": options.Coincidence = MergeIdentical
```

Полный контекст: tests/modTestSectionRecipes.bas:373.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-placementcheck"></a>
### CRebarRuleOptions.PlacementCheck

CheckCenter или CheckFullDisk относительно Outer/Opening; ужесточение задаётся явно.

```vb
Public PlacementCheck As ERebarPlacementCheck
```

Default после New: CheckCenter. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERebarPlacementCheck. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:32

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    options.PlacementCheck = CheckFullDisk: options.OverlapPolicy = RejectOverlap
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:63.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-crebarruleoptions-overlappolicy"></a>
### CRebarRuleOptions.OverlapPolicy

ReportOverlap или RejectOverlap. Контакт допустим; нормативный минимальный зазор не вводится.

```vb
Public OverlapPolicy As ERebarOverlapPolicy
```

Default после New: ReportOverlap. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: ERebarOverlapPolicy. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:33

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
        If mode = 2 Then options.OverlapPolicy = RejectOverlap
```

Полный контекст: tests/modTestRecipeOperations.bas:102.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleoptions-sourceprefix"></a>
### CRebarRuleOptions.SourcePrefix

Префикс SourcePositionId; пустой использует RuleId+'.' либо связь source+suffix.

```vb
Public SourcePrefix As String
```

Default после New: vbNullString. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:34

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    options.SourcePrefix = "P"
```

Полный контекст: tests/modTestSectionRecipes.bas:194.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-sourcesuffix"></a>
### CRebarRuleOptions.SourceSuffix

Суффикс SourcePositionId, в том числе для связанных рядов.

```vb
Public SourceSuffix As String
```

Default после New: vbNullString. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:35

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    options.DirectionY = 1#: options.StartSetback = 110#: options.SourceSuffix = "_Hit"
```

Полный контекст: tests/modTestSectionRecipes.bas:224.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleoptions-annotationgroup"></a>
### CRebarRuleOptions.AnnotationGroup

Смысловая принадлежность подписи физического стержня; не расчётная группа трещин СП35.

```vb
Public AnnotationGroup As String
```

Default после New: vbNullString. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:36

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    options.AnnotationGroup = "RowsLabel"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:62.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-crebarruleoptions-comment"></a>
### CRebarRuleOptions.Comment

Инженерное пояснение правила; не selector или ResultCode.

```vb
Public Comment As String
```

Default после New: vbNullString. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:37

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    options.StartSetback = 20#: options.EndSetback = 30#: options.Comment = "Guide": options.SourceReference = "ProgramInputs.Row"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:109.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-crebarruleoptions-sourcereference"></a>
### CRebarRuleOptions.SourceReference

Реальные адреса исходных параметров правила или программная ссылка.

```vb
Public SourceReference As String
```

Default после New: vbNullString. Поле изменяется до объявления правила; facade копирует его значение.

Тип записываемого поля: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: New задаёт defaults; автор меняет поля до объявления правила. Фасад копирует options в definition; последующее изменение options не меняет правило.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Section/CRebarRuleOptions.cls:38

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    options.StartSetback = 20#: options.EndSetback = 30#: options.Comment = "Guide": options.SourceReference = "ProgramInputs.Row"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:109.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

## CGeometryDiagnostic

Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

<a id="api-cgeometrydiagnostic-code"></a>
### CGeometryDiagnostic.Code

Машинный код причины; назначается напрямую, не извлекается из русского текста.

```vb
Public Property Get Code() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Geometry/CGeometryDiagnostic.cls:24

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "overlap.reject", i = vbObjectError + 5530 And diagnostic.Code = "BAR_OVERLAP"
```

Полный контекст: tests/modTestRecipeOperations.bas:112.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-cgeometrydiagnostic-entityid"></a>
### CGeometryDiagnostic.EntityID

Смысловой ID сущности отказа, если он известен этому сервису.

```vb
Public Property Get EntityID() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Geometry/CGeometryDiagnostic.cls:25

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "overlap.source", diagnostic.EntityID = "Bars" And diagnostic.SourceReference = "ProgramInputs.Spacing"
```

Полный контекст: tests/modTestRecipeOperations.bas:113.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-cgeometrydiagnostic-relatedentityid"></a>
### CGeometryDiagnostic.RelatedEntityID

ID связанного сегмента/позиции/стержня для локализации причины.

```vb
Public Property Get RelatedEntityID() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Geometry/CGeometryDiagnostic.cls:26

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.InvalidOperation с его подготовленными локальными объектами/входом.

```vb
    If InvalidOperation Then InvalidOperation = diagnostic.Code = expected And diagnostic.EntityID = "Failed" And Len(diagnostic.RelatedEntityID) > 0
```

Полный контекст: tests/modTestRecipeOperations.bas:90.

Native entrypoint: modTestRecipeOperations.RunRecipeOperationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-cgeometrydiagnostic-reason"></a>
### CGeometryDiagnostic.Reason

Человекочитаемая причина; не selector/status.

```vb
Public Property Get Reason() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Geometry/CGeometryDiagnostic.cls:27

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "facade.offsetReason", Len(diagnostic.Reason) > 0
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:157.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-cgeometrydiagnostic-detail1"></a>
### CGeometryDiagnostic.Detail1

Первое численное поле конкретного Code; единицы определяет Code.

```vb
Public Property Get Detail1() As Double
```

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Geometry/CGeometryDiagnostic.cls:28

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Near "overlap.numeric.gap", diagnostic.Detail1, -10#
```

Полный контекст: tests/modTestRecipeOperations.bas:114.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-cgeometrydiagnostic-detail2"></a>
### CGeometryDiagnostic.Detail2

Второе численное поле конкретного Code.

```vb
Public Property Get Detail2() As Double
```

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Geometry/CGeometryDiagnostic.cls:29

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.InvalidOperation с его подготовленными локальными объектами/входом.

```vb
    If scenario = 2 And InvalidOperation Then InvalidOperation = diagnostic.Detail1 = 10# And diagnostic.Detail2 = 20#
```

Полный контекст: tests/modTestRecipeOperations.bas:91.

Native entrypoint: modTestRecipeOperations.RunRecipeOperationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-cgeometrydiagnostic-sourcereference"></a>
### CGeometryDiagnostic.SourceReference

Реальный адрес/программный источник, добавленный SourceMap или правилом.

```vb
Public Property Get SourceReference() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Создаётся сервисом как immutable snapshot. Читайте через LastDiagnostic/DiagnosticAt; диагностический объект не изменяет геометрию или статусы.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Geometry/CGeometryDiagnostic.cls:30

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "overlap.source", diagnostic.EntityID = "Bars" And diagnostic.SourceReference = "ProgramInputs.Spacing"
```

Полный контекст: tests/modTestRecipeOperations.bas:113.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

## CSectionInputTable

Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

<a id="api-csectioninputtable-initialize"></a>
### CSectionInputTable.Initialize

Копирует двумерные scalar values и согласованные addresses один раз; Excel-объекты не сохраняет.

```vb
Public Sub Initialize(ByVal tableName As String, ByVal values As Variant, Optional ByVal addresses As Variant)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| tableName | String; ByVal; обязательный | Имя единственного корневого входного блока этого снимка. |
| values | Variant; ByVal; обязательный | Двумерный массив скалярных значений, копируется; вложенные массивы/объекты запрещены. |
| addresses | Variant; ByVal; Optional; пропущенный Variant=Missing | Необязательный согласованный 2D-массив адресов; без него применяется программный tableName[row,col]. |

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:18

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidInputRejected с его подготовленными локальными объектами/входом.

```vb
        Case 10: table.Initialize "Second", cells
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:373.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-name"></a>
### CSectionInputTable.Name

Имя корневого блока snapshot.

```vb
Public Property Get Name() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:54

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Check "table.name", table.Name = "ProgramInputs"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:221.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-csectioninputtable-rowcount"></a>
### CSectionInputTable.RowCount

Число строк неизменяемого input snapshot.

```vb
Public Property Get RowCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:55

Минимальный вызов; требуемый контекст: В теле modTestSectionSolver.TestRecipeInputCatalog с его подготовленными локальными объектами/входом.

```vb
            For row = 1 To table.RowCount
```

Полный контекст: tests/modTestSectionSolver.bas:504.

Native entrypoint: modTestSectionSolver.RunSectionSolverTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/NumericalRegression.txt.

<a id="api-csectioninputtable-columncount"></a>
### CSectionInputTable.ColumnCount

Число столбцов input snapshot.

```vb
Public Property Get ColumnCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:56

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunInputTableTests с его подготовленными локальными объектами/входом.

```vb
    Check "input.columns", table.ColumnCount = 3
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:314.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-sourcereference"></a>
### CSectionInputTable.SourceReference

Возвращает исходный адрес ячейки или программный tableName[row,col].

```vb
Public Function SourceReference(ByVal row As Long, ByVal column As Long) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:58

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunInputTableTests с его подготовленными локальными объектами/входом.

```vb
    Check "input.source", table.SourceReference(2, 2) = "Config!B12"
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:323.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-cellvalue"></a>
### CSectionInputTable.CellValue

Читает scalar snapshot; ошибка Excel в ячейке даёт адресное исключение.

```vb
Public Function CellValue(ByVal row As Long, ByVal column As Long) As Variant
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |

Тип результата: Variant. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:62

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunWorkbookRecipeInputTests с его подготовленными локальными объектами/входом.

```vb
        Set table = context.Table(rootName): initialCell = table.CellValue(1, 1)
```

Полный контекст: tests/modTestSectionRecipes.bas:38.

Native entrypoint: modTestSectionRecipes.RunWorkbookRecipeInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/ProductionRecipeEvidencePack/data/ProductionRecipe/WorkbookInput.txt.

<a id="api-csectioninputtable-isblank"></a>
### CSectionInputTable.IsBlank

Проверяет пустое значение снимка; ошибка Excel не подменяется пустотой.

```vb
Public Function IsBlank(ByVal row As Long, ByVal column As Long) As Boolean
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:68

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunInputTableTests с его подготовленными локальными объектами/входом.

```vb
    Check "input.blank", table.IsBlank(4, 3)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:324.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-text"></a>
### CSectionInputTable.Text

Читает непустой текст либо явно переданный fallback, обрезая крайние пробелы.

```vb
Public Function Text(ByVal row As Long, ByVal column As Long, Optional ByVal defaultValue As Variant) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |
| defaultValue | Variant; ByVal; Optional; пропущенный Variant=Missing | Явный fallback конкретного вызова. Пропущенный Optional Variant без default означает обязательное поле. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:72

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Check "table.text", table.Text(3, 2) = "Guide"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:222.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-csectioninputtable-number"></a>
### CSectionInputTable.Number

Читает число, исключая Boolean/ошибки/объекты; обязательное пустое поле не заменяется нулём.

```vb
Public Function Number(ByVal row As Long, ByVal column As Long, Optional ByVal defaultValue As Variant) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |
| defaultValue | Variant; ByVal; Optional; пропущенный Variant=Missing | Явный fallback конкретного вызова. Пропущенный Optional Variant без default означает обязательное поле. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:83

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidInputRejected с его подготовленными локальными объектами/входом.

```vb
        Case 11: value = table.Number(3, 2)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:374.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-count"></a>
### CSectionInputTable.Count

Читает целое неотрицательное 0..2147483647; отдельный executor проверяет суммарное число позиций.

```vb
Public Function Count(ByVal row As Long, ByVal column As Long, Optional ByVal defaultValue As Long = 0) As Long
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |
| defaultValue | Long; ByVal; Optional; default=0 | Явный fallback конкретного вызова. Пропущенный Optional Variant без default означает обязательное поле. |

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:101

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunInputTableTests с его подготовленными локальными объектами/входом.

```vb
    Check "input.count", table.Count(2, 2) = 4
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:320.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-choice"></a>
### CSectionInputTable.Choice

Проверяет вариант по allowed без учёта регистра и возвращает каноническое значение allowed.

```vb
Public Function Choice(ByVal row As Long, ByVal column As Long, ByVal allowed As Variant, Optional ByVal defaultValue As String = vbNullString) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |
| allowed | Variant; ByVal; обязательный | Массив разрешённых строк; Choice возвращает каноническую строку из этого массива. |
| defaultValue | String; ByVal; Optional; default=vbNullString | Явный fallback конкретного вызова. Пропущенный Optional Variant без default означает обязательное поле. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:109

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidInputRejected с его подготовленными локальными объектами/входом.

```vb
        Case 9: value = table.Choice(2, 2, Array("Stacked", "SideBySide"))
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:372.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-length"></a>
### CSectionInputTable.Length

Читает обязательное число и один раз переводит input length в мм через CUnitSystem.

```vb
Public Function Length(ByVal row As Long, ByVal column As Long, ByVal units As CUnitSystem) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |
| units | CUnitSystem; ByVal; обязательный | CUnitSystem, уже подготовленная вызывающим workflow; преобразование только через её методы. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:119

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunInputTableTests с его подготовленными локальными объектами/входом.

```vb
    Near "input.length", table.Length(4, 2, units), 16#
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:329.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-optionaldiameter"></a>
### CSectionInputTable.OptionalDiameter

Пусто/TODO/0 выключает ряд; положительное переводится в мм, отрицательное — ошибка.

```vb
Public Function OptionalDiameter(ByVal row As Long, ByVal column As Long, ByVal units As CUnitSystem) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| row | Long; ByVal; обязательный | Номер строки снимка 1..RowCount. |
| column | Long; ByVal; обязательный | Номер столбца снимка 1..ColumnCount. |
| units | CUnitSystem; ByVal; обязательный | CUnitSystem, уже подготовленная вызывающим workflow; преобразование только через её методы. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:126

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidInputRejected с его подготовленными локальными объектами/входом.

```vb
        Case 13: value = table.OptionalDiameter(2, 2, units)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:376.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-columnbycaption"></a>
### CSectionInputTable.ColumnByCaption

Находит уникальный столбец заголовка, без фиксированного адреса.

```vb
Public Function ColumnByCaption(ByVal headerRow As Long, ByVal caption As String) As Long
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| headerRow | Long; ByVal; обязательный | Строка заголовков, в пределах снимка. |
| caption | String; ByVal; обязательный | Смысловой заголовок столбца; повторные заголовки — ошибка. |

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:136

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidInputRejected с его подготовленными локальными объектами/входом.

```vb
        Case 6: value = table.ColumnByCaption(1, "Value")
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:370.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

<a id="api-csectioninputtable-rowbykey"></a>
### CSectionInputTable.RowByKey

Находит уникальную строку смыслового ключа в указанном подблоке.

```vb
Public Function RowByKey(ByVal key As String, Optional ByVal keyColumn As Long = 1, Optional ByVal firstRow As Long = 1, Optional ByVal lastRow As Long = 0) As Long
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| key | String; ByVal; обязательный | Смысловой ключ строки, не Excel-адрес. |
| keyColumn | Long; ByVal; Optional; default=1 | Столбец смысловых ключей 1..ColumnCount. |
| firstRow | Long; ByVal; Optional; default=1 | Начало диапазона поиска строки, включительно. |
| lastRow | Long; ByVal; Optional; default=0 | Конец поиска, включительно; 0 означает RowCount. |

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:151

Минимальный вызов; требуемый контекст: В теле modTestRecipeSetbacks.RunRecipeSetbackInputTests с его подготовленными локальными объектами/входом.

```vb
    main = table.RowByKey("as", 2)
```

Полный контекст: tests/modTestRecipeSetbacks.bas:191.

Native entrypoint: modTestRecipeSetbacks.RunRecipeSetbackInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalGeometry.txt.

<a id="api-csectioninputtable-rowbyanykey"></a>
### CSectionInputTable.RowByAnyKey

Находит уникальную строку по массиву допустимых альтернативных ключей; неоднозначность запрещена.

```vb
Public Function RowByAnyKey(ByVal keys As Variant, Optional ByVal keyColumn As Long = 1, Optional ByVal firstRow As Long = 1, Optional ByVal lastRow As Long = 0) As Long
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| keys | Variant; ByVal; обязательный | Массив допустимых альтернативных ключей; неоднозначное совпадение отклоняется. |
| keyColumn | Long; ByVal; Optional; default=1 | Столбец смысловых ключей 1..ColumnCount. |
| firstRow | Long; ByVal; Optional; default=1 | Начало диапазона поиска строки, включительно. |
| lastRow | Long; ByVal; Optional; default=0 | Конец поиска, включительно; 0 означает RowCount. |

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize один раз копирует значения/адреса. Последующее изменение листа/исходного массива не меняет снимок; ошибка Excel не скрывается.

Ошибки/исправление: 5525/адресные input codes: несогласованные массивы, пустое обязательное поле, ошибка Excel, нечисло/Boolean, повтор ключа/заголовка, неверный Choice/Count. Исправьте реальную ячейку.

Source: src/Section/CSectionInputTable.cls:158

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.InvalidInputRejected с его подготовленными локальными объектами/входом.

```vb
        Case 20: value = table.RowByAnyKey("Count")
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:381.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunInputTableTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/InputTables.txt.

## CSectionRecipeContext

Initialize→AddTable→Seal на внешней границе. Рецепт только читает Table/Units; не сохраняет context в готовом definition.

<a id="api-csectionrecipecontext-initialize"></a>
### CSectionRecipeContext.Initialize

Открывает контекст с подготовленной системой единиц один раз.

```vb
Public Sub Initialize(ByVal units As CUnitSystem)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| units | CUnitSystem; ByVal; обязательный | CUnitSystem, уже подготовленная вызывающим workflow; преобразование только через её методы. |

Жизненный цикл: Initialize→AddTable→Seal на внешней границе. Рецепт только читает Table/Units; не сохраняет context в готовом definition.

Ошибки/исправление: 5530: нет units/table, повтор имени, добавление после Seal. Готовьте новый context на внешней границе.

Source: src/Section/CSectionRecipeContext.cls:18

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Set context = New CSectionRecipeContext: context.Initialize units: context.AddTable table: context.Seal
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:223.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-csectionrecipecontext-addtable"></a>
### CSectionRecipeContext.AddTable

Добавляет immutable input snapshot с уникальным именем до Seal.

```vb
Public Sub AddTable(ByVal table As CSectionInputTable)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| table | CSectionInputTable; ByVal; обязательный | Неизменяемый CSectionInputTable. |

Жизненный цикл: Initialize→AddTable→Seal на внешней границе. Рецепт только читает Table/Units; не сохраняет context в готовом definition.

Ошибки/исправление: 5530: нет units/table, повтор имени, добавление после Seal. Готовьте новый context на внешней границе.

Source: src/Section/CSectionRecipeContext.cls:26

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Set context = New CSectionRecipeContext: context.Initialize units: context.AddTable table: context.Seal
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:223.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-csectionrecipecontext-seal"></a>
### CSectionRecipeContext.Seal

Закрывает состав таблиц; после этого добавление невозможно.

```vb
Public Sub Seal()
```

Жизненный цикл: Initialize→AddTable→Seal на внешней границе. Рецепт только читает Table/Units; не сохраняет context в готовом definition.

Ошибки/исправление: 5530: нет units/table, повтор имени, добавление после Seal. Готовьте новый context на внешней границе.

Source: src/Section/CSectionRecipeContext.cls:34

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Set context = New CSectionRecipeContext: context.Initialize units: context.AddTable table: context.Seal
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:223.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-csectionrecipecontext-table"></a>
### CSectionRecipeContext.Table

Возвращает снимок зарегистрированного блока по имени; отсутствие — ошибка, не fallback.

```vb
Public Function Table(ByVal tableName As String) As CSectionInputTable
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| tableName | String; ByVal; обязательный | Имя единственного корневого входного блока этого снимка. |

Тип результата: CSectionInputTable. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize→AddTable→Seal на внешней границе. Рецепт только читает Table/Units; не сохраняет context в готовом definition.

Ошибки/исправление: 5530: нет units/table, повтор имени, добавление после Seal. Готовьте новый context на внешней границе.

Source: src/Section/CSectionRecipeContext.cls:39

Минимальный вызов; требуемый контекст: В теле modTestGeometryConfig.CounterFixture с его подготовленными локальными объектами/входом.

```vb
    Set table = context.Table(CStr(names(0)))
```

Полный контекст: tests/modTestGeometryConfig.bas:85.

Native entrypoint: modTestGeometryConfig.RunAudit03RebarCounterTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/ProductionRecipeEvidencePack/data/ProductionRecipe/RebarCounters.txt.

<a id="api-csectionrecipecontext-units"></a>
### CSectionRecipeContext.Units

Система единиц внешнего workflow; не перезагружайте её из Excel в рецепте.

```vb
Public Property Get Units() As CUnitSystem
```

Тип результата: CUnitSystem. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Initialize→AddTable→Seal на внешней границе. Рецепт только читает Table/Units; не сохраняет context в готовом definition.

Ошибки/исправление: 5530: нет units/table, повтор имени, добавление после Seal. Готовьте новый context на внешней границе.

Source: src/Section/CSectionRecipeContext.cls:45

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Set units = context.Units: Near "context.normalizedUnit", units.InputLengthToInternal(table.Number(2, 2)), 100#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:224.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

## CSectionInputSnapshotReader

Внешний workbook+список имён+подготовленные units→новый sealed context. Невыбранные блоки не читаются; live Excel не передаётся геометрическому ядру.

<a id="api-csectioninputsnapshotreader-capture"></a>
### CSectionInputSnapshotReader.Capture

На внешней Excel-границе вычисляет и копирует только выбранные именованные блоки с адресами, затем Seal context.

```vb
Public Function Capture(ByVal workbook As Object, ByVal tableNames As Variant, ByVal units As CUnitSystem) As CSectionRecipeContext
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| workbook | Object; ByVal; обязательный | Excel workbook на внешней границе ввода; рецепт этот объект не хранит. |
| tableNames | Variant; ByVal; обязательный | Массив имён блоков выбранного типа; Empty-array допустим для программного рецепта. |
| units | CUnitSystem; ByVal; обязательный | CUnitSystem, уже подготовленная вызывающим workflow; преобразование только через её методы. |

Тип результата: CSectionRecipeContext. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Внешний workbook+список имён+подготовленные units→новый sealed context. Невыбранные блоки не читаются; live Excel не передаётся геометрическому ядру.

Ошибки/исправление: Адресные ошибки имени/блока/формулы. Повреждённый выбранный блок не равен отсутствию потребителя; восстановите имя/ячейку.

Source: src/Excel/CSectionInputSnapshotReader.cls:14

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunWorkbookRecipeInputTests с его подготовленными локальными объектами/входом.

```vb
        Set context = reader.Capture(ThisWorkbook, names, units)
```

Полный контекст: tests/modTestSectionRecipes.bas:56.

Native entrypoint: modTestSectionRecipes.RunWorkbookRecipeInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/ProductionRecipeEvidencePack/data/ProductionRecipe/WorkbookInput.txt.

## CSectionTypeRegistry

Новая instance регистрирует текущие типы. RegisterRecipe добавляет один экземпляр/metadata; consumer выбирает только зарегистрированный TypeID.

<a id="api-csectiontyperegistry-registerrecipe"></a>
### CSectionTypeRegistry.RegisterRecipe

Регистрирует один ISectionRecipe и массив имён его входных блоков; ID типа уникальный.

```vb
Public Sub RegisterRecipe(ByVal typeID As String, ByVal recipe As ISectionRecipe, ByVal tableNames As Variant)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| typeID | String; ByVal; обязательный | Смысловое имя зарегистрированного типа; непустой текст. |
| recipe | ISectionRecipe; ByVal; обязательный | Один объект с реализацией ISectionRecipe. |
| tableNames | Variant; ByVal; обязательный | Массив имён блоков выбранного типа; Empty-array допустим для программного рецепта. |

Жизненный цикл: Новая instance регистрирует текущие типы. RegisterRecipe добавляет один экземпляр/metadata; consumer выбирает только зарегистрированный TypeID.

Ошибки/исправление: 5530: неизвестный/повторный TypeID, пустой recipe/context, повреждённые metadata. Добавьте одну действительную регистрацию.

Source: src/Excel/CSectionTypeRegistry.cls:27

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunWorkbookRecipeInputTests с его подготовленными локальными объектами/входом.

```vb
    registry.RegisterRecipe "FixedMetadata", New CSectionRecipeCircle, Array()
```

Полный контекст: tests/modTestSectionRecipes.bas:80.

Native entrypoint: modTestSectionRecipes.RunWorkbookRecipeInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/ProductionRecipeEvidencePack/data/ProductionRecipe/WorkbookInput.txt.

<a id="api-csectiontyperegistry-createrecipe"></a>
### CSectionTypeRegistry.CreateRecipe

Возвращает зарегистрированный объект по TypeID; неизвестный тип — ошибка.

```vb
Public Function CreateRecipe(ByVal typeID As String) As ISectionRecipe
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| typeID | String; ByVal; обязательный | Смысловое имя зарегистрированного типа; непустой текст. |

Тип результата: ISectionRecipe. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Новая instance регистрирует текущие типы. RegisterRecipe добавляет один экземпляр/metadata; consumer выбирает только зарегистрированный TypeID.

Ошибки/исправление: 5530: неизвестный/повторный TypeID, пустой recipe/context, повреждённые metadata. Добавьте одну действительную регистрацию.

Source: src/Excel/CSectionTypeRegistry.cls:43

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Set registry = New CSectionTypeRegistry: Set recipe = registry.CreateRecipe("Circle")
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:225.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-csectiontyperegistry-recipetablenames"></a>
### CSectionTypeRegistry.RecipeTableNames

Возвращает независимый массив имён ввода, пустой для программного рецепта.

```vb
Public Function RecipeTableNames(ByVal typeID As String) As Variant
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| typeID | String; ByVal; обязательный | Смысловое имя зарегистрированного типа; непустой текст. |

Тип результата: Variant. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Новая instance регистрирует текущие типы. RegisterRecipe добавляет один экземпляр/metadata; consumer выбирает только зарегистрированный TypeID.

Ошибки/исправление: 5530: неизвестный/повторный TypeID, пустой recipe/context, повреждённые metadata. Добавьте одну действительную регистрацию.

Source: src/Excel/CSectionTypeRegistry.cls:48

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunWorkbookRecipeInputTests с его подготовленными локальными объектами/входом.

```vb
    names = registry.RecipeTableNames("Circle")
```

Полный контекст: tests/modTestSectionRecipes.bas:78.

Native entrypoint: modTestSectionRecipes.RunWorkbookRecipeInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/ProductionRecipeEvidencePack/data/ProductionRecipe/WorkbookInput.txt.

<a id="api-csectiontyperegistry-registeredrecipetypes"></a>
### CSectionTypeRegistry.RegisteredRecipeTypes

Возвращает фактически зарегистрированные TypeID — источник штатного списка Config.

```vb
Public Function RegisteredRecipeTypes() As Variant
```

Тип результата: Variant. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Новая instance регистрирует текущие типы. RegisterRecipe добавляет один экземпляр/metadata; consumer выбирает только зарегистрированный TypeID.

Ошибки/исправление: 5530: неизвестный/повторный TypeID, пустой recipe/context, повреждённые metadata. Добавьте одну действительную регистрацию.

Source: src/Excel/CSectionTypeRegistry.cls:53

Минимальный вызов; требуемый контекст: В теле modTestRoundedTrapezoidExample.RunExampleBuildTests с его подготовленными локальными объектами/входом.

```vb
    For Each id In registry.RegisteredRecipeTypes
```

Полный контекст: docs/geometry_refactor/examples/modTestRoundedTrapezoidExample.bas:18.

Native entrypoint: modTestRoundedTrapezoidExample.RunExampleBuildTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/OneClassExample/InputAndBuild.txt.

<a id="api-csectiontyperegistry-selectedrecipetype"></a>
### CSectionTypeRegistry.SelectedRecipeType

Читает обязательный Geometry.Type через settings и проверяет его по реестру.

```vb
Public Function SelectedRecipeType(ByVal settings As CSystemSettingsReader) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| settings | CSystemSettingsReader; ByVal; обязательный | CSystemSettingsReader, уже загрузивший Config. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Новая instance регистрирует текущие типы. RegisterRecipe добавляет один экземпляр/metadata; consumer выбирает только зарегистрированный TypeID.

Ошибки/исправление: 5530: неизвестный/повторный TypeID, пустой recipe/context, повреждённые metadata. Добавьте одну действительную регистрацию.

Source: src/Excel/CSectionTypeRegistry.cls:57

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunWorkbookRecipeInputTests с его подготовленными локальными объектами/входом.

```vb
    Check "workbook.registry.dynamicChoice", registry.SelectedRecipeType(settings) = "FixedMetadata"
```

Полный контекст: tests/modTestSectionRecipes.bas:86.

Native entrypoint: modTestSectionRecipes.RunWorkbookRecipeInputTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/ProductionRecipeEvidencePack/data/ProductionRecipe/WorkbookInput.txt.

<a id="api-csectiontyperegistry-createdefinition"></a>
### CSectionTypeRegistry.CreateDefinition

Вызывает ровно один выбранный ISectionRecipe с подготовленным context.

```vb
Public Function CreateDefinition(ByVal typeID As String, ByVal context As CSectionRecipeContext) As CSectionDefinition
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| typeID | String; ByVal; обязательный | Смысловое имя зарегистрированного типа; непустой текст. |
| context | CSectionRecipeContext; ByVal; обязательный | Подготовленный снимок CSectionRecipeContext, не live Excel. |

Тип результата: CSectionDefinition. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Новая instance регистрирует текущие типы. RegisterRecipe добавляет один экземпляр/metadata; consumer выбирает только зарегистрированный TypeID.

Ошибки/исправление: 5530: неизвестный/повторный TypeID, пустой recipe/context, повреждённые metadata. Добавьте одну действительную регистрацию.

Source: src/Excel/CSectionTypeRegistry.cls:63

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.BuildRecipe с его подготовленными локальными объектами/входом.

```vb
    Set definition = registry.CreateDefinition(typeID, context)
```

Полный контекст: tests/modTestSectionRecipes.bas:832.

Native entrypoint: modTestSectionRecipes.RunRecipeAnnotationCountTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/RoundedRecipeEvidencePack/RoundedRecipe/AnnotationCounts.txt.

Native entrypoint: modTestSectionRecipes.RunRoundedRecipeEquilibriumTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/RoundedRecipeEvidencePack/RoundedRecipe/EquilibriumTests.txt.

Native entrypoint: modTestSectionRecipes.RunHollowRecipeEquilibriumTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/HollowRecipeEvidencePack/data/HollowRecipe/EquilibriumTests.txt.

Native entrypoint: modTestSectionRecipes.RunHollowRecipeEdgeEquilibriumTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/HollowRecipeEvidencePack/data/HollowRecipe/EdgeEquilibriumYes.txt.

## CSectionBuilder

Один Build выполняет все общие стадии для immutable definition. После успеха доступны Mesh/Rebars/Rules; после нового отказа прошлый успешный результат не выдаётся.

<a id="api-csectionbuilder-build"></a>
### CSectionBuilder.Build

Единая сборка definition→область→сетка/правила→CSectionModel→аннотации; не ветвится по типу.

```vb
Public Function Build(ByVal definition As CSectionDefinition, ByRef meshOptions As TSectionMeshOptions) As CSectionModel
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| definition | CSectionDefinition; ByVal; обязательный | Успешно опубликованный неизменяемый CSectionDefinition. |
| meshOptions | TSectionMeshOptions; ByRef; обязательный | TSectionMeshOptions: StepX/StepY мм>0, BoundarySubdivisions целое≥1, MaterialID≥1. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Тип результата: CSectionModel. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Один Build выполняет все общие стадии для immutable definition. После успеха доступны Mesh/Rebars/Rules; после нового отказа прошлый успешный результат не выдаётся.

Ошибки/исправление: 5530: неопубликованное definition, неверные meshOptions, отсутствие баров/успешной сборки. Исправьте ввод; старый результат после отказа не выдаётся.

Source: src/Section/CSectionBuilder.cls:19

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeExamples.RunRoundedFrameExampleTests с его подготовленными локальными объектами/входом.

```vb
    Set model = builder.Build(definition, mesh)
```

Полный контекст: tests/modTestDeclarativeExamples.bas:20.

Native entrypoint: modTestDeclarativeExamples.RunRoundedFrameExampleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/OneClassExample/InputAndBuild.txt.

<a id="api-csectionbuilder-mesh"></a>
### CSectionBuilder.Mesh

CFiberMeshBuilder только последней успешно собранной модели; готовую сетку повторно не создавайте.

```vb
Public Property Get Mesh() As CFiberMeshBuilder
```

Тип результата: CFiberMeshBuilder. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Один Build выполняет все общие стадии для immutable definition. После успеха доступны Mesh/Rebars/Rules; после нового отказа прошлый успешный результат не выдаётся.

Ошибки/исправление: 5530: неопубликованное definition, неверные meshOptions, отсутствие баров/успешной сборки. Исправьте ввод; старый результат после отказа не выдаётся.

Source: src/Section/CSectionBuilder.cls:45

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set mesh = builder.Mesh: Check "builder.preparedMesh", Not mesh Is Nothing
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:120.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectionbuilder-rebars"></a>
### CSectionBuilder.Rebars

Физическая раскладка последней успешной сборки; совпадения уже обработаны явно.

```vb
Public Property Get Rebars() As CRebarLayout
```

Тип результата: CRebarLayout. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Один Build выполняет все общие стадии для immutable definition. После успеха доступны Mesh/Rebars/Rules; после нового отказа прошлый успешный результат не выдаётся.

Ошибки/исправление: 5530: неопубликованное definition, неверные meshOptions, отсутствие баров/успешной сборки. Исправьте ввод; старый результат после отказа не выдаётся.

Source: src/Section/CSectionBuilder.cls:50

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestPublicationAndCoincidence с его подготовленными локальными объектами/входом.

```vb
    memberships = builder.Rebars.BarMemberships(1)
```

Полный контекст: tests/modTestSectionRecipes.bas:380.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectionbuilder-rules"></a>
### CSectionBuilder.Rules

Исполнитель последней успешной сборки с фактическими счётчиками/шагами/происхождением.

```vb
Public Property Get Rules() As CRebarRuleExecutor
```

Тип результата: CRebarRuleExecutor. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Один Build выполняет все общие стадии для immutable definition. После успеха доступны Mesh/Rebars/Rules; после нового отказа прошлый успешный результат не выдаётся.

Ошибки/исправление: 5530: неопубликованное definition, неверные meshOptions, отсутствие баров/успешной сборки. Исправьте ввод; старый результат после отказа не выдаётся.

Source: src/Section/CSectionBuilder.cls:55

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set rules = builder.Rules
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:121.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

## CRebarRuleExecutor

Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

<a id="api-crebarruleexecutor-requestedpositions"></a>
### CRebarRuleExecutor.RequestedPositions

Все запрошенные позиции, включая пропущенные проекции; это не число физических стержней.

```vb
Public Property Get RequestedPositions() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:29

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestRectSetAutoRebarLayout с его подготовленными локальными объектами/входом.

```vb
    AssertTrue stats, "rectset.rebar.requested", builder.RequestedPositions = 8
```

Полный контекст: tests/modTestGeometry.bas:1209.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleexecutor-createdpositions"></a>
### CRebarRuleExecutor.CreatedPositions

Действительно добавленные физические стержни текущего Build, даже при отказе в середине.

```vb
Public Property Get CreatedPositions() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:30

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestAudit03CircleCountGuard с его подготовленными локальными объектами/входом.

```vb
        AssertClose stats, prefix & ".beforeCoordinates", CDbl(builder.CreatedPositions), 0#, 0#
```

Полный контекст: tests/modTestGeometry.bas:2586.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-crebarruleexecutor-skippedprojections"></a>
### CRebarRuleExecutor.SkippedProjections

Число явно разрешённых пропусков target hit.

```vb
Public Property Get SkippedProjections() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:31

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunAdvancedGuideExamples с его подготовленными локальными объектами/входом.

```vb
        Check "advanced.projection.skips." & CStr(useMaxStep), rules.SkippedProjections = 2
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:22.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-crebarruleexecutor-mergedpositions"></a>
### CRebarRuleExecutor.MergedPositions

Число заявленных позиций, объединённых с физическим владельцем.

```vb
Public Property Get MergedPositions() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:32

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    Check "merge.counts", rules.RequestedPositions = 2 And rules.CreatedPositions = 1 And rules.MergedPositions = 1
```

Полный контекст: tests/modTestRecipeOperations.bas:165.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-conflicts"></a>
### CRebarRuleExecutor.Conflicts

Число несовместимых/отклонённых совпадений или запрещённых пересечений по явной политике.

```vb
Public Property Get Conflicts() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:33

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "overlap.error.actual.created", rules.RequestedPositions = 2 And rules.CreatedPositions = 1 And rules.Conflicts = 1
```

Полный контекст: tests/modTestRecipeOperations.bas:115.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-baroverlaps"></a>
### CRebarRuleExecutor.BarOverlaps

Полное число пар с отрицательным геометрическим зазором дисков; касание не включается.

```vb
Public Property Get BarOverlaps() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:34

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "overlap.report." & CStr(mode), rules.BarOverlaps = 1
```

Полный контекст: tests/modTestRecipeOperations.bas:119.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-diagnosticrecordsomitted"></a>
### CRebarRuleExecutor.DiagnosticRecordsOmitted

Число событий сверх 128 сохранённых подробных образцов; полные счётчики не сокращаются.

```vb
Public Property Get DiagnosticRecordsOmitted() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:35

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    Check "diagnostics.bounded.records", rules.DiagnosticCount = 128 And rules.DiagnosticRecordsOmitted = 1582
```

Полный контекст: tests/modTestRecipeOperations.bas:159.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-lastdiagnostic"></a>
### CRebarRuleExecutor.LastDiagnostic

Последняя машинная диагностика; Nothing при отсутствии записанного события.

```vb
Public Property Get LastDiagnostic() As CGeometryDiagnostic
```

Тип результата: CGeometryDiagnostic. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:36

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Set diagnostic = rules.LastDiagnostic
```

Полный контекст: tests/modTestRecipeOperations.bas:111.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-diagnosticcount"></a>
### CRebarRuleExecutor.DiagnosticCount

Число сохранённых подробных immutable образцов, 0..128.

```vb
Public Property Get DiagnosticCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:37

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    Check "diagnostics.bounded.records", rules.DiagnosticCount = 128 And rules.DiagnosticRecordsOmitted = 1582
```

Полный контекст: tests/modTestRecipeOperations.bas:159.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-diagnosticat"></a>
### CRebarRuleExecutor.DiagnosticAt

Читает immutable подробный образец 1..DiagnosticCount; максимум 128 образцов, счётчики полные.

```vb
Public Function DiagnosticAt(ByVal index As Long) As CGeometryDiagnostic
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: CGeometryDiagnostic. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:41

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "overlap.machine." & CStr(mode), rules.DiagnosticAt(1).Code = "BAR_OVERLAP"
```

Полный контекст: tests/modTestRecipeOperations.bas:120.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-positioncount"></a>
### CRebarRuleExecutor.PositionCount

Число сгенерированных заявленных позиций до объединения физических владельцев.

```vb
Public Property Get PositionCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:47

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "rules.positionCount", rules.PositionCount = 3
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:122.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-crebarruleexecutor-positionruleid"></a>
### CRebarRuleExecutor.PositionRuleID

ID правила заявленной позиции, включая объединённые позиции.

```vb
Public Function PositionRuleID(ByVal index As Long) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:48

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "trace.ids." & CStr(mode), rules.PositionRuleID(1) = "Bars" And rules.PositionPathID(1) = "Row" And rules.PositionSourceID(1) = "Bars.1"
```

Полный контекст: tests/modTestRecipeOperations.bas:123.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-positionpathid"></a>
### CRebarRuleExecutor.PositionPathID

ID геометрического пути заявленной позиции.

```vb
Public Function PositionPathID(ByVal index As Long) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:51

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "trace.ids." & CStr(mode), rules.PositionRuleID(1) = "Bars" And rules.PositionPathID(1) = "Row" And rules.PositionSourceID(1) = "Bars.1"
```

Полный контекст: tests/modTestRecipeOperations.bas:123.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-positionsourceid"></a>
### CRebarRuleExecutor.PositionSourceID

Смысловой SourcePositionId, из которого публиковался физический стержень.

```vb
Public Function PositionSourceID(ByVal index As Long) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:52

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
            Check "trace.ids." & CStr(mode), rules.PositionRuleID(1) = "Bars" And rules.PositionPathID(1) = "Row" And rules.PositionSourceID(1) = "Bars.1"
```

Полный контекст: tests/modTestRecipeOperations.bas:123.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-positionphysicalowner"></a>
### CRebarRuleExecutor.PositionPhysicalOwner

Индекс физического владельца в итоговом CRebarLayout; объединённые позиции имеют одного владельца.

```vb
Public Function PositionPhysicalOwner(ByVal index As Long) As Long
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:53

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    Check "merge.physical.owner", rules.PositionPhysicalOwner(1) = 1 And rules.PositionPhysicalOwner(2) = 1
```

Полный контекст: tests/modTestRecipeOperations.bas:166.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-ruletrace"></a>
### CRebarRuleExecutor.RuleTrace

Текстовый отчёт конкретного правила с фактическими counts и шагами/хордами.

```vb
Public Function RuleTrace(ByVal ruleID As String) As String
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:57

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    Check "merge.trace", InStr(rules.RuleTrace("Second"), "Created=0; Merged=1") > 0
```

Полный контекст: tests/modTestRecipeOperations.bas:167.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-rulestepbounds"></a>
### CRebarRuleExecutor.RuleStepBounds

Возвращает число интервалов, min/max станционных шагов и хорд, мм; замыкание кольца учитывается.

```vb
Public Sub RuleStepBounds(ByVal ruleID As String, ByRef stepCount As Long, ByRef minStep As Double, ByRef maxStep As Double, ByRef minChord As Double, ByRef maxChord As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| ruleID | String; ByVal; обязательный | Непустой уникальный ID правила; при диагностике — ID ранее исполненного правила. |
| stepCount | Long; ByRef; обязательный | Целый неотрицательный счётчик; для ByCount применяется отдельно к каждому пути. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| minStep | Double; ByRef; обязательный | Длина/станция/граница minStep, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| maxStep | Double; ByRef; обязательный | Длина/станция/граница maxStep, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| minChord | Double; ByRef; обязательный | Длина/станция/граница minChord, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| maxChord | Double; ByRef; обязательный | Длина/станция/граница maxChord, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:72

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    rules.RuleStepBounds "RingBars", stepCount, minStep, maxStep, minChord, maxChord
```

Полный контекст: tests/modTestRecipeOperations.bas:147.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-crebarruleexecutor-diagnosticstext"></a>
### CRebarRuleExecutor.DiagnosticsText

Полный текстовый отчёт счётчиков и всех RuleTrace; численные длины в мм независимо от output units.

```vb
Public Function DiagnosticsText() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:108

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "rules.diagnosticsText", InStr(rules.DiagnosticsText, "Created=3") > 0
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:123.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-crebarruleexecutor-build"></a>
### CRebarRuleExecutor.Build

Исполняет опубликованные правила в готовой бетонной области и возвращает физическую раскладку; mesh не строит.

```vb
Public Function Build(ByVal definition As CSectionDefinition, ByVal geometry As CGeometryRegion) As CRebarLayout
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| definition | CSectionDefinition; ByVal; обязательный | Успешно опубликованный неизменяемый CSectionDefinition. |
| geometry | CGeometryRegion; ByVal; обязательный | Подготовленный CGeometryRegion материала для исполнения правил. |

Тип результата: CRebarLayout. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Build начинает новый отчёт/массивы, даже при раннем отказе. Чтение происхождения/шагов после исполнения; позиции не являются независимой копией mesh.

Ошибки/исправление: 5530: неверные options/длина/step/ClosedUniform, отсутствие hit, конфликт владельца/размещения. Читайте Code/ID/числа/source; Created — фактическое число.

Source: src/Section/CRebarRuleExecutor.cls:119

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
    Set layout = rules.Build(Nothing, Nothing)
```

Полный контекст: tests/modTestRecipeOperations.bas:176.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

## CUnitSystem

InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

<a id="api-cunitsystem-initializedefaults"></a>
### CUnitSystem.InitializeDefaults

Задаёт программные defaults: input mm/mm²/N/N*mm/MPa/1/mm и Tension, output m/m²/N/N*mm/MPa/1/mm. Не заменяет обязательный Config ввод.

```vb
Public Sub InitializeDefaults()
```

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:44

Минимальный вызов; требуемый контекст: В теле modTestSectionSolver.TestUnitSystemConversions с его подготовленными локальными объектами/входом.

```vb
    units.InitializeDefaults
```

Полный контекст: tests/modTestSectionSolver.bas:289.

Native entrypoint: modTestSectionSolver.RunSectionSolverTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/NumericalRegression.txt.

<a id="api-cunitsystem-loadfromsettings"></a>
### CUnitSystem.LoadFromSettings

Загружает и проверяет все активные единицы и знаки через общий settings reader.

```vb
Public Sub LoadFromSettings(ByVal settings As CSystemSettingsReader)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| settings | CSystemSettingsReader; ByVal; обязательный | CSystemSettingsReader, уже загрузивший Config. |

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:59

Минимальный вызов; требуемый контекст: В теле modTestSectionSolver.TestUnitSystemConversions с его подготовленными локальными объектами/входом.

```vb
    configured.LoadFromSettings settings
```

Полный контекст: tests/modTestSectionSolver.bas:299.

Native entrypoint: modTestSectionSolver.RunSectionSolverTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/NumericalRegression.txt.

<a id="api-cunitsystem-inputlengthtointernal"></a>
### CUnitSystem.InputLengthToInternal

Переводит InputLengthToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputLengthToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:82

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.inputLength", units.InputLengthToInternal(20#), 20#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:170.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internallengthtooutput"></a>
### CUnitSystem.InternalLengthToOutput

Переводит InternalLengthToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalLengthToOutput(ByVal value As Double, Optional ByVal savedUnit As String = vbNullString) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |
| savedUnit | String; ByVal; Optional; default=vbNullString | Единица сохранённого Results; пустая использует текущую output-единицу CUnitSystem. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:88

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.outputLength", units.InternalLengthToOutput(2000#), 2#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:171.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputlengthtointernal"></a>
### CUnitSystem.OutputLengthToInternal

Переводит OutputLengthToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function OutputLengthToInternal(ByVal value As Double, Optional ByVal savedUnit As String = vbNullString) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |
| savedUnit | String; ByVal; Optional; default=vbNullString | Единица сохранённого Results; пустая использует текущую output-единицу CUnitSystem. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:95

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.savedLength", units.OutputLengthToInternal(2#, "cm"), 20#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:172.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputareatointernal"></a>
### CUnitSystem.InputAreaToInternal

Переводит InputAreaToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputAreaToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:101

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.inputArea", units.InputAreaToInternal(100#), 100#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:173.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalareatooutput"></a>
### CUnitSystem.InternalAreaToOutput

Переводит InternalAreaToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalAreaToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:106

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.outputArea", units.InternalAreaToOutput(1000000#), 1#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:174.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputareatointernal"></a>
### CUnitSystem.OutputAreaToInternal

Переводит OutputAreaToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function OutputAreaToInternal(ByVal value As Double, Optional ByVal savedUnit As String = vbNullString) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |
| savedUnit | String; ByVal; Optional; default=vbNullString | Единица сохранённого Results; пустая использует текущую output-единицу CUnitSystem. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:112

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.savedArea", units.OutputAreaToInternal(2#, "cm2"), 200#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:175.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputfourthpowerlengthtointernal"></a>
### CUnitSystem.InputFourthPowerLengthToInternal

Переводит InputFourthPowerLengthToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputFourthPowerLengthToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:118

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.inputFourth", units.InputFourthPowerLengthToInternal(100#), 100#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:176.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalfourthpowerlengthtooutput"></a>
### CUnitSystem.InternalFourthPowerLengthToOutput

Переводит InternalFourthPowerLengthToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalFourthPowerLengthToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:123

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.outputFourth", units.InternalFourthPowerLengthToOutput(1000000000000#), 1#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:177.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputfourthpowerlengthtointernal"></a>
### CUnitSystem.OutputFourthPowerLengthToInternal

Переводит OutputFourthPowerLengthToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function OutputFourthPowerLengthToInternal(ByVal value As Double, Optional ByVal savedUnit As String = vbNullString) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |
| savedUnit | String; ByVal; Optional; default=vbNullString | Базовая единица длины сохранённого Results: mm/cm/m; степень 4 применяет сам метод. Не передавайте mm4/cm4/m4. Пустая строка использует текущую output-длину. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:129

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.savedFourth", units.OutputFourthPowerLengthToInternal(2#, "cm"), 20000#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:178.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputforcetointernal"></a>
### CUnitSystem.InputForceToInternal

Переводит InputForceToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputForceToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:135

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.force.input", units.InputForceToInternal(123#), 123#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:179.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalforcetooutput"></a>
### CUnitSystem.InternalForceToOutput

Переводит InternalForceToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalForceToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:140

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.force.output", units.InternalForceToOutput(123#), 123#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:180.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalforcelengthsquaredtooutput"></a>
### CUnitSystem.InternalForceLengthSquaredToOutput

Переводит InternalForceLengthSquaredToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalForceLengthSquaredToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:147

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.stiffness", units.InternalForceLengthSquaredToOutput(1000000#), 1#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:181.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputmomentmxtointernal"></a>
### CUnitSystem.InputMomentMxToInternal

Переводит InputMomentMxToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputMomentMxToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:152

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.moment.inputX", units.InputMomentMxToInternal(12#), 12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:182.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputmomentmytointernal"></a>
### CUnitSystem.InputMomentMyToInternal

Переводит InputMomentMyToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputMomentMyToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:157

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.moment.inputY", units.InputMomentMyToInternal(-12#), -12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:183.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputmomentperlengthtointernal"></a>
### CUnitSystem.InputMomentPerLengthToInternal

Переводит InputMomentPerLengthToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputMomentPerLengthToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:164

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.momentPerLength", units.InputMomentPerLengthToInternal(12#), 12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:184.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalmomentmxtooutput"></a>
### CUnitSystem.InternalMomentMxToOutput

Переводит InternalMomentMxToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalMomentMxToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:169

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.moment.outputX", units.InternalMomentMxToOutput(12#), 12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:185.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalmomentmytooutput"></a>
### CUnitSystem.InternalMomentMyToOutput

Переводит InternalMomentMyToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalMomentMyToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:174

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.moment.outputY", units.InternalMomentMyToOutput(-12#), -12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:186.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalmomentmagnitudetooutput"></a>
### CUnitSystem.InternalMomentMagnitudeToOutput

Переводит InternalMomentMagnitudeToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalMomentMagnitudeToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:179

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.moment.magnitude", units.InternalMomentMagnitudeToOutput(12#), 12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:187.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputstresstointernal"></a>
### CUnitSystem.InputStressToInternal

Переводит InputStressToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputStressToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:184

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.stress.input", units.InputStressToInternal(12#), 12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:188.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalstresstooutput"></a>
### CUnitSystem.InternalStressToOutput

Переводит InternalStressToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalStressToOutput(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:189

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.stress.output", units.InternalStressToOutput(12#), 12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:189.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputstresstointernal"></a>
### CUnitSystem.OutputStressToInternal

Переводит OutputStressToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function OutputStressToInternal(ByVal value As Double, Optional ByVal savedUnit As String = vbNullString) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |
| savedUnit | String; ByVal; Optional; default=vbNullString | Единица сохранённого Results; пустая использует текущую output-единицу CUnitSystem. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:195

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.stress.saved", units.OutputStressToInternal(12#, "MPa"), 12#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:190.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputcurvaturetointernal"></a>
### CUnitSystem.InputCurvatureToInternal

Переводит InputCurvatureToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function InputCurvatureToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:201

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.curvature.input", units.InputCurvatureToInternal(0.01), 0.01
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:191.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-internalcurvaturetooutput"></a>
### CUnitSystem.InternalCurvatureToOutput

Переводит InternalCurvatureToOutput из внутренних единиц в подготовленные output units; сохранённая единица при наличии имеет явный смысл.

```vb
Public Function InternalCurvatureToOutput(ByVal value As Double, Optional ByVal savedUnit As String = vbNullString) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |
| savedUnit | String; ByVal; Optional; default=vbNullString | Единица сохранённого Results; пустая использует текущую output-единицу CUnitSystem. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:207

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.curvature.output", units.InternalCurvatureToOutput(0.001, "1/m"), 1#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:192.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputcurvaturetointernal"></a>
### CUnitSystem.OutputCurvatureToInternal

Переводит OutputCurvatureToInternal во внутренние мм/Н/Н*мм/МПа/1/мм соответствующей размерности, с принятой конвенцией знаков для N/Mx/My.

```vb
Public Function OutputCurvatureToInternal(ByVal value As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Double; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:213

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Near "units.curvature.inverse", units.OutputCurvatureToInternal(0.001), 0.001
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:193.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputlengthunit"></a>
### CUnitSystem.OutputLengthUnit

Возвращает текущий output selector LengthUnit, без преобразования или округления данных.

```vb
Public Property Get OutputLengthUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:217

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.length", units.OutputLengthUnit = "m"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:194.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputareaunit"></a>
### CUnitSystem.OutputAreaUnit

Возвращает текущий output selector AreaUnit, без преобразования или округления данных.

```vb
Public Property Get OutputAreaUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:221

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.area", units.OutputAreaUnit = "m2"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:195.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputmomentunit"></a>
### CUnitSystem.OutputMomentUnit

Возвращает текущий output selector MomentUnit, без преобразования или округления данных.

```vb
Public Property Get OutputMomentUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:225

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.moment", units.OutputMomentUnit = "N*mm"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:197.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-inputmomentperlengthunit"></a>
### CUnitSystem.InputMomentPerLengthUnit

Возвращает единицу пользовательского момента на длину по input force/moment/length settings.

```vb
Public Property Get InputMomentPerLengthUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:230

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.momentPerLength", units.InputMomentPerLengthUnit = "N*mm/mm"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:198.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputforceunit"></a>
### CUnitSystem.OutputForceUnit

Возвращает текущий output selector ForceUnit, без преобразования или округления данных.

```vb
Public Property Get OutputForceUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:234

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.force", units.OutputForceUnit = "N"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:196.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputforcelengthsquaredunit"></a>
### CUnitSystem.OutputForceLengthSquaredUnit

Возвращает текущий output selector ForceLengthSquaredUnit, без преобразования или округления данных.

```vb
Public Property Get OutputForceLengthSquaredUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:239

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.stiffness", units.OutputForceLengthSquaredUnit = "N*m2"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:199.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputstressunit"></a>
### CUnitSystem.OutputStressUnit

Возвращает текущий output selector StressUnit, без преобразования или округления данных.

```vb
Public Property Get OutputStressUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:243

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.stress", units.OutputStressUnit = "MPa"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:200.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputcurvatureunit"></a>
### CUnitSystem.OutputCurvatureUnit

Возвращает текущий output selector CurvatureUnit, без преобразования или округления данных.

```vb
Public Property Get OutputCurvatureUnit() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:247

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.selector.curvature", units.OutputCurvatureUnit = "1/mm"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:201.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputsignn"></a>
### CUnitSystem.OutputSignN

Возвращает текущий output selector SignN, без преобразования или округления данных.

```vb
Public Property Get OutputSignN() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:251

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.sign.N", units.OutputSignN = "Tension"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:202.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputsignmx"></a>
### CUnitSystem.OutputSignMx

Возвращает текущий output selector SignMx, без преобразования или округления данных.

```vb
Public Property Get OutputSignMx() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:255

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.sign.Mx", units.OutputSignMx = "+Y tension"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:203.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-cunitsystem-outputsignmy"></a>
### CUnitSystem.OutputSignMy

Возвращает текущий output selector SignMy, без преобразования или округления данных.

```vb
Public Property Get OutputSignMy() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: InitializeDefaults для программного источника либо LoadFromSettings на внешней границе. В рецепте преобразование каждого параметра один раз; сохранённые Results читаются с savedUnit.

Ошибки/исправление: Адресные ошибки units/sign settings; пустой/неизвестный активный selector не заменяется default. Приводите единицы через CUnitSystem один раз.

Source: src/Excel/CUnitSystem.cls:259

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiUnitExamples с его подготовленными локальными объектами/входом.

```vb
    Check "units.sign.My", units.OutputSignMy = "+X tension"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:204.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

## CConcreteRegion

Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

<a id="api-cconcreteregion-setowner"></a>
### CConcreteRegion.SetOwner

Назначает скалярное происхождение инженерной области без пересчёта A/контуров; это внешний coordinator API.

```vb
Public Sub SetOwner(ByVal combinationID As String, ByVal standard As String, ByVal anchorID As String)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| combinationID | String; ByVal; обязательный | Скалярная metadata владельца/источника; геометрическая классификация от строки не зависит. |
| standard | String; ByVal; обязательный | Скалярная metadata владельца/источника; геометрическая классификация от строки не зависит. |
| anchorID | String; ByVal; обязательный | Непустой уникальный ID модельной привязки. |

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:76

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestAnalyticClipping с его подготовленными локальными объектами/входом.

```vb
    clipped.SetOwner "LC1", "TEST", "R1"
```

Полный контекст: tests/modTestGeometryQuery.bas:148.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-getsegment"></a>
### CConcreteRegion.GetSegment

Возвращает точную аналитическую запись одного ребра в скаляры: мм, sweep радианы, loop-индекс.

```vb
Public Sub GetSegment(ByVal index As Long, ByRef x1 As Double, ByRef y1 As Double, ByRef x2 As Double, ByRef y2 As Double, ByRef centerX As Double, ByRef centerY As Double, ByRef sweep As Double, ByRef loopID As Long)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |
| x1 | Double; ByRef; обязательный | Модельная координата x1, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| y1 | Double; ByRef; обязательный | Модельная координата y1, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| x2 | Double; ByRef; обязательный | Модельная координата x2, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| y2 | Double; ByRef; обязательный | Модельная координата y2, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| centerX | Double; ByRef; обязательный | Модельная координата centerX, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| centerY | Double; ByRef; обязательный | Модельная координата centerY, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| sweep | Double; ByRef; обязательный | Signed sweep, радианы: CCW положителен, CW отрицателен, 0 запрещён, \|sweep\|≤2*pi. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| loopID | Long; ByRef; обязательный | Непустой устойчивый ID контура; у CConcreteRegion численный индекс loop 1..LoopCount. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:82

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    region.GetSegment 1, x, y, x2, y2, cx, cy, sweep, loopID
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:133.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-cconcreteregion-segmentcount"></a>
### CConcreteRegion.SegmentCount

Число аналитических line/arc сегментов.

```vb
Public Property Get SegmentCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:93

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.CheckClosed с его подготовленными локальными объектами/входом.

```vb
    For i = 1 To region.SegmentCount
```

Полный контекст: tests/modTestGeometryQuery.bas:94.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

Native entrypoint: modTestGeometryQuery.RunGeneratedContourOwnershipTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-boundaryprobes"></a>
### CConcreteRegion.BoundaryProbes

Копия сохранённых пассивных пар P/Q; Empty допустим, контуры по ним не восстанавливаются.

```vb
Public Property Get BoundaryProbes() As Variant
```

Тип результата: Variant. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:99

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPostAudit03RegionClone с его подготовленными локальными объектами/входом.

```vb
    readProbes = region.BoundaryProbes
```

Полный контекст: tests/modTestGeometryQuery.bas:381.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-boundaryprobecount"></a>
### CConcreteRegion.BoundaryProbeCount

Число сохранённых диагностических проб P/Q.

```vb
Public Property Get BoundaryProbeCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:102

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPostAudit03RegionClone с его подготовленными локальными объектами/входом.

```vb
    Check "postAudit03.clone.probesIndependent", readProbes(1, 2) = 1# And region.BoundaryProbeCount = 2
```

Полный контекст: tests/modTestGeometryQuery.bas:382.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-loopcount"></a>
### CConcreteRegion.LoopCount

Число подготовленных материальных loops.

```vb
Public Property Get LoopCount() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:105

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPostAudit03RegionClone с его подготовленными локальными объектами/входом.

```vb
    For i = 1 To region.LoopCount
```

Полный контекст: tests/modTestGeometryQuery.bas:375.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-loopisopening"></a>
### CConcreteRegion.LoopIsOpening

Читает классификацию конкретной loop по подготовленной топологии.

```vb
Public Property Get LoopIsOpening(ByVal index As Long) As Boolean
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| index | Long; ByVal; обязательный | 1-based индекс в пределах соответствующего готового контейнера. |

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:111

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPostAudit03RegionClone с его подготовленными локальными объектами/входом.

```vb
        Check "postAudit03.clone.role." & CStr(i), copy.LoopIsOpening(i) = region.LoopIsOpening(i) And nextCopy.LoopIsOpening(i) = region.LoopIsOpening(i)
```

Полный контекст: tests/modTestGeometryQuery.bas:376.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-area"></a>
### CConcreteRegion.Area

Аналитическая площадь материальной области, мм²; не механическая A сетки.

```vb
Public Property Get Area() As Double
```

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:115

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestAdjacentRectangles с его подготовленными локальными объектами/входом.

```vb
    Near "adjacent.area", region.Area, 240000#
```

Полный контекст: tests/modTestSectionRecipes.bas:1035.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-cconcreteregion-source"></a>
### CConcreteRegion.Source

Скалярное происхождение подготовленной области.

```vb
Public Property Get Source() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:118

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestKnownAndUnknownContours с его подготовленными локальными объектами/входом.

```vb
    Check "knownOuter.noOpening.authoritative", region.Source = "AuthoritativeContour"
```

Полный контекст: tests/modTestGeometryQuery.bas:593.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-sectionrevision"></a>
### CConcreteRegion.SectionRevision

Ревизия исходной модели, к которой относится область.

```vb
Public Property Get SectionRevision() As Long
```

Тип результата: Long. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:121

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestKnownAndUnknownContours с его подготовленными локальными объектами/входом.

```vb
    revision = region.SectionRevision
```

Полный контекст: tests/modTestGeometryQuery.bas:608.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-ownerid"></a>
### CConcreteRegion.OwnerID

Инженерный владелец области; назначается coordinator, не геометрической классификацией.

```vb
Public Property Get OwnerID() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:124

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestAnalyticClipping с его подготовленными локальными объектами/входом.

```vb
    Check "copy.owner", copy.OwnerID = "LC1" And copy.AnchorID = "R1"
```

Полный контекст: tests/modTestGeometryQuery.bas:150.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-standard"></a>
### CConcreteRegion.Standard

Скалярная нормативная принадлежность инженерного владельца; geometry не вычисляет нормативные коэффициенты.

```vb
Public Property Get Standard() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:127

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPostAudit03RegionClone с его подготовленными локальными объектами/входом.

```vb
    Check "postAudit03.clone.owner", copy.OwnerID = "COPY_LC" And copy.Standard = "SP35" And copy.AnchorID = "G7"
```

Полный контекст: tests/modTestGeometryQuery.bas:365.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-anchorid"></a>
### CConcreteRegion.AnchorID

Скалярный ID сохранённой инженерной области.

```vb
Public Property Get AnchorID() As String
```

Тип результата: String. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:130

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestAnalyticClipping с его подготовленными локальными объектами/входом.

```vb
    Check "copy.owner", copy.OwnerID = "LC1" And copy.AnchorID = "R1"
```

Полный контекст: tests/modTestGeometryQuery.bas:150.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-cconcreteregion-clone"></a>
### CConcreteRegion.Clone

Копирует готовую область и metadata; временные массивы следующей операции не меняют исходный snapshot.

```vb
Public Function Clone() As CConcreteRegion
```

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Готовый аналитический snapshot общего query. Геометрия read-only; Clone отделяет следующий рабочий результат. SetOwner меняет только скалярную инженерную metadata.

Ошибки/исправление: 5400: индекс вне SegmentCount/LoopCount. Используйте диапазоны готового snapshot; пустая область и Nothing различаются.

Source: src/Section/CConcreteRegion.cls:136

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestAnalyticClipping с его подготовленными локальными объектами/входом.

```vb
    Set copy = clipped.Clone
```

Полный контекст: tests/modTestGeometryQuery.bas:145.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

## CSectionGeometryQuery

Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

<a id="api-csectiongeometryquery-lastdiagnostic"></a>
### CSectionGeometryQuery.LastDiagnostic

Последняя машинная диагностика; Nothing при отсутствии записанного события.

```vb
Public Property Get LastDiagnostic() As CGeometryDiagnostic
```

Тип результата: CGeometryDiagnostic. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:31

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.InvalidOperation с его подготовленными локальными объектами/входом.

```vb
    Set diagnostic = query.LastDiagnostic
```

Полный контекст: tests/modTestRecipeOperations.bas:88.

Native entrypoint: modTestRecipeOperations.RunRecipeOperationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiongeometryquery-transformcoordinates"></a>
### CSectionGeometryQuery.TransformCoordinates

Преобразует скалярную точку: reflectX, rotation, shift; общий порядок совпадает с путями.

```vb
Public Sub TransformCoordinates(ByRef x As Double, ByRef y As Double, ByVal shiftX As Double, ByVal shiftY As Double, Optional ByVal rotation As Double = 0#, Optional ByVal reflectX As Boolean = False)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| x | Double; ByRef; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| y | Double; ByRef; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| shiftX | Double; ByVal; обязательный | Перенос по X, мм. |
| shiftY | Double; ByVal; обязательный | Перенос по Y, мм. |
| rotation | Double; ByVal; Optional; default=0# | Угол поворота вокруг (0,0), радианы, CCW положителен. |
| reflectX | Boolean; ByVal; Optional; default=False | Отражение относительно локальной оси X перед поворотом и переносом. |

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:36

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    x = 1#: y = 2#: query.TransformCoordinates x, y, 10#, 20#, GEOM_PI / 2#, True
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:135.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiongeometryquery-offsetpath"></a>
### CSectionGeometryQuery.OffsetPath

Смещает линию/аналитическую цепочку слева от обхода при положительном signedLeftDistance. Line/line стыки miter; arc стыки должны быть гладкими.

```vb
Public Function OffsetPath(ByVal pathID As String, ByVal source As CGeometryPath, ByVal distance As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| source | CGeometryPath; ByVal; обязательный | Подготовленный объект/контейнер выбранного запроса, без повторного чтения Excel или назначения типа. |
| distance | Double; ByVal; обязательный | Длина/станция/граница distance, внутренние мм; направление и пределы задаёт выбранный запрос. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:48

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.InvalidOperation с его подготовленными локальными объектами/входом.

```vb
            Set result = query.OffsetPath("Failed", path, 1#)
```

Полный контекст: tests/modTestRecipeOperations.bas:83.

Native entrypoint: modTestRecipeOperations.RunRecipeOperationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiongeometryquery-constrainline"></a>
### CSectionGeometryQuery.ConstrainLine

Ограничивает или продлевает одну прямую двумя поперечными плоскостями nX*x+nY*y=bound; направление исходного пути сохраняется.

```vb
Public Function ConstrainLine(ByVal pathID As String, ByVal source As CGeometryPath, ByVal startNX As Double, ByVal startNY As Double, ByVal startBound As Double, ByVal endNX As Double, ByVal endNY As Double, ByVal endBound As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| source | CGeometryPath; ByVal; обязательный | Подготовленный объект/контейнер выбранного запроса, без повторного чтения Excel или назначения типа. |
| startNX | Double; ByVal; обязательный | X-компонента начальной поперечной нормали; линия не должна быть параллельна плоскости. |
| startNY | Double; ByVal; обязательный | Y-компонента начальной поперечной нормали. |
| startBound | Double; ByVal; обязательный | Значение начальной плоскости startNX*x+startNY*y=startBound; мм при единичной нормали. |
| endNX | Double; ByVal; обязательный | X-компонента конечной поперечной нормали. |
| endNY | Double; ByVal; обязательный | Y-компонента конечной поперечной нормали. |
| endBound | Double; ByVal; обязательный | Значение конечной плоскости endNX*x+endNY*y=endBound; мм при единичной нормали. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:116

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.InvalidOperation с его подготовленными локальными объектами/входом.

```vb
            Set result = query.ConstrainLine("Failed", path, 1#, 0#, 0#, 1#, 0#, 10#)
```

Полный контекст: tests/modTestRecipeOperations.bas:79.

Native entrypoint: modTestRecipeOperations.RunRecipeOperationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-csectiongeometryquery-initialize"></a>
### CSectionGeometryQuery.Initialize

Привязывает query к CSectionModel/revision. Достоверные контуры приоритетны; иначе используются реальные границы КЭ.

```vb
Public Sub Initialize(ByVal section As CSectionModel)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| section | CSectionModel; ByVal; обязательный | CSectionModel на внешней границе query/build; ядро не читает Excel. |

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:150

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestMesh с его подготовленными локальными объектами/входом.

```vb
    query.Initialize model
```

Полный контекст: tests/modTestGeometryQuery.bas:257.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-concretedomain"></a>
### CSectionGeometryQuery.ConcreteDomain

Возвращает clone области текущей query-session; не подменяет A/I механической сетки.

```vb
Public Function ConcreteDomain() As CConcreteRegion
```

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:177

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestMesh с его подготовленными локальными объектами/входом.

```vb
    Set region = query.ConcreteDomain
```

Полный контекст: tests/modTestGeometryQuery.bas:258.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-projectionbounds"></a>
### CSectionGeometryQuery.ProjectionBounds

Находит min/max аналитической области в заданном направлении, включая внутренние экстремумы дуг.

```vb
Public Sub ProjectionBounds(ByVal region As CConcreteRegion, ByVal nx As Double, ByVal ny As Double, ByRef minimum As Double, ByRef maximum As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| nx | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| ny | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| minimum | Double; ByRef; обязательный | Длина/станция/граница minimum, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| maximum | Double; ByRef; обязательный | Длина/станция/граница maximum, внутренние мм; направление и пределы задаёт выбранный запрос. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:185

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestRotatedAndTouchingGeometry с его подготовленными локальными объектами/входом.

```vb
    query.ProjectionBounds region, Cos(angle), Sin(angle), minimum, maximum
```

Полный контекст: tests/modTestGeometryQuery.bas:715.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-openingbounds"></a>
### CSectionGeometryQuery.OpeningBounds

Возвращает габариты всех заданных отверстий из контуров, без ограничителя только первым отверстием.

```vb
Public Sub OpeningBounds(ByVal contours As CSectionContours, ByRef bounds() As Double, ByRef openingCount As Long)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| contours | CSectionContours; ByVal; обязательный | CSectionContours с достоверными аналитическими Outer/Opening. |
| bounds | Double(); ByRef; обязательный | Выходной массив габаритов, мм; формат определяется конкретным запросом. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| openingCount | Long; ByRef; обязательный | Целый неотрицательный счётчик; для ByCount применяется отдельно к каждому пути. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:246

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestGeneratedContoursWithoutAnnotations с его подготовленными локальными объектами/входом.

```vb
        query.OpeningBounds model.Contours, bounds, openingCount
```

Полный контекст: tests/modTestGeometryQuery.bas:786.

Native entrypoint: modTestGeometryQuery.RunGeneratedContourOwnershipTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-polygonregion"></a>
### CSectionGeometryQuery.PolygonRegion

Готовит материальную область по замкнутому многоугольнику и проверяет топологию.

```vb
Public Function PolygonRegion(ByVal coordinates As Variant) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| coordinates | Variant; ByVal; обязательный | Массив координат вершин замкнутого многоугольника, мм. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:272

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestRotatedAndTouchingGeometry с его подготовленными локальными объектами/входом.

```vb
    Set region = query.PolygonRegion(points)
```

Полный контекст: tests/modTestGeometryQuery.bas:708.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-circleregion"></a>
### CSectionGeometryQuery.CircleRegion

Создаёт точную круговую область по центру и положительному R.

```vb
Public Function CircleRegion(ByVal centerX As Double, ByVal centerY As Double, ByVal radius As Double) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| centerX | Double; ByVal; обязательный | Модельная координата centerX, мм; знаки соответствуют section XY/WCS. |
| centerY | Double; ByVal; обязательный | Модельная координата centerY, мм; знаки соответствуют section XY/WCS. |
| radius | Double; ByVal; обязательный | Положительный радиус, мм. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:287

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestOpenings с его подготовленными локальными объектами/входом.

```vb
    Set hole = query.CircleRegion(40#, 50#, 10#)
```

Полный контекст: tests/modTestGeometryQuery.bas:211.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-boundaryregion"></a>
### CSectionGeometryQuery.BoundaryRegion

Готовит область по аналитическим рёбрам, сшивает/проверяет замкнутые loops и роли.

```vb
Public Function BoundaryRegion(ByRef edges() As TRegionEdge, ByVal count As Long, Optional ByVal source As String = "ValidatedContour") As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| edges | TRegionEdge(); ByRef; обязательный | Массив TRegionEdge аналитических рёбер с loop-данными, мм/радианы. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| count | Long; ByVal; обязательный | Целый неотрицательный счётчик; для ByCount применяется отдельно к каждому пути. |
| source | String; ByVal; Optional; default="ValidatedContour" | Подготовленный объект/контейнер выбранного запроса, без повторного чтения Excel или назначения типа. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:298

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestHollowArcJunctions с его подготовленными локальными объектами/входом.

```vb
        Set rotated = query.BoundaryRegion(raw, count, "HollowJunctionFixture")
```

Полный контекст: tests/modTestGeometryQuery.bas:477.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-loopisopening"></a>
### CSectionGeometryQuery.LoopIsOpening

Классифицирует подготовленную loop геометрически, не по строке имени.

```vb
Public Function LoopIsOpening(ByVal region As CConcreteRegion, ByVal loopID As Long) As Boolean
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| loopID | Long; ByVal; обязательный | Непустой устойчивый ID контура; у CConcreteRegion численный индекс loop 1..LoopCount. |

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:382

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "query.loopRole.opening", query.LoopIsOpening(frame, 2)
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:127.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiongeometryquery-connectedregionatpoint"></a>
### CSectionGeometryQuery.ConnectedRegionAtPoint

Возвращает связанную компоненту материальной области по точке.

```vb
Public Function ConnectedRegionAtPoint(ByVal region As CConcreteRegion, ByVal x As Double, ByVal y As Double) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| x | Double; ByVal; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. |
| y | Double; ByVal; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:394

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestConnectedRegionSelection с его подготовленными локальными объектами/входом.

```vb
    Set selected = query.ConnectedRegionAtPoint(region, 10#, 50#)
```

Полный контекст: tests/modTestGeometryQuery.bas:405.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-mergedisjointregions"></a>
### CSectionGeometryQuery.MergeDisjointRegions

Объединяет непересекающиеся области; не является универсальным Union перекрывающихся фигур.

```vb
Public Function MergeDisjointRegions(ByVal regions As Collection) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| regions | Collection; ByVal; обязательный | Collection готовых непересекающихся областей для MergeDisjointRegions. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:450

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPostAudit03RegionClone с его подготовленными локальными объектами/входом.

```vb
    Set region = query.MergeDisjointRegions(regions)
```

Полный контекст: tests/modTestGeometryQuery.bas:355.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-subtractcontainedregion"></a>
### CSectionGeometryQuery.SubtractContainedRegion

Вычитает строго вложенное отверстие, отклоняя нарушенные отношения границ.

```vb
Public Function SubtractContainedRegion(ByVal outer As CConcreteRegion, ByVal opening As CConcreteRegion) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| outer | CConcreteRegion; ByVal; обязательный | Исходная область материала/наружная область. |
| opening | CConcreteRegion; ByVal; обязательный | Вычитаемая область отверстия. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:471

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Set opening = query.CircleRegion(0#, 0#, 20#): Set frame = query.SubtractContainedRegion(region, opening)
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:125.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiongeometryquery-subtractregion"></a>
### CSectionGeometryQuery.SubtractRegion

Вычитает область по действующему ограниченному контурному контракту query; проверяет допустимость результата.

```vb
Public Function SubtractRegion(ByVal outer As CConcreteRegion, ByVal opening As CConcreteRegion) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| outer | CConcreteRegion; ByVal; обязательный | Исходная область материала/наружная область. |
| opening | CConcreteRegion; ByVal; обязательный | Вычитаемая область отверстия. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:535

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestIntervals с его подготовленными локальными объектами/входом.

```vb
    Set region = query.SubtractRegion(region, hole)
```

Полный контекст: tests/modTestGeometryQuery.bas:230.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-regionscoincide"></a>
### CSectionGeometryQuery.RegionsCoincide

Проверяет совпадение подготовленных областей по геометрическому контракту.

```vb
Public Function RegionsCoincide(ByVal first As CConcreteRegion, ByVal second As CConcreteRegion) As Boolean
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| first | CConcreteRegion; ByVal; обязательный | Первая/вторая сравниваемая готовая область. |
| second | CConcreteRegion; ByVal; обязательный | Первая/вторая сравниваемая готовая область. |

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:554

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestAnalyticClipping с его подготовленными локальными объектами/входом.

```vb
    Check "regionEquality.same", query.RegionsCoincide(region, copy)
```

Полный контекст: tests/modTestGeometryQuery.bas:120.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-cliphalfplane"></a>
### CSectionGeometryQuery.ClipHalfPlane

Обрезает материальную область полуплоскостью, сохраняя аналитические рёбра и топологию.

```vb
Public Function ClipHalfPlane(ByVal region As CConcreteRegion, ByVal nx As Double, ByVal ny As Double, ByVal bound As Double) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| nx | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| ny | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| bound | Double; ByVal; обязательный | Длина/станция/граница bound, внутренние мм; направление и пределы задаёт выбранный запрос. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:572

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPreparedGeometry с его подготовленными локальными объектами/входом.

```vb
    Set region = query.ClipHalfPlane(region, 1#, 0#, 31#)
```

Полный контекст: tests/modTestGeometryQuery.bas:182.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-clipwindow"></a>
### CSectionGeometryQuery.ClipWindow

Обрезает область конечным окном в направленных n/t координатах.

```vb
Public Function ClipWindow(ByVal region As CConcreteRegion, ByVal nx As Double, ByVal ny As Double, ByVal nMin As Double, ByVal nMax As Double, ByVal tMin As Double, ByVal tMax As Double) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| nx | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| ny | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| nMin | Double; ByVal; обязательный | Длина/станция/граница nMin, внутренние мм; направление и пределы задаёт выбранный запрос. |
| nMax | Double; ByVal; обязательный | Длина/станция/граница nMax, внутренние мм; направление и пределы задаёт выбранный запрос. |
| tMin | Double; ByVal; обязательный | Длина/станция/граница tMin, внутренние мм; направление и пределы задаёт выбранный запрос. |
| tMax | Double; ByVal; обязательный | Длина/станция/граница tMax, внутренние мм; направление и пределы задаёт выбранный запрос. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:644

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestFirstMaterialWall с его подготовленными локальными объектами/входом.

```vb
    Set wall = query.ClipWindow(wall, 0#, 1#, 0#, 100#, -50#, -30#)
```

Полный контекст: tests/modTestGeometryQuery.bas:560.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-materialregionthroughplane"></a>
### CSectionGeometryQuery.MaterialRegionThroughPlane

Получает материальную область по заданной плоскости и окну; не нормативный расчёт трещин.

```vb
Public Function MaterialRegionThroughPlane(ByVal region As CConcreteRegion, ByVal nx As Double, ByVal ny As Double, ByVal seedPlane As Double) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| nx | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| ny | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| seedPlane | Double; ByVal; обязательный | Подготовленный объект/контейнер выбранного запроса, без повторного чтения Excel или назначения типа. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:661

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestFirstMaterialWall с его подготовленными локальными объектами/входом.

```vb
    Set wall = query.MaterialRegionThroughPlane(region, 0#, 1#, 85#)
```

Полный контекст: tests/modTestGeometryQuery.bas:554.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-containspoint"></a>
### CSectionGeometryQuery.ContainsPoint

Проверяет действительную принадлежность материальной области с заданной политикой границы.

```vb
Public Function ContainsPoint(ByVal region As CConcreteRegion, ByVal x As Double, ByVal y As Double, Optional ByVal includeBoundary As Boolean = True) As Boolean
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| x | Double; ByVal; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. |
| y | Double; ByVal; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. |
| includeBoundary | Boolean; ByVal; Optional; default=True | Считать точку на границе принадлежащей области. |

Тип результата: Boolean. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:820

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestAdjacentRectangles с его подготовленными локальными объектами/входом.

```vb
    Check "adjacent.lower", query.ContainsPoint(region, 500#, 100#)
```

Полный контекст: tests/modTestSectionRecipes.bas:1037.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiongeometryquery-boundarydistance"></a>
### CSectionGeometryQuery.BoundaryDistance

Возвращает минимальное расстояние до любой внешней/внутренней границы, мм.

```vb
Public Function BoundaryDistance(ByVal region As CConcreteRegion, ByVal x As Double, ByVal y As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| x | Double; ByVal; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. |
| y | Double; ByVal; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:830

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    Near "distance.inside", query.BoundaryDistance(region, 90#, -20#), 20#
```

Полный контекст: tests/modTestSectionRecipes.bas:238.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiongeometryquery-roundedpolygon"></a>
### CSectionGeometryQuery.RoundedPolygon

Создаёт согласованную границу по вершинам/радиусам/ID. Edge.ID начинается у указанной вершины, Corner.ID существует только при R>0.

```vb
Public Function RoundedPolygon(ByVal pathID As String, ByVal vertices As Variant, ByVal radii As Variant, ByVal vertexIDs As Variant) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| vertices | Variant; ByVal; обязательный | Двумерные вершины: Array(Array(x,y),...); координаты во внутренних мм. |
| radii | Variant; ByVal; обязательный | Массив неотрицательных радиусов вершин в мм, длина равна vertices; clamp бетонного радиуса отсутствует. |
| vertexIDs | Variant; ByVal; обязательный | Массив уникальных смысловых ID вершин; определяет Edge.ID/Corner.ID. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:862

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunRoundedOffsetTests с его подготовленными локальными объектами/входом.

```vb
    Set original = query.RoundedPolygon("ConcaveBase", vertices, radii, names)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:250.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiongeometryquery-offsetroundedpolygon"></a>
### CSectionGeometryQuery.OffsetRoundedPolygon

Смещает весь скруглённый многоугольник с согласованными стыками. Положительное расстояние внутрь площади; отрицательное наружу, из Opening в бетон.

```vb
Public Function OffsetRoundedPolygon(ByVal pathID As String, ByVal vertices As Variant, ByVal radii As Variant, ByVal vertexIDs As Variant, ByVal distance As Double) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| vertices | Variant; ByVal; обязательный | Двумерные вершины: Array(Array(x,y),...); координаты во внутренних мм. |
| radii | Variant; ByVal; обязательный | Массив неотрицательных радиусов вершин в мм, длина равна vertices; clamp бетонного радиуса отсутствует. |
| vertexIDs | Variant; ByVal; обязательный | Массив уникальных смысловых ID вершин; определяет Edge.ID/Corner.ID. |
| distance | Double; ByVal; обязательный | Signed offset, мм: положительно внутрь площади, отрицательно наружу; это не left-offset обхода. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:932

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunRoundedOffsetTests с его подготовленными локальными объектами/входом.

```vb
    Set path = query.OffsetRoundedPolygon("ConcaveOffset", vertices, radii, names, 2#)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:252.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiongeometryquery-regionfrompath"></a>
### CSectionGeometryQuery.RegionFromPath

Готовит область по одному замкнутому аналитическому пути; открытый путь не становится бетоном.

```vb
Public Function RegionFromPath(ByVal path As CGeometryPath) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| path | CGeometryPath; ByVal; обязательный | Существующий непрерывный опубликованный CGeometryPath. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:991

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunRoundedPolygonTests с его подготовленными локальными объектами/входом.

```vb
    Set region = query.RegionFromPath(path)
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:160.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunRoundedPolygonTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/RoundedPolygons.txt.

<a id="api-csectiongeometryquery-adjacentrectangles"></a>
### CSectionGeometryQuery.AdjacentRectangles

Создаёт одну границу смежных неперекрывающихся прямоугольников. Произвольное пересекающееся CAD Union не выполняется.

```vb
Public Function AdjacentRectangles(ByVal pathID As String, ByVal rectangles As Variant) As CGeometryPath
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pathID | String; ByVal; обязательный | Непустой уникальный ID пути в определении. |
| rectangles | Variant; ByVal; обязательный | Array(Array(x,y,width,height),...); мм, размеры положительные, прямоугольники смежные без перекрытий. |

Тип результата: CGeometryPath. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:1003

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.InvalidAdjacentRejected с его подготовленными локальными объектами/входом.

```vb
    Set path = query.AdjacentRectangles("Bad", Array(Array(0#, 0#, 100#, 100#), rect))
```

Полный контекст: tests/modTestSectionRecipes.bas:1058.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-csectiongeometryquery-lineintervals"></a>
### CSectionGeometryQuery.LineIntervals

Возвращает реальные материальные интервалы пересечения с линией, с отверстиями и всеми компонентами.

```vb
Public Function LineIntervals(ByVal region As CConcreteRegion, ByVal pointX As Double, ByVal pointY As Double, ByVal directionX As Double, ByVal directionY As Double, Optional ByVal parameterMin As Double = -1E+100, Optional ByVal parameterMax As Double = 1E+100) As Variant
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| pointX | Double; ByVal; обязательный | Модельная координата pointX, мм; знаки соответствуют section XY/WCS. |
| pointY | Double; ByVal; обязательный | Модельная координата pointY, мм; знаки соответствуют section XY/WCS. |
| directionX | Double; ByVal; обязательный | X-компонента направления проекции/выбора экстремума; вектор не нулевой, у RebarRowExtremeLabel единичный. |
| directionY | Double; ByVal; обязательный | Y-компонента направления проекции/выбора экстремума. |
| parameterMin | Double; ByVal; Optional; default=-1E+100 | Граница нормированного параметра выбранной линии/интервала. |
| parameterMax | Double; ByVal; Optional; default=1E+100 | Граница нормированного параметра выбранной линии/интервала. |

Тип результата: Variant. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:1174

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestIntervals с его подготовленными локальными объектами/входом.

```vb
    intervals = query.LineIntervals(region, 10#, 50#, 1#, 0#)
```

Полный контекст: tests/modTestGeometryQuery.bas:231.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-samplematerialintervals"></a>
### CSectionGeometryQuery.SampleMaterialIntervals

Получает материальные интервалы для заданных направлений/уровней; не восстанавливает область по одной площади.

```vb
Public Function SampleMaterialIntervals(ByVal region As CConcreteRegion, ByVal nx As Double, ByVal ny As Double, ByVal seedPlane As Double, ByVal tMin As Double, ByVal tMax As Double, ByVal probeCount As Long) As Variant
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| nx | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| ny | Double; ByVal; обязательный | Компонента нормали/направления в section XY; вектор не нулевой. |
| seedPlane | Double; ByVal; обязательный | Signed нормальная координата опорной плоскости, мм, относительно начала section XY; это скаляр Double, не объект плоскости. |
| tMin | Double; ByVal; обязательный | Длина/станция/граница tMin, внутренние мм; направление и пределы задаёт выбранный запрос. |
| tMax | Double; ByVal; обязательный | Длина/станция/граница tMax, внутренние мм; направление и пределы задаёт выбранный запрос. |
| probeCount | Long; ByVal; обязательный | Целый неотрицательный счётчик; для ByCount применяется отдельно к каждому пути. |

Тип результата: Variant. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:1235

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    probes = query.SampleMaterialIntervals(region, 1#, 0#, 0#, -10#, 10#, 3)
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:129.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-csectiongeometryquery-concretecoverfrompointalongdirection"></a>
### CSectionGeometryQuery.ConcreteCoverFromPointAlongDirection

В текущей query-session находит геометрическое расстояние до бетонной границы по заданному направлению.

```vb
Public Function ConcreteCoverFromPointAlongDirection(ByVal pointX As Double, ByVal pointY As Double, ByVal directionX As Double, ByVal directionY As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| pointX | Double; ByVal; обязательный | Модельная координата pointX, мм; знаки соответствуют section XY/WCS. |
| pointY | Double; ByVal; обязательный | Модельная координата pointY, мм; знаки соответствуют section XY/WCS. |
| directionX | Double; ByVal; обязательный | X-компонента направления проекции/выбора экстремума; вектор не нулевой, у RebarRowExtremeLabel единичный. |
| directionY | Double; ByVal; обязательный | Y-компонента направления проекции/выбора экстремума. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:1267

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestMesh с его подготовленными локальными объектами/входом.

```vb
    CheckNear "mesh.cover", query.ConcreteCoverFromPointAlongDirection(5#, 5#, 1#, 0#), 15#
```

Полный контекст: tests/modTestGeometryQuery.bas:262.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-regionfromcontours"></a>
### CSectionGeometryQuery.RegionFromContours

Готовит область из единственных достоверных CSectionContours Outer/Opening.

```vb
Public Function RegionFromContours(ByVal contours As CSectionContours) As CConcreteRegion
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| contours | CSectionContours; ByVal; обязательный | CSectionContours с достоверными аналитическими Outer/Opening. |

Тип результата: CConcreteRegion. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:1406

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPreparedGeometry с его подготовленными локальными объектами/входом.

```vb
    Set region = query.RegionFromContours(contours)
```

Полный контекст: tests/modTestGeometryQuery.bas:163.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

<a id="api-csectiongeometryquery-regioncentroid"></a>
### CSectionGeometryQuery.RegionCentroid

Вычисляет аналитический центр материальной области, мм; не заменяет центр механической сетки НДС.

```vb
Public Sub RegionCentroid(ByVal region As CConcreteRegion, ByRef x As Double, ByRef y As Double)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| region | CConcreteRegion; ByVal; обязательный | Готовый CConcreteRegion; Nothing не является пустой областью. |
| x | Double; ByRef; обязательный | Модельная координата x, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |
| y | Double; ByRef; обязательный | Модельная координата y, мм; знаки соответствуют section XY/WCS. ByRef: возвращаемые скаляры/буфер можно изменять, исходный immutable snapshot не меняется. |

Жизненный цикл: Общие операции над готовыми областями/путями; Initialize нужен для query-session по CSectionModel. Новая revision требует актуальной session, исходная область/контуры не меняются.

Ошибки/исправление: 5401: нарушенная топология/радиусы/ограничения/отсутствующая область. Новые offsets/constraints имеют явные Code/ID/числа; GEOMETRY_INVALID используется прочими контрактами.

Source: src/Section/CSectionGeometryQuery.cls:1426

Минимальный вызов; требуемый контекст: В теле modTestGeometryQuery.TestPreparedGeometry с его подготовленными локальными объектами/входом.

```vb
    query.RegionCentroid region, x, y
```

Полный контекст: tests/modTestGeometryQuery.bas:179.

Native entrypoint: modTestGeometryQuery.RunGeometryQueryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/QueriesAndContours.txt.

## modSectionRecipeTypes

Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

<a id="api-modsectionrecipetypes-esectionlooprole"></a>
### modSectionRecipeTypes.ESectionLoopRole

Outer/Opening — геометрические роли, не выводятся из имени контура.

```vb
Public Enum ESectionLoopRole
```

Поля/селекторы по source:

```vb
LoopOuter = 1
LoopOpening = 2
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:6

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    loopValue.PathID = "Concrete": loopValue.Role = LoopOuter
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:231.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modsectionrecipetypes-erebarendmode"></a>
### modSectionRecipeTypes.ERebarEndMode

IncludeBoth/ExcludeBoth/IncludeStart/IncludeEnd/ClosedUniform; последние требуют соответствующей замкнутости.

```vb
Public Enum ERebarEndMode
```

Поля/селекторы по source:

```vb
IncludeBoth = 1
ExcludeBoth = 2
IncludeStart = 3
IncludeEnd = 4
ClosedUniform = 5
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:11

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.RunRecipeRuleTests с его подготовленными локальными объектами/входом.

```vb
    options.EndMode = ExcludeBoth
```

Полный контекст: tests/modTestSectionRecipes.bas:183.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-modsectionrecipetypes-erebardistribution"></a>
### modSectionRecipeTypes.ERebarDistribution

ByCount/ByMaxStep/ByFixedStep/ExplicitPositions/ProjectFrom/DependentOffset — режимы общего исполнителя.

```vb
Public Enum ERebarDistribution
```

Поля/селекторы по source:

```vb
ByCount = 1
ByMaxStep = 2
ByFixedStep = 3
ExplicitPositions = 4
ProjectFrom = 5
DependentOffset = 6
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:19

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Check "raw.rule", ruleValue.RuleID = "Bars" And ruleValue.Mode = ByCount
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:236.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modsectionrecipetypes-erebardistributionscope"></a>
### modSectionRecipeTypes.ERebarDistributionScope

Только PerPath: количество/шаг/setbacks отдельно для каждого пути группы.

```vb
Public Enum ERebarDistributionScope
```

Поля/селекторы по source:

```vb
PerPath = 1
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:29

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    options.DistributionScope = PerPath: options.StartSetback = 20#: options.EndSetback = 30#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:61.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-modsectionrecipetypes-eremainderplacement"></a>
### modSectionRecipeTypes.ERemainderPlacement

RemainderStart/End/Center: положение остатка для точного шага.

```vb
Public Enum ERemainderPlacement
```

Поля/селекторы по source:

```vb
RemainderStart = 1
RemainderEnd = 2
RemainderCenter = 3
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:33

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiGeometryReadExamples с его подготовленными локальными объектами/входом.

```vb
    Check "defaults.remainder", options.RemainderPlacement = RemainderCenter
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:105.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

<a id="api-modsectionrecipetypes-erebarpublication"></a>
### modSectionRecipeTypes.ERebarPublication

PublishByRule или PublishPerSourcePosition; влияет на вывод, не геометрический шаг.

```vb
Public Enum ERebarPublication
```

Поля/селекторы по source:

```vb
PublishByRule = 1
PublishPerSourcePosition = 2
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:39

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestProjectionNormalsAndOrdinals с его подготовленными локальными объектами/входом.

```vb
        options.Publication = PublishPerSourcePosition
```

Полный контекст: tests/modTestSectionRecipes.bas:281.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-modsectionrecipetypes-erebarpositionorder"></a>
### modSectionRecipeTypes.ERebarPositionOrder

AlongPath или FromPathMiddle; геометрические станции/исходные ordinals сохраняются.

```vb
Public Enum ERebarPositionOrder
```

Поля/селекторы по source:

```vb
AlongPath = 1
FromPathMiddle = 2
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:44

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestPublicationAndCoincidence с его подготовленными локальными объектами/входом.

```vb
    options.PositionOrder = FromPathMiddle: options.Publication = PublishPerSourcePosition
```

Полный контекст: tests/modTestSectionRecipes.bas:356.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-modsectionrecipetypes-erebarcoincidence"></a>
### modSectionRecipeTypes.ERebarCoincidence

RejectCoincidence/MergeIdentical/KeepPublishedOwner; последнее сохраняет явно выбранного опубликованного владельца.

```vb
Public Enum ERebarCoincidence
```

Поля/селекторы по source:

```vb
RejectCoincidence = 1
MergeIdentical = 2
KeepPublishedOwner = 3
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:49

Минимальный вызов; требуемый контекст: В теле modTestSectionRecipes.TestPublicationAndCoincidence с его подготовленными локальными объектами/входом.

```vb
    options.AnnotationGroup = "Second": options.Coincidence = MergeIdentical
```

Полный контекст: tests/modTestSectionRecipes.bas:373.

Native entrypoint: modTestSectionRecipes.RunRecipeRuleTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-modsectionrecipetypes-erebarplacementcheck"></a>
### modSectionRecipeTypes.ERebarPlacementCheck

CheckCenter или CheckFullDisk относительно Outer/Opening; ужесточение задаётся явно.

```vb
Public Enum ERebarPlacementCheck
```

Поля/селекторы по source:

```vb
CheckCenter = 1
CheckFullDisk = 2
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:55

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.AdvancedGuideDefinition с его подготовленными локальными объектами/входом.

```vb
    options.PlacementCheck = CheckFullDisk: options.OverlapPolicy = RejectOverlap
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:63.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

<a id="api-modsectionrecipetypes-erebaroverlappolicy"></a>
### modSectionRecipeTypes.ERebarOverlapPolicy

ReportOverlap или RejectOverlap. Контакт допустим; нормативный минимальный зазор не вводится.

```vb
Public Enum ERebarOverlapPolicy
```

Поля/селекторы по source:

```vb
ReportOverlap = 1
RejectOverlap = 2
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:62

Минимальный вызов; требуемый контекст: В теле modTestRecipeOperations.RunRecipeDiagnosticTests с его подготовленными локальными объектами/входом.

```vb
        If mode = 2 Then options.OverlapPolicy = RejectOverlap
```

Полный контекст: tests/modTestRecipeOperations.bas:102.

Native entrypoint: modTestRecipeOperations.RunRecipeDiagnosticTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-modsectionrecipetypes-tsectionloop"></a>
### modSectionRecipeTypes.TSectionLoop

Raw скалярное описание роли/ссылок контура. Заполняет фасад Outer/Opening; автору не нужен собственный классификатор.

```vb
Public Type TSectionLoop
```

Поля/селекторы по source:

```vb
PathID As String
LoopID As String
Role As ESectionLoopRole
ParentID As String
Comment As String
ArcComment As String
ContourIDs As Variant
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:67

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Dim loopValue As TSectionLoop, ruleValue As TRebarRule, annotationValue As TSectionAnnotation, positionValue As TRebarPosition
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:230.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modsectionrecipetypes-trebarrule"></a>
### modSectionRecipeTypes.TRebarRule

Raw snapshot правила исполнителя. Фасад копирует options, source references и параметры, координаты баров вычисляет общий executor.

```vb
Public Type TRebarRule
```

Поля/селекторы по source:

```vb
RuleID As String
Target As String
Mode As ERebarDistribution
DistributionScope As ERebarDistributionScope
Enabled As Boolean
Diameter As Double
SteelClass As String
Count As Long
Step As Double
StartSetback As Double
EndSetback As Double
EndMode As ERebarEndMode
RemainderPlacement As ERemainderPlacement
SourceRuleID As String
TangentOffset As Double
NormalOffset As Double
EverySecond As Boolean
IncomingTangentAtJoint As Boolean
DirectionX As Double
DirectionY As Double
SourceNormalSign As Double
SuccessfulProjectionOrdinal As Boolean
NewPublicationRoot As Boolean
SkipMissingProjection As Boolean
Publication As ERebarPublication
PositionOrder As ERebarPositionOrder
Coincidence As ERebarCoincidence
PlacementCheck As ERebarPlacementCheck
OverlapPolicy As ERebarOverlapPolicy
SourcePrefix As String
SourceSuffix As String
AnnotationGroup As String
Comment As String
SourceReference As String
ExplicitStations As Variant
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:77

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Dim loopValue As TSectionLoop, ruleValue As TRebarRule, annotationValue As TSectionAnnotation, positionValue As TRebarPosition
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:230.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modsectionrecipetypes-tsectionannotation"></a>
### modSectionRecipeTypes.TSectionAnnotation

Raw annotation rule с модельными привязками/измерением. Фасад объявляет, общий engine измеряет, layout оформляет.

```vb
Public Type TSectionAnnotation
```

Поля/селекторы по source:

```vb
AnnotationID As String
Kind As String
Target As String
SegmentID As String
StartAnchorID As String
EndAnchorID As String
Name As String
StartX As Double
StartY As Double
EndX As Double
EndY As Double
NormalX As Double
NormalY As Double
DirectionX As Double
DirectionY As Double
Value As Double
DisplayIncrement As Double
ReverseDirection As Boolean
Comment As String
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:115

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Dim loopValue As TSectionLoop, ruleValue As TRebarRule, annotationValue As TSectionAnnotation, positionValue As TRebarPosition
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:230.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modsectionrecipetypes-tsectionmeshoptions"></a>
### modSectionRecipeTypes.TSectionMeshOptions

Настройки общей дискретизации: StepX/StepY в мм>0, subdivisions≥1, MaterialID≥1. Для книги читаются общим workflow.

```vb
Public Type TSectionMeshOptions
```

Поля/селекторы по source:

```vb
StepX As Double
StepY As Double
BoundarySubdivisions As Long
MaterialID As Long
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:137

Минимальный вызов; требуемый контекст: В теле modTestRecipeAnnotations.BuildDefinition с его подготовленными локальными объектами/входом.

```vb
    Dim mesh As TSectionMeshOptions
```

Полный контекст: tests/modTestRecipeAnnotations.bas:178.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/FinalApiAnnotations.txt.

Native entrypoint: modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/DeclarativeApi/Operations.txt.

<a id="api-modsectionrecipetypes-trebarposition"></a>
### modSectionRecipeTypes.TRebarPosition

Скалярное происхождение заявленной позиции до объединения: координаты мм, касательная, станция, rule/root ordinals и ID.

```vb
Public Type TRebarPosition
```

Поля/селекторы по source:

```vb
X As Double
Y As Double
TangentX As Double
TangentY As Double
Station As Double
RuleIndex As Long
RootRuleIndex As Long
RootOrdinal As Long
RootPublicationRank As Long
SourceOrdinal As Long
SourcePositionID As String
PathID As String
```

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:144

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Dim loopValue As TSectionLoop, ruleValue As TRebarRule, annotationValue As TSectionAnnotation, positionValue As TRebarPosition
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:230.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modsectionrecipetypes-sectionrecipeerror"></a>
### modSectionRecipeTypes.SectionRecipeError

Выдаёт общий код 5530 с owner/причиной/строкой источника; не назначает нормативный статус.

```vb
Public Sub SectionRecipeError(ByVal owner As String, ByVal reason As String, Optional ByVal sourceReference As String = "")
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| owner | String; ByVal; обязательный | Имя компонента/владельца ошибки, а не тип сечения для ветвления. |
| reason | String; ByVal; обязательный | Понятная причина отказа и исправление; машинный код не извлекается из текста. |
| sourceReference | String; ByVal; Optional; default="" | Строка исходного адреса/программного параметра; без объекта Excel. |

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:159

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    SectionRecipeError "ApiGuide", "Invalid count", "ProgramInputs.Count"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:248.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modsectionrecipetypes-sectionrecipegeometryerror"></a>
### modSectionRecipeTypes.SectionRecipeGeometryError

В обработчике добавляет SourceReference к query/path отказу; неожиданные ошибки сохраняют исходный Err.Number/Source.

```vb
Public Sub SectionRecipeGeometryError(ByVal owner As String, ByVal sourceReference As String)
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| owner | String; ByVal; обязательный | Имя компонента/владельца ошибки, а не тип сечения для ветвления. |
| sourceReference | String; ByVal; обязательный | Строка исходного адреса/программного параметра; без объекта Excel. |

Жизненный цикл: Общие enum/UDT/error contracts, только внутренние единицы. Raw правила/аннотации заполняет фасад; автор не реализует координатные циклы баров через UDT.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modSectionRecipeTypes.bas:166

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    SectionRecipeGeometryError "ApiGuide", "ProgramInputs.Arc"
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:251.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

## modGeometryTypes

Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

<a id="api-modgeometrytypes-geom_pi"></a>
### modGeometryTypes.GEOM_PI

Число pi как сумма сохраняемых VBE литералов, без изменения Double при компиляции.

```vb
Public Const GEOM_PI As Double = 3.14159265358979 + 3.10862446895044E-15
```

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:14

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestAutoCADImporterRotatedRectangleBounds с его подготовленными локальными объектами/входом.

```vb
    angle = GEOM_PI / 4#
```

Полный контекст: tests/modTestGeometry.bas:364.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-modgeometrytypes-geom_tolerance"></a>
### modGeometryTypes.GEOM_TOLERANCE

Геометрический допуск совпадений исходных координат, мм; не округление ключей результатов.

```vb
Public Const GEOM_TOLERANCE As Double = 0.000000001
```

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:15

Минимальный вызов; требуемый контекст: В теле modTestGeometry.AssertRelative с его подготовленными локальными объектами/входом.

```vb
    If Abs(expected) <= GEOM_TOLERANCE Then
```

Полный контекст: tests/modTestGeometry.bas:2504.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

<a id="api-modgeometrytypes-geom_max_rebar_count"></a>
### modGeometryTypes.GEOM_MAX_REBAR_COUNT

Предел представимости счётчика позиций, не обещание доступности памяти для такого массива.

```vb
Public Const GEOM_MAX_REBAR_COUNT As Double = 2147483646# ' Long-счетчик должен сохранять представимость следующего шага обхода.
```

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:16

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Check "limit.counter", GEOM_MAX_REBAR_COUNT > 2147483645# And GEOM_MAX_REBAR_COUNT < 2147483647#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:244.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modgeometrytypes-tpoint2d"></a>
### modGeometryTypes.TPoint2D

Два координатных скаляра X/Y, мм, без Excel или объекта на каждую точку.

```vb
Public Type TPoint2D
```

Поля/селекторы по source:

```vb
X As Double
Y As Double
```

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:18

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Dim point As TPoint2D, fiber As TFiber, properties As TGeometryProperties
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:239.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modgeometrytypes-tregionedge"></a>
### modGeometryTypes.TRegionEdge

Ориентированное аналитическое ребро: endpoints/center мм, Sweep радианы, 0 означает прямую, LoopID — численный loop.

```vb
Public Type TRegionEdge
```

Поля/селекторы по source:

```vb
X1 As Double
Y1 As Double
X2 As Double
Y2 As Double
CenterX As Double
CenterY As Double
Sweep As Double
LoopID As Long
```

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:26

Минимальный вызов; требуемый контекст: В теле modTestDeclarativeGeometry.RunRoundedPolygonTests с его подготовленными локальными объектами/входом.

```vb
    Dim edge As TRegionEdge, i As Long, radius As Double, scenario As Long
```

Полный контекст: tests/modTestDeclarativeGeometry.bas:154.

Native entrypoint: modTestDeclarativeGeometry.RunCoreGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

Native entrypoint: modTestDeclarativeGeometry.RunRoundedPolygonTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/CorePaths/RoundedPolygons.txt.

<a id="api-modgeometrytypes-tfiber"></a>
### modGeometryTypes.TFiber

Скалярные данные механического бетонного КЭ. Не заменяются аналитической площадью области.

```vb
Public Type TFiber
```

Поля/селекторы по source:

```vb
X As Double
Y As Double
Width As Double
Height As Double
Area As Double
FillFactor As Double
MaterialID As Long
```

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:37

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Dim point As TPoint2D, fiber As TFiber, properties As TGeometryProperties
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:239.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modgeometrytypes-tgeometryproperties"></a>
### modGeometryTypes.TGeometryProperties

Скалярные геометрические свойства во внутренних единицах; источник аналитический/сеточный определяется вызывающим алгоритмом.

```vb
Public Type TGeometryProperties
```

Поля/селекторы по source:

```vb
Area As Double
StaticMomentX As Double
StaticMomentY As Double
CentroidX As Double
CentroidY As Double
Ix As Double
Iy As Double
Ixy As Double
Ixc As Double
Iyc As Double
Ixyc As Double
PrincipalI1 As Double
PrincipalI2 As Double
PrincipalAngleRad As Double
RadiusX As Double
RadiusY As Double
PrincipalRadius1 As Double
PrincipalRadius2 As Double
```

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:47

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Dim point As TPoint2D, fiber As TFiber, properties As TGeometryProperties
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:239.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modgeometrytypes-geommax"></a>
### modGeometryTypes.GeomMax

Максимум двух чисел одной размерности, без преобразования единиц.

```vb
Public Function GeomMax(ByVal A As Double, ByVal B As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| A | Double; ByVal; обязательный | Число той же размерности, что второй аргумент; helper единицы не преобразует. |
| B | Double; ByVal; обязательный | Число той же размерности, что второй аргумент; helper единицы не преобразует. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:70

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.Near с его подготовленными локальными объектами/входом.

```vb
    Check name, Abs(actual - expected) <= 0.000001 * GeomMax(1#, Abs(expected))
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:262.

Native entrypoint: modTestRecipeApiCatalogue.RunAdvancedGuideExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/AdvancedExamples.txt.

Native entrypoint: modTestRecipeApiCatalogue.RunApiGeometryReadExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.unit-label-probe.txt.

Native entrypoint: modTestRecipeApiCatalogue.RunApiUnitExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modgeometrytypes-geommin"></a>
### modGeometryTypes.GeomMin

Минимум двух чисел одной размерности.

```vb
Public Function GeomMin(ByVal A As Double, ByVal B As Double) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| A | Double; ByVal; обязательный | Число той же размерности, что второй аргумент; helper единицы не преобразует. |
| B | Double; ByVal; обязательный | Число той же размерности, что второй аргумент; helper единицы не преобразует. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:80

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Near "helper.min", GeomMin(1#, 2#), 1#
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:245.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modgeometrytypes-readcontourarcsweep"></a>
### modGeometryTypes.ReadContourArcSweep

Читает согласованный signed sweep точной контурной дуги, не выбирая произвольные несовместимые входы.

```vb
Public Function ReadContourArcSweep(ByVal value As Variant, ByVal inputLocation As String) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| value | Variant; ByVal; обязательный | Входное/выходное скалярное значение в размерности операции; CUnitSystem задаёт единственный перевод. |
| inputLocation | String; ByVal; обязательный | Строка реального исходного адреса для диагностического сообщения. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:93

Минимальный вызов; требуемый контекст: В теле modTestRecipeApiCatalogue.RunApiInputAndDataExamples с его подготовленными локальными объектами/входом.

```vb
    Near "saved.sweep.strict", ReadContourArcSweep("1.25", "ProgramInputs.Arc"), 1.25
```

Полный контекст: tests/modTestRecipeApiCatalogue.bas:246.

Native entrypoint: modTestRecipeApiCatalogue.RunApiInputAndDataExamples; журнал: docs/regression/GeometryDeclarative_2026-10-12/NativeGuide/ApiCallExamples.txt.

<a id="api-modgeometrytypes-rebarrequestedpositioncount"></a>
### modGeometryTypes.RebarRequestedPositionCount

Проверяет запрошенное число позиций основного/дополнительных рядов до выделения массива.

```vb
Public Function RebarRequestedPositionCount(ByVal baseCount As Long, ByVal baseDiameter As Double, ByVal row2Diameter As Double, ByVal row3Diameter As Double, ByVal row2Binding As String, ByVal row3Binding As String) As Double
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| baseCount | Long; ByVal; обязательный | Целый неотрицательный счётчик; для ByCount применяется отдельно к каждому пути. |
| baseDiameter | Double; ByVal; обязательный | Диаметр соответствующего ряда, мм≥0; 0 выключает дополнительный ряд. |
| row2Diameter | Double; ByVal; обязательный | Диаметр соответствующего ряда, мм≥0; 0 выключает дополнительный ряд. |
| row3Diameter | Double; ByVal; обязательный | Диаметр соответствующего ряда, мм≥0; 0 выключает дополнительный ряд. |
| row2Binding | String; ByVal; обязательный | Принятый selector связи соответствующего ряда; EachBar/EverySecondBar. |
| row3Binding | String; ByVal; обязательный | Принятый selector связи соответствующего ряда; EachBar/EverySecondBar. |

Тип результата: Double. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:120

Минимальный вызов; требуемый контекст: В теле modTestGeometryConfig.RunAudit03RebarCounterTests с его подготовленными локальными объектами/входом.

```vb
    Near stats, "rebarCounter.binding.even", RebarRequestedPositionCount(6, 16#, 12#, 10#, "EverySecondBar", "EachBar"), 15#
```

Полный контекст: tests/modTestGeometryConfig.bas:50.

Native entrypoint: modTestGeometryConfig.RunAudit03RebarCounterTests; журнал: docs/regression/GeometryDeclarative_2026-10-11/ProductionRecipeEvidencePack/data/ProductionRecipe/RebarCounters.txt.

<a id="api-modgeometrytypes-buildgeneratedsectionmodel"></a>
### modGeometryTypes.BuildGeneratedSectionModel

Общий тонкий adapter mesh/layout→CSectionModel; автор рецепта использует CSectionBuilder, а не отдельный генератор типа.

```vb
Public Function BuildGeneratedSectionModel(ByVal mesh As CFiberMeshBuilder, ByVal rebars As CRebarLayout, Optional ByVal sourceType As String = "Generated") As CSectionModel
```

| Параметр | Тип / передача / default | Смысл и единицы |
|---|---|---|
| mesh | CFiberMeshBuilder; ByVal; обязательный | Подготовленный объект/контейнер выбранного запроса, без повторного чтения Excel или назначения типа. |
| rebars | CRebarLayout; ByVal; обязательный | Подготовленный объект/контейнер выбранного запроса, без повторного чтения Excel или назначения типа. |
| sourceType | String; ByVal; Optional; default="Generated" | Скалярная metadata владельца/источника; геометрическая классификация от строки не зависит. |

Тип результата: CSectionModel. Назначение, единицы и ограничения приведены выше. Для объектного результата используйте Set.

Жизненный цикл: Общие математические scalar/UDT/adapters. Внутренние единицы; helpers не выбирают тип сечения и не обращаются к Excel.

Ошибки/исправление: Нарушенный контракт вызывающей операции даёт адресную ошибку; данные и selectors проверяются общим источником/фасадом.

Source: src/Common/modGeometryTypes.bas:142

Минимальный вызов; требуемый контекст: В теле modTestGeometry.TestRectangularMeshSteps с его подготовленными локальными объектами/входом.

```vb
    Set model = BuildGeneratedSectionModel(mesh, Nothing)
```

Полный контекст: tests/modTestGeometry.bas:1379.

Native entrypoint: modTestGeometry.RunGeometryTests; журнал: docs/regression/GeometryDeclarative_2026-10-12/RetiredArchitecture/GeometryCore.txt.

