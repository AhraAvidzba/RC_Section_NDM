﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Читает три настоящих состояния тяжёлой книги, не рассчитывает и не сохраняет её.
param([Parameter(Mandatory=$true)][string]$WorkbookPath)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$out=Join-Path $PSScriptRoot 'HeavyIndexedRead07';if(Test-Path -LiteralPath $out){throw 'Fresh evidence directory required'}
[void][IO.Directory]::CreateDirectory($out)
$path=(Resolve-Path -LiteralPath $WorkbookPath).Path;$before=(Get-FileHash -LiteralPath $path).Hash
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve insufficient'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMHeavyIndexOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMHeavyIndexOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;WorkbookSHA256=$before}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$true);$app.Calculation=-4135
 if(-not $book.ReadOnly -or $book.Worksheets.Item('Results').ProtectContents){throw 'Readonly unprotected book required'}
 $prefix="'$($book.Name)'!modIndexedExcelResults."
 [void]$app.Run($prefix+'TestIndexedExcelReadCounters',$true)
 $states=$app.Run($prefix+'ReadIndexedExcelElementResults',$book,'','',$true,'')
 $stateCounter=[string]$app.Run($prefix+'TestIndexedExcelReadCounters',$false)
 if($states.GetLength(0) -ne 93 -or $states.GetLength(1) -ne 4){throw 'Expected 92 state keys and four metadata columns'}
 $idx=$book.Names.Item('rngNDMElementResultIndex').RefersToRange
 $metadata=$idx.Resize(94,9).Value2;$elements=$book.Names.Item('rngNDMElementResults').RefersToRange
 if([int]$metadata[2,3] -ne 114081){throw 'Expected 114080 element result rows'}
 $records=@()
 foreach($choice in @(2,47,93)){
  $lc=[string]$states[$choice,2];$profile=[string]$states[$choice,3];$state=[string]$states[$choice,4]
  [void]$app.Run($prefix+'TestIndexedExcelReadCounters',$true)
  $watch=[Diagnostics.Stopwatch]::StartNew();$actual=$app.Run($prefix+'ReadIndexedExcelElementResults',$book,$lc,$state,$false,$profile);$watch.Stop()
  $counter=[string]$app.Run($prefix+'TestIndexedExcelReadCounters',$false)
  if($actual.GetLength(0) -ne 1241 -or $actual.GetLength(1) -ne 9){throw 'Expected 1232 concrete and 8 rebar values'}
  $block=0
  for($r=3;$r -le 94;$r++){if([string]$metadata[$r,7] -ceq $lc -and [string]$metadata[$r,8] -ceq $profile -and [string]$metadata[$r,9] -ceq $state){if($block){throw 'Unexpected duplicate block'};$block=$r}}
  if(-not $block){throw 'Selected state has no physical block'}
  $first=[int]$metadata[$block,5]-1;$count=[int]$metadata[$block,6]
  $expected=$elements.Offset($first,0).Resize($count,9).Value2
  for($r=1;$r -le 1240;$r++){for($c=1;$c -le 9;$c++){
   $a=$actual[($r+1),$c];$b=$expected[$r,$c]
   if($a -is [double] -and $b -is [double]){if([BitConverter]::DoubleToInt64Bits($a) -ne [BitConverter]::DoubleToInt64Bits($b)){throw 'IEEE result mismatch'}}
   elseif([string]$a -cne [string]$b){throw 'Text result mismatch'}
  }}
  if($counter -cne '1337|1|0'){throw ('Not selective: '+$counter)}
  $records+=,[ordered]@{LoadCase=$lc;Profile=$profile;State=$state;Rows=1240;Seconds=$watch.Elapsed.TotalSeconds;Counters=$counter;ExactIEEEAndTextEqual=$true}
 }
 [ordered]@{Status='PASS_REAL_HEAVY_SELECTED_READ';WorkbookSHA256=$before;Concrete=1232;Rebar=8;Combinations=30;StateBlocks=92;TotalResultRows=114080;StateKeyColumns=4;StateListCounters=$stateCounter;Selected=$records;Recalculated=$false;Saved=$false}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $out 'Review.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $idx=$null;$elements=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
if((Get-FileHash -LiteralPath $path).Hash -ne $before){throw 'Readonly test changed source book'}
Write-Output 'HEAVY_INDEXED_READ_PASS'
