"""ДЛЯ ТЕСТОВ. Целиком читает двенадцать первичных журналов и проверяет состав направленного запуска."""
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
directory=P/'DirectedResults01_Attempt1'
expected={'RunCalculationSnapshotTests':1007,'RunPreparedSnapshotReuseTests':69,'RunGeometryPreviewStorageTests':62,'RunResultsFormattingTests':64,'RunTestCalculationFreshnessWorkflow':371,'RunAudit03AutoCADConfigTests':1243}
run=json.loads((directory/'Run.json').read_text(encoding='utf-8-sig'));assert len(run)==12
assert {(r['Mode'],r['Macro'].split('.')[-1]) for r in run}=={(m,k) for m in ('No','Yes') for k in expected}
records=[]
for mode in ('No','Yes'):
    for name,passed in expected.items():
        path=directory/mode/(name+'.txt');raw=path.read_bytes();text=raw.decode('utf-8-sig')
        totals=re.findall(r'^TOTAL[^\r\n]*passed=(\d+); failed=(\d+)\s*$',text,re.M)
        assert totals==[(str(passed),'0')],(path,totals)
        assert not re.search(r'^FAIL\b|^.*runtime error|^Traceback',text,re.M|re.I),path
        records.append(dict(Mode=mode,Macro=name,Bytes=len(raw),SHA256=hashlib.sha256(raw).hexdigest().upper(),Passed=passed,Failed=0,EntirePrimaryRead=True))
    assert json.loads((directory/mode/'Quit.json').read_text(encoding='utf-8-sig'))['QuitReturned'] is True
assert sum(r['Passed'] for r in records)==5632
(P/'DirectedPrimaryReview05.json').write_text(json.dumps(dict(Status='PASS_AFFECTED_NO_YES_PRIMARY',MacroCalls=12,Passed=5632,Failed=0,FullOnOffPerformed=False,FocusedPerformed=False,Records=records),ensure_ascii=False,indent=2),encoding='utf-8')
print('PRIMARY_12_CALLS_5632_0_FULLY_READ')
