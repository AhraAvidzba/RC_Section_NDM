"""ДЛЯ ТЕСТОВ. Закрепляет обзор всей сохранённой справки и точность переноса в обе книги."""
from pathlib import Path
from datetime import datetime,timezone
from pypdf import PdfReader
import hashlib,json
P=Path(__file__).resolve().parent
R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')


def test_load(path):
    """ДЛЯ ТЕСТОВ. Читает нативное доказательство без подмены фактических данных."""
    return json.loads(path.read_text(encoding='utf-8-sig'))


def test_sha(path):
    """ДЛЯ ТЕСТОВ. Связывает просмотренные артефакты с их точными байтами."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


rows=test_load(P/'NativeClean06/AllHelpText.json')
for label in ('Main','Heavy'):
    assert test_load(P/(label+'Native06')/'AllHelpText.json')==rows
    assert test_load(P/(label+'Native06')/'SourceEquality.json')['Status']=='PASS'
headings={r['Values'][0]:r['Row'] for r in rows if r['Values'][0]}
titles=['Расчет ширины раскрытия нормальных трещин','СП 63: расчет ширины нормальных трещин','СП 35: расчет ширины нормальных трещин','Продольные трещины: общая проверка по СП 35','Расчет продольного изгиба и устойчивости','СП 63: расчёт продольного изгиба и устойчивости','СП 35: расчёт продольного изгиба и устойчивости','Общие характеристики и расчётные длины','Справка по результатам расчета листа Results']
positions=[headings[t] for t in titles];assert positions==sorted(positions) and len(set(positions))==len(positions)
full=' '.join(v for r in rows for v in r['Values'] if v)
assert 'Результаты элементов и индекс защищены от' not in full
assert 'защита листа включается только пользователем' in full
assert 'расчётная запись программы' not in full and 'расчетная запись программы' not in full and 'без номера' not in full
catalog=test_load(R/'tools/build_workbook/NormativeFormulaImages.json');assert len(catalog)==21
for item in catalog:
    assert test_sha(R/item['Source'])==item['SourceSHA256']
    png=R/'tools/build_workbook/NormativeFormulaImages'/item['File']
    assert test_sha(png)==item['SHA256'] and png.with_suffix('.svg').exists()
    assert hashlib.sha256((item['MathText']+'\n'+item['Reference']).encode()).hexdigest().upper()==item['ExpressionSHA256']
    assert item['PixelsPerPoint']==4
pdf=P/'NativeClean06/WholeHelp.pdf';pagecount=len(PdfReader(pdf).pages);assert pagecount==35
assert len(list((P/'NativeClean06/Pages').glob('*.png')))==35
assert all((P/f'FinalHelpContact_{i:02d}.jpg').exists() for i in range(1,7))
# Все шесть контактных листов (35 страниц) просмотрены в чате после окончательной сборки.
# Полноразмерная страница формул и обе галереи нормативных записей также просмотрены ранее.
result=dict(Status='PASS_WHOLE_HELP_NATIVE_VISUAL_AND_TEXT',ReviewedUTC=datetime.now(timezone.utc).isoformat(),
    NativeWorkbookSHA256=test_load(P/'NativeClean06/Native.json')['WorkbookSHA256'],
    PDFSHA256=test_sha(pdf),PDFPages=35,PagesRenderedAndViewed=list(range(1,36)),Pictures=80,ValidHelpLinks=155,
    SettingsBlocksReviewed=152,InitialSettingsParagraphsReviewed=638,FinalSettingsParagraphs=640,
    EntireTheoryAndSettingsReviewed=True,NativeHelpTextIdenticalInCleanMainHeavy=True,
    Headings={t:headings[t] for t in titles},NormativeFormulaCount=21,NormativePDFHashesAndExpressionsVerified=True,
    AutomaticProtectionDescriptionRemoved=True,ImagesDeliveredToUser=False,FullOnOffPerformed=False)
(P/'WholeHelpFinalReview08.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('WHOLE_HELP_35_PAGES_80_PICTURES_155_LINKS_REVIEWED')
