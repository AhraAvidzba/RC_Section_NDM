﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет точные собственные идентичности, включая сборщики; процессы не закрывает.
param([string]$ReportName='AllOwnClosures05.json')
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$repo='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$files=@(Get-ChildItem -Recurse -File -LiteralPath $PSScriptRoot -Filter Own.json)
$files+=@(Get-ChildItem -Recurse -File -LiteralPath "$repo/docs/regression/ResultsHelpClarity_2026-11-01_Run01" -Filter BuildOwnership.json)
$records=@()
foreach($file in $files){
 $own=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json
 $expected=[string]$own.UTCStartTicks;if(-not $expected){$expected=[string]$own.StartTicksUTC}
 if([int]$own.PID -le 0 -or -not $expected){throw ('Invalid own proof '+$file.FullName)}
 $cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$own.PID)
 $state='Unknown';$actual='';$exe='';$created=''
 if(-not $cim){$state='ConfirmedNotFound'}else{
  $exe=[string]$cim.Name;$created=[string]$cim.CreationDate
  if($exe -ine 'EXCEL.EXE'){$state='PIDReusedDifferentExecutable'}else{
   $actual=[string](Get-Process -Id ([int]$own.PID) -ErrorAction Stop).StartTime.ToUniversalTime().Ticks
   if($actual -eq $expected){$state='ExactAlive'}else{$state='PIDReusedDifferentStart'}
  }
 }
 $records+=,[ordered]@{Proof=$file.FullName;PID=[int]$own.PID;UTCStartTicks=$expected;State=$state;ObservedTicks=$actual;CIMExecutable=$exe;CIMCreation=$created}
}
$bad=@($records|Where-Object {$_.State -in @('Unknown','ExactAlive')})
[ordered]@{Status=$(if($bad.Count){'REVIEW_REQUIRED'}else{'ALL_OWN_TERMINAL'});ObservedUTC=[DateTime]::UtcNow.ToString('o');Processes=$records}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot $ReportName) -Encoding UTF8
Write-Output ('Own reviewed='+$records.Count+'; remaining='+$bad.Count)
if($bad.Count){$bad|ConvertTo-Json -Depth 4;throw 'Some exact own identities remain live or unknown'}
