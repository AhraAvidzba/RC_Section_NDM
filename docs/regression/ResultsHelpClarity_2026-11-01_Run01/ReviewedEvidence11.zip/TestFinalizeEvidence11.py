"""ДЛЯ ТЕСТОВ. Проверяет опубликованные файлы и сохраняет компактные доказательства всех шести требований."""
from pathlib import Path
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,re,shutil
P=Path(__file__).resolve().parent
R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
E=R/'docs/regression/ResultsHelpClarity_2026-11-01_Run01'


def test_load(path):
    """ДЛЯ ТЕСТОВ. Загружает фактически сохранённое доказательство."""
    return json.loads(path.read_text(encoding='utf-8-sig'))


def test_sha(path):
    """ДЛЯ ТЕСТОВ. Связывает публикацию с нативно проверенными байтами."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


publication=test_load(P/'Publication10.json')
assert publication['Status']=='PUBLISHED_NATIVE_VERIFIED_RESULTS_AND_HELP'
for book in publication['Books']:assert test_sha(Path(book['Destination']))==book['SHA256']
assert test_sha(Path(publication['Package']))==publication['PackageSHA256']
assert test_sha(R/'workbook/output/VBA_All_Code.txt')==publication['AllCodeSHA256']
primary=test_load(P/'DirectedPrimaryReview05.json');assert primary['Passed']==5632 and primary['Failed']==0
help_review=test_load(P/'WholeHelpFinalReview08.json');assert help_review['Status']=='PASS_WHOLE_HELP_NATIVE_VISUAL_AND_TEXT'
heavy=test_load(P/'HeavyIndexedRead07/Review.json');assert heavy['Status']=='PASS_REAL_HEAVY_SELECTED_READ'
own=test_load(P/'AllOwnBeforePublication10.json');assert own['Status']=='ALL_OWN_TERMINAL' and len(own['Processes'])==10
source='\n'.join(p.read_text(encoding='utf-8-sig') for p in (R/'src').rglob('*') if p.suffix in ('.bas','.cls'))
assert not re.search(r'\.(?:Protect|Unprotect)\b',source)
assert 'NDM_ResultIndex_v1' not in source and 'NDM.ElementResultIndex.Protection' not in source
requirements=[dict(ID=1,Requirement='No automatic protection or password; optional user protection',Status='PASS',Evidence=['DirectedPrimaryReview05.json','MainNative06.json','HeavyNative06.json']),
    dict(ID=2,Requirement='Compact nine-column state index; selected reads preserved',Status='PASS',Evidence=['MainNative06.json','HeavyNative06.json','HeavyIndexedRead07.json']),
    dict(ID=3,Requirement='Blue Results title band reaches final index column',Status='PASS',Evidence=['CleanNative06.json','MainNative06.json','HeavyNative06.json']),
    dict(ID=4,Requirement='Sharp freshly typeset formulas matching normative notation',Status='PASS',Evidence=['NormativeExpressionReview01.json','WholeHelpFinalReview08.json']),
    dict(ID=5,Requirement='Separate coherent SP63/SP35 stability subsections',Status='PASS',Evidence=['WholeHelpFinalReview08.json']),
    dict(ID=6,Requirement='Whole Help narrative order and explicit SP63/SP35 cracks',Status='PASS',Evidence=['WholeHelpTextReview02.json','WholeHelpFinalReview08.json'])]
records={'DirectedPrimaryReview05.json':P/'DirectedPrimaryReview05.json','WholeHelpTextReview02.json':P/'WholeHelpTextReview02.json',
    'NormativeExpressionReview01.json':P/'NormativeExpressionReview01.json','WholeHelpFinalReview08.json':P/'WholeHelpFinalReview08.json',
    'PreparedBooks06.json':P/'PreparedBooks06.json','Publication10.json':P/'Publication10.json','AllOwnClosures10.json':P/'AllOwnBeforePublication10.json',
    'HeavyIndexedRead07.json':P/'HeavyIndexedRead07/Review.json','Build03.json':P/'Build03.json',
    'HelpFinalPolish05.json':P/'HelpFinalPolish05.json'}
for label in ('Clean','Main','Heavy'):
    records[label+'Native06.json']=P/(('NativeClean06' if label=='Clean' else label+'Native06')+'/Native.json')
    records[label+'SourceEquality06.json']=P/(('NativeClean06' if label=='Clean' else label+'Native06')+'/SourceEquality.json')
for name,path in records.items():
    assert not (E/name).exists();shutil.copy2(path,E/name);assert test_sha(E/name)==test_sha(path)
archive=E/'ReviewedEvidence11.zip';assert not archive.exists()
manifest=[]
paths=[*records.values(),*list((P/'DirectedResults01_Attempt1').glob('*/*.txt')),
    P/'TestPrepareBooks06.py',P/'TestNativeHelpReadback06.ps1',P/'TestHeavyIndexedRead07.ps1',P/'TestReviewDirectedPrimary05.py',
    P/'TestReviewWholeHelp08.py',P/'TestReviewAllOwn05.ps1',P/'TestResumePublication10.py',P/'TestFinalizeEvidence11.py']
with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for path in paths:
        name=str(path.relative_to(P)).replace('\\','/');z.write(path,name)
        manifest.append(dict(Path=name,Bytes=path.stat().st_size,SHA256=test_sha(path)))
with ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:assert hashlib.sha256(z.read(item['Path'])).hexdigest().upper()==item['SHA256']
(E/'ReviewedEvidenceManifest11.json').write_text(json.dumps(dict(Archive=archive.name,SHA256=test_sha(archive),Files=manifest),ensure_ascii=False,indent=2),encoding='utf-8')
processed=dict(Status='PASS_ALL_SIX_REQUESTED_CHANGES_NATIVE_PUBLISHED',FinishedUTC=datetime.now(timezone.utc).isoformat(),
    Requirements=requirements,DirectedMacroCalls=12,AssertionsPassed=5632,AssertionsFailed=0,NativeSourceComponents=181,NativeDocumentComponents=6,
    HelpPagesReviewed=35,HelpPictures=80,HelpLinks=155,SettingsBlocksReviewed=152,NormativeFormulasTypeset=21,OwnProcessesTerminal=10,
    PublishedBooks=publication['Books'],UserInputAndSavedResultsPreserved=True,OriginalLockedHeavyBookNotOverwritten=True,
    FullOnOffPerformed=False,FocusedPerformed=False,MainMergePerformed=False,FeaturePushPending=True,
    NonProductIssues=[
        'First private preparation refused existing Invalid index; it was preserved as Invalid, not promoted to a valid index.',
        'PS5 test helper syntax corrected before starting Excel; application tests passed after correction.',
        'Help wording guard joined visual line breaks before matching a phrase; native text was unchanged.',
        'Original heavy file became locked by another process during publication; main succeeded, heavy published safely into a new folder.'
    ],ArchiveSHA256=test_sha(archive))
(E/'Processed.json').write_text(json.dumps(processed,ensure_ascii=False,indent=2),encoding='utf-8')
report=R/'docs/reports/ResultsHelpClarity_2026-11-01.md'
text=report.read_text(encoding='utf-8').replace('Статус: окончательные сохранённые книги и публикация проверяются.','Статус: все шесть требований приняты, основная книга и отдельный обновлённый тяжёлый комплект опубликованы с резервом.')
text+='\nФинальное выборочное чтение настоящего тяжёлого примера: PERF_01/StrengthState, PERF_15/CrackedState и PERF_30/CrackedState. Каждый запрос читает 1240 строк одного блока и 97 служебных строк вместо всех 114080 строк. Нативное время только чтения — 0,013–0,019 с; это не время обновления схемы. Значения сравнивались точно по IEEE-байтам и строкам. Все 10 собственных идентичностей терминальны; принудительное завершение не применялось.\n'
text+='\nОсновная книга: `workbook/output/RC_Section_NDM.xlsm`. Тяжёлый файл в исходном каталоге оказался занят другим процессом, поэтому он не закрывался и не заменялся. Обновлённая книга, исходный проверенный NDM и ZIP: `workbook/output/NDM_HeavyCircle_1232_30_ResultsHelp_2026-11-01/`. Все исходные нагрузки, результаты и четыре исторических InputErr сохранены. Пользовательские DWG, execution_report и исходный отдельный NDM не менялись. Резерв перед публикацией сохранён в частном каталоге задачи.\n'
report.write_text(text,encoding='utf-8')
progress=R/'docs/geometry_refactor/PROGRESS.md';text=progress.read_text(encoding='utf-8-sig')
entry='\n## 01.11.2026 — Вся справка и компактный индекс без автоматической защиты\n\nВся справка проверена: отдельные СП 63/СП 35 для нормальных трещин и устойчивости, общий блок продольных трещин, порядок от общей формулы к составляющим. 21 нормативная формула набрана заново, остальные формулы повышенной чёткости; 35 страниц, 80 рисунков и 155 ссылок приняты в сохранённом Excel. Индекс содержит девять необходимых столбцов, голубая полоса доходит до его конца. Защита включается только пользователем, пароль не меняется. Адресные 12 No/Yes вызовов 5632/0; выборочное чтение реального 1232/8/30 — один блок, точное совпадение данных; 181+6 во всех книгах, 10 own терминальны. Основная книга обновлена с сохранением данных; занятый тяжёлый файл оставлен, готов новый комплект рядом. В Git включается чистая сборка. Полного ON/OFF+Focused нет. [Отчёт](../reports/ResultsHelpClarity_2026-11-01.md).\n'
assert 'Вся справка и компактный индекс без автоматической защиты' not in text
first,rest=text.split('\n',1);progress.write_text(first+'\n'+entry+rest,encoding='utf-8')
print('ALL_SIX_REQUIREMENTS_AUDITED_PUBLICATION_AND_PROOFS_SAVED')
