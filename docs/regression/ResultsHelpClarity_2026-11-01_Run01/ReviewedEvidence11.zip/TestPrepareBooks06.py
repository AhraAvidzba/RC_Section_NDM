"""ДЛЯ ТЕСТОВ. Переносит принятую справку и код, сохраняя данные пользовательских книг.

Одноразово сокращает технический индекс 02 до 03 и снимает только известную
автоматическую защиту. Рабочий VBA не содержит миграции или управления паролем.
"""
import copy
import hashlib
import importlib.util
import json
import posixpath
import re
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E

P = Path(__file__).resolve().parent
R = Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
spec = importlib.util.spec_from_file_location('help_package', R/'tools/build_workbook/Package-HelpOnly.py')
helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
M, X, A, NS = helper.M, helper.X, helper.A, helper.NS
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG = 'http://schemas.openxmlformats.org/package/2006/relationships'


def test_sha(data):
    """ДЛЯ ТЕСТОВ. Фиксирует точное содержимое, а не время изменения."""
    return hashlib.sha256(data).hexdigest().upper()


def test_read(path):
    """ДЛЯ ТЕСТОВ. Читает все части без пересохранения через Excel."""
    with ZipFile(path) as z:
        assert z.testzip() is None
        return z.infolist(), {n: z.read(n) for n in z.namelist()}


def test_dump(node):
    """ДЛЯ ТЕСТОВ. Сохраняет Unicode и пространства имён XML."""
    return E.tostring(node, encoding='UTF-8', xml_declaration=True, standalone=True)


def test_rels(parts, part):
    """ДЛЯ ТЕСТОВ. Разрешает внутренние связи относительно владельца."""
    name = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part)+'.rels')
    root = E.fromstring(parts[name])
    targets = {n.get('Id'): posixpath.normpath(posixpath.join(posixpath.dirname(part), n.get('Target'))).lstrip('/') for n in root if n.get('TargetMode') != 'External'}
    return name, root, targets


def test_sheets(parts):
    """ДЛЯ ТЕСТОВ. Находит листы по отображаемому имени и проверяет кодовые имена."""
    _, _, rel = test_rels(parts, 'xl/workbook.xml')
    w = E.fromstring(parts['xl/workbook.xml'])
    return {s.get('name'): rel[s.get('{'+REL+'}id')] for s in w.find('m:sheets', NS)}


def test_codes(parts):
    """ДЛЯ ТЕСТОВ. Не допускает подстановку VBA с другой структурой документов."""
    result = {}
    for part in ['xl/workbook.xml', *test_sheets(parts).values()]:
        node = E.fromstring(parts[part]).find('m:workbookPr' if part == 'xl/workbook.xml' else 'm:sheetPr', NS)
        result[part] = node.get('codeName') if node is not None else None
    return result


def test_strings(parts):
    """ДЛЯ ТЕСТОВ. Читает исходную общую таблицу строк без изменения её индексов."""
    return list(E.fromstring(parts['xl/sharedStrings.xml'])) if 'xl/sharedStrings.xml' in parts else []


def test_value(cell, strings):
    """ДЛЯ ТЕСТОВ. Извлекает значение только для проверки технических ключей."""
    if cell is None: return ''
    if cell.get('t') == 's': return ''.join(strings[int(cell.find('m:v', NS).text)].itertext())
    if cell.get('t') == 'inlineStr': return ''.join(cell.find('m:is', NS).itertext())
    return cell.findtext('m:v', '', NS)


def test_inline(cell, text):
    """ДЛЯ ТЕСТОВ. Меняет одну техническую строку, не затрагивая sharedStrings."""
    for child in list(cell): cell.remove(child)
    cell.set('t', 'inlineStr'); E.SubElement(E.SubElement(cell, '{'+M+'}is'), '{'+M+'}t').text = text


def test_column(text):
    """ДЛЯ ТЕСТОВ. Преобразует буквенный столбец в номер."""
    value = 0
    for c in text: value = value*26+ord(c)-64
    return value


def test_letters(value):
    """ДЛЯ ТЕСТОВ. Формирует адрес без зависимости от языка Excel."""
    result = ''
    while value:
        value, rem = divmod(value-1, 26); result = chr(65+rem)+result
    return result


def test_anchor(parts, name):
    """ДЛЯ ТЕСТОВ. Принимает только одноклеточный якорь существующего диапазона."""
    w = E.fromstring(parts['xl/workbook.xml'])
    text = w.find("m:definedNames/m:definedName[@name='"+name+"']", NS).text
    match = re.fullmatch(r"'?([^']+)'?!\$([A-Z]+)\$(\d+)", text)
    assert match, (name, text)
    return match[1], test_column(match[2]), int(match[3])


def test_help(parts, before, donor, styles):
    """ДЛЯ ТЕСТОВ. Переносит справку, рисунки и адреса её существующих ссылок."""
    hp, np = test_sheets(before)['Справка'], test_sheets(donor)['Справка']
    assert hp == np
    ws, oldws = E.fromstring(donor[np]), E.fromstring(before[hp])
    strings = test_strings(donor)
    for cell in ws.findall('.//m:c', NS):
        if cell.get('s') is not None: cell.set('s', str(styles[int(cell.get('s'))]))
        if cell.get('t') == 's':
            index = int(cell.find('m:v', NS).text)
            for child in list(cell): cell.remove(child)
            cell.set('t', 'inlineStr'); inline = E.SubElement(cell, '{'+M+'}is')
            for child in strings[index]: inline.append(copy.deepcopy(child))
    for node in ws.findall('m:cols/m:col', NS)+ws.findall('m:sheetData/m:row', NS):
        for attr in ('s', 'style'):
            if node.get(attr) is not None: node.set(attr, str(styles[int(node.get(attr))]))
    _, _, oldtargets = test_rels(before, hp)
    _, _, newtargets = test_rels(donor, np)
    page, oldpage = ws.find('m:pageSetup', NS), oldws.find('m:pageSetup', NS)
    if page is not None and page.get('{'+REL+'}id') is not None:
        page.attrib.pop('{'+REL+'}id')
        if oldpage is not None and oldpage.get('{'+REL+'}id') is not None: page.set('{'+REL+'}id', oldpage.get('{'+REL+'}id'))
    old_id, new_id = oldws.find('m:drawing', NS).get('{'+REL+'}id'), ws.find('m:drawing', NS).get('{'+REL+'}id')
    old_draw, new_draw = oldtargets[old_id], newtargets[new_id]
    ws.find('m:drawing', NS).set('{'+REL+'}id', old_id)
    for node in ws.iter():
        for attr, value in list(node.attrib.items()):
            if attr == '{'+REL+'}id' and node.tag != '{'+M+'}drawing':
                matches = [k for k, v in oldtargets.items() if v == newtargets[value]]
                assert len(matches) == 1, value
                node.set(attr, matches[0])
    parts[hp] = test_dump(ws)
    old_rel, _, old_media = test_rels(before, old_draw)
    _, _, new_media = test_rels(donor, new_draw)
    old_xml = E.fromstring(before[old_draw])
    assert all(n.find('x:pic/x:nvPicPr/x:cNvPr', NS).get('name', '').startswith('NDMHelpFormula_') for n in old_xml), 'Foreign Help shape'
    other_targets = set()
    for part in before:
        if not part.endswith('.rels') or part == old_rel: continue
        owner = posixpath.join(posixpath.dirname(posixpath.dirname(part)), posixpath.basename(part)[:-5])
        for rel in E.fromstring(before[part]):
            if rel.get('TargetMode') != 'External': other_targets.add(posixpath.normpath(posixpath.join(posixpath.dirname(owner), rel.get('Target'))).lstrip('/'))
    pool = list(dict.fromkeys(old_media.values()))
    assert not set(pool)&other_targets, 'Shared image cannot be replaced'
    drawing, relroot = E.fromstring(donor[new_draw]), E.Element('{'+PKG+'}Relationships', nsmap={None: PKG})
    assert len(drawing) == 80
    assert len(new_media) >= len(pool)
    for i, (rid, part) in enumerate(new_media.items()):
        dest = pool[i] if i < len(pool) else f'xl/media/ndm_help_clarity_{i:03d}.png'
        if i >= len(pool): assert dest not in before
        parts[dest] = donor[part]
        E.SubElement(relroot, '{'+PKG+'}Relationship', Id=rid, Type=REL+'/image', Target=posixpath.relpath(dest, posixpath.dirname(old_draw)))
    parts[old_draw], parts[old_rel] = test_dump(drawing), test_dump(relroot)
    count = 0
    for part in test_sheets(before).values():
        if part == hp: continue
        old, new = E.fromstring(before[part]), E.fromstring(donor[part])
        links = lambda root: {n.get('ref'): n for n in root.findall('m:hyperlinks/m:hyperlink', NS) if helper.help_link(n.get('location'))}
        a, b = links(old), links(new); assert a.keys() == b.keys(), part
        for ref in a: a[ref].set('location', b[ref].get('location')); count += 1
        if a: parts[part] = test_dump(old)
    w, nw = E.fromstring(before['xl/workbook.xml']), E.fromstring(donor['xl/workbook.xml'])
    for node in w.findall('m:definedNames/m:definedName', NS):
        if re.match(r"^=?'?Справка'?!", node.text or ''):
            match = nw.find("m:definedNames/m:definedName[@name='"+node.get('name')+"']", NS)
            assert match is not None; node.text = match.text
    parts['xl/workbook.xml'] = test_dump(w)
    return dict(HelpLinks=count, Pictures=len(drawing), HelpPart=hp, Drawing=old_draw, DrawingRels=old_rel, Media=pool)


def test_results(parts, before):
    """ДЛЯ ТЕСТОВ. Удаляет только ненужные столбцы индекса и известную автозащиту."""
    sheet, col, row = test_anchor(before, 'rngNDMElementResultIndex')
    part = test_sheets(before)[sheet]; ws = E.fromstring(parts[part]); strings = test_strings(before)
    rows = {int(n.get('r')): n for n in ws.find('m:sheetData', NS)}
    cells = {c.get('r'): c for r in rows.values() for c in r}
    at = lambda c, r: cells.get(test_letters(c)+str(r))
    expected = ['IndexKind','RunID','TableRows','TableColumns','FirstRow','RowCount','LoadCase','ProfileId','StateType','ElementID','MaterialType','Strain','Stress, MPa','PhysicalState']
    assert [test_value(at(col+i,row),strings) for i in range(14)] == expected
    kind = test_value(at(col,row+1),strings)
    if kind == 'NDMResultIndex02':
        count = int(float(test_value(at(col+5,row+1),strings)))
        assert 0 < count < 5000, count
        test_inline(at(col,row+1), 'NDMResultIndex03')
    else:
        # Invalid — существующая отметка отсутствия достоверного индекса, а не результаты для миграции.
        assert kind == 'Invalid', ('Unknown index status',kind)
        assert all(test_value(at(col+i,row+1),strings)=='' for i in range(1,14))
        count = 0
    for r in range(row-1,row+count+2):
        node = rows[r]
        for c in list(node):
            address = re.fullmatch(r'([A-Z]+)(\d+)', c.get('r')); cnum = test_column(address[1])
            if col+9 <= cnum <= col+13: node.remove(c)
    old_merge = f'{test_letters(col)}{row-1}:{test_letters(col+13)}{row-1}'
    merge = ws.find("m:mergeCells/m:mergeCell[@ref='"+old_merge+"']", NS)
    assert merge is not None; merge.set('ref', f'{test_letters(col)}{row-1}:{test_letters(col+8)}{row-1}')
    cp = E.fromstring(parts['docProps/custom.xml'])
    marker = [n for n in cp if n.get('name') == 'NDM.ElementResultIndex.Protection']
    protection = ws.find('m:sheetProtection', NS)
    assert len(marker) == 1 and ''.join(marker[0].itertext()) == 'NDMResultIndex02'
    assert protection is not None and dict(protection.attrib) == {'password':'F77B','sheet':'1'}, 'Unknown user protection must be preserved'
    cp.remove(marker[0]); ws.remove(protection); parts['docProps/custom.xml'] = test_dump(cp)
    _, gcol, grow = test_anchor(before, 'rngNDMSectionGeometry'); bandrow = grow-2
    styles = E.fromstring(parts['xl/styles.xml']); xfs = styles.find('m:cellXfs', NS); fills = styles.find('m:fills', NS)
    fill = E.fromstring(('<fill xmlns="'+M+'"><patternFill patternType="solid"><fgColor rgb="FFBDD7EE"/><bgColor indexed="64"/></patternFill></fill>').encode())
    match = next((i for i,n in enumerate(fills) if helper.signature(n) == helper.signature(fill)), None)
    if match is None: match = len(fills); fills.append(fill); fills.set('count',str(len(fills)))
    cache = {}
    for cnum in range(gcol, col+9):
        address = test_letters(cnum)+str(bandrow); cell = cells.get(address)
        if cell is None:
            cell = E.SubElement(rows[bandrow], '{'+M+'}c', r=address); cells[address] = cell
        oldstyle = int(cell.get('s','0'))
        if oldstyle not in cache:
            style = copy.deepcopy(xfs[oldstyle]); style.set('fillId',str(match)); style.set('applyFill','1')
            cache[oldstyle] = len(xfs); xfs.append(style)
        cell.set('s',str(cache[oldstyle]))
    for node in rows.values():
        node[:] = sorted(node, key=lambda c:test_column(re.match('[A-Z]+',c.get('r'))[0]))
    xfs.set('count',str(len(xfs))); parts['xl/styles.xml'] = test_dump(styles); parts[part] = test_dump(ws)
    # Все рабочие матрицы и исходные ячейки сравниваются семантически; индекс и полоса исключены явно.
    old = E.fromstring(before[part]); oldcells = {c.get('r'):c for c in old.findall('m:sheetData/m:row/m:c',NS)}
    newcells = {c.get('r'):c for c in ws.findall('m:sheetData/m:row/m:c',NS)}
    def allowed(address):
        a = re.fullmatch(r'([A-Z]+)(\d+)', address); c,r = test_column(a[1]),int(a[2])
        return (row-1 <= r <= row+count+1 and col <= c <= col+13) or (r == bandrow and gcol <= c <= col+8)
    preserved = 0
    for address in oldcells.keys() | newcells.keys():
        if allowed(address): continue
        assert address in oldcells and address in newcells and helper.signature(oldcells[address]) == helper.signature(newcells[address]), ('Changed result cell', address)
        preserved += 1
    return dict(Part=part, IndexColumns=9, OriginalIndexStatus=kind, StateBlocks=count, PreservedOtherResultCells=preserved, KnownAutomaticProtectionRemoved=True, BandLastCell=test_letters(col+8)+str(bandrow))


def test_prepare(label, source, expected, donor):
    """ДЛЯ ТЕСТОВ. Готовит частную копию, затем повторно читает и проверяет все ZIP-части."""
    assert test_sha(source.read_bytes()) == expected, 'Source changed: preserve latest user save'
    directory=P/'Prepared06'/label; directory.mkdir(parents=True,exist_ok=False); target=directory/source.name
    infos,before=test_read(source); parts=dict(before)
    assert test_codes(before) == test_codes(donor)
    assert not any('signature' in n.lower() for n in before)
    parts['xl/styles.xml'], styles = helper.merge_styles(before['xl/styles.xml'],donor['xl/styles.xml'])
    help_review=test_help(parts,before,donor,styles); results=test_results(parts,before)
    parts['xl/vbaProject.bin']=donor['xl/vbaProject.bin']
    changed=[n for n in before if before[n] != parts[n]]; added=set(parts)-set(before)
    allowed={'xl/styles.xml','xl/workbook.xml','xl/vbaProject.bin','docProps/custom.xml',results['Part'],help_review['HelpPart'],help_review['Drawing'],help_review['DrawingRels'],*help_review['Media']}
    allowed.update(n for n in test_sheets(before).values() if E.fromstring(before[n]).find('m:hyperlinks',NS) is not None)
    assert set(changed)<=allowed,changed
    for part in test_sheets(before).values():
        if part in (results['Part'],help_review['HelpPart']):continue
        a,b=E.fromstring(before[part]),E.fromstring(parts[part])
        for root in (a,b):
            for link in root.findall('m:hyperlinks/m:hyperlink',NS):
                if helper.help_link(link.get('location')):link.set('location','HELP')
        assert helper.signature(a)==helper.signature(b),('Changed input',part)
    oldstyles,newstyles=E.fromstring(before['xl/styles.xml']),E.fromstring(parts['xl/styles.xml'])
    for old in oldstyles:
        new=newstyles.find(old.tag)
        assert new is not None
        assert all(helper.signature(a)==helper.signature(b) for a,b in zip(old,new)),old.tag
    with ZipFile(target,'w') as z:
        for info in infos:z.writestr(info,parts[info.filename])
        for name in added:z.writestr(name,parts[name])
    _,reopened=test_read(target);assert all(reopened[n]==parts[n] for n in parts)
    assert test_sha(source.read_bytes())==expected
    return dict(Label=label,Source=str(source),SourceSHA256=expected,Prepared=str(target),PreparedSHA256=test_sha(target.read_bytes()),ChangedParts=changed,AddedParts=sorted(added),PreservedOtherParts=len(before)-len(changed),UserInputAndResultsPreserved=True,StylesPrefixPreserved=True,Help=help_review,Results=results)


if __name__=='__main__':
    native=json.loads((P/'NativeClean06/Native.json').read_text(encoding='utf-8-sig'))
    donorpath=R/'docs/regression/ResultsHelpClarity_2026-11-01_Run01/Build03/RC_Section_NDM.xlsm'
    assert test_sha(donorpath.read_bytes())==native['WorkbookSHA256']
    assert json.loads((P/'NativeClean06/SourceEquality.json').read_text())['Status']=='PASS'
    _,donor=test_read(donorpath)
    records=[test_prepare('Main',R/'workbook/output/RC_Section_NDM.xlsm','A31DBB9C444FEF51AEA44AC55CDD16DAF0A4D868E2807483521E63C4FA39A681',donor),test_prepare('Heavy',R/'workbook/output/NDM_HeavyCircle_1232_30_2026-11-01/RC_Section_NDM_HeavyCircle_1232_30.xlsm','E2FEB935EC02841D59EFEA8633417D7503C6DEEB8489268443F0168EF5F9AFA7',donor)]
    (P/'PreparedBooks06.json').write_text(json.dumps(dict(Status='PREPARED_NATIVE_REOPEN_REQUIRED',Books=records),ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(records,ensure_ascii=False))
