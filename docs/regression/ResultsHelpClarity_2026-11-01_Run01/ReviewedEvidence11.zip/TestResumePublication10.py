"""ДЛЯ ТЕСТОВ. Завершает публикацию после блокировки тяжёлой книги другим процессом.

Основная книга уже заменена. Тяжёлый файл пользователя не закрывается и не
перезаписывается: готовый комплект сохраняется в отдельном новом каталоге.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil
from zipfile import ZipFile,ZIP_DEFLATED
P=Path(__file__).resolve().parent
R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')


def test_load(path):
    """ДЛЯ ТЕСТОВ. Читает подтверждённые факты подготовки и приёмки."""
    return json.loads(path.read_text(encoding='utf-8-sig'))


def test_sha(path):
    """ДЛЯ ТЕСТОВ. Проверяет байты только доступных файлов; занятый файл не открывает."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


own=test_load(P/'AllOwnBeforePublication10.json')
assert own['Status']=='ALL_OWN_TERMINAL'
assert (datetime.now(timezone.utc)-datetime.fromisoformat(own['ObservedUTC'].replace('Z','+00:00'))).total_seconds()<120
books=test_load(P/'PreparedBooks06.json')['Books']
main,heavy=[next(b for b in books if b['Label']==label) for label in ('Main','Heavy')]
assert test_sha(Path(main['Source']))==main['PreparedSHA256']
assert test_sha(P/'BeforePublication09/Main/RC_Section_NDM.xlsm')==main['SourceSHA256']
assert test_sha(P/'BeforePublication09/Heavy'/Path(heavy['Source']).name)==heavy['SourceSHA256']
for label in ('Main','Heavy'):
    assert test_load(P/(label+'Native06')/'SourceEquality.json')['Status']=='PASS'
    item=next(b for b in books if b['Label']==label)
    assert test_load(P/(label+'Native06')/'Native.json')['WorkbookSHA256']==item['PreparedSHA256']
    assert test_sha(Path(item['Prepared']))==item['PreparedSHA256']
assert test_load(P/'WholeHelpFinalReview08.json')['Status']=='PASS_WHOLE_HELP_NATIVE_VISUAL_AND_TEXT'
assert test_load(P/'HeavyIndexedRead07/Review.json')['Status']=='PASS_REAL_HEAVY_SELECTED_READ'
maincode=R/'workbook/output/VBA_All_Code.txt'
assert test_sha(maincode)==test_load(P/'Start.json')['AllCodeSHA256']
foreign=[R/'Типы_сечения.dwg',R/'workbook/output/RC_Section_NDM_execution_report.txt',R/'workbook/output/NDM_Test_1232_30/RC_Section_NDM_execution_report.txt']
foreign_sha={str(p):test_sha(p) for p in foreign}
old_dir=Path(heavy['Source']).parent
folder=old_dir.with_name('NDM_HeavyCircle_1232_30_ResultsHelp_2026-11-01')
assert folder.resolve().is_relative_to((R/'workbook/output').resolve())
assert not folder.exists();folder.mkdir()
old_zip=old_dir/'NDM_HeavyCircle_1232_30_Комплект.zip'
snapshot_name='NDM_HeavyCircle_1232_30.ndm'
original_sha='E48038B73A6E4146A9AB6D594BC57B4E7C26C561D2DBAC3A9FE7496AFA96C9AA'
with ZipFile(old_zip) as z:original=z.read(snapshot_name)
assert hashlib.sha256(original).hexdigest().upper()==original_sha
target=folder/Path(heavy['Source']).name
shutil.copy2(heavy['Prepared'],target);assert test_sha(target)==heavy['PreparedSHA256']
(folder/snapshot_name).write_bytes(original)
verification=test_load(P/'BeforePublication09/Heavy/Verification.json')
verification.update(WorkbookSHA256=heavy['PreparedSHA256'],PackagedSnapshotSHA256=original_sha,
    SeparateLocalSnapshotSHA256=original_sha,SeparateLocalSnapshotSameAsOriginalArchive=True)
verification['ResultsHelpClarity']=dict(CompactIndexColumns=9,IndexFormat='NDMResultIndex03',AutomaticSheetProtection=False,
    WholeHelpReviewed=True,SeparateSP63SP35CracksAndStability=True,NativeSourceComponents=181,NativeDocumentComponents=6,
    UserInputsAndResultMatricesPreserved=True,ResultRows=114080,StateBlocks=92,FullOnOffPerformed=False)
(folder/'Verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
readme=(P/'BeforePublication09/Heavy/Прочитать.txt').read_text(encoding='utf-8-sig')
readme+='\n\n01.11.2026 — обновлены справка, чёткие формулы, отдельные подразделы СП 63 и СП 35, компактный индекс из девяти столбцов. Автоматическая защита листа выключена; пользователь может включить свою. Все исходные данные и результаты сохранены без пересчёта.\n'
readme+='Этот новый каталог создан, поскольку Windows не разрешил заменить исходную тяжёлую книгу, занятую другим процессом. Исходная книга и её отдельный NDM не перезаписывались. В новом каталоге и ZIP лежит исходный проверенный снимок NDMSNP06; он сохранён без изменений.\n'
(folder/'Прочитать.txt').write_text(readme,encoding='utf-8-sig')
package=folder/old_zip.name
with ZipFile(package,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for path in (target,folder/'Прочитать.txt',folder/'Verification.json',folder/snapshot_name):z.write(path,path.name)
with ZipFile(package) as z:
    assert z.testzip() is None
    assert hashlib.sha256(z.read(target.name)).hexdigest().upper()==heavy['PreparedSHA256']
    assert hashlib.sha256(z.read(snapshot_name)).hexdigest().upper()==original_sha
temporary=maincode.with_name(maincode.name+'.help-results-update.tmp');assert not temporary.exists()
shutil.copy2(P/'MainNative06/VBA_All_Code.txt',temporary);os.replace(temporary,maincode)
# Убирается только собственный временный файл неудавшейся атомарной замены; его байты сохраняются в резерве.
leftover=Path(heavy['Source']).with_name(Path(heavy['Source']).name+'.help-results-update.tmp')
assert leftover.resolve().parent==old_dir.resolve() and test_sha(leftover)==heavy['PreparedSHA256']
os.replace(leftover,P/'BeforePublication09/Heavy/PreparedBlockedReplacement.tmp')
assert {str(p):test_sha(p) for p in foreign}==foreign_sha
receipts=[dict(Label='Main',Destination=main['Source'],SHA256=main['PreparedSHA256'],StandardPathUpdated=True),
    dict(Label='Heavy',Destination=str(target),SHA256=heavy['PreparedSHA256'],StandardPathUpdated=False,Reason='Original file locked by another process; preserved')]
result=dict(Status='PUBLISHED_NATIVE_VERIFIED_RESULTS_AND_HELP',PublishedUTC=datetime.now(timezone.utc).isoformat(),Books=receipts,
    Backup=str(P/'BeforePublication09'),AllCodeSHA256=test_sha(maincode),Package=str(package),PackageSHA256=test_sha(package),
    NewHeavySidecarSHA256=test_sha(folder/snapshot_name),PackagedOriginalSnapshotSHA256=original_sha,
    OriginalHeavyFileAndSidecarNotOverwritten=True,ForeignFilesPreserved=True,UserApplicationsClosed=False,FullOnOffPerformed=False)
(P/'Publication10.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('PUBLISHED_MAIN_AND_NEW_HEAVY_PACKAGE_WITHOUT_CLOSING_USER_BOOK')
