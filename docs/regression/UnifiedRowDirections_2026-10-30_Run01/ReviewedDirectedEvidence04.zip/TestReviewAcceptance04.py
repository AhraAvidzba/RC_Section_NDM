"""ДЛЯ ТЕСТОВ: целиком читает адресную приёмку и сверяет её состав с требованиями единого направления."""
from pathlib import Path
import json,re,hashlib,zipfile,subprocess
P=Path(__file__).parent;R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
E=R/'docs/regression/UnifiedRowDirections_2026-10-30_Run01'
def read(name):return json.loads((P/name).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
expected_no=['modTestRecipeSetbacks.RunRecipeSetbackInputTests','modTestRecipeSetbacks.RunRecipeSetbackUnitTests',
 'modTestSectionRecipes.RunRecipeRuleTests','modTestSectionRecipes.RunRecipeDefinitionTests',
 'modTestSectionRecipes.RunWorkbookRecipeInputTests','modTestSectionRecipes.RunRoundedRecipeInputTests',
 'modTestSectionRecipes.RunHollowRecipeInputTests','modTestIndividualContours.RunIndividualContourTests',
 'modTestIndividualContours.RunOffsetNeighborMergeTests','modTestIndividualContours.RunIndividualContourWorkbookTests',
 'modTestRecipeAnnotations.RunRecipeAnnotationTests','modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests',
 'modTestSectionRecipes.RunRecipeAnnotationCountTests','modTestWorkbookInterface.RunFormationPreviewTests',
 'modTestWorkbookInterface.RunSectionWorkflowCalculationTests']
expected_yes=['modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests','modTestWorkbookInterface.RunFormationPreviewTests',
 'modTestWorkbookInterface.RunSectionWorkflowCalculationTests','modTestSectionRecipes.RunHollowRecipeEquilibriumTests',
 'modTestSectionRecipes.RunHollowRecipeEdgeEquilibriumTests','modTestSectionRecipes.RunRoundedRecipeEquilibriumTests']
records=[];total=0
for directory,names,mode in [('Test_No_Affected03',expected_no,'No'),('Test_Yes_Output04',expected_yes,'Yes')]:
    receipt=read(directory+'/Result.json');macros=read(directory+'/Macros.json')
    assert receipt['Passed'] and receipt['OwnClosure']=='ConfirmedNotFound' and receipt['Mode']==mode
    assert receipt['SourceSHA256']==receipt['SourceAfterSHA256']
    assert [x['Macro'] for x in macros]==names
    for item in macros:
        path=P/directory/(item['Macro']+'.txt');text=path.read_text(encoding='utf-8-sig')
        matches=re.findall(r'(?im)^TOTAL[^\r\n]*passed=(\d+); failed=(\d+)',text)
        assert item['Passed'] and matches and all(int(f)==0 for _,f in matches)
        assert not re.search(r'(?im)^FAIL\b',text)
        count=int(matches[-1][0]);total+=count
        records.append({'Directory':directory,'Macro':item['Macro'],'Passed':count,'Failed':0,'Bytes':path.stat().st_size,'SHA256':sha(path),'Seconds':item['Seconds']})
assert len(records)==21 and total==7764
text=(P/'Test_No_Affected03/modTestRecipeSetbacks.RunRecipeSetbackInputTests.txt').read_text(encoding='utf-8')
cases=re.findall(r'^DIRECTION_CASE: kind=(\d); row=([^;]+); endModes=4; counts=1,4; extras=4$',text,re.M)
required={(str(k),s) for k in (0,1) for s in ('R1.Top','R1.Bottom','R1.Left','R1.Right')}
required|={('1',s) for s in ('R2.Top','R2.Bottom','R2.Left','R2.Right')}
required|={(str(k),s) for k in (2,3) for s in ('Top','Bottom','Left','Right')}
assert len(cases)==20 and set(cases)==required
projections=re.findall(r'^DIRECTION_PROJECTION: row=([^;]+); accepted=(\d+)$',text,re.M)
assert dict(projections)=={'Top':'3','Bottom':'3','Left':'2','Right':'2'}
curves=re.findall(r'^DIRECTION_CURVE: kind=(\d); row=([^;]+); asymmetricArcSetbacks=True$',text,re.M)
assert set(curves)=={(str(k),s) for k in (2,3) for s in ('Top','Bottom','Left','Right')} and len(curves)==8
assert read('FinalSourceEquality03.json')['Passed']
assert read('AllOwnClosures04.json')['Passed'] and read('AllOwnClosures04.json')['Count']==6
preservation=read('PackagePreservation02.json');final=P/'FinalPreserved02.xlsm'
assert sha(final)==preservation['FinalSHA256']
with zipfile.ZipFile(final) as f,zipfile.ZipFile(P/'Candidate02.xlsm') as n,zipfile.ZipFile(P/'UserMainBefore.xlsm') as a:
    assert f.read('xl/vbaProject.bin')==n.read('xl/vbaProject.bin')
    assert f.namelist()==a.namelist() and f.testzip() is None
    assert set(k for k in a.namelist() if a.read(k)!=f.read(k))=={'xl/vbaProject.bin','xl/worksheets/sheet3.xml'}
assert read('Inspect_No_Final03/Result.json')['HelpReadbackCount']==7
assert len(read('Inspect_No_Final03/HelpReadback.json'))==7
original=(P/'SourceBefore/tests/modTestRecipeSetbacks.bas').read_text(encoding='utf-8-sig')
current=(R/'tests/modTestRecipeSetbacks.bas').read_text(encoding='utf-8-sig')
assert current.startswith(original.replace('    TestCircleClosedEndModes','    TestCircleClosedEndModes\n    TestUniformRowDirections'))
changed_src=subprocess.check_output(['git','diff','--name-only','--','src'],cwd=R).decode().splitlines()
assert set(changed_src)=={'src/Geometry/CSectionRecipeRectangles.cls','src/Geometry/CSectionRecipeHollowRectangle.cls'}
audit=read('DocumentationAudit01.json')
assert set(audit['MissingModuleHeaders'])=={'src/Excel/modSectionSnapshot.bas'}
assert {x['Path'] for x in audit['MissingMethodHeaders']}=={'src/Excel/CNDMResultsWriter.cls'}
assert subprocess.check_output(['git','diff','--','src/Excel/modSectionSnapshot.bas','src/Excel/CNDMResultsWriter.cls'],cwd=R)==b''
result={'Status':'PASS_DIRECTED','AssertionsPassed':total,'AssertionsFailed':0,'AcceptedExecutions':records,
 'WholeReportsRead':True,'DirectionCases':cases,'ProjectionCases':projections,'ArcCases':curves,
 'EndModesPerStraightCase':4,'SingleAndFourBarsChecked':True,'ExtraPlacementsAndEverySecondChecked':True,
 'ExistingExpectationsPreserved':True,'SourceComponents':175,'NativeComponents':181,'FullSuiteRun':False,
 'SourceMainBookSHA256':sha(P/'UserMainBefore.xlsm'),'FinalBookSHA256':sha(final),
 'NativeSavedReopenedCodeEquality':True,'SharedHelpUpdatedWithoutLayoutOrLinkShift':True,
 'Preservation':preservation,'AllOwnIdentitiesClosed':6,
 'SetupHistory':'Build01 stopped on UTF8 JSON decoding. Build02 compiled and saved; its Excel exit was confirmed after client termination. Original receipts retained.',
 'DocumentationAudit':'Two existing header omissions in unchanged files; no new omissions in changed files.'}
(P/'Acceptance04.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
E.mkdir(parents=True,exist_ok=True)
files=['Acceptance04.json','PackagePreservation02.json','AllOwnClosures04.json','FinalSourceEquality03.json',
 'SourceEquality02.json','SourceChanges01.json','HelpTargets01.json','HelpParagraphChanges01.json',
 'ChangedModules01.json','HelpVisualReview02.json','DocumentationAudit01.json','Build01ClosureAfterClientExit.json',
 'Build02ClosureAfterClientExit.json','TestPatchSources01.py','TestPrepareHelp01.py','TestNativeDirections01.ps1',
 'TestDirectionCases01.bas','TestPackageWorkbook01.py','TestReviewAcceptance04.py']
for directory in ('Build_No_01','Build_No_02','Test_No_02','Test_No_Affected03','Inspect_No_Final03','Test_Yes_Output04'):
    files += [str(p.relative_to(P)).replace('\\','/') for p in (P/directory).glob('*.json') if p.name!='Components.json']
files += [r['Directory']+'/'+r['Macro']+'.txt' for r in records]
files += ['Build_No_02/After_1.png','Build_No_02/After_2.png','Build_No_02/After_3.png']
files=list(dict.fromkeys(files))
with zipfile.ZipFile(E/'ReviewedDirectedEvidence04.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in files:z.write(P/name,name)
manifest={'ArchiveSHA256':sha(E/'ReviewedDirectedEvidence04.zip'),'Files':[{'Path':n,'Bytes':(P/n).stat().st_size,'SHA256':sha(P/n)} for n in files]}
(E/'Manifest04.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ('Acceptance04.json','PackagePreservation02.json','AllOwnClosures04.json'):(E/name).write_bytes((P/name).read_bytes())
(E/'Processed.json').write_text(json.dumps({'Status':'DIRECTED_PASS_READY_FOR_PUBLICATION','FullSuiteRun':False,'AssertionsPassed':total,'AssertionsFailed':0,'Acceptance':'Acceptance04.json'},indent=2),encoding='utf-8')
report='''# Единое направление арматурных рядов — 30.10.2026

Горизонтальные ряды всех параметрических типов направлены слева направо, вертикальные — сверху вниз, включая стороны отверстия. s0, s1, IncludeStart/IncludeEnd и EverySecondBar следуют этому направлению. SideBySide направлен вперёд по пути, Stacked — в бетон. У Circle сохранены начало в верхней точке и обход по часовой стрелке.

В Rectangles изменены пути Left/Bottom обоих исходных прямоугольников и соответствующие нормали. В HollowRectangle изменены вертикальные пути наружной границы и отверстия, нормали Extra и направления лучей проекции. PointedSection уже следует этому контракту. Использованы существующие Chain/OffsetContour и общие правила; собственной расстановки в рецептах нет. Порядок групп, нумерация от середины в Rectangles и правило первого владельца сохранены. Исходные бетонные контуры, ядро смещения, solver и нормативные формулы не менялись.

Общий блок справки описывает направления один раз; описания типов ссылаются на него. Обновлены семь абзацев, сохранены ссылки, оформление и границы таблиц. Нативные PNG просмотрены: текст читается без обрезки. Актуальный контракт закреплён также в AGENTS и геометрическом ТЗ; описание ориентации исходного замкнутого контура в API остаётся самостоятельным геометрическим правилом.

Адресная приёмка **7764/0**: все 15 затронутых наборов в No и шесть наборов вывода/независимого равновесия в Yes. Все первичные отчёты прочитаны целиком. Новая аналитическая матрица проверяет 20 сторон, четыре EndMode, n=1/4, неодинаковые s0/s1, 80 комбинаций Extra, четыре проекционных стороны и восемь дуговых случаев. 92 сценария физических подписей, индивидуальные контуры, обычные/предельные Hollow, Pointed, roundtrip и расчёт по сохранённой геометрии приняты. Исходные ожидания существующих тестов не менялись. Новый полный 182+Focused122 не запускался; предыдущая полная приёмка относится к своей зафиксированной SHA.

VBE-компиляция и нативное повторное открытие: 175 исходных + 6 документных компонентов соответствуют исходникам, семь абзацев прочитаны из финального файла. Все шесть собственных Excel завершены после обычного Quit. Первичная служебная сборка остановилась на неверной кодировке JSON в PS5; UTF8 исправлена. У сборки02 процесс завершился после выхода COM-клиента, что проверено отдельно; первоначальные квитанции сохранены. Общий аудит шапок показывает только две существующие проблемы неизменённых файлов, новых нет.

В пользовательской книге изменяются только VBA и лист справки: семь текстовых ячеек и необходимые высоты их строк. Остальные 109 ZIP-частей побайтно совпадают, включая входы, результаты, схему, стили и имена; остальной XML справки семантически совпадает. Сохранённые результаты не пересчитывались. Для применения новых направлений к сохранённой геометрии нужно нажать «Сформировать сечение»; расчёт сам её не перестраивает.

Доказательства: [Acceptance04](../regression/UnifiedRowDirections_2026-10-30_Run01/Acceptance04.json), [манифест](../regression/UnifiedRowDirections_2026-10-30_Run01/Manifest04.json).
'''
(R/'docs/reports/UnifiedRowDirections_2026-10-30.md').write_text(report,encoding='utf-8')
progress=R/'docs/geometry_refactor/PROGRESS.md';old=progress.read_text(encoding='utf-8-sig');heading,rest=old.split('\n',1)
progress.write_text(heading+'\n\n## 30.10.2026 — Единое направление арматурных рядов\n\nГоризонтальные ряды всех типов идут вправо, вертикальные вниз, включая отверстие; Extra/EverySecond/проекции согласованы. Circle — от верхней точки по часовой стрелке. Общий контур и декларативные рецепты сохранены, справка обновлена без сдвига ссылок. Адресная приёмка 7764/0 (15 No + 6 Yes), нативные181/equality/Help и все6 own проверены. Данные и сохранённые результаты пользовательской книги сохранены. [Отчёт](../reports/UnifiedRowDirections_2026-10-30.md).\n'+rest,encoding='utf-8')
print(json.dumps({'Status':'PASS_DIRECTED','Executions':len(records),'AssertionsPassed':total,'Files':len(files),'FinalBookSHA256':sha(final)}))
