"""ДЛЯ ТЕСТОВ: находит точные ячейки меняемых абзацев; не пересоздаёт лист или его оформление."""
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile,json,posixpath,subprocess
P=Path(__file__).parent;R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
M='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
with zipfile.ZipFile(P/'UserMainBefore.xlsm') as z:
    strings=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml'))]
    wb=ET.fromstring(z.read('xl/workbook.xml'));rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    sheet=next(x for x in wb.find(M+'sheets') if x.get('name')=='Справка')
    rid=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
    target=next(x.get('Target') for x in rels if x.get('Id')==rid)
    part=posixpath.normpath(posixpath.join('xl',target)) if not target.startswith('/') else target[1:]
    helpxml=ET.fromstring(z.read(part));cells={}
    for cell in helpxml.iter(M+'c'):
        v=cell.find(M+'v'); text=''
        if cell.get('t')=='s' and v is not None:text=strings[int(v.text)]
        elif cell.get('t')=='inlineStr':text=''.join(cell.find(M+'is').itertext())
        elif v is not None:text=v.text or ''
        cells[cell.get('r')]=text
    replacements=json.loads((P/'HelpParagraphChanges01.json').read_text(encoding='utf-8'))
    for item in replacements:
        matches=[ref for ref,text in cells.items() if text==item['Before']]
        assert len(matches)==1,(item['Before'],matches)
        item['Cell']=matches[0]
    blocks=[]
    for title in ('Как задать сечение и армирование','Клиновидное сечение','Пустотелый прямоугольник','Набор прямоугольников'):
        matches=[ref for ref,text in cells.items() if text==title]
        if not matches and title=='Набор прямоугольников':
            matches=[ref for ref,text in cells.items() if text in ('Прямоугольное и составное сечение','Прямоугольные сечения')]
        if not matches:
            print('TITLE_NOT_CAPTURED',title);continue
        assert len(matches)==1,(title,matches)
        row=int(''.join(c for c in matches[0] if c.isdigit()))
        blocks.append({'Title':title,'Range':f'A{row}:F{row+12}'})
    data={'HelpPart':part,'Paragraphs':replacements,'Blocks':blocks}
    (P/'HelpTargets01.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
modules=[]
for name in subprocess.check_output(['git','diff','--name-only','--','src','tests'],cwd=R).decode().splitlines():
    if Path(name).suffix in ('.bas','.cls'):modules.append({'Name':Path(name).stem,'Path':name})
(P/'ChangedModules01.json').write_text(json.dumps(modules,indent=2),encoding='utf-8')
print(json.dumps({'HelpPart':part,'Cells':[x['Cell'] for x in replacements],'Modules':modules},ensure_ascii=False))
