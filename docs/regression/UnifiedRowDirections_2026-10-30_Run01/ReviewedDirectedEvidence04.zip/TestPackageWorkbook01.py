"""ДЛЯ ТЕСТОВ: переносит только VBA и семь проверенных абзацев справки в исходный пользовательский пакет."""
from pathlib import Path
from copy import copy,deepcopy
import argparse,hashlib,json,zipfile
from lxml import etree as E
P=Path(__file__).parent
parser=argparse.ArgumentParser();parser.add_argument('--candidate',default='Candidate02.xlsm');parser.add_argument('--build',default='Build_No_02');parser.add_argument('--tag',default='02');args=parser.parse_args()
M='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
def read(n):return json.loads((P/n).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
targets=read('HelpTargets01.json');receipt=read(args.build+'/Result.json')
assert receipt['Passed'] and receipt['Compiled'] and receipt['Components']==181 and receipt['HelpCells']==7
original=P/'UserMainBefore.xlsm';candidate=P/args.candidate;final=P/('FinalPreserved'+args.tag+'.xlsm')
assert not final.exists() and receipt['SourceAfterSHA256']==sha(candidate)
with zipfile.ZipFile(original) as z:
    info=[copy(i) for i in z.infolist()];parts={i.filename:z.read(i.filename) for i in info};comment=z.comment
with zipfile.ZipFile(candidate) as z:
    vba=z.read('xl/vbaProject.bin');native=E.fromstring(z.read(targets['HelpPart']))
source=E.fromstring(parts[targets['HelpPart']]);helpout=deepcopy(source)
oldrows={row.get('r'):row for row in source.find(M+'sheetData')}
newrows={row.get('r'):row for row in helpout.find(M+'sheetData')}
nativerows={row.get('r'):row for row in native.find(M+'sheetData')}
for item in targets['Paragraphs']:
    row=''.join(x for x in item['Cell'] if x.isdigit());newrow=newrows[row]
    cell=next(c for c in newrow if c.get('r')==item['Cell'])
    assert cell.find(M+'f') is None
    for child in list(cell):cell.remove(child)
    cell.set('t','inlineStr');text=E.SubElement(E.SubElement(cell,M+'is'),M+'t');text.text=item['After']
    for key in ('ht','customHeight'):
        if nativerows[row].get(key) is None:newrow.attrib.pop(key,None)
        else:newrow.set(key,nativerows[row].get(key))
# Восстановление семи ячеек/высот в контрольной копии должно вернуть весь исходный XML без других изменений.
check=deepcopy(helpout);checkrows={row.get('r'):row for row in check.find(M+'sheetData')}
for item in targets['Paragraphs']:
    row=''.join(x for x in item['Cell'] if x.isdigit());checkrow=checkrows[row]
    oldcell=next(c for c in oldrows[row] if c.get('r')==item['Cell'])
    newcell=next(c for c in checkrow if c.get('r')==item['Cell'])
    assert oldcell.get('s')==newcell.get('s')
    checkrow.replace(newcell,deepcopy(oldcell))
    for key in ('ht','customHeight'):
        if oldrows[row].get(key) is None:checkrow.attrib.pop(key,None)
        else:checkrow.set(key,oldrows[row].get(key))
assert E.tostring(check,method='c14n')==E.tostring(source,method='c14n')
parts['xl/vbaProject.bin']=vba
parts[targets['HelpPart']]=E.tostring(helpout,xml_declaration=True,encoding='UTF-8',standalone=True)
with zipfile.ZipFile(final,'w') as z:
    z.comment=comment
    for i in info:z.writestr(i,parts[i.filename])
with zipfile.ZipFile(original) as a,zipfile.ZipFile(final) as b:
    assert a.namelist()==b.namelist() and b.testzip() is None
    changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
    assert set(changed)=={'xl/vbaProject.bin',targets['HelpPart']}
proof={'OriginalSHA256':sha(original),'FinalSHA256':sha(final),'NativeCandidateSHA256':sha(candidate),'ChangedZIPParts':changed,
       'UnchangedZIPParts':len(info)-2,'OnlySevenHelpCellsAndTheirRowHeightsChanged':True,'AllOtherHelpXMLIdentical':True,
       'DataResultsPlotConfigStylesNamesLinksPreserved':True,'SavedResultsRecalculated':False,
       'HelpCells':[i['Cell'] for i in targets['Paragraphs']]}
(P/('PackagePreservation'+args.tag+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
