﻿# ДЛЯ ТЕСТОВ: сборка, сохранённое чтение и направленные проверки только в отдельных собственных Excel.
param([ValidateSet('Build','Inspect','Test')][string]$Stage='Build', [string]$Tag='01', [string]$WorkbookPath='',
      [ValidateSet('No','Yes')][string]$Mode='No', [ValidateSet('DirectionOnly','Affected','FinalOutput')][string]$SuiteSet='DirectionOnly')
$ErrorActionPreference='Stop'
Import-Module 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1' -Global
$p=$PSScriptRoot;$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
if(-not $WorkbookPath){$WorkbookPath=Join-Path $p 'Candidate01.xlsm'}
$path=(Resolve-Path -LiteralPath $WorkbookPath).Path
if(-not $path.StartsWith($p+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Native work requires a private copy'}
$out=Join-Path $p ($Stage+'_'+$Mode+'_'+$Tag)
if(Test-Path -LiteralPath (Join-Path $out 'Result.json')){throw 'Use a new evidence tag'}
[void][IO.Directory]::CreateDirectory($out)
$os=Get-CimInstance Win32_OperatingSystem;$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$free=[double]$os.FreePhysicalMemory*1024/1GB;$commit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
if($free -lt 8 -or $commit -lt 14){throw "Insufficient RAM/commit reserve: $free/$commit GiB"}
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object {$_.Id})
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class TestDirectionWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hWnd,out uint id);}'
$excel=$null;$book=$null;$ownedId=0;$ticks=0;$quit=$false
$r=[ordered]@{Stage=$Stage;Tag=$Tag;Mode=$Mode;SuiteSet=$SuiteSet;Source=$path;SourceSHA256=(Get-FileHash -LiteralPath $path).Hash;FreeRAMGiB=$free;FreeCommitGiB=$commit;Passed=$false;Error=''}

# ДЛЯ ТЕСТОВ: временный ChartObject нужен только для экспорта ячеек; он удаляется до сохранения книги.
function Export-TestHelpPictures([string]$Prefix){
    $helpData=Get-Content -LiteralPath (Join-Path $p 'HelpTargets01.json') -Raw -Encoding UTF8|ConvertFrom-Json
    $sheet=$book.Worksheets.Item('Справка');$index=0
    foreach($block in $helpData.Blocks){
        $index++;$capture=$sheet.Range($block.Range);$sheet.Activate();$capture.CopyPicture(1,2)
        $chartBox=$sheet.ChartObjects().Add(0,0,[double]$capture.Width,[double]$capture.Height)
        try{$chartBox.Activate();$chartBox.Chart.Paste();if(-not $chartBox.Chart.Export((Join-Path $out ($Prefix+'_'+$index+'.png')),'PNG')){throw 'Help PNG export failed'}}
        finally{$chartBox.Delete();$chartBox=$null}
    }
}
try{
    $excel=New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][TestDirectionWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    if([int]$id -in $existing){throw 'Excel returned a pre-existing process'}
    $ownedId=[int]$id;$ticks=(Get-Process -Id $ownedId).StartTime.ToUniversalTime().Ticks
    $r.OwnedPID=$ownedId;$r.OwnedStartTicksUTC=[string]$ticks
    $r|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $out 'Ownership.json') -Encoding utf8
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=3
    if($Stage -eq 'Test'){$excel.AutomationSecurity=1}
    $book=$excel.Workbooks.Open($path,0,($Stage -ne 'Build'))
    if($Stage -eq 'Build'){
        if($book.ReadOnly){throw 'Candidate opened readonly'}
        Export-TestHelpPictures 'Before'
        $modules=Get-Content -LiteralPath (Join-Path $p 'ChangedModules01.json') -Raw -Encoding UTF8|ConvertFrom-Json
        foreach($item in $modules){
            $source=[IO.File]::ReadAllText((Join-Path $root $item.Path),[Text.Encoding]::UTF8)
            $body=[regex]::Match($source,'(?ms)^Option Explicit.*').Value
            if(-not $body){throw ('Missing source body '+$item.Name)}
            $module=$book.VBProject.VBComponents.Item($item.Name).CodeModule
            $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($body)
        }
        $excel.VBE.ActiveVBProject=$book.VBProject;$compile=$excel.VBE.CommandBars.FindControl(1,578)
        if($null -eq $compile){throw 'Missing VBE compile command'}
        if($compile.Enabled){$compile.Execute()}
        if($compile.Enabled){throw 'VBE compilation did not complete'}
        $targets=Get-Content -LiteralPath (Join-Path $p 'HelpTargets01.json') -Raw -Encoding UTF8|ConvertFrom-Json
        $help=$book.Worksheets.Item('Справка');$checks=@()
        foreach($item in $targets.Paragraphs){
            $cell=$help.Range($item.Cell)
            if([string]$cell.Value2 -cne [string]$item.Before){throw ('Help text changed: '+$item.Cell)}
            $oldHeight=[double]$cell.EntireRow.RowHeight
            $cell.Value2=[string]$item.After;$cell.EntireRow.AutoFit()|Out-Null
            if([string]$cell.Value2 -cne [string]$item.After){throw 'Help write mismatch'}
            $checks+=,[ordered]@{Cell=$item.Cell;Before=$item.Before;After=$item.After;BeforeHeight=$oldHeight;AfterHeight=[double]$cell.EntireRow.RowHeight;Wrap=[bool]$cell.WrapText;Font=[string]$cell.Font.Name;FontSize=[double]$cell.Font.Size}
        }
        $checks|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $out 'HelpChecks.json') -Encoding utf8
        Export-TestHelpPictures 'After'
        $book.Save();$r.Compiled=$true;$r.HelpCells=$checks.Count
    }
    if($Stage -eq 'Test'){
        $settings=$book.Names.Item('rngSystemSettings').RefersToRange;$found=0
        for($row=1;$row -le $settings.Rows.Count;$row++){
            if([string]$settings.Cells.Item($row,1).Value2 -eq 'General.ReformatResultsEnabled'){$settings.Cells.Item($row,2).Value2=$Mode;$found++;if([string]$settings.Cells.Item($row,2).Value2 -cne $Mode){throw 'Mode write failed'}}
        }
        if($found -ne 1){throw 'Mode setting not unique'}
        $macros=@('modTestRecipeSetbacks.RunRecipeSetbackInputTests')
        if($SuiteSet -eq 'Affected'){
            $macros=@('modTestRecipeSetbacks.RunRecipeSetbackInputTests','modTestRecipeSetbacks.RunRecipeSetbackUnitTests',
                'modTestSectionRecipes.RunRecipeRuleTests','modTestSectionRecipes.RunRecipeDefinitionTests',
                'modTestSectionRecipes.RunWorkbookRecipeInputTests','modTestSectionRecipes.RunRoundedRecipeInputTests',
                'modTestSectionRecipes.RunHollowRecipeInputTests','modTestIndividualContours.RunIndividualContourTests',
                'modTestIndividualContours.RunOffsetNeighborMergeTests','modTestIndividualContours.RunIndividualContourWorkbookTests',
                'modTestRecipeAnnotations.RunRecipeAnnotationTests','modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests',
                'modTestSectionRecipes.RunRecipeAnnotationCountTests','modTestWorkbookInterface.RunFormationPreviewTests',
                'modTestWorkbookInterface.RunSectionWorkflowCalculationTests')
        }
        if($SuiteSet -eq 'FinalOutput'){
            $macros=@('modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests',
                'modTestWorkbookInterface.RunFormationPreviewTests','modTestWorkbookInterface.RunSectionWorkflowCalculationTests',
                'modTestSectionRecipes.RunHollowRecipeEquilibriumTests','modTestSectionRecipes.RunHollowRecipeEdgeEquilibriumTests',
                'modTestSectionRecipes.RunRoundedRecipeEquilibriumTests')
        }
        $all=@()
        foreach($macro in $macros){
            $started=[DateTime]::UtcNow
            Write-Output ('START '+$macro)
            $text=[string]$excel.Run("'"+$book.Name+"'!"+$macro)
            [IO.File]::WriteAllText((Join-Path $out ($macro+'.txt')),$text,[Text.UTF8Encoding]::new($false))
            $counts=[regex]::Matches($text,'(?im)\bfailed\s*=\s*(\d+)')
            $passed=$counts.Count -gt 0 -and @($counts|Where-Object {[long]$_.Groups[1].Value -ne 0}).Count -eq 0 -and $text -notmatch '(?im)^FAIL\b'
            $all+=,[ordered]@{Macro=$macro;Passed=$passed;Seconds=([DateTime]::UtcNow-$started).TotalSeconds}
            $all|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $out 'Macros.json') -Encoding utf8
            Write-Output ($text -split '\r?\n'|Where-Object {$_ -match '^TOTAL'}|Select-Object -Last 1)
            if(-not $passed){throw ('Directed suite failed: '+$macro)}
        }
        $r.Macros=$all
    }else{
        $bodies=[ordered]@{};$dump=New-Object Text.StringBuilder
        [void]$dump.AppendLine('Date: '+[DateTime]::UtcNow.ToString('o'))
        foreach($component in $book.VBProject.VBComponents){
            $module=$component.CodeModule;$count=$module.CountOfLines;$body=''
            if($count -gt 0){$body=[string]$module.Lines(1,$count)}
            $bodies[$component.Name]=[ordered]@{Type=[int]$component.Type;Body=$body}
            [void]$dump.AppendLine('COMPONENT: '+$component.Name);[void]$dump.AppendLine('TYPE: '+$component.Type)
            [void]$dump.AppendLine('LINES: '+$count);[void]$dump.AppendLine('');[void]$dump.AppendLine($body)
        }
        $bodies|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $out 'Components.json') -Encoding utf8
        [IO.File]::WriteAllText((Join-Path $out 'VBA_All_Code.txt'),$dump.ToString(),[Text.UTF8Encoding]::new($false))
        $r.Components=$bodies.Count
    }
    if($Stage -eq 'Inspect'){
        $targets=Get-Content -LiteralPath (Join-Path $p 'HelpTargets01.json') -Raw -Encoding UTF8|ConvertFrom-Json
        $help=$book.Worksheets.Item('Справка');$checks=@()
        foreach($item in $targets.Paragraphs){
            $cell=$help.Range($item.Cell)
            if([string]$cell.Value2 -cne [string]$item.After){throw ('Reopened help mismatch '+$item.Cell)}
            if(-not $cell.WrapText -or $cell.Font.Name -ne 'Arial' -or [double]$cell.Font.Size -ne 10){throw 'Help presentation mismatch'}
            $checks+=,[ordered]@{Cell=$item.Cell;After=[string]$cell.Value2;Height=[double]$cell.EntireRow.RowHeight}
        }
        $checks|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $out 'HelpReadback.json') -Encoding utf8
        $r.HelpReadbackCount=$checks.Count
    }
    $r.Passed=$true
}catch{$r.Error=$_.Exception.ToString();throw}
finally{
    if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book);$book=$null}
    if($excel -and $ownedId){$excel.Quit();$quit=$true}
    if($excel){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null}
    $module=$null;$component=$null;$help=$null;$cell=$null;$settings=$null;$compile=$null
    [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect()
    $state='Unknown'
    for($attempt=0;$attempt -lt 35;$attempt++){
        try{$v=Get-Process -Id $ownedId -ErrorAction Stop;if($v.ProcessName -ne 'EXCEL' -or $v.StartTime.ToUniversalTime().Ticks -ne $ticks){$state='DifferentIdentity';break};$state='Live'}
        catch{if($_.FullyQualifiedErrorId -like 'NoProcessFoundForGivenId*'){$state='ConfirmedNotFound'};break}
        Start-Sleep -Milliseconds 200
    }
    $r.QuitRequested=$quit;$r.OwnClosure=$state;$r.SourceAfterSHA256=(Get-FileHash -LiteralPath $path).Hash
    $r|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $out 'Result.json') -Encoding utf8
    if($state -notin @('ConfirmedNotFound','DifferentIdentity')){throw ('Own closure not confirmed: '+$state)}
}
