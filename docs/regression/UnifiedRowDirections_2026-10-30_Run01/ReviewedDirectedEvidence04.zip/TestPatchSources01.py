"""ДЛЯ ТЕСТОВ: точечная правка деклараций направлений и общей справки с резервом источников."""
from pathlib import Path
import hashlib,json
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
P=Path(__file__).parent
changes={}
def edit(name,old,new):
    if name not in changes:changes[name]=(R/name).read_text(encoding='utf-8-sig')
    assert changes[name].count(old)==1,(name,old)
    changes[name]=changes[name].replace(old,new)

rect='src/Geometry/CSectionRecipeRectangles.cls'
edit(rect,"Case 1 ' Линия арматуры у левой грани: отступ as, снизу вверх.","Case 1 ' Линия арматуры у левой грани: отступ as, сверху вниз.")
edit(rect,"Case 4 ' Линия арматуры у нижней грани: отступ as, справа налево.","Case 4 ' Линия арматуры у нижней грани: отступ as, слева направо.")
edit(rect,'Dim tangentSign As Double, i As Long, rowNumber As Long, path As CGeometryPath, options As CRebarRuleOptions',
          'Dim normalSign As Double, forward As Boolean, i As Long, rowNumber As Long, path As CGeometryPath, options As CRebarRuleOptions')
edit(rect,'''            Set path = facade.Chain(.ID, contours((i - 1) \\ 4 + 1).ID, CStr(groups((i - 1) Mod 4)), 1#, CStr(groups((i - 1) Mod 4)), 0#, False) ' Направления: Left снизу вверх, Right сверху вниз, Top слева направо, Bottom справа налево; концы учитывают соседние as.''',
'''            side = (i - 1) Mod 4 + 1 ' Для обоих прямоугольников: Left/Right сверху вниз, Top/Bottom слева направо.
            forward = (side = 1 Or side = 4) ' Left и Bottom следуют исходному контуру; Right и Top проходят его в обратную сторону.
            normalSign = -1#: If forward Then normalSign = 1# ' Знак левой нормали выбранного пути, направленной внутрь соответствующего прямоугольника.
            Set path = facade.Chain(.ID, contours((i - 1) \\ 4 + 1).ID, CStr(groups(side - 1)), _
                IIf(forward, 0#, 1#), CStr(groups(side - 1)), IIf(forward, 1#, 0#), forward) ' Концы общего смещённого пути учитывают as всех соседних сторон.''')
edit(rect,'''            facade.RebarContour .ID & ".Main", "OUTER", .ContourSource, .AxisDistance, .ID & ".Row2", .ID & ".Row3", sourceSegments:=Array(CStr(groups((i - 1) Mod 4))), normalSign:=-1# ' Связь с исходным прямоугольником и известным направлением в бетон.
            Select Case (i - 1) Mod 4 + 1 ' Повторяем направления сторон Left/Right/Top/Bottom для обоих прямоугольников.
                Case 1, 4: tangentSign = -1#
                Case 2, 3: tangentSign = 1#
            End Select''',
'''            facade.RebarContour .ID & ".Main", "OUTER", .ContourSource, .AxisDistance, .ID & ".Row2", .ID & ".Row3", sourceSegments:=Array(CStr(groups(side - 1))), normalSign:=normalSign ' Связь с исходным прямоугольником и нормалью в бетон.''')
edit(rect,"contact.Initialize .Diameter, -1#, tangentSign, extraOptions ' Stacked направлен в бетон справа от обхода; знак касательной сохраняет выбранную ориентацию SideBySide.",
          "contact.Initialize .Diameter, normalSign, 1#, extraOptions ' Stacked направлен в бетон, SideBySide — вперёд по направлению ряда.")

hollow='src/Geometry/CSectionRecipeHollowRectangle.cls'
edit(hollow,"normalSign = 1#: If base = 1 Or base = 3 Then normalSign = -1# ' Оси горизонталей идут вправо, вертикалей вверх: выбираем сторону нормали внутрь наружного бетона.",
            "normalSign = 1#: If base = 1 Or base = 4 Then normalSign = -1# ' Горизонтали идут вправо, вертикали вниз; нормаль направлена внутрь наружного бетона.")
edit(hollow,"Горизонтальные линии идут слева направо и включают скругления, если они есть; вертикальные — снизу вверх.",
            "Горизонтальные линии идут слева направо и включают скругления, если они есть; вертикальные — сверху вниз.")
edit(hollow,'''Set AxisPath = facade.Chain(faces(index).ID, shape.ID, "Edge.BL", 0#, "Edge.BL", 1#) ' Линия центров у левой грани, снизу вверх.''',
            '''Set AxisPath = facade.Chain(faces(index).ID, shape.ID, "Edge.BL", 1#, "Edge.BL", 0#, False) ' Линия центров у левой грани, сверху вниз; обход контура обратный.''')
edit(hollow,'''Set AxisPath = facade.Chain(faces(index).ID, shape.ID, "Edge.TR", 1#, "Edge.TR", 0#, False) ' Линия центров у правой грани, снизу вверх; обход контура обратный.''',
            '''Set AxisPath = facade.Chain(faces(index).ID, shape.ID, "Edge.TR", 0#, "Edge.TR", 1#) ' Линия центров у правой грани, сверху вниз.''')

catalog='tools/build_workbook/SettingsCatalog.ps1'
help_replacements=[
 ('Направления раскладки указаны в справке соответствующего типа сечения.',
  'Горизонтальные ряды идут слева направо, вертикальные — сверху вниз; это же правило действует у отверстия.'),
 (' Направление пути указано в справке своего типа сечения.',''),
 ('EverySecondBar — у первого, третьего и следующих нечётных.',
  'EverySecondBar — у первого, третьего и следующих нечётных по направлению пути.'),
 ('а SideBySide — вдоль линии раскладки арматуры.',
  'а SideBySide — вперёд по направлению раскладки арматуры.'),
 ('Верхний и нижний ряды идут слева направо, оба боковых — сверху вниз.',
  'Направления рядов задаются общим правилом.'),
 ('Горизонтальные линии раскладки идут слева направо, вертикальные — снизу вверх. По этим направлениям отсчитываются отступы s0 и s1.',
  'Направления наружных рядов и рядов у отверстия задаются общим правилом.'),
 ('Верхние ряды арматуры идут слева направо, нижние — справа налево, левые — снизу вверх, правые — сверху вниз.',
  'Направления всех рядов задаются общим правилом.')]
old_catalog=(R/catalog).read_text(encoding='utf-8-sig')
for old,new in help_replacements:edit(catalog,old,new)
old_lines=old_catalog.splitlines();new_lines=changes[catalog].splitlines()
assert len(old_lines)==len(new_lines)
paragraphs=[]
for old,new in zip(old_lines,new_lines):
    if old!=new:
        assert old.strip().startswith('"') and new.strip().startswith('"')
        paragraphs.append({'Before':old.strip().strip(',')[1:-1],'After':new.strip().strip(',')[1:-1]})
edit('AGENTS.md','- Новый параметрический тип описывается',
     '- Направления раскладки Main и Extra едины для всех типов: горизонтальные ряды слева направо, вертикальные сверху вниз, включая стороны отверстий. У круга начало в верхней точке и обход по часовой стрелке. s0/s1, IncludeStart/IncludeEnd и выбор EverySecondBar следуют направлению пути; SideBySide смещает вперёд по нему, Stacked — в бетон. Рецепт явно задаёт путь и знак нормали без собственной расстановки стержней.\n- Новый параметрический тип описывается')
records=[]
for name,text in changes.items():
    source=R/name;before=source.read_bytes()
    backup=P/'SourceBefore'/name;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(before)
    data=text.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8')
    if before.startswith(b'\xef\xbb\xbf'):data=b'\xef\xbb\xbf'+data
    source.write_bytes(data)
    records.append({'Path':name,'BeforeSHA256':hashlib.sha256(before).hexdigest().upper(),'AfterSHA256':hashlib.sha256(data).hexdigest().upper()})
(P/'HelpParagraphChanges01.json').write_text(json.dumps(paragraphs,ensure_ascii=False,indent=2),encoding='utf-8')
(P/'SourceChanges01.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'SourceFiles':len(records),'HelpParagraphs':len(paragraphs)}))
