﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет формирование, расчёт и обновление схемы на отдельной копии чистой сборки.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/MainCleanRebuild_2026-10-28_Run01'
$source=Join-Path $PSScriptRoot 'FreshBuild01/RC_Section_NDM.xlsm';$sourceHash=(Get-FileHash -LiteralPath $source).Hash
$path=Join-Path $scratch 'Smoke/RC_Section_NDM.xlsm';[void][IO.Directory]::CreateDirectory((Split-Path -Parent $path));Copy-Item -LiteralPath $source -Destination $path
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCleanSmokeOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$range=$null;$records=New-Object 'System.Collections.Generic.List[object]'
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestCleanSmokeOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'SmokeOwnership.json') -Encoding UTF8
 $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($path,0,$false);$app.Visible=$true;$app.EnableEvents=$true;$app.Calculation=-4105
 $book.Worksheets.Item('Расчет').Activate()
 $range=$book.Names.Item('rngLoadCombinations').RefersToRange
 $range.Cells.Item(2,1).Value2='TEST_REBUILD_01';$range.Cells.Item(2,2).Value2=1.0;$range.Cells.Item(2,3).Value2=1.0;$range.Cells.Item(2,4).Value2=0.0
 $range=$null
 foreach($action in @('FormSectionForWorkbook','RunSectionCalculationForWorkbook','RunSectionCalculationForWorkbook','UpdateSectionResultsForWorkbook')){
  $watch=[Diagnostics.Stopwatch]::StartNew()
  if($action-eq'RunSectionCalculationForWorkbook'){$message=[string]$app.Run("'$($book.Name)'!$action",$book,$false)}else{$message=[string]$app.Run("'$($book.Name)'!$action",$book)}
  $seconds=$watch.Elapsed.TotalSeconds
  if($message-match'не выполнен|не сформирован|ошибк|не запускался|Предупреждение'){throw ('Smoke action did not finish cleanly: '+$message)}
  $record=[ordered]@{Action=$action;Seconds=$seconds;Message=$message;Ready=[bool]$app.Ready;CalculationState=[int]$app.CalculationState;ProductionVBAUnmodified=$true;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')}
  if(-not$record.Ready-or$record.CalculationState-ne0){throw 'Excel did not return ready'}
  $records.Add($record);$records|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'Smoke.json') -Encoding UTF8
  Write-Output ('SMOKE '+$action+': '+('{0:N3}'-f$seconds)+'s')
 }
 # Сохраняется только частная расчётная копия; чистая сборка остаётся без тестовых данных.
 $book.Save()
}finally{
 $range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'SmokeClosure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
if((Get-FileHash -LiteralPath $source).Hash-cne$sourceHash){throw 'Clean source changed during smoke'}
