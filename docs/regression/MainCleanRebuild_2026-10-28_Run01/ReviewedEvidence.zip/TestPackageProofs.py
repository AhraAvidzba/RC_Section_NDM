"""ДЛЯ ТЕСТОВ: сохраняет компактные доказательства чистой пересборки без книг и изображений."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).parent
SCRATCH = Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/MainCleanRebuild_2026-10-28_Run01')


def read(name):
    return json.loads((HERE/name).read_text(encoding='utf-8-sig'))


def main():
    layout = read('Layout.json')
    summary = {k:v for k,v in layout.items() if k!='Details'}
    (HERE/'LayoutSummary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    closures = [read(n) for n in ('VerificationAttempt01Closure.json','VerificationClosure.json','SmokeClosure.json','LayoutClosure.json')]
    assert all(x['Absent'] and not x['ForceKilled'] for x in closures)
    assert read('Build.json')['OwnProcessAbsent']
    assert read('NativeAcceptance.json')['Passed'] and layout['Status']=='PASS' and read('SourceEquality.json')['Passed']
    publication = read('Publication.json')
    assert publication['HeavyBeforeSHA256']==publication['HeavyAfterSHA256']
    records = read('Smoke.json')
    assert len(records)==4 and all(r['Ready'] and r['CalculationState']==0 and r['ProductionVBAUnmodified'] for r in records)
    proof = {
        'Status':'FRESH_MAIN_REBUILD_ACCEPTED',
        'Publication':publication,
        'NativeChecks':read('NativeAcceptance.json'),
        'Layout':summary,
        'NativeSourceEqualityPassed':True,
        'OwnClosures':closures,
        'BuildExcelAbsent':True,
        'ForceKilled':False,
        'SmokeActions':len(records),
        'ProductionSourceChanges':0,
        'FullSuiteLaunched':False,
        'UserVisualPauseAfterOKVerified':False,
        'PreparationIssues':[
            'First build wrapper checked Excel absence before remaining COM references were released; exact process independently absent after PowerShell exited.',
            'Verification harness needed UTF-8 BOM under Windows PowerShell5.1; first parse attempt did not launch Excel.',
            'Verification harness was narrowed to Config list dictionary instead of also matching unit/sign dictionaries; first native attempt closed normally.',
        ],
    }
    (HERE/'Processed.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    files = sorted(p for p in HERE.iterdir() if p.suffix in ('.json','.ps1','.py') and p.name not in ('ArchiveManifest.json', 'PushVerification.json'))
    extra = [SCRATCH/'Test-VerifySource.ps1']
    archive = HERE/'ReviewedEvidence.zip'
    manifest = []
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files+extra:
            name = p.name
            data = p.read_bytes()
            z.writestr(name,data)
            manifest.append({'Path':name,'Bytes':len(data),'SHA256':hashlib.sha256(data).hexdigest().upper()})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    result = {'Files':manifest,'ArchiveBytes':archive.stat().st_size,'ArchiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest().upper()}
    (HERE/'ArchiveManifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'PROOFS_READY: {len(manifest)} files; {archive.stat().st_size} bytes')


if __name__=='__main__':
    main()
