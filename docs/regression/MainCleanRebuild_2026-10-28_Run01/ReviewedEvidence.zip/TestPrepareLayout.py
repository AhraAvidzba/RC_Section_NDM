"""ДЛЯ ТЕСТОВ: запускает прежние проверки раскладки с безопасным завершением COM."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).parent
s = (ROOT/'tools/build_workbook/Test-WorkbookLayout.ps1').read_text(encoding='utf-8-sig')
s = s.replace(". (Join-Path $PSScriptRoot 'WorkbookLayout.ps1')", f". '{ROOT.as_posix()}/tools/build_workbook/WorkbookLayout.ps1'")
s = s.replace("$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path", f"$root='{ROOT.as_posix()}'")
s = s.replace("$app=$null;$book=$null;$owned=0;$ticks=0", "$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory\nif($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}\n$app=$null;$book=$null;$owned=0;$ticks=0")
s = s.replace(" $book=$app.Workbooks.Open($path,0,$true)", " [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'LayoutOwnership.json') -Encoding UTF8\n $book=$app.Workbooks.Open($path,0,$true)")
a = s.index('}finally{')
b = s.index('\nif((Get-FileHash',a)
s = s[:a] + '''}finally{
 $table=$null;$cell=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'LayoutClosure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}''' + s[b:]
(HERE/'Test-Layout.ps1').write_text(s,encoding='utf-8-sig')
