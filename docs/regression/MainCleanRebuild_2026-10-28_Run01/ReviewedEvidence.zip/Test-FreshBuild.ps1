﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Собирает новую основную книгу из Workbooks.Add, не открывая опубликованные книги.
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major-ne5){throw 'Windows PowerShell5.1 required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$output='docs/regression/MainCleanRebuild_2026-10-28_Run01/FreshBuild01/RC_Section_NDM.xlsm'
if(Test-Path -LiteralPath (Split-Path -Parent $output)){throw 'Fresh build directory must not exist'}
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/MainCleanRebuild_2026-10-28_Run01'
[void][IO.Directory]::CreateDirectory((Join-Path $scratch 'Backup'))
$main=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$heavy=Join-Path $root 'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm'
$allCode=Join-Path $root 'workbook/output/VBA_All_Code.txt'
$before=[ordered]@{AtUTC=[DateTimeOffset]::UtcNow.ToString('o');HEAD=(&git rev-parse HEAD);MainSHA256=(Get-FileHash -LiteralPath $main).Hash;HeavySHA256=(Get-FileHash -LiteralPath $heavy).Hash;AllCodeSHA256=(Get-FileHash -LiteralPath $allCode).Hash;BuildInputs=@()}
foreach($dir in @('src','tests','tools/build_workbook')){foreach($file in Get-ChildItem -LiteralPath (Join-Path $root $dir) -Recurse -File){$before.BuildInputs+=,[ordered]@{Path=$file.FullName.Substring($root.Length+1);SHA256=(Get-FileHash -LiteralPath $file.FullName).Hash}}}
$before|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'Before.json') -Encoding UTF8
Copy-Item -LiteralPath $main -Destination (Join-Path $scratch 'Backup/RC_Section_NDM_Before.xlsm')
Copy-Item -LiteralPath $allCode -Destination (Join-Path $scratch 'Backup/VBA_All_Code_Before.txt')
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
[ordered]@{RAMGiB=([double]$m.AvailableMBytes/1024);CommitFreeGiB=([double]($m.CommitLimit-$m.CommittedBytes)/1GB);MinimumRAMGiB=8;MinimumCommitGiB=14}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'MemoryBeforeBuild.json') -Encoding UTF8
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
$started=[DateTimeOffset]::UtcNow.ToString('o')
& (Join-Path $root 'tools/build_workbook/Build-Workbook.ps1') -OutputPath $output -FormulaImageDirectory 'docs/regression/MainCleanRebuild_2026-10-28_Run01/FreshBuild01/FormulaImages'
$owner=Get-Content -LiteralPath (Join-Path (Split-Path -Parent $output) 'BuildOwnership.json') -Raw|ConvertFrom-Json
$ownedExcelProcessId=[int]$owner.PID;$ownedExcelStartTicks=[long]$owner.StartTicksUTC
[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
$watch=[Diagnostics.Stopwatch]::StartNew();$absent=$false
do{try{$p=Get-Process -Id $ownedExcelProcessId -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ownedExcelStartTicks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
if(-not$absent){throw 'Build Excel still exists after cleanup'}
if((Get-FileHash -LiteralPath $main).Hash-cne$before.MainSHA256 -or (Get-FileHash -LiteralPath $heavy).Hash-cne$before.HeavySHA256){throw 'Published workbook changed during isolated build'}
[ordered]@{Status='FRESH_SOURCE_BUILD_AND_COMPILE_COMPLETED';CreatedFrom='Excel.Workbooks.Add';StartedUTC=$started;FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o');BookSHA256=(Get-FileHash -LiteralPath $output).Hash;OwnExcelPID=$ownedExcelProcessId;OwnExcelStartTicksUTC=[string]$ownedExcelStartTicks;OwnProcessAbsent=$true;ForceKilled=$false;HeavyOpenedOrChanged=$false;CompileCommand578Passed=$true}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'Build.json') -Encoding UTF8
