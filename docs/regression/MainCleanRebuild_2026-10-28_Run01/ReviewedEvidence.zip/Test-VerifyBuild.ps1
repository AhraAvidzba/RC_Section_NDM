﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет сохранённую чистую сборку, экспортирует настоящий VBA; книгу не сохраняет.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/MainCleanRebuild_2026-10-28_Run01'
$out=Join-Path $scratch 'Native';[void][IO.Directory]::CreateDirectory($out)
$path=Join-Path $PSScriptRoot 'FreshBuild01/RC_Section_NDM.xlsm';$hash=(Get-FileHash -LiteralPath $path).Hash
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCleanBuildOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$checks=New-Object 'System.Collections.Generic.List[object]'
function Test-Check([string]$Name,[bool]$Passed,[object]$Actual){$checks.Add([ordered]@{Name=$Name;Passed=$Passed;Actual=$Actual})}
$app=$null;$book=$null;$project=$null;$component=$null;$code=$null;$cell=$null;$range=$null;$config=$null
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestCleanBuildOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'VerificationOwnership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 $book=$app.Workbooks.Open($path,0,$true);$app.Calculation=-4135
 Test-Check 'ReadonlyReopen' ([bool]$book.ReadOnly) $book.ReadOnly
 $project=$book.VBProject;Test-Check '181NativeComponents' ($project.VBComponents.Count-eq181) $project.VBComponents.Count
 $all=New-Object Text.StringBuilder
 [void]$all.AppendLine('VBA PROJECT EXPORT');[void]$all.AppendLine('Workbook: '+$book.Name);[void]$all.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
 for($i=1;$i-le$project.VBComponents.Count;$i++){
  $component=$project.VBComponents.Item($i);$code=$component.CodeModule;$n=[int]$code.CountOfLines;$body=if($n){[string]$code.Lines(1,$n)}else{''}
  [void]$all.AppendLine('='*100);[void]$all.AppendLine('COMPONENT: '+$component.Name);[void]$all.AppendLine('TYPE: '+$component.Type);[void]$all.AppendLine('LINES: '+$n);[void]$all.AppendLine('='*100);if($n){[void]$all.AppendLine($body)};[void]$all.AppendLine()
  [IO.File]::WriteAllText((Join-Path $out ($component.Name+'.txt')),$body,[Text.Encoding]::UTF8)
 }
 [IO.File]::WriteAllText((Join-Path $out 'VBA_All_Code.txt'),$all.ToString(),[Text.Encoding]::UTF8)
 $config=$book.Worksheets.Item('Config');$range=$book.Names.Item('rngSystemSettings').RefersToRange;$values=$range.Value2;$keys=@{}
 for($r=2;$r-le$values.GetLength(0);$r++){$key=[string]$values[$r,1];if($key -and -not$key.StartsWith('[')){if($keys.ContainsKey($key)){throw ('Duplicate setting '+$key)};$keys[$key]=[ordered]@{Value=$values[$r,2];Row=($range.Row+$r-1)}}}
 foreach($pair in @(@('Mesh.CellGeometry','Contour'),@('Mesh.StepMode','Auto 0.1'),@('Results.SnapshotStorage','Excel'),@('Output.CombinationMode','Worst'))){Test-Check ('Default.'+$pair[0]) ($keys[$pair[0]].Value-ceq$pair[1]) $keys[$pair[0]].Value}
 Test-Check 'NoLegacyOutputSettings' (-not$keys.ContainsKey('Plot.LoadCase')-and-not$keys.ContainsKey('AutoCAD.Export.CombinationID')) ''
 Test-Check 'OutputOrder' ($keys['Output.CombinationMode'].Row+1-eq$keys['General.WorstCombinationCriterion'].Row-and$keys['General.WorstCombinationCriterion'].Row+1-eq$keys['Output.CombinationID'].Row) ''
 foreach($name in @('rngNDMSectionGeometry','rngNDMSectionProperties','rngNDMMaterialDiagrams','rngNDMSectionContours','rngNDMElementResults','rngNDMElementGeometry','rngNDMSectionAnnotations')){$cell=$book.Names.Item($name).RefersToRange;Test-Check ('Clean.'+$name) ([string]$cell.Offset(1,0).Value2-eq'') $cell.Address()}
 $loads=$book.Names.Item('rngLoadCombinations').RefersToRange;$v=$loads.Value2;$nonempty=0
 for($r=2;$r-le$v.GetLength(0);$r++){foreach($c in 1..4){if([string]$v[$r,$c]-ne''){$nonempty++}}}
 Test-Check 'NoUserLoadsOrIDs' ($nonempty-eq0) $nonempty
 $tokens=$null;$parseErrors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1'),[ref]$tokens,[ref]$parseErrors)
 if($parseErrors.Count){throw 'Catalog parse error'}
 $assign=@($ast.FindAll({param($n)$n-is[Management.Automation.Language.AssignmentStatementAst]-and$n.Left.Extent.Text-ceq'$validationLists'-and$n.Right.Extent.Text-match'"Mesh.CellGeometry"\s*='},$true))
 if($assign.Count-ne1){throw 'Expected one source validation dictionary'}
 $lambda=[char]0x03bb;$mu=[char]0x03bc;$lists=Invoke-Expression $assign[0].Right.Extent.Text
 $lists['Geometry.Type']=@('Circle','Rectangles','PointedSection','HollowRectangle')
 foreach($key in ($lists.Keys|Sort-Object)){
  if(-not$keys.ContainsKey($key)){throw ('List key missing '+$key)}
  $cell=$config.Cells.Item($keys[$key].Row,2);$saved=$cell.Formula;$options=@($lists[$key])
  try{
   Test-Check ('List.Type.'+$key) ($cell.Validation.Type-eq3 -and $cell.Validation.InCellDropdown) ([string]$cell.Validation.Formula1)
   foreach($option in $options){$cell.Value2=[string]$option;Test-Check ('List.Accept.'+$key+'.'+$option) ([bool]$cell.Validation.Value) ''}
   foreach($bad in @('TEST_INVALID_OPTION_9D37',($options-join','),($options-join';'))){$cell.Value2=[string]$bad;Test-Check ('List.Reject.'+$key+'.'+$bad) (-not[bool]$cell.Validation.Value) ''}
  }finally{$cell.Formula=$saved}
 }
 Test-Check 'DirectCombinationList' ($config.Cells.Item($keys['Output.CombinationID'].Row,2).Validation.Formula1-ceq'=$H$71:$H$100') $config.Cells.Item($keys['Output.CombinationID'].Row,2).Validation.Formula1
 Test-Check 'DirectProfileList' ($config.Range('L71').Validation.Formula1-ceq'=$J$39:$M$39') $config.Range('L71').Validation.Formula1
 foreach($row in @(4,11)){$style=@();foreach($col in 1..5){$cell=$config.Cells.Item($row,$col);$style+=,[ordered]@{Bold=$cell.Font.Bold;Fill=$cell.Interior.Color;FontSize=$cell.Font.Size;BorderRight=$cell.Borders.Item(10).LineStyle}};if($row-eq4){$mainStyle=$style|ConvertTo-Json -Compress}else{Test-Check 'SectionHeaderStyle' (($style|ConvertTo-Json -Compress)-ceq$mainStyle) ''}}
 foreach($name in @('rngCircleGeometry','rngRectanglesGeometry','rngPointedSectionGeometry','rngHollowRectangleGeometry')){$table=$book.Names.Item($name).RefersToRange;$cell=$table.Worksheet.Cells.Item($table.Row-1,$table.Column);Test-Check ('SectionHeading.'+$name) ([bool]$cell.Characters(1,1).Font.Bold-and$cell.RowHeight-gt15) ([string]$cell.Value2)}
 Test-Check 'FiveSheetOrder' ((($book.Worksheets|ForEach-Object {$_.Name})-join'|') -ceq 'Config|Сечения|Справка|Расчет|Results') ''
 $checks|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'NativeChecks.json') -Encoding UTF8
 $failed=@($checks|Where-Object {-not$_.Passed})
 [ordered]@{Passed=($failed.Count-eq0);Checks=$checks.Count;Failed=$failed;ReopenedSavedBook=$true;SourceSHA256=$hash;NativeComponents=$project.VBComponents.Count;SettingsKeys=$keys.Count;PermanentLists=$lists.Count;CleanResultsAndLoads=$true;NoBookSaveOrVBAExecution=$true}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot 'NativeAcceptance.json') -Encoding UTF8
 if($failed.Count){throw ('Native checks failed: '+($failed.Name-join', '))}
 Write-Output ('NATIVE_ACCEPTED: '+$checks.Count+' checks; '+$lists.Count+' dropdowns; 181 components')
}finally{
 $table=$null;$loads=$null;$cell=$null;$range=$null;$config=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'VerificationClosure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
if((Get-FileHash -LiteralPath $path).Hash-cne$hash){throw 'Readonly book changed'}
