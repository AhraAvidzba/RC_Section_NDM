"""ДЛЯ ТЕСТОВ: извлекает весь пользовательский текст Справки без запуска Excel."""
from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile

E = Path(__file__).resolve().parent
ROOT = E.parents[2]
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'

def TestMain():
    """ДЛЯ ТЕСТОВ: сохраняет исходные книги и полный построчный инвентарь для редакторского обзора."""
    backup = E/'Before'
    backup.mkdir()
    records = []
    for rel in ['tools/build_workbook/SettingsCatalog.ps1', 'workbook/output/RC_Section_NDM.xlsm',
                'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm', 'workbook/output/VBA_All_Code.txt']:
        source = ROOT/rel
        target = backup/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source,target)
        records.append({'Path': rel, 'SHA256': hashlib.sha256(source.read_bytes()).hexdigest().upper()})
    with zipfile.ZipFile(ROOT/'workbook/output/RC_Section_NDM.xlsm') as z:
        strings = [''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        sheet = ET.fromstring(z.read('xl/worksheets/sheet3.xml'))
        rows = []
        for row in sheet.find(NS+'sheetData'):
            cells = []
            for c in row:
                value = c.findtext(NS+'v')
                text = strings[int(value)] if c.get('t') == 's' else ''.join(c.find(NS+'is').itertext()) if c.get('t') == 'inlineStr' else ''
                if text:
                    cells.append({'Cell': c.get('r'), 'Text': text})
            if cells: rows.append({'Row': int(row.get('r')), 'Cells': cells})
    (E/'Inputs.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    (E/'HelpRows.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    chunks = []
    for i in range(0,len(rows),160):
        path = E/f'Read_{i//160+1:02}.txt'
        selected = rows[i:i+160]
        path.write_text('\n'.join(' | '.join(c['Cell']+': '+c['Text'] for c in r['Cells']) for r in selected),encoding='utf-8')
        chunks.append({'Path': path.name, 'FirstRow': selected[0]['Row'], 'LastRow': selected[-1]['Row']})
    print(json.dumps({'NonemptyRows':len(rows),'TextCells':sum(len(r['Cells']) for r in rows),'Chunks':chunks}))

if __name__ == '__main__':
    TestMain()
