"""ДЛЯ ТЕСТОВ: независимая приёмка опубликованных текстов, исходника и первичных native proofs."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

E = Path(__file__).resolve().parent
ROOT = E.parents[2]

def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает доказательство без потери Unicode."""
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: фиксирует фактические байты опубликованного файла."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()

def TestMain():
    """ДЛЯ ТЕСТОВ: завершает только документальную цель, не приписывая ей полный расчётный PASS."""
    package=TestJSON(E/'PackageProof02.json')
    native=TestJSON(E/'Native03/NativeBooks.json')
    closure=TestJSON(E/'Native03.Watchdog/Completion.json')
    publication=TestJSON(E/'Publication.json')
    source=TestJSON(E/'SourceChange.json')
    plan=TestJSON(E/'TextPlan.json')
    mapping=TestJSON(E/'CellMap.json')
    assert closure['Passed'] and not closure['Timeout'] and closure['WorkerExitCode']==0
    assert closure['Worker']['State']==closure['Excel']['State']=='Absent'
    assert publication['Passed'] and len(native)==len(package['Books'])==2
    actual=(ROOT/source['Path']).read_bytes()
    assert TestSHA(ROOT/source['Path'])==source['AfterSHA256']
    before=(E/'Before'/source['Path']).read_bytes()
    original=before.decode('utf-8-sig')
    reverse=actual.decode('utf-8-sig')
    restored=set()
    for change in plan:
        if change['Before'] in restored: continue
        restored.add(change['Before'])
        if change['Kind']=='Guide':
            old_lines=[line for line in original.splitlines() if '"'+change['Before']+'"' in line]
            new_lines=[line for line in reverse.splitlines() if '"'+change['After']+'"' in line]
            assert len(old_lines)==len(new_lines)==1
            reverse=reverse.replace(new_lines[0],old_lines[0],1)
        else:
            reverse=reverse.replace('"'+change['After']+'"','"'+change['Before']+'"')
    assert reverse==original, 'Unexpected non-prose build change'
    books=[]
    for book,observed in zip(package['Books'],native):
        published=ROOT/book['RelativeOutput']
        assert TestSHA(published)==book['SHA256']==observed['SHA256']
        assert observed['AllHelpTextCellsCompared']==1317 and observed['NativeComponents']==181 and observed['DocumentComponents']==6
        assert len(observed['TextFit'])==len(mapping)==37 and all(c['Fits'] for c in observed['TextFit'])
        assert observed['MacrosDisabled'] and observed['ReadOnly']
        unchanged=[]
        with zipfile.ZipFile(E/'Before'/book['RelativeOutput']) as old,zipfile.ZipFile(published) as new:
            assert old.namelist()==new.namelist() and new.testzip() is None
            for name in old.namelist():
                if name in book['ChangedParts']:continue
                assert old.read(name)==new.read(name), 'Unexpected part changed '+name
                unchanged.append(name)
            assert 'xl/vbaProject.bin' in unchanged
        assert unchanged==book['PreservedParts']
        books.append({'Path':book['RelativeOutput'],'SHA256':book['SHA256'],'TotalZIPParts':len(unchanged)+3,
                      'PreservedParts':len(unchanged),'HelpCellsCompared':1317,'HelpChanges':37,'DependentConfigChanges':1,
                      'VBA181Unchanged':True,'InputsResultsAndSchemePreserved':True,'TextFits':True})
    dump=package['AllCodeUnchanged']
    assert TestSHA(ROOT/dump['Path'])==dump['SHA256']
    behavior=[]
    for path,needles in [
        ('src/Excel/CAutoCADSectionModelImporter.cls',['Set ImportFromDocument = ImportConfiguredModelSpace(document.ModelSpace, settings, units, document.Layers)']),
        ('src/Excel/modAutoCADStressExport.bas',['Set ms = doc.ModelSpace','Set ms = document.ModelSpace'])]:
        lines=(ROOT/path).read_text(encoding='utf-8-sig').splitlines()
        hits=[]
        for needle in needles:
            found=[{'Line':i+1,'Code':line.strip()} for i,line in enumerate(lines) if needle in line]
            assert len(found)==1
            hits.extend(found)
        behavior.append({'Path':path,'SHA256':TestSHA(ROOT/path),'VerifiedLines':hits})
    (E/'AutoCADSpaceEvidence.json').write_text(json.dumps({'ImporterAndBothExportersUseModelSpace':True,'ProductionSources':behavior,
        'ImportPaperSpaceSupported':False,'ExportDestinationChangesWithActiveLayout':False,
        'NewCADTestNeeded':False,'Reason':'Только документация; VBA побайтно совпадает с ранее проверенной версией c8c33c66.'},ensure_ascii=False,indent=2),encoding='utf-8')
    result={'Passed':True,'Scope':'Полная редакторская проверка текста Справки и описание ModelSpace',
        'EditorialReview':TestJSON(E/'EditorialReview.json'),'SourceOnly31TextLiteralsAnd5RowCountArguments':True,
        'SourceSHA256':source['AfterSHA256'],'NativeHelpTextsPerBook':1317,'NativeComponentsPerBook':181,
        'Books':books,'AllCode':dump,'OwnProcessClosure':closure,'NoNewFullRun':True,
        'CalculationOrNormativeAlgorithmsChanged':False,'FullCalculationAcceptanceClaimed':False,
        'FirstAttempt':'Native01: PS5.1 helper без UTF8 BOM; исправлена кодировка, собственный Excel вышел нормально.',
        'SecondAttempt':'Native02: тексты B874 и B1286 не помещались; сокращены без изменения высот/шрифта.',
        'AcceptedAttempt':'Native03: все тексты и измерения приняты; оба собственных процесса отсутствуют.'}
    (E/'FinalReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'Passed':True,'Books':books,'SourceReversalExact':True,'AllCodeUnchanged':True}))

if __name__=='__main__':
    TestMain()
