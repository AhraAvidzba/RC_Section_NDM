# ДЛЯ ТЕСТОВ: публикует две проверенные книги с резервными копиями; чужие файлы не меняет.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$accept=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Native03.Watchdog/Completion.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $accept.Passed -or $accept.Excel.State -ne 'Absent' -or $accept.Worker.State -ne 'Absent'){throw 'Successful native read and exact own closure required'}
$source=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'SourceChange.json') -Raw -Encoding UTF8|ConvertFrom-Json
if((Get-FileHash -LiteralPath (Join-Path $root $source.Path)).Hash -cne $source.AfterSHA256){throw 'Build source changed after acceptance'}
$proof=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PackageProof02.json') -Raw -Encoding UTF8|ConvertFrom-Json
if((Get-FileHash -LiteralPath (Join-Path $root $proof.AllCodeUnchanged.Path)).Hash -cne $proof.AllCodeUnchanged.SHA256){throw 'AllCode changed'}
$stage=Join-Path $PSScriptRoot 'PublicationStage';$backup=Join-Path $PSScriptRoot 'PublicationBackups'
if((Test-Path -LiteralPath $stage) -or (Test-Path -LiteralPath $backup)){throw 'Fresh publication directories required'}
[void][IO.Directory]::CreateDirectory($stage);[void][IO.Directory]::CreateDirectory($backup)
$records=@()
foreach($book in $proof.Books){
 $target=Join-Path $root $book.RelativeOutput
 if((Get-FileHash -LiteralPath $target).Hash -cne $book.BeforeSHA256){throw ('User modified the output: '+$target)}
 if((Get-FileHash -LiteralPath $book.Path).Hash -cne $book.SHA256){throw 'Private accepted book changed'}
 $lock=[IO.File]::Open($target,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$lock.Dispose()
 $staged=Join-Path $stage $book.ID;Copy-Item -LiteralPath $book.Path -Destination $staged
 $records+=,[ordered]@{ID=$book.ID;Path=$book.RelativeOutput;Destination=$target;Stage=$staged;Backup=(Join-Path $backup $book.ID);BeforeSHA256=$book.BeforeSHA256;AfterSHA256=$book.SHA256}
}
foreach($record in $records){
 if((Get-FileHash -LiteralPath $record.Destination).Hash -cne $record.BeforeSHA256){throw 'Output changed immediately before publication'}
 [IO.File]::Replace($record.Stage,$record.Destination,$record.Backup)
 if((Get-FileHash -LiteralPath $record.Destination).Hash -cne $record.AfterSHA256 -or (Get-FileHash -LiteralPath $record.Backup).Hash -cne $record.BeforeSHA256){throw 'Atomic publication verification failed'}
}
[ordered]@{Passed=$true;Status='PUBLISHED_HELP_TEXT_ONLY';Files=$records;AllCodeUnchanged=$proof.AllCodeUnchanged;PublishedUTC=[DateTimeOffset]::UtcNow.ToString('o');NoFullRunStarted=$true}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Publication.json') -Encoding UTF8
$records|Select-Object Path,AfterSHA256|ConvertTo-Json
