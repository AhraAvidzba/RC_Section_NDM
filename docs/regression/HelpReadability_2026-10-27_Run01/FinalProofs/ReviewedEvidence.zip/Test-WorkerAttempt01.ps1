# ==========================================================================
# ДЛЯ ТЕСТОВ: readonly-проверка всей Справки и 181 VBA-компонента, без расчёта.
# ==========================================================================
param([Parameter(Mandatory=$true)][string]$PlanJson,[Parameter(Mandatory=$true)][string]$EvidenceDirectory)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne 5){throw 'PS5.1 required'}
$directory=[IO.Path]::GetFullPath($EvidenceDirectory)
[void][IO.Directory]::CreateDirectory($directory)
$homeDirectory=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$plan=Get-Content -LiteralPath $PlanJson -Raw -Encoding UTF8|ConvertFrom-Json
$rows=Get-Content -LiteralPath (Join-Path $homeDirectory 'HelpRows.json') -Raw -Encoding UTF8|ConvertFrom-Json
$mapping=Get-Content -LiteralPath (Join-Path $homeDirectory 'CellMap.json') -Raw -Encoding UTF8|ConvertFrom-Json
$expected=@{};foreach($row in $rows){foreach($cell in $row.Cells){$expected[$cell.Cell]=[string]$cell.Text}}
foreach($cell in $mapping){$expected[$cell.Cell]=[string]$cell.After}

# -------------------- ДЛЯ ТЕСТОВ --------------------
# Пишет самостоятельные доказательства до опасных COM вызовов.
function Test-Proof([string]$Name,$Value){
 [IO.File]::WriteAllText((Join-Path $directory $Name),(ConvertTo-Json -InputObject $Value -Depth 12),[Text.UTF8Encoding]::new($true))
}
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class TestHelpExcelOwner { [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint pid); }
'@
$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$ram=[double]$memory.AvailableMBytes/1024
$commit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
Test-Proof 'MemoryBeforeExcel.json' ([ordered]@{RAMGiB=$ram;CommitGiB=$commit;RequiredRAMGiB=8;RequiredCommitGiB=14})
if($ram -lt 8 -or $commit -lt 14 -or $null -eq $memory -or [double]$memory.CommitLimit -le 0){throw '8RAM/14commit reserve required'}
$before=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object {$_.Id})
$app=$null;$book=$null;$owner=$null;$passed=$false;$fail=$null;$books=@()
$bitmap=New-Object Drawing.Bitmap(1,1);$bitmap.SetResolution(96,96)
$graphics=[Drawing.Graphics]::FromImage($bitmap)
try{
 $app=New-Object -ComObject Excel.Application
 $ownID=[uint32]0
 [void][TestHelpExcelOwner]::GetWindowThreadProcessId([IntPtr][long]$app.Hwnd,[ref]$ownID)
 $owner=Get-Process -Id $ownID
 if($before -contains $ownID -or $owner.ProcessName -ine 'EXCEL'){throw 'A fresh own Excel is required'}
 $ticks=$owner.StartTime.ToUniversalTime().Ticks;$null=$owner.Handle
 Test-Proof 'Ownership.json' ([ordered]@{PID=$ownID;StartTicksUTC=[string]$ticks;BeforeExcelPIDs=$before;OnlyOwnInstance=$true})
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AskToUpdateLinks=$false;$app.AutomationSecurity=3
 foreach($case in $plan.Books){
  $path=[IO.Path]::GetFullPath([string]$case.Path)
  if((Get-FileHash -LiteralPath $path).Hash -cne [string]$case.SHA256){throw 'Book changed before native read'}
  $book=$app.Workbooks.Open($path,0,$true)
  if(-not $book.ReadOnly -or $app.Workbooks.Count -ne 1 -or [string]$book.FullName -cne $path){throw 'Exact own readonly book required'}
  if(-not $book.HasVBProject -or $book.VBProject.VBComponents.Count -ne 181){throw 'Native component inventory differs'}
  $documents=0;foreach($component in $book.VBProject.VBComponents){if($component.Type -eq 100){$documents++}}
  if($documents -ne 6){throw 'Six native document components required'}
  $sheet=$book.Worksheets.Item('Справка')
  $matrix=$sheet.Range('A1:F1531').Value2
  foreach($address in $expected.Keys){
   if($address -notmatch '^([A-F])([0-9]+)$'){throw 'Unexpected Help address'}
   $column=[int][char]$Matches[1]-[int][char]'A'+1;$rowNumber=[int]$Matches[2]
   if([string]$matrix[$rowNumber,$column] -cne [string]$expected[$address]){throw ('Native Help mismatch '+$case.ID+'/'+$address)}
  }
  $fit=@()
  foreach($change in $mapping){
   $cell=$sheet.Range([string]$change.Cell);$hidden=[bool]$cell.EntireRow.Hidden
   if($hidden){$cell.EntireRow.Hidden=$false}
   $width=[double]$cell.MergeArea.Width;$height=[double]$cell.RowHeight
   $style=[Drawing.FontStyle]::Regular;if($cell.Font.Bold){$style=$style -bor [Drawing.FontStyle]::Bold}
   $font=New-Object Drawing.Font([string]$cell.Font.Name,[single]$cell.Font.Size,$style)
   try{$size=$graphics.MeasureString([string]$cell.Value2,$font,[single](($width-4)*96/72))}finally{$font.Dispose()}
   $required=[double]$size.Height*72/96
   $fit+=,[ordered]@{Cell=$change.Cell;WidthPt=$width;RowHeightPt=$height;MeasuredTextHeightPt=$required;Fits=($required -le ($height+1));Wrap=[bool]$cell.WrapText;Text=[string]$cell.Value2}
   if($hidden){$cell.EntireRow.Hidden=$true}
  }
  $books+=,[ordered]@{ID=$case.ID;Path=$path;SHA256=$case.SHA256;AllHelpTextCellsCompared=$expected.Count;NativeComponents=181;DocumentComponents=$documents;ChangedCells=$mapping.Count;TextFit=$fit;MacrosDisabled=$true;ReadOnly=$true}
  $book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book);$book=$null
  if((Get-FileHash -LiteralPath $path).Hash -cne [string]$case.SHA256){throw 'Native read changed the file'}
 }
 Test-Proof 'NativeBooks.json' $books
 if(@($books|ForEach-Object {$_.TextFit}|Where-Object {-not $_.Fits}).Count){throw 'Changed Help text does not fit its preserved row; review text, do not shrink the font'}
 $passed=$true
}catch{$fail=$_.Exception.ToString();Test-Proof 'Failure.json' ([ordered]@{Error=$fail});throw}
finally{
 if($null -ne $book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 if($null -ne $app -and $null -ne $owner){$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 $graphics.Dispose();$bitmap.Dispose();$component=$null;$sheet=$null;$cell=$null;$matrix=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 Test-Proof 'Acceptance.json' ([ordered]@{Passed=$passed;Books=$books.Count;AllHelpCellsPerBook=$expected.Count;NoCalculation=$true;NoImport=$true;NoSave=$true;Error=$fail})
}
