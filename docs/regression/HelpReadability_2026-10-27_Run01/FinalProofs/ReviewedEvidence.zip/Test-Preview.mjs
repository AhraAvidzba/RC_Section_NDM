// ДЛЯ ТЕСТОВ: только чтение XLSM; экспорт книги через XLSX API не выполняется.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {FileBlob, SpreadsheetFile} from '@oai/artifact-tool';
const here = path.dirname(fileURLToPath(import.meta.url));
const input = process.argv[2] || path.join(here, 'Before/workbook/output/RC_Section_NDM.xlsm');
const suffix = process.argv[3] || 'Before';
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(input));
if (suffix === 'Before') {
  const capability = workbook.help('xlsm VBA preservation', {include:'index,notes', maxChars:1800});
  await fs.writeFile(path.join(here, 'ArtifactCapability.txt'), capability.ndjson || JSON.stringify(capability));
}
for (const [name, range] of [['AutoCAD','A1:F7'], ['Contour','A845:F853'], ['Export','A51:F60'], ['MeshLevels','A872:F881'], ['Plot','A1285:F1288']]) {
  const preview = await workbook.render({sheetName:'Справка', range, scale:1.3, format:'png'});
  await fs.writeFile(path.join(here, `${suffix}_${name}.png`), new Uint8Array(await preview.arrayBuffer()));
}
console.log(JSON.stringify({ReadOnly:true, Input:input, Previews:suffix, WorkbookExport:false}));
