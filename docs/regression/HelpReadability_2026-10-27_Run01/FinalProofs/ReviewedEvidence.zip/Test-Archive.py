"""ДЛЯ ТЕСТОВ: компактно сохраняет все первичные проверки документационной задачи."""
from pathlib import Path
import hashlib
import json
import zipfile

E=Path(__file__).resolve().parent
ROOT=E.parents[2]

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: точный SHA для архива и первичного файла."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()

def TestMain():
    """ДЛЯ ТЕСТОВ: исключает книги, node_modules junction и чужие outputs из доказательств."""
    review=json.loads((E/'FinalReview.json').read_text(encoding='utf-8'))
    assert review['Passed']
    final=E/'FinalProofs';final.mkdir(exist_ok=True)
    selected=set()
    for pattern in ['*.json','*.txt','Test-*.py','Test-*.mjs','Test-*.ps1','*.png']:
        selected.update(p for p in E.glob(pattern) if p.is_file())
    for directory in ['NativePlan','Native01','Native01.Watchdog','Native02','Native02.Watchdog','Native03','Native03.Watchdog']:
        selected.update(p for p in (E/directory).rglob('*') if p.is_file())
    selected.add(E/'Before/tools/build_workbook/SettingsCatalog.ps1')
    extras=[ROOT/'docs/regression/GeometryFinalization_2026-10-26_Run01/LowMemoryPerformancePackagePlan/TestPrepareVbaOnlyPerformanceBook.py',
            ROOT/'docs/regression/GeometryFinalization_2026-10-26_Run01/PostTransferNativePlan01/TestPreparePreservedReady01.py']
    entries=[]
    target=final/'ReviewedEvidence.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(selected):
            name=path.relative_to(E).as_posix();z.write(path,name)
            entries.append({'Path':name,'Bytes':path.stat().st_size,'SHA256':TestSHA(path)})
        for path in extras:
            name='Dependencies/'+path.name;z.write(path,name)
            entries.append({'Path':name,'OriginalPath':path.relative_to(ROOT).as_posix(),'Bytes':path.stat().st_size,'SHA256':TestSHA(path)})
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None and len(z.namelist())==len(entries)
        for item in entries:assert hashlib.sha256(z.read(item['Path'])).hexdigest().upper()==item['SHA256']
    manifest={'Path':target.name,'SHA256':TestSHA(target),'Bytes':target.stat().st_size,'Files':entries,'AllArchiveMembersReadAndVerified':True}
    (final/'ArchiveManifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    requirements=[
        ('Contour: автоматическое построение без ручного описания каждого элемента','TextPlan.json / B850'),
        ('Проверена понятность всего текста Справки','EditorialReview.json / HelpRows.json / Read_01…08.txt'),
        ('Импорт только из ModelSpace подтверждён актуальным кодом','AutoCADSpaceEvidence.json'),
        ('Оба варианта экспорта всегда в ModelSpace подтверждены кодом','AutoCADSpaceEvidence.json'),
        ('Импорт с листов и экспорт при активном листе явно описаны в нужном разделе','CellMap.json / A2:A3, A52:A53'),
        ('Сборка и зависимое пояснение Config синхронизированы','SourceRuntime.json / SourceChange.json / PackageProof02.json'),
        ('Обе книги опубликованы; файлы и резервные копии сверены','Publication.json / FinalReview.json'),
        ('Все 1317 текстов каждой книги проверены в Excel','Native03/NativeBooks.json'),
        ('Изменённые тексты читаемы в прежних строках','Native03/NativeBooks.json / Final_*.png'),
        ('VBA, AllCode, результаты, данные и схема сохранены','PackageProof02.json / FinalReview.json'),
        ('Ссылки, раскладка и формулы сохранены','PackageProof02.json / SourceChange.json'),
        ('Собственные Excel/PowerShell закрыты штатно','Native03.Watchdog/Completion.json'),
        ('Неуспешные служебные попытки не скрыты','Native01 / Native02 / FinalReview.json'),
        ('Отчёт и PROGRESS сохранены','docs/reports/HelpReadability_2026-10-27.md / docs/geometry_refactor/PROGRESS.md')]
    processed={'Status':'PASS_DOCUMENTATION_SCOPE_ONLY','Requirements':[{'Requirement':r,'Evidence':p,'Verified':True} for r,p in requirements],
               'PublishedBooks':review['Books'],'SourceSHA256':review['SourceSHA256'],'AllCode':review['AllCode'],
               'ArchiveSHA256':manifest['SHA256'],'NoFullCalculationPassClaimed':True,'NoNewFullRun':True}
    (final/'Processed.json').write_text(json.dumps(processed,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'ArchiveFiles':len(entries),'ArchiveBytes':target.stat().st_size,'SHA256':manifest['SHA256']}))

if __name__=='__main__':
    TestMain()
