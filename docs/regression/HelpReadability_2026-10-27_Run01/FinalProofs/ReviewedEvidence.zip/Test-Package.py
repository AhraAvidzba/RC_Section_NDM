"""ДЛЯ ТЕСТОВ: правит только строковые ссылки Справки; всё VBA и данные сохраняет побайтно."""
from pathlib import Path
import hashlib
import argparse
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
import zipfile

E = Path(__file__).resolve().parent
ROOT = E.parents[2]
OLD = ROOT/'docs/regression/GeometryFinalization_2026-10-26_Run01'
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
SST, HELP = 'xl/sharedStrings.xml', 'xl/worksheets/sheet3.xml'

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: фиксирует точный файл, а не имя или дату."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()

def TestLoad(path, name):
    """ДЛЯ ТЕСТОВ: импортирует существующие raw ZIP функции без запуска старых сценариев."""
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode=True
    spec.loader.exec_module(module)
    return module

def TestValues(book, part=HELP):
    """ДЛЯ ТЕСТОВ: читает все строки справки, сохраняя фактические адреса."""
    strings=[''.join(x.itertext()) for x in ET.fromstring(book.read(SST))]
    return {c.get('r'):strings[int(c.findtext(NS+'v'))] for c in ET.fromstring(book.read(part)).iter(NS+'c') if c.get('t')=='s'}

def TestPatch(book, mapping, baseline):
    """ДЛЯ ТЕСТОВ: добавляет SST записи вместо глобальной замены общих строк Config/Results."""
    shared, raw = book.read(SST), book.read(HELP)
    original_si=re.findall(rb'<si\b[^>]*>.*?</si>',shared,re.S)
    root=ET.fromstring(shared)
    assert len(original_si)==len(root)==int(root.get('uniqueCount'))
    strings=[''.join(x.itertext()) for x in root]
    old_values=TestValues(book)
    appended=[];changes=[];result=raw
    for row in mapping:
        address, after=row['Cell'],row['After']
        before=baseline[address]
        assert old_values[address]==before and before!=after
        index=len(strings)+len(appended)
        appended.append(('<si><t xml:space="preserve">'+escape(after)+'</t></si>').encode('utf-8'))
        hits=list(re.finditer(rb'<c\b(?=[^>]*\br="'+address.encode()+rb'")[^>]*>.*?</c>',result,re.S))
        assert len(hits)==1
        cell=hits[0].group()
        matches=list(re.finditer(rb'<v>([0-9]+)</v>',cell))
        assert len(matches)==1 and strings[int(matches[0][1])]==before
        match=matches[0]
        new_cell=cell[:match.start(1)]+str(index).encode()+cell[match.end(1):]
        result=result[:hits[0].start()]+new_cell+result[hits[0].end():]
        changes.append({'Part':HELP,'Cell':address,'Before':before,'After':after,'OldCell':cell,'NewCell':new_cell})
    reverse=result
    for c in reversed(changes):
        assert reverse.count(c['NewCell'])==1
        reverse=reverse.replace(c['NewCell'],c['OldCell'],1)
    assert reverse==raw, 'Changed formatting, links or other sheet content'
    # Подпись Steel.R.SLS(II) служит источником и для Config, и для вводной строки Справки.
    # Обновляем её зависимую ячейку одновременно, чтобы полная сборка давала ту же книгу.
    config='xl/worksheets/sheet1.xml'
    plan=json.loads((E/'TextPlan.json').read_text(encoding='utf-8'))
    material=next(c for c in plan if c['Cells']==['B1506'])
    config_hits=[a for a,t in TestValues(book,config).items() if t==material['Before']]
    assert len(config_hits)==1
    address=config_hits[0]
    config_raw=book.read(config)
    hits=list(re.finditer(rb'<c\b(?=[^>]*\br="'+address.encode()+rb'")[^>]*>.*?</c>',config_raw,re.S))
    assert len(hits)==1
    cell=hits[0].group()
    hit=re.search(rb'<v>([0-9]+)</v>',cell)
    assert strings[int(hit[1])]==material['Before']
    index=len(strings)+len(appended)
    appended.append(('<si><t xml:space="preserve">'+escape(material['After'])+'</t></si>').encode('utf-8'))
    new_cell=cell[:hit.start(1)]+str(index).encode()+cell[hit.end(1):]
    config_new=config_raw[:hits[0].start()]+new_cell+config_raw[hits[0].end():]
    assert config_new.replace(new_cell,cell,1)==config_raw
    changes.append({'Part':config,'Cell':address,'Before':material['Before'],'After':material['After']})
    header=re.search(rb'<sst\b[^>]*>',shared).group()
    new_header,n=re.subn(rb'\buniqueCount="[0-9]+"',b'uniqueCount="'+str(len(original_si)+len(appended)).encode()+b'"',header)
    assert n==1
    new_shared=shared.replace(header,new_header,1).replace(b'</sst>',b''.join(appended)+b'</sst>',1)
    assert re.findall(rb'<si\b[^>]*>.*?</si>',new_shared,re.S)[:len(original_si)]==original_si
    assert ET.fromstring(new_shared).get('count')==root.get('count')
    for c in changes:
        c.pop('OldCell',None);c.pop('NewCell',None)
    return {HELP:result,SST:new_shared,config:config_new},changes

def TestMain():
    """ДЛЯ ТЕСТОВ: проверяет все ZIP части, готовые результаты и точность карты source→book."""
    helper=TestLoad(OLD/'LowMemoryPerformancePackagePlan/TestPrepareVbaOnlyPerformanceBook.py','TestRawZIP')
    pack=TestLoad(OLD/'PostTransferNativePlan01/TestPreparePreservedReady01.py','TestXMLZIP')
    parser=argparse.ArgumentParser()
    parser.add_argument('--label',default='Packages02')
    parser.add_argument('--proof',default='PackageProof02.json')
    args=parser.parse_args()
    assert re.fullmatch(r'Packages[0-9]+',args.label)
    inputs=json.loads((E/'Inputs.json').read_text(encoding='utf-8'))
    mapping=json.loads((E/'CellMap.json').read_text(encoding='utf-8-sig'))
    rows=json.loads((E/'HelpRows.json').read_text(encoding='utf-8'))
    baseline={c['Cell']:c['Text'] for row in rows for c in row['Cells']}
    assert len({r['Cell'] for r in mapping})==len(mapping)
    source=json.loads((E/'SourceChange.json').read_text(encoding='utf-8'))
    assert TestSHA(ROOT/source['Path'])==source['AfterSHA256']
    proof=[]
    for identity,rel in [('Main','workbook/output/RC_Section_NDM.xlsm'),('Saved30','workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm')]:
        base=E/'Before'/rel
        expected=next(r['SHA256'] for r in inputs if r['Path']==rel)
        assert TestSHA(base)==expected==TestSHA(ROOT/rel), 'Published book changed'
        target=E/args.label/identity/'RC_Section_NDM.xlsm'
        target.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(base) as book:
            changes,texts=TestPatch(book,mapping,baseline)
            records=pack.TestXMLRecords(book,changes)
        old=helper.archive(base)
        pack.TestWritePackage(helper,base,base,target,old,old,records)
        new=helper.archive(target)
        old_entries,new_entries=dict(old['entries']),dict(new['entries'])
        preserved=[]
        with zipfile.ZipFile(base) as before,zipfile.ZipFile(target) as after:
            assert before.namelist()==after.namelist() and after.testzip() is None
            for part in before.namelist():
                if part in changes:
                    assert after.read(part)==changes[part]
                else:
                    assert helper.digest_member(base,part)==helper.digest_member(target,part)
                    assert helper.slice_hash(base,*old['blocks'][part])==helper.slice_hash(target,*new['blocks'][part])
                    x,y=bytearray(old_entries[part]),bytearray(new_entries[part]);x[42:46]=y[42:46]=b'\0'*4
                    assert x==y
                    preserved.append(part)
            expected_values=TestValues(before)
            expected_values.update({r['Cell']:r['After'] for r in mapping})
            assert TestValues(after)==expected_values
            for c in texts:
                assert TestValues(after,c['Part'])[c['Cell']]==c['After']
        proof.append({'ID':identity,'Path':str(target),'RelativeOutput':rel,'SHA256':TestSHA(target),'BeforeSHA256':expected,
                      'ChangedParts':list(changes),'PreservedParts':preserved,'Texts':texts,
                      'SheetExceptChangedStringIndicesByteExact':True,'PriorSharedStringsByteExact':True,
                      'VBAProjectByteExact':True,'ResultsAndInputsAndDrawingsByteExact':True,
                      'AllZIPPartsCRCRead':True,'SourceRuntimeMapExact':True})
    dump=next(r for r in inputs if r['Path']=='workbook/output/VBA_All_Code.txt')
    assert TestSHA(ROOT/dump['Path'])==dump['SHA256']
    (E/args.proof).write_text(json.dumps({'Books':proof,'AllCodeUnchanged':dump},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps([{'ID':r['ID'],'SHA256':r['SHA256'],'ChangedCells':len(r['Texts']),'PreservedParts':len(r['PreservedParts'])} for r in proof]))

if __name__=='__main__':
    TestMain()
