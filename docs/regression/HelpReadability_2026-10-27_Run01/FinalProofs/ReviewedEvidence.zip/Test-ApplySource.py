"""ДЛЯ ТЕСТОВ: применяет только согласованную карту прозы к источнику сборки."""
from pathlib import Path
import hashlib
import json
import re

E = Path(__file__).resolve().parent
ROOT = E.parents[2]

def TestMain():
    """ДЛЯ ТЕСТОВ: запрещает замену неизвестного исходника и сохраняет CRLF/BOM."""
    relative = 'tools/build_workbook/SettingsCatalog.ps1'
    path, backup = ROOT/relative, E/'Before'/relative
    current = path.read_bytes()
    raw = backup.read_bytes()
    if current != raw:
        previous=json.loads((E/'SourceChange.json').read_text(encoding='utf-8'))
        assert hashlib.sha256(current).hexdigest().upper()==previous['AfterSHA256'], 'Catalog changed outside own patch'
    text = raw.decode('utf-8-sig')
    plan = json.loads((E/'TextPlan.json').read_text(encoding='utf-8'))
    applied = set()
    for c in plan:
        if c['Before'] in applied:
            continue
        applied.add(c['Before'])
        old, new = '"'+c['Before']+'"', '"'+c['After']+'"'
        assert old in text and c['LiteralQuotes'] == '"'
        if c['Kind'] == 'Guide':
            pattern = re.escape(old)+r'(?P<tail>[^\r\n]*)'
            hits = list(re.finditer(pattern, text))
            assert len(hits) == 1
            tail = re.sub(r'\s+-RowCount\s+[0-9]+', '', hits[0]['tail'])
            text = text[:hits[0].start()]+new+tail+' -RowCount '+str(len(c['Cells']))+text[hits[0].end():]
        else:
            text = text.replace(old,new)
    new_raw = (b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b'')+text.encode('utf-8')
    path.write_bytes(new_raw)
    (E/'SourceChange.json').write_text(json.dumps({'Path':relative,
        'BeforeSHA256':hashlib.sha256(raw).hexdigest().upper(),
        'AfterSHA256':hashlib.sha256(new_raw).hexdigest().upper(),
        'UniqueLiteralsChanged':len(applied), 'GuideRowsPreserved':True,
        'OnlyHelpTextAndExplicitExistingRowCountParameter':True},indent=2),encoding='utf-8')

if __name__ == '__main__':
    TestMain()
