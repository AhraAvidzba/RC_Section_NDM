﻿# ДЛЯ ТЕСТОВ: проверяет фактический каталог/разбивку строк в Windows PowerShell 5.1 без Excel.
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne 5){throw 'PS5.1 required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$source=Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors|Out-String)}
. $source
$catalog=@(Get-SettingsInstructionCatalog)
$actual=New-Object 'System.Collections.Generic.List[string]'
foreach($item in $catalog){
 foreach($line in $item.Lines){$actual.Add([string]$line)}
 foreach($table in $item.Tables){foreach($row in $table.Rows){foreach($field in $row){$actual.Add([string]$field)}}}
}
$plan=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'TextPlan.json') -Raw -Encoding UTF8|ConvertFrom-Json
$mapping=@();$proof=@()
foreach($change in $plan){
 $parts=@([string]$change.After)
 if($change.Kind -eq 'Guide'){
  $parts=@(Split-GuideParagraphRows ([string]$change.After) @($change.Cells).Count)
 }else{
  $found=@($actual|Where-Object {$_ -ceq [string]$change.After})
  if(-not $found.Count){throw ('Actual catalog missing text: '+($change.Cells -join ','))}
 }
 if($parts.Count -ne @($change.Cells).Count){throw 'Changed paragraph row count'}
 for($i=0;$i -lt $parts.Count;$i++){$mapping+=,[ordered]@{Cell=$change.Cells[$i];After=[string]$parts[$i]}}
 $proof+=,[ordered]@{Cells=$change.Cells;ActualSourceRuntime=$true;LineCount=$parts.Count;Lengths=@($parts|ForEach-Object {$_.Length})}
}
$mapping|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'CellMap.json') -Encoding UTF8
[ordered]@{Passed=$true;PSVersion=[string]$PSVersionTable.PSVersion;ParseErrors=$errors.Count;CatalogItems=$catalog.Count;Changes=$proof}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'SourceRuntime.json') -Encoding UTF8
