"""Stream one compiled VBA ZIP member into an immutable heavy fixture; no XML/Office/solve.

Non-VBA local ZIP records (compressed bytes, local headers and data descriptors) are copied
verbatim. Their central-directory records change only the required local-record offset.
The deliberately limited helper rejects ZIP64/multidisk/duplicate-member packages.
"""
from pathlib import Path
import argparse, ctypes, hashlib, json, os, struct, time, zipfile

ROOT=Path(__file__).resolve().parents[4]
ALLOWED=(ROOT/'docs/regression').resolve()
VBA='xl/vbaProject.bin'
CHUNK=1024*1024
def memory_observation():
    assert os.name=='nt', 'Native Windows memory observation required'
    class MemoryStatus(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong)for x in ['physical','available','pagefile','available_pagefile','virtual','available_virtual','extended']]
    class PerformanceInfo(ctypes.Structure):
        _fields_=[('cb',ctypes.c_ulong)]+[(x,ctypes.c_size_t)for x in ['commit_total','commit_limit','commit_peak','physical_total','physical_available','system_cache','kernel_total','kernel_paged','kernel_nonpaged','page_size']]+[(x,ctypes.c_ulong)for x in ['handles','processes','threads']]
    memory=MemoryStatus();memory.length=ctypes.sizeof(memory)
    performance=PerformanceInfo();performance.cb=ctypes.sizeof(performance)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)), 'Physical memory observation failed'
    assert ctypes.windll.psapi.GetPerformanceInfo(ctypes.byref(performance),performance.cb), 'Commit observation failed'
    assert performance.page_size>0 and performance.commit_limit>=performance.commit_total
    return {'AvailableRAMGiB':memory.available/1024**3,'AvailableCommitGiB':(performance.commit_limit-performance.commit_total)*performance.page_size/1024**3,
            'MinimumRAMGiB':8,'MinimumCommitGiB':14,'NewExcelOrCAD':False}
def peak_working_set():
    class Counters(ctypes.Structure):
        _fields_=[('cb',ctypes.c_ulong),('faults',ctypes.c_ulong)]+[(x,ctypes.c_size_t)for x in ['peak_working_set','working_set','peak_paged_pool','paged_pool','peak_nonpaged_pool','nonpaged_pool','pagefile','peak_pagefile']]
    value=Counters();value.cb=ctypes.sizeof(value)
    api=ctypes.windll.psapi.GetProcessMemoryInfo;api.argtypes=[ctypes.c_void_p,ctypes.POINTER(Counters),ctypes.c_ulong]
    assert api(ctypes.c_void_p(-1),ctypes.byref(value),value.cb), 'Own peak memory unavailable'
    return value.peak_working_set
def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def file_sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for data in iter(lambda:handle.read(CHUNK),b''):digest.update(data)
    return digest.hexdigest().upper()
def checked_path(path):
    result=Path(path).resolve();assert result.is_relative_to(ALLOWED), 'Inputs/outputs must stay in docs/regression'
    return result
def digest_member(path,name):
    digest=hashlib.sha256()
    with zipfile.ZipFile(path) as book,book.open(name) as source:
        for data in iter(lambda:source.read(CHUNK),b''):digest.update(data)
    return digest.hexdigest().upper()
def slice_hash(path,offset,count):
    digest=hashlib.sha256()
    with path.open('rb') as source:
        source.seek(offset)
        while count:
            data=source.read(min(CHUNK,count));assert data, 'Truncated raw ZIP record'
            digest.update(data);count-=len(data)
    return digest.hexdigest().upper()
def archive(path):
    with zipfile.ZipFile(path) as z:
        infos=z.infolist();assert len({x.filename for x in infos})==len(infos), 'Duplicate ZIP members forbidden'
        assert VBA in z.namelist() and len(infos)<65535
        directory=z.start_dir;comment=z.comment
        offsets=sorted(infos,key=lambda x:x.header_offset)
        blocks={x.filename:(x.header_offset,(offsets[i+1].header_offset if i+1<len(offsets) else directory)-x.header_offset)for i,x in enumerate(offsets)}
    with path.open('rb') as raw:
        raw.seek(path.stat().st_size-22-len(comment));end=raw.read(22+len(comment))
        signature,disk,start_disk,disk_count,total,size,offset,comment_size=struct.unpack('<4s4H2IH',end[:22])
        assert signature==b'PK\x05\x06' and disk==start_disk==0 and disk_count==total==len(infos)
        assert comment_size==len(comment) and offset==directory and offset+size==path.stat().st_size-len(end), 'ZIP64/extra directory records unsupported'
        raw.seek(directory);entries=[]
        for info in infos:
            header=raw.read(46);assert len(header)==46 and header[:4]==b'PK\x01\x02'
            name_len,extra_len,comment_len=struct.unpack_from('<3H',header,28)
            tail=raw.read(name_len+extra_len+comment_len);assert len(tail)==name_len+extra_len+comment_len
            flags=struct.unpack_from('<H',header,8)[0]
            name=tail[:name_len].decode('utf-8' if flags&0x800 else 'cp437')
            assert name==info.filename and struct.unpack_from('<I',header,42)[0]==info.header_offset
            assert info.file_size<0xFFFFFFFF and info.compress_size<0xFFFFFFFF and info.header_offset<0xFFFFFFFF
            assert struct.unpack_from('<H',header,34)[0]==0, 'Multidisk entry forbidden'
            entries.append((name,header+tail))
        assert raw.tell()==directory+size
    return {'infos':infos,'blocks':blocks,'entries':entries,'end':end,'prefix':min(x.header_offset for x in infos)}
def copy_slice(source,target,offset,count):
    source.seek(offset)
    while count:
        block=source.read(min(CHUNK,count));assert block, 'Truncated source ZIP record'
        target.write(block);count-=len(block)
def write_package(base,compiled,output,base_zip,compiled_zip):
    offsets={}
    with base.open('rb') as old,compiled.open('rb') as code,output.open('xb') as target:
        copy_slice(old,target,0,base_zip['prefix'])
        for info in sorted(base_zip['infos'],key=lambda x:x.header_offset):
            name=info.filename;offsets[name]=target.tell()
            source,description=(code,compiled_zip) if name==VBA else (old,base_zip)
            start,count=description['blocks'][name];copy_slice(source,target,start,count)
        central_offset=target.tell();compiled_entries=dict(compiled_zip['entries'])
        for name,record in base_zip['entries']:
            record=bytearray(compiled_entries[VBA] if name==VBA else record)
            assert offsets[name]<0xFFFFFFFF
            struct.pack_into('<I',record,42,offsets[name]);target.write(record)
        central_size=target.tell()-central_offset
        assert central_offset<0xFFFFFFFF and central_size<0xFFFFFFFF
        end=bytearray(base_zip['end']);struct.pack_into('<I',end,12,central_size);struct.pack_into('<I',end,16,central_offset)
        target.write(end)
def compare(base,candidate,base_zip,new_zip):
    assert [x.filename for x in base_zip['infos']]==[x.filename for x in new_zip['infos']], 'ZIP member inventory changed'
    base_entries=dict(base_zip['entries']);new_entries=dict(new_zip['entries']);parts=[]
    with zipfile.ZipFile(base) as old,zipfile.ZipFile(candidate) as new:
        for info in base_zip['infos']:
            name=info.filename
            if name==VBA:continue
            a=hashlib.sha256();b=hashlib.sha256()
            with old.open(name) as left,new.open(name) as right:
                while True:
                    x=left.read(CHUNK);y=right.read(CHUNK)
                    assert x==y, 'Non-VBA uncompressed ZIP bytes changed: '+name
                    if not x:break
                    a.update(x);b.update(y)
            old_offset,old_size=base_zip['blocks'][name];new_offset,new_size=new_zip['blocks'][name]
            assert old_size==new_size
            raw_old=slice_hash(base,old_offset,old_size);raw_new=slice_hash(candidate,new_offset,new_size)
            assert raw_old==raw_new, 'Non-VBA compressed/local ZIP record changed: '+name
            ca=bytearray(base_entries[name]);cb=bytearray(new_entries[name]);ca[42:46]=cb[42:46]=b'\0'*4
            assert ca==cb, 'Non-VBA directory metadata changed beyond physical offset: '+name
            parts.append({'Part':name,'Bytes':info.file_size,'SHA256':a.hexdigest().upper(),'RawLocalZipBytes':old_size,
                          'RawLocalZipSHA256':raw_old,'RawLocalRecordIdentical':True,'CentralMetadataIdenticalExceptOffset':True})
        assert new.testzip() is None, 'Output CRC validation failed'
    return parts

def main():
    started=time.perf_counter()
    p=argparse.ArgumentParser();p.add_argument('--base-workbook',required=True);p.add_argument('--expected-base-sha',required=True)
    p.add_argument('--compiled-workbook',required=True);p.add_argument('--expected-compiled-sha',required=True)
    p.add_argument('--compile-acceptance',required=True);p.add_argument('--base-pair-proof',required=True);p.add_argument('--output-directory',required=True)
    args=p.parse_args();base=checked_path(args.base_workbook);compiled=checked_path(args.compiled_workbook)
    acceptance=checked_path(args.compile_acceptance);base_proof=checked_path(args.base_pair_proof);out=checked_path(args.output_directory)
    assert not out.exists(), 'Fresh output directory required'
    assert file_sha(base)==args.expected_base_sha and file_sha(compiled)==args.expected_compiled_sha, 'Base/compiled input SHA mismatch'
    accepted=load(acceptance);pair=load(base_proof);before_inputs=load(acceptance.parent/'Inputs.json');after=load(acceptance.parent/'SourceEqualityAfter181.json')
    assert accepted['Passed'] and accepted['Compiled'] and accepted['SavedPrivateCopy'] and accepted['OwnExcelAbsent']
    assert accepted['SourceEqualityBefore181'] and accepted['SourceEqualityAfter181'] and accepted['Overrides']==3 and accepted['AllOtherComponentsExact']==178
    assert accepted['HelpersInPerformanceCopy']==0 and accepted['FrozenCodeInputs']==179 and not accepted['ChangedInputs']
    assert accepted['SavedPrivateCopySHA256']==args.expected_compiled_sha
    assert after['Passed'] and after['SourceComponents']==175 and after['ExportComponents']==181
    assert len([x for x in after['Components'] if x.get('ExplicitOverride')])==3
    assert pair['CurrentSHA256']==args.expected_base_sha and pair['SharedInputsAndResultsAndLayoutIdentical'] is True
    assert pair['SourceOriginSHA256']=='C456377A98C1C71D5128DA7E958DE1EA8349CF587E9B9BE96A8E5F42785A042E'
    assert before_inputs['SourceSHA256'] in [pair['TemplateSHA256'],args.expected_base_sha], 'Compiled source is not the proven baseline/template'
    code_source=checked_path(before_inputs['SourceWorkbook'])
    assert file_sha(code_source)==before_inputs['SourceSHA256']
    assert digest_member(base,VBA)==digest_member(code_source,VBA)==pair['NewCodeVBAProjectSHA256'], 'Baseline/source VBA identity differs'
    protected=[{'Path':str(x),'SHA256':file_sha(x)}for x in [base,base_proof,compiled,acceptance,acceptance.parent/'Inputs.json',acceptance.parent/'SourceEqualityAfter181.json',code_source]]
    memory=memory_observation();out.mkdir()
    (out/'MemoryBeforePackage.json').write_text(json.dumps(memory,indent=2)+'\n',encoding='utf-8')
    assert memory['AvailableRAMGiB']>=8 and memory['AvailableCommitGiB']>=14, '8RAM/14commit reserve required before package write'
    old_zip=archive(base);code_zip=archive(compiled);output=out/'RC_Section_NDM_Test_1232_30_PerformanceCandidate.xlsm'
    write_package(base,compiled,output,old_zip,code_zip);new_zip=archive(output);parts=compare(base,output,old_zip,new_zip)
    code_sha=digest_member(compiled,VBA);assert digest_member(output,VBA)==code_sha
    for item in protected:assert file_sha(Path(item['Path']))==item['SHA256'], 'Protected input changed during package preparation'
    details={'Status':'PASS_STREAMED_VBA_ONLY_PACKAGE_NATIVE_BENCHMARK_PENDING','Base':str(base),'BaseSHA256':args.expected_base_sha,
             'Compiled':str(compiled),'CompiledSHA256':args.expected_compiled_sha,'Output':str(output),'OutputSHA256':file_sha(output),
             'VBAProjectSHA256':code_sha,'NonVBAPartCount':len(parts),'NonVBAParts':parts,
             'AllNonVbaUncompressedBytesIdentical':True,'AllNonVbaCompressedLocalRecordsIdentical':True,
             'AllNonVbaCentralMetadataIdenticalExceptRequiredOffset':True,'ZIPCRCValid':True,
             'XMLParsed':False,'MatricesTransferredOrRebuilt':False,'CellStylesRemapped':False,
             'StreamChunkBytes':CHUNK,'OfficeStarted':False,'FormSectionRun':False,'SolveRun':False,'RootWorkbookChanged':False,
             'PackageElapsedSeconds':time.perf_counter()-started,'OwnPythonPeakWorkingSetBytes':peak_working_set(),
             'Native181CodeIdentityInheritedFromCompiledAcceptance':str(acceptance),'BenchmarkAndPhysicsPending':True}
    (out/'PackagePreservation.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    receipt={'Status':'PRIVATE_COMPILED_CODE_ONLY_PERFORMANCE_PAIR','SourceOriginSHA256':pair['SourceOriginSHA256'],
             'TemplateSHA256':args.expected_compiled_sha,'CurrentWorkbook':str(output),'CurrentSHA256':file_sha(output),
             'NewCodeVBAProjectSHA256':code_sha,'CodeOnlyZIPDifference':[VBA],'SourceAndTemplateUnchanged':True,
             'SharedInputsAndResultsAndLayoutIdentical':True,'BaselineWorkbook':str(base),'BaselineSHA256':args.expected_base_sha,
             'CompiledSourceWorkbook':str(compiled),'CompiledNativeComponents':181,'ExplicitCandidateOverrides':3,'HelpersInjected':0,
             'ProtectedBase':protected,'PackageProof':{'Path':str(out/'PackagePreservation.json'),'SHA256':file_sha(out/'PackagePreservation.json')},
             'AllUserInputsAndExistingResultsPreserved':True,'HistoricalStorage':'Excel','SavedLegacyGeometryInterpretation':'Adaptive',
             'CleanFinalPublicationClaimed':False,'FullBuildExecutedForThisPrivateCodeOnlyFixture':False,'OfficeStarted':False}
    (out/'PairPreparation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:details[k] for k in ['Status','Output','OutputSHA256','NonVBAPartCount','VBAProjectSHA256']},ensure_ascii=True))

if __name__=='__main__':main()
