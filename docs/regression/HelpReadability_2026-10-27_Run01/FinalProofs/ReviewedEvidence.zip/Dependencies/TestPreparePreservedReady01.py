"""ДЛЯ ТЕСТОВ: private Ready package — compiled VBA и пять Help indices; без Office/solve.

Запускать только после FreshBuild08 compile и readonly native reopen. Рабочие книги не
перезаписывает. Остальные108 local ZIP records копирует буквально через проверенный helper.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import io
import json
import os
import re
import struct
import sys
import time
import zipfile
import xml.etree.ElementTree as ET
from xml.parsers import expat
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parents[4]
E = ROOT / "docs/regression/GeometryFinalization_2026-10-26_Run01"
HERE = Path(__file__).resolve().parent
CONTRACT = HERE / "ReadyPreservationContract01.json"
CONTRACT_SHA = "5732EB0EEE68240DCDAFC6164D78D7EFF24526F935CE15401A5F21727E2F23C0"
HELPER = E / "LowMemoryPerformancePackagePlan/TestPrepareVbaOnlyPerformanceBook.py"
HELPER_SHA = "1E745DFE8E952EC1D0F177225EFBFF731952B182D1276E766EF579AD87F64DCD"
CATALOG = ROOT / "tools/build_workbook/SettingsCatalog.ps1"
CATALOG_SHA = "C258F59F34B62EC4CD83A9201FC1AE78E1F7621142D82C4D8CD3BDDDDB0DB371"
OLD_MAIN_SHA = "CD264F72E8E110BAE04277C1C68F133AE64D92B908F9C2BCD34B3ADD0F2365BF"
READY_SHA = "38AB6A1E9748D2840E3E941C720973DAAF2643C221694A1A36B0863CAD69C2B8"
FRESH_SHA = "08A9652C85E111B4C1DFCEDF828AF11CE369AA7CB20E3C8E6048C07FB3D7E8C3"
PROOF_PINS = {
    E / "FreshBuild08.json": "AC747AF4B999137F4242CA1C13935F9017E75BBFB307A7B7DD53F803DF7B84D6",
    E / "PostTransferNativeRelease01/NativeRelease.json": "46AFADDF7B70C097BFA59EF3E132FFB891BC52CE4805772E5ABA42840A1B214C",
    E / "PostTransferNativeRelease01/ProcessClosure.json": "E175B55910F132F03F4A80C06A46A2E672B4A4DBBFD443C2CAFD60ADD8B711D7",
    E / "PostTransferNativeRelease01/Ownership.json": "22217EDCE95C61D72E4F4AA4EBA66814D0EEACF465D693DDE65FE2CC75AA6217",
}
VBA, SST, HELP = "xl/vbaProject.bin", "xl/sharedStrings.xml", "xl/worksheets/sheet3.xml"
ALLOWED = {VBA, SST, HELP}
NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
CHUNK = 1024 * 1024


def TestRequire(condition, message):
    """ДЛЯ ТЕСТОВ: останавливает подготовку, не исправляя неизвестную структуру автоматически."""
    if not condition:
        raise ValueError(message)


def TestSHA(path):
    """ДЛЯ ТЕСТОВ: хеширует поток, не загружая тяжёлую книгу в память."""
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            h.update(block)
    return h.hexdigest().upper()


def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает только отдельный proof/contract."""
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def TestRecord(path):
    """ДЛЯ ТЕСТОВ: фиксирует абсолютный путь и фактический SHA входа."""
    return {"Path": str(Path(path).resolve()), "SHA256": TestSHA(path)}


def TestInside(path, parent):
    """ДЛЯ ТЕСТОВ: ограничивает входы workspace, output — точным private Ready каталогом."""
    path, parent = Path(path).resolve(), Path(parent).resolve()
    TestRequire(path.is_relative_to(parent), "Path outside authorized directory: " + str(path))
    return path


def TestLoadZIPHelper():
    """ДЛЯ ТЕСТОВ: импортирует только функции frozen low-memory helper; его main не вызывается."""
    TestRequire(TestSHA(HELPER) == HELPER_SHA, "Raw ZIP helper changed")
    spec = importlib.util.spec_from_file_location("TestPreservedReadyRawZIP", HELPER)
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    return module


def TestSplitGuide(text, maximum=200):
    """ДЛЯ ТЕСТОВ: повторяет применённый Split-GuideParagraphText для пяти зафиксированных строк."""
    result, remaining = [], text.strip()
    while len(remaining) > maximum:
        stop = min(maximum, len(remaining)-1)
        positions = [remaining.rfind(separator, 0, stop+1)+len(separator) for separator in (". ", "; ", ": ", ", ", " ") if remaining.rfind(separator, 0, stop+1) >= 0]
        take = max(positions, default=maximum)
        result.append(remaining[:take].strip())
        remaining = remaining[take:].strip()
    if remaining:
        result.append(remaining)
    return result


def TestCatalogAndContract(contract):
    """ДЛЯ ТЕСТОВ: берёт пять ExpectedAfter из contract и сверяет их с тремя C258 literals."""
    TestRequire(TestSHA(CATALOG) == CATALOG_SHA, "Transferred active SettingsCatalog must be exact C258")
    rows = contract["HelpPatchFromThreeCatalogLiterals"]
    TestRequire([row["Address"] for row in rows] == ["B1182", "A517", "A518", "A519", "A520"], "Exact five Help cells required")
    TestRequire({row["Part"] for row in rows} == {HELP} and len({row["ExpectedAfter"] for row in rows}) == 5, "Help contract part/text shape differs")
    source = CATALOG.read_text(encoding="utf-8-sig")
    groups = [[rows[0]["ExpectedAfter"]], [row["ExpectedAfter"] for row in rows[1:3]], [row["ExpectedAfter"] for row in rows[3:5]]]
    for index, group in enumerate(groups):
        literal = " ".join(group)
        TestRequire(source.count('"'+literal+'"') == 1, "Catalog literal differs from contract")
        if index:
            TestRequire(TestSplitGuide(literal) == group, "Catalog default paragraph split differs from contract")
    return rows


def TestShared(raw):
    """ДЛЯ ТЕСТОВ: читает plain/rich строки; сохраняет raw si для независимой byte-проверки."""
    root = ET.fromstring(raw)
    TestRequire(root.tag == NS+"sst", "Expected standard sst namespace")
    entries = root.findall(NS+"si")
    parts = re.findall(rb"<si\b[^>]*>.*?</si>", raw, re.S)
    TestRequire(len(entries) == len(parts) == int(root.attrib["uniqueCount"]), "Actual si/uniqueCount differs")
    values = ["".join(node.itertext()) for node in entries]
    plain = {}
    for index, node in enumerate(entries):
        children = list(node)
        if not node.attrib and len(children) == 1 and children[0].tag == NS+"t" and set(children[0].attrib) <= {"{http://www.w3.org/XML/1998/namespace}space"}:
            plain.setdefault(children[0].text or "", index)
    return root, parts, values, plain


def TestHelpValues(book, rows, field):
    """ДЛЯ ТЕСТОВ: проверяет фактические Help cells без импорта или native-save."""
    workbook = ET.fromstring(book.read("xl/workbook.xml"))
    relations = ET.fromstring(book.read("xl/_rels/workbook.xml.rels"))
    sheets = [node for node in workbook.findall(NS+"sheets/"+NS+"sheet") if node.get("name") == "Справка"]
    TestRequire(len(sheets) == 1, "One Help sheet required")
    rid = sheets[0].get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
    target = [node.get("Target") for node in relations if node.get("Id") == rid]
    TestRequire(len(target) == 1 and (target[0].lstrip("/") if target[0].startswith("/") else "xl/"+target[0]) == HELP, "Help relationship differs")
    _, _, strings, _ = TestShared(book.read(SST))
    sheet = ET.fromstring(book.read(HELP))
    cells = {cell.get("r"): cell for cell in sheet.iter(NS+"c")}
    for row in rows:
        cell = cells[row["Address"]]
        TestRequire(cell.get("t") == "s" and cell.find(NS+"f") is None, "Help literal cell type/formula differs")
        TestRequire(strings[int(cell.findtext(NS+"v"))] == row[field], "Actual Help text differs: "+row["Address"])
    return cells


def TestSharedReferenceCount(book):
    """ДЛЯ ТЕСТОВ: потоково считает все t=s ячейки без построения больших Results матриц."""
    count = 0
    def start(name, attrs):
        nonlocal count
        if name == NS[1:]+"c" and attrs.get("t") == "s":
            count += 1
    for info in book.infolist():
        if re.fullmatch(r"xl/worksheets/[^/]+\.xml", info.filename):
            parser = expat.ParserCreate(namespace_separator="}")
            parser.StartElementHandler = start
            parser.ExternalEntityRefHandler = lambda *unused: 0
            with book.open(info) as stream:
                for block in iter(lambda: stream.read(CHUNK), b""):
                    parser.Parse(block, False)
            parser.Parse(b"", True)
    return count


def TestPatchXML(book, rows):
    """ДЛЯ ТЕСТОВ: только si append/reuse, два счётчика и пять цифровых v-индексов."""
    old_sst, old_help = book.read(SST), book.read(HELP)
    root, old_parts, values, plain = TestShared(old_sst)
    TestRequire(len(old_parts) == 5546, "Pinned Ready must contain exactly5546 existing si entries")
    references = TestSharedReferenceCount(book)
    TestRequire(int(root.attrib["count"]) == references, "Original SST count differs from actual cell references; requires review")
    cells = TestHelpValues(book, rows, "ExpectedBefore")
    appended, changed, details = [], old_help, []
    for row in rows:
        cell = cells[row["Address"]]
        TestRequire(cell.get("s") == row["OriginalStyle"] and int(cell.findtext(NS+"v")) == row["OriginalSharedStringIndex"], "Original Help style/index differs")
        value = row["ExpectedAfter"]
        reused = value in plain
        if not reused:
            plain[value] = len(values)+len(appended)
            appended.append(('<si><t xml:space="preserve">'+escape(value)+'</t></si>').encode("utf-8"))
        index = plain[value]
        pattern = rb'<c\b(?=[^>]*\br="'+row["Address"].encode("ascii")+rb'")[^>]*>.*?</c>'
        matches = list(re.finditer(pattern, changed, re.S))
        TestRequire(len(matches) == 1, "Unique exact Help c node required")
        old_cell = matches[0].group()
        v = list(re.finditer(rb"<v>([0-9]+)</v>", old_cell))
        TestRequire(len(v) == 1 and int(v[0][1]) == row["OriginalSharedStringIndex"], "Exact old Help v node required")
        new_cell = old_cell[:v[0].start(1)]+str(index).encode("ascii")+old_cell[v[0].end(1):]
        changed = changed[:matches[0].start()]+new_cell+changed[matches[0].end():]
        details.append({**row, "NewSharedStringIndex": index, "ReusedExistingPlainSI": reused, "OriginalCellSHA256": hashlib.sha256(old_cell).hexdigest().upper(), "ChangedCellSHA256": hashlib.sha256(new_cell).hexdigest().upper(), "_old": old_cell, "_new": new_cell})
    reverse = changed
    for row in reversed(details):
        TestRequire(reverse.count(row["_new"]) == 1, "Unique reverse Help cell required")
        reverse = reverse.replace(row["_new"], row["_old"], 1)
    TestRequire(reverse == old_help, "Other Help XML/style/row/column bytes changed")
    header = re.search(rb"<sst\b[^>]*>", old_sst).group()
    new_header, hits = re.subn(rb'\buniqueCount="[0-9]+"', b'uniqueCount="'+str(len(old_parts)+len(appended)).encode()+b'"', header)
    TestRequire(hits == 1 and old_sst.count(b"</sst>") == 1, "SST root/count layout differs")
    insert = b"".join(appended)
    new_sst = old_sst.replace(header, new_header, 1).replace(b"</sst>", insert+b"</sst>", 1)
    _, new_parts, _, _ = TestShared(new_sst)
    TestRequire(new_parts[:len(old_parts)] == old_parts, "Existing raw si entries changed")
    restored = new_sst.replace(new_header, header, 1)
    if insert:
        restored = restored.replace(insert+b"</sst>", b"</sst>", 1)
    TestRequire(restored == old_sst, "SST changed beyond append/uniqueCount")
    for row in details:
        del row["_old"], row["_new"]
    return {SST: new_sst, HELP: changed}, {"Cells": details, "OldSICount": len(old_parts), "NewSICount": len(new_parts), "AppendedSI": len(appended), "ReusedSI": 5-len(appended), "ActualSharedStringReferences": references, "CountAttributeUnchangedAndCorrect": True, "ExistingSIByteExact": True, "RestOfSSTByteExactExceptUniqueCountAndAppend": True, "RestOfHelpXMLByteExactByReverse": True}


def TestXMLRecords(base, changed):
    """ДЛЯ ТЕСТОВ: создаёт raw records только двух небольших XML parts, без новой книги."""
    memory = io.BytesIO()
    with zipfile.ZipFile(memory, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
        for name, value in changed.items():
            target.writestr(copy.copy(base.getinfo(name)), value)
    raw = memory.getvalue()
    with zipfile.ZipFile(io.BytesIO(raw)) as book:
        infos, directory = book.infolist(), book.start_dir
    ordered = sorted(infos, key=lambda item: item.header_offset)
    blocks = {item.filename: raw[item.header_offset:(ordered[i+1].header_offset if i+1 < len(ordered) else directory)] for i, item in enumerate(ordered)}
    position, entries = directory, {}
    for item in infos:
        header = raw[position:position+46]
        TestRequire(header[:4] == b"PK\x01\x02", "Generated XML central record invalid")
        a, b, c = struct.unpack_from("<3H", header, 28)
        size = 46+a+b+c
        entries[item.filename] = raw[position:position+size]
        position += size
    return blocks, entries


def TestWritePackage(helper, base_path, compiled, output, old_meta, code_meta, xml_records):
    """ДЛЯ ТЕСТОВ: сохраняет108 raw local records и central metadata, меняя лишь их offset."""
    blocks, entries = xml_records
    offsets, old_entries, code_entries = {}, dict(old_meta["entries"]), dict(code_meta["entries"])
    with base_path.open("rb") as old, compiled.open("rb") as code, output.open("xb") as target:
        helper.copy_slice(old, target, 0, old_meta["prefix"])
        for info in sorted(old_meta["infos"], key=lambda item: item.header_offset):
            name = info.filename
            offsets[name] = target.tell()
            if name in blocks:
                target.write(blocks[name])
            else:
                source, meta = (code, code_meta) if name == VBA else (old, old_meta)
                helper.copy_slice(source, target, *meta["blocks"][name])
        central_offset = target.tell()
        for name, original in old_meta["entries"]:
            record = bytearray(entries[name] if name in entries else code_entries[VBA] if name == VBA else original)
            TestRequire(offsets[name] < 0xFFFFFFFF, "ZIP64 output not supported")
            struct.pack_into("<I", record, 42, offsets[name])
            target.write(record)
        size = target.tell()-central_offset
        TestRequire(size < 0xFFFFFFFF and central_offset < 0xFFFFFFFF, "ZIP64 output not supported")
        end = bytearray(old_meta["end"])
        struct.pack_into("<I", end, 12, size)
        struct.pack_into("<I", end, 16, central_offset)
        target.write(end)


def TestVerifyPackage(helper, base, compiled, output, contract, old_meta, rows, changed):
    """ДЛЯ ТЕСТОВ: независимо сверяет все111 частей, CRC и108 raw records/metadata."""
    new_meta = helper.archive(output)
    names = [item.filename for item in old_meta["infos"]]
    TestRequire([item.filename for item in new_meta["infos"]] == names, "ZIP name/count/order set changed")
    expected = {row["Name"]: row for row in contract["OriginalParts"]}
    old_entries, new_entries, proof = dict(old_meta["entries"]), dict(new_meta["entries"]), []
    code_sha = helper.digest_member(compiled, VBA)
    with zipfile.ZipFile(output) as book:
        for info in book.infolist():
            h = hashlib.sha256()
            with book.open(info) as stream:
                for block in iter(lambda: stream.read(CHUNK), b""):
                    h.update(block)
            value = h.hexdigest().upper()
            name = info.filename
            want = code_sha if name == VBA else hashlib.sha256(changed[name]).hexdigest().upper() if name in changed else expected[name]["SHA256"]
            TestRequire(value == want, "Output part bytes differ: "+name)
            if name not in ALLOWED:
                TestRequire(info.file_size == expected[name]["Bytes"], "Preserved size changed")
                a, b = old_meta["blocks"][name], new_meta["blocks"][name]
                TestRequire(a[1] == b[1] and helper.slice_hash(base, *a) == helper.slice_hash(output, *b), "Raw local record differs: "+name)
                x, y = bytearray(old_entries[name]), bytearray(new_entries[name])
                x[42:46] = y[42:46] = b"\0"*4
                TestRequire(x == y, "Central metadata changed beyond offset: "+name)
                proof.append({"Name": name, "Bytes": info.file_size, "SHA256": value, "RawLocalRecordIdentical": True, "CentralMetadataIdenticalExceptOffset": True})
        TestHelpValues(book, rows, "ExpectedAfter")
    TestRequire(len(proof) == 108, "Exactly108 preserved parts required")
    return {"All111PartsCRCRead": True, "Preserved108Parts": proof, "VBAByteIdenticalToCompiled": True, "VBAProjectSHA256": code_sha, "ZIPInventoryAndOrderIdentical111": True, "ActualHelpFiveTextsVerified": True}


def main():
    """ДЛЯ ТЕСТОВ: строит только новый private Ready после предъявления actual build/native proofs."""
    p = argparse.ArgumentParser()
    p.add_argument("--compiled-workbook", required=True)
    p.add_argument("--expected-compiled-sha", required=True)
    p.add_argument("--build-proof", required=True)
    p.add_argument("--native-release-proof", required=True)
    p.add_argument("--native-closure-proof", required=True)
    p.add_argument("--baseline-main", default=str(E / "FreshBuild07/RC_Section_NDM.xlsm"))
    args = p.parse_args()
    TestRequire(os.name == "nt", "Native Windows staging only")
    TestRequire(TestSHA(CONTRACT) == CONTRACT_SHA, "Ready contract changed")
    contract = TestJSON(CONTRACT)
    TestRequire(contract["ReferenceEntries"] == 111 and contract["RequiredByteIdenticalOtherParts"] == 108 and set(contract["AllowedChangedPartsOnly"]) == ALLOWED and len(contract["OriginalParts"]) == 111, "Exact contract111/108/3 required")
    helper = TestLoadZIPHelper()
    base = TestInside(ROOT / contract["ReferenceWorkbook"], ROOT)
    compiled = TestInside(args.compiled_workbook, E / "FreshBuild08")
    old_main = TestInside(args.baseline_main, ROOT)
    TestRequire(compiled.name == "RC_Section_NDM.xlsm" and compiled.parent == E / "FreshBuild08", "Only actual FreshBuild08 clean main allowed")
    TestRequire(args.expected_compiled_sha == FRESH_SHA and TestSHA(base) == READY_SHA == contract["ReferenceSHA256"] and TestSHA(compiled) == args.expected_compiled_sha and TestSHA(old_main) == OLD_MAIN_SHA, "Ready/newcompiled/oldmain SHA mismatch")
    rows = TestCatalogAndContract(contract)
    build_path, native_path, closure_path = [TestInside(value, E) for value in (args.build_proof, args.native_release_proof, args.native_closure_proof)]
    ownership_path = E / "PostTransferNativeRelease01/Ownership.json"
    TestRequire((build_path, native_path, closure_path) == tuple(PROOF_PINS)[:3], "Only pinned actual FreshBuild08/native/closure proof paths allowed")
    for path, expected_sha in PROOF_PINS.items():
        TestRequire(TestSHA(path) == expected_sha, "Actual proof changed: " + str(path))
    build, native, closure = [TestJSON(path) for path in (build_path, native_path, closure_path)]
    ownership = TestJSON(ownership_path)
    TestRequire(build["Status"] == "FULL_SOURCE_BUILD_AND_COMPILE_COMPLETED" and build["BookSHA256"] == args.expected_compiled_sha and build["BuildScriptSHA256"] == TestSHA(ROOT / "tools/build_workbook/Build-Workbook.ps1") and build["UserBookChanged"] is False, "Actual full build/compile proof missing")
    native_book = Path(native["Workbook"])
    if not native_book.is_absolute():
        native_book = ROOT / native_book
    TestRequire(native["Status"] == "PASS" and native["ImportedComponents"] == 0 and native["Components"] == 181 and native["BeforeSHA256"] == native["WorkbookSHA256"] == args.expected_compiled_sha and native_book.resolve() == compiled, "Actual readonly native181/noimport reopen proof missing")
    TestRequire(native["OwnedPID"] == ownership["PID"] and str(native["StartTicks"]) == str(ownership["StartTicksUTC"]), "Pinned native release and sibling ownership identity differ")
    TestRequire(closure["WorkerExitCode"] == 0 and closure["ExactIdentityAbsent"] is True and closure["Observation"]["Status"] == "ConfirmedNotFound" and closure["ResidualForceKilled"] is False, "Explicit natural native-close proof required; DifferentIdentity is not absence")
    output_dir = E / "PostTransferPublication01/Ready"
    TestRequire(not output_dir.exists(), "Fresh Ready output directory required")
    inputs = [TestRecord(path) for path in (base, compiled, old_main, CONTRACT, CATALOG, HELPER, build_path, native_path, closure_path, ownership_path, Path(__file__))]
    memory = helper.memory_observation()
    TestRequire(memory["AvailableRAMGiB"] >= 8 and memory["AvailableCommitGiB"] >= 14, "8RAM/14commit reserve required before package write")
    old_meta, code_meta = helper.archive(base), helper.archive(compiled)
    TestRequire(len(old_meta["infos"]) == 111 and {item.filename for item in old_meta["infos"]} == {row["Name"] for row in contract["OriginalParts"]}, "Reference ZIP inventory differs from111 contract")
    with zipfile.ZipFile(base) as original, zipfile.ZipFile(old_main) as old, zipfile.ZipFile(compiled) as new:
        TestHelpValues(old, rows, "ExpectedBefore")
        TestHelpValues(new, rows, "ExpectedAfter")
        changed, patch_proof = TestPatchXML(original, rows)
        xml_records = TestXMLRecords(original, changed)
    output_dir.mkdir(parents=True)
    pending, output = output_dir / "RC_Section_NDM.Pending.xlsm", output_dir / "RC_Section_NDM.xlsm"
    started = time.perf_counter()
    try:
        (output_dir / "InputsBefore.json").write_text(json.dumps({"Inputs": inputs, "Memory": memory, "NoOfficeOrSolve": True}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        TestWritePackage(helper, base, compiled, pending, old_meta, code_meta, xml_records)
        verified = TestVerifyPackage(helper, base, compiled, pending, contract, old_meta, rows, changed)
        for row in inputs:
            TestRequire(TestSHA(row["Path"]) == row["SHA256"], "Input changed during package: "+row["Path"])
        TestRequire(not output.exists(), "Final private output unexpectedly exists")
        os.rename(pending, output)  # Windows rename rejects an existing destination; input books are never renamed.
        proof = {"Status": "PASS_PRIVATE_READY_THREE_PART_PACKAGE_NATIVE_REOPEN_PENDING", "Output": str(output), "OutputSHA256": TestSHA(output), "CompiledWorkbook": str(compiled), "CompiledSHA256": args.expected_compiled_sha, "ReferenceSHA256": READY_SHA, "OldMainBaselineSHA256": OLD_MAIN_SHA, "ContractSHA256": CONTRACT_SHA, "CatalogSHA256": CATALOG_SHA, "AllowedChangedParts": sorted(ALLOWED), "HelpAndSSTPatch": patch_proof, "Preservation": verified, "InputsUnchanged": inputs, "PackageSecondsDiagnosticOnly": time.perf_counter()-started, "OfficeOrCOMStarted": False, "NoNativeSaveRecalculateRemesh": True, "UserDataResultsShapesStylesPreserved": True, "NativeMainReady181AndHelpAuditPending": True, "Published": False, "FullRegressionPass": False}
        (output_dir / "PackagePreservation.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        print(json.dumps({key: proof[key] for key in ("Status", "Output", "OutputSHA256", "AllowedChangedParts")}, ensure_ascii=True))
    except Exception as error:
        (output_dir / "Failure.json").write_text(json.dumps({"Status": "FAILED_PRIVATE_PACKAGE_NO_PUBLICATION", "Error": repr(error), "PendingWorkbook": str(pending), "FinalWorkbook": str(output), "OriginalInputsNeverWritten": True, "NoBlindDeleteOrRollback": True, "FullRegressionPass": False}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        raise


if __name__ == "__main__":
    main()
