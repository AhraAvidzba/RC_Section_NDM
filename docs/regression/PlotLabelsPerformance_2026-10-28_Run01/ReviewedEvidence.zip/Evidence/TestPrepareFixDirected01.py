"""ДЛЯ ТЕСТОВ: адресная приёмка локальных подписей и запросов неизменяемого элемента."""
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parents[3]
e=Path(__file__).resolve().parent
label=sys.argv[1] if len(sys.argv)>1 else 'FixDirected01'
assert label in ('FixDirected01','FixDirected02','FixDirected03')
body=(e/'TestRenderingDirected02.ps1').read_text('utf-8-sig').replace('RenderingDirected02',label)
files=subprocess.check_output(['git','diff','--name-only','--','src','tests'],text=True).splitlines()
assert len(files)==13 and all(Path(f).suffix in ('.cls','.bas') for f in files)
start=body.index(" foreach($relative in @(")
end=body.index(')){',start)+1
body=body[:start]+" foreach($relative in @("+','.join(repr(f) for f in files)+')'+body[end:]
start=body.index("foreach($entry in @(")
end=body.index(')){',start)+1
entries=['modTestElementGeometry.RunElementGeometryTests','modTestElementGeometry.RunContourCellMeshTests',
         'modTestElementGeometryViews.RunElementGeometryViewTests','modTestCalculationSnapshot.RunConcreteGeometrySnapshotTests',
         'modTestCalculationSnapshot.RunGeometryHashTests','modTestCalculationSnapshot.RunWorkbookActionCompletionTests',
         'modTestSectionRecipes.RunRecipeRuleTests','modTestSectionRecipes.RunRecipeAnnotationCountTests',
         'modTestGeometryReview.RunRebarLabelBoundaryTests','modTestGeometryReview.RunGeometryReviewTests',
         'modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests','modTestWorkbookInterface.RunFormationPreviewTests']
body=body[:start]+"foreach($entry in @("+','.join(repr(v) for v in entries)+')'+body[end:]
body=body.replace("if($matches.Count-ne1){throw ('Terminal total missing '+$entry)};$total=$matches[0]\n   $passed=[int]$total.Groups[1].Value;$failed=[int]$total.Groups[2].Value", """$expectedTotals=1;if($entry-ceq'modTestGeometryReview.RunGeometryReviewTests'){$expectedTotals=3}
   if($matches.Count-ne$expectedTotals){throw ('Terminal totals missing '+$entry)}
   $passed=0;$failed=0;foreach($total in $matches){$passed+=[int]$total.Groups[1].Value;$failed+=[int]$total.Groups[2].Value}""")
(e/('Test'+label+'.ps1')).write_text(body,encoding='utf-8-sig')
print('FIX_DIRECTED_PREPARED: '+str(len(entries))+' groups per mode')
