# -------------------- ДЛЯ ТЕСТОВ --------------------
# Отличает выход собственной идентичности от повторного использования номера PID; ошибки доступа не равны выходу.
$ErrorActionPreference='Stop'
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01'
$records=@();$seen=@{}
foreach($file in @(Get-ChildItem -LiteralPath $scratch,$PSScriptRoot -Recurse -File -Filter '*Ownership.json')){
 $own=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
 if(-not $own.PID -or -not $own.StartTicksUTC){continue}
 $key=[string]$own.PID+'/'+[string]$own.StartTicksUTC;if($seen.ContainsKey($key)){continue};$seen[$key]=$true
 $p=$null;$state=''
 try{$p=Get-Process -Id ([int]$own.PID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId-like'NoProcessFoundForGivenId*'){$state='ABSENT'}else{throw}}
 if($p){
  if($p.ProcessName-ine'EXCEL'){$state='PID_REUSED_DIFFERENT_EXECUTABLE'}else{
   if($null-eq$p.StartTime){throw ('Unreadable identity '+$own.PID)}
   if([string]$p.StartTime.ToUniversalTime().Ticks-ceq[string]$own.StartTicksUTC){throw ('Own Excel still live '+$own.PID)}
   $state='PID_REUSED_DIFFERENT_START'
  }
 }
 $records+=,[ordered]@{PID=[int]$own.PID;StartTicksUTC=[string]$own.StartTicksUTC;State=$state;OriginalEvidence=$file.FullName;OwnIdentityTerminal=$true;ForceKilled=$false}
}
[ordered]@{AtUTC=[DateTimeOffset]::UtcNow.ToString('o');AllOwnClosed=$true;Identities=$records;Count=$records.Count}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot 'AllDirectedOwnClosures01.json') -Encoding UTF8
Write-Output ('OWN_IDENTITIES_TERMINAL: '+$records.Count)
