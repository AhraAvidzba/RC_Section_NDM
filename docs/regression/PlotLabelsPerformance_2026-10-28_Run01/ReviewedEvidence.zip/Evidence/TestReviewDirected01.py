"""ДЛЯ ТЕСТОВ: читает полностью принятые первичные отчёты, сохраняет их SHA и проверяет точные суммы."""
from pathlib import Path
import json,re,hashlib
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01')
records=[]
for folder,expected in [('RenderingDirected02',462),('FixDirected03',9198),('GeometryFixtureDirected04',8106)]:
    rows=json.loads((p/folder/'Results.json').read_text('utf-8-sig'))
    assert sum(row['Passed'] for row in rows)==expected
    for row in rows:
        path=p/folder/(row['Entry']+'_'+row['Mode']+'.txt')
        raw=path.read_bytes();text=raw.decode('utf-8-sig')
        totals=re.findall(r'(?m)^TOTAL[^\r\n]*?(?:passed=)?(\d+)(?:; failed=|/)(\d+)\s*$',text)
        assert totals and sum(int(a) for a,b in totals)==row['Passed'] and all(int(b)==0 for a,b in totals)
        assert not re.search(r'(?m)^(?:FAIL:|FAIL |RUNTIME|WATCHDOG_FAILURE)',text)
        passed_lines=len(re.findall(r'(?m)^(?:OK:|PASS[: ])',text))
        if row['Entry']=='modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests':
            assert passed_lines==0 and row['Passed']==24 and text.strip()=='TOTAL RECIPE ANNOTATION SNAPSHOT: passed=24; failed=0'
        else:
            assert passed_lines==row['Passed'], (str(path),passed_lines,row['Passed'])
        records.append({'Path':str(path),'SHA256':hashlib.sha256(raw).hexdigest().upper(),'Passed':row['Passed'],'Failed':0,'FullyDecoded':True})
roundtrips=json.loads((e/'StoredRoundtrip01.json').read_text('utf-8-sig'))
assert {(r['Mode'],r['Storage']) for r in roundtrips}=={(m,s) for m in ('No','Yes') for s in ('Excel','File')}
for row in roundtrips:
    path=p/'StoredRoundtrip01'/(row['Mode']+'_'+row['Storage'])/'StoredHash.txt'
    raw=path.read_bytes();text=raw.decode('utf-8-sig')
    assert 'TOTAL_STORED_GEOMETRY_HASH: passed=4; failed=0' in text and 'FAIL:' not in text
    assert row['SnapshotPlotExportUnchanged']
    records.append({'Path':str(path),'SHA256':hashlib.sha256(raw).hexdigest().upper(),'Passed':4,'Failed':0,'FullyDecoded':True})
assert len(records)==38 and sum(r['Passed'] for r in records)==17782
result={'Status':'PASS_DIRECTED_ONLY','FullPass':False,'PrimaryReports':38,'Passed':17782,'Failed':0,'Records':records,
        'HistoricalPreparationFailuresPreserved':['RenderingDirected01 empty load prerequisite','FixDirected01 stored-hash prerequisite','FixDirected02 multiple terminal totals parser','CandidateProfile02 ChartObjects COM accessor','FocusedVerifierPreflight01 sandbox access'],
        'AdditionalFixtureCorrection':'Geometry fixture now includes local-boundary rebar labels; numerical and bar-position expectations unchanged.'}
(e/'DirectedPrimaryReview01.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('DIRECTED_PRIMARY_REVIEW: 38 complete reports, 17782/0; full acceptance pending')
