"""ДЛЯ ТЕСТОВ: создаёт компактный архив первичных доказательств без временных книг и чужих данных."""
from pathlib import Path
import hashlib,json,zipfile
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01')
def sha(b):return hashlib.sha256(b).hexdigest().upper()
files={}
for f in e.rglob('*'):
    if f.is_file() and f.suffix in ('.json','.ps1','.py','.txt') and f.name not in ('ArchiveManifest.json','Processed.json'):
        files['Evidence/'+str(f.relative_to(e)).replace('\\','/')]=f
folders=('RenderingDirected01','RenderingDirected02','FixDirected01','FixDirected02','FixDirected03','GeometryFixtureDirected04',
         'StoredRoundtrip01','NativeTimingParity01','OwnerTimingParity02','NativeFreshBuild02')
for name in folders:
    for f in (p/name).rglob('*'):
        if f.is_file() and f.suffix in ('.json','.txt'):
            files['Native/'+str(f.relative_to(p)).replace('\\','/')]=f
for f in p.glob('*.json'):files['Native/'+f.name]=f
records=[]
with zipfile.ZipFile(e/'ReviewedEvidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,f in sorted(files.items()):
        data=f.read_bytes();z.writestr(name,data);records.append({'Path':name,'Bytes':len(data),'SHA256':sha(data)})
    z.writestr('Manifest.json',json.dumps(records,ensure_ascii=False,indent=2))
with zipfile.ZipFile(e/'ReviewedEvidence.zip') as z:assert z.testzip() is None
manifest={'Files':len(records),'UncompressedBytes':sum(r['Bytes'] for r in records),'ArchiveBytes':(e/'ReviewedEvidence.zip').stat().st_size,'ArchiveSHA256':sha((e/'ReviewedEvidence.zip').read_bytes()),'Entries':records}
(e/'ArchiveManifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
processed={'Status':'DIRECTED_REVIEWED_FULL_PENDING','DirectedPassed':17782,'DirectedFailed':0,'FullPass':False,
           'Publication':json.loads((e/'Publication.json').read_text('utf-8')),'AllOwnClosed':True,'ArchiveSHA256':manifest['ArchiveSHA256'],'PrimaryReports':38,
           'TimingEvidence':['NativeTimingParityReview01.json','OwnerTimingParityReview02.json'],'ExactPhysicsParity':True,'ReadOnlySourceEquality':'SourceEquality02.json'}
(e/'Processed.json').write_text(json.dumps(processed,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='Entries'}))
