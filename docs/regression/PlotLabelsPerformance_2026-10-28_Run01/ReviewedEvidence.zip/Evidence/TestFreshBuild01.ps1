﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Собирает чистый шаблон из актуальных исходников; расчёт и автоматические поведенческие тесты не запускает.
$ErrorActionPreference='Stop'
$repoOuter=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $repoOuter
$outOuter=Join-Path $PSScriptRoot 'FreshBuild01'
if(Test-Path -LiteralPath $outOuter){throw 'Fresh build directory required'}
[void][IO.Directory]::CreateDirectory($outOuter)
$memoryOuter=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($memoryOuter.AvailableMBytes-lt8192-or($memoryOuter.CommitLimit-$memoryOuter.CommittedBytes)-lt14GB){throw 'RAM/commit reserve insufficient; no Excel started'}
[ordered]@{AtUTC=[DateTimeOffset]::UtcNow.ToString('o');RAMGiB=$memoryOuter.AvailableMBytes/1024;CommitFreeGiB=($memoryOuter.CommitLimit-$memoryOuter.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $outOuter 'MemoryBefore.json') -Encoding UTF8
$startedOuter=[DateTimeOffset]::UtcNow.ToString('o')
. (Join-Path $repoOuter 'tools/build_workbook/Build-Workbook.ps1') -OutputPath 'docs/regression/PlotLabelsPerformance_2026-10-28_Run01/FreshBuild01/RC_Section_NDM.xlsm' -FormulaImageDirectory 'docs/regression/PlotLabelsPerformance_2026-10-28_Run01/FreshBuild01/FormulaImages'
[ordered]@{Status='CLEAN_BUILD_COMPILED';StartedUTC=$startedOuter;FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o');PID=$ownedExcelProcessId;StartTicksUTC=[string]$ownedExcelStartTicks;BookSHA256=(Get-FileHash -LiteralPath (Join-Path $outOuter 'RC_Section_NDM.xlsm')).Hash;CompileCommand=578;UserDataCopied=$false;CalculationsOrBehaviorTestsRun=$false;PlotterSHA256=(Get-FileHash -LiteralPath (Join-Path $repoOuter 'src/Excel/CSectionPlotter.cls')).Hash}|ConvertTo-Json|Set-Content (Join-Path $outOuter 'Build.json') -Encoding UTF8
