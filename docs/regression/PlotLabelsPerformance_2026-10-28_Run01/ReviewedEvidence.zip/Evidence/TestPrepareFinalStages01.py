"""ДЛЯ ТЕСТОВ: готовит сборку и полный план без запуска процессов или задачи Windows."""
from pathlib import Path
import json
e=Path(__file__).resolve().parent
root=e.parents[2]
old=root/'docs/regression/FullSuiteLaunch_2026-10-27_FileSnapshot_Run02'
launch=root/'docs/regression/FullSuiteLaunch_2026-10-28_PlotLabels_Run01'
launch.mkdir(exist_ok=True)
assert not (launch/'LaunchRequest.json').exists()
for name in ('FullDriverHost.ps1','Read-CurrentStatus.ps1','TestObserveCompleted.py','Test-ObserverSelftest.py'):
    (launch/name).write_bytes((old/name).read_bytes())
body=(old/'Launch.ps1').read_text('utf-8-sig')
begin=body.index('# -------------------- ДЛЯ ТЕСТОВ --------------------')
end=body.index("$evidence=",begin)
body=body[:begin]+'''# Перед стартом все адресные процессы должны быть завершены и проверены по PID и UTC ticks.
$eligibility=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ReleaseEligibility.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $eligibility.Ready -or -not $eligibility.AllOwnClosed){throw 'Release eligibility or own closure proof missing.'}
foreach($own in $eligibility.OwnIdentities){
 $p=$null;try{$p=Get-Process -Id ([int]$own.PID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId-notlike'NoProcessFoundForGivenId*'){throw}}
 if($p-and$p.ProcessName-ieq'EXCEL'){
  if($null-eq$p.StartTime){throw 'Previous own identity unreadable'}
  if([string]$p.StartTime.ToUniversalTime().Ticks-ceq[string]$own.StartTicksUTC){throw 'Previous own Excel still live'}
 }
}
$epoch=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'SourceEpoch.json') -Raw -Encoding UTF8|ConvertFrom-Json
''' + body[end:]
body=body.replace('FullOnOff_2026-10-27_FileSnapshot_Run02','FullOnOff_2026-10-28_PlotLabels_Run01')
start=body.index("if((& git rev-parse HEAD) -cne")
end=body.index('\n& git diff',start)
body=body[:start]+'''if((& git rev-parse HEAD) -cne $epoch.HEAD -or (& git branch --show-current) -cne $epoch.Branch -or (Get-FileHash -LiteralPath 'workbook/output/RC_Section_NDM.xlsm').Hash -cne $epoch.BookSHA256 -or (Get-FileHash -LiteralPath 'workbook/output/VBA_All_Code.txt').Hash -cne $epoch.AllCodeSHA256){throw 'Reviewed published source epoch differs.'}''' + body[end:]
body=body.replace('2026-10-28T11:00:00+03:00','2026-10-29T12:00:00+03:00').replace('RC_NDM_Full_20261027_FileSnapshot_Run02','RC_NDM_Full_20261028_PlotLabels_Run01')
body=body.replace("'Test-ObserverSelftest.py'|ForEach-Object", "'Test-ObserverSelftest.py','SourceEpoch.json','ReleaseEligibility.json'|ForEach-Object")
body=body.replace('ExpectedSuites=178','ExpectedSuites=182').replace('CoverageVersion=6','CoverageVersion=7')
(launch/'Launch.ps1').write_text(body,encoding='utf-8-sig')
body=(old/'FullDriver.ps1').read_text('utf-8-sig')
start=body.index('if(-not $request.ExplicitUserConfirmation')
end=body.index('\n$driver=',start)
body=body[:start]+'''$epoch=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'SourceEpoch.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $request.ExplicitUserConfirmation -or [string]::IsNullOrWhiteSpace([string]$request.UserAuthorization) -or $request.SourceCommit -cne $epoch.HEAD -or $request.SourceSHA256 -cne $epoch.BookSHA256 -or $request.AllCodeSHA256 -cne $epoch.AllCodeSHA256){throw 'Explicit reviewed source epoch required.'}''' + body[end:]
body=body.replace('-ne 178','-ne 182').replace('-eq 178','-eq 182').replace('ExpectedSuites=178','ExpectedSuites=182').replace('CoverageVersion=6','CoverageVersion=7').replace('$request.CoverageVersion -ne 6','$request.CoverageVersion -ne 7')
(launch/'FullDriver.ps1').write_text(body,encoding='utf-8-sig')
(launch/'PreparedPlan.json').write_text(json.dumps({'Status':'PREPARED_NOT_LAUNCHED','ExpectedCoreMacroExecutions':182,'CoverageVersion':7,'FocusedSingleCases':122,'IncludesEntireFocusedPlan':True,'OverallDeadline':'2026-10-29T12:00:00+03:00','ForecastHours':4.5,'FinalReviewReserveMinutes':40},indent=2),encoding='utf-8')
body=(root/'docs/regression/ButtonUiLatency_2026-10-28_Run01/TestCleanRebuild01.ps1').read_text('utf-8-sig')
body=body.replace('CleanRebuild01','FreshBuild01').replace('ButtonUiLatency_2026-10-28_Run01','PlotLabelsPerformance_2026-10-28_Run01')
(e/'TestFreshBuild01.ps1').write_text(body,encoding='utf-8-sig')
body=(root/'docs/regression/ButtonUiLatency_2026-10-28_Run01/TestNativeCleanRebuild03.ps1').read_text('utf-8-sig')
body=body.replace('ButtonUiLatency_2026-10-28_Run01','PlotLabelsPerformance_2026-10-28_Run01').replace('NativeCleanRebuild03','NativeFreshBuild01').replace('CleanRebuild01','FreshBuild01')
(e/'TestNativeFreshBuild01.ps1').write_text(body,encoding='utf-8-sig')
print('PREPARED_ONLY: build, native export, full182 + entireFocused122')
