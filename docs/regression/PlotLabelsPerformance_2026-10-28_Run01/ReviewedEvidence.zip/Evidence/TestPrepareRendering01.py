"""ДЛЯ ТЕСТОВ: готовит короткий драйвер проверки актуального оформления в изолированной книге."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[3]
e=Path(__file__).resolve().parent
label=sys.argv[1] if len(sys.argv)>1 else 'RenderingDirected01'
assert label in ('RenderingDirected01','RenderingDirected02')
body=(root/'docs/regression/ButtonUiLatency_2026-10-28_Run01/TestExactPackageSmoke02.ps1').read_text('utf-8-sig')
body=body.replace('/ButtonUiLatency_2026-10-28_Run01','/PlotLabelsPerformance_2026-10-28_Run01')
body=body.replace("'ExactPackageSmoke02'",repr(label))
body=body.replace("(Join-Path $scratch 'Publication02/RC_Section_NDM.xlsm')", "(Join-Path $PSScriptRoot '../ButtonUiLatency_2026-10-28_Run01/CleanRebuild01/RC_Section_NDM.xlsm')")
needle=' $app.VBE.ActiveVBProject=$project;'
assert needle in body
insert="""
 foreach($relative in @('src/Excel/CSectionPlotter.cls','tests/modTestElementGeometryViews.bas','tests/modTestCalculationSnapshot.bas')){
  $file=Get-Item -LiteralPath (Join-Path $PSScriptRoot ('../../../'+$relative))
  $module=$project.VBComponents.Item($file.BaseName).CodeModule
  $body=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  if($file.Extension-eq'.cls'){$body=$body.Substring($body.IndexOf('Option Explicit'))}else{$body=[regex]::Replace($body,'(?m)^Attribute [^\\r\\n]*\\r?\\n','')}
  $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($body);$module=$null
 }
"""
body=body.replace(needle,insert+needle)
(e/('Test'+label+'.ps1')).write_text(body,encoding='utf-8-sig')
print('RENDERING_DRIVER_PREPARED')
