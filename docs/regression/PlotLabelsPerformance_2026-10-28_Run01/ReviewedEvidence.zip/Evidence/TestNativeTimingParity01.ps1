﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Измеряет ABBA без таймеров внутри рабочего кода; сохраняет IEEE64 всех физических таблиц, кроме RunID.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01'
$out=Join-Path $scratch 'NativeTimingParity01';if(Test-Path -LiteralPath $out){throw 'Fresh native timing directory required'};[void][IO.Directory]::CreateDirectory($out)
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestNativeTimingOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=New-Object 'System.Collections.Generic.List[object]'
$files=@(& git -C $root diff --name-only -- src tests)

# Меняет только существующую настройку в собственной книге.
function Set-TestSetting([string]$Key,[string]$Value){
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2
 for($r=2;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}}
 throw ('Setting absent '+$Key)
}
$helper=@'

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает геометрию, свойства, диаграммы и НДС без потери битов Double; аннотации намеренно проверяются отдельно.
Public Function TestPhysicsMatrixDump() As String
 Dim key As Variant, data As Variant, row As Long, column As Long, value As Variant, lines() As String, parts() As String
 For Each key In Array("rngNDMSectionGeometry", "rngNDMSectionProperties", "rngNDMMaterialDiagrams", "rngNDMElementResults")
  data = ReadPhysicalResultTable(ThisWorkbook, CStr(key))
  ReDim lines(0 To UBound(data, 1)): lines(0) = CStr(key) & "|" & CStr(UBound(data, 1)) & "|" & CStr(UBound(data, 2))
  For row = 1 To UBound(data, 1)
   ReDim parts(1 To UBound(data, 2))
   For column = 1 To UBound(data, 2)
    value = data(row, column)
    If row > 1 And column = 1 Then
     parts(column) = "RUNID"
    ElseIf VarType(value) = vbString Or IsEmpty(value) Then
     parts(column) = "S" & CStr(Len(CStr(value))) & ":" & CStr(value)
    Else
     parts(column) = "D" & TestSnapshotDouble(CDbl(value))
    End If
   Next column
   lines(row) = Join(parts, "|")
  Next row
  TestPhysicsMatrixDump = TestPhysicsMatrixDump & Join(lines, vbLf) & vbLf
 Next key
End Function
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отдельно обрабатывает очередь Excel после API; это не время ожидания физического нажатия.
Public Sub TestDrainNativeQueue()
 Dim i As Long: For i = 1 To 3: DoEvents: Next i
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подсчитывает реальные элементы по сохранённой таблице, без знания режима сетки.
Public Function TestNativeElementCounts() As String
 Dim data As Variant, row As Long, c As Long, r As Long
 data = ReadPhysicalResultTable(ThisWorkbook, "rngNDMSectionGeometry")
 For row = 2 To UBound(data, 1)
  If CStr(data(row, 3)) = "Concrete" Then c = c + 1 Else If CStr(data(row, 3)) = "Rebar" Then r = r + 1
 Next row
 TestNativeElementCounts = CStr(c) & "/" & CStr(r)
End Function
'@
$sequence=@('Baseline','Candidate','Candidate','Baseline')
for($pass=0;$pass-lt$sequence.Count;$pass++){
 $version=$sequence[$pass];$dir=Join-Path $out ($version+($pass+1));[void][IO.Directory]::CreateDirectory($dir)
 $path=Join-Path $dir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $scratch 'UserInput.xlsm') -Destination $path
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
 $app=$null;$book=$null;$project=$null;$code=$null;$compile=$null
 try{
  $existing=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object {$_.Id})
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][TestNativeTimingOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id
  if($existing-contains$owned){$app=$null;throw 'New Excel identity required'}
  $ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
  $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
  $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
  if($version-eq'Candidate'){
   foreach($relative in $files){
    $file=Get-Item -LiteralPath (Join-Path $root $relative);$source=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
    if($file.Extension-eq'.cls'){$source=$source.Substring($source.IndexOf('Option Explicit'))}else{$source=[regex]::Replace($source,'(?m)^Attribute [^\r\n]*\r?\n','')}
    $code=$project.VBComponents.Item($file.BaseName).CodeModule;$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($source)
   }
  }
  $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule;$code.AddFromString($helper)
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private benchmark compile failed'}
  $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $app.Visible=$true;$book.Worksheets.Item('Расчет').Activate();$app.EnableEvents=$true;$app.Calculation=-4105
  $modes=if($pass%2-eq0){@('Adaptive','Contour')}else{@('Contour','Adaptive')}
  foreach($mode in $modes){
   Set-TestSetting 'Mesh.CellGeometry' $mode
   $message=[string]$app.Run("'$($book.Name)'!FormSectionForWorkbook",$book)
   if($message-match'не сформировано|Ошибка'){throw $message}
   foreach($n in 1..6){
    $watch=[Diagnostics.Stopwatch]::StartNew();$message=[string]$app.Run("'$($book.Name)'!RunSectionCalculationForWorkbook",$book);$seconds=$watch.Elapsed.TotalSeconds
    if($message-notmatch'Время расчёта:'){throw $message}
    $idle=[Diagnostics.Stopwatch]::StartNew();[void]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestDrainNativeQueue");$idleSeconds=$idle.Elapsed.TotalSeconds
    $records.Add([ordered]@{Version=$version;Pass=$pass+1;Mode=$mode;Repeat=$n;Seconds=$seconds;QueueDrainSeconds=$idleSeconds;Message=$message})
    $records|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'NativeTimingParity01.json') -Encoding UTF8
    Write-Output ('NATIVE_TIME '+$version+' '+$mode+' #'+$n+': '+('{0:N3}'-f$seconds))
   }
   $dump=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestPhysicsMatrixDump")
   [IO.File]::WriteAllText((Join-Path $dir ($mode+'.IEEE64.txt')),$dump,[Text.Encoding]::UTF8)
   $counts=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestNativeElementCounts")
   [IO.File]::WriteAllText((Join-Path $dir ($mode+'.Counts.txt')),$counts)
  }
 }catch{[ordered]@{PrimaryError=$_.Exception.ToString();Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $dir 'Failure.json') -Encoding UTF8;throw}finally{
  $compile=$null;$code=$null;$project=$null;$range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;QuitRequested=$true;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Quit.json') -Encoding UTF8
 }
}
