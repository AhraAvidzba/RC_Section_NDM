﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет хеши и локальную подпись после реального сохранения и повторного открытия Excel/File в обоих режимах.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01'
$out=Join-Path $scratch 'StoredRoundtrip01';if(Test-Path -LiteralPath $out){throw 'Fresh roundtrip directory required'};[void][IO.Directory]::CreateDirectory($out)
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestStoredOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=New-Object 'System.Collections.Generic.List[object]'
$helper=@'

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет привязку подписи нижней арматуры верхнего прямоугольника к y=250 мм после чтения снимка.
Public Function TestLocalLabelProof() As String
 Dim settings As CSystemSettingsReader, reader As CSectionPlotDataReader, i As Long, found As Boolean, count As Long
 Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
 Set reader = New CSectionPlotDataReader: reader.LoadFromWorkbook ThisWorkbook, settings
 For i = 1 To reader.AnnotationCount
  If reader.AnnotationType(i) = "REBAR_LOCAL_ANNOTATION" Then
   count = count + 1
   If reader.AnnotationNormalY(i) = -1# And reader.AnnotationStartY(i) = 250# And reader.AnnotationEndY(i) = 250# Then
    If reader.AnnotationBoundaryDistance(i) <> 0# Then Err.Raise 5, "TestLocalLabelProof", "Локальная грань повторно перенесена к общей оболочке."
    found = True
   End If
  End If
 Next i
 If Not found Then Err.Raise 5, "TestLocalLabelProof", "Не найдена подпись у нижней грани верхнего прямоугольника y=250 мм."
 TestLocalLabelProof = "PASS: local=" & CStr(count) & "; upperBottomY=250; repeatedBoundaryDistance=0"
End Function
'@
# Изменяет только существующую настройку в собственной книге.
function Set-TestSetting([string]$Key,[string]$Value){
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2
 for($r=2;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}}
 throw ('Setting absent '+$Key)
}
foreach($mode in @('No','Yes')){foreach($storage in @('Excel','File')){
 $dir=Join-Path $out ($mode+'_'+$storage);[void][IO.Directory]::CreateDirectory($dir)
 $path=Join-Path $dir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $scratch 'UserInput.xlsm') -Destination $path
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
 $app=$null;$book=$null;$project=$null;$code=$null;$compile=$null
 try{
  $existing=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object {$_.Id})
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][TestStoredOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id
  if($existing-contains$owned){$app=$null;throw 'New Excel identity required'}
  $ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
  $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
  $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
  foreach($relative in @(& git -C $root diff --name-only -- src tests)){
   $file=Get-Item -LiteralPath (Join-Path $root $relative);$body=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
   if($file.Extension-eq'.cls'){$body=$body.Substring($body.IndexOf('Option Explicit'))}else{$body=[regex]::Replace($body,'(?m)^Attribute [^\r\n]*\r?\n','')}
   $code=$project.VBComponents.Item($file.BaseName).CodeModule;$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
  }
  $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule;$code.AddFromString($helper)
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private roundtrip compile failed'}
  $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  Set-TestSetting 'General.DiagramExtension' $mode
  Set-TestSetting 'Mesh.CellGeometry' 'Contour';Set-TestSetting 'Results.SnapshotStorage' $storage
  Set-TestSetting 'Results.SnapshotName' 'Test_Local';Set-TestSetting 'Plot.Enabled' 'Yes'
  $message=[string]$app.Run("'$($book.Name)'!FormSectionForWorkbook",$book)
  [IO.File]::WriteAllText((Join-Path $dir 'Formation.txt'),$message,[Text.Encoding]::UTF8)
  $message=[string]$app.Run("'$($book.Name)'!RunSectionCalculationForWorkbook",$book)
  [IO.File]::WriteAllText((Join-Path $dir 'Calculation.txt'),$message,[Text.Encoding]::UTF8)
  if($message-notmatch'Время расчёта:'){throw $message}
  $before=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestSnapshotReopenFingerprint")
  $localBefore=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestLocalLabelProof")
  $book.Save();$book.Close($false);$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $book=$app.Workbooks.Open($path,0,$false)
  $report=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.RunStoredGeometryHashTests")
  [IO.File]::WriteAllText((Join-Path $dir 'StoredHash.txt'),$report,[Text.Encoding]::UTF8)
  if($report-notmatch'TOTAL_STORED_GEOMETRY_HASH: passed=4; failed=0'-or$report-match'(?m)^FAIL:'){throw $report}
  $after=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestSnapshotReopenFingerprint")
  $localAfter=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestLocalLabelProof")
  if($before-cne$after-or$localBefore-cne$localAfter){throw 'Exact snapshot/plot/export/local annotation changed after reopen'}
  [IO.File]::WriteAllText((Join-Path $dir 'Fingerprint.txt'),$after,[Text.Encoding]::UTF8)
  $records.Add([ordered]@{Mode=$mode;Storage=$storage;StoredHashPassed=4;Failed=0;ExactFingerprintBytes=[Text.Encoding]::UTF8.GetByteCount($after);LocalAnnotation=$localAfter;SnapshotPlotExportUnchanged=$true})
  $records|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'StoredRoundtrip01.json') -Encoding UTF8
  Write-Output ('STORED_REOPEN '+$mode+' '+$storage+': 4/0; '+$localAfter)
 }catch{[ordered]@{Error=$_.Exception.ToString();Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $dir 'Failure.json') -Encoding UTF8;throw}finally{
  $compile=$null;$code=$null;$project=$null;$range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;QuitRequested=$true;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Quit.json') -Encoding UTF8
 }
}}
