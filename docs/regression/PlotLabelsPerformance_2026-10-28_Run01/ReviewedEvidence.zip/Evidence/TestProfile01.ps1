﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Читает настоящий код и измеряет короткие действия на замороженных копиях.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01'
$python='C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$profiler=Join-Path $scratch 'modTestActionProfiler.bas'
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestContourLatencyOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=New-Object 'System.Collections.Generic.List[object]'

# Меняет существующий ключ только в частной копии, не расширяя каталог.
function Set-TestSetting([string]$Key,[string]$Value){
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2
 for($r=2;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}}
 throw ('Setting absent '+$Key)
}

# Измеряет функцию и обработку очереди после её возврата, без диалогового ожидания.
function Invoke-TestAction([string]$Action,[string]$Fixture,[int]$Repeat){
 [void]$app.Run("'$($book.Name)'!modTestActionProfiler.TestReset")
 $watch=[Diagnostics.Stopwatch]::StartNew()
 $message=[string]$app.Run("'$($book.Name)'!$Action",$book)
 $seconds=$watch.Elapsed.TotalSeconds
 $idle=[double]$app.Run("'$($book.Name)'!modTestActionProfiler.TestIdle")
 $phases=[ordered]@{};$dump=[string]$app.Run("'$($book.Name)'!modTestActionProfiler.TestDump")
 foreach($line in $dump-split"`n"){if(-not$line.Trim()){continue};$v=$line.Trim()-split"`t";$phases[$v[0]]=[ordered]@{Seconds=[double]::Parse($v[1],[Globalization.CultureInfo]::InvariantCulture);Calls=[int]$v[2]}}
 $records.Add([ordered]@{Case=$case;Fixture=$Fixture;Action=$Action;Repeat=$Repeat;Seconds=$seconds;IdleDrainSeconds=$idle;Phases=$phases;Ready=[bool]$app.Ready;CalculationState=[int]$app.CalculationState;Message=$message;RealDialogTested=$false;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')})
 $records|ConvertTo-Json -Depth 8|Set-Content (Join-Path $PSScriptRoot 'ProfileMeasurements.json') -Encoding UTF8
 Write-Output ('PROFILE '+$case+' '+$Fixture+' '+$Action+' #'+$Repeat+': '+('{0:N3}'-f$seconds)+'s; idle='+('{0:N3}'-f$idle))
 if($message-match'не выполнен|не сформирован|Ошибка|Предупреждение'){throw ('Unexpected action message: '+$message)}
}

foreach($case in @('Adaptive','Contour')){
 $sourceCase=if($case-eq'PairedAdaptive'){'Contour'}else{$case}
 $dir=Join-Path $scratch ('Runtime/'+$case);[void][IO.Directory]::CreateDirectory($dir)
 $path=Join-Path $dir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $scratch 'UserInput.xlsm') -Destination $path
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
 $app=$null;$book=$null;$project=$null;$component=$null;$code=$null;$compile=$null
 try{
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][TestContourLatencyOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot ($case+'Ownership.json')) -Encoding UTF8
  $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
  $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
  $code=$project.VBComponents.Item('CSectionPlotter').CodeModule;$source=[IO.File]::ReadAllText((Join-Path $root 'src/Excel/CSectionPlotter.cls'),[Text.Encoding]::UTF8);$source=$source.Substring($source.IndexOf('Option Explicit'));$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($source)

  $native=Join-Path $scratch ('NativeActual/'+$case);[void][IO.Directory]::CreateDirectory($native)
  $all=New-Object Text.StringBuilder;[void]$all.AppendLine('VBA PROJECT EXPORT');[void]$all.AppendLine('Workbook: '+$book.Name);[void]$all.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  for($i=1;$i-le$project.VBComponents.Count;$i++){
   $component=$project.VBComponents.Item($i);$code=$component.CodeModule;$n=[int]$code.CountOfLines;$body=if($n){[string]$code.Lines(1,$n)}else{''}
   [IO.File]::WriteAllText((Join-Path $native ($component.Name+'.txt')),$body,[Text.Encoding]::UTF8)
   [void]$all.AppendLine('='*100);[void]$all.AppendLine('COMPONENT: '+$component.Name);[void]$all.AppendLine('TYPE: '+$component.Type);[void]$all.AppendLine('LINES: '+$n);[void]$all.AppendLine('='*100);if($n){[void]$all.AppendLine($body)};[void]$all.AppendLine()
  }
  [IO.File]::WriteAllText((Join-Path $native 'VBA_All_Code.txt'),$all.ToString(),[Text.Encoding]::UTF8)
  & $python (Join-Path $PSScriptRoot 'TestInstrument01.py') $case
  if($LASTEXITCODE-ne0){throw 'Profiler preparation failed'}
  $component=$project.VBComponents.Add(1);$component.Name='modTestActionProfiler';$component.CodeModule.AddFromString([IO.File]::ReadAllText($profiler,[Text.Encoding]::UTF8))
  foreach($file in Get-ChildItem -LiteralPath (Join-Path $scratch ('Instrumented/'+$case)) -Filter '*.txt'){$code=$project.VBComponents.Item($file.BaseName).CodeModule;$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString([IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8))}
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private profiling compile failed'}
  $compile=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  Set-TestSetting 'Mesh.CellGeometry' $case
  $app.Visible=$true;$book.Worksheets.Item('Расчет').Activate();$app.EnableEvents=$true;$app.Calculation=-4105
  foreach($n in 1..3){Invoke-TestAction 'FormSectionForWorkbook' 'PlotYes' $n}; foreach($n in 1..6){Invoke-TestAction 'RunSectionCalculationForWorkbook' 'PlotYes' $n}
  Set-TestSetting 'Plot.Enabled' 'No'
  Invoke-TestAction 'FormSectionForWorkbook' 'PlotNo' 1
  foreach($n in 1..3){Invoke-TestAction 'RunSectionCalculationForWorkbook' 'PlotNo' $n}; $book.Save()
 }finally{
  $compile=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $absent=$false;$w=[Diagnostics.Stopwatch]::StartNew()
  do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($w.Elapsed.TotalSeconds-lt15)
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot ($case+'Closure.json')) -Encoding UTF8
  if(-not$absent){throw 'Own normal closure not proven'}
 }
}
