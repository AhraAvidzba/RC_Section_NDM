"""ДЛЯ ТЕСТОВ: отделяет ускорение чтения неизменяемой области от исправления размещения подписей."""
from pathlib import Path
import subprocess
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01')
out=p/'OwnerBaselineSources';out.mkdir(exist_ok=True)
for name in ('CConcreteElement','CSectionModel'):
    data=subprocess.check_output(['git','show','HEAD:src/Section/'+name+'.cls'])
    (out/(name+'.cls')).write_bytes(data)
body=(e/'TestNativeTimingParity01.ps1').read_text('utf-8-sig').replace('NativeTimingParity01','OwnerTimingParity02')
body=body.replace("if($version-eq'Candidate'){",'if($true){')
anchor="  $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule;$code.AddFromString($helper)"
assert body.count(anchor)==1
body=body.replace(anchor,"""  if($version-eq'Baseline'){
   foreach($name in @('CConcreteElement','CSectionModel')){
    $source=[IO.File]::ReadAllText((Join-Path $scratch ('OwnerBaselineSources/'+$name+'.cls')),[Text.Encoding]::UTF8)
    $source=$source.Substring($source.IndexOf('Option Explicit'))
    $code=$project.VBComponents.Item($name).CodeModule;$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($source)
   }
  }
"""+anchor)
body=body.replace(' Dim key As Variant, data As Variant, row As Long, column As Long, value As Variant, lines() As String, parts() As String', ' Dim key As Variant, data As Variant, row As Long, column As Long, value As Variant, lines() As String, parts() As String\n BeginCalculationSnapshotRead ThisWorkbook')
body=body.replace('data = ReadPhysicalResultTable(ThisWorkbook, CStr(key))','data = ReadAnchoredResultTable(ThisWorkbook, CStr(key))')
body=body.replace(' Next key\nEnd Function',' Next key\n EndCalculationSnapshotRead\nEnd Function')
body=body.replace('  foreach($mode in $modes){', "  foreach($storage in @('Excel','File')){foreach($mode in $modes){\n   Set-TestSetting 'Results.SnapshotStorage' $storage")
body=body.replace('Mode=$mode;Repeat=$n','Mode=$mode;Storage=$storage;Repeat=$n')
body=body.replace("($mode+'.IEEE64.txt')", "($storage+'_'+$mode+'.IEEE64.txt')").replace("($mode+'.Counts.txt')", "($storage+'_'+$mode+'.Counts.txt')")
body=body.replace('  }\n }catch{','  }}\n }catch{')
(e/'TestOwnerTimingParity02.ps1').write_text(body,encoding='utf-8-sig')
body=(e/'TestReviewTiming01.py').read_text('utf-8').replace('NativeTimingParity01','OwnerTimingParity02').replace('NativeTimingParityReview01','OwnerTimingParityReview02')
body=body.replace('len(records)==48','len(records)==96').replace("for mode in ('Adaptive','Contour'):", "for storage,mode in ((s,m) for s in ('Excel','File') for m in ('Adaptive','Contour')):\n    label=storage+'/'+mode")
body=body.replace('stats[mode]','stats[label]').replace("(mode+'.IEEE64.txt')", "(storage+'_'+mode+'.IEEE64.txt')").replace("(mode+'.Counts.txt')", "(storage+'_'+mode+'.Counts.txt')")
body=body.replace("if r['Mode']==mode and", "if r['Storage']==storage and r['Mode']==mode and")
(e/'TestReviewOwnerTiming02.py').write_text(body,encoding='utf-8')
print('PREPARED_OWNER_ONLY_ABBA: all other sources and annotations identical')
