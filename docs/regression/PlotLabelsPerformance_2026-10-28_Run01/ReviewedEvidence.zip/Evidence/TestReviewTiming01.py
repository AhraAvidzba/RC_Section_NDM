"""ДЛЯ ТЕСТОВ: сверяет ABBA-замеры и точное IEEE64-представление рабочих таблиц."""
from pathlib import Path
import json, hashlib, statistics
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01/NativeTimingParity01')
records=json.loads((e/'NativeTimingParity01.json').read_text('utf-8-sig'))
assert len(records)==48
stats={}
for mode in ('Adaptive','Contour'):
    stats[mode]={}
    dumps=[]
    for number,version in enumerate(('Baseline','Candidate','Candidate','Baseline'),1):
        folder=p/(version+str(number))
        raw=(folder/(mode+'.IEEE64.txt')).read_bytes()
        dumps.append(raw)
        assert not (folder/'Failure.json').exists()
    assert all(raw==dumps[0] for raw in dumps), f'Exact physical tables differ: {mode}'
    stats[mode]['ExactTableSHA256']=hashlib.sha256(dumps[0]).hexdigest().upper()
    stats[mode]['ComparedDumpBytes']=len(dumps[0])
    stats[mode]['Counts']=(p/'Candidate2'/(mode+'.Counts.txt')).read_text()
    for version in ('Baseline','Candidate'):
        rows=[r for r in records if r['Mode']==mode and r['Version']==version and r['Repeat']>=2]
        assert len(rows)==10
        stats[mode][version]={'WarmMedianSeconds':statistics.median(r['Seconds'] for r in rows),
                             'MinimumSeconds':min(r['Seconds'] for r in rows),'MaximumSeconds':max(r['Seconds'] for r in rows),
                             'QueueMedianSeconds':statistics.median(r['QueueDrainSeconds'] for r in rows),
                             'Samples':len(rows)}
    stats[mode]['SpeedChangePercent']=100*(stats[mode]['Candidate']['WarmMedianSeconds']/stats[mode]['Baseline']['WarmMedianSeconds']-1)
out={'Status':'PASS_EXACT_PHYSICAL_PARITY_AND_NATIVE_TIMING','Instrumented':False,
     'Order':['Baseline','Candidate','Candidate','Baseline'],'IgnoredPhysicalFields':['RunID only'],
     'Tables':['rngNDMSectionGeometry','rngNDMSectionProperties','rngNDMMaterialDiagrams','rngNDMElementResults'],
     'AnnotationsComparedSeparately':True,'Measurements':stats,'FullPass':False}
(e/'NativeTimingParityReview01.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
