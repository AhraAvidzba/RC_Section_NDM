"""ДЛЯ ТЕСТОВ: готовит парный профайлер реальных повторных расчётов одной пользовательской геометрии."""
from pathlib import Path
root=Path(__file__).resolve().parents[3]
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01')
old=root/'docs/regression/ContourLatency_2026-10-28_Run01'
body=(old/'TestProfile.ps1').read_text('utf-8-sig').replace('/ContourLatency_2026-10-28_Run01','/PlotLabelsPerformance_2026-10-28_Run01')
body=body.replace("$profiler='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ActionLatency_2026-10-28_Run01/modTestActionProfiler.bas'", "$profiler=Join-Path $scratch 'modTestActionProfiler.bas'")
body=body.replace("@('Contour','Adaptive','PairedAdaptive')","@('Adaptive','Contour')")
body=body.replace("(Join-Path $scratch ($sourceCase+'/RC_Section_NDM.xlsm'))","(Join-Path $scratch 'UserInput.xlsm')")
body=body.replace("$book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject", """$book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
  $code=$project.VBComponents.Item('CSectionPlotter').CodeModule;$source=[IO.File]::ReadAllText((Join-Path $root 'src/Excel/CSectionPlotter.cls'),[Text.Encoding]::UTF8);$source=$source.Substring($source.IndexOf('Option Explicit'));$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($source)
""")
body=body.replace("if($case-eq'PairedAdaptive'){Set-TestSetting 'Mesh.CellGeometry' 'Adaptive'}","Set-TestSetting 'Mesh.CellGeometry' $case")
body=body.replace("foreach($n in 1..2){Invoke-TestAction 'FormSectionForWorkbook' 'PlotYes' $n;Invoke-TestAction 'RunSectionCalculationForWorkbook' 'PlotYes' $n}", "foreach($n in 1..3){Invoke-TestAction 'FormSectionForWorkbook' 'PlotYes' $n}; foreach($n in 1..6){Invoke-TestAction 'RunSectionCalculationForWorkbook' 'PlotYes' $n}")
body=body.replace("  Invoke-TestAction 'RunSectionCalculationForWorkbook' 'PlotNo' 1", "  foreach($n in 1..3){Invoke-TestAction 'RunSectionCalculationForWorkbook' 'PlotNo' $n}; $book.Save()")
body=body.replace("TestInstrument.py","TestInstrument01.py")
(e/'TestProfile01.ps1').write_text(body,encoding='utf-8-sig')
helper=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ActionLatency_2026-10-28_Run01/modTestActionProfiler.bas')
(p/'modTestActionProfiler.bas').write_bytes(helper.read_bytes())
instrument=(old/'TestInstrument.py').read_text('utf-8-sig').replace('/ContourLatency_2026-10-28_Run01','/PlotLabelsPerformance_2026-10-28_Run01')
start=instrument.index('methods = {')
end=instrument.index('\nfor module,names',start)
methods={
 'modWorkbookCalculation':['RunSectionCalculationForWorkbook','CalculateSectionCore','FormSectionForWorkbook','UpdateSectionPlotForWorkbook','UpdateSectionGeometryPreviewForWorkbook','PrepareSectionSnapshot','FinishWorkbookAction','CalculateResultsSheet'],
 'modSectionSnapshot':['ReadFormedSectionFromResults','ReadConcreteBoundaryMap','ReadSavedConcreteBoundaries','ReadSectionGeometryFromResults','SavedConcreteRegion','ValidateSavedBoundaryProperties'],
 'modCalculationSnapshot':['SaveAndDisplayCalculationSnapshot','UpdateSectionResultsForWorkbook'],
 'CCalculationSnapshot':['Validate','ValidateGeometryPreview'],
 'CSectionPlotDataReader':['LoadFromWorkbook','LoadGeometryPreviewFromWorkbook','ReadGeometryAndResults','ReadGeometryPreview','ConcreteGeometry','AnnotationBoundaryDistance'],
 'CSectionPlotter':['Draw','PrepareChart','AddElementShapes','AddConcreteElementShape'],
 'CNDMResultsWriter':['WriteResults','WriteGeometryPreview','RestoreSnapshotBase','PrepareGeometryPreviewSnapshot','PrepareElementGeometryRows','WriteSectionGeometry','WriteElementGeometry','WriteSectionAnnotations'],
 'CExcelAppStateGuard':['Enter','Restore'],
 'CSectionGeometryQuery':['TryRectangle','LabelBoundaryDistance'],
 'CConcreteRegion':['Clone'],
}
instrument=instrument[:start]+'methods = '+repr(methods)+instrument[end:]
(e/'TestInstrument01.py').write_text(instrument,encoding='utf-8')
print('PAIRED_PROFILER_PREPARED')
