"""ДЛЯ ТЕСТОВ: повторяет исходный парный профайлер с текущими исправлениями, не перезаписывая базовые замеры."""
from pathlib import Path
import shutil,subprocess
root=Path(__file__).resolve().parents[3]
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01')
target=p/'CandidateProfile02'
assert not target.exists()
target.mkdir()
shutil.copyfile(p/'UserInput.xlsm',target/'UserInput.xlsm')
shutil.copyfile(p/'modTestActionProfiler.bas',target/'modTestActionProfiler.bas')
body=(e/'TestProfile01.ps1').read_text('utf-8-sig').replace(str(p).replace('\\','/'),str(target).replace('\\','/'))
old="  $code=$project.VBComponents.Item('CSectionPlotter').CodeModule;$source=[IO.File]::ReadAllText((Join-Path $root 'src/Excel/CSectionPlotter.cls'),[Text.Encoding]::UTF8);$source=$source.Substring($source.IndexOf('Option Explicit'));$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($source)"
assert old in body
files=subprocess.check_output(['git','diff','--name-only','--','src','tests'],text=True).splitlines()
replacement="  foreach($relative in @("+','.join(repr(v) for v in files)+""")){
   $file=Get-Item -LiteralPath (Join-Path $root $relative);$source=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
   if($file.Extension-eq'.cls'){$source=$source.Substring($source.IndexOf('Option Explicit'))}else{$source=[regex]::Replace($source,'(?m)^Attribute [^\\r\\n]*\\r?\\n','')}
   $code=$project.VBComponents.Item($file.BaseName).CodeModule;$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($source)
  }
"""
body=body.replace(old,replacement).replace('TestInstrument01.py','TestInstrumentCandidate02.py').replace('ProfileMeasurements.json','CandidateProfileMeasurements02.json')
body=body.replace("($case+'Ownership.json')","('Candidate'+$case+'Ownership.json')").replace("($case+'Closure.json')","('Candidate'+$case+'Closure.json')")
body=body.replace("  Set-TestSetting 'Plot.Enabled' 'No'", "  $chart=$book.Worksheets.Item('Расчет').ChartObjects.Item('chtNDMSectionPlot').Chart;[void]$chart.Export((Join-Path $dir 'FinalPlot.png'),'PNG');$chart=$null\n  Set-TestSetting 'Plot.Enabled' 'No'")
(e/'TestCandidateProfile02.ps1').write_text(body,encoding='utf-8-sig')
instrument=(e/'TestInstrument01.py').read_text('utf-8').replace(str(p).replace('\\','/'),str(target).replace('\\','/'))
(e/'TestInstrumentCandidate02.py').write_text(instrument,encoding='utf-8')
print('CANDIDATE_PROFILE_PREPARED')
