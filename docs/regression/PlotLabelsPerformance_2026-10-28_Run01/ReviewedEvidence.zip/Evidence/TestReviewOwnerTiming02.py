"""ДЛЯ ТЕСТОВ: сверяет ABBA-замеры и точное IEEE64-представление рабочих таблиц."""
from pathlib import Path
import json, hashlib, statistics
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01/OwnerTimingParity02')
records=json.loads((e/'OwnerTimingParity02.json').read_text('utf-8-sig'))
assert len(records)==96
stats={}
for storage,mode in ((s,m) for s in ('Excel','File') for m in ('Adaptive','Contour')):
    label=storage+'/'+mode
    stats[label]={}
    dumps=[]
    for number,version in enumerate(('Baseline','Candidate','Candidate','Baseline'),1):
        folder=p/(version+str(number))
        raw=(folder/(storage+'_'+mode+'.IEEE64.txt')).read_bytes()
        dumps.append(raw)
        assert not (folder/'Failure.json').exists()
    assert all(raw==dumps[0] for raw in dumps), f'Exact physical tables differ: {mode}'
    stats[label]['ExactTableSHA256']=hashlib.sha256(dumps[0]).hexdigest().upper()
    stats[label]['ComparedDumpBytes']=len(dumps[0])
    stats[label]['Counts']=(p/'Candidate2'/(storage+'_'+mode+'.Counts.txt')).read_text()
    for version in ('Baseline','Candidate'):
        rows=[r for r in records if r['Storage']==storage and r['Mode']==mode and r['Version']==version and r['Repeat']>=2]
        assert len(rows)==10
        stats[label][version]={'WarmMedianSeconds':statistics.median(r['Seconds'] for r in rows),
                             'MinimumSeconds':min(r['Seconds'] for r in rows),'MaximumSeconds':max(r['Seconds'] for r in rows),
                             'QueueMedianSeconds':statistics.median(r['QueueDrainSeconds'] for r in rows),
                             'Samples':len(rows)}
    stats[label]['SpeedChangePercent']=100*(stats[label]['Candidate']['WarmMedianSeconds']/stats[label]['Baseline']['WarmMedianSeconds']-1)
out={'Status':'PASS_EXACT_PHYSICAL_PARITY_AND_NATIVE_TIMING','Instrumented':False,
     'Order':['Baseline','Candidate','Candidate','Baseline'],'IgnoredPhysicalFields':['RunID only'],
     'Tables':['rngNDMSectionGeometry','rngNDMSectionProperties','rngNDMMaterialDiagrams','rngNDMElementResults'],
     'AnnotationsComparedSeparately':True,'Measurements':stats,'FullPass':False}
(e/'OwnerTimingParityReview02.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
