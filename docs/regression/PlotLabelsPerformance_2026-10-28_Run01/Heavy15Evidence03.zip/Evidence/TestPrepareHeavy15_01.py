"""ДЛЯ ТЕСТОВ: переносит только точный текущий VBA в частные копии тяжёлой книги для сравнения Excel/File."""
from pathlib import Path
import zipfile,re,json,hashlib
e=Path(__file__).resolve().parent;root=e.parents[2]
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01')
heavy=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/ActionLatency_2026-10-28_Run01/StorageRun02/Heavy1232_30_Optimized_ExcelResults.xlsm')
target=p/'Heavy15_03';target.mkdir(exist_ok=False)
with zipfile.ZipFile(root/'workbook/output/RC_Section_NDM.xlsm') as z:vba=z.read('xl/vbaProject.bin')
with zipfile.ZipFile(heavy) as old,zipfile.ZipFile(target/'Input.xlsm','w',zipfile.ZIP_DEFLATED) as new:
    for item in old.infolist():new.writestr(item,vba if item.filename=='xl/vbaProject.bin' else old.read(item.filename))
    assert new.testzip() is None
with zipfile.ZipFile(heavy) as old,zipfile.ZipFile(target/'Input.xlsm') as new:
    assert all(old.read(n)==new.read(n) for n in old.namelist() if n!='xl/vbaProject.bin')
(e/'Heavy15InputProof03.json').write_text(json.dumps({'OriginalHeavyPath':str(heavy),'OriginalHeavySHA256':hashlib.sha256(heavy.read_bytes()).hexdigest().upper(),'PrivateInputSHA256':hashlib.sha256((target/'Input.xlsm').read_bytes()).hexdigest().upper(),'CurrentVBAProjectSHA256':hashlib.sha256(vba).hexdigest().upper(),'OnlyVBAChangedInPrivateCopy':True,'OriginalModified':False},indent=2),encoding='utf-8')
body=(e/'TestNativeTimingParity01.ps1').read_text('utf-8-sig')
body=body.replace("$out=Join-Path $scratch 'NativeTimingParity01';if(Test-Path -LiteralPath $out){throw 'Fresh native timing directory required'};[void][IO.Directory]::CreateDirectory($out)","$out=Join-Path $scratch 'Heavy15_03'")
body=body.replace("$sequence=@('Baseline','Candidate','Candidate','Baseline')","$sequence=@('Excel','File','File','Excel')")
body=body.replace("(Join-Path $scratch 'UserInput.xlsm')","(Join-Path $out 'Input.xlsm')")
start=body.index("  if($version-eq'Candidate'){")
end=body.index("  $code=$project.VBComponents.Item('modTestCalculationSnapshot')",start)
body=body[:start]+body[end:]
start=body.index('  $modes=')
end=body.index('   foreach($n in 1..6){',start)
body=body[:start]+'''  Set-TestSetting 'Results.SnapshotStorage' 'Excel'
  $range=$book.Names.Item('rngBatchSummary').RefersToRange;$summary=$range.Cells.Item(1,1).Resize(50,33).Value2;$excluded=@{}
  for($r=1;$r-le50;$r++){if([string]$summary[$r,1]-match'^PERF_\\d+$'-and[string]$summary[$r,4]-ceq'InputErr'){$excluded[[string]$summary[$r,1]]=$true}}
  $range=$book.Names.Item('rngLoadCombinations').RefersToRange;$original=$range.Value2;$values=$range.Value2
  for($r=2;$r-le$values.GetLength(0);$r++){for($c=1;$c-le$values.GetLength(1);$c++){$values[$r,$c]=$null}}
  $retained=@();$targetRow=2
  for($r=2;$r-le$original.GetLength(0)-and$targetRow-le16;$r++){
   $loadID=[string]$original[$r,1];if(-not$loadID-or$excluded.ContainsKey($loadID)){continue}
   for($c=1;$c-le$values.GetLength(1);$c++){$values[$targetRow,$c]=$original[$r,$c]}
   $retained+=$loadID;$targetRow++
  }
  if($retained.Count-ne15){throw ('Exactly 15 nonempty valid original load IDs required; actual='+$retained.Count)}
  $range.Value2=$values;$range=$null
  [IO.File]::WriteAllText((Join-Path $dir 'LoadIDs.json'),($retained|ConvertTo-Json),[Text.Encoding]::UTF8)
  $counts=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestNativeElementCounts")
  if($counts-cne'1232/8'){throw ('The real heavy fixture is required: '+$counts)}
  [IO.File]::WriteAllText((Join-Path $dir 'ElementCounts.txt'),$counts)
  if($version-eq'File'){[void]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestPrepareHeavyGeometryFile")}
  Set-TestSetting 'Results.SnapshotStorage' $version
  Set-TestSetting 'Plot.Enabled' 'Yes';Set-TestSetting 'Plot.AutoUpdateAfterCalculation' 'Yes'
  foreach($mode in @('SavedHeavy')){
''' +body[end:]
body=body.replace('NativeTimingParity01.json','Heavy15Timing03.json').replace('ReadPhysicalResultTable(ThisWorkbook, CStr(key))','ReadAnchoredResultTable(ThisWorkbook, CStr(key))')
body=body.replace("if($message-notmatch'Время расчёта:'){throw $message}","if($message-notmatch'Время расчёта:'-or$message-notmatch'Обработано сочетаний: 15\\.'-or$message-match'ошибками ввода'){throw $message}")
body=body.replace(' Dim key As Variant, data As Variant, row As Long, column As Long, value As Variant, lines() As String, parts() As String',' Dim key As Variant, data As Variant, row As Long, column As Long, value As Variant, lines() As String, parts() As String\n BeginCalculationSnapshotRead ThisWorkbook')
body=body.replace(' Next key\nEnd Function',' Next key\n EndCalculationSnapshotRead\nEnd Function')
helper="""
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает уже сохранённую геометрию в собственный файл preview; новую сетку не формирует.
Public Sub TestPrepareHeavyGeometryFile()
 Dim model As CSectionModel, settings As CSystemSettingsReader, units As CUnitSystem
 Dim writer As CNDMResultsWriter, snapshot As CCalculationSnapshot, store As CCalculationSnapshotStore
 Dim exact As CCalculationSnapshot, original As Variant, key As Variant, row As Long
 original = ReadPhysicalResultTable(ThisWorkbook, "rngNDMSectionGeometry")
 Set model = ReadFormedSectionFromResults(ThisWorkbook, False)
 Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
 Set units = New CUnitSystem: units.LoadFromSettings settings
 Set writer = New CNDMResultsWriter
 Set snapshot = writer.PrepareGeometryPreviewSnapshot(ThisWorkbook, model, PrepareSectionSnapshot(model), units)
 Set exact = New CCalculationSnapshot: exact.RunID = snapshot.RunID
 For row = 2 To UBound(original, 1): original(row, 1) = snapshot.RunID: Next row
 For Each key In snapshot.Keys()
  If CStr(key) = "rngNDMSectionGeometry" Then exact.AddTable CStr(key), original Else exact.AddTable CStr(key), snapshot.Table(CStr(key))
 Next key
 exact.Validate
 Set store = New CCalculationSnapshotStore: store.SaveFile ThisWorkbook, exact
End Sub
"""
body=body.replace("'@\n$sequence=",helper+"'@\n$sequence=")
(e/'TestHeavy15_03.ps1').write_text(body,encoding='utf-8-sig')
print('PREPARED_HEAVY_15_ABBA: Excel/File/File/Excel, 1232/8 required, 15 valid original loads required')
