﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Измеряет ABBA без таймеров внутри рабочего кода; сохраняет IEEE64 всех физических таблиц, кроме RunID.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$scratch='C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01'
$out=Join-Path $scratch 'Heavy15_02'
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestNativeTimingOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=New-Object 'System.Collections.Generic.List[object]'
$files=@(& git -C $root diff --name-only -- src tests)

# Меняет только существующую настройку в собственной книге.
function Set-TestSetting([string]$Key,[string]$Value){
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2
 for($r=2;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}}
 throw ('Setting absent '+$Key)
}
$helper=@'

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает геометрию, свойства, диаграммы и НДС без потери битов Double; аннотации намеренно проверяются отдельно.
Public Function TestPhysicsMatrixDump() As String
 Dim key As Variant, data As Variant, row As Long, column As Long, value As Variant, lines() As String, parts() As String
 BeginCalculationSnapshotRead ThisWorkbook
 For Each key In Array("rngNDMSectionGeometry", "rngNDMSectionProperties", "rngNDMMaterialDiagrams", "rngNDMElementResults")
  data = ReadAnchoredResultTable(ThisWorkbook, CStr(key))
  ReDim lines(0 To UBound(data, 1)): lines(0) = CStr(key) & "|" & CStr(UBound(data, 1)) & "|" & CStr(UBound(data, 2))
  For row = 1 To UBound(data, 1)
   ReDim parts(1 To UBound(data, 2))
   For column = 1 To UBound(data, 2)
    value = data(row, column)
    If row > 1 And column = 1 Then
     parts(column) = "RUNID"
    ElseIf VarType(value) = vbString Or IsEmpty(value) Then
     parts(column) = "S" & CStr(Len(CStr(value))) & ":" & CStr(value)
    Else
     parts(column) = "D" & TestSnapshotDouble(CDbl(value))
    End If
   Next column
   lines(row) = Join(parts, "|")
  Next row
  TestPhysicsMatrixDump = TestPhysicsMatrixDump & Join(lines, vbLf) & vbLf
 Next key
 EndCalculationSnapshotRead
End Function
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отдельно обрабатывает очередь Excel после API; это не время ожидания физического нажатия.
Public Sub TestDrainNativeQueue()
 Dim i As Long: For i = 1 To 3: DoEvents: Next i
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подсчитывает реальные элементы по сохранённой таблице, без знания режима сетки.
Public Function TestNativeElementCounts() As String
 Dim data As Variant, row As Long, c As Long, r As Long
 data = ReadPhysicalResultTable(ThisWorkbook, "rngNDMSectionGeometry")
 For row = 2 To UBound(data, 1)
  If CStr(data(row, 3)) = "Concrete" Then c = c + 1 Else If CStr(data(row, 3)) = "Rebar" Then r = r + 1
 Next row
 TestNativeElementCounts = CStr(c) & "/" & CStr(r)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает уже сохранённую геометрию в собственный файл preview; новую сетку не формирует.
Public Sub TestPrepareHeavyGeometryFile()
 Dim model As CSectionModel, settings As CSystemSettingsReader, units As CUnitSystem
 Dim writer As CNDMResultsWriter, snapshot As CCalculationSnapshot, store As CCalculationSnapshotStore
 Set model = ReadFormedSectionFromResults(ThisWorkbook, False)
 Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
 Set units = New CUnitSystem: units.LoadFromSettings settings
 Set writer = New CNDMResultsWriter
 Set snapshot = writer.PrepareGeometryPreviewSnapshot(ThisWorkbook, model, PrepareSectionSnapshot(model), units)
 Set store = New CCalculationSnapshotStore: store.SaveFile ThisWorkbook, snapshot
End Sub
'@
$sequence=@('Excel','File','File','Excel')
for($pass=0;$pass-lt$sequence.Count;$pass++){
 $version=$sequence[$pass];$dir=Join-Path $out ($version+($pass+1));[void][IO.Directory]::CreateDirectory($dir)
 $path=Join-Path $dir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $out 'Input.xlsm') -Destination $path
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient RAM/commit reserve'}
 $app=$null;$book=$null;$project=$null;$code=$null;$compile=$null
 try{
  $existing=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object {$_.Id})
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][TestNativeTimingOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id
  if($existing-contains$owned){$app=$null;throw 'New Excel identity required'}
  $ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $dir 'Ownership.json') -Encoding UTF8
  $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
  $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
  $code=$project.VBComponents.Item('modTestCalculationSnapshot').CodeModule;$code.AddFromString($helper)
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private benchmark compile failed'}
  $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $app.Visible=$true;$book.Worksheets.Item('Расчет').Activate();$app.EnableEvents=$true;$app.Calculation=-4105
  Set-TestSetting 'Results.SnapshotStorage' 'Excel'
  $range=$book.Names.Item('rngBatchSummary').RefersToRange;$summary=$range.Cells.Item(1,1).Resize(50,33).Value2;$excluded=@{}
  for($r=1;$r-le50;$r++){if([string]$summary[$r,1]-match'^PERF_\d+$'-and[string]$summary[$r,4]-ceq'InputErr'){$excluded[[string]$summary[$r,1]]=$true}}
  $range=$book.Names.Item('rngLoadCombinations').RefersToRange;$original=$range.Value2;$values=$range.Value2
  for($r=2;$r-le$values.GetLength(0);$r++){for($c=1;$c-le$values.GetLength(1);$c++){$values[$r,$c]=$null}}
  $retained=@();$targetRow=2
  for($r=2;$r-le$original.GetLength(0)-and$targetRow-le16;$r++){
   $loadID=[string]$original[$r,1];if(-not$loadID-or$excluded.ContainsKey($loadID)){continue}
   for($c=1;$c-le$values.GetLength(1);$c++){$values[$targetRow,$c]=$original[$r,$c]}
   $retained+=$loadID;$targetRow++
  }
  if($retained.Count-ne15){throw ('Exactly 15 nonempty valid original load IDs required; actual='+$retained.Count)}
  $range.Value2=$values;$range=$null
  [IO.File]::WriteAllText((Join-Path $dir 'LoadIDs.json'),($retained|ConvertTo-Json),[Text.Encoding]::UTF8)
  $counts=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestNativeElementCounts")
  if($counts-cne'1232/8'){throw ('The real heavy fixture is required: '+$counts)}
  [IO.File]::WriteAllText((Join-Path $dir 'ElementCounts.txt'),$counts)
  if($version-eq'File'){[void]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestPrepareHeavyGeometryFile")}
  Set-TestSetting 'Results.SnapshotStorage' $version
  Set-TestSetting 'Plot.Enabled' 'Yes';Set-TestSetting 'Plot.AutoUpdateAfterCalculation' 'Yes'
  foreach($mode in @('SavedHeavy')){
   foreach($n in 1..6){
    $watch=[Diagnostics.Stopwatch]::StartNew();$message=[string]$app.Run("'$($book.Name)'!RunSectionCalculationForWorkbook",$book);$seconds=$watch.Elapsed.TotalSeconds
    if($message-notmatch'Время расчёта:'-or$message-notmatch'Обработано сочетаний: 15\.'-or$message-match'ошибками ввода'){throw $message}
    $idle=[Diagnostics.Stopwatch]::StartNew();[void]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestDrainNativeQueue");$idleSeconds=$idle.Elapsed.TotalSeconds
    $records.Add([ordered]@{Version=$version;Pass=$pass+1;Mode=$mode;Repeat=$n;Seconds=$seconds;QueueDrainSeconds=$idleSeconds;Message=$message})
    $records|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'Heavy15Timing02.json') -Encoding UTF8
    Write-Output ('NATIVE_TIME '+$version+' '+$mode+' #'+$n+': '+('{0:N3}'-f$seconds))
   }
   $dump=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestPhysicsMatrixDump")
   [IO.File]::WriteAllText((Join-Path $dir ($mode+'.IEEE64.txt')),$dump,[Text.Encoding]::UTF8)
   $counts=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestNativeElementCounts")
   [IO.File]::WriteAllText((Join-Path $dir ($mode+'.Counts.txt')),$counts)
  }
 }catch{[ordered]@{PrimaryError=$_.Exception.ToString();Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $dir 'Failure.json') -Encoding UTF8;throw}finally{
  $compile=$null;$code=$null;$project=$null;$range=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;QuitRequested=$true;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'Quit.json') -Encoding UTF8
 }
}
