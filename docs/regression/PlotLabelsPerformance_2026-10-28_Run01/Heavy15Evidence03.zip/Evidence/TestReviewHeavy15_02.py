"""ДЛЯ ТЕСТОВ: сравнивает File/Excel на 1232 бетонных элементах, 8 стержнях и 15 пригодных исходных LC."""
from pathlib import Path
import hashlib,json,statistics,re
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01/Heavy15_02')
rows=json.loads((e/'Heavy15Timing02.json').read_text('utf-8-sig'));assert len(rows)==24
records={};dumps=[];ids=[]
for i,storage in enumerate(('Excel','File','File','Excel'),1):
    directory=p/(storage+str(i))
    assert not (directory/'Failure.json').exists()
    assert (directory/'ElementCounts.txt').read_text()=='1232/8'
    values=json.loads((directory/'LoadIDs.json').read_text('utf-8-sig'))
    assert len(values)==len(set(values))==15 and all(values)
    ids.append(values)
    raw=(directory/'SavedHeavy.IEEE64.txt').read_bytes();dumps.append(raw)
assert all(v==ids[0] for v in ids)
assert all(v==dumps[0] for v in dumps), 'Full physical tables differ between File and Excel'
for storage in ('Excel','File'):
    samples=[r for r in rows if r['Version']==storage and r['Repeat']>=2]
    assert len(samples)==10
    assert all('Обработано сочетаний: 15.' in r['Message'] and 'ошибками ввода' not in r['Message'] for r in samples)
    records[storage]={'WarmMedianSeconds':statistics.median(r['Seconds'] for r in samples),'MinimumSeconds':min(r['Seconds'] for r in samples),'MaximumSeconds':max(r['Seconds'] for r in samples),'Samples':10,'QueueMedianSeconds':statistics.median(r['QueueDrainSeconds'] for r in samples)}
out={'Status':'PASS_HEAVY_15_STORAGE_COMPARISON_ONLY','Concrete':1232,'Rebar':8,'Combinations':15,'LoadIDs':ids[0],
     'PlotEnabled':True,'GenerationIncluded':False,'SameCurrentVBA':True,'PhysicalTablesExact':True,
     'PhysicalDumpBytes':len(dumps[0]),'PhysicalDumpSHA256':hashlib.sha256(dumps[0]).hexdigest().upper(),
     'Measurements':records,'FileTimeChangePercent':100*(records['File']['WarmMedianSeconds']/records['Excel']['WarmMedianSeconds']-1),
     'FullPass':False,'OriginalUserBookChanged':False,'WrongFixtureProbeExcluded':'Heavy15_01 had 474 concrete/28 rebar and only one active combination; excluded from this comparison.'}
(e/'Heavy15Review02.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
