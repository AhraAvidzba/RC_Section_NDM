"""ДЛЯ ТЕСТОВ: строго сравнивает числа и строки, учитывая только известное представление Boolean Excel/File."""
from pathlib import Path
import hashlib,json,statistics,re
e=Path(__file__).resolve().parent
p=Path('C:/Users/avidzba/.codex/visualizations/2026/10/12/01a12ece-8192-7141-89b3-f83f1176184c/PlotLabelsPerformance_2026-10-28_Run01/Heavy15_03')
rows=json.loads((e/'Heavy15Timing03.json').read_text('utf-8-sig'));assert len(rows)==24
records={};dumps=[];ids=[];hashes=[];boolean_counts=[]
boolean=re.compile(r'^(RUNID\|S\d+:[^|]+\|S\d+:(?:ExtensionUsed|General\.DiagramExtension|State\.[^.]+\.ExtensionUsed)\|)(D0000000000000000|DBFF0000000000000|S4:True|S5:False)(\|.*)$')
truth={'D0000000000000000':'B0','DBFF0000000000000':'B1','S4:True':'B1','S5:False':'B0'}
for i,storage in enumerate(('Excel','File','File','Excel'),1):
    directory=p/(storage+str(i));assert not (directory/'Failure.json').exists()
    assert (directory/'ElementCounts.txt').read_text()=='1232/8'
    values=json.loads((directory/'LoadIDs.json').read_text('utf-8-sig'))
    assert len(values)==len(set(values))==15 and all(values);ids.append(values)
    raw=(directory/'SavedHeavy.IEEE64.txt').read_bytes();hashes.append(hashlib.sha256(raw).hexdigest().upper())
    lines=raw.decode('utf-8-sig').splitlines();changed=0
    for index,line in enumerate(lines):
        m=boolean.fullmatch(line)
        if m:lines[index]=m[1]+truth[m[2]]+m[3];changed+=1
    boolean_counts.append(changed);dumps.append('\n'.join(lines))
assert all(v==ids[0] for v in ids)
assert all(v==dumps[0] for v in dumps), 'Numerical, geometry source data, material or NDS tables differ'
assert hashes[0]==hashes[3] and hashes[1]==hashes[2]
for storage in ('Excel','File'):
    samples=[r for r in rows if r['Version']==storage and r['Repeat']>=2];assert len(samples)==10
    assert all('Обработано сочетаний: 15.' in r['Message'] and 'ошибками ввода' not in r['Message'] for r in samples)
    records[storage]={'WarmMedianSeconds':statistics.median(r['Seconds'] for r in samples),'MinimumSeconds':min(r['Seconds'] for r in samples),'MaximumSeconds':max(r['Seconds'] for r in samples),'Samples':10,'QueueMedianSeconds':statistics.median(r['QueueDrainSeconds'] for r in samples)}
out={'Status':'PASS_HEAVY_15_STORAGE_COMPARISON_ONLY','Concrete':1232,'Rebar':8,'Combinations':15,'LoadIDs':ids[0],
     'ConcreteGeometry':'Saved rectangular cells from the historical heavy circular section; no new generation',
     'PlotEnabled':True,'GenerationIncluded':False,'SameCurrentVBA':True,'NumericalIEEE64Exact':True,'GeometrySourceMetadataExact':True,
     'DocumentedBooleanMetadataRepresentationOnly':True,'BooleanMetadataRows':boolean_counts,'RawPhysicalSHA256':hashes,
     'ComparedDataBytes':len(dumps[0].encode('utf-8')),'CanonicalSHA256':hashlib.sha256(dumps[0].encode('utf-8')).hexdigest().upper(),
     'Measurements':records,'FileTimeChangePercent':100*(records['File']['WarmMedianSeconds']/records['Excel']['WarmMedianSeconds']-1),
     'FullPass':False,'OriginalUserBookChanged':False,
     'PreparationTrialsPreserved':{'Heavy15_01':'Wrong fixture, 474/28 and one active LC, excluded','Heavy15_02':'Conversion helper recreated source metadata, corrected by preserving the saved geometry matrix; excluded from final timing'}}
(e/'Heavy15Review03.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
