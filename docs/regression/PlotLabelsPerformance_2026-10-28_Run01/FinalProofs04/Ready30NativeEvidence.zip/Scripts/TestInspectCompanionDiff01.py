from pathlib import Path
import importlib.util,json,struct
b=Path(__file__).resolve().parent;p=b/'PlotLabelsPerformance_2026-10-28_Run01/Ready30CompanionNative01'
sp=importlib.util.spec_from_file_location('test_fingerprint_parser',b/'TestReviewReady30Companion01.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
datasets=[m.parse((p/f).read_bytes().decode('utf-8-sig')) for f in ['ExcelFingerprint.txt','FileFingerprint.txt']]
all=[]
def show(v):
 if v[0]=='D':return dict(Kind=v[0],Bits=v[1],Double=struct.unpack('>d',bytes.fromhex(v[1]))[0])
 return dict(Kind=v[0],Text=v[1])
for key in ['rngNDMSectionGeometry','rngNDMElementResults','rngNDMSectionContours','rngNDMMaterialDiagrams','rngNDMElementGeometry']:
 a,c=datasets[0][1][key],datasets[1][1][key];diff=[];count=0
 for i,(x,y) in enumerate(zip(a,c)):
  for j,(u,v) in enumerate(zip(x,y)):
   if u!=v:
    count+=1
    if len(diff)<25:diff.append(dict(Row=i+1,Column=j+1,Header=show(a[0][j]),Excel=show(u),File=show(v)))
 all.append(dict(Key=key,ExcelShape=[len(a),len(a[0])],FileShape=[len(c),len(c[0])],DifferingCells=count,FirstDifferences=diff))
out=dict(Tables=all,ConsumersExact=datasets[0][2]==datasets[1][2],ExcelPrefix=datasets[0][0],FilePrefix=datasets[1][0])
(p/'Differences01.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=True))
