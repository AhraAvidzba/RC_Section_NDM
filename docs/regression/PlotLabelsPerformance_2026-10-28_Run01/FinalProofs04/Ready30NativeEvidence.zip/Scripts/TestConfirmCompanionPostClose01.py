from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parent
p=b/'PlotLabelsPerformance_2026-10-28_Run01/Ready30CompanionNative01'
root=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
e=root/'docs/regression/PlotLabelsPerformance_2026-10-28_Run01'
def read(f):return json.loads(f.read_text('utf-8-sig'))
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest().upper()
ready=read(e/'Ready30CodePreparation01.json');source=read(e/'Ready30SourceInspection01.json')
full=read(root/'docs/regression/FullOnOff_2026-10-29_PlotLabels_Run02/CompleteCurrentAcceptance.json')
assert full['Status']=='PASS' and full['SourceSHA256']==ready['AcceptedMainSHA256']
assert read(p/'OwnClosure.json')['AllOwnClosed'] and read(p/'Quit.json')['QuitRequested']
failure=read(p/'Failure.json')
assert 'GetFileHashCommand.ComputeFileHash' in failure['Error'] and 'because it is being used by another process' in failure['Error']
assert 'TestReady30CompanionNative01.ps1: line 48' in failure['Stack']
assert sha(p/'RC_Section_NDM.xlsm')==ready['ReadySHA256']
assert sha(p/'Heavy1232_30_Optimized.ndm')==source['CompanionSHA256']
assert sha(Path(ready['Ready']))==ready['ReadySHA256']
assert all((p/f).stat().st_size>1_000_000 for f in ['ExcelFingerprint.txt','FileFingerprint.txt'])
proof=dict(Status='NATIVE_FILE_LOADED_AND_FINGERPRINTS_CAPTURED_REVIEW_REQUIRED',CurrentFullSourceSHA256=full['SourceSHA256'],ReadySHA256=ready['ReadySHA256'],CompanionSHA256=source['CompanionSHA256'],NoHelperImported=True,NoRecalculation=True,NoBookSaved=True,CanonicalReadyUntouched=True,FullPass=False,OriginalSharingFailurePreserved=True,FinalHashChecksPerformedAfterNormalQuit=True,NativeScriptSHA256=sha(b/'TestReady30CompanionNative01.ps1'),InitialFailureSHA256=sha(p/'Failure.json'))
(p/'Capture.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
print('CAPTURE_CONFIRMED_AFTER_NORMAL_QUIT; exact ready and companion bytes unchanged; no repeat native process')
