"""ДЛЯ ТЕСТОВ: точно разбирает длины строк и IEEE64 нативного отпечатка без округления чисел."""
from pathlib import Path
import argparse,hashlib,json,re
BASE=Path(__file__).resolve().parent
HEADER=re.compile(r'\n([A-Za-z][A-Za-z0-9_.]*)\|(\d+)\|(\d+)\n')
NUMBER=re.compile(r'D([0-9A-F]{16})\|')
STRING=re.compile(r'S(\d+):')

def parse(s):
    tables={};p=s.find('\n');assert p>=0
    prefix=s[:p]
    while True:
        h=HEADER.match(s,p)
        if not h:break
        key=h[1];assert key not in tables
        nr,nc=int(h[2]),int(h[3]);assert nr>0 and nc>0
        p=h.end();rows=[]
        for r in range(nr):
            row=[]
            for c in range(nc):
                n=NUMBER.match(s,p)
                if n:row.append(('D',n[1]));p=n.end();continue
                t=STRING.match(s,p);assert t,(key,r,c,p,s[p:p+40])
                wanted=int(t[1]);start=t.end();end=start;units=0
                while units<wanted:
                    assert end<len(s)
                    units+=2 if ord(s[end])>0xffff else 1;end+=1
                assert units==wanted and s[end:end+1]=='|'
                row.append(('S',s[start:end]));p=end+1
            rows.append(row)
            if r<nr-1:assert s[p:p+1]=='\n';p+=1
        tables[key]=rows
    return prefix,tables,s[p:]

def selftest():
    text='\nrngNDMSectionGeometry|1|3\nS6:я|\n😀x|D3FF0000000000000|S0:|\nrngNDMElementResults|1|1\nD8000000000000000|\nPLOT_SUFFIX'
    a,t,suffix=parse(text)
    assert a=='' and len(t)==2 and t['rngNDMSectionGeometry'][0][0]==('S','я|\n😀x')
    assert suffix=='\nPLOT_SUFFIX'
    assert parse(text.replace('D3FF0000000000000','D3FF0000000000001'))[1]!=t
    for broken in [text.replace('S6:','S5:',1),text.replace('D3FF','X3FF',1),text.replace('|D3FF','D3FF',1)]:
        try:parse(broken)
        except AssertionError:continue
        raise AssertionError('Malformed fingerprint accepted')
    print('FINGERPRINT_PARSER_SELFTEST: exact IEEE, UTF16 string length, embedded separator/newline, malformed lengths/tokens rejected')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--selftest',action='store_true');args=parser.parse_args()
    if args.selftest:selftest();return
    p=BASE/'PlotLabelsPerformance_2026-10-28_Run01/Ready30CompanionNative01'
    capture=json.loads((p/'Capture.json').read_text('utf-8-sig'))
    assert capture['Status']=='NATIVE_FILE_LOADED_AND_FINGERPRINTS_CAPTURED_REVIEW_REQUIRED'
    paths=[p/'ExcelFingerprint.txt',p/'FileFingerprint.txt']
    raw=[f.read_bytes() for f in paths]
    excel=parse(raw[0].decode('utf-8-sig'));file=parse(raw[1].decode('utf-8-sig'))
    assert len(excel[1])==7 and len(file[1])==17
    critical=['rngNDMSectionGeometry','rngNDMElementResults','rngNDMSectionContours','rngNDMMaterialDiagrams','rngNDMElementGeometry']
    comparisons=[]
    for key in critical:
        a,b=excel[1][key],file[1][key]
        assert a==b,('Exact geometry/results/diagrams mismatch',key)
        comparisons.append(dict(Key=key,Rows=len(a),Columns=len(a[0]),AllCellsExact=True))
    assert excel[2]==file[2], 'Current plot/export consumer values differ'
    geometry=excel[1]['rngNDMSectionGeometry']
    assert len(geometry)==1241
    assert sum(row[2]==('S','Concrete') for row in geometry[1:])==1232
    assert sum(row[2]==('S','Rebar') for row in geometry[1:])==8
    proof=dict(Status='PASS_NATIVE_COMPANION_LOAD_GEOMETRY_ALL_ELEMENT_STATES_AND_CONSUMERS',NativeFileValidated=True,Comparisons=comparisons,PlotAndExportConsumerSuffixExact=True,Concrete=1232,Rebar=8,ExcelTables=7,FileTables=17,UpperSummaryTablesSeparatelyCompared=False,UpperTablesValidatedByCurrentNativeLoader=True,PhysicalNumbersNeverRounded=True,NoRecalculation=True,NoHelperImported=True,CompanionSHA256=capture['CompanionSHA256'],ReadySHA256=capture['ReadySHA256'],FingerprintFiles=[dict(Path=str(f),Bytes=len(b),SHA256=hashlib.sha256(b).hexdigest().upper()) for f,b in zip(paths,raw)],CurrentFullSourceSHA256=capture['CurrentFullSourceSHA256'])
    (p/'Parity.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=True))

if __name__=='__main__':main()
