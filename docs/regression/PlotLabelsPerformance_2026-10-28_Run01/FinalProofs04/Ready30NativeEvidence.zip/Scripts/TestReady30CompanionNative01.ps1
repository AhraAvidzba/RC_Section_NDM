# -------------------- ДЛЯ ТЕСТОВ --------------------
# После полного PASS читает архивный File текущим кодом и снимает точные данные Excel/File без пересчёта.
param([Parameter(Mandatory=$true)][string]$LaunchDirectory)
$ErrorActionPreference='Stop'
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$e=Join-Path $root 'docs/regression/PlotLabelsPerformance_2026-10-28_Run01'
$launch=Join-Path $root $LaunchDirectory
$request=Get-Content -LiteralPath (Join-Path $launch 'LaunchRequest.json') -Raw -Encoding UTF8|ConvertFrom-Json
$complete=Get-Content -LiteralPath (Join-Path $root ($request.EvidenceDirectory+'/CompleteCurrentAcceptance.json')) -Raw -Encoding UTF8|ConvertFrom-Json
$closed=Get-Content -LiteralPath (Join-Path $launch 'AllOwnClosuresReviewed.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($complete.Status-cne'PASS'-or$complete.SourceSHA256-cne$request.SourceSHA256-or-not$closed.AllOwnIdentitiesTerminal-or-not$closed.PrimaryLogsReviewed){throw 'Actual full PASS and complete closures required'}
$ready=Get-Content -LiteralPath (Join-Path $e 'Ready30CodePreparation01.json') -Raw -Encoding UTF8|ConvertFrom-Json
$inspection=Get-Content -LiteralPath (Join-Path $e 'Ready30SourceInspection01.json') -Raw -Encoding UTF8|ConvertFrom-Json
if((Get-FileHash -LiteralPath $ready.Ready).Hash-cne$ready.ReadySHA256-or(Get-FileHash -LiteralPath $inspection.CompanionSource).Hash-cne$inspection.CompanionSHA256){throw 'Exact ready/source companion hashes required'}
$dir=Join-Path $PSScriptRoot 'PlotLabelsPerformance_2026-10-28_Run01/Ready30CompanionNative01'
if(Test-Path -LiteralPath $dir){throw 'Fresh evidence required; do not repeat a possibly running process'}
[void][IO.Directory]::CreateDirectory($dir)
$path=Join-Path $dir 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath $ready.Ready -Destination $path
$companion=Join-Path $dir 'Heavy1232_30_Optimized.ndm';Copy-Item -LiteralPath $inspection.CompanionSource -Destination $companion
$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($memory.AvailableMBytes-lt8192-or($memory.CommitLimit-$memory.CommittedBytes)-lt14GB){throw 'RAM/commit reserve insufficient'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCompanionOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$range=$null;$cell=$null;$ownedNew=$false
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Изменяет только выбранную настройку частной копии в памяти; не сохраняет книгу.
function Test-CompanionSetting([string]$Key,[string]$Value){
 $area=$book.Names.Item('rngSystemSettings').RefersToRange;$data=$area.Value2
 for($r=2;$r-le$data.GetLength(0);$r++){if([string]$data[$r,1]-ceq$Key){$target=$area.Cells.Item($r,2);$target.Value2=$Value;return}}
 throw ('Setting missing: '+$Key)
}
try{
 $existing=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object {$_.Id})
 $app=New-Object -ComObject Excel.Application
 [uint32]$nativeId=0;[void][TestCompanionOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$nativeId);$owned=[int]$nativeId
 if($existing-contains$owned){$app=$null;throw 'New own Excel required'};$ownedNew=$true
 $ticks=[string](Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=$ticks;RAMGiB=$memory.AvailableMBytes/1024;CommitFreeGiB=($memory.CommitLimit-$memory.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $dir 'Ownership.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($path,0,$false)
 Test-CompanionSetting 'Results.SnapshotStorage' 'Excel'
 Test-CompanionSetting 'Output.CombinationMode' 'Worst'
 $excel=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestSnapshotReopenFingerprint")
 [IO.File]::WriteAllText((Join-Path $dir 'ExcelFingerprint.txt'),$excel,[Text.Encoding]::UTF8);$excel=$null
 Test-CompanionSetting 'Results.SnapshotName' 'Heavy1232_30_Optimized'
 Test-CompanionSetting 'Results.SnapshotStorage' 'File'
 $file=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.TestSnapshotReopenFingerprint")
 [IO.File]::WriteAllText((Join-Path $dir 'FileFingerprint.txt'),$file,[Text.Encoding]::UTF8);$file=$null
 if((Get-FileHash -LiteralPath $path).Hash-cne$ready.ReadySHA256-or(Get-FileHash -LiteralPath $companion).Hash-cne$inspection.CompanionSHA256){throw 'Read-only-on-disk inputs changed'}
 [ordered]@{Status='NATIVE_FILE_LOADED_AND_FINGERPRINTS_CAPTURED_REVIEW_REQUIRED';CurrentFullSourceSHA256=$request.SourceSHA256;ReadySHA256=$ready.ReadySHA256;CompanionSHA256=$inspection.CompanionSHA256;NoHelperImported=$true;NoRecalculation=$true;NoBookSaved=$true;CanonicalReadyUntouched=$true;FullPass=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $dir 'Capture.json') -Encoding UTF8
 Write-Output 'READY30_COMPANION: current native File loader validated full archive; exact Excel/File fingerprints saved for independent comparison'
}catch{
 [ordered]@{Error=$_.Exception.ToString();Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $dir 'Failure.json') -Encoding UTF8;throw
}finally{
 $range=$null;$cell=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app-and$ownedNew){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$owned;StartTicksUTC=$ticks;QuitRequested=$true;ForceKilled=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $dir 'Quit.json') -Encoding UTF8
}
