"""ДЛЯ ТЕСТОВ: публикует только нативно проверенную книгу30 с сохранёнными архивными данными."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re,shutil,zipfile
root=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
b=Path(__file__).resolve().parent;p=b/'PlotLabelsPerformance_2026-10-28_Run01';e=root/'docs/regression/PlotLabelsPerformance_2026-10-28_Run01'
l=root/'docs/regression/FullSuiteLaunch_2026-10-29_PlotLabels_Run02';f=root/'docs/regression/FullOnOff_2026-10-29_PlotLabels_Run02'
def read(x):return json.loads(x.read_text('utf-8-sig'))
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest().upper()
full=read(f/'CompleteCurrentAcceptance.json');closed=read(l/'AllOwnClosuresReviewed.json');req=read(l/'LaunchRequest.json')
assert full['Status']=='PASS' and full['SourceSHA256']==req['SourceSHA256'] and full['CoreSuites']==182 and full['FocusedSingleCases']==122
assert closed['AllOwnIdentitiesTerminal'] and closed['PrimaryLogsReviewed']
ready=read(e/'Ready30CodePreparation01.json');native=read(p/'Ready30Native01/NativeVerification.json')
assert native['Status']=='PASS_READONLY_READY_CODE_AND_INPUT_INVENTORY' and len(native['Components'])==181
assert read(p/'Ready30Native01/DropdownAcceptance.json')['Status']=='PASS_SAVED_READY_NATIVE_DROPDOWNS'
assert read(p/'Ready30SourceEquality01.json')['Passed'] and read(e/'Ready30OwnClosure01.json')['AllOwnClosed']
export=p/'Ready30Native01/VBA_All_Code.txt';maincode=root/'workbook/output/VBA_All_Code.txt'
def remove_date(x):
 s=x.read_bytes().decode('utf-8-sig');assert len(re.findall(r'(?m)^Date: [^\r\n]*',s))==1
 return re.sub(r'(?m)^Date: [^\r\n]*','Date: <export date>',s)
assert remove_date(export)==remove_date(maincode),'Literal native Main/Ready bodies must match; only export Date differs'
main=root/'workbook/output/RC_Section_NDM.xlsm';assert sha(main)==full['SourceSHA256'] and sha(maincode)==req['AllCodeSHA256']
source=Path(ready['Ready']);assert sha(source)==ready['ReadySHA256']
dest=root/'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm'
assert not dest.exists(),'Canonical ready was deleted before this request; if it reappeared, review current user data before replacing'
other=dest.with_name('RC_Section_NDM_ok.xlsm');assert sha(other)=='31F188692A01CC421A37CF962598778A5AD1FE6D9AB5D96DD41C29389C0919F7'
preserve={x.name:sha(x) for x in dest.parent.iterdir() if x.is_file() and (x.name=='RC_Section_NDM_ok.xlsm' or x.suffix in {'.ndm','.ndms'} or 'execution_report' in x.name)}
shutil.copyfile(source,dest);assert sha(dest)==ready['ReadySHA256']
for name,h in preserve.items():assert sha(dest.parent/name)==h
for name in ['NativeVerification.json','DropdownAcceptance.json','Quit.json','Ownership.json']:shutil.copyfile(p/'Ready30Native01'/name,e/('Ready30'+name))
shutil.copyfile(p/'Ready30SourceEquality01.json',e/'Ready30SourceEquality01.json')
comp=p/'Ready30CompanionNative01';diff=read(comp/'Differences01.json');assert read(comp/'OwnClosure.json')['AllOwnClosed']
decision=dict(Status='HISTORICAL_COMPANION_NOT_MATCHING_NOT_PUBLISHED',Reason='Native snapshots belong to different historical runs; SourceName and contour IEEE bits also differ. Current source code unchanged; no weakening of exact comparison.',Differences=diff,ArchiveFileSHA256=read(comp/'Capture.json')['CompanionSHA256'],NativeCurrentReaderLoadedSuccessfully=True,CanonicalReadyMode='Excel',RequiredByLastBookCodeUpdate=False,Published=False)
(e/'Ready30CompanionDecision01.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2),encoding='utf-8')
proof=dict(Status='PUBLISHED_CURRENT_CODE_REAL_HEAVY_30_ARCHIVE_DATA_PRESERVED',AtUTC=datetime.now(timezone.utc).isoformat(),Path=dest.relative_to(root).as_posix(),SHA256=sha(dest),AcceptedMainSHA256=sha(main),AcceptedMainAllCodeSHA256=sha(maincode),ProductionVBAProjectIdentical=True,NativeComponents=181,NativeBodiesLiteralEqualExceptExportDate=True,SourceEquality=True,Concrete=1232,Rebar=8,LoadIDs=native['LoadIDs'],HistoricalInputErrIDs=native['HistoricalInputErrIDs'],PreservedNonVBAParts=ready['PreservedCount'],Recalculated=False,FullPASSAppliesToMainSHA=full['SourceSHA256'],ReadyOwnFullRunClaim=False,CompanionPublished=False,UserOtherFilesUnchanged=preserve)
(e/'Ready30Publication01.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
readme=dest.parent/'README.txt'
readme.write_text('''Тестовая книга: 1232 бетонных элемента, 8 стержней, 30 исходных сочетаний.

Код обновлён из версии, прошедшей полный набор 182 основных макроса и весь Focused122. Нативно проверены все 181 компонент и выпадающие списки. Основная чистая книга находится на уровень выше.

Исходная геометрия, нагрузки и готовые результаты сохранены из настоящего архивного примера: изменён только VBA, остальные 110 ZIP-частей побайтно сохранены. Нового расчёта 30 сочетаний при обновлении кода не выполнялось. Выбор вывода Worst; хранение Excel, схема включена, пошаговый отчёт выключен, как в исходном примере.

Четыре исторические ошибки ввода исходных нагрузок сохранены: PERF_14, PERF_21, PERF_27, PERF_28. Это не новые ошибки программы. Для собственного замера используйте кнопку «Выполнить расчёт».

Готовые данные находятся на Results. Архивный .ndm относится к другому запуску и не поставляется как соответствующая пара. Существующие пользовательские .ndm/.ndms, книга _ok и execution_report не менялись. Лежащий рядом execution_report не является отчётом этого тяжёлого примера.

Последний отдельный замер 15 пригодных сочетаний на этом тяжёлом сечении: Excel 4,862 с, File 4,153 с, со схемой и сохранением. Это не время 30 сочетаний. Новый результат для 30 сочетаний этой публикацией не заявляется.
''',encoding='utf-8-sig')
print(json.dumps({k:v for k,v in proof.items() if k not in {'LoadIDs','UserOtherFilesUnchanged'}},ensure_ascii=True))
