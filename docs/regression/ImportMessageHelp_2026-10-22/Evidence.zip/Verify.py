"""Verify compiled source, notice ownership, build heights, and both directed test modes."""
from pathlib import Path
import hashlib, json, re, sys
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def modules(path):
    result={}
    for part in re.split(r'(?m)^={100}\nCOMPONENT: ',path.read_text(encoding='utf-8-sig'))[1:]:
        head,body=part.split('='*100+'\n',1)
        result[head.splitlines()[0]]=body.rstrip()
    return result
before=modules(HERE/'ActualBaselineVBA.txt')
after=modules(HERE/'NativeCheckVBA.txt')
assert before.keys()==after.keys()
expected={'CAutoCADSectionModelImporter','modAutoCADStressExport','modWorkbookCalculation',
          'modWorkbookMessages','modTestContourMesh','modTestWorkbookInterface'}
changed={n for n in before if before[n].casefold()!=after[n].casefold()}
assert changed==expected,changed
literal_pattern=r'"(?:[^"\n]|"")*"'
for name in before.keys()-expected:
    # Excel may normalize identifier case across components; literals stay exact.
    assert re.findall(literal_pattern,before[name])==re.findall(literal_pattern,after[name]),name
for name in expected:
    files=[p for d in ('src','tests') for p in (ROOT/d).rglob(name+'.*') if p.suffix in ('.bas','.cls')]
    assert len(files)==1
    source=re.search(r'(?ms)^Option Explicit.*',files[0].read_text(encoding='utf-8-sig')).group().rstrip()
    # VBE drops an explicit Double marker on decimal literals (0.45# -> 0.45).
    canonical=lambda text: re.sub(r'(\d+\.\d+(?:[eE][+-]?\d+)?)#',r'\1',text).casefold()
    assert canonical(source)==canonical(after[name]),name
    assert re.findall(literal_pattern,source)==re.findall(literal_pattern,after[name]),name
assert all('WithConcreteMeshGenerationNotice' not in text for text in after.values())
export=re.search(r'(?ms)^Public Sub ExportSectionStressToAutoCAD\(\).*?^End Sub',after['modAutoCADStressExport']).group()
assert 'ShowWorkbookMessage message, vbInformation' in export
assert not any(s in export for s in ('CONTOUR_MESH_GENERATION_NOTICE','ConcreteMeshSource','ImportComment','ResultMessage'))
calc=re.search(r'(?ms)^Private Function BuildCalculationMessage\(.*?^End Function',after['modWorkbookCalculation']).group()
assert not any(s in calc for s in ('AutoCAD','SourceType','Import','CONTOUR_MESH_GENERATION_NOTICE'))
assert 'importer.ResultMessage(section)' in after['modWorkbookCalculation']
assert 'If model.ConcreteMeshSource = "AutoCADContours" Then' in after['CAutoCADSectionModelImporter']
layout=json.loads((ROOT/'tools/build_workbook/WorkbookLayout.json').read_text(encoding='utf-8-sig'))
rows={r['Row']:r['Height'] for s in layout['Sheets'] if s['Name']=='Справка' for r in s['Rows']}
edit=json.loads((HERE/'NativeEdit.json').read_text(encoding='utf-8-sig'))
for block in edit['Blocks']:
    for row,height in block['Heights'].items(): assert rows[int(row)]==height
tests={}
for mode in ('No','Yes'):
    text=(HERE/f'Directed_{mode}.txt').read_text(encoding='utf-8-sig')
    totals=re.findall(r'(TOTAL_[A-Z_]+): passed=(\d+); failed=(\d+)',text)
    assert len(totals)==2 and all(int(failed)==0 for _,_,failed in totals)
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    assert all('OK: '+key in text for key in ('ui.autocad.run.savedGeometry.message',
        'ui.autocad.run.savedGeometry.noImportText','ui.autocad.run.savedGeometry.noMeshNotice'))
    # ContourMesh writes only failing assertions; verify the executed group includes both checks.
    assert all('Check "'+key+'"' in after['modTestContourMesh'] for key in ('snapshot.importNotice','snapshot.noFalseImportNotice'))
    assert '    CheckSnapshot' in after['modTestContourMesh']
    tests[mode]={name:{'Passed':int(passed),'Failed':int(failed)} for name,passed,failed in totals}
result={'Passed':True,'Components':len(after),'SubstantivelyChangedComponents':sorted(changed),
        'UnchangedComponentsExceptVBEIdentifierCase':len(after)-len(changed),
        'AllSourceStringLiteralsExact':True,'ExportNoticeAbsent':True,'CalculationImportNoticeAbsent':True,
        'FormationNoticePreserved':True,'BuildHelpHeightsMatch':True,'DirectedTests':tests,
        'AllCodeSHA256':hashlib.sha256((HERE/'NativeCheckVBA.txt').read_bytes()).hexdigest().upper()}
(HERE/'Verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
