﻿# ДЛЯ ТЕСТОВ: точечное обновление кода и справки в копии пользовательской книги.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
. (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
$before=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Before.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$baseline=Join-Path $PSScriptRoot 'Baseline.xlsm'
$candidate=Join-Path $PSScriptRoot 'NativeCandidate.xlsm'
if ((Get-FileHash -LiteralPath $baseline).Hash -cne $before.WorkbookSHA256) {throw 'Baseline hash differs.'}
Copy-Item -LiteralPath $baseline -Destination $candidate
$keys=@('DependentRebarRows','CircleGeometry','PointedSectionGeometry','HollowRectangleGeometry','RectanglesGeometry')
$definitions=@(Get-SettingsInstructionCatalog | Where-Object {$_.Key -in $keys})
if ($definitions.Count -ne 5) {throw 'Expected five help blocks.'}
$definitions | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Catalog.json') -Encoding UTF8
$moduleNames=@('CAutoCADSectionModelImporter','modAutoCADStressExport','modWorkbookCalculation','modWorkbookMessages','modTestContourMesh','modTestWorkbookInterface')
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class ImportHelpWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint id);}'
function Export-Code($Book,[string]$Path) {
    $text=New-Object Text.StringBuilder
    [void]$text.AppendLine('VBA PROJECT EXPORT');[void]$text.AppendLine('Workbook: RC_Section_NDM.xlsm')
    [void]$text.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    foreach ($component in $Book.VBProject.VBComponents) {
        $count=[int]$component.CodeModule.CountOfLines
        [void]$text.AppendLine('='*100);[void]$text.AppendLine('COMPONENT: '+$component.Name)
        [void]$text.AppendLine('TYPE: '+$component.Type);[void]$text.AppendLine('LINES: '+$count);[void]$text.AppendLine('='*100)
        if ($count) {[void]$text.AppendLine($component.CodeModule.Lines(1,$count))}
        [void]$text.AppendLine()
    }
    [IO.File]::WriteAllText($Path,$text.ToString(),(New-Object Text.UTF8Encoding($true)))
}
function Export-Preview($Book,$Sheet,[int]$First,[int]$Last,[string]$Path) {
    $Sheet.Activate()
    $range=$Sheet.Range($Sheet.Cells.Item($First,1),$Sheet.Cells.Item($Last,2))
    $range.CopyPicture(1,-4147)
    $scratch=$Book.Application.Workbooks.Add()
    try {
        $chart=$scratch.Worksheets.Item(1).ChartObjects().Add(0,0,[double]$range.Width,[double]$range.Height)
        $chart.Activate();$chart.Chart.Paste()
        if (-not $chart.Chart.Export($Path,'PNG')) {throw 'PNG export failed.'}
    } finally {$scratch.Close($false);$Sheet.Activate()}
}
$excel=$null;$book=$null;$ownedPid=0;$ownedTicks=0
try {
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=3
    [uint32]$id=0;[void][ImportHelpWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    $ownedPid=[int]$id;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks
    Write-Output "OWNED_EXCEL: id=$ownedPid; utcStartTicks=$ownedTicks"
    $book=$excel.Workbooks.Open($candidate,0,$false)
    if ($book.ReadOnly) {throw 'Private candidate is read-only.'}
    $excel.Calculation=-4135;$excel.CalculateBeforeSave=$false
    Export-Code $book (Join-Path $PSScriptRoot 'ActualBaselineVBA.txt')
    foreach ($name in $moduleNames) {
        $file=@(Get-ChildItem -LiteralPath (Join-Path $root 'src'),(Join-Path $root 'tests') -Recurse -File | Where-Object {$_.BaseName -ceq $name -and $_.Extension -in '.bas','.cls'})
        if ($file.Count -ne 1) {throw "Source not unique: $name"}
        $body=[regex]::Match([IO.File]::ReadAllText($file[0].FullName,[Text.Encoding]::UTF8),'(?ms)^Option Explicit.*').Value
        if (-not $body) {throw "Source missing: $name"}
        $module=$book.VBProject.VBComponents.Item($name).CodeModule
        if ($module.CountOfLines) {$module.DeleteLines(1,$module.CountOfLines)}
        $module.AddFromString(($body -split '\r?\n') -join "`r`n")
    }
    $excel.VBE.ActiveVBProject=$book.VBProject
    $compile=$excel.VBE.CommandBars.FindControl(1,578)
    if ($null -eq $compile) {throw 'Compile command unavailable.'}
    if ($compile.Enabled) {$compile.Execute()}
    if ($compile.Enabled) {throw 'VBA compilation failed.'}
    $sheet=$book.Worksheets.Item('Справка');$changes=@();$blocks=@()
    foreach ($item in $definitions) {
        $title=$sheet.Cells.Find([string]$item.Title,$sheet.Cells.Item(1,1),-4163,1,1,1,$false,$false,$false)
        if ($null -eq $title) {throw ('Missing help: '+$item.Title)}
        $first=[int]$title.Row;$last=$first+$item.Lines.Count
        $sheet.Rows.Item("${first}:${last}").Hidden=$false
        for ($i=0;$i -lt $item.Lines.Count;$i++) {
            $row=$first+$i+1
            if ([string]$sheet.Cells.Item($row,1).Value2 -cne [string]($i+1)) {throw 'Paragraph count differs.'}
            $cell=$sheet.Cells.Item($row,2)
            $changes+=,[ordered]@{Address=$cell.Address($false,$false);Before=[string]$cell.Value2;After=[string]$item.Lines[$i]}
            $cell.Value2=[string]$item.Lines[$i]
        }
        $sheet.Rows.Item("$($first+1):${last}").AutoFit() | Out-Null
        $heights=@{};for ($row=$first+1;$row -le $last;$row++) {$heights[[string]$row]=[double]$sheet.Rows.Item($row).RowHeight}
        $blocks+=,[ordered]@{Key=$item.Key;First=$first;Last=$last;Heights=$heights;RelatedKey=$item.RelatedKey}
    }
    $guide=$null;$used=$sheet.UsedRange;$values=$used.Value2
    for ($r=1;$r -le $values.GetLength(0);$r++) {
        if ([string]$values[$r,1] -like '*итоговые сообщения импорта и экспорта*') {
            if ($null -ne $guide) {throw 'Ambiguous AutoCAD guide paragraph.'}
            $guide=$sheet.Cells.Item(($used.Row+$r-1),$used.Column)
        }
    }
    if ($null -eq $guide) {throw 'Old AutoCAD guide paragraph not found.'}
    $guideText='Если бетонная сетка автоматически создана по контурам AutoCAD, сообщение об этом появляется только при формировании сечения. После расчёта и экспорта это сообщение не повторяется. Сведения о происхождении сетки сохраняются на листе Results.'
    $changes+=,[ordered]@{Address=$guide.Address($false,$false);Before=[string]$guide.Value2;After=$guideText}
    $guide.Value2=$guideText
    # Этот абзац короче прежнего и сохраняет прежнюю высоту строки и оформление.
    foreach ($pair in @(@('HollowRectangleGeometry','HollowRectangleHelp.png'),@('DependentRebarRows','AdditionalRebarHelp.png'))) {
        $block=@($blocks | Where-Object Key -eq $pair[0])[0]
        Export-Preview $book $sheet $block.First $block.Last (Join-Path $PSScriptRoot $pair[1])
    }
    $book.Save()
    Export-Code $book (Join-Path $PSScriptRoot 'PreparedVBA.txt')
    [ordered]@{Compiled=$true;SourceSHA256=$before.WorkbookSHA256;Modules=$moduleNames;Changes=$changes;Blocks=$blocks;MainHeadingAddress='A621';OwnPID=$ownedPid;OwnStartTicks=$ownedTicks} |
        ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'NativeEdit.json') -Encoding UTF8
    $book.Close($false);$book=$null
    Write-Output 'NATIVE_CANDIDATE_READY: compiled=True; helpBlocks=5; screenshots=2'
} finally {
    if ($book) {$book.Close($false)}
    if ($excel) {$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if ($ownedPid) {
        $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
        if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks) {Stop-Process -Id $ownedPid -Force}
    }
}
