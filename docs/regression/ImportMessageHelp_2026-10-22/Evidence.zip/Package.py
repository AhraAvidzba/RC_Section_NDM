"""Preserve every saved data/graphic part; replace only help text/heights and compiled VBA."""
from copy import deepcopy
from pathlib import Path
from zipfile import ZipFile
import argparse, hashlib, json, re, sys
from lxml import etree as E

sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
S = '{' + NS['s'] + '}'
sha = lambda b: hashlib.sha256(b).hexdigest().upper()
edit = json.loads((HERE / 'NativeEdit.json').read_text(encoding='utf-8-sig'))
catalog = json.loads((HERE / 'Catalog.json').read_text(encoding='utf-8-sig'))
before = json.loads((HERE / 'Before.json').read_text(encoding='utf-8-sig'))
baseline = HERE / 'Baseline.xlsm'
assert sha(baseline.read_bytes()) == before['WorkbookSHA256'] == edit['SourceSHA256']

def read_book(path):
    with ZipFile(path) as z:
        parts = {i.filename: z.read(i) for i in z.infolist()}
    wb = E.fromstring(parts['xl/workbook.xml'])
    rels = {r.get('Id'): r.get('Target') for r in E.fromstring(parts['xl/_rels/workbook.xml.rels'])}
    sheets = {s.get('name'): 'xl/' + rels[s.get('{' + NS['r'] + '}id')]
              for s in wb.find('s:sheets', NS)}
    strings = [''.join(x.itertext()) for x in E.fromstring(parts['xl/sharedStrings.xml'])]
    return parts, sheets, strings

def values(doc, strings):
    result = {}
    for c in doc.findall('s:sheetData/s:row/s:c', NS):
        if c.get('t') == 'inlineStr':
            result[c.get('r')] = ''.join(c.find('s:is', NS).itertext())
        else:
            v = c.find('s:v', NS)
            result[c.get('r')] = strings[int(v.text)] if c.get('t') == 's' else (v.text if v is not None else '')
    return result

parser = argparse.ArgumentParser()
parser.add_argument('--verify', type=Path)
args = parser.parse_args()
old, sheets, strings = read_book(baseline)
help_part = sheets['Справка']
original = E.fromstring(old[help_part]); doc = deepcopy(original)
old_values = values(original, strings)
cells = {c.get('r'): c for c in doc.findall('s:sheetData/s:row/s:c', NS)}
changes = {c['Address']: c for c in edit['Changes'] if c['Before'] != c['After']}
for address, change in changes.items():
    assert old_values[address] == change['Before'], address
    cell = cells[address]
    for child in list(cell):
        cell.remove(child)
    cell.set('t', 'inlineStr')
    E.SubElement(E.SubElement(cell, S + 'is'), S + 't').text = change['After']
heights = {row: height for b in edit['Blocks'] for row, height in b['Heights'].items()}
for row, height in heights.items():
    target = doc.find(f's:sheetData/s:row[@r="{row}"]', NS)
    target.set('ht', format(height, '.12g')); target.set('customHeight', '1')
new = dict(old)
new[help_part] = E.tostring(doc, encoding='UTF-8', xml_declaration=True, standalone=True)
with ZipFile(HERE / 'NativeCandidate.xlsm') as z:
    new['xl/vbaProject.bin'] = z.read('xl/vbaProject.bin')
target = args.verify or HERE / 'Release/RC_Section_NDM.xlsm'
if not args.verify:
    target.parent.mkdir(exist_ok=True)
    with ZipFile(baseline) as src, ZipFile(target, 'w') as dst:
        for info in src.infolist():
            dst.writestr(info, new[info.filename])
actual, actual_sheets, actual_strings = read_book(target)
assert actual.keys() == old.keys()
changed = [p for p in actual if actual[p] != old[p]]
assert set(changed) == {help_part, 'xl/vbaProject.bin'}, changed
assert all(actual[p] == new[p] for p in actual)
actual_doc = E.fromstring(actual[help_part]); actual_values = values(actual_doc, actual_strings)
assert actual_values.keys() == old_values.keys()
for address, value in old_values.items():
    assert actual_values[address] == (changes[address]['After'] if address in changes else value), address
# Removing permitted edits must restore the original help XML exactly in canonical form.
restored = deepcopy(actual_doc)
restore_cells = {c.get('r'): c for c in restored.findall('s:sheetData/s:row/s:c', NS)}
original_cells = {c.get('r'): c for c in original.findall('s:sheetData/s:row/s:c', NS)}
for address in changes:
    cell = restore_cells[address]; cell.getparent().replace(cell, deepcopy(original_cells[address]))
for row in heights:
    rr = restored.find(f's:sheetData/s:row[@r="{row}"]', NS)
    oo = original.find(f's:sheetData/s:row[@r="{row}"]', NS)
    rr.attrib.clear(); rr.attrib.update(oo.attrib)
assert E.tostring(restored, method='c14n') == E.tostring(original, method='c14n')
for item, block in zip(catalog, edit['Blocks']):
    assert item['Key'] == block['Key']
    for row, line in enumerate(item['Lines'], block['First'] + 1):
        assert actual_values['B' + str(row)] == line
paragraphs = [t for item in catalog for t in item['Lines'] if not t.startswith('Подробнее:')]
assert len(paragraphs) == len(set(paragraphs))
result = {'Passed': True, 'WorkbookSHA256': sha(target.read_bytes()), 'BaselineSHA256': before['WorkbookSHA256'],
          'ChangedParts': changed, 'UnchangedParts': len(old) - len(changed),
          'UserInputsResultsStylesAndGraphicsByteIdentical': True, 'HelpLinksAndStructureUnchanged': True,
          'ChangedHelpCells': len(changes), 'SectionHelpBlocks': 4, 'CommonRebarHelpBlocks': 1,
          'ExactDuplicateDescriptions': 0, 'CompiledVbaSHA256': sha(actual['xl/vbaProject.bin'])}
(HERE / ('PublishedVerification.json' if args.verify else 'Acceptance.json')).write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
if not args.verify:
    layout_path = ROOT / 'tools/build_workbook/WorkbookLayout.json'
    layout = json.loads(layout_path.read_text(encoding='utf-8-sig'))
    sheet = next(s for s in layout['Sheets'] if s['Name'] == 'Справка')
    rows = {r['Row']: r for r in sheet['Rows']}
    for row, height in heights.items():
        assert int(row) in rows
        rows[int(row)]['Height'] = height
    layout_path.write_text(json.dumps(layout, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
