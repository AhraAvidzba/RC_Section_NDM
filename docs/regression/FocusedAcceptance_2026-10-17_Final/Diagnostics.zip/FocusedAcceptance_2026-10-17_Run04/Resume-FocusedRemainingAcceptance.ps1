# Завершает только CAD и независимый контроль после ошибки запуска приложения.
param([Parameter(Mandatory=$true)][string]$EvidenceDirectory,[switch]$FinishCompletedNative)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $root
$directory=(Resolve-Path -LiteralPath $EvidenceDirectory).Path
$runPath=Join-Path $directory 'Run.json'
$run=Get-Content -LiteralPath $runPath -Raw -Encoding UTF8 | ConvertFrom-Json
if($run.Status -ne 'INCOMPLETE_OR_FAILED' -or $run.Records.Count -ne 24 -or @($run.Records|Where-Object {-not $_.Passed}).Count){throw 'Only the complete unchanged VBA stages may be resumed.'}
foreach($item in $run.ProtectedInputs){if((Get-FileHash -LiteralPath $item.Path).Hash -cne $item.SHA256){throw 'Protected source changed.'}}
$backup=Join-Path $directory 'Run.BeforeNativeRecovery.json'
if(Test-Path -LiteralPath $backup){if(-not $FinishCompletedNative){throw 'Recovery evidence already exists.'}}
else {Copy-Item -LiteralPath $runPath -Destination $backup}
$native=Join-Path $directory 'NativeCAD'
$diagnostic=Join-Path $directory 'NativeCAD_Diagnostic'
$allowed=[IO.Path]::GetFullPath($directory)+[IO.Path]::DirectorySeparatorChar
if(-not [IO.Path]::GetFullPath($native).StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase) -or
   -not [IO.Path]::GetFullPath($diagnostic).StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase) -or
   ((Test-Path -LiteralPath $diagnostic) -and -not $FinishCompletedNative)){throw 'Unsafe recovery paths.'}
if(-not $FinishCompletedNative -and (Test-Path -LiteralPath $native)){Move-Item -LiteralPath $native -Destination $diagnostic}
$deadline=[DateTimeOffset]::Parse($run.DeadlineUTC)
$remaining=[int][math]::Floor(($deadline-[DateTimeOffset]::UtcNow).TotalSeconds)-20
if($remaining -lt 30){throw 'Original deadline reached.'}
$python=Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if(-not $FinishCompletedNative){
    & (Join-Path $PSScriptRoot 'Run-FocusedNativeAcceptance.ps1') -SourceWorkbook $run.SourceWorkbook -ReportDirectory ($EvidenceDirectory+'/NativeCAD') -MaxSeconds ([math]::Min(420,$remaining))
}
$nativeStage=Get-Content -LiteralPath (Join-Path $native 'Stage.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if(-not $nativeStage.Passed -or $nativeStage.Results.Count -ne 2){throw 'Native recovery failed.'}
$run.Records+=@{ID='NativeCAD';Kind='NativeCAD';Passed=$true;Report=($EvidenceDirectory+'/NativeCAD/Stage.json')}
$run | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $runPath -Encoding UTF8
& $python (Join-Path $PSScriptRoot 'Verify-FocusedAcceptance.py') --directory $directory --independent
$run.Records+=@{ID='Independent';Kind='Python';Passed=($LASTEXITCODE -eq 0);Report=($EvidenceDirectory+'/Independent.json')}
$run.Status='COMPLETED_PENDING_REVIEW'
$run.FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o')
$run.ElapsedSeconds=([DateTimeOffset]::UtcNow-[DateTimeOffset]::Parse($run.StartedUTC)).TotalSeconds
$run.ProtectedInputsUnchanged=@($run.ProtectedInputs|Where-Object {(Get-FileHash -LiteralPath $_.Path).Hash -cne $_.SHA256}).Count -eq 0
$run | Add-Member NoteProperty InitialInfrastructureError $run.Error -Force
$run.PSObject.Properties.Remove('Error')
$run | Add-Member NoteProperty NativeRecovery @{PreviousRunSHA256=(Get-FileHash -LiteralPath $backup).Hash;Reason='Direct COM activation returns a separate owned application; first-instance ROT lookup was unsuitable.';SameProductionCodeAndInputs=$true;OriginalDeadlinePreserved=$true} -Force
$run | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $runPath -Encoding UTF8
& $python (Join-Path $PSScriptRoot 'Verify-FocusedAcceptance.py') --directory $directory --check
exit $LASTEXITCODE
