# Повторяет один экстремальный случай с двоичным выводом Double, без изменения математики.
param([Parameter(Mandatory=$true)][string]$EvidenceDirectory)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$directory=(Resolve-Path -LiteralPath $EvidenceDirectory).Path
$precision=Join-Path $directory 'Precision'
if(Test-Path -LiteralPath $precision){throw 'Precision evidence exists.'}
[void][IO.Directory]::CreateDirectory($precision)
$source=Join-Path $directory 'Probe/RC_Section_NDM.xlsm'
$path=Join-Path $precision 'RC_Section_NDM.xlsm'
Copy-Item -LiteralPath $source -Destination $path
$excel=$null;$book=$null
try {
 $excel=New-Object -ComObject Excel.Application
 $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AutomationSecurity=1;$excel.EnableCancelKey=0
 $book=$excel.Workbooks.Open($path,0,$false)
 $module=$book.VBProject.VBComponents.Add(1);$module.Name='modExactDoubleProbe'
 $module.CodeModule.AddFromString(@'
Option Explicit
Private Type TNumber
    Value As Double
End Type
Private Type TWords
    Low As Long
    High As Long
End Type
Public Function RawDoubleHex(ByVal value As Double) As String
    Dim number As TNumber, words As TWords
    number.Value = value: LSet words = number
    RawDoubleHex = "F64:" & Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function
'@)
 $code=$book.VBProject.VBComponents.Item('modTestBatchCalculation').CodeModule
 $changed=@()
 for($line=1;$line -le $code.CountOfLines;$line++){
  $text=$code.Lines($line,1)
  if($text -match '^\s*(FocusedExactNumber|FocusedBoundNumber) = '){$name=$Matches[1];$code.ReplaceLine($line,('    '+$name+' = RawDoubleHex(value)'));$changed+=$name}
 }
 if($changed.Count -ne 2){throw 'Only two number-formatting statements must change.'}
 $settings=$book.Names.Item('rngSystemSettings').RefersToRange
 for($row=2;$row -le $settings.Rows.Count;$row++){if([string]$settings.Cells.Item($row,1).Value2 -ceq 'General.DiagramExtension'){$settings.Cells.Item($row,2).Value2='Yes'}}
 $excel.VBE.ActiveVBProject=$book.VBProject;$compile=$excel.VBE.CommandBars.FindControl(1,578)
 if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Precision helper compilation failed.'}
 $model=[string]$excel.Run("'$($book.Name)'!modTestBatchCalculation.DumpFocusedForceBounds",'SavedWorkbook')
 $model | Set-Content -LiteralPath (Join-Path $precision 'Model.txt') -Encoding UTF8
 $body=[string]$excel.Run("'$($book.Name)'!modTestBatchCalculation.RunFocusedAcceptanceCases",'SavedWorkbook','Saved','overloadMixed1000000')
 $body | Set-Content -LiteralPath (Join-Path $precision 'Case.txt') -Encoding UTF8
 if($body -match '(?m)^FAIL:|RUNTIME ERROR|RESTORE ERROR' -or $body -notmatch 'cases=1;[^\r\n]*failed=0'){throw 'Exact case failed.'}
 $book.Save();$book.Close($false);$book=$null
 @{SourceSHA256=(Get-Content -LiteralPath (Join-Path $directory 'Run.json') -Raw -Encoding UTF8|ConvertFrom-Json).SourceSHA256;OriginalProbeSHA256=(Get-FileHash -LiteralPath $source).Hash;ExactProbeSHA256=(Get-FileHash -LiteralPath $path).Hash;ModelSHA256=(Get-FileHash -LiteralPath (Join-Path $precision 'Model.txt')).Hash;CaseSHA256=(Get-FileHash -LiteralPath (Join-Path $precision 'Case.txt')).Hash;ChangedStatements=$changed;CaseID='focused.SavedWorkbook.overloadMixed1000000';Mode='Yes';FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o');ProductionChanged=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $directory 'PrecisionOverride.json') -Encoding UTF8
 'PRECISION_CAPTURE: passed; only two log-format statements changed'
} finally {
 if($book){$book.Close($false)}
 if($excel){$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
