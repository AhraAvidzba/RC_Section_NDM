# ==================== ДЛЯ ТЕСТОВ ====================
# Публикует только проверенное оформление, под блокировкой и с точным сравнением исходных байтов.
$ErrorActionPreference='Stop'
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
foreach($name in @('Preservation.json','TemplatePreservation.json','AfterNativeFonts.json','TemplateNativeFonts.json','UnitsCoverage.json','HeaderUnitsNative.json')){
 if((Get-Content (Join-Path $PSScriptRoot $name) -Raw -Encoding UTF8|ConvertFrom-Json).Status -cne 'PASS'){throw ('Missing PASS '+$name)}
}
$font=Get-Content (Join-Path $PSScriptRoot 'AfterNativeFonts.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($font.HeaderCellsChecked -ne 651 -or $font.Problems.Count -ne 0){throw 'Incomplete native header audit'}
$identities=@{};$records=@()
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*Own.json'){
 $o=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json;$key=[string]$o.PID+'/'+[string]$o.StartTicksUTC;if($identities.ContainsKey($key)){continue};$identities[$key]=$true
 $proc=Get-Process -Id ([int]$o.PID) -ErrorAction SilentlyContinue
 if($proc -and $proc.StartTime.ToUniversalTime().Ticks.ToString() -eq [string]$o.StartTicksUTC){throw ('Own still live '+$key)}
 $cim=@(Get-CimInstance Win32_Process -Filter ('ProcessId='+$o.PID));$t=[long]$o.StartTicksUTC;$t=$t-($t%10)
 if($cim.Count -and $cim[0].Name -ieq 'EXCEL.EXE' -and $cim[0].CreationDate.ToUniversalTime().Ticks -eq $t){throw ('CIM own still live '+$key)}
 $records+=,[ordered]@{PID=$o.PID;StartTicksUTC=$o.StartTicksUTC;State=$(if($proc){'Reused'}else{'Absent'});CIMFresh=$true}
}
if($records.Count -lt 6){throw 'Incomplete own inventory'}
[ordered]@{Status='PASS';Count=$records.Count;Identities=$records;NoForcedClosure=$true}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'AllOwnClosures.json') -Encoding UTF8
function Test-FontSHA([byte[]]$b){$sha=[Security.Cryptography.SHA256]::Create();try{[BitConverter]::ToString($sha.ComputeHash($b)).Replace('-','')}finally{$sha.Dispose()}}
$before=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'UserMainBefore.xlsm'));$after=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'UserFinal.xlsm'))
$book=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$allCode=Join-Path $root 'workbook/output/VBA_All_Code.txt'
if((Get-FileHash -LiteralPath $allCode).Hash -cne (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'AllCodeBefore.txt')).Hash){throw 'AllCode changed'}
$stream=$null;$written=$false
try{
 $stream=[IO.File]::Open($book,'Open','ReadWrite','None');$data=New-Object byte[] $stream.Length;$offset=0
 while($offset -lt $data.Length){$count=$stream.Read($data,$offset,$data.Length-$offset);if($count -le 0){throw 'Unexpected EOF'};$offset+=$count}
 if((Test-FontSHA $data) -cne (Test-FontSHA $before)){throw 'User book changed since backup'}
 $written=$true;$stream.Position=0;$stream.Write($after,0,$after.Length);$stream.SetLength($after.Length);$stream.Flush($true)
}catch{if($stream -and $written){$stream.Position=0;$stream.Write($before,0,$before.Length);$stream.SetLength($before.Length);$stream.Flush($true)};throw}finally{if($stream){$stream.Dispose()}}
if((Get-FileHash -LiteralPath $book).Hash -cne (Test-FontSHA $after)){throw 'Published bytes mismatch'}
[ordered]@{Status='PASS';UserBookSHA256=(Test-FontSHA $after);OriginalSHA256=(Test-FontSHA $before);ChangedFontRuns=8;HeaderCellsAudited=651;UnitsMissing=0;VBAAndAllCodeUnchanged=$true;UserDataPreserved=$true;NoRecalculation=$true}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'Publication.json') -Encoding UTF8
Write-Output 'FONT_PUBLICATION_PASS'
