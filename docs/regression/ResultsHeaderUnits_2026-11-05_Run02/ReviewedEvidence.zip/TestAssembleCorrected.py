"""ДЛЯ ТЕСТОВ: заменяет только VBA и разрешённые шапки; остальные ZIP-части побайтово неизменны."""
from pathlib import Path
import copy,hashlib,json,re,sys,zipfile,xml.etree.ElementTree as E
P=Path(__file__).resolve().parent
R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
sys.path.insert(0,str(P.parent/'PlotLayoutControls_2026-11-03_Run01'))
from TestWorkbookRead import read,targetpart,N,RID
NS=N['m'];E.register_namespace('',NS)
def q(tag):return '{'+NS+'}'+tag
def sha(b):return hashlib.sha256(b).hexdigest().upper()
changes=json.loads((P/'HeaderChanges.json').read_text(encoding='utf8'))
titles=json.loads((P/'TechnicalTitles.json').read_text(encoding='utf8'))
reports=[]
for label in ['User','Template']:
 before=P/'UserMainBefore.xlsm' if label=='User' else R/'docs/regression/PlotLayoutControls_2026-11-03_Run01/FreshBuild05/RC_Section_NDM.xlsm'
 compiled=P/(label+'Compile')/'RC_Section_NDM.xlsm'
 result=P/(label+'Final')/'RC_Section_NDM.xlsm';result.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(before) as z,zipfile.ZipFile(compiled) as native:
  assert not any('signature' in n.lower() for n in z.namelist())
  wb=E.fromstring(z.read('xl/workbook.xml'));rels={x.get('Id'):x.get('Target') for x in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  sh=next(x for x in wb.find('m:sheets',N) if x.get('name')=='Results');part=targetpart('xl/workbook.xml',rels[sh.get(RID)])
  raw=z.read(part);sheet=E.fromstring(raw);ss=E.fromstring(z.read('xl/sharedStrings.xml'))
  cells={c.get('r'):c for c in sheet.findall('m:sheetData/m:row/m:c',N)}
  applied={}
  for address,item in changes.items():
   old=cells.get(address)
   if old is None or old.find('m:v',N) is None:continue
   assert old.get('t')=='s',address
   source=ss[int(old.find('m:v',N).text)]
   text=''.join(source.itertext())
   if label=='User':assert text==item['Before'],(address,text)
   elif text!=item['Before']:
    assert address in ['S155','AN155','BR155','CL155'] and text in titles,(address,text)
    item={'Before':text,'After':titles[text]}
   c=copy.deepcopy(old);c.set('t','inlineStr')
   for child in list(c):c.remove(child)
   inline=E.SubElement(c,q('is'))
   if item['After'].startswith(text):
    for child in source:inline.append(copy.deepcopy(child))
    suffix=item['After'][len(text):]
    t=inline.find('m:t',N)
    if t is not None:t.text=(t.text or '')+suffix
    else:
     run=E.SubElement(inline,q('r'))
     props=copy.deepcopy(next(r.find('m:rPr',N) for r in source.findall('m:r',N) if r.find('m:rPr/m:rFont',N) is not None))
     for vertical in props.findall('m:vertAlign',N):props.remove(vertical)
     E.SubElement(props,q('vertAlign'),{'val':'baseline'});run.append(props)
     E.SubElement(run,q('t')).text=suffix
   else:E.SubElement(inline,q('t')).text=item['After']
   pattern=rb'<c\b[^>]*\br="'+address.encode()+rb'"[^>]*>.*?</c>'
   raw,count=re.subn(pattern,lambda m:E.tostring(c,encoding='utf-8'),raw,flags=re.S)
   assert count==1,address
   applied[address]=item
  assert len(applied)==(12 if label=='User' else 2),(label,len(applied))
  replacements={part:raw,'xl/vbaProject.bin':native.read('xl/vbaProject.bin')}
  with zipfile.ZipFile(result,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
   for info in z.infolist():out.writestr(info,replacements.get(info.filename,z.read(info.filename)))
 with zipfile.ZipFile(before) as a,zipfile.ZipFile(result) as b:
  assert a.namelist()==b.namelist()
  different=[n for n in a.namelist() if a.read(n)!=b.read(n)]
  assert set(different)==set(replacements)
  # После удаления ровно разрешённых ячеек весь лист также совпадает.
  x=E.fromstring(a.read(part));y=E.fromstring(b.read(part))
  for tree in [x,y]:
   for row in tree.findall('m:sheetData/m:row',N):
    for c in list(row):
     if c.get('r') in applied:row.remove(c)
  assert E.tostring(x)==E.tostring(y)
 old=read(before);new=read(result)
 for sheetname,data in old['sheets'].items():
  current=new['sheets'][sheetname]
  for key in ['validations','objects','columns']:assert data[key]==current[key],(sheetname,key)
  original=dict(data['cells']);actual=dict(current['cells'])
  if sheetname=='Results':
   for address,item in applied.items():
    assert actual[address]==('text',item['After'],None),address
    original.pop(address);actual.pop(address)
  assert original==actual,sheetname
 assert old['media']==new['media'] and old['names']==new['names']
 report={'Status':'PASS','Label':label,'OriginalSHA256':sha(before.read_bytes()),'FinalSHA256':sha(result.read_bytes()),'ZipPartsChanged':different,'OnlyAllowedHeaderCellsChanged':list(applied),'AllOtherZipPartsByteExact':True,'AllOtherCellsStylesNamesListsObjectsMediaPreserved':True,'NoRecalculation':True}
 (P/(label+'Preservation.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');reports.append(report)
print(json.dumps(reports,ensure_ascii=False))
