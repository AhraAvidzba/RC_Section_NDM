"""ДЛЯ ТЕСТОВ: независимая размерная карта всех таблиц Results, включая построчные единицы."""
from pathlib import Path
import json,re,sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'PlotLayoutControls_2026-11-03_Run01'))
from TestWorkbookRead import read
b=read(P/'UserFinal.xlsm');d=b['sheets']['Results']['cells'];text=lambda a:d.get(a,(None,'',None))[1]
props={text('U'+str(i)):text('V'+str(i)) for i in range(157,2000) if text('U'+str(i))}
units={key:props['Output.'+key+'Unit'] for key in ['Length','Area','Force','Moment','Stress','Curvature']}
units['Stiffness']=units['Force']+'*'+units['Length']+'2';units['Inertia']=units['Length']+'4';units['Angle']='rad'
expected={}
def add(row,kind,columns):
 for col in columns.split():
  a=col+str(row);assert a not in expected,a;expected[a]=kind
add(10,'Force','AB AE');add(10,'Moment','AC AD AF AG')
add(48,'Force','D G AM');add(48,'Moment','E F H I AN AO');add(48,'Curvature','P Q AG AH');add(48,'Stress','V W X Y');add(48,'Length','Z AA AT AU')
add(84,'Force','D G M P');add(84,'Moment','E F H I Q');add(84,'Area','K AE AX AY');add(84,'Stress','L AM AN BI BJ BK BQ BR');add(84,'Length','AH AI AJ AO AP AT AU AV AW AZ BA BB BL BM')
add(121,'Force','F I L P S AG AP AV BE BQ CC');add(121,'Moment','G H J K M N Q R T U');add(121,'Length','V W X Y Z AA AD AE AF AS AT AU BJ BK BV BW');add(121,'Stiffness','BP CB')
add(156,'Length','D E H I J');add(156,'Area','F');add(156,'Inertia','L M N');add(156,'Angle','K BA CE');add(156,'Stress','AK BN')
records=[]
for a,kind in expected.items():
 value=text(a);unit=units[kind];assert value.endswith(', '+unit),(a,value,unit)
 records.append({'Cell':a,'Text':value,'Quantity':kind,'Unit':unit,'Status':'PASS'})
# Эти числовые столбцы имеют одну физическую размерность, но единица каждой строки хранится явно.
references=[]
for title,columns,owner,unit_column,quantity,token in [
 ('AN155','AT AU AV AW AX AY AZ','AN','BD','Length','LengthUnit'),
 ('BR155','BX BY BZ CA CB CC CD','BR','CH','Length','LengthUnit'),
 ('CL155','CO CP CQ CR','CL','DH','Length','CoordinateUnit'),
 ('CL155','DE','CL','DF','Area','AreaUnit'),
]:
 assert token in text(title),(title,text(title))
 relevant=[]
 rows=sorted({int(re.search(r'\d+$',a)[0]) for a in d if re.sub(r'\d+$','',a)==owner and int(re.search(r'\d+$',a)[0])>156})
 for row in rows:
  if not any(text(c+str(row))!='' for c in columns.split()):continue
  unit=text(unit_column+str(row));assert unit,(owner,row,unit_column)
  if quantity=='Length':assert unit.lower() in ['mm','cm','m'],(unit,row)
  else:assert unit.lower() in ['mm2','cm2','m2'],(unit,row)
  relevant.append(row)
 for col in columns.split():references.append({'Cell':col+'156','Quantity':quantity,'UnitColumn':unit_column,'HeaderReference':title,'DataRowsChecked':len(relevant),'Status':'PASS'})
assert 'Unit' in text('S155') and 'Unit' in text('CL155')
# Value имеет различные физические величины и безразмерные значения; единица определяется столбцом Unit каждой записи.
mixed=[{'Cell':'V156','UnitCell':'W156','Meaning':'Section properties Value / Unit'}, {'Cell':'CV156','UnitCell':'CW156','Meaning':'Annotation Value / Unit'}, {'Cell':'CS156','UnitCell':'DH156','Meaning':'Dimensionless normal, or arc centre with CoordinateUnit'}, {'Cell':'CT156','UnitCell':'DH156','Meaning':'Dimensionless normal, or arc centre with CoordinateUnit'}]
for cell in ['AJ156','BM156']:
 assert text(cell)=='Strain'
dimensionless=[]
for row in [10,48,84,121]:
 for a,value in d.items():
  if int(re.search(r'\d+$',a)[0])!=row or a in expected or value[0]!='text':continue
  if a.startswith(('AI','AJ')) and row==10:continue
  if any(value[1].endswith(', '+u) for u in set(units.values())):raise AssertionError(('Unexpected dimensional header',a,value[1]))
  dimensionless.append({'Cell':a,'Text':value[1],'Meaning':'Dimensionless quantity, status, identifier or descriptive field','Status':'PASS'})
# Восемь технических таблиц покрыты полностью: однородные столбцы, построчные единицы и служебные ключи.
technical_headers={a:v[1] for a,v in d.items() if int(re.search(r'\d+$',a)[0])==156 and v[0]=='text'}
report={'Status':'PASS','NativeHeaderInventory':651,'GroupsReviewed':['Summary','Strength','Cracks_SP35_SP63','Stability_SP35_SP63','Geometry','SectionProperties','MaterialDiagrams','SectionContours','ElementResults','ElementGeometry','Annotations','ElementIndex'],'FixedDimensionalHeaders':records,'PerRowDimensionalHeaders':references,'MixedColumns':mixed,'DimensionlessAndMetadataLabels':dimensionless,'AllTechnicalColumnsReviewed':technical_headers,'MissingUnits':[],'DimensionlessUnitsAdded':False}
(P/'UnitsCoverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('UNITS_COVERAGE_PASS: fixed='+str(len(records))+'; per-row='+str(len(references))+'; technical='+str(len(technical_headers))+'; missing=0')
