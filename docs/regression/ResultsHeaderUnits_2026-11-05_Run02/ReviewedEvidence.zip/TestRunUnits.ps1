﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет пять единиц и внутренний режим на одноразовой книге без сохранения тестового VBA.
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory;if($m.AvailableMBytes/1024 -lt 8 -or ($m.CommitLimit-$m.CommittedBytes)/1GB -lt 14){throw 'Insufficient native reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestUnitsOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object Id);$app=$null;$book=$null;$own=0;$ticks=0
try{
 $app=New-Object -ComObject Excel.Application;[uint32]$id=0;[void][TestUnitsOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($id -le 0 -or $existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;StartTicksUTC=[string]$ticks}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'UnitsTestOwn.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open((Join-Path $PSScriptRoot 'UserFinal.xlsm'),0,$true)
 if(-not $book.ReadOnly){throw 'Readonly required'}
 $module=$book.VBProject.VBComponents.Add(1);$module.Name='modTestHeaderUnits'
 $body=[regex]::Match([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'TestHeaderUnits.bas'),[Text.Encoding]::UTF8),'(?ms)^Option Explicit.*').Value;$module.CodeModule.AddFromString($body)
 $app.VBE.ActiveVBProject=$book.VBProject;$compile=$app.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Test compile failed'}
 $report=[string]$app.Run("'"+$book.Name+"'!modTestHeaderUnits.TestHeaderUnits")
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'HeaderUnitsPrimary.txt'),$report,[Text.UTF8Encoding]::new($true))
 if($report -notmatch '^PASS: 162;'){throw $report}
 [ordered]@{Status='PASS';Assertions=162;Units=@('MPa','kPa','Pa','kgf/cm2','tf/m2','Nothing');NoNDSCalculation=$true;ProductionWritersExercised=$true;TestModuleSaved=$false}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'HeaderUnitsNative.json') -Encoding UTF8
 Write-Output $report
}finally{
 if($own){$proc=Get-Process -Id $own -ErrorAction Stop;if($proc.StartTime.ToUniversalTime().Ticks -ne $ticks){throw 'Owner changed'};if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($book)};if($app){$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
