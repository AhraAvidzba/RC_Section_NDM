"""ДЛЯ ТЕСТОВ: исправляет только оформление восьми текстовых фрагментов, сохраняя все остальные байты."""
from pathlib import Path
import copy,hashlib,json,re,sys,subprocess,zipfile,xml.etree.ElementTree as E
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'PlotLayoutControls_2026-11-03_Run01'))
from TestWorkbookRead import read,N
NS=N['m'];E.register_namespace('',NS)
q=lambda tag:'{'+NS+'}'+tag
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
before=P/'UserMainBefore.xlsm';after=P/'UserFinal.xlsm'
addresses=['V48','W48','X48','Y48','BI84','BJ84','BQ84','BR84']
with zipfile.ZipFile(before) as z:
 part='xl/worksheets/sheet5.xml';raw=z.read(part);sheet=E.fromstring(raw)
 cells={c.get('r'):c for c in sheet.findall('m:sheetData/m:row/m:c',N)}
 for address in addresses:
  c=copy.deepcopy(cells[address]);assert c.get('t')=='inlineStr',address
  runs=c.find('m:is',N).findall('m:r',N);assert runs
  properties=copy.deepcopy(next(r.find('m:rPr',N) for r in runs if r.find('m:rPr/m:rFont',N) is not None))
  assert properties.find('m:rFont',N).get('val')=='Arial' and properties.find('m:sz',N).get('val')=='9'
  for v in properties.findall('m:vertAlign',N):properties.remove(v)
  E.SubElement(properties,q('vertAlign'),{'val':'baseline'})
  bad=[r for r in runs if r.find('m:rPr',N) is not None and r.find('m:rPr/m:rFont',N) is None]
  assert len(bad)==1 and bad[0].find('m:t',N).text==', MPa',address
  bad[0].remove(bad[0].find('m:rPr',N));bad[0].insert(0,properties)
  pattern=rb'<c\b[^>]*\br="'+address.encode()+rb'"[^>]*>.*?</c>'
  raw,count=re.subn(pattern,lambda m:E.tostring(c,encoding='utf-8'),raw,flags=re.S);assert count==1
 with zipfile.ZipFile(after,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
  for info in z.infolist():out.writestr(info,raw if info.filename==part else z.read(info.filename))
with zipfile.ZipFile(before) as a,zipfile.ZipFile(after) as b:
 assert a.namelist()==b.namelist()
 differences=[n for n in a.namelist() if a.read(n)!=b.read(n)];assert differences==[part]
 x=E.fromstring(a.read(part));y=E.fromstring(b.read(part))
 for tree in [x,y]:
  for row in tree.findall('m:sheetData/m:row',N):
   for c in list(row):
    if c.get('r') in addresses:row.remove(c)
 assert E.tostring(x)==E.tostring(y)
assert read(before)==read(after),'Values, formulas, names, lists, drawings or columns changed'
# Публичная чистая книга уже имеет правильный Arial 9 и не содержит этих восьми заполненных строк.
(P/'Template.xlsm').write_bytes(subprocess.check_output(['git','show','HEAD:workbook/output/RC_Section_NDM.xlsm']))
report={'Status':'PASS','OriginalSHA256':sha(before.read_bytes()),'FinalSHA256':sha(after.read_bytes()),'ChangedZIPParts':differences,'ChangedCells':addresses,'OnlyRunFontPropertiesChanged':True,'AllValuesFormulasNamesValidationDrawingsStylesVBAAndOtherPartsUnchanged':True,'NoRecalculation':True,'Font':'Arial','Size':9,'SubscriptsPreserved':True}
(P/'Preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False))
