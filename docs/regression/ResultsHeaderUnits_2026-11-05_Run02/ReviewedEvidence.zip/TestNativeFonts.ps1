﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет фактический шрифт всех непустых шапок и каждого символа исправляемых ячеек; книгу не сохраняет.
param([ValidateSet('Before','After','Template')][string]$Phase)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$path=Join-Path $PSScriptRoot 'UserMainBefore.xlsm';if($Phase -ceq 'After'){$path=Join-Path $PSScriptRoot 'UserFinal.xlsm'}
if($Phase -ceq 'Template'){$path=Join-Path $PSScriptRoot 'TemplateFinal.xlsm'}
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory;if($m.AvailableMBytes/1024 -lt 8 -or ($m.CommitLimit-$m.CommittedBytes)/1GB -lt 14){throw 'Insufficient native reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestHeaderFontOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@([Diagnostics.Process]::GetProcessesByName('EXCEL')|ForEach-Object Id);$app=$null;$book=$null;$own=0;$ticks=0
try{
 $app=New-Object -ComObject Excel.Application;[uint32]$id=0;[void][TestHeaderFontOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($id -le 0 -or $existing -contains [int]$id){throw 'Existing Excel refused'};$own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;StartTicksUTC=[string]$ticks;Phase=$Phase}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot ($Phase+'Own.json')) -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.AutomationSecurity=3;$app.EnableEvents=$false
 $book=$app.Workbooks.Open($path,0,$true);if(-not $book.ReadOnly){throw 'Readonly required'};$sheet=$book.Worksheets.Item('Results')
 $headers=Get-Content (Join-Path $PSScriptRoot 'HeaderCells.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $expectedFonts=Get-Content (Join-Path $PSScriptRoot 'ExpectedHeaderFonts.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $problems=@();$checked=0;$characters=@()
 foreach($item in $headers.PSObject.Properties){
  $cell=$sheet.Range($item.Name);if($Phase -ceq 'Template' -and -not $cell.Value2){continue}
  if($Phase -cne 'Template' -and [string]$cell.Value2 -cne $item.Value){throw ('Header text changed '+$item.Name)}
  $name=[string]$cell.Font.Name;$size=[string]$cell.Font.Size;$checked++
  $expected=$expectedFonts.PSObject.Properties[$item.Name].Value
  if($name -cne $expected.Name -or $size -cne $expected.Size){$problems+=,[ordered]@{Cell=$item.Name;Name=$name;Size=$size;ExpectedName=$expected.Name;ExpectedSize=$expected.Size}}
 }
 if($Phase -cne 'Template'){
  foreach($address in @('V48','W48','X48','Y48','BI84','BJ84','BQ84','BR84')){
   $cell=$sheet.Range($address);$text=[string]$cell.Value2
   for($i=1;$i -le $text.Length;$i++){
    $f=$cell.Characters($i,1).Font;$name=[string]$f.Name;$size=[string]$f.Size
    $characters+=,[ordered]@{Cell=$address;Position=$i;Character=$text.Substring($i-1,1);Name=$name;Size=$size;Subscript=[bool]$f.Subscript}
   }
  }
 }
 [ordered]@{Status=$(if($problems.Count){'FONT_MISMATCH'}else{'PASS'});Phase=$Phase;HeaderCellsChecked=$checked;Problems=$problems;Characters=$characters;NoSave=$true;NoNDSCalculation=$true}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot ($Phase+'NativeFonts.json')) -Encoding UTF8
 if($Phase -ceq 'After' -and $problems.Count){throw 'Remaining header font mismatch'}
 if($Phase -ceq 'Template' -and $problems.Count){throw 'Remaining template header font mismatch'}
 if($Phase -ceq 'After'){
  $app.Visible=$true;$sheet.Activate()
  foreach($area in @('R45:AA50','BG81:BT86')){$sheet.PageSetup.PrintArea=$sheet.Range($area).Address();$sheet.PageSetup.Orientation=2;$sheet.PageSetup.Zoom=$false;$sheet.PageSetup.FitToPagesWide=1;$sheet.PageSetup.FitToPagesTall=1;$sheet.ExportAsFixedFormat(0,(Join-Path $PSScriptRoot ($area.Replace(':','_')+'.pdf')))}
 }
 Write-Output ($Phase+': headers='+$checked+'; font mismatches='+$problems.Count)
}finally{
 if($own){$proc=Get-Process -Id $own -ErrorAction Stop;if($proc.StartTime.ToUniversalTime().Ticks -ne $ticks){throw 'Own identity changed'};if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($book)};if($app){$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}};[GC]::Collect();[GC]::WaitForPendingFinalizers()
}
