"""ДЛЯ ТЕСТОВ: Arial 9 для статических шапок шаблона без смены данных и существующих ID стилей."""
from pathlib import Path
import copy,hashlib,json,re,sys,zipfile,xml.etree.ElementTree as E
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'PlotLayoutControls_2026-11-03_Run01'))
from TestWorkbookRead import read,N
NS=N['m'];E.register_namespace('',NS);q=lambda t:'{'+NS+'}'+t
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
before=P/'Template.xlsm';after=P/'TemplateFinal.xlsm'
with zipfile.ZipFile(before) as z:
 styles=E.fromstring(z.read('xl/styles.xml'));fonts=styles.find('m:fonts',N);xfs=styles.find('m:cellXfs',N)
 old_fonts=[E.tostring(x) for x in fonts];old_xfs=[E.tostring(x) for x in xfs]
 raw=z.read('xl/worksheets/sheet5.xml');sheet=E.fromstring(raw);mapping={};changed=[]
 def colnum(address):
  result=0
  for c in re.match('[A-Z]+',address)[0]:result=result*26+ord(c)-64
  return result
 for c in sheet.findall('m:sheetData/m:row/m:c',N):
  a=c.get('r');row=int(re.search(r'\d+$',a)[0]);col=colnum(a)
  if row not in [155,156] or not (40<=col<=56 or 70<=col<=87):continue
  sid=int(c.get('s','0'))
  if sid not in mapping:
   xf=copy.deepcopy(xfs[sid]);font=copy.deepcopy(fonts[int(xf.get('fontId','0'))]);font.find('m:name',N).set('val','Arial');font.find('m:sz',N).set('val','9')
   for scheme in font.findall('m:scheme',N):font.remove(scheme) # Тема minor переопределяет явное имя и возвращает Calibri в нативном Excel.
   signature=E.tostring(font);fid=next((i for i,f in enumerate(fonts) if E.tostring(f)==signature),None)
   if fid is None:fid=len(fonts);fonts.append(font)
   xf.set('fontId',str(fid));xf.set('applyFont','1');sig=E.tostring(xf);newid=next((i for i,x in enumerate(xfs) if E.tostring(x)==sig),None)
   if newid is None:newid=len(xfs);xfs.append(xf)
   mapping[sid]=newid
  c.set('s',str(mapping[sid]));changed.append(a)
  pattern=rb'<c\b[^>]*\br="'+a.encode()+rb'"[^>]*>'
  def change_style(match):
   tag=match[0];new,count=re.subn(rb'\bs="\d+"',b's="'+c.get('s').encode()+b'"',tag)
   assert count==1,(a,tag)
   return new
  raw,count=re.subn(pattern,change_style,raw);assert count==1,a
 fonts.set('count',str(len(fonts)));xfs.set('count',str(len(xfs)))
 assert [E.tostring(x) for x in fonts[:len(old_fonts)]]==old_fonts
 assert [E.tostring(x) for x in xfs[:len(old_xfs)]]==old_xfs
 # Сохраняем исходную namespace-разметку стилей, заменяя только две расширенные коллекции.
 style_raw=z.read('xl/styles.xml')
 for name,node in [('fonts',fonts),('cellXfs',xfs)]:
  style_raw,count=re.subn(rb'<'+name.encode()+rb'\b[^>]*>.*?</'+name.encode()+rb'>',lambda m:E.tostring(node,encoding='utf-8'),style_raw,flags=re.S);assert count==1
 replacements={'xl/worksheets/sheet5.xml':raw,'xl/styles.xml':style_raw}
 with zipfile.ZipFile(after,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
  for info in z.infolist():out.writestr(info,replacements.get(info.filename,z.read(info.filename)))
with zipfile.ZipFile(before) as a,zipfile.ZipFile(after) as b:
 differences=[n for n in a.namelist() if a.read(n)!=b.read(n)];assert set(differences)==set(replacements)
assert read(before)==read(after),'Template data, objects, names or column styles changed'
report={'Status':'PASS','Font':'Arial','Size':9,'OriginalSHA256':sha(before.read_bytes()),'FinalSHA256':sha(after.read_bytes()),'ChangedParts':differences,'OnlyTwoHeaderBlocksFormatted':True,'ExistingStyleAndFontIDsPreserved':True,'ValuesVBAImagesNamesListsUnchanged':True,'StyledCells':changed,'BuilderRanges':['AN155:BD156','BR155:CI156']}
(P/'TemplatePreservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('TEMPLATE_FONT_FIX_PASS',len(changed))
