Attribute VB_Name = "modTestHeaderUnits"
Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Проверяет настоящие writers на пустом пакете: ни решатель, ни пользовательские данные не используются.
Public Function TestHeaderUnits() As String
    Dim fixture As Workbook, sheet As Worksheet, batch As New CBatchSectionCalculator
    Dim strength As New CStrengthSummaryWriter, cracks As New CCrackSummaryWriter
    Dim settings As New CSystemSettingsReader, units As CUnitSystem, unit As Variant
    Dim cells As Variant, labels As Variant, i As Long, passed As Long, failure As String
    On Error GoTo Failed
    Set fixture = Application.Workbooks.Add(xlWBATWorksheet)
    Set sheet = fixture.Worksheets(1): sheet.Name = "Results"
    fixture.Names.Add "rngStrengthSummaryAnchor", "=Results!$A$49"
    fixture.Names.Add "rngCrackSummaryAnchor", "=Results!$A$85"
    cells = Array("V48", "W48", "X48", "Y48", "BI84", "BJ84", "BQ84", "BR84")
    labels = Array(ChrW$(&H3C3) & "bc", ChrW$(&H3C3) & "bt", ChrW$(&H3C3) & "sc", ChrW$(&H3C3) & "st", _
        ChrW$(&H3C3) & "s,crc", ChrW$(&H3C3) & "s", ChrW$(&H3C3) & "b,max", "Rb,mc2")
    sheet.Range("DA1").Value2 = "Key": sheet.Range("DB1").Value2 = "Value": sheet.Range("DC1").Value2 = "Comment"
    sheet.Range("DA2").Value2 = "Units.Stress.Output"
    For Each unit In Array("MPa", "kPa", "Pa", "kgf/cm2", "tf/m2", "DEFAULT_INTERNAL")
        Set units = Nothing
        If CStr(unit) <> "DEFAULT_INTERNAL" Then
            sheet.Range("DB2").Value2 = CStr(unit)
            settings.LoadFromRange sheet.Range("DA1:DC2")
            Set units = New CUnitSystem: units.LoadFromSettings settings
        End If
        strength.WriteSummary fixture, batch, units
        cracks.WriteSummary fixture, batch, units
        Dim expectedUnit As String: expectedUnit = CStr(unit)
        If expectedUnit = "DEFAULT_INTERNAL" Then expectedUnit = "MPa"
        For i = 0 To UBound(cells)
            If CStr(sheet.Range(cells(i)).Value2) <> labels(i) & ", " & expectedUnit Then Err.Raise 5, , cells(i) & ": wrong unit " & CStr(sheet.Range(cells(i)).Value2)
            passed = passed + 1
            If sheet.Range(cells(i)).Font.Name <> "Arial" Or sheet.Range(cells(i)).Font.Size <> 9 Then Err.Raise 5, , cells(i) & ": header font must be Arial 9"
            passed = passed + 1
            If sheet.Range(cells(i)).Characters(Len(CStr(sheet.Range(cells(i)).Value2)) - Len(expectedUnit) + 1, Len(expectedUnit)).Font.Subscript Then Err.Raise 5, , cells(i) & ": unit must use baseline"
            passed = passed + 1
        Next i
        If sheet.Range("R48").Value2 <> ChrW$(&H3B5) & "bc" Then Err.Raise 5, , "Strain must remain dimensionless"
        If sheet.Range("BC84").Value2 <> ChrW$(&H3C6) & "1" Then Err.Raise 5, , "Coefficient must remain dimensionless"
        If sheet.Range("BS84").Value2 <> "Rb,mc2/" & ChrW$(&H3C3) & "b" Then Err.Raise 5, , "Ratio must remain dimensionless"
        passed = passed + 3
    Next unit
    fixture.Close False
    TestHeaderUnits = "PASS: " & passed & "; units=MPa,kPa,Pa,kgf/cm2,tf/m2,Nothing; solver=0"
    Exit Function
Failed:
    failure = CStr(Err.Number) & ": " & Err.Description
    On Error Resume Next
    If Not fixture Is Nothing Then fixture.Close False
    TestHeaderUnits = "FAIL: " & failure
End Function
