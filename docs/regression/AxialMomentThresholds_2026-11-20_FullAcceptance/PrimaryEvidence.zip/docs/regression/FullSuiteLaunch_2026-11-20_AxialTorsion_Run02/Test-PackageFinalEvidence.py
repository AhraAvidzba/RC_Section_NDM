"""ДЛЯ ТЕСТОВ: сохраняет компактные доказательства приёмки без рабочих книг, снимков и чертежей."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
CORE=ROOT/'docs/regression/FullOnOff_2026-11-20_AxialTorsion_Run02'
TARGET=ROOT/'docs/regression/AxialMomentThresholds_2026-11-20_FullAcceptance'

# -------------------- ДЛЯ ТЕСТОВ --------------------
def test_sha(path):
    """Возвращает отпечаток для проверки извлечённого файла архива."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

# -------------------- ДЛЯ ТЕСТОВ --------------------
def test_package():
    """Включает журналы и управляющие сценарии; проверяет каждый архивированный байт по SHA256."""
    review=json.loads((HERE/'PostprocessCorrectionReview.json').read_text(encoding='utf-8-sig'))
    assert review['Status']=='PASS' and review['ProductionAndWorkbookUnchanged']
    TARGET.mkdir(parents=True,exist_ok=True)
    copies={
        'LaunchRequest.json':HERE/'LaunchRequest.json',
        'OriginalCompletion.json':HERE/'Completion.json',
        'TerminalScopeReview.json':HERE/'TerminalScopeReview.json',
        'AllOwnClosuresReviewed.json':HERE/'AllOwnClosuresReviewed.json',
        'PostprocessCorrectionReview.json':HERE/'PostprocessCorrectionReview.json',
        'Summary.json':CORE/'Summary.json',
        'Run.json':CORE/'Run.json',
        'FocusedRun.json':CORE/'Focused/Run.json',
        'FocusedAcceptance.json':CORE/'Focused/Acceptance.json',
        'Independent.json':CORE/'Focused/Independent.json',
        'CombinedAcceptance.json':CORE/'Focused/CombinedAcceptance.json',
    }
    for name,path in copies.items():
        shutil.copyfile(path,TARGET/name)
        assert test_sha(TARGET/name)==test_sha(path)
    files=sorted(path for directory in (HERE,CORE) for path in directory.rglob('*')
                 if path.is_file() and path.suffix.lower() in ('.txt','.json','.log','.ps1','.py','.bas')
                 and not path.name.endswith('.progress.txt'))
    archive=TARGET/'PrimaryEvidence.zip'
    manifest=[]
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
        for path in files:
            name=path.relative_to(ROOT).as_posix();output.write(path,name)
            manifest.append({'Path':name,'Bytes':path.stat().st_size,'SHA256':test_sha(path)})
    with zipfile.ZipFile(archive) as saved:
        assert saved.testzip() is None
        assert saved.namelist()==[r['Path'] for r in manifest]
        for row in manifest:
            assert hashlib.sha256(saved.read(row['Path'])).hexdigest().upper()==row['SHA256']
    result={'Status':'PASS','Files':manifest,'ArchiveSHA256':test_sha(archive),
            'ArchiveBytes':archive.stat().st_size,
            'Excluded':'All .xlsm/.dwg/.ndm files and repeated progress copies. Frozen source remains local for exact revalidation.',
            'Copies':{name:test_sha(TARGET/name) for name in copies}}
    (TARGET/'ArchiveManifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'Status':result['Status'],'Files':len(files),'ArchiveBytes':result['ArchiveBytes'],'ArchiveSHA256':result['ArchiveSHA256']}))

if __name__=='__main__':test_package()
