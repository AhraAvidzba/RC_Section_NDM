"""ДЛЯ ТЕСТОВ: связывает исправленный разбор с неизменными первичными доказательствами полного запуска."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
CORE=ROOT/'docs/regression/FullOnOff_2026-11-20_AxialTorsion_Run02'

# -------------------- ДЛЯ ТЕСТОВ --------------------
def read_test_json(path):
    """Читает сохранённое доказательство с допустимым BOM PowerShell."""
    return json.loads(path.read_text(encoding='utf-8-sig'))

# -------------------- ДЛЯ ТЕСТОВ --------------------
def test_sha(path):
    """Считает отпечаток фактических байтов без преобразования кодировки."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

# -------------------- ДЛЯ ТЕСТОВ --------------------
def test_review():
    """Проверяет первичные журналы, исходную неуспешную сводку и единственную правку её парсера."""
    request=read_test_json(HERE/'LaunchRequest.json')
    before=read_test_json(HERE/'TerminalScopeReview.json')
    closures=read_test_json(HERE/'AllOwnClosuresReviewed.json')
    original=read_test_json(HERE/'OriginalPostprocess/Summary.json')
    completion=read_test_json(HERE/'Completion.json')
    assert before['PrimaryLogsReviewed'] and before['HEADUnchanged']
    assert before['InventoryErrors']==before['Failures']==before['ChangedInputs']==[]
    assert before['InputsChecked']==closures['InputsChecked']==583
    assert closures['AllOwnIdentitiesTerminal'] and closures['InputsUnchanged']
    assert len(closures['Identities'])==43
    assert test_sha(HERE/'TerminalScopeReview.json')==closures['ScopeReviewSHA256']
    assert test_sha(HERE/'Completion.json')==test_sha(HERE/'OriginalPostprocess/Completion.json')
    assert completion['Status']=='REVIEW_REQUIRED' and not completion['CompleteAcceptancePassed']
    assert original['failedAssertions']==0 and original['errors']==['CurrentFeatures_Off.txt','CurrentFeatures_On.txt']
    invalid=[s for job in original['jobs'] for s in job['suites'] if s['status']!='PASS']
    assert len(invalid)==16 and all(s['status']=='UNVERIFIED_TOTAL' for s in invalid)
    parser='tools/build_workbook/Summarize-GeometryFull.py'
    rows=request['ProtectedInputs']+request['SourceComponents']+request.get('ParticipatingScripts',[])
    changed=[r['Path'] for r in rows if test_sha(ROOT/r['Path'])!=r['SHA256']]
    assert changed==[parser], changed
    old_parser=HERE/'OriginalPostprocess/Summarize-GeometryFull.py'
    assert test_sha(old_parser)==next(r['SHA256'] for r in rows if r['Path']==parser)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==request['SourceCommit']
    for entry in before['Primary']:
        assert entry['AllBytesRead'] and entry['Closed']
        assert test_sha(ROOT/entry['Path'])==entry['SHA256'],entry['Path']
    corrected=read_test_json(CORE/'Summary.json')
    combined=read_test_json(CORE/'Focused/CombinedAcceptance.json')
    assert corrected['status']==combined['Status']=='PASS'
    assert corrected['observedSuites']==corrected['completedSuites']==combined['CoreSuites']==202
    assert corrected['failedAssertions']==0 and not corrected['errors']
    assert combined['FocusedSingleCases']==122 and combined['FocusedPassedAssertions']==14010
    assert combined['SameWorkbookBytes'] and combined['SingleInvocation']
    assert combined['SourceSHA256']==request['SourceSHA256']
    torsion=[]
    for job in corrected['jobs']:
        if job['group']=='CurrentFeatures':
            selected=[s for s in job['suites'] if s['name'].startswith('modTestTorsionPost.')]
            assert len(selected)==8 and sum(s['passed'] for s in selected)==1144
            torsion.append({'Mode':job['mode'],'Suites':selected})
    assert len(torsion)==2
    tests=[]
    for name in ('Test-FullLogTotals.py','Test-FullCoverageVerifier.py','Test-FocusedAcceptanceVerifier.py'):
        process=subprocess.run([sys.executable,'-X','utf8',str(ROOT/'tools/build_workbook'/name),'-v'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
        output=HERE/(name+'.result.txt');output.write_text(process.stdout+process.stderr,encoding='utf-8')
        assert process.returncode==0,process.stderr
        tests.append({'Path':str(output.relative_to(ROOT)).replace('\\','/'),'SHA256':test_sha(output),'ExitCode':0})
    clean=ROOT/'outputs/AxialMomentThresholds_2026-11-19_Run02/FinalClean.xlsm'
    assert test_sha(clean)=='136B8CF8BFBD6F54BEC8CEDF3A9A651786E23A1C5A9D8F70C9FCC77264011B22'
    committed=subprocess.check_output(['git','show',request['SourceCommit']+':workbook/output/RC_Section_NDM.xlsm'],cwd=ROOT)
    assert hashlib.sha256(committed).hexdigest().upper()==test_sha(clean)
    result={
        'Status':'PASS','CheckedUTC':datetime.now(timezone.utc).isoformat(),
        'SourceCommit':request['SourceCommit'],'SourceSHA256':request['SourceSHA256'],
        'OriginalDriverStatusPreserved':completion['Status'],'OriginalUnverifiedTorsionSuites':16,
        'OriginalFailedAssertions':0,'Cause':'Postprocessor recognized TOTAL but not the eight exact named torsion totals.',
        'ChangedFrozenInputsAfterCompletion':changed,'ProductionAndWorkbookUnchanged':True,
        'InputsChecked':len(rows),'PrimaryRecordsUnchanged':len(before['Primary']),
        'OriginalScopeReviewSHA256':test_sha(HERE/'TerminalScopeReview.json'),
        'OriginalClosuresSHA256':test_sha(HERE/'AllOwnClosuresReviewed.json'),
        'OriginalSummarySHA256':test_sha(HERE/'OriginalPostprocess/Summary.json'),
        'OldParserSHA256':test_sha(old_parser),'CorrectedParserSHA256':test_sha(ROOT/parser),
        'ParserTestSHA256':test_sha(ROOT/'tools/build_workbook/Test-FullLogTotals.py'),
        'VerifierTests':tests,'CorrectedSummarySHA256':test_sha(CORE/'Summary.json'),
        'CombinedAcceptanceSHA256':test_sha(CORE/'Focused/CombinedAcceptance.json'),
        'CoreSuites':202,'PrintedSuccessfulCoreAssertionLines':corrected['printedSuccessfulAssertions'],
        'CoreSuiteDeclaredPassedAssertions':combined['CorePassedAssertions'],
        'Counting':'Printed lines and suite counters are separate measures; some suites print only selected assertion lines.',
        'FocusedSingleCases':122,'FocusedPassedAssertions':14010,'Torsion':torsion,
        'AllOwnIdentitiesTerminal':43,'CleanBuildSHA256':test_sha(clean),
        'FinishedUTC':corrected['finishedUTC'],'Deadline':corrected['deadline'],
        'NoCalculationRerun':'All original primary reports are unchanged; only strict reporting was repeated.'
    }
    (HERE/'PostprocessCorrectionReview.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('Torsion','VerifierTests')},ensure_ascii=False))

if __name__=='__main__':test_review()
