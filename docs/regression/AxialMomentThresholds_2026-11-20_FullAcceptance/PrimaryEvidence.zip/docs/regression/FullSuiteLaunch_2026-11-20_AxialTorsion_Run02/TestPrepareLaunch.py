"""ДЛЯ ТЕСТОВ: фиксирует актуальную полную эпоху до запуска; исходники не изменяет."""
from pathlib import Path
import hashlib,json,subprocess
from datetime import datetime,timezone,timedelta
here=Path(__file__).resolve().parent; root=here.parents[2]
def test_sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
request=json.loads((root/'docs/regression/FullSuiteLaunch_2026-11-19_AxialTorsion_Run01/LaunchRequest.json').read_text(encoding='utf-8-sig'))
request['SourceCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
request['SourceSHA256']=test_sha(root/request['SourceWorkbook'])
request['AllCodeSHA256']=test_sha(root/'workbook/output/VBA_All_Code.txt')
request['EvidenceDirectory']='docs/regression/FullOnOff_2026-11-20_AxialTorsion_Run02'
request['PrecedingDirectedFocused']='docs/regression/FocusedAcceptance_2026-11-20_AxialTorsion_Precheck'
request['UserAuthorization']+=' Проверить также вместимость подробной таблицы кручения и адресные рекомендации по вставке строк.'
paths={item['Path'] for item in request['SourceComponents']}
paths.add('src/Excel/CResultsLayoutValidator.cls')
tracked=set(subprocess.check_output(['git','ls-files','-z','--','src','tests','tools'],cwd=root).decode('utf-8').strip('\0').split('\0'))
assert paths==tracked, sorted(paths^tracked)
request['SourceComponents']=[{'Path':path,'SHA256':test_sha(root/path)} for path in sorted(paths)]
request['ProtectedInputs']=[{'Path':item['Path'],'SHA256':test_sha(root/item['Path'])} for item in request['ProtectedInputs']]
assert len(request['SourceComponents'])==578 and len(request['ProtectedInputs'])==5
assert not (root/request['EvidenceDirectory']).exists()
assert request['ExpectedSuites']==202 and request['CoverageVersion']==8 and request['IncludesFocusedAcceptance']
assert datetime.now(timezone.utc)+timedelta(hours=6,minutes=15)<datetime.fromisoformat(request['Deadline'])
target=here/'LaunchRequest.json'; assert not target.exists()
target.write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'Status':'PREPARED_NOT_LAUNCHED','SourceCommit':request['SourceCommit'],'SourceSHA256':request['SourceSHA256'],'AllCodeSHA256':request['AllCodeSHA256'],'Inputs':583,'Suites':202,'FocusedCases':122,'Deadline':request['Deadline']}))
