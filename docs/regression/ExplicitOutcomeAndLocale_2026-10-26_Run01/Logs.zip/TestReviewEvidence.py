# ДЛЯ ТЕСТОВ: полностью читает все первичные culture-журналы; статус JSON один не является PASS.
from pathlib import Path
import json,re,hashlib,decimal
r=Path(__file__).resolve().parents[3];d=Path(__file__).resolve().parent
base=d/'WindowsLocales03';records=[]
expected=['modTestConfiguration.RunExplicitPathOutcomeTests','modTestConfiguration.RunLocaleNumberTests','modTestConfiguration.RunLocaleBoundaryTests','modTestConfiguration.RunLocaleSavedContractTests','modTestBatchCalculation.RunLocaleSP35InterpolationTests','modTestConfiguration.RunAudit03SettingsTableGuardTests','modTestLoadTableConfig.RunLoadActivationTests','modTestLoadTableConfig.RunAudit03LoadTableDiagnosticTests','modTestProfileConfig.RunLocaleDurationTests','modTestProfileConfig.RunStabilityDurationMatchingTests','modTestPlotConfig.RunAudit03SnapshotMetadataTests','modTestCalculationSnapshot.RunCalculationSnapshotTests','modTestRegressionBaseline.RunRegressionBaselineTests']
def read(p):
 b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig')
def baseline(text):
 out={}
 for line in text.splitlines():
  if not line.startswith('BASELINE|'):continue
  parts=line.split('|');fields={}
  for item in parts[2:]:
   k,_,v=item.partition('=')
   if k=='elapsedSec':continue
   try:v=str(decimal.Decimal(v.replace(',','.')).normalize())
   except decimal.InvalidOperation:pass
   fields[k]=v
  out[parts[1]]=fields
 return out
old=baseline(read(r/'docs/regression/FullOnOff_2026-10-26_OOP_Run01/Full_Off.txt'))
for culture in ['en-US','ru-RU']:
 for mode in ['No','Yes']:
  p=base/f'{culture}_{mode}.txt';j=base/f'{culture}_{mode}.json'
  if not p.exists() or not j.exists():raise RuntimeError('Missing primary '+str(p))
  proof=json.loads(j.read_text(encoding='utf-8-sig'));body=read(p)
  actual=re.findall(r'^MACRO_STARTED: (.*?)\|Mode=',body,re.M)
  totals=re.findall(r'^TOTAL[^\r\n]*',body,re.M)
  errors=re.findall(r'^(?:FAIL[: ].*|RUNTIME ERROR.*|RESTORE ERROR.*|CLEANUP ERROR.*)',body,re.M)
  native='0,5' if culture=='ru-RU' else '0.5'
  passed=(proof['Status']=='PASS_ACTUAL_WINDOWS_VBA_LOCALE_DIRECTED' and actual==expected and len(proof['Records'])==13 and all(x['Passed'] for x in proof['Records']) and proof['SourceUnchanged'] and not errors and len(totals)>=13 and all(re.search(r'failed=0(?:\D|$)',x) for x in totals) and proof['VBA'].startswith('CStr='+native+'|Format='+native+'|') and proof['WindowsUserLocale']==culture and baseline(body)==old)
  records.append({'Culture':culture,'Mode':mode,'Passed':passed,'SourceSHA256':proof['SourceSHA256'],'FullPrimaryRead':True,'Bytes':p.stat().st_size,'SHA256':hashlib.sha256(p.read_bytes()).hexdigest().upper(),'MacroOrder':actual,'Totals':totals,'Errors':errors,'VBA':proof['VBA'],'BaselineRecords':len(old),'AllBaselineNumericsEqualExceptElapsed':baseline(body)==old})
restore=json.loads((base/'Restoration.json').read_text(encoding='utf-8-sig'))
passed=all(x['Passed'] for x in records) and restore['Status']=='RESTORED_EXACT'
(d/'WindowsLocalesAcceptance.json').write_text(json.dumps({'Status':'PASS_ACTUAL_BOTH_WINDOWS_VBA_NO_YES' if passed else 'REVIEW_REQUIRED','Records':records,'Restoration':restore,'NewFullPass':False},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'Passed':passed,'Records':len(records),'Macros':sum(len(x['MacroOrder']) for x in records),'BaselineRecordsEach':len(old),'Restore':restore['Status']},ensure_ascii=False))
if not passed:raise SystemExit(1)
