from pathlib import Path
import zipfile,hashlib,json,os
r=Path(__file__).resolve().parents[3];d=Path(__file__).resolve().parent
source=d/'Before_Published.xlsm';candidate=d/'Build04/Candidate/RC_Section_NDM.xlsm';output=r/'workbook/output/RC_Section_NDM.xlsm'
expected='AFF765CB9D7126158534C1752DDF0BEE475C3C3765111C66CFD84B4C4AC38698'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
assert sha(source)==expected and sha(output)==expected,'Published source changed; preserve it and re-evaluate.'
# All chosen profile logs and culture repetitions must be reviewed before publication.
accept=json.loads((d/'Acceptance.json').read_text(encoding='utf-8'))
assert accept['Status']=='PASS_DIRECTED_GOAL_GATES' and accept['CandidateSHA256']==sha(candidate)
temp=output.with_name('RC_Section_NDM_ExplicitOutcome_Packaging.tmp')
with zipfile.ZipFile(source) as original,zipfile.ZipFile(candidate) as updated,zipfile.ZipFile(temp,'w') as result:
 assert original.namelist()==updated.namelist()
 for info in original.infolist():result.writestr(info,updated.read(info.filename) if info.filename=='xl/vbaProject.bin' else original.read(info.filename))
checks=[]
with zipfile.ZipFile(source) as original,zipfile.ZipFile(temp) as result,zipfile.ZipFile(candidate) as updated:
 for name in original.namelist():
  same=original.read(name)==result.read(name);checks.append({'Part':name,'EqualOriginal':same,'VBA':name=='xl/vbaProject.bin'})
 assert len(checks)==107 and all(x['EqualOriginal'] for x in checks if not x['VBA'])
 assert result.read('xl/vbaProject.bin')==updated.read('xl/vbaProject.bin')
os.replace(temp,output)
(d/'PackagePreservation.json').write_text(json.dumps({'Status':'PASS_PACKAGE_ONLY_VBA_CHANGED','BeforeSHA256':expected,'CandidateSHA256':sha(candidate),'PublishedSHA256':sha(output),'PreservedNonVbaParts':106,'Parts':checks},indent=2),encoding='utf-8')
print('Published VBA-only package:',sha(output))
