﻿# ДЛЯ ТЕСТОВ: новая собственная Excel под реальной Windows-локалью, без override разделителей.
param([ValidateSet('en-US','ru-RU')][string]$Culture,[ValidateSet('No','Yes')][string]$Mode)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$source=Join-Path $PSScriptRoot '../Build03/Candidate/RC_Section_NDM.xlsm'
$prefix=Join-Path $PSScriptRoot ($Culture+'_'+$Mode)
if(Test-Path -LiteralPath ($prefix+'.txt')){throw 'Preserve existing primary.'}
$memory=Get-CimInstance Win32_OperatingSystem
if($memory.FreePhysicalMemory*1KB -lt 4GB -or $memory.FreeVirtualMemory*1KB -lt 8GB){throw 'Memory reserve insufficient; no Excel started.'}
$hash=(Get-FileHash -LiteralPath $source).Hash
$before=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
Add-Type 'using System;using System.Text;using System.Runtime.InteropServices;public static class NdmActualLocaleOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);[DllImport("kernel32.dll",CharSet=CharSet.Unicode)]public static extern int GetUserDefaultLocaleName(StringBuilder s,int n);}'
$locale=[Text.StringBuilder]::new(85);[void][NdmActualLocaleOwner]::GetUserDefaultLocaleName($locale,85)
$proof=[ordered]@{Status='STARTED';Culture=$Culture;Mode=$Mode;SourceSHA256=$hash;WindowsUserLocale=$locale.ToString();Registry=(Get-ItemProperty 'HKCU:/Control Panel/International'|Select-Object Locale,LocaleName,sDecimal,sThousand,sList);FreeRAMGiB=$memory.FreePhysicalMemory*1KB/1GB;FreeCommitGiB=$memory.FreeVirtualMemory*1KB/1GB;Records=@()}
$app=$null;$book=$null;$owned=0;$ticks='';$reports=[Text.StringBuilder]::new()
try{
 if($locale.ToString() -cne $Culture){throw 'Actual Windows user locale differs.'}
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NdmActualLocaleOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 $owned=[int]$id;$ticks=[string](Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 if($owned -in $before){throw 'Fresh own Excel required.'}
 $proof.PID=$owned;$proof.StartTicks=$ticks
 $proof|ConvertTo-Json -Depth 6|Set-Content -LiteralPath ($prefix+'.json') -Encoding UTF8
 $oldUseSystem=$app.UseSystemSeparators;$app.UseSystemSeparators=$true
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 $book=$app.Workbooks.Open($source,0,$true)
 if(-not $book.ReadOnly){throw 'Read-only source required.'}
 $probe=[string]$app.Run(("'"+$book.Name+"'!modTestConfiguration.TestActualVbaLocale"))
 $proof.VBA=$probe
 $expected=if($Culture -ceq 'ru-RU'){'0,5'}else{'0.5'}
 if(-not $app.UseSystemSeparators -or $probe -notlike ('CStr='+$expected+'|Format='+$expected+'|*')){throw ('Real VBA locale not changed: '+$probe)}
 [void]$reports.AppendLine('ACTUAL_WINDOWS_VBA: '+$Culture+'|'+$probe)
 $macros=@('modTestConfiguration.RunExplicitPathOutcomeTests','modTestConfiguration.RunLocaleNumberTests','modTestConfiguration.RunLocaleBoundaryTests','modTestConfiguration.RunLocaleSavedContractTests','modTestBatchCalculation.RunLocaleSP35InterpolationTests','modTestConfiguration.RunAudit03SettingsTableGuardTests','modTestLoadTableConfig.RunLoadActivationTests','modTestLoadTableConfig.RunAudit03LoadTableDiagnosticTests','modTestProfileConfig.RunLocaleDurationTests','modTestProfileConfig.RunStabilityDurationMatchingTests','modTestPlotConfig.RunAudit03SnapshotMetadataTests','modTestCalculationSnapshot.RunCalculationSnapshotTests','modTestRegressionBaseline.RunRegressionBaselineTests')
 foreach($macro in $macros){
  $settings=$book.Names.Item('rngSystemSettings').RefersToRange
  for($row=2;$row -le $settings.Rows.Count;$row++){if([string]$settings.Cells($row,1).Value2 -eq 'General.DiagramExtension'){$settings.Cells($row,2).Value2=$Mode;break}}
  [void]$reports.AppendLine('MACRO_STARTED: '+$macro+'|Mode='+$Mode)
  [IO.File]::WriteAllText(($prefix+'.txt'),$reports.ToString(),[Text.UTF8Encoding]::new($true))
  $body=[string]$app.Run(("'"+$book.Name+"'!"+$macro))
  [void]$reports.AppendLine($body)
  $passed=$body -match '(?im)^TOTAL[^\r\n]*failed=0' -and $body -notmatch '(?im)^(FAIL[: ]|RUNTIME ERROR|RESTORE ERROR|CLEANUP ERROR)'
  $proof.Records+=@{Macro=$macro;Mode=$Mode;Passed=$passed}
  [IO.File]::WriteAllText(($prefix+'.txt'),$reports.ToString(),[Text.UTF8Encoding]::new($true))
  $proof|ConvertTo-Json -Depth 6|Set-Content -LiteralPath ($prefix+'.json') -Encoding UTF8
  if(-not $passed){throw ('Profile macro failed: '+$macro)}
 }
 $proof.Status='PASS_ACTUAL_WINDOWS_VBA_LOCALE_DIRECTED'
} catch{$proof.Status='REVIEW_REQUIRED';$proof.Error=$_.Exception.ToString();throw}
finally{
 $p=Get-Process -Id $owned -ErrorAction SilentlyContinue
 if($p -and [string]$p.StartTime.ToUniversalTime().Ticks -ceq $ticks -and $owned -notin $before){if($book){$book.Close($false)};if($app){$app.UseSystemSeparators=$oldUseSystem;$app.Quit()}}
 if($book){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 if($app){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 $proof.SourceUnchanged=(Get-FileHash -LiteralPath $source).Hash -ceq $hash
 $proof.FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o')
 $p=Get-Process -Id $owned -ErrorAction SilentlyContinue
 $proof.OwnIdentityStillLive=($p -and [string]$p.StartTime.ToUniversalTime().Ticks -ceq $ticks)
 $proof|ConvertTo-Json -Depth 6|Set-Content -LiteralPath ($prefix+'.json') -Encoding UTF8
}
