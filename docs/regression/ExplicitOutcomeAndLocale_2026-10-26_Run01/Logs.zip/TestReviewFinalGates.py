# ДЛЯ ТЕСТОВ: проверяет все первичные профильные и mutation-журналы, режимы, SHA и watchdog.
from pathlib import Path
import re,json,hashlib
r=Path(__file__).resolve().parents[3];d=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
records=[]
def inspect(path,count,sourcehash):
 text=path.read_text(encoding='utf-8-sig')
 starts=re.findall(r'^SUITE_STARTED: (.*?); ',text,re.M);ends=re.findall(r'^SUITE_FINISHED: (.*?); ',text,re.M)
 errors=re.findall(r'^(?:FAIL[: ].*|RUNTIME ERROR.*|RESTORE ERROR.*|CLEANUP ERROR.*|WATCHDOG_FAILURE.*)',text,re.M)
 totals=re.findall(r'^TOTAL[^\r\n]*',text,re.M)
 passed=len(starts)==count and starts==ends and not errors and len(totals)>=count and all(re.search(r'failed=0(?:\D|$)',x) for x in totals) and ('SOURCE_SHA256: '+sourcehash) in text and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text and 'SOURCE_UNCHANGED: True' in text
 return {'Primary':str(path.relative_to(r)),'Passed':passed,'Bytes':path.stat().st_size,'SHA256':sha(path),'MacroOrder':starts,'Totals':totals,'Errors':errors,'FullPrimaryRead':True}
finalsha=sha(d/'Build04/Candidate/RC_Section_NDM.xlsm')
for mode in ['No','Yes']:
 path=d/f'Profile01_{mode}.txt';records.append(inspect(path,11,finalsha))
 state=json.loads((d/f'Profile01_{mode}_Run.json').read_text(encoding='utf-8-sig'))
 records[-1]['WrapperExit0']=state['ExitCode']==0 and state['SourceUnchanged']
mutsha=sha(d/'BlankMessages/Candidate/RC_Section_NDM.xlsm')
for mode in ['No','Yes']:
 path=d/f'BlankMessages/Blank01_{mode}.txt';records.append(inspect(path,3,mutsha))
records_ok=all(x['Passed'] and x.get('WrapperExit0',True) for x in records)
old=json.loads((d/'WindowsLocalesAcceptance.json').read_text(encoding='utf-8'))
final=[]
for culture in ['en-US','ru-RU']:
 for mode in ['No','Yes']:
  p=d/f'WindowsLocales04/{culture}_{mode}.txt';text=p.read_text(encoding='utf-8-sig');j=json.loads(p.with_suffix('.json').read_text(encoding='utf-8-sig'))
  totals=re.findall(r'^TOTAL[^\r\n]*',text,re.M);errors=re.findall(r'^(?:FAIL[: ].*|RUNTIME ERROR.*|RESTORE ERROR.*|CLEANUP ERROR.*)',text,re.M)
  native='0,5' if culture=='ru-RU' else '0.5'
  passed=j['Status']=='PASS_ACTUAL_WINDOWS_VBA_LOCALE_DIRECTED' and j['SourceUnchanged'] and j['SourceSHA256']==finalsha and len(j['Records'])==8 and all(x['Passed'] for x in j['Records']) and len(totals)>=8 and not errors and all(re.search(r'failed=0(?:\D|$)',x) for x in totals) and j['WindowsUserLocale']==culture and j['VBA'].startswith('CStr='+native+'|Format='+native+'|')
  final.append({'Culture':culture,'Mode':mode,'Passed':passed,'VBA':j['VBA'],'FullPrimaryRead':True,'Bytes':p.stat().st_size,'SHA256':sha(p),'Totals':totals,'Errors':errors})
restored=json.loads((d/'WindowsLocales04/Restoration.json').read_text(encoding='utf-8-sig'))
passed=records_ok and all(x['Passed'] for x in final) and old['Status']=='PASS_ACTUAL_BOTH_WINDOWS_VBA_NO_YES' and restored['Status']=='RESTORED_EXACT'
result={'Status':'PASS_DIRECTED_GOAL_GATES' if passed else 'REVIEW_REQUIRED','CandidateSHA256':finalsha,'SelectedNoYesProfiles':records[:2],'BlankMessageMutation':records[2:],'ActualFinalCandidateCultures':final,'OriginalCultureSeries':old['Status'],'Restoration':restored,'NoNewVBAComponents':True,'FullOnOffRepeated':False,'OriginalFullPassBookSHA':'AFF765CB9D7126158534C1752DDF0BEE475C3C3765111C66CFD84B4C4AC38698'}
(d/'Acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'Passed':passed,'CandidateSHA256':finalsha,'Profiles':len(records),'Cultures':len(final),'Restore':restored['Status']}))
if not passed:raise SystemExit(1)
