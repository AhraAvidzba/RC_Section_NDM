﻿# ДЛЯ ТЕСТОВ: ограниченное временное переключение Windows culture с независимым восстановлением.
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'InternationalBefore.clixml')){throw 'Existing culture evidence must be preserved.'}
$backup=[ordered]@{Culture=(Get-Culture).Name;UTC=[DateTimeOffset]::UtcNow.ToString('o');Keys=@()}
$paths=@('Control Panel\International')+@(Get-ChildItem 'HKCU:/Control Panel/International' -Recurse|ForEach-Object {$_.Name.Substring('HKEY_CURRENT_USER\'.Length)})
foreach($path in $paths){
 $key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($path)
 $values=@();foreach($name in $key.GetValueNames()){$values+=@{Name=$name;Kind=$key.GetValueKind($name).ToString();Value=$key.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}}
 $backup.Keys+=@{Path=$path;Values=$values};$key.Close()
}
$backup|Export-Clixml -LiteralPath (Join-Path $PSScriptRoot 'InternationalBefore.clixml') -Depth 15
$exe=Join-Path $PSHOME 'powershell.exe';$restore=Join-Path $PSScriptRoot 'Restore-OriginalCulture.ps1';$phase=Join-Path $PSScriptRoot 'TestActualCulture.ps1'
$parentTicks=[string](Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks
$guard=Start-Process -FilePath $exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$restore+'"'),'-Guard','-ParentPID',$PID,'-ParentTicks',$parentTicks) -PassThru
[ordered]@{PID=$PID;StartTicks=$parentTicks;GuardPID=$guard.Id;GuardStartTicks=[string]$guard.StartTime.ToUniversalTime().Ticks;DeadlineMinutes=20}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Owner.json') -Encoding UTF8
try{
 foreach($culture in @('en-US','ru-RU')){
  Set-Culture -CultureInfo $culture
  foreach($mode in @('No','Yes')){
   & $exe -NoProfile -ExecutionPolicy Bypass -File $phase -Culture $culture -Mode $mode
   if($LASTEXITCODE -ne 0){throw ('Directed tests failed under '+$culture+'/'+$mode)}
  }
 }
}finally{& $exe -NoProfile -ExecutionPolicy Bypass -File $restore;if($LASTEXITCODE -ne 0){throw 'Restoration requires review.'}}
