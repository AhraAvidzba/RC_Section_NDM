﻿# ДЛЯ ТЕСТОВ: независимое восстановление сохранённых региональных настроек пользователя.
param([switch]$Guard,[string]$ParentTicks='',[int]$ParentPID=0)
$ErrorActionPreference='Stop'
$backup=Import-Clixml -LiteralPath (Join-Path $PSScriptRoot 'InternationalBefore.clixml')
if($Guard){
 $deadline=[DateTimeOffset]::UtcNow.AddMinutes(20)
 while([DateTimeOffset]::UtcNow -lt $deadline){
  if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'Restored.ok')){exit 0}
  $p=Get-Process -Id $ParentPID -ErrorAction SilentlyContinue
  if(-not $p -or [string]$p.StartTime.ToUniversalTime().Ticks -cne $ParentTicks){break}
  Start-Sleep -Seconds 5
 }
}
Set-Culture -CultureInfo $backup.Culture
foreach($saved in $backup.Keys){
 $key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($saved.Path)
 foreach($name in $key.GetValueNames()){if($name -notin @($saved.Values.Name)){$key.DeleteValue($name,$false)}}
 foreach($value in $saved.Values){$typed=$value.Value
 switch($value.Kind){'Binary'{$typed=[byte[]]$value.Value};'MultiString'{$typed=[string[]]$value.Value};'DWord'{$typed=[int]$value.Value};'QWord'{$typed=[long]$value.Value};default{$typed=[string]$value.Value}}
 $key.SetValue($value.Name,$typed,[Microsoft.Win32.RegistryValueKind]$value.Kind)}
 $key.Close()
}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NdmLocaleBroadcast{[DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]public static extern IntPtr SendMessageTimeout(IntPtr h,uint msg,IntPtr w,string l,uint flags,uint timeout,out IntPtr result);}'
[IntPtr]$result=[IntPtr]::Zero
[void][NdmLocaleBroadcast]::SendMessageTimeout([IntPtr]0xffff,0x1a,[IntPtr]::Zero,'intl',2,2000,[ref]$result)
$checks=@()
foreach($saved in $backup.Keys){
 $key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($saved.Path)
 $same=(@($key.GetValueNames()).Count -eq @($saved.Values).Count)
 foreach($value in $saved.Values){$actual=$key.GetValue($value.Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);if($key.GetValueKind($value.Name).ToString() -cne $value.Kind -or (ConvertTo-Json -InputObject $actual -Compress) -cne (ConvertTo-Json -InputObject $value.Value -Compress)){$same=$false}}
 $checks+=@{Path=$saved.Path;ExactValuesAndKinds=$same};$key.Close()
}
$passed=@($checks|Where-Object {-not $_.ExactValuesAndKinds}).Count -eq 0
[ordered]@{Status=if($passed){'RESTORED_EXACT'}else{'RESTORE_REVIEW_REQUIRED'};Guard=$Guard.IsPresent;CheckedUTC=[DateTimeOffset]::UtcNow.ToString('o');OriginalCulture=$backup.Culture;Keys=$checks}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Restoration.json') -Encoding UTF8
if(-not $passed){throw 'Regional settings restoration mismatch.'}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'Restored.ok'),[DateTimeOffset]::UtcNow.ToString('o'))
