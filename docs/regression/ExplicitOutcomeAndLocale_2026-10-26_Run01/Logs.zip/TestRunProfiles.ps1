﻿# ДЛЯ ТЕСТОВ: один последовательный режим профильной приёмки первого этапа.
param([ValidateSet('No','Yes')][string]$Mode='No',[string]$Label='Probe01',[string]$CandidateRelativePath='Build04/Candidate/RC_Section_NDM.xlsm')
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global -ErrorAction Stop
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$report=Join-Path $PSScriptRoot ($Label+'_'+$Mode+'.txt')
if(Test-Path -LiteralPath $report){throw 'Existing primary report must be preserved.'}
$source=Join-Path $PSScriptRoot $CandidateRelativePath
$sourceHash=(Get-FileHash -LiteralPath $source).Hash
$p=Get-Process -Id $PID
$state=[ordered]@{Status='RUNNING';PID=$PID;StartTicks=[string]$p.StartTime.ToUniversalTime().Ticks;Mode=$Mode;Started=[DateTimeOffset]::Now.ToString('o');SourceSHA256=$sourceHash;Primary=$report;ExitCode=$null}
$statePath=Join-Path $PSScriptRoot ($Label+'_'+$Mode+'_Run.json')
$state|ConvertTo-Json|Set-Content -LiteralPath $statePath -Encoding UTF8
$macros=@('modTestConfiguration.RunExplicitPathOutcomeTests','modTestConfiguration.RunExplicitInputOutcomeTests','modTestProfileConfig.RunExplicitDurationOutcomeTests','modTestConfiguration.RunAudit03UniversalLoadPathTests','modTestBatchCalculation.RunAudit03SP35TableBehaviorTests','modTestCapacitySolver.RunCapacitySolverTests','modTestCrackWidth.RunCrackWidthTests','modTestAudit02Api.RunProgramMessageTests','modTestCalculationSnapshot.RunCalculationSnapshotTests','modTestPlotConfig.RunAudit03SnapshotMetadataTests','modTestRegressionBaseline.RunRegressionBaselineTests')
try{
 & (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') -SourceWorkbook $source -ReportPath $report.Substring($root.Length+1) -Mode $Mode -Macro ($macros -join ',') -TimeoutSeconds 900
 $state.ExitCode=$LASTEXITCODE
 $state.Status=if($LASTEXITCODE -eq 0){'COMPLETED_NEEDS_PRIMARY_REVIEW'}else{'REVIEW_REQUIRED'}
}catch{$state.Status='REVIEW_REQUIRED';$state.Error=$_.Exception.Message;$state.ExitCode=1;throw}
finally{$state.Finished=[DateTimeOffset]::Now.ToString('o');$state.SourceUnchanged=((Get-FileHash -LiteralPath $source).Hash -ceq $sourceHash);$state|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $statePath -Encoding UTF8}
exit $state.ExitCode
