from pathlib import Path
r=Path.cwd()
p=r/"tests/modTestConfiguration.bas"
s=p.read_text(encoding="utf-8")
s+='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет ошибочные значения до оформления пояснений: ошибочный ноль не
' выключает LC, ошибочная отложенная настройка не подменяется default.
Public Function RunExplicitInputOutcomeTests() As String
    Dim stats As TConfigTestStats, fixture As Object, area As Object, reader As CLoadCombinationReader
    Dim settings As CSystemSettingsReader, batch As CBatchSectionCalculator, data(1 To 2, 1 To 7) As Variant
    Dim bad As Variant, code As Long, actual As String, value As Double, row As Long, column As Long
    On Error GoTo Failed
    Set fixture = Application.Workbooks.Add(-4167): fixture.Worksheets(1).Name = "ExplicitInput"
    Set area = fixture.Worksheets(1).Range("D5:J6"): area.NumberFormat = "@"
    data(1, 1) = "CombinationID": data(1, 2) = "N": data(1, 3) = "Mx": data(1, 4) = "My"
    data(1, 5) = "ProfileId": data(1, 6) = "LoadPath": data(1, 7) = "Comment"
    data(2, 1) = "BAD_ZERO": data(2, 5) = "PR1"
    Set reader = New CLoadCombinationReader
    For Each bad In Array(CVErr(2015), "not a number", "1 2")
        data(2, 2) = bad: area.Value2 = data
        Set batch = New CBatchSectionCalculator: reader.LoadFromRange area, batch
        TestCheck stats, "explicitInput.invalidNotZero", batch.Count = 1
        If batch.Count = 1 Then TestCheck stats, "explicitInput.typedInvalid", Not batch.OriginalLoadsAvailable(1)
    Next bad
    data(2, 1) = "": area.Value2 = data
    Set batch = New CBatchSectionCalculator: reader.LoadFromRange area, batch
    TestCheck stats, "explicitInput.blankIdDisabled", batch.Count = 0
    data(2, 1) = "ZERO": data(2, 2) = 0#: data(2, 5) = CVErr(2015): area.Value2 = data
    Set batch = New CBatchSectionCalculator: reader.LoadFromRange area, batch
    TestCheck stats, "explicitInput.exactZeroDisabled", batch.Count = 0
    Set area = fixture.Worksheets(1).Range("A20:D21")
    area.Cells(1, 1).Value2 = "Parameter": area.Cells(1, 2).Value2 = "Value"
    area.Cells(2, 1).Value2 = "Plot.ContourLineWeight": area.Cells(2, 2).Value2 = CVErr(2015)
    Set settings = New CSystemSettingsReader: settings.LoadFromRange area
    On Error Resume Next
    Err.Clear: actual = settings.GetRawString("Plot.ContourLineWeight", "Unexpected default")
    code = Err.Number: Err.Clear
    On Error GoTo Failed
    TestCheck stats, "explicitInput.deferredTypedError", code = vbObjectError + 4309
    On Error Resume Next
    Err.Clear: value = settings.GetDouble("Plot.ContourLineWeight", 999#)
    code = Err.Number: Err.Clear
    On Error GoTo Failed
    TestCheck stats, "explicitInput.noDefaultForFormulaError", code = vbObjectError + 4309
    area.Cells(2, 2).Value2 = 15#: settings.LoadFromRange area
    TestCheck stats, "explicitInput.recovered", settings.GetRequiredDouble("Plot.ContourLineWeight") = 15#
    GoTo Finished
Failed:
    TestCheck stats, "explicitInput.runtime." & Err.Number & "." & Err.Description, False
Finished:
    If Not fixture Is Nothing Then fixture.Close False
    RunExplicitInputOutcomeTests = stats.Report & "TOTAL EXPLICIT INPUT OUTCOME: passed=" & stats.Passed & "; failed=" & stats.Failed
End Function
'''
p.write_text(s,encoding="utf-8",newline="\n")
p=r/"tests/modTestProfileConfig.bas";s=p.read_text(encoding="utf-8-sig")
a="    If localeOnly Then\n        TestDurationInvalidRows"
b="    TestDurationErrorTextOutcome stats, loads, duration, section, provider, settings, units\n"+a
assert a in s;s=s.replace(a,b)
s+='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет исход настоящего duration-reader и batch независимо от текста
' отдельной ошибки; valid/blank строки сохраняют прежние правила.
Private Sub TestDurationErrorTextOutcome(ByRef stats As TProfileStats, ByVal loads As Object, ByVal duration As Object, _
        ByVal section As CSectionModel, ByVal provider As CMaterialModelProvider, _
        ByVal settings As CSystemSettingsReader, ByVal units As CUnitSystem)
    Dim bad As Variant, data As Variant, batch As CBatchSectionCalculator
    For Each bad In Array(CVErr(2015), "not a number", "1 2")
        TestPrepareDurationLoads loads, duration, 1
        data = duration.Value2: data(2, 2) = bad: duration.Value2 = data
        Set batch = TestExecuteFixture(section, provider, settings, units, True)
        TestCheck stats, "explicitInput.durationTypedInvalid", batch.ResultAt(1).StabilityMeta.InternalStatus = rsInvalidInput
        TestCheck stats, "explicitInput.durationNoZeroFallback", Not batch.ResultAt(1).StabilityMeta.Calculated
    Next bad
End Sub
'''
s=s.replace("Optional ByVal localeOnly As Boolean = False) As String", "Optional ByVal localeOnly As Boolean = False, Optional ByVal explicitOutcomeOnly As Boolean = False) As String")
s=s.replace("    TestDurationErrorTextOutcome stats, loads, duration, section, provider, settings, units\n    If localeOnly Then", "    TestDurationErrorTextOutcome stats, loads, duration, section, provider, settings, units\n    If explicitOutcomeOnly Then GoTo Restore\n    If localeOnly Then")
s+='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Короткая независимая проверка машинного исхода чтения дополнительных нагрузок.
Public Function RunExplicitDurationOutcomeTests() As String
    RunExplicitDurationOutcomeTests = RunAudit03DurationConfigTests(explicitOutcomeOnly:=True)
End Function
'''
p.write_text(s,encoding="utf-8",newline="\n")
