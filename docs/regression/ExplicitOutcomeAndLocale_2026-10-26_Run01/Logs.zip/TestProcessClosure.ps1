﻿# ДЛЯ ТЕСТОВ: финальная сверка точных идентичностей всех собственных Excel/контроллеров без закрытия чужих процессов.
$ErrorActionPreference='Stop'
$records=@()
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File -Filter '*.json'){
 if($file.Name -match 'NativeCode|BeforeNative|Requirements|Acceptance|Manifest|Review|ProcessClosure'){continue}
 try{$x=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json}catch{continue}
 $ticks=$null
 if($x.StartTicks){$ticks=[string]$x.StartTicks}elseif($x.StartTicksUtc){$ticks=[string]$x.StartTicksUtc}
 if($x.PID -and $ticks){$records+=@{PID=[int]$x.PID;Ticks=$ticks;Source=$file.Name}}
 if($x.GuardPID -and $x.GuardStartTicks){$records+=@{PID=[int]$x.GuardPID;Ticks=[string]$x.GuardStartTicks;Source=$file.Name+' guard'}}
}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -File -Filter '*.txt'){
 if($file.Name -match 'NativeSnapshot|progress'){continue}
 $line=Select-String -LiteralPath $file.FullName -Pattern '^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)' -Encoding UTF8|Select-Object -First 1
 if($line -and $line.Line -match 'id=(\d+); startTicks=(\d+)'){$records+=@{PID=[int]$Matches[1];Ticks=$Matches[2];Source=$file.Name}}
}
$seen=@{};$checks=@();foreach($x in $records){$identity=[string]$x.PID+'|'+$x.Ticks;if($seen.ContainsKey($identity)){continue};$seen[$identity]=$true;$p=Get-Process -Id $x.PID -ErrorAction SilentlyContinue;$live=[bool]($p -and [string]$p.StartTime.ToUniversalTime().Ticks -ceq $x.Ticks);$checks+=@{PID=$x.PID;UTCStartTicks=$x.Ticks;ExactIdentityLive=$live;Source=$x.Source;Name=if($p){$p.ProcessName}else{''}}}
$user=Get-Process -Id 3712 -ErrorAction SilentlyContinue
$m=Get-CimInstance Win32_OperatingSystem
$passed=@($checks|Where-Object {$_.ExactIdentityLive}).Count -eq 0
[ordered]@{Status=if($passed){'ALL_OWN_IDENTITIES_CLOSED'}else{'REVIEW_LIVE_OWN_IDENTITIES'};CheckedUTC=[DateTimeOffset]::UtcNow.ToString('o');OwnIdentityCount=$checks.Count;Checks=$checks;UserExcelPID=3712;UserExcelUTCStartTicks=if($user){[string]$user.StartTime.ToUniversalTime().Ticks}else{''};UserExcelStoppedByAgent=$false;FreePhysicalGiB=$m.FreePhysicalMemory*1KB/1GB;FreeCommitGiB=$m.FreeVirtualMemory*1KB/1GB}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'ProcessClosure.json') -Encoding UTF8
if(-not $passed){throw 'Recorded own process still alive; observe it before publication.'}
Write-Output ('All own identities closed: '+$checks.Count)
