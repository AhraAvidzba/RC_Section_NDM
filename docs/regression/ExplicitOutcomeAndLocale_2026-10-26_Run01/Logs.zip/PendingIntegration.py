from pathlib import Path
import re
r=Path.cwd()
for name,public,helper,typ,total in [
 ('modTestConfiguration','RunExplicitPathOutcomeTests','TestExplicitPathOutcome','TConfigTestStats','EXPLICIT PATH OUTCOME'),
 ('modTestConfiguration','RunExplicitInputOutcomeTests','TestExplicitInputOutcome','TConfigTestStats','EXPLICIT INPUT OUTCOME'),
 ('modTestBatchCalculation','RunLocaleSP35InterpolationTests','TestLocaleSP35Interpolation','TBatchTestStats','LOCALE SP35 INTERPOLATION')]:
 p=r/'tests'/(name+'.bas');s=p.read_text(encoding='utf-8-sig')
 pattern=r'Public Function '+public+r'\(\) As String\n(.*?)\nEnd Function'
 m=re.search(pattern,s,re.S);assert m,public
 body=m.group(1).replace('    Dim stats As '+typ+', ','    Dim ',1)
 lines=body.splitlines();lines=[x for x in lines if not x.strip().startswith(public+' = ')]
 private='Private Sub '+helper+'(ByRef stats As '+typ+')\n'+'\n'.join(lines)+'\nEnd Sub'
 wrapper="\n\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Отдельный короткий запуск того же контракта, который включён в штатную регрессию.\nPublic Function "+public+'() As String\n    Dim stats As '+typ+'\n    '+helper+' stats\n    '+public+' = stats.Report & "TOTAL '+total+': passed=" & stats.Passed & "; failed=" & stats.Failed\nEnd Function'
 s=s[:m.start()]+private+wrapper+s[m.end():]
 p.write_text(s,encoding='utf-8',newline='\n')
p=r/'tests/modTestConfiguration.bas';s=p.read_text(encoding='utf-8');s=s.replace('    TestCheckUniversalPathMath stats','    TestExplicitPathOutcome stats\n    TestCheckUniversalPathMath stats',1);s=s.replace('    TestAudit03SettingsTableGuards stats','    TestExplicitInputOutcome stats\n    TestAudit03SettingsTableGuards stats',1);p.write_text(s,encoding='utf-8',newline='\n')
p=r/'tests/modTestBatchCalculation.bas';s=p.read_text(encoding='utf-8');a='''    Dim covered As Long
    On Error GoTo Failed
    Set tableRange = ThisWorkbook.Names.Item("rngSP35Table721").RefersToRange''';b='''    Dim covered As Long
    On Error GoTo Failed
    TestLocaleSP35Interpolation stats
    Set tableRange = ThisWorkbook.Names.Item("rngSP35Table721").RefersToRange''';assert a in s;s=s.replace(a,b,1);p.write_text(s,encoding='utf-8',newline='\n')
print('Integrated new contracts into existing standard regression entrypoints; added no components.')
