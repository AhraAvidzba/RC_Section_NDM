"""ДЛЯ ТЕСТОВ: проверяет точный объём изменений кода, пакетов и native-проверок."""
from pathlib import Path
import hashlib
import json
import re

E = Path(__file__).resolve().parent
ROOT = E.parents[2]

def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает собственные сохранённые результаты."""
    return json.loads(path.read_text(encoding='utf-8-sig'))

def TestComponents(path):
    """ДЛЯ ТЕСТОВ: извлекает реальные native-строки без изменения регистра, пробелов или чисел."""
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    result = {}
    for i, line in enumerate(lines):
        if line.startswith('COMPONENT: '):
            name = line[11:]
            count = int(lines[i+2][7:])
            assert name not in result
            result[name] = '\r\n'.join(lines[i+4:i+4+count])
    assert len(result) == 181
    return result

def TestMain():
    """ДЛЯ ТЕСТОВ: не принимает число assertions вместо фактически пройденного состава."""
    old = TestComponents(E / 'Before/workbook/output/VBA_All_Code.txt')
    main = TestComponents(E / 'Native02/Main/VBA_All_Code.txt')
    ready = TestComponents(E / 'Native02/SavedExcelWarm2/VBA_All_Code.txt')
    assert main == ready
    changed = [k for k in old if old[k] != main[k]]
    assert sorted(changed) == sorted(['CAutoCADSectionModelImporter', 'modAutoCADStressExport', 'modTestAutoCADContours']), changed
    closure = TestJSON(E / 'Native02.Watchdog/Completion.json')
    assert closure['Passed'] and not closure['Timeout'] and closure['WorkerExitCode'] == 0
    assert closure['Worker']['State'] == closure['Excel']['State'] == 'Absent'
    for name in ['Main', 'SavedExcelWarm2']:
        source = TestJSON(E / ('Native02/'+name+'/SourceEquality.json'))
        assert source['Passed'] and source['SourceComponents'] == 175 and source['ExportComponents'] == 181
    # Каждый прежний текст алгоритма импортера сохранён в прежнем порядке; добавлены только сообщения/контекст.
    before = (E / 'Before/src/Excel/CAutoCADSectionModelImporter.cls').read_text(encoding='utf-8-sig').splitlines()
    after = iter((ROOT / 'src/Excel/CAutoCADSectionModelImporter.cls').read_text(encoding='utf-8-sig').splitlines())
    assert all(any(candidate == line for candidate in after) for line in before)
    packages = TestJSON(E / 'PackageProof02.json')
    for package in packages:
        assert package['ResultsAndInputsPreserved'] and package['SourceBuildReproducesTexts']
        assert len(package['ChangedParts']) == 4 and len(package['Cells']) == 5
        assert {r['Cell'] for r in package['Cells']} == {'D8', 'D9', 'D25', 'B846', 'B848'}
    native = TestJSON(E / 'NativeCAD04/Acceptance.json')
    watchdog = TestJSON(E / 'NativeCAD04.Watchdog/Completion.json')
    assert native['Passed'] and native['SourcesUnchanged'] and not native['CleanupErrors']
    assert watchdog['Status'] == 'NATIVE_WORKER_COMPLETED_REVIEW_PRIMARY' and not watchdog['TimedOut'] and watchdog['WorkerExitCode'] == 0
    assert not watchdog['OrphansAfterWorkerExit']
    assert not TestJSON(E / 'NativeCAD04.Watchdog/WatchdogCleanup.json')
    total = 0
    primaries = []
    for case in native['Cases']:
        path = Path(case['Primary'])
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest().upper() == case['SHA256']
        text = raw.decode('utf-8-sig')
        assert not re.search(r'^FAIL:', text, re.M) and case['Passed']
        totals = re.findall(r'^TOTAL_([A-Z_]+): passed=(\d+); failed=(\d+)', text, re.M)
        assert totals == ([('AUTOCAD_CONTOURS', '670', '0'), ('NATIVE_GEOMETRY_ONLY', '62', '0'), ('CAD_TEXT', '12', '0')] if case['Case'] == 'Main' else [('CAD_TEXT', '4', '0')])
        if case['Case'] == 'Main':
            for key in ['export.success.', 'export.actualModel.', 'export.geometryWarning.', 'import.sourceName.', 'import.geometry.', 'import.missingLayers.', 'import.emptyIsNotMissing.', 'cleanup.drawingName.', 'import.noDocument.', 'noSolve.']:
                assert 'OK: '+key+case['Mode'] in text
        else:
            assert 'OK: export.calculated' in text and 'сочетание: PERF_01' in text
        passed = sum(int(p) for _, p, _ in totals)
        total += passed
        primaries.append({'Case': case['Case'], 'Mode': case['Mode'], 'SHA256': case['SHA256'], 'Passed': passed, 'Failed': 0})
    assert total == 1492
    result = {'Passed': True, 'Scope': '181 native components and five text cells in each book',
              'ChangedNativeComponents': changed, 'UnchangedNativeComponentsLiteral': 178,
              'MainReady181LiteralEqual': True, 'Source175Plus6Equal': True,
              'AllPreviousImporterLinesPreservedInOrder': True,
              'ResultsAndUserDataBytePreserved': True, 'MainPreservedOtherParts': 103, 'ReadyPreservedOtherParts': 107,
              'NativeOwnClosureVerified': True, 'NativeCADPassed': total, 'NativeCADFailed': 0, 'PrimaryReports': primaries,
              'ConnectionAndWindowBoundariesStubbedOnlyInPrivateFixture': True,
              'OriginalNoDocImportBranchRunWithActualZeroDocuments': True,
              'ExportToModelWhilePaperSpaceActive': True,
              'FullRegressionPass': False}
    (E / 'CodeAndPackageReview.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result))

if __name__ == '__main__':
    TestMain()
