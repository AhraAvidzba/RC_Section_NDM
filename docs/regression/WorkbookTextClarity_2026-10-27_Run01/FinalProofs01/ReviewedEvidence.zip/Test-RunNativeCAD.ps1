# ==========================================================================
# ДЛЯ ТЕСТОВ: короткая проверка текстов настоящего CAD без пользовательских документов.
# ==========================================================================
param([Parameter(Mandatory=$true)][string]$SourceWorkbook,[Parameter(Mandatory=$true)][string]$EvidenceDirectory,[double]$MinimumFreeRAMGiB=8,[double]$MinimumFreeCommitGiB=14)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$source=(Resolve-Path -LiteralPath $SourceWorkbook).Path
$directory=[IO.Path]::GetFullPath($EvidenceDirectory)
if(Test-Path -LiteralPath $directory){throw 'Fresh own evidence required.'}
[void][IO.Directory]::CreateDirectory($directory)
$sourceHash=(Get-FileHash -LiteralPath $source).Hash
$packages=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PackageProof02.json') -Raw -Encoding UTF8|ConvertFrom-Json
$saved=@($packages|Where-Object ID -eq 'SavedExcelWarm2')[0]
$priorExcel=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$priorCAD=@(Get-Process acad -ErrorAction SilentlyContinue|ForEach-Object Id)
$excel=$null;$book=$null;$acad=$null;$excelID=0;$excelTicks=0L;$cadID=0;$cadTicks=0L;$ownCAD=$false;$failure=$null;$cases=@();$cleanup=@()

# -------------------- ДЛЯ ТЕСТОВ --------------------
# Записывает первичные доказательства в собственный каталог.
function Proof([string]$Name,$Value){[IO.File]::WriteAllText((Join-Path $directory $Name),(ConvertTo-Json -InputObject $Value -Depth 12),[Text.UTF8Encoding]::new($true))}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Каждый новый native-процесс требует фактического общего резерва.
function Memory([string]$Name){
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($null -eq$m.AvailableMBytes -or $null -eq$m.CommitLimit -or $null -eq$m.CommittedBytes){throw 'Memory counters unavailable.'}
 $ram=[double]$m.AvailableMBytes/1024;$commit=([double]$m.CommitLimit-[double]$m.CommittedBytes)/1GB
 Proof ('Memory'+$Name+'.json') ([ordered]@{RAMGiB=$ram;CommitGiB=$commit})
 if($ram -lt$MinimumFreeRAMGiB -or $commit -lt$MinimumFreeCommitGiB){throw 'Insufficient memory reserve; no new native process.'}
}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Повторяет только чтение COM-свойства при запуске собственного CAD.
function NativeProperty($Target,[string]$Name){
 for($i=0;$i -lt100;$i++){try{return $Target.GetType().InvokeMember($Name,[Reflection.BindingFlags]::GetProperty,$null,$Target,$null)}catch{if($i -eq99){throw};Start-Sleep -Milliseconds 300}}
}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Перед Quit требует прежнюю пару PID/startTicks; неизвестный процесс не закрывается.
function Exact([int]$ID,[long]$Ticks,[string]$Name){$p=Get-Process -Id $ID -ErrorAction SilentlyContinue;return $p -and $p.ProcessName -ieq$Name -and $p.StartTime.ToUniversalTime().Ticks -eq$Ticks}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Подменяет только внешние границы подключения/окна в собственной копии; математика и форматтер сохраняются.
function Inject($Book){
 $helper=$Book.VBProject.VBComponents.Add(1);$helper.Name='modTestCADText'
 $text=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'TestCADText.bas'),[Text.Encoding]::UTF8)
 $helper.CodeModule.AddFromString([regex]::Match($text,'(?ms)^Option Explicit.*').Value)
 foreach($spec in @(@('modAutoCADStressExport','ConnectToRunningAutoCAD','    Set ConnectToRunningAutoCAD = modTestCADText.TestOwnedCAD'),@('modWorkbookMessages','ShowWorkbookMessage',"    modTestCADText.TestMessage = WorkbookDialogText(message)`r`n    ShowWorkbookMessage = vbOK"))){
  $module=$Book.VBProject.VBComponents.Item($spec[0]).CodeModule
  $body=[string]$module.Lines(1,$module.CountOfLines)
  $pattern='(?ms)(^Public Function '+$spec[1]+'\([^\n]*(?:_\r?\n[^\n]*)*? As [^\r\n]+\r?\n).*?^End Function'
  $match=[regex]::Match($body,$pattern)
  if(-not$match.Success -or ([regex]::Matches($body,$pattern)).Count -ne1){throw ('Unique native seam required: '+$spec[1])}
  $replacement=$match.Groups[1].Value+$spec[2]+"`r`nEnd Function"
  $body=$body.Substring(0,$match.Index)+$replacement+$body.Substring($match.Index+$match.Length)
  $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($body)
 }
 $excel.VBE.ActiveVBProject=$Book.VBProject;$compile=$excel.VBE.CommandBars.FindControl(1,578)
 if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private native seam/helper compilation failed.'}
}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestCADTextOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
public static class TestOwnCADRot {
 [DllImport("ole32.dll")] static extern int GetRunningObjectTable(int n,out IRunningObjectTable r);
 [DllImport("ole32.dll")] static extern int CreateBindCtx(int n,out IBindCtx b);
 public static object Find(string path,out string display) {
  display=null;IRunningObjectTable r=null;IBindCtx b=null;IEnumMoniker e=null;
  try {
   Marshal.ThrowExceptionForHR(GetRunningObjectTable(0,out r));Marshal.ThrowExceptionForHR(CreateBindCtx(0,out b));r.EnumRunning(out e);
   var m=new IMoniker[1];
   while(e.Next(1,m,IntPtr.Zero)==0){
    try{string name;m[0].GetDisplayName(b,null,out name);if(name.IndexOf(path,StringComparison.OrdinalIgnoreCase)>=0){object value;r.GetObject(m[0],out value);display=name;return value;}}
    finally{if(m[0]!=null)Marshal.ReleaseComObject(m[0]);m[0]=null;}
   }
   return null;
  }finally{if(e!=null)Marshal.ReleaseComObject(e);if(b!=null)Marshal.ReleaseComObject(b);if(r!=null)Marshal.ReleaseComObject(r);}
 }
}
'@
try{
 Memory 'BeforeExcel'
 $excel=New-Object -ComObject Excel.Application
 [uint32]$native=0;[void][TestCADTextOwner]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$native);$excelID=[int]$native;$excelTicks=(Get-Process -Id $excelID).StartTime.ToUniversalTime().Ticks
 if($excelID -in$priorExcel){throw 'Fresh own Excel required.'}
 Proof 'Ownership.json' ([ordered]@{ExcelPID=$excelID;ExcelStartTicksUTC=[string]$excelTicks;CADPID=0;CADStartTicksUTC='0';SourceSHA256=$sourceHash})
 $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AskToUpdateLinks=$false
 Memory 'BeforeCAD'
 $bridge=Join-Path $directory 'OwnCADTextBridge.dwg'
 Copy-Item -LiteralPath (Join-Path $root 'docs/regression/GeometryFinalization_2026-10-26_Run01/ImportRotationFormBaseline05/Fixtures/ContoursOnly_Contour.dwg') -Destination $bridge
 $startedCAD=Start-Process -FilePath 'C:\Program Files\Autodesk\AutoCAD 2023\acad.exe' -ArgumentList @('/nologo',('"'+$bridge+'"')) -WindowStyle Hidden -PassThru
 $null=$startedCAD.Handle;$cadID=$startedCAD.Id;$cadTicks=$startedCAD.StartTime.ToUniversalTime().Ticks
 if($cadID -in$priorCAD){throw 'Fresh CAD process required.'};$ownCAD=$true
 Proof 'Ownership.json' ([ordered]@{ExcelPID=$excelID;ExcelStartTicksUTC=[string]$excelTicks;CADPID=$cadID;CADStartTicksUTC=[string]$cadTicks;SourceSHA256=$sourceHash;UserDocumentsUsed=$false})
 $binding=[Diagnostics.Stopwatch]::StartNew()
 while($binding.Elapsed.TotalSeconds -lt90 -and $null -eq$acad){
  $candidate=$null
  try{
   $display='';$bound=[TestOwnCADRot]::Find($bridge,[ref]$display)
   if($null -eq$bound){Start-Sleep -Milliseconds 500;continue}
   $candidate=NativeProperty $bound 'Application'
   [uint32]$native=0;[void][TestCADTextOwner]::GetWindowThreadProcessId([IntPtr][long](NativeProperty $candidate 'HWND'),[ref]$native)
   if([int]$native -eq$cadID -and (Exact $cadID $cadTicks 'acad')){$acad=$candidate;$candidate=$null;Proof 'OwnROTBinding.json' ([ordered]@{OwnPath=$bridge;DisplayName=$display;PID=$cadID;StartTicksUTC=[string]$cadTicks;NoForeignDocumentUsed=$true})}
   [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($bound)
  }catch{}
  if($candidate){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($candidate)}
  if($null -eq$acad){Start-Sleep -Milliseconds 500}
 }
 if($null -eq$acad){throw 'Own CAD not available in ROT; user instance was not used.'}
 if((NativeProperty $acad 'FullName') -cne'C:\Program Files\Autodesk\AutoCAD 2023\acad.exe'){throw 'Unexpected CAD executable.'}
 $acad.Visible=$false
 foreach($spec in @(@('Main',$source,@('No','Yes'),$false),@('Ready',[string]$saved.Path,@('No'),$true))){
  $folder=Join-Path $directory $spec[0];[void][IO.Directory]::CreateDirectory($folder)
  $path=Join-Path $folder 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath $spec[1] -Destination $path
  $excel.AutomationSecurity=3;$book=$excel.Workbooks.Open($path,0,$false);Inject $book
  $book.Save();$book.Close($false);$book=$null
  $excel.AutomationSecurity=1;$book=$excel.Workbooks.Open($path,0,$true)
  foreach($mode in $spec[2]){
   $report=[string]$excel.Run(("'"+$book.Name+"'!modTestCADText.TestRunCADText"),$acad,$folder,[string]$mode,[bool]$spec[3])
   $reportPath=Join-Path $folder ($mode+'.txt');[IO.File]::WriteAllText($reportPath,$report,[Text.UTF8Encoding]::new($true))
   $totals=[regex]::Matches($report,'TOTAL_CAD_TEXT: passed=(\d+); failed=(\d+)')
   $pass=$totals.Count -eq1 -and [int]$totals[0].Groups[2].Value -eq0 -and $report -notmatch'(?m)^FAIL:'
   $cases+=,[ordered]@{Case=$spec[0];Mode=$mode;Passed=$pass;Primary=$reportPath;SHA256=(Get-FileHash -LiteralPath $reportPath).Hash}
   Proof 'Cases.json' $cases
   if(-not$pass){throw 'Native message assertions failed; inspect primary.'}
  }
  $book.Close($false);$book=$null
 }
}catch{$failure=$_.Exception.ToString();Proof 'Failure.json' ([ordered]@{Reason=$failure;Stack=$_.ScriptStackTrace})}
finally{
 if($book){try{$book.Close($false)}catch{$cleanup+=$_.Exception.Message};$book=$null}
 if($ownCAD -and (Exact $cadID $cadTicks 'acad')){try{if($acad){while($acad.Documents.Count -gt0){$acad.Documents.Item(0).Close($false)};$acad.Quit()}}catch{$cleanup+=$_.Exception.Message}}
 if($excelID -gt0 -and (Exact $excelID $excelTicks 'EXCEL')){try{$excel.Quit()}catch{$cleanup+=$_.Exception.Message}}
 if($acad){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($acad);$acad=$null}
 if($excel){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 $grace=[DateTimeOffset]::UtcNow.AddSeconds(10)
 while([DateTimeOffset]::UtcNow -lt$grace -and ((Exact $excelID $excelTicks 'EXCEL') -or (Exact $cadID $cadTicks 'acad'))){Start-Sleep -Milliseconds 200}
}
$unchanged=(Get-FileHash -LiteralPath $source).Hash -ceq$sourceHash -and (Get-FileHash -LiteralPath $saved.Path).Hash -ceq$saved.SHA256
$pass=-not$failure -and $cases.Count -eq3 -and -not$cleanup.Count -and $unchanged
Proof 'Acceptance.json' ([ordered]@{Passed=[bool]$pass;Cases=$cases;Failure=$failure;CleanupErrors=$cleanup;SourcesUnchanged=$unchanged;TestBoundaryOverrides=@('Own CAD connection','Message capture through real formatter');NoProductionHelpersAdded=$true;FullRegressionPass=$false;PostChildClosureRequired=$true})
if(-not$pass){exit 1}
