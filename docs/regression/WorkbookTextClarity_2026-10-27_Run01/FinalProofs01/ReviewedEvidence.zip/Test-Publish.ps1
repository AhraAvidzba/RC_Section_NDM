# -------------------- ДЛЯ ТЕСТОВ --------------------
# Публикует только три проверенных файла, с резервными копиями и защитой от изменения входов.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$review=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'CodeAndPackageReview.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not$review.Passed -or $review.NativeCADPassed -ne1492 -or $review.NativeCADFailed -ne0){throw 'Complete scoped acceptance required.'}
$closure=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'NativeCAD04/OwnClosure.json') -Raw|ConvertFrom-Json
if(@($closure).Count -ne2 -or @($closure|Where-Object State -ne 'Absent').Count){throw 'Native own closure required.'}
$changes=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Changes.json') -Raw -Encoding UTF8|ConvertFrom-Json
foreach($item in $changes|Where-Object AfterSHA256){if((Get-FileHash -LiteralPath (Join-Path $root $item.Path)).Hash -cne$item.AfterSHA256){throw 'Source changed after build/native.'}}
$packages=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PackageProof02.json') -Raw -Encoding UTF8|ConvertFrom-Json
$sources=@($packages[0].Path,$packages[1].Path,(Join-Path $PSScriptRoot 'Native02/Main/VBA_All_Code.txt'))
$destinations=@('workbook/output/RC_Section_NDM.xlsm','workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm','workbook/output/VBA_All_Code.txt')
$stage=Join-Path $PSScriptRoot 'PublishStage02';$backup=Join-Path $PSScriptRoot 'PublicationBackups02'
if((Test-Path -LiteralPath $stage) -or (Test-Path -LiteralPath $backup)){throw 'Fresh publication stage required.'}
[void][IO.Directory]::CreateDirectory($stage);[void][IO.Directory]::CreateDirectory($backup)
$plan=@()
for($i=0;$i -lt3;$i++){
 $relative=$destinations[$i];$destination=Join-Path $root $relative
 $old=@($changes|Where-Object Path -eq $relative)[0].BeforeSHA256
 if((Get-FileHash -LiteralPath $destination).Hash -cne$old){throw ('Published file was changed: '+$relative)}
 $lock=[IO.File]::Open($destination,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$lock.Dispose()
 $staged=Join-Path $stage ([string]$i);Copy-Item -LiteralPath $sources[$i] -Destination $staged
 $plan+=,[ordered]@{Path=$relative;Destination=$destination;Stage=$staged;Backup=(Join-Path $backup ([string]$i));BeforeSHA256=$old;AfterSHA256=(Get-FileHash -LiteralPath $staged).Hash}
}
foreach($item in $plan){
 if((Get-FileHash -LiteralPath $item.Destination).Hash -cne$item.BeforeSHA256){throw 'Published destination changed before replacement.'}
 [IO.File]::Replace($item.Stage,$item.Destination,$item.Backup)
 if((Get-FileHash -LiteralPath $item.Destination).Hash -cne$item.AfterSHA256 -or (Get-FileHash -LiteralPath $item.Backup).Hash -cne$item.BeforeSHA256){throw 'Atomic replacement verification failed.'}
}
[ordered]@{Status='PUBLISHED_SCOPED_TEXT_AND_CAD_MESSAGE_ACCEPTANCE';Files=$plan;DataAndResultsPreserved=$true;NativeCADPassed=1492;NativeCADFailed=0;FullRegressionPass=$false;MainMergePerformed=$false;PublishedUTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 7|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Publication.json') -Encoding UTF8
$plan|Select-Object Path,AfterSHA256|ConvertTo-Json
