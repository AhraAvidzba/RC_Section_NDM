# -------------------- ДЛЯ ТЕСТОВ --------------------
# Готовит read-only проверку двух готовых пакетов; не запускает приложения.
param([string]$PackageProof='PackageProof.json',[string]$PlanFolder='NativePlan',[switch]$ChangedMethods)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
$previous=Join-Path $root 'docs/regression/GeometryFinalization_2026-10-26_Run01'
$native=Join-Path $PSScriptRoot $PlanFolder
[void][IO.Directory]::CreateDirectory((Join-Path $native 'Verifier'))
foreach($name in @('Test-WatchSourceOnly.ps1','Test-RunSourceOnly.ps1')){Copy-Item -LiteralPath (Join-Path $previous ('FinalNativeCodePlan02/'+$name)) -Destination (Join-Path $native $name)}
$verifier=Join-Path $native 'Verifier/Test-VerifyProbeSourceEquality.ps1'
Copy-Item -LiteralPath (Join-Path $previous 'AutoLispWholeExportPrototype01/NativePlanOnePair01/Test-VerifyProbeSourceEquality.ps1') -Destination $verifier
$worker=Join-Path $native 'Test-RunSourceOnly.ps1'
$body=[IO.File]::ReadAllText($worker,[Text.Encoding]::UTF8)
$needle='  $project=$book.VBProject;$count=[int]$project.VBComponents.Count'
if(([regex]::Matches($body,[regex]::Escape($needle))).Count -ne1){throw 'Native insertion point differs.'}
$insert=@'
  # -------------------- ДЛЯ ТЕСТОВ --------------------
  # Проверяет именно сохранённые текстовые ячейки до чтения кода, без исправления книги.
  foreach($cell in $Case.TextCells){
   $sheetIndex=if($cell.Part -eq 'xl/worksheets/sheet1.xml'){1}elseif($cell.Part -eq 'xl/worksheets/sheet3.xml'){3}else{throw 'Unexpected text part.'}
   $value=[string]$book.Worksheets.Item($sheetIndex).Range([string]$cell.Cell).Value2
   if($value -cne[string]$cell.After){throw ('Native text mismatch: '+$Case.ID+'/'+$cell.Cell)}
  }
'@
$body=$body.Replace($needle,$insert+"`r`n"+$needle)
if($ChangedMethods){
 $compare='$allCode=$null;if([string]$Case.ID -ceq''Main''){$allCode=Test-CompareAllCode $export ([string]$plan.PublishedAllCode.Path)}'
 if(-not$body.Contains($compare)){throw 'Exact AllCode comparison insertion differs.'}
 $body=$body.Replace($compare,'$allCode=$null # Actual Main native dump becomes AllCode; scoped raw178 comparison is reviewed separately.')
}
[IO.File]::WriteAllText($worker,$body,[Text.UTF8Encoding]::new($true))
$packages=Get-Content -LiteralPath (Join-Path $PSScriptRoot $PackageProof) -Raw -Encoding UTF8|ConvertFrom-Json
$cases=@(foreach($package in $packages){[ordered]@{ID=$package.ID;Path=$package.Path;SHA256=$package.SHA256;TextCells=$package.Cells}})
$expected=Join-Path $PSScriptRoot 'Expected_AllCode.txt'
[ordered]@{Status='PRIVATE_SOURCE_ONLY_TWO_BOOKS_NO_IMPORT';Cases=$cases;PublishedAllCode=[ordered]@{Path=$expected;SHA256=(Get-FileHash -LiteralPath $expected).Hash};Verifier=[ordered]@{Path=$verifier;SHA256=(Get-FileHash -LiteralPath $verifier).Hash};NoImportCompileSaveRunSettings=$true}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $native 'Plan.json') -Encoding UTF8
