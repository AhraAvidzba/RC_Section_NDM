"""ДЛЯ ТЕСТОВ: сохраняет компактные доказательства восьми требований без нового прогона."""
from pathlib import Path
import hashlib
import json
import zipfile

E = Path(__file__).resolve().parent
ROOT = E.parents[2]

def TestSHA(path):
    """ДЛЯ ТЕСТОВ: проверяет фактический опубликованный файл."""
    h = hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda: f.read(1024*1024), b''):
            h.update(data)
    return h.hexdigest().upper()

def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает итог собственного этапа."""
    return json.loads(path.read_text(encoding='utf-8-sig'))

def TestMain():
    """ДЛЯ ТЕСТОВ: сверяет публикацию и первичные evidence, не присваивая полный PASS."""
    review = TestJSON(E / 'CodeAndPackageReview.json')
    publication = TestJSON(E / 'Publication.json')
    assert review['Passed'] and review['NativeCADPassed'] == 1492 and review['NativeCADFailed'] == 0
    for f in publication['Files']:
        assert TestSHA(ROOT/f['Path']) == f['AfterSHA256']
        assert TestSHA(Path(f['Backup'])) == f['BeforeSHA256']
    assert (ROOT/'workbook/output/VBA_All_Code.txt').read_bytes() == (E/'Native02/Main/VBA_All_Code.txt').read_bytes()
    own = TestJSON(E/'NativeCAD04/OwnClosure.json')
    assert len(own) == 2 and all(p['State'] == 'Absent' for p in own)
    worker = TestJSON(E/'NativeCAD04.Watchdog/WorkerIdentity.json')
    assert worker['RunnerSHA256'] == TestSHA(E/'Test-RunNativeCAD.ps1')
    matrix = [
        {'Requirement': 'Geometry-only reason and outcome wording', 'Passed': True, 'Evidence': 'NativeCAD04/Main/No.txt; Yes.txt; native module'},
        {'Requirement': 'SnapshotStorage explanation', 'Passed': True, 'Evidence': 'Both native Config D8; Catalog/FreshBuild03; PackageProof02'},
        {'Requirement': 'Adaptive faster and coarse boundary after subdivision', 'Passed': True, 'Evidence': 'Both native Config D25, Guide B846/B848; Catalog/FreshBuild03'},
        {'Requirement': 'SnapshotName states .ndm format without automatic-extension phrase', 'Passed': True, 'Evidence': 'Both native Config D9; Catalog/FreshBuild03'},
        {'Requirement': 'Export names actual DWG and ModelSpace for preview and calculated state', 'Passed': True, 'Evidence': 'NativeCAD04/Main/No.txt, Yes.txt, Ready/No.txt; PaperSpace active'},
        {'Requirement': 'Import success names actual source DWG', 'Passed': True, 'Evidence': 'NativeCAD04/Main/No.txt; Yes.txt'},
        {'Requirement': 'Missing-layer/cleanup messages name DWG without confusing empty layers', 'Passed': True, 'Evidence': 'NativeCAD04/Main/No.txt; Yes.txt'},
        {'Requirement': 'Clear no-open-document import error before geometry', 'Passed': True, 'Evidence': 'NativeCAD04/Main/No.txt; Yes.txt; actual own CAD Documents.Count=0'}
    ]
    result = {'Status': 'PASS_SCOPED_TEXT_AND_CAD_MESSAGES_ONLY', 'Requirements': matrix,
              'SourceFilesChanged': 4, 'NativeComponents': 181, 'LiteralUnchangedNativeComponents': 178,
              'Source175Plus6VerifiedInBothBooks': True, 'FreshBuildAndCompile': 'FreshBuild03',
              'NativeCAD': {'Passed': 1492, 'Failed': 0, 'OwnQuitNoKillInAcceptedRun': True},
              'OutputFiles': [{'Path': f['Path'], 'SHA256': f['AfterSHA256']} for f in publication['Files']],
              'MainPreservedParts': 103, 'ReadyPreservedParts': 107,
              'UserDataAndReadyResultsPreserved': True, 'FullRunAuthorizedOrStarted': False,
              'OriginalFullReviewRequiredRetained': True, 'MainMergePerformed': False,
              'ForeignExecutionReportsAndOutputsExcluded': True}
    out = E/'FinalProofs01'
    out.mkdir()
    processed = out/'Processed.json'
    processed.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    selected = [E/x for x in ['Changes.json', 'TextMap.json', 'FreshBuild03.Build.json', 'Build03Closure.json',
                'PackageProof02.json', 'CodeAndPackageReview.json', 'Publication.json',
                'Native02/Main/VBA_All_Code.txt', 'Native02/Main/SourceEquality.json',
                'Native02/SavedExcelWarm2/SourceEquality.json', 'Native02/RawNativeComponentComparison.json',
                'Native02.Watchdog/Completion.json', 'NativeCAD04/Main/No.txt', 'NativeCAD04/Main/Yes.txt',
                'NativeCAD04/Ready/No.txt', 'NativeCAD04/Acceptance.json', 'NativeCAD04/OwnClosure.json',
                'NativeCAD04/OwnROTBinding.json', 'NativeCAD04/Ownership.json', 'NativeCAD04/MemoryBeforeExcel.json',
                'NativeCAD04/MemoryBeforeCAD.json', 'NativeCAD04.Watchdog/WorkerIdentity.json',
                'NativeCAD04.Watchdog/Completion.json', 'NativeCAD04.Watchdog/WatchdogCleanup.json',
                'TestCADText.bas', 'Test-RunNativeCAD.ps1', 'Test-Build.ps1', 'Test-Package.py',
                'Test-SetupNative.ps1', 'Test-Review.py', 'Test-Publish.ps1', 'Test-Finalize.py']]
    for trial in ['NativeCAD01','NativeCAD02','NativeCAD03']:
        for suffix in ['/Failure.json','.Watchdog/Completion.json','.Watchdog/WatchdogCleanup.json','/Main/No.txt']:
            path = E/(trial+suffix)
            if path.exists(): selected.append(path)
    selected.append(processed)
    archive = out/'ReviewedEvidence.zip'
    manifest = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in selected:
            name = str(path.relative_to(E)).replace('\\','/')
            z.write(path,name)
            manifest.append({'Path': name, 'Bytes': path.stat().st_size, 'SHA256': TestSHA(path)})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(manifest)
        for item in manifest:
            assert hashlib.sha256(z.read(item['Path'])).hexdigest().upper() == item['SHA256']
    (out/'ArchiveManifest.json').write_text(json.dumps({'ArchiveSHA256': TestSHA(archive), 'ArchiveBytes': archive.stat().st_size,
        'Count': len(manifest), 'Files': manifest}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'Status': result['Status'], 'Requirements': len(matrix), 'AssertionsPassed': 1492,
                      'ArchiveFiles': len(manifest), 'ArchiveBytes': archive.stat().st_size, 'ArchiveSHA256': TestSHA(archive)}))

if __name__ == '__main__':
    TestMain()
