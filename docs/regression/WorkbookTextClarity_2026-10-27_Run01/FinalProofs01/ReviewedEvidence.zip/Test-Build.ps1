# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет каталог и выполняет чистую сборку с компиляцией в отдельном каталоге.
param([ValidatePattern('^FreshBuild[0-9]+$')][string]$Label='FreshBuild01')
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne 5){throw 'Windows PowerShell5.1 required.'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
. (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
$changes=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Changes.json') -Raw -Encoding UTF8|ConvertFrom-Json
$map=@()
foreach($pair in @($changes|Where-Object Path -eq 'tools/build_workbook/SettingsCatalog.ps1').Replacements){
 $map+=,[ordered]@{Before=[string]$pair.Before;After=[string]$pair.After;Kind=$(if($map.Count -lt3){'Config'}else{'Guide'})}
}
$map|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'TextMap.json') -Encoding UTF8
$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$ram=[double]$memory.AvailableMBytes/1024;$commit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
[ordered]@{RAMGiB=$ram;CommitGiB=$commit;MinimumRAMGiB=8;MinimumCommitGiB=14}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'MemoryBeforeBuild.json') -Encoding UTF8
if($null -eq$memory -or $ram -lt8 -or $commit -lt14){throw 'Insufficient actual memory reserve.'}
$output='docs/regression/WorkbookTextClarity_2026-10-27_Run01/'+$Label+'/RC_Section_NDM.xlsm'
if(Test-Path -LiteralPath (Split-Path -Parent $output)){throw 'Fresh directory required.'}
$started=[DateTimeOffset]::UtcNow.ToString('o')
. (Join-Path $root 'tools/build_workbook/Build-Workbook.ps1') -OutputPath $output -FormulaImageDirectory ('docs/regression/WorkbookTextClarity_2026-10-27_Run01/'+$Label+'/FormulaImages')
$proofName=if($Label -eq'FreshBuild01'){'Build.json'}else{$Label+'.Build.json'}
[ordered]@{Status='FRESH_SOURCE_BUILD_AND_COMPILE_COMPLETED';StartedUTC=$started;FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o');BookSHA256=(Get-FileHash -LiteralPath $output).Hash;OwnExcelPID=$ownedExcelProcessId;OwnExcelStartTicksUTC=[string]$ownedExcelStartTicks;PublishedBooksChanged=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot $proofName) -Encoding UTF8
