"""ДЛЯ ТЕСТОВ: обновляет только VBA и согласованные текстовые ячейки двух книг."""
from pathlib import Path
import hashlib
import argparse
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
import zipfile

E = Path(__file__).resolve().parent
ROOT = E.parents[2]
OLD = ROOT / 'docs/regression/GeometryFinalization_2026-10-26_Run01'
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
SST, VBA = 'xl/sharedStrings.xml', 'xl/vbaProject.bin'
SHEETS = ['xl/worksheets/sheet1.xml', 'xl/worksheets/sheet3.xml']

def TestLoad(path, name):
    """ДЛЯ ТЕСТОВ: использует уже проверенные raw ZIP-функции без запуска прежних сценариев."""
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(module)
    return module

def TestJSON(path):
    """ДЛЯ ТЕСТОВ: читает собственный proof с сохранением Unicode."""
    return json.loads(path.read_text(encoding='utf-8-sig'))

def TestCells(book, part):
    """ДЛЯ ТЕСТОВ: читает строки Config/Справки, не загружая тяжёлые таблицы Results."""
    values = [''.join(node.itertext()) for node in ET.fromstring(book.read(SST))]
    return {c.get('r'): (values[int(c.findtext(NS+'v'))], c) for c in ET.fromstring(book.read(part)).iter(NS+'c') if c.get('t') == 's'}

def TestPatch(book, fresh, mapping):
    """ДЛЯ ТЕСТОВ: привязывает текст к точной ячейке, не меняя другие ссылки на ту же строку."""
    old_sst = book.read(SST)
    sst = ET.fromstring(old_sst)
    old_values = [''.join(node.itertext()) for node in sst]
    original_si = re.findall(rb'<si\b[^>]*>.*?</si>', old_sst, re.S)
    assert len(original_si) == len(old_values) == int(sst.get('uniqueCount'))
    appended, changes, proofs = [], {}, []
    for part in SHEETS:
        raw = book.read(part)
        cells, target = TestCells(book, part), TestCells(fresh, part)
        changed = raw
        for pair in mapping:
            for address, (value, cell) in cells.items():
                if value != pair['Before'] or address not in target or target[address][0] != pair['After']:
                    continue
                index = len(old_values) + len(appended)
                appended.append(('<si><t xml:space="preserve">'+escape(pair['After'])+'</t></si>').encode('utf-8'))
                pattern = rb'<c\b(?=[^>]*\br="'+address.encode()+rb'")[^>]*>.*?</c>'
                hits = list(re.finditer(pattern, changed, re.S))
                assert len(hits) == 1
                original = hits[0].group()
                matches = list(re.finditer(rb'<v>([0-9]+)</v>', original))
                assert len(matches) == 1 and old_values[int(matches[0][1])] == pair['Before']
                m = matches[0]
                replacement = original[:m.start(1)] + str(index).encode() + original[m.end(1):]
                changed = changed[:hits[0].start()] + replacement + changed[hits[0].end():]
                proofs.append({'Part': part, 'Cell': address, **pair, '_old': original, '_new': replacement})
        assert changed != raw, 'No changes in '+part
        reverse = changed
        for p in reversed([p for p in proofs if p['Part'] == part]):
            assert reverse.count(p['_new']) == 1
            reverse = reverse.replace(p['_new'], p['_old'], 1)
        assert reverse == raw, 'Non-target sheet bytes changed'
        changes[part] = changed
    for pair in mapping:
        assert any(p['Before'] == pair['Before'] and p['After'] == pair['After'] for p in proofs), 'Expected text was not patched'
    header = re.search(rb'<sst\b[^>]*>', old_sst).group()
    new_header, count = re.subn(rb'\buniqueCount="[0-9]+"', b'uniqueCount="'+str(len(old_values)+len(appended)).encode()+b'"', header)
    assert count == 1
    new_sst = old_sst.replace(header, new_header, 1).replace(b'</sst>', b''.join(appended)+b'</sst>', 1)
    assert re.findall(rb'<si\b[^>]*>.*?</si>', new_sst, re.S)[:len(original_si)] == original_si
    changes[SST] = new_sst
    for p in proofs:
        del p['_old'], p['_new']
    return changes, proofs

def TestMain():
    """ДЛЯ ТЕСТОВ: сохраняет все прежние данные, результаты, схемы и оформление побайтно."""
    helper = TestLoad(OLD / 'LowMemoryPerformancePackagePlan/TestPrepareVbaOnlyPerformanceBook.py', 'TestRawZip')
    pack = TestLoad(OLD / 'PostTransferNativePlan01/TestPreparePreservedReady01.py', 'TestXmlZip')
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', default='FreshBuild01')
    parser.add_argument('--packages', default='Packages')
    parser.add_argument('--proof', default='PackageProof.json')
    args = parser.parse_args()
    assert re.fullmatch('FreshBuild[0-9]+', args.label) and re.fullmatch('Packages[0-9]*', args.packages)
    fresh = E / args.label / 'RC_Section_NDM.xlsm'
    build = TestJSON(E / ('Build.json' if args.label == 'FreshBuild01' else args.label+'.Build.json'))
    assert helper.file_sha(fresh) == build['BookSHA256']
    mapping = TestJSON(E / 'TextMap.json')
    records = TestJSON(E / 'Changes.json')
    output = E / args.packages
    output.mkdir(exist_ok=True)
    receipt = []
    with zipfile.ZipFile(fresh) as new:
        for case, relative in [('Main', 'workbook/output/RC_Section_NDM.xlsm'), ('SavedExcelWarm2', 'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm')]:
            base = E / 'Before' / relative
            expected = next(r['BeforeSHA256'] for r in records if r['Path'] == relative)
            assert helper.file_sha(base) == expected == helper.file_sha(ROOT / relative), 'Published source changed'
            folder = output / case
            folder.mkdir(exist_ok=True)
            candidate = folder / 'RC_Section_NDM.xlsm'
            with zipfile.ZipFile(base) as old:
                changes, proof = TestPatch(old, new, mapping)
                xml_records = pack.TestXMLRecords(old, changes)
            a, b = helper.archive(base), helper.archive(fresh)
            pack.TestWritePackage(helper, base, fresh, candidate, a, b, xml_records)
            c = helper.archive(candidate)
            before_entries, after_entries = dict(a['entries']), dict(c['entries'])
            unchanged = []
            with zipfile.ZipFile(base) as old, zipfile.ZipFile(candidate) as result:
                assert old.namelist() == result.namelist() and result.testzip() is None
                for part in old.namelist():
                    if part == VBA:
                        assert helper.digest_member(candidate, part) == helper.digest_member(fresh, part)
                    elif part in changes:
                        assert result.read(part) == changes[part]
                    else:
                        assert helper.digest_member(base, part) == helper.digest_member(candidate, part)
                        assert helper.slice_hash(base, *a['blocks'][part]) == helper.slice_hash(candidate, *c['blocks'][part])
                        x, y = bytearray(before_entries[part]), bytearray(after_entries[part])
                        x[42:46] = y[42:46] = b'\0'*4
                        assert x == y
                        unchanged.append(part)
                for p in proof:
                    assert TestCells(result, p['Part'])[p['Cell']][0] == p['After']
            assert len(unchanged) == len(a['infos']) - 4
            receipt.append({'ID': case, 'Path': str(candidate), 'SHA256': helper.file_sha(candidate), 'BaseSHA256': expected,
                            'Cells': proof, 'ChangedParts': [VBA, *changes], 'OtherPartsByteExact': unchanged,
                            'ResultsAndInputsPreserved': True, 'SourceBuildReproducesTexts': True})
    old_dump = (E / 'Before/workbook/output/VBA_All_Code.txt').read_bytes()
    text_change = records[0]['Replacements'][0]
    assert old_dump.count(text_change['Before'].encode('utf-8')) == 3
    expected_dump = old_dump.replace(text_change['Before'].encode('utf-8'), text_change['After'].encode('utf-8'))
    if not (E / 'Expected_AllCode.txt').exists():
        (E / 'Expected_AllCode.txt').write_bytes(expected_dump)
    (E / args.proof).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps([{'ID': r['ID'], 'SHA256': r['SHA256'], 'ChangedCells': len(r['Cells']), 'PreservedParts': len(r['OtherPartsByteExact'])} for r in receipt]))

if __name__ == '__main__':
    TestMain()
