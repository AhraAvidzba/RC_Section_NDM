Attribute VB_Name = "modTestCADText"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: сообщения настоящего AutoCAD через собственные документы
' ==========================================================================
' Только в частной копии подменяются подключение к CAD и показ окна.
' Форматтер, рабочие обработчики, импорт и экспорт остаются штатными.
Public TestOwnedCAD As Object
Public TestMessage As String
Private mReport As String
Private mPassed As Long
Private mFailed As Long

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует проверку до следующего COM-действия; ошибка остаётся в первичном отчёте.
Private Sub TestCheck(ByVal key As String, ByVal passed As Boolean)
    If passed Then mPassed = mPassed + 1 Else mFailed = mFailed + 1
    mReport = mReport & IIf(passed, "OK: ", "FAIL: ") & key & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет существующий ключ только частной книги; отсутствие ключа означает ошибку fixture.
Private Sub TestSet(ByVal key As String, ByVal value As Variant)
    Dim table As Object: Set table = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    Dim i As Long
    For i = 2 To table.Rows.Count
        If CStr(table.Cells(i, 1).Value2) = key Then table.Cells(i, 2).Value2 = value: Exit Sub
    Next i
    Err.Raise 5, "modTestCADText", "Ключ отсутствует: " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вызывает реальные обработчики, но записывает текст окна вместо блокирующего диалога.
Public Function TestRunCADText(ByVal acad As Object, ByVal directory As String, ByVal mode As String, ByVal calculated As Boolean) As String
    Set TestOwnedCAD = acad
    mReport = vbNullString: mPassed = 0: mFailed = 0
    Dim settingsTable As Object: Set settingsTable = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    Dim saved As Variant: saved = settingsTable.Formula
    Dim document As Object, emptyDrawing As Object, layout As Object
    Dim importer As CAutoCADSectionModelImporter, settings As CSystemSettingsReader, section As CSectionModel
    Dim number As Long, description As String, warning As String, native As String, sourceName As String, stage As String
    Dim paperCount As Long, modelCount As Long, solves As Long: solves = SectionEquilibriumSolveCount()
    On Error GoTo Failed
    TestSet "General.DiagramExtension", mode
    TestSet "General.NonCriticalMessagesEnabled", "Yes"
    Set document = acad.Documents.Add
    document.SaveAs directory & "\" & IIf(calculated, "Расчёт", "Геометрия_" & mode) & ".dwg"
    sourceName = CStr(document.Name)
    If Not calculated Then
        native = modTestAutoCADContours.RunAutoCADContourTests()
        mReport = mReport & native
        TestCheck "contourRegression.clean", InStr(native, "; failed=0") > 0 And InStr(native, "FAIL:") = 0
        native = modTestAutoCADContours.RunNativeGeometryOnlyExportTests(document)
        mReport = mReport & native
        TestCheck "nativeGeometryOnly.clean", InStr(native, "; failed=0") > 0 And InStr(native, "FAIL:") = 0
        TestSet "AutoCAD.Common.ConcreteLayer", "TEXT_CONCRETE"
        TestSet "AutoCAD.Common.RebarLayer", "TEXT_REBAR"
        TestSet "AutoCAD.Common.SectionContourLayer", "TEXT_OUTER"
        TestSet "AutoCAD.Common.OpeningContourLayer", "TEXT_OPENING"
    End If
    stage = "SwitchToPaperSpace"
    document.ActiveSpace = 0
    stage = "ReadModelAndPaperCounts"
    paperCount = document.PaperSpace.Count: modelCount = document.ModelSpace.Count
    stage = "WorkingExport"
    TestMessage = vbNullString
    ExportSectionStressToAutoCAD
    mReport = mReport & "CAPTURED_EXPORT: " & TestMessage & vbCrLf
    TestCheck "export.success." & mode, InStr(TestMessage, "Сечение выгружено в чертёж «" & sourceName & "» — в модель.") > 0
    TestCheck "export.actualModel." & mode, document.ModelSpace.Count > modelCount And document.PaperSpace.Count = paperCount
    If calculated Then
        TestCheck "export.calculated", InStr(TestMessage, "Экспорт в AutoCAD завершен") > 0 And InStr(TestMessage, "только геометрия") = 0
    Else
        stage = "WorkingImport"
        TestCheck "export.geometryWarning." & mode, InStr(TestMessage, "Сохранённые результаты расчёта сечения отсутствуют.") > 0 And InStr(TestMessage, "только геометрия сечения.") > 0
        document.ActiveSpace = 1
        Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
        Set importer = New CAutoCADSectionModelImporter
        Set section = importer.ImportFromActiveDocument(settings)
        warning = importer.ResultMessage(section)
        mReport = mReport & "CAPTURED_IMPORT: " & warning & vbCrLf
        TestCheck "import.sourceName." & mode, InStr(warning, "Сечение импортировано из чертежа AutoCAD «" & sourceName & "».") > 0
        TestCheck "import.geometry." & mode, section.ConcreteCount = 1 And section.RebarCount = 1
        Set emptyDrawing = acad.Documents.Add
        emptyDrawing.SaveAs directory & "\Пустой_" & mode & ".dwg"
        Set section = Nothing
        On Error Resume Next
        Set section = importer.ImportFromActiveDocument(settings)
        number = Err.Number: description = Err.Description: Err.Clear
        On Error GoTo Failed
        mReport = mReport & "CAPTURED_MISSING_LAYERS: " & description & vbCrLf
        TestCheck "import.missingLayers." & mode, number = vbObjectError + 4405 And InStr(description, CStr(emptyDrawing.Name)) > 0 And InStr(description, "отсутствуют указанные в Config слои") > 0 And InStr(description, "TEXT_CONCRETE") > 0 And InStr(description, "TEXT_REBAR") > 0
        emptyDrawing.Layers.Add "TEXT_CONCRETE": emptyDrawing.Layers.Add "TEXT_REBAR"
        On Error Resume Next
        Set section = importer.ImportFromActiveDocument(settings)
        number = Err.Number: description = Err.Description: Err.Clear
        On Error GoTo Failed
        TestCheck "import.emptyIsNotMissing." & mode, number = vbObjectError + 4405 And InStr(description, CStr(emptyDrawing.Name)) > 0 And InStr(description, "отсутствуют указанные в Config слои") = 0 And InStr(description, "Слой бетона пуст") > 0
        TestMessage = vbNullString: ClearAutoCADDrawing
        mReport = mReport & "CAPTURED_CLEANUP: " & TestMessage & vbCrLf
        TestCheck "cleanup.drawingName." & mode, InStr(TestMessage, CStr(emptyDrawing.Name)) > 0 And InStr(TestMessage, "нет слоёв с подписями") > 0
        emptyDrawing.Close False: Set emptyDrawing = Nothing
        document.Close False: Set document = Nothing
        Do While acad.Documents.Count > 0: acad.Documents.Item(0).Close False: Loop
        On Error Resume Next
        Set section = importer.ImportFromActiveDocument(settings)
        number = Err.Number: description = Err.Description: Err.Clear
        On Error GoTo Failed
        mReport = mReport & "CAPTURED_NO_DOCUMENT: " & description & vbCrLf
        TestCheck "import.noDocument." & mode, number = vbObjectError + 4402 And InStr(description, "активный чертеж не найден") > 0 And InStr(description, "Откройте или создайте чертеж") > 0
    End If
    TestCheck "noSolve." & mode, SectionEquilibriumSolveCount() = solves
    GoTo Cleanup
Failed:
    TestCheck "runtime." & stage & "." & CStr(Err.Number) & "." & Err.Description, False
Cleanup:
    On Error Resume Next
    If Not emptyDrawing Is Nothing Then emptyDrawing.Close False
    If Not document Is Nothing Then document.Close False
    settingsTable.Formula = saved
    On Error GoTo 0
    Set TestOwnedCAD = Nothing
    TestRunCADText = mReport & "TOTAL_CAD_TEXT: passed=" & CStr(mPassed) & "; failed=" & CStr(mFailed) & vbCrLf
End Function
