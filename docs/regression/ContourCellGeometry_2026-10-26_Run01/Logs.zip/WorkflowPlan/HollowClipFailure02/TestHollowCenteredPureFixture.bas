Attribute VB_Name = "modTestHollowCenteredPureFixture"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: чистая геометрия сбоя Contour25x50 из Workflow02
' ==========================================================================
' Нет обращения к Excel, Config, solver или материалам. Размеры идентичны
' TestConfigureShapeFixture("HollowCentered") при INPUT mm. Код не запускался.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает точную область Outer1000x1200R60 минус Opening400x500R30.
' Порядок исходных TL/TR/BR/BL и идентификаторы повторяют рабочий рецепт.
Public Function TestHollowCenteredRegion() As CConcreteRegion
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim outer As CConcreteRegion, opening As CConcreteRegion
    Set outer = query.RegionFromPath(query.RoundedPolygon("OUTER.Boundary", TestRoundedPolygon(1000#, 1200#, 60#)))
    Set opening = query.RegionFromPath(query.RoundedPolygon("OPENING.Boundary", TestRoundedPolygon(400#, 500#, 30#)))
    Set TestHollowCenteredRegion = query.SubtractContainedRegion(outer, opening)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет одну ячейку непосредственно тем же ClipWindow, которым пользуется
' CGeometryRegion. По умолчанию — первый кандидат в порядке сканирования сетки.
Public Function TestHollowCenteredCell(Optional ByVal minX As Double = -200#, _
        Optional ByVal minY As Double = -250#) As CConcreteRegion
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Set TestHollowCenteredCell = query.ClipWindow(TestHollowCenteredRegion(), 1#, 0#, minX, minX + 25#, minY, minY + 50#)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет весь чистый вызов сетки; никаких настроек или сохранённых данных
' предшествующих случаев нет. Последние аргументы задают Contour явно.
Public Function TestHollowCenteredMesh() As CFiberMeshBuilder
    Dim geometry As CGeometryRegion: Set geometry = New CGeometryRegion
    geometry.Initialize TestHollowCenteredRegion()
    Dim mesh As CFiberMeshBuilder: Set mesh = New CFiberMeshBuilder
    mesh.BuildMesh geometry, 25#, 50#, 1, 2, "Pure Workflow02 HollowCentered reproduction", 0#, "Contour"
    Set TestHollowCenteredMesh = mesh
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создаёт те же вершины и радиусы, что CSectionRecipeHollowRectangle.DescribePolygon.
Private Function TestRoundedPolygon(ByVal width As Double, ByVal height As Double, ByVal radius As Double) As CPolygonSpec
    Dim polygon As CPolygonSpec: Set polygon = New CPolygonSpec
    polygon.AddVertex "TL", -width / 2#, height / 2#, radius, "Pure Workflow02", cornerID:="Corner.TL"
    polygon.AddVertex "TR", width / 2#, height / 2#, radius, "Pure Workflow02", "Edge.TR", "Corner.TR"
    polygon.AddVertex "BR", width / 2#, -height / 2#, radius, "Pure Workflow02", cornerID:="Corner.BR"
    polygon.AddVertex "BL", -width / 2#, -height / 2#, radius, "Pure Workflow02", "Edge.BL", "Corner.BL"
    polygon.Seal
    Set TestRoundedPolygon = polygon
End Function
