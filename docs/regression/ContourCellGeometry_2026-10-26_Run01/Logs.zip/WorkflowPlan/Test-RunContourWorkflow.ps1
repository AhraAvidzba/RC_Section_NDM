﻿# ДЛЯ ТЕСТОВ: пять коротких сквозных случаев только в собственных копиях книги.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$SourceWorkbook,
    [Parameter(Mandatory=$true)][string]$EvidenceDirectory,
    [double]$MinimumFreeRAMGiB=6,
    [double]$MinimumFreeCommitGiB=10,
    [string]$HelperFile=''
)
$ErrorActionPreference='Stop'
if([string]::IsNullOrWhiteSpace($HelperFile)){$HelperFile=Join-Path $PSScriptRoot 'TestContourWorkflowProbe.bas'}
if($PSVersionTable.PSVersion.Major -ne 5){throw 'Use Windows PowerShell 5.1.'}
if($MinimumFreeRAMGiB -lt 4 -or $MinimumFreeCommitGiB -lt 8){throw 'Absolute minimum reserve is 4 GiB RAM / 8 GiB commit.'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$source=(Resolve-Path -LiteralPath $SourceWorkbook).Path
$helper=(Resolve-Path -LiteralPath $HelperFile).Path
if([IO.Path]::IsPathRooted($EvidenceDirectory)){$directory=[IO.Path]::GetFullPath($EvidenceDirectory)}else{$directory=[IO.Path]::GetFullPath((Join-Path $root $EvidenceDirectory))}
$allowed=(Join-Path $root 'docs/regression')+[IO.Path]::DirectorySeparatorChar
if(-not $directory.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)){throw 'Evidence directory must stay in docs/regression.'}
if(Test-Path -LiteralPath $directory){throw 'Use a fresh evidence directory.'}
[void][IO.Directory]::CreateDirectory($directory)
$sourceHash=(Get-FileHash -LiteralPath $source).Hash
$helperHash=(Get-FileHash -LiteralPath $helper).Hash
$template=Join-Path $directory 'InjectedWorkflowTemplate.xlsm'
Copy-Item -LiteralPath $source -Destination $template
function Write-Proof([string]$name,$value){$value | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $directory $name) -Encoding UTF8}
function Memory-Gate([string]$stage){
    $memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
    $ram=[double]$memory.AvailableMBytes/1024;$commit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
    $value=[ordered]@{ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');Stage=$stage;FreeRAMGiB=$ram;FreeCommitGiB=$commit;
        RequiredRAMGiB=$MinimumFreeRAMGiB;RequiredCommitGiB=$MinimumFreeCommitGiB;Ready=($ram -ge $MinimumFreeRAMGiB -and $commit -ge $MinimumFreeCommitGiB)}
    Write-Proof ('Memory_'+$stage+'.json') $value
    if(-not $value.Ready){throw 'Insufficient combined memory reserve; no next workflow case started.'}
}
function Exact-Process([int]$processID,[long]$ticks){
    if($processID -le 0 -or $ticks -le 0){return $false}
    $process=Get-Process -Id $processID -ErrorAction SilentlyContinue
    if(-not $process){return $false}
    try{return $process.ProcessName -ieq 'EXCEL' -and $process.StartTime.ToUniversalTime().Ticks -eq $ticks}catch{return $false}
}
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class NdmWorkflowOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$prior=@(Get-Process -Name EXCEL -ErrorAction SilentlyContinue | ForEach-Object {[ordered]@{PID=$_.Id;StartTicksUTC=[string]$_.StartTime.ToUniversalTime().Ticks}})
$priorIDs=@($prior | ForEach-Object {$_.PID})
$excel=$null;$book=$null;$excelID=0;$excelTicks=0L;$owned=$false;$failure=$null;$cases=@();$templateHash=$null;$closed=$false
Write-Proof 'Input.json' ([ordered]@{Source=$source;SourceSHA256=$sourceHash;Helper=$helper;HelperSHA256=$helperHash;ExistingExcel=$prior;
    PlannedCases=5;SimultaneousExcel=1;FullRegressionRun=$false;PredeclaredNumericalLimits=[ordered]@{CoarseError=0.10;RefinedError=0.03;RefinementMustImprove=$true;
    FineAdaptiveIsApproximate=$true;Norm='max(abs(delta epsilon0), H*abs(delta kappaX), W*abs(delta kappaY))/max(abs(reference epsilon0), H*abs(reference kappaX), W*abs(reference kappaY))'}})
try{
    Memory-Gate 'BeforeExcel'
    $excel=New-Object -ComObject Excel.Application
    [uint32]$nativeID=0;[void][NdmWorkflowOwner]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$nativeID)
    $excelID=[int]$nativeID;$excelTicks=(Get-Process -Id $excelID).StartTime.ToUniversalTime().Ticks
    if($excelID -in $priorIDs){throw 'Refusing to use a pre-existing Excel.'}
    $owned=$true
    Write-Proof 'Ownership.json' ([ordered]@{Status='INJECTING_HELPER';ExcelPID=$excelID;ExcelStartTicksUTC=[string]$excelTicks;CADPID=0;CADStartTicksUTC='0';SourceSHA256=$sourceHash;UserDocumentsUsed=$false})
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AskToUpdateLinks=$false;$excel.AutomationSecurity=3
    $book=$excel.Workbooks.Open($template,0,$false)
    if($book.ReadOnly){throw 'Private helper injection book must be writable.'}
    $module=$book.VBProject.VBComponents.Add(1);$module.Name='modTestContourWorkflow'
    $body=[regex]::Match([IO.File]::ReadAllText($helper,[Text.Encoding]::UTF8),'(?ms)^Option Explicit.*').Value
    if(-not $body){throw 'Helper lacks Option Explicit.'}
    $module.CodeModule.AddFromString(($body -split '\r?\n') -join "`r`n")
    $excel.VBE.ActiveVBProject=$book.VBProject;$compile=$excel.VBE.CommandBars.FindControl(1,578)
    if(-not $compile){throw 'VBE compile command unavailable.'}
    if($compile.Enabled){$compile.Execute()}
    if($compile.Enabled){
        $pane=$excel.VBE.ActiveCodePane;$sl=0;$sc=0;$el=0;$ec=0;$pane.GetSelection([ref]$sl,[ref]$sc,[ref]$el,[ref]$ec)
        Write-Proof 'HelperCompileFailure.json' ([ordered]@{Component=$pane.CodeModule.Parent.Name;Line=$sl;Text=$pane.CodeModule.Lines([math]::Max(1,$sl-2),5)})
        throw 'Workflow helper failed to compile.'
    }
    $book.Save();$book.Close($false);$book=$null;$templateHash=(Get-FileHash -LiteralPath $template).Hash
    $fixtures=@(@('Circle','Excel','User'),@('RoundedSimple','File','User'),@('HollowCentered','Excel','User'),@('LSection','File','User'),@('Circle','File','Auto 0.1'))
    $index=0
    foreach($fixture in $fixtures){
        $index++;$label='{0:00}_{1}_{2}' -f $index,$fixture[0],$fixture[1]
        Memory-Gate $label
        $path=Join-Path $directory ($label+'.xlsm');Copy-Item -LiteralPath $template -Destination $path
        Write-Proof 'Ownership.json' ([ordered]@{Status='RUNNING_'+$label;ExcelPID=$excelID;ExcelStartTicksUTC=[string]$excelTicks;CADPID=0;CADStartTicksUTC='0';SourceSHA256=$sourceHash;UserDocumentsUsed=$false;PrivateWorkbook=$path})
        $excel.AutomationSecurity=1;$book=$excel.Workbooks.Open($path,0,$false)
        if($book.ReadOnly){throw 'Workflow case copy must be writable.'}
        $prefix="'"+$book.Name+"'!modTestContourWorkflow."
        $clock=[Diagnostics.Stopwatch]::StartNew()
        $report=[string]$excel.Run($prefix+'TestRunContourWorkflow',[string]$fixture[0],[string]$fixture[1],[string]$fixture[2])
        $clock.Stop();$primary=Join-Path $directory ($label+'.txt');[IO.File]::WriteAllText($primary,$report,[Text.UTF8Encoding]::new($true))
        $match=[regex]::Match($report,'TOTAL_CONTOUR_WORKFLOW: passed=(\d+); failed=(\d+)')
        $passed=$match.Success -and [int]$match.Groups[2].Value -eq 0 -and $report -notmatch '(?m)^FAIL '
        $entry=[ordered]@{Case=$label;Fixture=$fixture[0];Storage=$fixture[1];StepMode=$fixture[2];Seconds=$clock.Elapsed.TotalSeconds;PrimarySHA256=(Get-FileHash -LiteralPath $primary).Hash;
            AssertionsPassed=$(if($match.Success){[int]$match.Groups[1].Value}else{0});AssertionsFailed=$(if($match.Success){[int]$match.Groups[2].Value}else{$null});MacroPassed=$passed;ReopenFingerprintEqual=$false}
        $cases+=,$entry;Write-Proof 'Cases.json' $cases
        if(-not $passed){$book.Save();throw ('Workflow assertions failed: '+$label)}
        $before=[string]$excel.Run("'"+$book.Name+"'!modTestCalculationSnapshot.TestSnapshotReopenFingerprint")
        [IO.File]::WriteAllText((Join-Path $directory ($label+'.Before.txt')),$before,[Text.UTF8Encoding]::new($true))
        $book.Save();$book.Close($false);$book=$null
        $excel.AutomationSecurity=1;$book=$excel.Workbooks.Open($path,0,$true)
        if(-not $book.ReadOnly){throw 'Reopen verification must be read-only.'}
        $after=[string]$excel.Run("'"+$book.Name+"'!modTestContourWorkflow.TestContourWorkflowReopen")
        [IO.File]::WriteAllText((Join-Path $directory ($label+'.After.txt')),$after,[Text.UTF8Encoding]::new($true))
        $entry.ReopenFingerprintEqual=$before -ceq $after
        $entry.ReopenBeforeSHA256=(Get-FileHash -LiteralPath (Join-Path $directory ($label+'.Before.txt'))).Hash
        $entry.ReopenAfterSHA256=(Get-FileHash -LiteralPath (Join-Path $directory ($label+'.After.txt'))).Hash
        Write-Proof 'Cases.json' $cases
        $book.Close($false);$book=$null
        if(-not $entry.ReopenFingerprintEqual){throw ('Reopen fingerprint differs: '+$label)}
    }
}catch{$failure=$_.Exception.ToString();Write-Proof 'Failure.json' ([ordered]@{ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');Reason=$failure})}
finally{
    if($owned -and (Exact-Process $excelID $excelTicks)){
        if($book){try{$book.Close($false)}catch{}}
        if($excel){try{$excel.Quit()}catch{}}
    }
    $module=$null;$compile=$null;$pane=$null;$book=$null
    if($excel){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    $forced=$false
    if($owned -and (Exact-Process $excelID $excelTicks)){
        $process=Get-Process -Id $excelID;[void]$process.WaitForExit(3000)
        if(Exact-Process $excelID $excelTicks){Stop-Process -Id $excelID -Force;$forced=$true}
    }
    $closed=-not (Exact-Process $excelID $excelTicks)
    Write-Proof 'ProcessClosure.json' ([ordered]@{PID=$excelID;StartTicksUTC=[string]$excelTicks;Owned=$owned;ResidualForceKilled=$forced;ExactIdentityAbsent=$closed})
}
$sourceUnchanged=(Get-FileHash -LiteralPath $source).Hash -ceq $sourceHash
$templateUnchanged=$templateHash -and (Get-FileHash -LiteralPath $template).Hash -ceq $templateHash
$passed=$cases.Count -eq 5 -and @($cases | Where-Object {-not $_.MacroPassed -or -not $_.ReopenFingerprintEqual}).Count -eq 0 -and $sourceUnchanged -and $templateUnchanged -and $closed -and -not $failure
Write-Proof 'Acceptance.json' ([ordered]@{Status=$(if($passed){'PASS_DIRECTED_CONTOUR_WORKFLOW'}else{'REVIEW_REQUIRED'});Passed=$passed;CompletedCases=$cases.Count;ExpectedCases=5;
    SourceUnchanged=$sourceUnchanged;SourceSHA256=$sourceHash;PrivateTemplateUnchanged=$templateUnchanged;AllOwnedProcessesClosed=$closed;FullRegressionPass=$false;Failure=$failure})
if(-not $passed){throw 'Workflow acceptance requires review; inspect primary evidence.'}
Get-Content -LiteralPath (Join-Path $directory 'Acceptance.json') -Raw
