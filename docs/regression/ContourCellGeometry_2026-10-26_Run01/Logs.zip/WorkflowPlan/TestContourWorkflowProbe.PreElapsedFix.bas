Attribute VB_Name = "modTestContourWorkflow"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: короткий сквозной конвейер точных бетонных ячеек
' ==========================================================================
' Внедряется только в собственную копию уже собранной книги. Не запускает CAD,
' не ищет чужие приложения, не меняет рабочие исходники и не заменяет полный UI.
Private mPassed As Long, mFailed As Long ' ДЛЯ ТЕСТОВ: независимые счётчики адресного случая.
Private mReport As String ' ДЛЯ ТЕСТОВ: первичные значения, длительности и причины отказа.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет реальное формирование, расчёт и снимок, затем сравнивает поле
' деформаций с уточнённым Contour и приближённым мелким Adaptive без вывода.
Public Function TestRunContourWorkflow(ByVal fixture As String, ByVal storage As String, ByVal stepMode As String) As String
    mPassed = 0: mFailed = 0: mReport = vbNullString
    On Error GoTo Failed
    TestConfigure fixture, storage, stepMode
    Dim settings As CSystemSettingsReader, units As CUnitSystem
    TestReadSettings settings, units
    mReport = "CASE fixture=" & fixture & "; type=" & settings.GetRequiredString("Geometry.Type") & _
        "; storage=" & storage & "; mode=" & stepMode & "; input=mm,kN,kN*m; output=cm,cm2,tf,tf*m" & vbCrLf
    Dim started As Double: started = Timer
    Dim solves As Long: solves = SectionEquilibriumSolveCount()
    Dim info As Boolean, attention As Boolean, message As String
    message = FormSectionForWorkbook(ThisWorkbook, , info, attention)
    TestCheck "form.noSolve", solves = SectionEquilibriumSolveCount()
    TestCheck "form.noWarnings", Not attention
    mReport = mReport & "FORM seconds=" & CStr(ElapsedSecondsFrom(started)) & "; " & message & vbCrLf
    Dim original As CSectionModel: Set original = ReadSectionGeometryFromResults(ThisWorkbook)
    TestExactModel "formed", original
    Dim originalProperties As CSectionPropertiesCalculator: Set originalProperties = New CSectionPropertiesCalculator
    originalProperties.CalculateConcrete original
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim region As CConcreteRegion: Set region = query.RegionFromContours(original.Contours)
    Dim exact As TGeometryProperties: query.RegionProperties region, exact
    TestNear "exact.area", originalProperties.Area, exact.Area, 0.00000001
    TestNear "exact.cx", originalProperties.CentroidX, exact.CentroidX, 0.00000001
    TestNear "exact.cy", originalProperties.CentroidY, exact.CentroidY, 0.00000001
    TestNear "exact.Ix", originalProperties.Ixc, exact.Ixc, 0.00000001
    TestNear "exact.Iy", originalProperties.Iyc, exact.Iyc, 0.00000001
    TestCheck "exact.Ixy", Abs(originalProperties.Ixyc - exact.Ixyc) <= 0.00000001 * (Abs(exact.Ixc) + Abs(exact.Iyc))
    started = Timer
    message = RunSectionCalculationForWorkbook(ThisWorkbook, False, , info, attention)
    TestCheck "calculate.didSolve", SectionEquilibriumSolveCount() > solves
    TestCheck "calculate.noWarnings", Not attention
    mReport = mReport & "CALCULATE seconds=" & CStr(ElapsedSecondsFrom(started)) & "; " & message & vbCrLf
    Dim restored As CSectionModel: Set restored = ReadSectionGeometryFromResults(ThisWorkbook)
    TestCompareModels original, restored
    TestReadSettings settings, units
    Dim reader As CSectionPlotDataReader: Set reader = New CSectionPlotDataReader
    reader.LoadFromWorkbook ThisWorkbook, settings
    TestCheck "saved.state.available", Not reader.GeometryOnly And reader.Count > 0 And reader.StateType = "StrengthState"
    TestCheck "saved.state.noInputError", reader.DirectStateStatus <> "InputErr" And Len(reader.DirectStateStatus) > 0
    TestCheck "saved.units.outputLength", ReadLoadCasePropertyText(ThisWorkbook, "ALL", "Output.LengthUnit") = "cm"
    TestCheck "saved.units.outputArea", ReadLoadCasePropertyText(ThisWorkbook, "ALL", "Output.AreaUnit") = "cm2"
    TestCheck "saved.units.normalizedLength", reader.LengthUnit = "mm"
    TestCheck "saved.units.normalizedArea", reader.AreaUnit = "mm2"
    TestCheck "saved.units.readerCount", reader.Count = original.ConcreteCount + original.RebarCount
    Dim readerIndex As Long
    For readerIndex = 1 To original.ConcreteCount
        TestNear "saved.units.readerX." & CStr(readerIndex), reader.X(readerIndex), original.ConcreteX(readerIndex), 0.0000000001
        TestNear "saved.units.readerY." & CStr(readerIndex), reader.Y(readerIndex), original.ConcreteY(readerIndex), 0.0000000001
        TestNear "saved.units.readerA." & CStr(readerIndex), reader.Area(readerIndex), original.ConcreteArea(readerIndex), 0.0000000001
    Next readerIndex
    TestNear "saved.sign.N", CDbl(ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "N")), units.InternalForceToOutput(-100000#), 0.0000000001
    TestNear "saved.sign.Mx", CDbl(ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "MxUser")), units.InternalMomentMxToOutput(1000000#), 0.0000000001
    TestNear "saved.sign.My", CDbl(ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "MyUser")), units.InternalMomentMyToOutput(-800000#), 0.0000000001
    mReport = mReport & "COARSE_SAVED_OUTPUT tf,tf*m: N=" & ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "N") & _
        "; MxUser=" & ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "MxUser") & "; MyUser=" & ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "MyUser") & _
        "; Nint=" & ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "Nint") & "; MxInternal=" & ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "MxInternal") & _
        "; MyInternal=" & ReadLoadCasePropertyText(ThisWorkbook, "PERF_01", "MyInternal") & vbCrLf
    Dim sx As Double, sy As Double
    If stepMode = "User" Then sx = 50#: sy = 100# Else sx = 60#: sy = 60#
    Dim fine As CSectionStateResult, refined As CSectionStateResult
    Dim fineCount As Long, refinedCount As Long
    Set fine = TestReference("Adaptive", sx / 4#, sy / 4#, fineCount)
    Set refined = TestReference("Contour", sx / 2#, sy / 2#, refinedCount)
    Dim minimum As Double, maximum As Double, spanX As Double, spanY As Double
    query.ProjectionBounds region, 1#, 0#, minimum, maximum: spanX = maximum - minimum
    query.ProjectionBounds region, 0#, 1#, minimum, maximum: spanY = maximum - minimum
    Dim coarseError As Double, refinedError As Double
    coarseError = TestFieldError(reader.Epsilon0, reader.KappaX, reader.KappaY, fine, spanX, spanY)
    refinedError = TestFieldError(refined.Epsilon0, refined.KappaX, refined.KappaY, fine, spanX, spanY)
    TestCheck "convergence.coarse10percent", coarseError <= 0.1
    TestCheck "convergence.refined3percent", refinedError <= 0.03
    TestCheck "convergence.refinementImproves", refinedError < coarseError Or (coarseError < 0.00000001 And refinedError < 0.00000001)
    mReport = mReport & "COARSE count=" & CStr(original.ConcreteCount) & "; eps=" & CStr(reader.Epsilon0) & "; kx=" & CStr(reader.KappaX) & _
        "; ky=" & CStr(reader.KappaY) & "; status=" & reader.DirectStateStatus & "; error=" & CStr(coarseError) & vbCrLf & _
        "REFINEMENT coarseError=" & CStr(coarseError) & "; refinedError=" & CStr(refinedError) & "; fineCount=" & CStr(fineCount) & "; refinedCount=" & CStr(refinedCount) & vbCrLf
    TestSetting "Mesh.CellGeometry", "Contour": TestSetting "Mesh.StepMode", stepMode
    TestSetting "Mesh.StepX", 50#: TestSetting "Mesh.StepY", 100#
    Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
    TestCheck "snapshot.mode", store.StorageMode(ThisWorkbook) = storage
    If storage = "File" Then
        Dim saved As CCalculationSnapshot: Set saved = store.LoadFile(ThisWorkbook)
        TestCheck "snapshot.boundaryTable", saved.HasTable("rngNDMElementGeometry")
        mReport = mReport & "SNAPSHOT_FILE " & store.SnapshotPath(ThisWorkbook) & vbCrLf
    End If
    GoTo Finish
Failed:
    TestCheck "runtime " & CStr(Err.Number) & "; " & Err.Source & "; " & Err.Description, False
Finish:
    TestRunContourWorkflow = mReport & "TOTAL_CONTOUR_WORKFLOW: passed=" & CStr(mPassed) & "; failed=" & CStr(mFailed) & vbCrLf
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' После настоящего закрытия и открытия обновляет результаты без нового solver.
' Побитное сравнение всех таблиц и потребителей выполняет внешний сценарий.
Public Function TestContourWorkflowReopen() As String
    Dim solves As Long: solves = SectionEquilibriumSolveCount()
    UpdateSectionResultsForWorkbook ThisWorkbook
    If solves <> SectionEquilibriumSolveCount() Then Err.Raise 5, , "Повторное открытие вызвало solver."
    Dim restored As CSectionModel: Set restored = ReadSectionGeometryFromResults(ThisWorkbook)
    Dim i As Long
    For i = 1 To restored.ConcreteCount
        If Not restored.ConcreteHasBoundary(i) Then Err.Raise 5, , "После открытия потеряна граница " & restored.ConcreteID(i)
    Next i
    TestContourWorkflowReopen = TestSnapshotReopenFingerprint()
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Готовит существующие геометрические fixtures; единицы и знаки намеренно
' отличаются от внутренних, чтобы проверить весь адаптер ввода и вывода.
Private Sub TestConfigure(ByVal fixture As String, ByVal storage As String, ByVal stepMode As String)
    TestUnit "Length", "mm", "cm": TestUnit "Area", "mm2", "cm2"
    TestUnit "Force", "kN", "tf": TestUnit "Moment", "kN*m", "tf*m"
    TestUnit "Stress", "MPa", "MPa": TestUnit "Curvature", "1/mm", "1/m"
    TestSign "+N", "Compression": TestSign "+Mx", "-Y tension": TestSign "+My", "-X tension"
    TestConfigureShapeFixture fixture
    TestConfigurePerformanceFixture "DIRECT", 1, "Newton", "Saved", "Normal", "No"
    TestSetting "Mesh.CellGeometry", "Contour": TestSetting "Mesh.StepMode", stepMode
    TestSetting "Mesh.StepX", 50#: TestSetting "Mesh.StepY", 100#: TestSetting "Mesh.BoundarySubdivisions", 2
    TestSetting "Results.SnapshotStorage", storage
    TestSetting "Results.SnapshotName", "ContourWorkflow_" & fixture & "_" & Replace$(stepMode, " ", vbNullString)
    TestSetting "Plot.Enabled", "Yes": TestSetting "Plot.AutoUpdateAfterCalculation", "Yes"
    TestSetting "Plot.LoadCase", "PERF_01": TestSetting "AutoCAD.Export.CombinationID", "PERF_01"
    TestSetting "Load.ReferenceOffsetX", 0#: TestSetting "Load.ReferenceOffsetY", 0#
    TestSetting "General.ExecutionReportEnabled", "No": TestSetting "General.ReformatResultsEnabled", "No"
    Dim table As Object, data As Variant, row As Long
    Set table = ThisWorkbook.Names.Item("rngCalculationProfiles").RefersToRange: data = table.Value2
    For row = 1 To UBound(data, 1)
        If CStr(data(row, 2)) = "Visualization.State" Then data(row, 3) = "StrengthState"
    Next row
    table.Value2 = data
    Dim settings As CSystemSettingsReader, units As CUnitSystem: TestReadSettings settings, units
    Set table = ThisWorkbook.Names.Item("rngLoadCombinations").RefersToRange
    table.Cells(2, 2).Value2 = -100000# / units.InputForceToInternal(1#)
    table.Cells(2, 3).Value2 = 1000000# / units.InputMomentMxToInternal(1#)
    table.Cells(2, 4).Value2 = -800000# / units.InputMomentMyToInternal(1#)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит эталон напрямую из тех же Config и материалов; не пишет Results,
' не создаёт схему и не заменяет геометрию реально сформированного сечения.
Private Function TestReference(ByVal mode As String, ByVal sx As Double, ByVal sy As Double, ByRef count As Long) As CSectionStateResult
    TestSetting "Mesh.CellGeometry", mode: TestSetting "Mesh.StepMode", "User"
    TestSetting "Mesh.StepX", sx: TestSetting "Mesh.StepY", sy
    Dim settings As CSystemSettingsReader, units As CUnitSystem: TestReadSettings settings, units
    Dim started As Double: started = Timer
    Dim model As CSectionModel: Set model = BuildWorkbookSectionModel(ThisWorkbook, settings, units)
    count = model.ConcreteCount
    Dim buildSeconds As Double: buildSeconds = ElapsedSecondsFrom(started)
    Dim provider As CMaterialModelProvider: Set provider = New CMaterialModelProvider: provider.Initialize settings, units
    Dim profiles As CCalculationProfileCatalog: Set profiles = New CCalculationProfileCatalog: profiles.LoadFromWorkbook ThisWorkbook
    Dim batch As CBatchSectionCalculator: Set batch = New CBatchSectionCalculator
    batch.Initialize model, provider: Set batch.ProfileCatalog = profiles: batch.ApplySettings settings, units
    Audit03ApplyLoadReferenceForTests model, settings, units, batch
    batch.AddCombination "PERF_01", -100000#, 1000000#, -800000#, "PR1", "Контроль сходимости сетки.", "Auto"
    started = Timer: batch.Execute
    TestCheck "reference." & mode & ".available", batch.ResultAt(1).StrengthResult.DirectState.StateAvailable
    TestCheck "reference." & mode & ".converged", batch.ResultAt(1).StrengthResult.DirectState.StateConverged
    Dim state As CSectionStateResult: Set state = batch.ResultAt(1).StrengthResult.DirectState.StateResult
    mReport = mReport & "REFERENCE mode=" & mode & "; sx=" & CStr(sx) & "; sy=" & CStr(sy) & "; count=" & CStr(count) & _
        "; buildSeconds=" & CStr(buildSeconds) & "; solveSeconds=" & CStr(ElapsedSecondsFrom(started)) & "; status=" & batch.ResultAt(1).Status & _
        "; eps=" & CStr(state.Epsilon0) & "; kx=" & CStr(state.KappaX) & "; ky=" & CStr(state.KappaY) & _
        "; N=" & CStr(state.TargetN) & "; Mx=" & CStr(state.TargetMx) & "; My=" & CStr(state.TargetMy) & _
        "; Nint=" & CStr(state.Nint) & "; Mxint=" & CStr(state.Mxint) & "; Myint=" & CStr(state.Myint) & _
        "; comment=" & batch.ResultAt(1).OverallMeta.ResultComment & vbCrLf
    Set TestReference = state
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Нормирует ошибки коэффициентов единой плоскости на наибольшую деформацию
' эталона с характерными полными размерами сечения; почти нулевой член не делит.
Private Function TestFieldError(ByVal epsilon As Double, ByVal kx As Double, ByVal ky As Double, _
        ByVal reference As CSectionStateResult, ByVal width As Double, ByVal height As Double) As Double
    Dim norm As Double: norm = Abs(reference.Epsilon0)
    If Abs(reference.KappaX) * height > norm Then norm = Abs(reference.KappaX) * height
    If Abs(reference.KappaY) * width > norm Then norm = Abs(reference.KappaY) * width
    If norm <= 0# Then Err.Raise 5, , "Нулевая норма эталонного поля."
    Dim fieldError As Double: fieldError = Abs(epsilon - reference.Epsilon0)
    If Abs(kx - reference.KappaX) * height > fieldError Then fieldError = Abs(kx - reference.KappaX) * height
    If Abs(ky - reference.KappaY) * width > fieldError Then fieldError = Abs(ky - reference.KappaY) * width
    TestFieldError = fieldError / norm
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет наличие границы каждой ячейки, включая внутренние прямоугольники.
Private Sub TestExactModel(ByVal label As String, ByVal model As CSectionModel)
    Dim i As Long: TestCheck label & ".nonempty", model.ConcreteCount > 0
    For i = 1 To model.ConcreteCount
        TestCheck label & ".boundary." & model.ConcreteID(i), model.ConcreteHasBoundary(i)
        TestCheck label & ".shape." & model.ConcreteID(i), model.ConcreteShapeType(i) = "Contour"
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет весь сохранённый набор и области без требования одинакового порядка рёбер.
Private Sub TestCompareModels(ByVal expected As CSectionModel, ByVal actual As CSectionModel)
    TestCheck "saved.count", expected.ConcreteCount = actual.ConcreteCount
    TestCheck "saved.rebar", expected.RebarCount = actual.RebarCount
    If expected.ConcreteCount <> actual.ConcreteCount Then Exit Sub
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim i As Long
    For i = 1 To expected.ConcreteCount
        TestCheck "saved.ID." & CStr(i), expected.ConcreteID(i) = actual.ConcreteID(i)
        TestCheck "saved.boundary." & CStr(i), actual.ConcreteHasBoundary(i)
        TestCheck "saved.region." & CStr(i), query.RegionsCoincide(expected.ConcreteGeometry(i), actual.ConcreteGeometry(i))
        TestNear "saved.A." & CStr(i), actual.ConcreteArea(i), expected.ConcreteArea(i), 0.0000000001
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считывает единицы из одного свежего снимка настроек после изменения fixture.
Private Sub TestReadSettings(ByRef settings As CSystemSettingsReader, ByRef units As CUnitSystem)
    Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    Set units = New CUnitSystem: units.LoadFromSettings settings
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Изменяет только значение фактической настройки по её ключу, без жёсткой ячейки.
Private Sub TestSetting(ByVal key As String, ByVal value As Variant)
    Dim table As Object, data As Variant, row As Long
    Set table = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange: data = table.Value2
    For row = 1 To UBound(data, 1)
        If CStr(data(row, 1)) = key Then table.Cells(row, 2).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, "TestSetting", "Нет настройки " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задаёт INPUT/OUTPUT через существующую пользовательскую таблицу единиц.
Private Sub TestUnit(ByVal key As String, ByVal inputUnit As String, ByVal outputUnit As String)
    Dim table As Object, row As Long: Set table = ThisWorkbook.Names.Item("rngUnitSettings").RefersToRange
    For row = 1 To table.Rows.Count
        If CStr(table.Cells(row, 1).Value2) = key Then table.Cells(row, 2).Value2 = inputUnit: table.Cells(row, 4).Value2 = outputUnit: Exit Sub
    Next row
    Err.Raise 5, , "Нет единицы " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет пользовательский знак, сохраняя неизменным внутренний контракт.
Private Sub TestSign(ByVal key As String, ByVal value As String)
    Dim table As Object, row As Long: Set table = ThisWorkbook.Names.Item("rngSignConventionSettings").RefersToRange
    For row = 1 To table.Rows.Count
        If CStr(table.Cells(row, 1).Value2) = key Then table.Cells(row, 2).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, , "Нет знака " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Регистрирует численное сравнение с абсолютным запасом для нулевых координат.
Private Sub TestNear(ByVal label As String, ByVal actual As Double, ByVal expected As Double, ByVal relative As Double)
    TestCheck label & "; actual=" & CStr(actual) & "; expected=" & CStr(expected), Abs(actual - expected) <= 0.00000001 + relative * Abs(expected)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет первичный отказ и продолжает независимые проверки текущего случая.
Private Sub TestCheck(ByVal label As String, ByVal passed As Boolean)
    If passed Then mPassed = mPassed + 1 Else mFailed = mFailed + 1
    mReport = mReport & IIf(passed, "PASS ", "FAIL ") & label & vbCrLf
End Sub
