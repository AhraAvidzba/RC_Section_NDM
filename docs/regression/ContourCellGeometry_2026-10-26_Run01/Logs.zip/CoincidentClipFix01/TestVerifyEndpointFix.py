"""Independent diagnostic of the narrow endpoint rule; no Excel/native PASS."""
import json
from math import pi, hypot, sin, cos, fsum
from pathlib import Path
import TestReproduceClip as geom


def arc_crossing(edge, u):
    _, py = geom.point(edge, u)
    _, dy = geom.tangent(edge, u)
    if abs(dy) > geom.QT:
        if (geom.PT < u < 1 - geom.PT) or (u <= geom.PT and dy > 0) or (u >= 1 - geom.PT and dy < 0):
            return 1 if dy > 0 else -1
    elif py < edge.cy:
        if u <= geom.PT:
            return 1
        if u >= 1 - geom.PT:
            return -1
    return 0


def fixed_contains(edges, x, y):
    winding = 0
    for edge in edges:
        if abs(edge.sweep) <= geom.PT:
            f1, f2 = edge.y1-y, edge.y2-y
            if abs(f1) <= geom.QT: f1 = 0.
            if abs(f2) <= geom.QT: f2 = 0.
            if (f1 <= 0 < f2) or (f2 <= 0 < f1):
                cross_x = edge.x1 - f1*(edge.x2-edge.x1)/(f2-f1)
                if cross_x > x: winding += 1 if edge.y2 > edge.y1 else -1
        else:
            parameters = geom.cuts(edge, 0, 1, y)
            if abs(edge.y1-y) <= geom.QT: geom.add(parameters, 0.)
            if abs(edge.y2-y) <= geom.QT: geom.add(parameters, 1.)
            seen = set()
            for u in parameters:
                if u*geom.length(edge) <= geom.QT: u = 0.
                if (1-u)*geom.length(edge) <= geom.QT: u = 1.
                if u in (0., 1.):
                    if u in seen: continue
                    seen.add(u)
                px, _ = geom.point(edge, u)
                if px > x: winding += arc_crossing(edge, u)
    return winding > 0


def area(edges):
    terms = []
    for edge in edges:
        terms.append((edge.x1*edge.y2-edge.x2*edge.y1)/2)
        if abs(edge.sweep) > geom.PT:
            r = hypot(edge.x1-edge.cx, edge.y1-edge.cy)
            terms.append(r*r*(edge.sweep-sin(edge.sweep))/2)
    return fsum(terms)


def corner(at_start=True, upper=False):
    if at_start:
        edges = [geom.Edge(0, 0, 10, 10, 0, 10, pi/2), geom.Edge(10, 10, -10, 10),
                 geom.Edge(-10, 10, -10, -10), geom.Edge(-10, -10, 0, -10), geom.Edge(0, -10, 0, 0)]
    else:
        edges = [geom.Edge(-10, 10, 0, 0, 0, 10, pi/2), geom.Edge(0, 0, 0, -10),
                 geom.Edge(0, -10, 10, -10), geom.Edge(10, -10, 10, 10), geom.Edge(10, 10, -10, 10)]
    if upper:
        edges = [geom.Edge(e.x2, -e.y2, e.x1, -e.y1, e.cx, -e.cy, e.sweep) for e in reversed(edges)]
    return edges


if __name__ == '__main__':
    checks = []
    def check(name, actual, expected):
        checks.append({'Name':name, 'Actual':actual, 'Expected':expected, 'Passed':actual==expected})
    # Signed endpoint contract directly exercises both sweep directions.
    for sweep_sign in (-1, 1):
        for endpoint in (0., 1.):
            for lower in (False, True):
                angle = -pi/2 if lower else pi/2
                start = angle - endpoint*sweep_sign*pi/2
                end = start+sweep_sign*pi/2
                edge = geom.Edge(10*cos(start), 10*sin(start), 10*cos(end), 10*sin(end), 0, 0, sweep_sign*pi/2)
                expected = (1 if endpoint == 0 else -1) if lower else 0
                check(f'endpoint.sign{sweep_sign}.u{endpoint}.lower{lower}', arc_crossing(edge, endpoint), expected)
        edge = geom.Edge(-10, 0, 10, 0, 0, 0, sweep_sign*pi)
        check(f'interior.tangent.sign{sweep_sign}', arc_crossing(edge, .5), 0)
    for start in (False, True):
        for upper in (False, True):
            shape = corner(start, upper)
            check(f'corner.start{start}.upper{upper}.left', fixed_contains(shape, -5, 0), start)
            check(f'corner.start{start}.upper{upper}.right', fixed_contains(shape, 5, 0), not start)
            check(f'corner.start{start}.upper{upper}.outside', fixed_contains(shape, -15, 0), False)
            outer = [geom.Edge(-50,-50,50,-50), geom.Edge(50,-50,50,50), geom.Edge(50,50,-50,50), geom.Edge(-50,50,-50,-50)]
            hole = [geom.Edge(e.x2,e.y2,e.x1,e.y1,e.cx,e.cy,-e.sweep) for e in shape]
            check(f'hole.start{start}.upper{upper}.left', fixed_contains(outer+hole, -5, 0), not start)
            check(f'hole.start{start}.upper{upper}.right', fixed_contains(outer+hole, 5, 0), start)
    circular = [geom.Edge(10*cos(i*pi/2),10*sin(i*pi/2),10*cos((i+1)*pi/2),10*sin((i+1)*pi/2),0,0,pi/2) for i in range(4)]
    check('fullCircle.lowerTangentOutside', fixed_contains(circular, -15,-10), False)
    check('fullCircle.upperTangentOutside', fixed_contains(circular, -15,10), False)
    check('fullCircle.middleOutside', fixed_contains(circular, -15,0), False)
    check('fullCircle.centerInside', fixed_contains(circular, 0,0), True)
    geom.contains = fixed_contains
    region = geom.domain()
    records = []
    for width, height in [(50,100), (25,50), (12.5,25)]:
        pieces = []
        for row in range(round(1200/height)):
            for column in range(round(1000/width)):
                x, y = -500+column*width, -600+row*height
                current = region
                for nx, ny, bound in [(1,0,x),(-1,0,-x-width),(0,1,y),(0,-1,-y-height)]:
                    current = geom.clip(current,nx,ny,bound)
                if current: pieces.append(area(current))
        actual, expected = fsum(pieces), area(region)
        records.append({'Step':[width,height], 'NonemptyCells':len(pieces), 'ActualArea':actual,'ExpectedArea':expected,'Error':actual-expected})
        check(f'hollow{width}x{height}.closedAndArea', abs(actual-expected)<1e-7, True)
    result = {'NativeExcelStarted':False,'DiagnosticTranslation':True,'Checks':checks,'Meshes':records,
              'Passed':sum(c['Passed'] for c in checks),'Failed':sum(not c['Passed'] for c in checks)}
    Path(__file__).with_name('EndpointVerification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'Passed':result['Passed'],'Failed':result['Failed'],'Meshes':records}))
    raise SystemExit(bool(result['Failed']))
