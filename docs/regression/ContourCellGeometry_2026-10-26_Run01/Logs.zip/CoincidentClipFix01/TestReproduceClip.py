"""Diagnostic translation of the existing line/arc clip; not a native VBA PASS."""
from dataclasses import dataclass, asdict
from math import atan2, cos, sin, sqrt, tan, pi, hypot, copysign
import json
from pathlib import Path

QT=1e-6
PT=1e-10
GT=1e-9

@dataclass
class Edge:
    x1:float; y1:float; x2:float; y2:float
    cx:float=0.; cy:float=0.; sweep:float=0.

def same(a,b):return abs(a[0]-b[0])<=QT and abs(a[1]-b[1])<=QT
def length(e):return hypot(e.x2-e.x1,e.y2-e.y1) if abs(e.sweep)<=PT else hypot(e.x1-e.cx,e.y1-e.cy)*abs(e.sweep)
def point(e,u):
    if abs(e.sweep)<=PT:return e.x1+u*(e.x2-e.x1),e.y1+u*(e.y2-e.y1)
    r=hypot(e.x1-e.cx,e.y1-e.cy);a=atan2(e.y1-e.cy,e.x1-e.cx)+u*e.sweep
    return e.cx+r*cos(a),e.cy+r*sin(a)
def tangent(e,u):
    if abs(e.sweep)<=PT:return e.x2-e.x1,e.y2-e.y1
    x,y=point(e,u);return -(y-e.cy)*e.sweep,(x-e.cx)*e.sweep
def parameter(e,x,y):
    if abs(e.sweep)<=PT:
        dx=e.x2-e.x1;dy=e.y2-e.y1;sq=dx*dx+dy*dy
        if sq<=QT*QT:return None
        u=((x-e.x1)*dx+(y-e.y1)*dy)/sq
        if not -PT<=u<=1+PT or not same((e.x1+u*dx,e.y1+u*dy),(x,y)):return None
    else:
        if abs(hypot(x-e.cx,y-e.cy)-hypot(e.x1-e.cx,e.y1-e.cy))>QT:return None
        d=atan2(y-e.cy,x-e.cx)-atan2(e.y1-e.cy,e.x1-e.cx)
        if e.sweep>0:
            while d < -PT:d+=2*pi
        else:
            while d>PT:d-=2*pi
        u=d/e.sweep
        if not -PT<=u<=1+PT:return None
    return max(0.,min(1.,u))
def add(a,x):
    if not any(abs(v-x)<=PT for v in a):a.append(x)
def cuts(e,nx,ny,bound):
    out=[]
    if abs(e.sweep)<=PT:
        f1=nx*e.x1+ny*e.y1-bound;f2=nx*e.x2+ny*e.y2-bound
        if abs(f1)<=QT:add(out,0.)
        if abs(f2)<=QT:add(out,1.)
        if abs(f1-f2)>GT:
            u=f1/(f1-f2)
            if PT<u<1-PT:add(out,u)
    else:
        r=hypot(e.x1-e.cx,e.y1-e.cy);norm=hypot(nx,ny);dist=(bound-nx*e.cx-ny*e.cy)/norm
        if abs(dist)>r+QT:return out
        roundoff=3.5527136788005e-15*((abs(bound)+abs(nx*e.cx)+abs(ny*e.cy))/norm+r+1)
        if abs(abs(dist)-r)<=roundoff:dist=copysign(r,dist)
        if abs(dist)>r:dist=copysign(r,dist)
        bx=e.cx+nx/norm*dist;by=e.cy+ny/norm*dist;offset=sqrt(max((r-abs(dist))*(r+abs(dist)),0))
        for x,y in ((bx-ny/norm*offset,by+nx/norm*offset),(bx+ny/norm*offset,by-nx/norm*offset)):
            u=parameter(e,x,y)
            if u is not None:add(out,u)
    return out
def contains(es,x,y):
    winding=0
    for e in es:
        if abs(e.sweep)<=PT:
            f1=e.y1-y;f2=e.y2-y
            if abs(f1)<=QT:f1=0.
            if abs(f2)<=QT:f2=0.
            if (f1<=0<f2) or (f2<=0<f1):
                cx=e.x1-f1*(e.x2-e.x1)/(f2-f1)
                if cx>x:winding+=1 if e.y2>e.y1 else -1
        else:
            us=cuts(e,0,1,y)
            if abs(e.y1-y)<=QT:add(us,0.)
            if abs(e.y2-y)<=QT:add(us,1.)
            seen=set()
            for u in us:
                if u*length(e)<=QT:u=0.
                if (1-u)*length(e)<=QT:u=1.
                if u in (0.,1.):
                    if u in seen:continue
                    seen.add(u)
                px,py=point(e,u);tx,ty=tangent(e,u)
                if px>x and abs(ty)>QT and ((PT<u<1-PT) or (u<=PT and ty>0) or (u>=1-PT and ty<0)):
                    winding+=1 if ty>0 else -1
    return winding>0
def has_material(es,nx,ny,bound,x,y):
    for e in es:
        if abs(e.sweep)<=PT and abs(nx*e.x1+ny*e.y1-bound)<=QT and abs(nx*e.x2+ny*e.y2-bound)<=QT:
            if parameter(e,x,y) is not None:return nx*(e.y1-e.y2)+ny*(e.x2-e.x1)>0
    return contains(es,x,y)
def projection(es,nx,ny):
    values=[]
    for e in es:
        values.extend((nx*e.x1+ny*e.y1,nx*e.x2+ny*e.y2))
        if abs(e.sweep)>PT:
            r=hypot(e.x1-e.cx,e.y1-e.cy)
            for s in (-1,1):
                x=e.cx+s*r*nx;y=e.cy+s*r*ny
                if parameter(e,x,y) is not None:values.append(nx*x+ny*y)
    return min(values),max(values)
def stitch(es):
    ordered=[];used=set()
    for i,first in enumerate(es):
        if i in used:continue
        current=first;used.add(i)
        while True:
            ordered.append(current)
            if same((current.x2,current.y2),(first.x1,first.y1)):break
            candidates=[];ax,ay=tangent(current,1)
            for j,e in enumerate(es):
                if j not in used and same((current.x2,current.y2),(e.x1,e.y1)):
                    bx,by=tangent(e,0);candidates.append((atan2(ax*by-ay*bx,ax*bx+ay*by),j,e))
            if not candidates:raise ValueError({'OpenEnd':(current.x2,current.y2),'Edges':[asdict(x) for x in es]})
            _,j,current=max(candidates);used.add(j)
    return ordered
def clip(es,nx,ny,bound):
    if not es:return []
    lo,hi=projection(es,nx,ny);roundoff=3.5527136788005e-15*(abs(lo)+abs(hi)+abs(bound)+1)
    if bound<=lo+roundoff:return es
    if bound>=hi-roundoff:return []
    out=[];line=[]
    for e in es:
        us=[0.,1.]
        for u in cuts(e,nx,ny,bound):add(us,u)
        us.sort()
        for u in us:
            x,y=point(e,u)
            if abs(nx*x+ny*y-bound)<=QT:add(line,ny*x-nx*y)
        for a,b in zip(us,us[1:]):
            x,y=point(e,(a+b)/2)
            if nx*x+ny*y>bound:
                x1,y1=point(e,a);x2,y2=point(e,b);piece=Edge(x1,y1,x2,y2,e.cx,e.cy,e.sweep*(b-a))
                if abs(piece.sweep)>PT or abs(nx*x1+ny*y1-bound)>QT or abs(nx*x2+ny*y2-bound)>QT:
                    if length(piece)>QT:out.append(piece)
    line.sort()
    for a,b in zip(line,line[1:]):
        mid=(a+b)/2;x=nx*bound+ny*mid;y=ny*bound-nx*mid
        if has_material(es,nx,ny,bound,x,y):
            e=Edge(nx*bound+ny*a,ny*bound-nx*a,nx*bound+ny*b,ny*bound-nx*b)
            if length(e)>QT:out.append(e)
    return stitch(out)
def rounded(w,h,r):
    points=[(-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)];es=[];d=r*tan(pi/4)
    for i,(x,y) in enumerate(points):
        prev=points[(i-1)%4];nxt=points[(i+1)%4];dx=x-prev[0];dy=y-prev[1];norm=hypot(dx,dy);dx/=norm;dy/=norm
        ex=nxt[0]-x;ey=nxt[1]-y;norm=hypot(ex,ey);ex/=norm;ey/=norm
        x1=x-dx*d;y1=y-dy*d;x2=x+ex*d;y2=y+ey*d
        es.append(Edge(x1,y1,x2,y2,x1-dy*r,y1+dx*r,pi/2))
        es.append(Edge(x2,y2,nxt[0]-ex*d,nxt[1]-ey*d))
    return es
def domain():
    outer=rounded(1000,1200,60);hole=[Edge(e.x2,e.y2,e.x1,e.y1,e.cx,e.cy,-e.sweep) for e in rounded(400,500,30)]
    return stitch(outer+hole)

if __name__=='__main__':
    es=domain();record={'NativeExcelStarted':False,'DiagnosticTranslation':True,'Cases':[]}
    for bounds in [(-200,-250,-175,-200),(-175,-250,-150,-200)]:
        current=es
        try:
            x0,y0,x1,y1=bounds
            for name,nx,ny,bound in [('xMin',1,0,x0),('xMax',-1,0,-x1),('yMin',0,1,y0),('yMax',0,-1,-y1)]:
                current=clip(current,nx,ny,bound)
            record['Cases'].append({'Bounds':bounds,'Closed':True})
        except ValueError as error:record['Cases'].append({'Bounds':bounds,'Stage':name,'Plane':(nx,ny,bound),'Input':[asdict(x) for x in current],'Closed':False,'Error':error.args[0]})
    Path(__file__).with_name('Diagnostic.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps([{k:v for k,v in c.items() if k not in ('Input','Error')} for c in record['Cases']]))
