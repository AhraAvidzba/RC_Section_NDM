﻿# ДЛЯ ТЕСТОВ: внешний timeout ограниченного NativeCAD worker, не полный прогон.
# Чужие процессы запрещены; завершение допустимо только по точной own identity и SourceSHA256.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$SourceWorkbook,
    [Parameter(Mandatory=$true)][string]$EvidenceDirectory,
    [ValidateRange(60,1800)][int]$TimeoutSeconds=900,
    [double]$MinimumFreeRAMGiB=8,
    [double]$MinimumFreeCommitGiB=14,
    [string]$RunnerFile=''
)
$ErrorActionPreference='Stop'
if([string]::IsNullOrWhiteSpace($RunnerFile)){$RunnerFile=Join-Path $PSScriptRoot 'Test-RunNativeContourCells.ps1'}
if($PSVersionTable.PSVersion.Major -ne 5){throw 'Use Windows PowerShell 5.1.'}
if($MinimumFreeRAMGiB -lt 4 -or $MinimumFreeCommitGiB -lt 8){throw 'Absolute minimum reserve is 4 GiB RAM / 8 GiB commit.'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$source=(Resolve-Path -LiteralPath $SourceWorkbook).Path
$runner=(Resolve-Path -LiteralPath $RunnerFile).Path
$evidence=[IO.Path]::GetFullPath((Join-Path $root $EvidenceDirectory))
$control=$evidence+'.Watchdog'
$allowed=(Join-Path $root 'docs/regression')+[IO.Path]::DirectorySeparatorChar
if(-not $evidence.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase) -or -not $control.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)){throw 'Evidence and control directories must stay in docs/regression.'}
if((Test-Path -LiteralPath $evidence) -or (Test-Path -LiteralPath $control)){throw 'Use fresh evidence/control directories.'}
[void][IO.Directory]::CreateDirectory($control)
function Write-Control([string]$name,$value){$value | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $control $name) -Encoding UTF8}
function Exact-Process([int]$processID,[long]$ticks,[string]$name){
    if($processID -le 0 -or $ticks -le 0){return $null}
    $process=Get-Process -Id $processID -ErrorAction SilentlyContinue
    if(-not $process){return $null}
    try{if($process.ProcessName -ieq $name -and $process.StartTime.ToUniversalTime().Ticks -eq $ticks){return $process}}catch{}
    return $null
}
function Read-Ownership {
    $path=Join-Path $evidence 'Ownership.json'
    if(-not (Test-Path -LiteralPath $path)){return $null}
    for($attempt=0;$attempt -lt 5;$attempt++){
        try{return Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json}
        catch{if($attempt -eq 4){return $null};Start-Sleep -Milliseconds 100}
    }
}
function Owned-Identities($ownership){
    if(-not $ownership -or [string]$ownership.SourceSHA256 -cne $sourceHash){return @()}
    $result=@()
    foreach($spec in @(@('ExcelPID','ExcelStartTicksUTC','EXCEL'),@('CADPID','CADStartTicksUTC','acad'))){
        $processID=[int]$ownership.($spec[0]);$ticks=[long]$ownership.($spec[1])
        if($processID -le 0 -or $ticks -le 0){continue}
        if(($spec[2] -eq 'EXCEL' -and $processID -in $priorExcel) -or ($spec[2] -eq 'acad' -and $processID -in $priorCAD)){continue}
        $result+=,[ordered]@{PID=$processID;StartTicksUTC=[string]$ticks;Name=$spec[2];SourceSHA256=$sourceHash}
    }
    return $result
}
function Stop-ExactOwned($identity,[string]$reason){
    $process=Exact-Process ([int]$identity.PID) ([long]$identity.StartTicksUTC) ([string]$identity.Name)
    $before=$null
    if($process){
        $before=[ordered]@{PID=$process.Id;Name=$process.ProcessName;StartTicksUTC=[string]$process.StartTime.ToUniversalTime().Ticks;CPUSeconds=$process.CPU;WorkingSet=$process.WorkingSet64}
        Stop-Process -Id $process.Id -Force
        try{[void]$process.WaitForExit(3000)}catch{}
    }
    $absent=$null -eq (Exact-Process ([int]$identity.PID) ([long]$identity.StartTicksUTC) ([string]$identity.Name))
    return [ordered]@{Reason=$reason;Identity=$identity;Before=$before;Stopped=($null -ne $before);ExactIdentityAbsent=$absent}
}
$sourceHash=(Get-FileHash -LiteralPath $source).Hash
$priorExcel=@(Get-Process EXCEL -ErrorAction SilentlyContinue | ForEach-Object Id)
$priorCAD=@(Get-Process acad -ErrorAction SilentlyContinue | ForEach-Object Id)
$memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$freeRAM=[double]$memory.AvailableMBytes/1024
$freeCommit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
Write-Control 'Launch.json' ([ordered]@{ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');SourceWorkbook=$source;SourceSHA256=$sourceHash;Runner=$runner;RunnerSHA256=(Get-FileHash -LiteralPath $runner).Hash;
    EvidenceDirectory=$evidence;ControlDirectory=$control;TimeoutSeconds=$TimeoutSeconds;PriorExcel=$priorExcel;PriorCAD=$priorCAD;
    FreeRAMGiB=$freeRAM;FreeCommitGiB=$freeCommit;MinimumRAMGiB=$MinimumFreeRAMGiB;MinimumCommitGiB=$MinimumFreeCommitGiB;FullRegressionRun=$false})
if($freeRAM -lt $MinimumFreeRAMGiB -or $freeCommit -lt $MinimumFreeCommitGiB){throw 'Memory gate failed; native worker not started.'}
foreach($path in @($source,$runner,$evidence)){if($path.Contains('"')){throw 'Unexpected quote in filesystem path.'}}
$stdout=Join-Path $control 'Worker.stdout.log';$stderr=Join-Path $control 'Worker.stderr.log'
$arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$runner+'" -SourceWorkbook "'+$source+'" -EvidenceDirectory "'+$evidence+'" -MinimumFreeRAMGiB '+$MinimumFreeRAMGiB.ToString([Globalization.CultureInfo]::InvariantCulture)+' -MinimumFreeCommitGiB '+$MinimumFreeCommitGiB.ToString([Globalization.CultureInfo]::InvariantCulture)
$worker=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -WindowStyle Hidden -WorkingDirectory $root -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
$workerTicks=$worker.StartTime.ToUniversalTime().Ticks
Write-Control 'WorkerIdentity.json' ([ordered]@{PID=$worker.Id;StartTicksUTC=[string]$workerTicks;SourceSHA256=$sourceHash;RunnerSHA256=(Get-FileHash -LiteralPath $runner).Hash})
$clock=[Diagnostics.Stopwatch]::StartNew();$timedOut=$false;$cleanup=@();$ownership=$null
while(-not $worker.WaitForExit(1000)){
    $ownership=Read-Ownership
    Write-Control 'WatchdogLast.json' ([ordered]@{ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');ElapsedSeconds=$clock.Elapsed.TotalSeconds;TimeoutSeconds=$TimeoutSeconds;
        WorkerPID=$worker.Id;WorkerStartTicksUTC=[string]$workerTicks;WorkerIdentityLive=($null -ne (Exact-Process $worker.Id $workerTicks 'powershell'));Ownership=$ownership})
    if($clock.Elapsed.TotalSeconds -lt $TimeoutSeconds){continue}
    $timedOut=$true
    Write-Control 'TimeoutEvidence.json' ([ordered]@{ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');ElapsedSeconds=$clock.Elapsed.TotalSeconds;Ownership=$ownership;
        StdoutTail=@(Get-Content -LiteralPath $stdout -Tail 40 -ErrorAction SilentlyContinue);StderrTail=@(Get-Content -LiteralPath $stderr -Tail 40 -ErrorAction SilentlyContinue)})
    foreach($identity in (Owned-Identities $ownership)){$cleanup+=,(Stop-ExactOwned $identity 'Native worker timeout after recorded deadline')}
    $cleanup+=,(Stop-ExactOwned ([ordered]@{PID=$worker.Id;StartTicksUTC=[string]$workerTicks;Name='powershell';SourceSHA256=$sourceHash}) 'Exact own worker timeout')
    break
}
if(-not $timedOut){$worker.WaitForExit()}
$clock.Stop();$ownership=Read-Ownership
$orphans=@()
foreach($identity in (Owned-Identities $ownership)){
    if(Exact-Process ([int]$identity.PID) ([long]$identity.StartTicksUTC) ([string]$identity.Name)){
        $orphans+=,$identity
        $cleanup+=,(Stop-ExactOwned $identity 'Own native worker exited but left a recorded orphan')
    }
}
Write-Control 'WatchdogCleanup.json' $cleanup
$sourceUnchanged=(Get-FileHash -LiteralPath $source).Hash -ceq $sourceHash
$nativeAcceptance=$null
try{$nativeAcceptance=Get-Content -LiteralPath (Join-Path $evidence 'Acceptance.json') -Raw -Encoding UTF8 | ConvertFrom-Json}catch{}
$exitCode=$null;if(-not $timedOut){$exitCode=$worker.ExitCode}
$completed=-not $timedOut -and $exitCode -eq 0 -and $sourceUnchanged -and $orphans.Count -eq 0 -and $nativeAcceptance -and $nativeAcceptance.Passed
Write-Control 'Completion.json' ([ordered]@{Status=$(if($completed){'NATIVE_WORKER_COMPLETED_REVIEW_PRIMARY'}else{'REVIEW_REQUIRED'});ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');
    TimedOut=$timedOut;ElapsedSeconds=$clock.Elapsed.TotalSeconds;WorkerExitCode=$exitCode;SourceUnchanged=$sourceUnchanged;SourceSHA256=$sourceHash;
    OrphansAfterWorkerExit=$orphans;NativeAcceptance=$nativeAcceptance;PrimaryReviewStillRequired=$true;FullRegressionPass=$false})
if(-not $completed){throw 'Native worker did not complete cleanly; inspect control and primary evidence.'}
Get-Content -LiteralPath (Join-Path $control 'Completion.json') -Raw
