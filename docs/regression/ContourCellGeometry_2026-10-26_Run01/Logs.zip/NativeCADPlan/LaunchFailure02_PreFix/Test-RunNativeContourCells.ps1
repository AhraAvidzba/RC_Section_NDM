﻿# ДЛЯ ТЕСТОВ: адресный настоящий Excel/AutoCAD roundtrip, не полный набор.
# Запускать после compile/unit gates через внешний watchdog (рекомендуется 900 секунд).
# До каждого тяжелого процесса проверяется общий запас RAM/commit; пользовательские PID/DWG запрещены.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$SourceWorkbook,
    [Parameter(Mandatory=$true)][string]$EvidenceDirectory,
    [string]$HelperFile='',
    [double]$MinimumFreeRAMGiB=8,
    [double]$MinimumFreeCommitGiB=14,
    [string]$CADProgId='AutoCAD.Application.24.2'
)
$ErrorActionPreference='Stop'
if([string]::IsNullOrWhiteSpace($HelperFile)){$HelperFile=Join-Path $PSScriptRoot 'TestNativeContourCellProbe.bas'}
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
if($PSVersionTable.PSVersion.Major -ne 5){throw 'Use Windows PowerShell 5.1.'}
if($MinimumFreeRAMGiB -lt 4 -or $MinimumFreeCommitGiB -lt 8){throw 'Absolute minimum reserve is 4 GiB RAM / 8 GiB commit.'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$source=(Resolve-Path -LiteralPath $SourceWorkbook).Path
$helper=(Resolve-Path -LiteralPath $HelperFile).Path
$directory=[IO.Path]::GetFullPath((Join-Path $root $EvidenceDirectory))
$allowed=(Join-Path $root 'docs/regression')+[IO.Path]::DirectorySeparatorChar
if(-not $directory.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)){throw 'Evidence directory must stay inside docs/regression.'}
if(Test-Path -LiteralPath $directory){throw 'Use a fresh evidence directory.'}
[void][IO.Directory]::CreateDirectory($directory)
$sourceHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$helperHash=(Get-FileHash -LiteralPath $helper -Algorithm SHA256).Hash
$candidate=Join-Path $directory 'NativeContourProbe.xlsm'
Copy-Item -LiteralPath $source -Destination $candidate

function Write-Proof([string]$name,$value){
    $value | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $directory $name) -Encoding UTF8
}
function Read-MemoryGate([string]$stage){
    $memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
    $physical=[double]$memory.AvailableMBytes/1024
    $commit=([double]$memory.CommitLimit-[double]$memory.CommittedBytes)/1GB
    $value=[ordered]@{ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');Stage=$stage;FreeRAMGiB=$physical;FreeCommitGiB=$commit;
        RequiredRAMGiB=$MinimumFreeRAMGiB;RequiredCommitGiB=$MinimumFreeCommitGiB;Ready=($physical -ge $MinimumFreeRAMGiB -and $commit -ge $MinimumFreeCommitGiB);
        Accounting='Combined free system reserve including already active processes; CAD peak and Codex reserve included in defaults.'}
    Write-Proof ('Memory_'+$stage+'.json') $value
    if(-not $value.Ready){throw ('Insufficient combined memory reserve before '+$stage+'; no new heavy process started.')}
}
function Get-ProcessInventory([string]$name){
    @((Get-Process -Name $name -ErrorAction SilentlyContinue) | ForEach-Object {
        [ordered]@{PID=$_.Id;Name=$_.ProcessName;StartTicksUTC=[string]$_.StartTime.ToUniversalTime().Ticks}
    })
}
function Native-Property($target,[string]$name){
    for($attempt=0;$attempt -lt 80;$attempt++){
        try{return $target.GetType().InvokeMember($name,[Reflection.BindingFlags]::GetProperty,$null,$target,$null)}
        catch{if($attempt -eq 79){throw};Start-Sleep -Milliseconds 250}
    }
}
function Test-ExactProcess([int]$processID,[long]$startTicks,[string]$name){
    if(-not $processID){return $false}
    $process=Get-Process -Id $processID -ErrorAction SilentlyContinue
    if(-not $process){return $false}
    try{return $process.ProcessName -ieq $name -and $process.StartTime.ToUniversalTime().Ticks -eq $startTicks}catch{return $false}
}
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class NdmNativeCellOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$priorExcel=Get-ProcessInventory 'EXCEL';$priorCAD=Get-ProcessInventory 'acad'
$priorExcelIDs=@($priorExcel | ForEach-Object {$_.PID});$priorCADIDs=@($priorCAD | ForEach-Object {$_.PID})
$excel=$null;$book=$null;$acad=$null;$document=$null;$previousDocument=$null;$excelID=0;$cadID=0;$excelTicks=0L;$cadTicks=0L
$ownedExcel=$false;$ownedCAD=$false;$macroPassed=$false;$failure=$null;$candidateHash=$null;$cleanup=@()
Write-Proof 'Input.json' ([ordered]@{Source=$source;SourceSHA256=$sourceHash;Helper=$helper;HelperSHA256=$helperHash;PrivateWorkbook=$candidate;
    ExistingExcel=$priorExcel;ExistingCAD=$priorCAD;FullRegressionRun=$false;PlannedMaximumSimultaneousExcel=1;PlannedMaximumSimultaneousCAD=1})
try{
    Read-MemoryGate 'BeforeExcel'
    $excel=New-Object -ComObject Excel.Application
    [uint32]$nativeID=0;[void][NdmNativeCellOwner]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$nativeID)
    $excelID=[int]$nativeID;$excelTicks=(Get-Process -Id $excelID).StartTime.ToUniversalTime().Ticks
    if($excelID -in $priorExcelIDs){throw 'Refusing to use a pre-existing Excel.'}
    $ownedExcel=$true
    Write-Proof 'Ownership.json' ([ordered]@{Status='PREPARING_NATIVE_HELPER';ExcelPID=$excelID;ExcelStartTicksUTC=[string]$excelTicks;CADPID=0;CADStartTicksUTC='0';UserDocumentsUsed=$false;SourceSHA256=$sourceHash})
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.AskToUpdateLinks=$false;$excel.AutomationSecurity=3
    $book=$excel.Workbooks.Open($candidate,0,$false)
    if($book.ReadOnly){throw 'Private injection workbook must be writable.'}
    $module=$null;try{$module=$book.VBProject.VBComponents.Item('modTestNativeContourCells')}catch{}
    if($module){throw 'Native helper already present; use an unmodified source Probe.'}
    $module=$book.VBProject.VBComponents.Add(1);$module.Name='modTestNativeContourCells'
    $body=[regex]::Match([IO.File]::ReadAllText($helper,[Text.Encoding]::UTF8),'(?ms)^Option Explicit.*').Value
    if(-not $body){throw 'Helper lacks Option Explicit.'}
    $module.CodeModule.AddFromString(($body -split '\r?\n') -join "`r`n")
    $excel.VBE.ActiveVBProject=$book.VBProject
    $compile=$excel.VBE.CommandBars.FindControl(1,578)
    if(-not $compile){throw 'VBE compile command unavailable.'}
    if($compile.Enabled){$compile.Execute()}
    if($compile.Enabled){
        $pane=$excel.VBE.ActiveCodePane;$sl=0;$sc=0;$el=0;$ec=0;$pane.GetSelection([ref]$sl,[ref]$sc,[ref]$el,[ref]$ec)
        Write-Proof 'HelperCompileFailure.json' ([ordered]@{Component=$pane.CodeModule.Parent.Name;Line=$sl;Text=$pane.CodeModule.Lines([math]::Max(1,$sl-2),5)})
        throw 'Native helper failed to compile.'
    }
    $book.Save();$book.Close($false);$book=$null;$candidateHash=(Get-FileHash -LiteralPath $candidate).Hash
    $excel.AutomationSecurity=1;$book=$excel.Workbooks.Open($candidate,0,$true)
    if(-not $book.ReadOnly){throw 'Native test workbook must reopen read-only.'}
    Read-MemoryGate 'BeforeAutoCAD'
    $acad=New-Object -ComObject $CADProgId
    [uint32]$nativeID=0;[void][NdmNativeCellOwner]::GetWindowThreadProcessId([IntPtr][long](Native-Property $acad 'HWND'),[ref]$nativeID)
    $cadID=[int]$nativeID;$cadTicks=(Get-Process -Id $cadID).StartTime.ToUniversalTime().Ticks
    if($cadID -in $priorCADIDs){throw 'Refusing to use a pre-existing AutoCAD process.'}
    $ownedCAD=$true
    Write-Proof 'Ownership.json' ([ordered]@{Status='PREPARING_OWN_DOCUMENT';ExcelPID=$excelID;ExcelStartTicksUTC=[string]$excelTicks;CADPID=$cadID;CADStartTicksUTC=[string]$cadTicks;UserDocumentsUsed=$false;SourceSHA256=$sourceHash})
    if((Native-Property $acad 'FullName') -cne 'C:\Program Files\Autodesk\AutoCAD 2023\acad.exe'){throw 'Unexpected AutoCAD executable.'}
    $acad.Visible=$false
    try{$previousDocument=$acad.ActiveDocument}catch{}
    $previousName=$null;if($previousDocument){$previousName=[string]$previousDocument.Name}
    $document=$acad.Documents.Add();$document.Activate()
    Write-Proof 'Ownership.json' ([ordered]@{Status='RUNNING_NATIVE';ExcelPID=$excelID;ExcelStartTicksUTC=[string]$excelTicks;CADPID=$cadID;CADStartTicksUTC=[string]$cadTicks;
        PreviousOwnCADDocument=$previousName;OwnTestDocument=[string]$document.Name;UserDocumentsUsed=$false;WorkbookSHA256=$candidateHash;SourceSHA256=$sourceHash})
    $prefix="'"+$book.Name+"'!modTestNativeContourCells.TestRunNativeContourCells"
    $clock=[Diagnostics.Stopwatch]::StartNew()
    $report=[string]$excel.Run($prefix,$document)
    $clock.Stop();[IO.File]::WriteAllText((Join-Path $directory 'NativeContourCells.txt'),$report,[Text.UTF8Encoding]::new($true))
    $match=[regex]::Match($report,'TOTAL_NATIVE_CONTOUR_CELLS: passed=(\d+); failed=(\d+)')
    $macroPassed=$match.Success -and [int]$match.Groups[2].Value -eq 0 -and $report -notmatch '(?m)^FAIL '
    Write-Proof 'NativeRun.json' ([ordered]@{CompletedUTC=[DateTimeOffset]::UtcNow.ToString('o');Seconds=$clock.Elapsed.TotalSeconds;MacroPassed=$macroPassed;
        PrimaryLog='NativeContourCells.txt';PrimarySHA256=(Get-FileHash -LiteralPath (Join-Path $directory 'NativeContourCells.txt')).Hash;
        AssertionsPassed=$(if($match.Success){[int]$match.Groups[1].Value}else{0});AssertionsFailed=$(if($match.Success){[int]$match.Groups[2].Value}else{$null})})
    $document.SaveAs((Join-Path $directory 'NativeContourCells.dwg'))
    $book.SaveCopyAs((Join-Path $directory 'NativeWorkingState.xlsm'))
    if(-not $macroPassed){throw 'Native primary log contains failed or missing assertions.'}
}catch{
    $failure=$_.Exception.ToString()
    Write-Proof 'Failure.json' ([ordered]@{ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o');Reason=$failure;MacroPassed=$macroPassed})
}finally{
    if($ownedCAD -and (Test-ExactProcess $cadID $cadTicks 'acad')){
        if($document){try{$document.Close($false)}catch{}}
        if($previousDocument){try{$previousDocument.Activate()}catch{}}
    }
    if($ownedExcel -and (Test-ExactProcess $excelID $excelTicks 'EXCEL')){
        if($book){try{$book.Close($false)}catch{}}
        if($excel){try{$excel.Quit()}catch{}}
    }
    if($ownedCAD -and (Test-ExactProcess $cadID $cadTicks 'acad')){try{$acad.Quit()}catch{}}
    $module=$null;$compile=$null;$pane=$null;$previousDocument=$null;$document=$null;$book=$null
    if($excel){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel);$excel=$null}
    if($acad){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($acad);$acad=$null}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    foreach($identity in @(@($excelID,$excelTicks,'EXCEL',$ownedExcel),@($cadID,$cadTicks,'acad',$ownedCAD))){
        $forced=$false
        if($identity[3] -and (Test-ExactProcess ([int]$identity[0]) ([long]$identity[1]) ([string]$identity[2]))){
            $process=Get-Process -Id ([int]$identity[0]);[void]$process.WaitForExit(3000)
            if(Test-ExactProcess ([int]$identity[0]) ([long]$identity[1]) ([string]$identity[2])){
                Stop-Process -Id ([int]$identity[0]) -Force;$forced=$true
            }
        }
        $absent=-not (Test-ExactProcess ([int]$identity[0]) ([long]$identity[1]) ([string]$identity[2]))
        $cleanup+=,[ordered]@{PID=$identity[0];StartTicksUTC=[string]$identity[1];Name=$identity[2];Owned=$identity[3];ResidualForceKilled=$forced;ExactIdentityAbsent=$absent}
    }
    Write-Proof 'ProcessClosure.json' $cleanup
}
$sourceUnchanged=(Get-FileHash -LiteralPath $source).Hash -ceq $sourceHash
$privateUnchanged=$candidateHash -and (Get-FileHash -LiteralPath $candidate).Hash -ceq $candidateHash
$closed=@($cleanup | Where-Object {$_.Owned -and -not $_.ExactIdentityAbsent}).Count -eq 0
$passed=$macroPassed -and $sourceUnchanged -and $privateUnchanged -and $closed -and -not $failure
Write-Proof 'Acceptance.json' ([ordered]@{Status=$(if($passed){'PASS_DIRECTED_NATIVE_CONTOUR_CELLS'}else{'REVIEW_REQUIRED'});Passed=$passed;
    SourceUnchanged=$sourceUnchanged;SourceSHA256=$sourceHash;PrivateProbeUnchanged=$privateUnchanged;PrivateProbeSHA256=$candidateHash;
    AllOwnedProcessesClosed=$closed;FullRegressionPass=$false;Failure=$failure})
if(-not $passed){throw 'Native contour-cell acceptance requires review; inspect preserved primary evidence.'}
Get-Content -LiteralPath (Join-Path $directory 'Acceptance.json') -Raw
