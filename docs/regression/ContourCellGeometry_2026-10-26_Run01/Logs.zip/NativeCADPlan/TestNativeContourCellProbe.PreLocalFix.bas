Attribute VB_Name = "modTestNativeContourCells"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: адресный настоящий Results — AutoCAD — Contour roundtrip
' ==========================================================================
' Инъекционный модуль только для собственной копии проверенной книги.
' Документ и приложение принадлежат внешнему PS-сценарию. Модуль не ищет
' пользовательский AutoCAD, не закрывает DWG и не запускает полный набор.

Private mPassed As Long, mFailed As Long ' ДЛЯ ТЕСТОВ: счетчики проверок реального COM-обмена.
Private mReport As String ' ДЛЯ ТЕСТОВ: первичные численные значения, геометрия и диагностика.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проводит небольшой direct-only расчет пяти связанных ячеек, включая дуги,
' отверстие, тонкую полосу и две отдельные части исходной несвязной области.
Public Function TestRunNativeContourCells(ByVal document As Object) As String
    mPassed = 0: mFailed = 0: mReport = vbNullString
    Dim world As Object, number As Long, description As String
    On Error GoTo Failed
    If document.ModelSpace.Count <> 0 Then Err.Raise 5, "modTestNativeContourCells", "Требуется пустой собственный DWG."
    TestCheck "native.application", InStr(1, CStr(document.Application.FullName), "\AutoCAD 2023\acad.exe", vbTextCompare) > 0
    Set world = TestWorldUCS(document)
    TestConfigureFixture
    Dim settings As CSystemSettingsReader: Set settings = New CSystemSettingsReader
    settings.LoadFromWorkbook ThisWorkbook
    Dim units As CUnitSystem: Set units = New CUnitSystem
    units.LoadFromSettings settings
    Dim model As CSectionModel: Set model = TestBuildModel()
    Dim provider As CMaterialModelProvider: Set provider = New CMaterialModelProvider
    provider.Initialize settings, units
    Dim batch As CBatchSectionCalculator: Set batch = TestDirectBatch(model, settings, units, provider)
    TestCheck "native.direct.available", batch.ResultAt(1).StrengthResult.DirectState.StateAvailable
    TestCheck "native.direct.converged", batch.ResultAt(1).StrengthResult.DirectState.StateConverged
    TestCheck "native.direct.noInputError", batch.ResultAt(1).Status <> "InputErr"
    mReport = mReport & "NATIVE_STATE_BEFORE: " & batch.ResultAt(1).Status & "; " & batch.ResultAt(1).OverallMeta.ResultComment & vbCrLf
    Dim writer As CNDMResultsWriter: Set writer = New CNDMResultsWriter
    writer.WriteResults ThisWorkbook, model, PrepareSectionSnapshot(model, provider), batch, units
    Dim restored As CSectionModel: Set restored = ReadSectionGeometryFromResults(ThisWorkbook)
    TestCompareModels "native.snapshot", model, restored, True
    Dim physical As Variant, names As Variant, name As Variant, savedTables As Object
    names = Array("rngNDMSectionGeometry", "rngNDMElementGeometry", "rngNDMElementResults", "rngNDMSectionProperties")
    Set savedTables = CreateObject("Scripting.Dictionary")
    For Each name In names
        physical = ReadPhysicalResultTable(ThisWorkbook, CStr(name))
        savedTables.Add CStr(name), physical
    Next name
    Dim solves As Long: solves = SectionEquilibriumSolveCount()
    Dim added As Long: added = Audit03ExportAutoCADDocumentForTests(document)
    TestCheck "native.export.objects", added >= model.ConcreteCount + model.RebarCount
    TestCheck "native.export.noSolve", solves = SectionEquilibriumSolveCount()
    Dim importer As CAutoCADSectionModelImporter: Set importer = New CAutoCADSectionModelImporter
    Dim imported As CSectionModel, entitiesBefore As Long
    entitiesBefore = document.ModelSpace.Count
    Set imported = importer.ImportFromDocument(document, settings, units)
    TestCheck "native.import.sourceEntitiesPreserved", document.ModelSpace.Count = entitiesBefore
    TestCheck "native.import.noSolve", solves = SectionEquilibriumSolveCount()
    TestCompareModels "native.CAD", model, imported, True
    TestCheck "native.CAD.thinIxRetained", imported.ConcreteLocalIx(3) > 0# And imported.ConcreteLocalIx(3) < GEOM_TOLERANCE
    TestCheck "native.CAD.holeRetained", imported.ConcreteGeometry(2).LoopCount = 2
    TestCheck "native.CAD.disconnectedNormalized", imported.ConcreteCount = 5
    TestCheck "native.CAD.noEquivalent", InStr(1, importer.ImportComment, "эквивалент", vbTextCompare) = 0
    mReport = mReport & "NATIVE_IMPORT_DIAGNOSTIC: " & importer.ImportComment & vbCrLf
    TestCADLabels document, model
    Dim afterBatch As CBatchSectionCalculator: Set afterBatch = TestDirectBatch(imported, settings, units, provider)
    TestCheck "native.state.sameStatus", afterBatch.ResultAt(1).Status = batch.ResultAt(1).Status
    TestCheck "native.state.sameDirectStatus", afterBatch.ResultAt(1).StrengthResult.DirectState.Status = batch.ResultAt(1).StrengthResult.DirectState.Status
    TestCheck "native.state.convergedAgain", afterBatch.ResultAt(1).StrengthResult.DirectState.StateConverged
    TestNear "native.state.Nint", afterBatch.ResultAt(1).StrengthResult.DirectState.StateResult.Nint, batch.ResultAt(1).StrengthResult.DirectState.StateResult.Nint, 0.0000001, 0.00000001
    TestNear "native.state.Mxint", afterBatch.ResultAt(1).StrengthResult.DirectState.StateResult.Mxint, batch.ResultAt(1).StrengthResult.DirectState.StateResult.Mxint, 0.0000001, 0.00000001
    TestNear "native.state.Myint", afterBatch.ResultAt(1).StrengthResult.DirectState.StateResult.Myint, batch.ResultAt(1).StrengthResult.DirectState.StateResult.Myint, 0.0000001, 0.00000001
    TestBooleanFailureCleanup document, model.ConcreteGeometry(2)
    TestWorldGuard document, world, settings, units
    For Each name In names
        physical = ReadPhysicalResultTable(ThisWorkbook, CStr(name))
        TestCheck "native.ResultsUnchanged." & CStr(name), TestTablesEqual(savedTables.Item(CStr(name)), physical)
    Next name
    GoTo Finish
Failed:
    number = Err.Number: description = Err.Description
    TestCheck "native.runtime; " & CStr(number) & "; " & Err.Source & "; " & description, False
Finish:
    On Error Resume Next
    If Not world Is Nothing Then document.ActiveUCS = world
    On Error GoTo 0
    TestRunNativeContourCells = mReport & "TOTAL_NATIVE_CONTOUR_CELLS: passed=" & CStr(mPassed) & "; failed=" & CStr(mFailed) & vbCrLf
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет только частную книгу: профиль PR1 решает прямое НДС без поиска предела,
' ширины трещин и устойчивости; экспорт читает этот сохраненный StrengthState.
Private Sub TestConfigureFixture()
    TestSetting "Mesh.CellGeometry", "Contour"
    TestSetting "AutoCAD.Common.ConcreteLayer", "NDM_NATIVE_C"
    TestSetting "AutoCAD.Common.RebarLayer", "NDM_NATIVE_R"
    TestSetting "AutoCAD.Common.SectionContourLayer", "NDM_NATIVE_OUT"
    TestSetting "AutoCAD.Common.OpeningContourLayer", "NDM_NATIVE_HOLE"
    TestSetting "AutoCAD.Import.MinArea", "0"
    TestSetting "AutoCAD.Export.CombinationID", "NATIVE_01"
    TestSetting "AutoCAD.Export.LabelMode", "NamesAndValues"
    TestSetting "AutoCAD.Export.ContourEnabled", "No"
    TestSetting "AutoCAD.Export.NeutralLineEnabled", "No"
    TestSetting "AutoCAD.Export.PrincipalAxesMode", "None"
    TestSetting "AutoCAD.Export.LoadPointEnabled", "No"
    TestSetting "AutoCAD.Export.ExportCrackInteractionContour", "No"
    TestSetting "General.DiagramExtension", "No"
    TestProfile "Calculation.Strength.DirectState", "Yes"
    TestProfile "Calculation.Strength.Capacity", "No"
    TestProfile "Calculation.Crack.Width", "No"
    TestProfile "Calculation.Stability.Enabled", "No"
    TestProfile "Visualization.State", "StrengthState"
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Намеренно портит только ожидаемую площадь тестовой области, не ее границы.
' Реальный Boolean успевает вычесть отверстие, после чего рабочий контроль площади
' обязан отказать и удалить собственные Region/полилинии, сохранив прежний DWG.
Private Sub TestBooleanFailureCleanup(ByVal document As Object, ByVal ring As CConcreteRegion)
    Audit03EnsureAutoCADLayerForTests document, "TEST_CONCRETE", 8
    Dim edges() As TRegionEdge, count As Long, openings() As Boolean, i As Long
    ring.CopyEdges edges, count: ReDim openings(1 To ring.LoopCount)
    For i = 1 To ring.LoopCount: openings(i) = ring.LoopIsOpening(i): Next i
    Dim broken As CConcreteRegion: Set broken = New CConcreteRegion
    broken.SetGeometry edges, count, ring.LoopCount, ring.Area * 1.01, "TestInjectedExpectedArea", 0, openings
    Dim before As Long, ignored As Long, number As Long, description As String
    before = document.ModelSpace.Count
    On Error Resume Next
    ignored = TestExportConcreteElementGeometry(document.ModelSpace, broken)
    number = Err.Number: description = Err.Description: Err.Clear
    On Error GoTo 0
    TestCheck "native.Boolean.failureDetected", number = vbObjectError + 4371 And InStr(description, "Площадь") > 0
    TestCheck "native.Boolean.failureOwnedCleanup", document.ModelSpace.Count = before
    mReport = mReport & "NATIVE_BOOLEAN_INJECTED_FAILURE: " & CStr(number) & "; " & description & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создает связанные ячейки одной универсальной модели. Два последних элемента
' получены нормализацией исходной несвязной области, без сохранения чужого CAD-ID.
Private Function TestBuildModel() As CSectionModel
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim result As CSectionModel: Set result = New CSectionModel
    result.SourceType = "NativeContourCellFixture": result.ConcreteMeshSource = "Generated"
    TestAddExact result, query.ClipWindow(query.CircleRegion(0#, 0#, 80#), 1#, 0#, -80#, 60#, -80#, 80#), "LineAndArc"
    TestAddExact result, query.SubtractContainedRegion(query.CircleRegion(250#, 0#, 65#), query.CircleRegion(250#, 0#, 20#)), "Hole"
    TestAddExact result, query.RectangleRegion(500#, 0#, 10#, 0.0001), "Thin"
    Dim parts As Collection: Set parts = New Collection
    parts.Add query.CircleRegion(700#, 0#, 25#): parts.Add query.CircleRegion(850#, 0#, 25#)
    Dim components As Collection: Set components = query.ConnectedRegions(query.MergeDisjointRegions(parts))
    Dim item As CConcreteRegion
    For Each item In components: TestAddExact result, item, "DisconnectedComponent": Next item
    result.AddRebarElement 0#, -45#, 10#, 0#, "Rebar"
    result.AddRebarElement 0#, 45#, 10#, 0#, "Rebar"
    result.AddRebarElement 250#, -45#, 10#, 0#, "Rebar"
    result.AddRebarElement 250#, 45#, 10#, 0#, "Rebar"
    Set TestBuildModel = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передает точные характеристики и границу одним согласованным контрактом модели.
Private Sub TestAddExact(ByVal model As CSectionModel, ByVal region As CConcreteRegion, ByVal label As String)
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim properties As TGeometryProperties: query.RegionProperties region, properties
    model.AddConcreteElement properties.CentroidX, properties.CentroidY, properties.Area, 1, label, , "Contour", , , , _
        "Нативный контроль фактической границы.", properties.Ixc, properties.Iyc, properties.Ixyc, True
    model.SetConcreteGeometry model.ConcreteCount, region
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает одно малое физически пригодное сочетание с теми же материалами
' и настройками до и после настоящего CAD roundtrip; Results здесь не записывает.
Private Function TestDirectBatch(ByVal model As CSectionModel, ByVal settings As CSystemSettingsReader, _
        ByVal units As CUnitSystem, ByVal provider As CMaterialModelProvider) As CBatchSectionCalculator
    Dim profiles As CCalculationProfileCatalog: Set profiles = New CCalculationProfileCatalog
    profiles.LoadFromWorkbook ThisWorkbook
    Dim result As CBatchSectionCalculator: Set result = New CBatchSectionCalculator
    result.Initialize model, provider: Set result.ProfileCatalog = profiles: result.ApplySettings settings, units
    Dim properties As CSectionPropertiesCalculator: Set properties = New CSectionPropertiesCalculator
    properties.CalculateConcrete model
    result.ApplyLoadReference properties.CentroidX, properties.CentroidY, 0#, 0#
    result.AddCombination "NATIVE_01", -1000#, 0#, 0#, "PR1", "Нативный адресный контроль геометрии.", "Auto"
    result.Execute
    Set TestDirectBatch = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает устойчивые имена контролируемого порядка, все A/c/I и настоящие
' геометрические области; конкретный порядок ребер после AutoCAD не навязывается.
Private Sub TestCompareModels(ByVal label As String, ByVal expected As CSectionModel, ByVal actual As CSectionModel, ByVal compareNames As Boolean)
    TestCheck label & ".concreteCount", expected.ConcreteCount = actual.ConcreteCount
    TestCheck label & ".rebarCount", expected.RebarCount = actual.RebarCount
    If expected.ConcreteCount <> actual.ConcreteCount Then Exit Sub
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim i As Long
    For i = 1 To expected.ConcreteCount
        If compareNames Then TestCheck label & ".ID." & CStr(i), expected.ConcreteID(i) = actual.ConcreteID(i)
        TestCheck label & ".actualBoundary." & CStr(i), actual.ConcreteHasBoundary(i)
        TestNear label & ".A." & CStr(i), actual.ConcreteArea(i), expected.ConcreteArea(i), 0.0000000001, 0.00000001
        TestNear label & ".X." & CStr(i), actual.ConcreteX(i), expected.ConcreteX(i), 0.0000001, 0.0000000001
        TestNear label & ".Y." & CStr(i), actual.ConcreteY(i), expected.ConcreteY(i), 0.0000001, 0.0000000001
        TestNear label & ".Ix." & CStr(i), actual.ConcreteLocalIx(i), expected.ConcreteLocalIx(i), 0.0000000000000001, 0.00000001
        TestNear label & ".Iy." & CStr(i), actual.ConcreteLocalIy(i), expected.ConcreteLocalIy(i), 0.0000000000000001, 0.00000001
        TestNear label & ".Ixy." & CStr(i), actual.ConcreteLocalIxy(i), expected.ConcreteLocalIxy(i), 0.000000001, 0.00000001
        TestCheck label & ".rawBoundary." & CStr(i), query.RegionsCoincide(expected.ConcreteGeometry(i), actual.ConcreteGeometry(i))
        mReport = mReport & "RAW_GEOMETRY " & label & " " & actual.ConcreteID(i) & ": A=" & CStr(actual.ConcreteArea(i)) & _
            "; X=" & CStr(actual.ConcreteX(i)) & "; Y=" & CStr(actual.ConcreteY(i)) & "; Ix=" & CStr(actual.ConcreteLocalIx(i)) & _
            "; Iy=" & CStr(actual.ConcreteLocalIy(i)) & "; Ixy=" & CStr(actual.ConcreteLocalIxy(i)) & _
            "; loops=" & CStr(actual.ConcreteGeometry(i).LoopCount) & "; segments=" & CStr(actual.ConcreteGeometry(i).SegmentCount) & vbCrLf
        TestDumpBoundary label & "." & actual.ConcreteID(i), actual.ConcreteGeometry(i)
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет все настоящие прямые/дуговые сегменты первичным текстом для проверки
' после выхода AutoCAD; топологический parity проверяется отдельно общим ядром.
Private Sub TestDumpBoundary(ByVal label As String, ByVal region As CConcreteRegion)
    Dim i As Long, x1 As Double, y1 As Double, x2 As Double, y2 As Double
    Dim cx As Double, cy As Double, sweep As Double, loopID As Long
    For i = 1 To region.SegmentCount
        region.GetSegment i, x1, y1, x2, y2, cx, cy, sweep, loopID
        mReport = mReport & "RAW_EDGE " & label & "; segment=" & CStr(i) & "; loop=" & CStr(loopID) & _
            "; opening=" & CStr(region.LoopIsOpening(loopID)) & "; x1=" & CStr(x1) & "; y1=" & CStr(y1) & _
            "; x2=" & CStr(x2) & "; y2=" & CStr(y2) & "; cx=" & CStr(cx) & "; cy=" & CStr(cy) & "; sweep=" & CStr(sweep) & vbCrLf
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет имена в реальных AcDbText, не считая их постоянными идентификаторами CAD.
Private Sub TestCADLabels(ByVal document As Object, ByVal model As CSectionModel)
    Dim found As Object: Set found = CreateObject("Scripting.Dictionary")
    Dim entity As Object, i As Long, text As String
    For Each entity In document.ModelSpace
        If entity.ObjectName = "AcDbText" Then
            text = CStr(entity.TextString)
            For i = 1 To model.ConcreteCount
                If InStr(1, text, model.ConcreteID(i), vbBinaryCompare) = 1 Then found(model.ConcreteID(i)) = True
            Next i
        End If
    Next entity
    For i = 1 To model.ConcreteCount: TestCheck "native.labels." & model.ConcreteID(i), found.Exists(model.ConcreteID(i)): Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создает собственную именованную МСК в принадлежащем сценарию документе.
Private Function TestWorldUCS(ByVal document As Object) As Object
    Dim origin(0 To 2) As Double, xAxis(0 To 2) As Double, yAxis(0 To 2) As Double
    xAxis(0) = 1#: yAxis(1) = 1#
    Dim world As Object: Set world = document.UserCoordinateSystems.Add(origin, xAxis, yAxis, "NDM_CELL_WORLD")
    document.ActiveUCS = world
    TestCheck "native.WCS.initialWorld", CLng(document.GetVariable("WORLDUCS")) = 1
    Set TestWorldUCS = world
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет отказ локальной ПСК до любого изменения сущностей и возвращает
' мировую систему только собственного тестового DWG.
Private Sub TestWorldGuard(ByVal document As Object, ByVal world As Object, ByVal settings As CSystemSettingsReader, ByVal units As CUnitSystem)
    Dim origin(0 To 2) As Double, xAxis(0 To 2) As Double, yAxis(0 To 2) As Double
    origin(0) = 123#: origin(1) = -456#: xAxis(0) = 124#: xAxis(1) = -456#: yAxis(0) = 123#: yAxis(1) = -455#
    Dim local As Object: Set local = document.UserCoordinateSystems.Add(origin, xAxis, yAxis, "NDM_CELL_LOCAL")
    document.ActiveUCS = local
    Dim importer As CAutoCADSectionModelImporter: Set importer = New CAutoCADSectionModelImporter
    Dim model As CSectionModel, countBefore As Long, number As Long, description As String
    countBefore = document.ModelSpace.Count
    On Error Resume Next
    Set model = importer.ImportFromDocument(document, settings, units): number = Err.Number: description = Err.Description: Err.Clear
    On Error GoTo 0
    TestCheck "native.WCS.reject", number = vbObjectError + 4407 And model Is Nothing
    TestCheck "native.WCS.action", InStr(description, "_World") > 0
    TestCheck "native.WCS.sourcesKept", document.ModelSpace.Count = countBefore And CStr(document.GetVariable("UCSNAME")) = local.Name
    document.ActiveUCS = world
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Изменяет одну существующую настройку частной книги, не создавая скрытых default.
Private Sub TestSetting(ByVal key As String, ByVal value As String)
    Dim table As Object: Set table = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    Dim i As Long
    For i = 1 To table.Rows.Count
        If CStr(table.Cells(i, 1).Value2) = key Then table.Cells(i, 2).Value2 = value: Exit Sub
    Next i
    Err.Raise 5, "modTestNativeContourCells", "В частной книге отсутствует настройка " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет только колонку PR1 существующего каталога профилей.
Private Sub TestProfile(ByVal key As String, ByVal value As String)
    Dim table As Object: Set table = ThisWorkbook.Names.Item("rngCalculationProfiles").RefersToRange
    Dim i As Long
    For i = 1 To table.Rows.Count
        If CStr(table.Cells(i, 2).Value2) = key Then table.Cells(i, 3).Value2 = value: Exit Sub
    Next i
    Err.Raise 5, "modTestNativeContourCells", "В частной книге отсутствует поле профиля " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает каждый Variant физического снимка без округления чисел.
Private Function TestTablesEqual(ByVal first As Variant, ByVal second As Variant) As Boolean
    If Not IsArray(first) Or Not IsArray(second) Then TestTablesEqual = IsEmpty(first) And IsEmpty(second): Exit Function
    If UBound(first, 1) <> UBound(second, 1) Or UBound(first, 2) <> UBound(second, 2) Then Exit Function
    Dim i As Long, j As Long
    For i = 1 To UBound(first, 1)
        For j = 1 To UBound(first, 2)
            If VarType(first(i, j)) <> VarType(second(i, j)) Then Exit Function
            If IsError(first(i, j)) Or IsError(second(i, j)) Then Exit Function
            If first(i, j) <> second(i, j) Then Exit Function
        Next j
    Next i
    TestTablesEqual = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Добавляет одно условие к первичному отчету настоящего COM-обмена.
Private Sub TestCheck(ByVal label As String, ByVal passed As Boolean)
    If passed Then mPassed = mPassed + 1 Else mFailed = mFailed + 1
    mReport = mReport & IIf(passed, "PASS ", "FAIL ") & label & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает независимо вычисленные свойства без общего размерного порога,
' который мог бы скрыть потерю тонкого положительного собственного момента.
Private Sub TestNear(ByVal label As String, ByVal actual As Double, ByVal expected As Double, ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double)
    TestCheck label & "; actual=" & CStr(actual) & "; expected=" & CStr(expected), _
        Abs(actual - expected) <= absoluteTolerance + relativeTolerance * Abs(expected)
End Sub
