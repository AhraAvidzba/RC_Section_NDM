"""Read all NativeCAD07 evidence; do not create Excel or AutoCAD processes."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import subprocess

HERE = Path(__file__).resolve().parent
PLAN = HERE.parent
WATCH = PLAN / (HERE.name + '.Watchdog')
issues = []


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def require(condition, message):
    if not condition:
        issues.append(message)


evidence = {p.name: read_json(p) for p in sorted(HERE.glob('*.json'))
            if p.name != 'PrimaryReview.json'}
watch = {p.name: read_json(p) for p in sorted(WATCH.glob('*.json'))}
inputs = evidence['Input.json']
acceptance = evidence['Acceptance.json']
run = evidence['NativeRun.json']
ownership = evidence['Ownership.json']
closure = evidence['ProcessClosure.json']
completion = watch['Completion.json']
launch = watch['Launch.json']
primary_path = HERE / run['PrimaryLog']
raw = primary_path.read_bytes()
body = raw.decode('utf-8-sig')
lines = body.splitlines()
passes = re.findall(r'^PASS ([^;\r\n]+)', body, re.M)
failures = re.findall(r'^(?:FAIL\b|RUNTIME ERROR\b|WATCHDOG_FAILURE\b).*', body, re.M)
totals = re.findall(r'^TOTAL_NATIVE_CONTOUR_CELLS: passed=(\d+); failed=(\d+)', body, re.M)
require(len(passes) == 127 and not failures and totals == [('127', '0')], 'Primary counts/failures')
require(run['AssertionsPassed'] == 127 and run['AssertionsFailed'] == 0 and run['MacroPassed'], 'NativeRun counts')
require(digest(primary_path) == run['PrimarySHA256'], 'Primary SHA does not match NativeRun')

required = ['native.application', 'native.WCS.initialWorld', 'native.direct.available',
            'native.direct.converged', 'native.direct.noInputError', 'native.snapshot.concreteCount',
            'native.snapshot.rebarCount', 'native.export.objects', 'native.export.noSolve',
            'native.import.sourceEntitiesPreserved', 'native.import.noSolve',
            'native.CAD.concreteCount', 'native.CAD.rebarCount', 'native.CAD.thinIxRetained',
            'native.CAD.holeRetained', 'native.CAD.disconnectedNormalized', 'native.CAD.noEquivalent',
            'native.state.sameStatus', 'native.state.sameDirectStatus', 'native.state.convergedAgain',
            'native.state.Nint', 'native.state.Mxint', 'native.state.Myint',
            'native.Boolean.failureDetected', 'native.Boolean.failureOwnedCleanup',
            'native.WCS.reject', 'native.WCS.action', 'native.WCS.sourcesKept']
for scope in ['native.snapshot', 'native.CAD']:
    for index in range(1, 6):
        required.extend(f'{scope}.{field}.{index}' for field in ['ID', 'actualBoundary', 'A', 'X', 'Y', 'Ix', 'Iy', 'Ixy', 'rawBoundary'])
required.extend(f'native.labels.C{i}' for i in range(1, 6))
required.extend(f'native.ResultsUnchanged.{name}' for name in ['rngNDMSectionGeometry', 'rngNDMElementGeometry', 'rngNDMElementResults', 'rngNDMSectionProperties'])
missing = sorted(set(required) - set(passes))
require(not missing, 'Required assertions missing: ' + ', '.join(missing))
require(len(passes) == len(set(passes)), 'Duplicate PASS assertion IDs')

props = {}
edges = {}
for line in lines:
    match = re.match(r'^RAW_GEOMETRY (native\.snapshot|native\.CAD) (C\d+): (.+)$', line)
    if match:
        props[(match[1], match[2])] = {key: float(value) for key, value in (v.split('=', 1) for v in match[3].split('; '))}
    match = re.match(r'^RAW_EDGE (native\.snapshot|native\.CAD)\.(C\d+); (.+)$', line)
    if match:
        entry = {}
        for part in match[3].split('; '):
            key, value = part.split('=', 1)
            entry[key] = value == 'True' if key == 'opening' else float(value)
        edges.setdefault((match[1], match[2]), []).append(entry)
require(len(props) == 10 and sum(map(len, edges.values())) == 50, 'Raw geometry completeness')
models = []
for index in range(1, 6):
    element = f'C{index}'
    saved = props[('native.snapshot', element)]
    imported = props[('native.CAD', element)]
    raw_saved = edges[('native.snapshot', element)]
    raw_imported = edges[('native.CAD', element)]
    outer_loops = {e['loop'] for e in raw_imported if not e['opening']}
    holes = {e['loop'] for e in raw_imported if e['opening']}
    require(len(raw_imported) == int(imported['segments']), element + ' imported edge count')
    require(int(imported['loops']) == len(outer_loops | holes), element + ' imported loop count')
    tolerance = max(1e-15, 64 * 2**-52 * max(abs(saved['Ix']), abs(saved['Iy']))) + 1e-8 * abs(saved['Ixy'])
    require(abs(imported['Ixy'] - saved['Ixy']) <= tolerance, element + ' Ixy tolerance')
    models.append(dict(ElementID=element, SnapshotProperties=saved, CADProperties=imported,
                       Difference={k: imported[k] - saved[k] for k in ['A', 'X', 'Y', 'Ix', 'Iy', 'Ixy']},
                       ActualIxyTolerance=tolerance, TrueRegionParityPassed=f'native.CAD.rawBoundary.{index}' in passes,
                       SnapshotEdges=raw_saved, CADEdges=raw_imported,
                       Topology=dict(LoopCount=int(imported['loops']), Segments=len(raw_imported),
                                     LineCount=sum(e['sweep'] == 0 for e in raw_imported),
                                     ArcCount=sum(e['sweep'] != 0 for e in raw_imported),
                                     OuterLoopCount=len(outer_loops), OpeningLoopCount=len(holes))))
require(models[1]['Topology']['OpeningLoopCount'] == 1, 'C2 hole lost')
require(models[2]['CADProperties']['Ix'] > 0 and math.isclose(models[2]['CADProperties']['Ix'], 8.33333333333333e-13, rel_tol=1e-14), 'C3 thin Ix lost')
require(models[3]['CADProperties']['X'] == 700 and models[4]['CADProperties']['X'] == 850, 'Disconnected elements not separate')

source = Path(inputs['Source'])
helper = Path(inputs['Helper'])
probe = Path(inputs['PrivateWorkbook'])
runner = Path(launch['Runner'])
source_hash = digest(source)
helper_hash = digest(helper)
probe_hash = digest(probe)
require(source_hash == inputs['SourceSHA256'] == acceptance['SourceSHA256'] == completion['SourceSHA256'] == ownership['SourceSHA256'], 'Source SHA mismatch')
require(helper_hash == inputs['HelperSHA256'], 'Helper SHA mismatch')
require(probe_hash == acceptance['PrivateProbeSHA256'] == ownership['WorkbookSHA256'], 'Private probe SHA mismatch')
require(digest(runner) == launch['RunnerSHA256'] == watch['WorkerIdentity.json']['RunnerSHA256'], 'Runner SHA mismatch')
require(acceptance['Passed'] and acceptance['SourceUnchanged'] and acceptance['PrivateProbeUnchanged'] and acceptance['AllOwnedProcessesClosed'] and acceptance['Failure'] is None, 'Acceptance not clean')
require(not completion['TimedOut'] and completion['WorkerExitCode'] == 0 and not completion['OrphansAfterWorkerExit'], 'Watchdog not clean')
stdout = (WATCH / 'Worker.stdout.log').read_bytes()
stderr = (WATCH / 'Worker.stderr.log').read_bytes()
require(not stderr and json.loads(stdout.decode('utf-8-sig')) == acceptance, 'Worker stdout/stderr mismatch')
require(all(p['ExactIdentityAbsent'] and p['Owned'] and not p['ResidualForceKilled'] for p in closure), 'Closure evidence not clean')
require(ownership['UserDocumentsUsed'] is False, 'User documents used')
for key in ['Memory_BeforeExcel.json', 'Memory_BeforeAutoCAD.json']:
    m = evidence[key]
    require(m['Ready'] and m['FreeRAMGiB'] >= m['RequiredRAMGiB'] and m['FreeCommitGiB'] >= m['RequiredCommitGiB'], 'Memory gate not ready: ' + key)

# A new shell reads only process identities; it never starts Excel/AutoCAD.
identities = [(p['PID'], p['StartTicksUTC']) for p in closure]
identities.append((watch['WorkerIdentity.json']['PID'], watch['WorkerIdentity.json']['StartTicksUTC']))
ps_rows = ','.join('@{PID=%d;Ticks=\'%s\'}' % row for row in identities)
command = "$rows = foreach ($identity in @(" + ps_rows + ")) { $p = Get-Process -Id $identity.PID -ErrorAction SilentlyContinue; $ticks = if ($null -ne $p) {$p.StartTime.ToUniversalTime().Ticks.ToString()} else {$null}; [pscustomobject]@{PID=$identity.PID;ExpectedStartTicksUTC=$identity.Ticks;ObservedStartTicksUTC=$ticks;ExactIdentityLive=($ticks -eq $identity.Ticks)} }; $rows | ConvertTo-Json -Depth 3"
fresh = json.loads(subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', '-NoProfile', '-Command', command], capture_output=True, text=True, check=True).stdout)
require(all(not p['ExactIdentityLive'] for p in fresh), 'Own exact process identity still live')
boolean_line = next((line for line in lines if line.startswith('NATIVE_BOOLEAN_INJECTED_FAILURE: ')), '')
require(boolean_line.startswith('NATIVE_BOOLEAN_INJECTED_FAILURE: -2147217133;'), 'Original geometry error masked')
diagnostic = next((line for line in lines if line.startswith('NATIVE_IMPORT_DIAGNOSTIC: ')), '')
require('NDM_NATIVE_OUT' in diagnostic and 'NDM_NATIVE_HOLE' in diagnostic and 'отсутствует' in diagnostic, 'Expected optional-layer diagnostic absent')
previous_primary = PLAN / 'NativeCAD06' / 'NativeContourCells.txt'
require(raw == previous_primary.read_bytes(), 'Primary changed from fully reviewed NativeCAD06')

review = dict(Status='PASS_DIRECTED_NATIVE_CAD07_PRIMARY_REVIEW' if not issues else 'REVIEW_REQUIRED',
              ReviewedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              PrimaryReadEntirely=True, PrimaryBytesRead=len(raw), PrimaryLinesRead=len(lines),
              PrimarySHA256=digest(primary_path), AssertionsPassed=len(passes), AssertionsFailed=len(failures),
              Failures=failures, RequiredCheckGroupsMissing=missing, TerminalCountsMatch=totals == [('127', '0')],
              SourceWorkbook=str(source), SourceWorkbookSHA256=source_hash, SourceWorkbookHashRechecked=True,
              SourceHelperSHA256=helper_hash, SourceHelperHashRechecked=True,
              PrivateProbeSHA256=probe_hash, PrivateProbeHashRechecked=True,
              SourceJSONFilesRead=sorted(evidence), WatchdogJSONFilesRead=sorted(watch),
              SourceJSONChecksConsistent=True, MacroInvocationSeconds=run['Seconds'],
              WorkerElapsedSeconds=completion['ElapsedSeconds'], Models=models,
              ThinC3IxPreserved=True, OpeningInC2=True, DisconnectedC4C5Preserved=True,
              BooleanFailureRegression=dict(ExpectedGeometryErrorCode=-2147217133, PrimaryLine=boolean_line,
                                             OwnedEntityCountRestored=True, ResumeFailureCleanupConfirmedOnRealAutoCAD=True),
              WCS=dict(InitialWorldPassed=True, LocalUCSRejected=True, ActionPresent=True, SourceEntitiesPreserved=True),
              StateChecks=[v for v in passes if v.startswith('native.state.')],
              ExpectedOptionalContourDiagnostic=diagnostic,
              ResultsPreservationChecks=[v for v in passes if v.startswith('native.ResultsUnchanged.')],
              ProcessClosure=closure, FreshProcessObservation=fresh, WatchdogCompletion=completion,
              SourceUserAppsNotOwned=dict(ExistingExcel=inputs['ExistingExcel'], ExistingCAD=inputs['ExistingCAD']),
              AllMemoryGatesReady=True,
              MinimumObservedFreeRAMGiB=min(evidence[k]['FreeRAMGiB'] for k in ['Memory_BeforeExcel.json', 'Memory_BeforeAutoCAD.json']),
              MinimumObservedFreeCommitGiB=min(evidence[k]['FreeCommitGiB'] for k in ['Memory_BeforeExcel.json', 'Memory_BeforeAutoCAD.json']),
              WorkerStdoutAcceptanceMatches=True, WorkerStderrBytes=len(stderr),
              PrimaryByteEqualNativeCAD06=True, ReadOnlyReview=True, ExcelOrCADStartedByReview=False,
              Issues=issues, FullRegressionPass=False,
              ScopeLimitation='Real AutoCAD controlled line/arc/hole/thin/disconnected cells, failure cleanup and WCS; directed verification only. No full ON/OFF + Focused claim.')
(HERE / 'PrimaryReview.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(Status=review['Status'], AssertionsPassed=len(passes), AssertionsFailed=len(failures), PrimaryBytesRead=len(raw), SourceSHA256=source_hash, Issues=issues), ensure_ascii=False))
raise SystemExit(0 if not issues else 1)
