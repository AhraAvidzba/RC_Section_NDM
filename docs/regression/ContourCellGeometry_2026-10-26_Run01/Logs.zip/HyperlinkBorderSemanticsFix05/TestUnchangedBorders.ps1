﻿$ErrorActionPreference='Stop'
$repo=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$candidate=Join-Path $PSScriptRoot 'SettingsCatalog.Candidate.ps1'
$tokens=$null;$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($candidate,[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw ($parseErrors.Message -join '; ')}
$functions=@('Get-InstructionFormatProperties','Set-InstructionFormatProperties','Save-InstructionCellFormat','Restore-InstructionCellFormat','Add-InstructionHyperlink','Add-HeaderInstructionHyperlink','Set-InstructionHyperlinkFont')
foreach($definition in $ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst]},$true)){
    if($definition.Name -in $functions){. ([scriptblock]::Create($definition.Extent.Text))}
}
$script:checks=0
$script:borderWrites=0
function Test-Assert([bool]$Condition,[string]$Name){if(-not $Condition){throw $Name};$script:checks++}
function New-TestFont([double]$Size=9){[pscustomobject]@{Name='Arial';Size=$Size;Bold=$false;Italic=$false;Strikethrough=$false;Superscript=$false;Subscript=$false;OutlineFont=$false;Shadow=$false;ThemeFont=0;ColorIndex=1;Color=0;ThemeColor=0;TintAndShade=0;Underline=-4142}}
function Reset-TestCell($Cell){
    $Cell.TestStyle='Hyperlink';$Cell.Font=New-TestFont 11;$Cell.Font.Name='Calibri'
    $Cell.Interior.Color=16777215;$Cell.Interior.Pattern=-4142
    # Native04 showed that Hyperlink does not change actual font/fill/border appearance.
    # This mock leaves borders intact, unlike the earlier aggressive fault-injection mock.
    $Cell.HorizontalAlignment=-4105;$Cell.NumberFormat='General';$Cell.Locked=$true
    $Cell.CaptionFont=New-TestFont 11;$Cell.LinkFont=New-TestFont 11
}
function New-TestCell([int]$Column,[string]$Text){
    $borders=@{};foreach($i in @(5,6,7,8,9,10,11,12)){$borders[$i]=[pscustomobject]@{ColorIndex=1;Color=0;ThemeColor=0;TintAndShade=0;Weight=2;LineStyle=-4115}}
    foreach($border in $borders.Values){
        $lineStyle=$border.LineStyle;$border.PSObject.Properties.Remove('LineStyle')
        $border|Add-Member NoteProperty TestLineStyle $lineStyle
        $border|Add-Member ScriptProperty LineStyle {return $this.TestLineStyle} {param($value) $script:borderWrites++;$this.TestLineStyle=$value}
    }
    $borderCollection=[pscustomobject]@{All=$borders;Values=@($borders.Values)}
    $borderCollection|Add-Member ScriptMethod Item {param($Index) return $this.All[[int]$Index]}
    $cell=[pscustomobject]@{Row=2;Column=$Column;TestStyle='Normal';Value2=$Text;Font=(New-TestFont);CaptionFont=(New-TestFont 12);LinkFont=(New-TestFont 8);Interior=[pscustomobject]@{ColorIndex=15;Color=15921906;ThemeColor=0;TintAndShade=0;PatternColorIndex=-4105;PatternColor=0;PatternThemeColor=0;PatternTintAndShade=0;Pattern=1};Borders=$borderCollection;NumberFormat='0.000';HorizontalAlignment=-4131;VerticalAlignment=-4108;WrapText=$false;ShrinkToFit=$false;Orientation=0;AddIndent=$false;IndentLevel=0;ReadingOrder=-5002;Locked=$false;FormulaHidden=$true;MergeArea=$null;Parent=$null;Hyperlinks=$null}
    $cell|Add-Member ScriptProperty Style {return $this.TestStyle}
    $cell|Add-Member ScriptMethod Characters {param($Start,$Length) if($Start -le 7){return [pscustomobject]@{Font=$this.CaptionFont}}else{return [pscustomobject]@{Font=$this.LinkFont}}}
    $links=[pscustomobject]@{Anchor=$cell};$links|Add-Member ScriptMethod Delete {foreach($part in $this.Anchor.MergeArea.Cells){Reset-TestCell $part}}
    $cell.Hyperlinks=$links
    return $cell
}
function New-TestArea($Cells){
    $area=[pscustomobject]@{Cells=@($Cells)}
    $area|Add-Member ScriptProperty Locked {return $this.Cells[0].Locked} {param($value) foreach($part in $this.Cells){$part.Locked=$value}}
    $area|Add-Member ScriptProperty FormulaHidden {return $this.Cells[0].FormulaHidden} {param($value) foreach($part in $this.Cells){$part.FormulaHidden=$value}}
    return $area
}
$header=New-TestCell 8 'Caption (Подробнее)';$right=New-TestCell 9 ''
$header.Font.Size=[DBNull]::Value;$header.Font.Color=[DBNull]::Value
$header.CaptionFont.Bold=$true;$header.LinkFont.Color=16711680;$header.LinkFont.Underline=2
$area=New-TestArea @($header,$right);$header.MergeArea=$area;$right.MergeArea=$area
$cells=[pscustomobject]@{All=@{8=$header;9=$right}};$cells|Add-Member ScriptMethod Item {param($Row,$Column) return $this.All[[int]$Column]}
$links=[pscustomobject]@{};$links|Add-Member ScriptMethod Add {param($Anchor,$Address,$SubAddress,$ScreenTip,$DisplayText) foreach($part in $Anchor.MergeArea.Cells){Reset-TestCell $part};$Anchor.Value2=$DisplayText}
$sheet=[pscustomobject]@{Cells=$cells;Hyperlinks=$links};$header.Parent=$sheet;$right.Parent=$sheet
Add-HeaderInstructionHyperlink $header 'Caption' 'Справка' 5
Test-Assert ($header.Font.Name -eq 'Arial') 'basefont'
Test-Assert ($header.CaptionFont.Size -eq 12) 'caption size'
Test-Assert ($header.CaptionFont.Bold) 'caption bold'
Test-Assert ($header.LinkFont.Size -eq 8) 'small link size'
Test-Assert ($header.LinkFont.Color -eq 16711680 -and $header.LinkFont.Underline -eq 2) 'intentional link color'
foreach($part in @($header,$right)){
    Test-Assert ($part.Interior.Color -eq 15921906 -and $part.Interior.Pattern -eq 1) 'merged fill'
    Test-Assert ($part.NumberFormat -eq '0.000' -and -not $part.Locked -and $part.FormulaHidden) 'format protection'
    Test-Assert ($part.Borders.Item(10).LineStyle -eq -4115 -and $part.Borders.Item(10).Weight -eq 2) 'right border'
    Test-Assert ($part.HorizontalAlignment -eq -4131) 'alignment'
}
$header.Value2='Подробнее';$header.Font=New-TestFont;$header.MergeArea=New-TestArea @($header)
Add-InstructionHyperlink $header 'Справка' 6
Test-Assert ($header.Font.Name -eq 'Arial' -and $header.Font.Size -eq 9 -and $header.Font.Color -eq 16711680 -and $header.Font.Underline -eq 2) 'plain link font'
Test-Assert ($header.Interior.Color -eq 15921906 -and $header.NumberFormat -eq '0.000' -and -not $header.Locked) 'plain link format'
Test-Assert ($header.Style -eq 'Hyperlink' -and $right.Style -eq 'Hyperlink') 'Style is read-only diagnostic; actual attributes restored'
Test-Assert ($script:borderWrites -eq 0) 'Unchanged shared borders must receive no writes'
[pscustomobject]@{Status='PASS_MOCK_UNCHANGED_BORDERS_NO_SETTERS_ONLY';PowerShellVersion=$PSVersionTable.PSVersion.ToString();Checks=$script:checks;ExcelStarted=$false;NativeVerification=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'UnchangedBordersResult.json') -Encoding UTF8
