# ДЛЯ ТЕСТОВ: незначимые default-атрибуты рамки не вызывают COM setter-ы.
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'TestUnchangedBorders.ps1')
$script:paletteWrites=0;$script:weightWrites=0
foreach($border in $header.Borders.Values){
    $index=$border.ColorIndex;$border.PSObject.Properties.Remove('ColorIndex')
    $border|Add-Member NoteProperty TestColorIndex $index
    $border|Add-Member ScriptProperty ColorIndex {return $this.TestColorIndex} {param($value) $script:paletteWrites++;$this.TestColorIndex=$value}
}
$snapshot=@(Save-InstructionCellFormat $header)
foreach($border in $header.Borders.Values){$border.TestColorIndex=2}
Restore-InstructionCellFormat $header $snapshot
if($script:paletteWrites -ne 0){throw 'An unchanged RGB line must not be rewritten through a different palette-index getter.'}
foreach($border in $header.Borders.Values){
    $border.TestLineStyle=-4142
    $weight=$border.Weight;$border.PSObject.Properties.Remove('Weight')
    $border|Add-Member NoteProperty TestWeight $weight
    $border|Add-Member ScriptProperty Weight {return $this.TestWeight} {param($value) $script:weightWrites++;$this.TestWeight=$value;$this.TestLineStyle=1}
}
$snapshot=@(Save-InstructionCellFormat $header)
foreach($border in $header.Borders.Values){$border.TestWeight=1}
Restore-InstructionCellFormat $header $snapshot
if($script:weightWrites -ne 0 -or @($header.Borders.Values|Where-Object {$_.LineStyle -ne -4142}).Count){throw 'Weight of an invisible line must not be restored: its setter can activate the shared line.'}
[ordered]@{Status='PASS_MOCK_BORDER_INTERLOCK_AND_PALETTE_ONLY';PowerShellVersion=$PSVersionTable.PSVersion.ToString();Checks=2;PaletteWrites=$script:paletteWrites;HiddenWeightWrites=$script:weightWrites;ExcelStarted=$false;NativeVerification=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'BorderEdgeCasesResult.json') -Encoding UTF8
