﻿# ДЛЯ ТЕСТОВ: только синтаксический разбор PS5.1, без Excel/AutoCAD.
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne 5){throw 'Run this static preflight with Windows PowerShell5.1.'}
$results=@()
foreach($name in @('Test-RunContourDecimalSnapshots.ps1','Test-WatchContourDecimalSnapshots.ps1')){
    $path=Join-Path $PSScriptRoot $name
    $tokens=$null;$errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
    $results+=,[ordered]@{Name=$name;SHA256=(Get-FileHash -LiteralPath $path).Hash;ParserVersion=$PSVersionTable.PSVersion.ToString();Errors=@($errors|ForEach-Object Message)}
}
$results|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'PS51Parse.json') -Encoding UTF8
$results|ConvertTo-Json -Compress
if(@($results|Where-Object {$_.Errors.Count -gt 0}).Count -gt 0){throw 'Parse errors found.'}
