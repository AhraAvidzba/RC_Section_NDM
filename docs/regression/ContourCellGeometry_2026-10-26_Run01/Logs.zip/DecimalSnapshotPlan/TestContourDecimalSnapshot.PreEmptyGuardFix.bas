Attribute VB_Name = "modTestContourDecimalSnapshot"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: точный новый 18-колоночный снимок при двух разделителях Excel
' ==========================================================================
' Не меняет регион Windows. Внешний runner меняет только собственный Excel.
' Два небольших элемента с прямыми, дугами и отверстием; один direct-only LC.
Private Type TTestDoubleValue
    Value As Double ' ДЛЯ ТЕСТОВ: численное значение для побитной проверки.
End Type
Private Type TTestDoubleWords
    Low As Long ' ДЛЯ ТЕСТОВ: младшее слово IEEE754.
    High As Long ' ДЛЯ ТЕСТОВ: старшее слово IEEE754.
End Type
Private mPassed As Long, mFailed As Long ' ДЛЯ ТЕСТОВ: счётчики текущего короткого сценария.
Private mReport As String ' ДЛЯ ТЕСТОВ: первичный отчёт без замены результатов PASS.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет реальный File05 и восстанавливает его на лист без повторного solver.
Public Function TestRunContourDecimalSnapshot(ByVal decimalMark As String) As String
    mPassed = 0: mFailed = 0: mReport = vbNullString
    On Error GoTo Failed
    TestCheck "application.customSeparators", Not ThisWorkbook.Application.UseSystemSeparators
    TestCheck "application.decimal", ThisWorkbook.Application.DecimalSeparator = decimalMark
    TestCheck "application.thousandsDifferent", ThisWorkbook.Application.ThousandsSeparator <> decimalMark
    TestParsers
    TestConfigure decimalMark
    Dim settings As CSystemSettingsReader: Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    TestNear "settings.GetDouble.dot", settings.GetDouble("Mesh.StepX"), 25.5
    TestNear "settings.GetRequiredDouble.comma", settings.GetRequiredDouble("Mesh.StepY"), 50.25
    Dim units As CUnitSystem: Set units = New CUnitSystem: units.LoadFromSettings settings
    Dim model As CSectionModel: Set model = TestBuildModel()
    Dim writer As CNDMResultsWriter: Set writer = New CNDMResultsWriter
    writer.WriteGeometryPreview ThisWorkbook, model, PrepareSectionSnapshot(model), units, False
    TestCompareModel "preview", model, ReadSectionGeometryFromResults(ThisWorkbook)
    Dim info As Boolean, attention As Boolean, message As String
    message = RunSectionCalculationForWorkbook(ThisWorkbook, False, , info, attention)
    TestCheck "calculate.noWarning", Not attention
    mReport = mReport & "CALCULATION " & message & vbCrLf
    TestCompareModel "fileView", model, ReadSectionGeometryFromResults(ThisWorkbook)
    TestNumericTables
    Dim before As String: before = TestCanonicalContourGeometry()
    Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
    Dim snapshot As CCalculationSnapshot: Set snapshot = store.LoadFile(ThisWorkbook)
    Dim boundaryData As Variant: boundaryData = snapshot.Table("rngNDMElementGeometry")
    TestCheck "file.has18Columns", UBound(boundaryData, 2) = 18
    TestCheck "file.hasElementGeometry", snapshot.HasTable("rngNDMElementGeometry")
    TestSetting "Results.SnapshotStorage", "Excel"
    Dim solves As Long: solves = SectionEquilibriumSolveCount()
    TestClearPhysicalGeometry
    UpdateSectionResultsForWorkbook ThisWorkbook, snapshot
    TestCheck "sheetRestore.noSolve", SectionEquilibriumSolveCount() = solves
    TestCompareModel "sheetRestore", model, ReadSectionGeometryFromResults(ThisWorkbook)
    TestCheck "sheetRestore.bits", before = TestCanonicalContourGeometry()
    TestNumericTables
    TestSetting "Results.SnapshotStorage", "File"
    TestClearPhysicalGeometry
    UpdateSectionResultsForWorkbook ThisWorkbook, snapshot
    TestCheck "fileRestore.noSolve", SectionEquilibriumSolveCount() = solves
    TestCheck "fileRestore.bits", before = TestCanonicalContourGeometry()
    mReport = mReport & "FILE_PATH " & store.SnapshotPath(ThisWorkbook) & vbCrLf
    GoTo Finish
Failed:
    TestCheck "runtime " & CStr(Err.Number) & "; " & Err.Source & "; " & Err.Description, False
Finish:
    TestRunContourDecimalSnapshot = mReport & "TOTAL_CONTOUR_DECIMAL: passed=" & CStr(mPassed) & "; failed=" & CStr(mFailed) & vbCrLf
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' После реального открытия читает File05 и обновляет вид без расчёта.
Public Function TestContourDecimalReopen() As String
    Dim solves As Long: solves = SectionEquilibriumSolveCount()
    TestClearPhysicalGeometry
    UpdateSectionResultsForWorkbook ThisWorkbook
    If solves <> SectionEquilibriumSolveCount() Then Err.Raise 5, , "Reopen вызвал solver."
    TestCompareModel "reopen", TestBuildModel(), ReadSectionGeometryFromResults(ThisWorkbook)
    If mFailed <> 0 Then Err.Raise 5, , mReport
    TestContourDecimalReopen = TestSnapshotReopenFingerprint()
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удаляет только физические таблицы собственной книги перед restore, чтобы
' прежний вывод не мог скрыть ошибочное отсутствие восстановления из снимка.
Private Sub TestClearPhysicalGeometry()
    Dim key As Variant, values As Variant, target As Object
    For Each key In Array("rngNDMSectionGeometry", "rngNDMElementGeometry")
        values = ReadPhysicalResultTable(ThisWorkbook, CStr(key))
        Set target = ThisWorkbook.Names.Item(CStr(key)).RefersToRange
        target.Resize(UBound(values, 1), UBound(values, 2)).ClearContents
        TestCheck "restore.privateTableCleared." & CStr(key), IsEmpty(target.Cells(1, 1).Value2)
    Next key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Канонический физический снимок геометрии без RunID: одинаковые Double имеют
' одинаковые биты при точке/запятой, строка не использует CStr чисел.
Public Function TestCanonicalContourGeometry() As String
    Dim key As Variant, values As Variant, row As Long, column As Long, item As Variant, result As String
    For Each key In Array("rngNDMSectionGeometry", "rngNDMElementGeometry")
        values = ReadPhysicalResultTable(ThisWorkbook, CStr(key))
        result = result & CStr(key) & vbLf
        For row = 1 To UBound(values, 1)
            For column = 2 To UBound(values, 2)
                item = values(row, column)
                If VarType(item) = vbString Or IsEmpty(item) Then
                    result = result & "S" & CStr(item) & Chr$(30)
                Else
                    result = result & "D" & TestDoubleBits(CDbl(item)) & Chr$(30)
                End If
            Next column
            result = result & vbLf
        Next row
    Next key
    TestCanonicalContourGeometry = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контракт обоих десятичных знаков общий; одиночная запятая означает дробь,
' смешанная/многократная группировка разрядов никогда не означает тысячу.
Private Sub TestParsers()
    Dim value As Variant, parsed As Double
    For Each value In Array("1.25", "1,25", "+1.25E0", "+1,25E0")
        TestCheck "strict.accept." & CStr(value), TryReadStrictDouble(value, parsed)
        TestNear "strict.value." & CStr(value), parsed, 1.25
    Next value
    TestCheck "strict.numericVariant", TryReadStrictDouble(1.25, parsed)
    TestNear "strict.numericVariant.value", parsed, 1.25
    TestCheck "strict.singleCommaDecimal", TryReadStrictDouble("1,234", parsed)
    TestNear "strict.noAccidentalThousands", parsed, 1.234
    For Each value In Array("1,234.5", "1.234,5", "1 234,5", "1'234.5", "1.234.567", "1,234,567", "12.5mm")
        TestCheck "strict.rejectGrouping." & CStr(value), Not TryReadStrictDouble(value, parsed)
    Next value
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задаёт только частный direct-only профиль и корректные физические единицы.
Private Sub TestConfigure(ByVal decimalMark As String)
    TestSetting "Mesh.CellGeometry", "Contour": TestSetting "Mesh.StepX", "25.5": TestSetting "Mesh.StepY", "50,25"
    TestSetting "Plot.Enabled", "No": TestSetting "General.ExecutionReportEnabled", "No"
    TestSetting "General.ReformatResultsEnabled", "No"
    TestSetting "Load.ReferenceOffsetX", 0#: TestSetting "Load.ReferenceOffsetY", 0#
    TestSetting "Results.SnapshotStorage", "File"
    TestSetting "Results.SnapshotName", IIf(decimalMark = ".", "ContourDecimalDot", "ContourDecimalComma")
    TestSetting "Plot.LoadCase", "PERF_01": TestSetting "AutoCAD.Export.CombinationID", "PERF_01"
    TestConfigurePerformanceFixture "DIRECT", 1, "Newton", "Saved", "Normal", "No"
    Dim table As Object, data As Variant, row As Long
    Set table = ThisWorkbook.Names.Item("rngCalculationProfiles").RefersToRange: data = table.Value2
    For row = 1 To UBound(data, 1)
        If CStr(data(row, 2)) = "Visualization.State" Then data(row, 3) = "StrengthState"
    Next row
    table.Value2 = data
    Dim settings As CSystemSettingsReader: Set settings = New CSystemSettingsReader: settings.LoadFromWorkbook ThisWorkbook
    Dim units As CUnitSystem: Set units = New CUnitSystem: units.LoadFromSettings settings
    Set table = ThisWorkbook.Names.Item("rngLoadCombinations").RefersToRange
    table.Cells(2, 2).Value2 = -1000# / units.InputForceToInternal(1#)
    table.Cells(2, 3).Value2 = 0#: table.Cells(2, 4).Value2 = 0#
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Два аналитических связанных элемента: обрезанный круг и кольцо.
' Дробные центры/радиусы и прямой срез исключают только целочисленный путь.
Private Function TestBuildModel() As CSectionModel
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim result As CSectionModel: Set result = New CSectionModel
    result.SourceType = "DecimalContourFixture": result.ConcreteMeshSource = "Generated"
    TestAddExact result, query.ClipWindow(query.CircleRegion(0.125, -0.375, 20.5), 1#, 0#, -20.375, 15.125, -20.875, 20.125)
    TestAddExact result, query.SubtractContainedRegion(query.CircleRegion(75.125, -0.375, 17.25), query.CircleRegion(75.125, -0.375, 6.125))
    result.AddRebarElement -5#, -5#, 8#, 0#, "Rebar"
    result.AddRebarElement 5#, 5#, 8#, 0#, "Rebar"
    Set TestBuildModel = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт фактические A/c/I и явную границу по единому контракту модели.
Private Sub TestAddExact(ByVal model As CSectionModel, ByVal region As CConcreteRegion)
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim properties As TGeometryProperties: query.RegionProperties region, properties
    model.AddConcreteElement properties.CentroidX, properties.CentroidY, properties.Area, 1, "DecimalFixture", , "Contour", , , , _
        "Decimal line-arc-hole", properties.Ixc, properties.Iyc, properties.Ixyc, True
    model.SetConcreteGeometry model.ConcreteCount, region
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет точную геометрию и все собственные свойства после чтения таблиц.
Private Sub TestCompareModel(ByVal label As String, ByVal expected As CSectionModel, ByVal actual As CSectionModel)
    TestCheck label & ".count", expected.ConcreteCount = actual.ConcreteCount
    If expected.ConcreteCount <> actual.ConcreteCount Then Exit Sub
    Dim query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery
    Dim i As Long
    For i = 1 To expected.ConcreteCount
        TestCheck label & ".boundary." & CStr(i), actual.ConcreteHasBoundary(i)
        TestCheck label & ".region." & CStr(i), query.RegionsCoincide(expected.ConcreteGeometry(i), actual.ConcreteGeometry(i))
        TestNear label & ".A." & CStr(i), actual.ConcreteArea(i), expected.ConcreteArea(i)
        TestNear label & ".X." & CStr(i), actual.ConcreteX(i), expected.ConcreteX(i)
        TestNear label & ".Y." & CStr(i), actual.ConcreteY(i), expected.ConcreteY(i)
        TestNear label & ".Ix." & CStr(i), actual.ConcreteLocalIx(i), expected.ConcreteLocalIx(i)
        TestNear label & ".Iy." & CStr(i), actual.ConcreteLocalIy(i), expected.ConcreteLocalIy(i)
        TestNear label & ".Ixy." & CStr(i), actual.ConcreteLocalIxy(i), expected.ConcreteLocalIxy(i)
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет все численные Variant обеих физических таблиц без преобразования
' через строки: separator Excel не должен менять записанные Double.
Private Sub TestNumericTables()
    Dim key As Variant, values As Variant, row As Long, column As Long, parsed As Double, required As Variant, item As Variant
    For Each key In Array("rngNDMSectionGeometry", "rngNDMElementGeometry")
        values = ReadPhysicalResultTable(ThisWorkbook, CStr(key))
        For row = 2 To UBound(values, 1)
            If CStr(key) = "rngNDMSectionGeometry" Then
                required = Array(4, 5, 6, 11, 12, 13, 14)
                For Each item In required: TestRequiredNumeric values(row, CLng(item)), CStr(key) & "." & CStr(row) & "." & CStr(item): Next item
                If CStr(values(row, 3)) = "Concrete" Then required = Array(8, 9) Else required = Array(10)
            Else
                required = Array(4, 7, 8)
                For Each item In required: TestRequiredNumeric values(row, CLng(item)), CStr(key) & "." & CStr(row) & "." & CStr(item): Next item
                Select Case CStr(values(row, 6))
                    Case "CONTOUR_LINE": required = Array(9, 10)
                    Case "CONTOUR_ARC": required = Array(11, 12, 14)
                    Case "CONTOUR_CIRCLE": required = Array(13)
                    Case Else: Err.Raise 5, , "Неизвестный SegmentType в тестовом снимке."
                End Select
            End If
            For Each item In required: TestRequiredNumeric values(row, CLng(item)), CStr(key) & "." & CStr(row) & "." & CStr(item): Next item
            For column = 2 To UBound(values, 2)
                If IsNumeric(values(row, column)) And VarType(values(row, column)) <> vbString Then
                    TestCheck "matrix.numeric." & CStr(key) & "." & CStr(row) & "." & CStr(column), TryReadStrictDouble(values(row, column), parsed)
                    TestCheck "matrix.bits." & CStr(key) & "." & CStr(row) & "." & CStr(column), TestDoubleBits(parsed) = TestDoubleBits(CDbl(values(row, column)))
                End If
            Next column
        Next row
    Next key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Обязательное численное поле должно быть числом, а не строкой с похожим видом.
' Неиспользуемые поля другого типа сегмента здесь намеренно не проверяются.
Private Sub TestRequiredNumeric(ByVal value As Variant, ByVal label As String)
    TestCheck "matrix.requiredType." & label, VarType(value) <> vbString And Not IsEmpty(value) And Not IsNull(value) And Not IsError(value)
    Dim parsed As Double, accepted As Boolean: accepted = TryReadStrictDouble(value, parsed)
    TestCheck "matrix.requiredParse." & label, accepted
    If accepted Then TestCheck "matrix.requiredBits." & label, TestDoubleBits(parsed) = TestDoubleBits(CDbl(value))
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет существующую настройку key/value; строки чисел сохраняет текстом.
Private Sub TestSetting(ByVal key As String, ByVal value As Variant)
    Dim table As Object, row As Long: Set table = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    For row = 1 To table.Rows.Count
        If CStr(table.Cells(row, 1).Value2) = key Then
            If VarType(value) = vbString Then table.Cells(row, 2).NumberFormat = "@"
            table.Cells(row, 2).Value2 = value: Exit Sub
        End If
    Next row
    Err.Raise 5, , "Нет настройки " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Копирует биты Double без текстового форматирования и зависимости от локали.
Private Function TestDoubleBits(ByVal value As Double) As String
    Dim source As TTestDoubleValue, words As TTestDoubleWords
    source.Value = value: LSet words = source
    TestDoubleBits = Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает численные свойства с небольшим запасом округления сериализации.
Private Sub TestNear(ByVal label As String, ByVal actual As Double, ByVal expected As Double)
    TestCheck label & "; actual=" & CStr(actual) & "; expected=" & CStr(expected), Abs(actual - expected) <= 0.000000001 * (1# + Abs(expected))
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет все результаты текущего адресного случая в первичном журнале.
Private Sub TestCheck(ByVal label As String, ByVal passed As Boolean)
    If passed Then mPassed = mPassed + 1 Else mFailed = mFailed + 1
    mReport = mReport & IIf(passed, "PASS ", "FAIL ") & label & vbCrLf
End Sub
