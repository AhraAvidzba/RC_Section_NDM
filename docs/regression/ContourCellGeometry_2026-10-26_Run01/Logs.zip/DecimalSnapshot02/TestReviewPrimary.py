"""ДЛЯ ТЕСТОВ: read-only review двух новых Contour/File05 decimal-сценариев."""
from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import re

RUN = Path(__file__).resolve().parent
BASE = RUN.parent
WATCH = BASE / "DecimalSnapshot02.Watchdog"
load = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda data: hashlib.sha256(data).hexdigest().upper()
inputs, records = load(RUN / "Input.json"), load(RUN / "Cases.json")
acceptance, completion = load(RUN / "Acceptance.json"), load(WATCH / "Completion.json")
closure = load(RUN / "ProcessClosure.json")
restoration, previous_separators = load(RUN / "SeparatorRestoration.json"), load(RUN / "SeparatorsBefore.json")
guard = load(BASE / "DecimalSnapshotPlan/EmptyNumericSweepFailure01Proof.json")
expected = [("01_Dot_File", ".", ",", "ContourDecimalDot.ndm"),
            ("02_Comma_File", ",", ".", "ContourDecimalComma.ndm")]
required = ["application.customSeparators", "application.decimal", "application.thousandsDifferent",
            "strict.numericVariant", "strict.singleCommaDecimal", "strict.noAccidentalThousands",
            "settings.GetDouble.dot", "settings.GetRequiredDouble.comma", "preview.count", "fileView.count",
            "sheetRestore.count", "calculate.noWarning", "file.has18Columns", "file.hasElementGeometry",
            "sheetRestore.noSolve", "sheetRestore.bits", "fileRestore.noSolve", "fileRestore.bits"]
issues, cases, geometries = [], [], []


def canonical_tables(data):
    """Chr30 — разделитель полей, поэтому splitlines здесь использовать нельзя."""
    result, current = {}, None
    for line in data.decode("utf-8-sig").split("\n"):
        line = line.rstrip("\r")
        if line in ("rngNDMSectionGeometry", "rngNDMElementGeometry"):
            current = line
            result[current] = []
        elif current and line:
            result[current].append(line.split(chr(30))[:-1])
    return result


for case_id, decimal, thousands, filename in expected:
    record = next(item for item in records if item["Case"] == case_id)
    raw = (RUN / (case_id + ".txt")).read_bytes()
    lines = raw.decode("utf-8-sig").splitlines()
    passed = [line[5:] for line in lines if line.startswith("PASS ")]
    failed = [line for line in lines if line.startswith(("FAIL ", "RUNTIME", "WATCHDOG_FAILURE"))]
    labels = Counter(line.split(";")[0] for line in passed)
    terminals = [re.fullmatch(r"TOTAL_CONTOUR_DECIMAL: passed=(\d+); failed=(\d+)", line)
                 for line in lines if line.startswith("TOTAL_CONTOUR_DECIMAL:")]
    counts_match = (len(terminals) == 1 and terminals[0] is not None
                    and int(terminals[0][1]) == len(passed) == record["AssertionsPassed"] == 1196
                    and int(terminals[0][2]) == len(failed) == record["AssertionsFailed"] == 0)
    before, after = ((RUN / (case_id + suffix)).read_bytes() for suffix in (".Before.txt", ".After.txt"))
    geometry = (RUN / (case_id + ".Geometry.txt")).read_bytes()
    geometries.append(geometry)
    tables = canonical_tables(geometry)
    grid, boundary = tables["rngNDMSectionGeometry"], tables["rngNDMElementGeometry"]
    element_ids = [row[0][1:] for row in grid[1:]]
    owners, kinds, roles = (Counter(row[index][1:] for row in boundary[1:]) for index in (16, 4, 3))
    numeric_frames = sum(value.startswith("D") for table in tables.values() for row in table[1:] for value in row)
    topology_ok = (len(grid[0]) == 15 and len(boundary[0]) == 17 and len(grid) == 5 and len(boundary) == 14
                   and element_ids == ["C1", "C2", "R1", "R2"] and owners == {"C1": 5, "C2": 8}
                   and kinds == {"CONTOUR_ARC": 12, "CONTOUR_LINE": 1}
                   and roles == {"Outer": 9, "Opening": 4} and numeric_frames == 111)
    numeric_counts = {prefix: sum(count for label, count in labels.items() if label.startswith(prefix + "."))
                      for prefix in ("matrix.requiredType", "matrix.requiredParse", "matrix.requiredBits", "matrix.numeric", "matrix.bits")}
    separators = load(RUN / (case_id + ".Separators.json"))
    archive = (RUN / filename).read_bytes()
    magic = archive[:8].decode("ascii")
    clear_counts = {table: labels["restore.privateTableCleared." + table] for table in tables}
    checks = {
        "TerminalCountsMatch": bool(counts_match), "NoPrimaryFailures": not failed,
        "RequiredCheckGroupsPresent": all(labels[key] for key in required),
        "AllRequiredNumericGroupsComplete": all(value == 222 for value in numeric_counts.values()),
        "ExpectedIDsOwnersTopologyAnd111NumericFrames": topology_ok,
        "BothTablesClearedBeforeBothRestoreStages": all(value == 2 for value in clear_counts.values()),
        "SeparatorProfileMatches": separators == {"UseSystem": False, "Decimal": decimal, "Thousands": thousands, "WindowsLocaleChanged": False},
        "ActualFile05MagicAndHashMatch": magic == record["FileMagic"] == "NDMSNP05" and sha(archive) == record["FileSHA256"],
        "PrimaryAndGeometryHashesMatch": sha(raw) == record["PrimarySHA256"] and sha(geometry) == record["GeometrySHA256"],
        "ActualReopenFingerprintBytesMatch": before == after and sha(before) == record["ReopenBeforeSHA256"]
            and sha(after) == record["ReopenAfterSHA256"] and record["ReopenFingerprintEqual"] and record["ReopenGeometryEqual"],
    }
    if not all(checks.values()):
        issues.append({"Case": case_id, "Checks": checks, "FailedLines": failed})
    model_properties = []
    for line in passed:
        match = re.match(r"(preview|fileView|sheetRestore)\.(A|X|Y|Ix|Iy|Ixy)\.(\d+); actual=([^;]+); expected=(.*)$", line)
        if match:
            model_properties.append({"Stage": match[1], "Property": match[2], "ElementID": "C" + match[3],
                "Actual": float(match[4].replace(",", ".")), "Expected": float(match[5].replace(",", "."))})
    cases.append({"CaseID": case_id, "SeparatorProfile": separators, "PrimaryReadEntirely": True,
        "PrimaryBytesRead": len(raw), "PrimaryLinesRead": len(lines), "PrimarySHA256": sha(raw),
        "AssertionsPassed": len(passed), "AssertionsFailed": len(failed), "Checks": checks,
        "NumericAssertionCounts": numeric_counts, "RequiredNumericScalarFieldsPerSweep": 111, "NumericSweeps": 2,
        "GeometryColumnsIncludingRunID": len(grid[0]) + 1, "BoundaryColumnsIncludingRunID": len(boundary[0]) + 1,
        "ElementIDs": element_ids, "BoundaryOwnerRowCounts": owners, "SegmentTypeRowCounts": kinds,
        "LoopRoleRowCounts": roles, "NumericIEEE754Frames": numeric_frames, "ModelProperties": model_properties,
        "AllParserAndSettingsChecks": [line for line in passed if line.startswith(("strict.", "settings."))],
        "PhysicalTableClearCounts": clear_counts, "SnapshotFile": filename, "SnapshotBytesRead": len(archive),
        "SnapshotMagic": magic, "SnapshotSHA256": sha(archive), "GeometrySHA256": sha(geometry),
        "GeometryBytesRead": len(geometry), "ReopenFingerprintBytesRead": len(before) + len(after),
        "ReopenBeforeSHA256": sha(before), "ReopenAfterSHA256": sha(after), "MacroInvocationSeconds": record["Seconds"]})

source_ok = sha(Path(inputs["Source"]).read_bytes()) == inputs["SourceSHA256"]
helper_ok = sha(Path(inputs["Helper"]).read_bytes()) == inputs["HelperSHA256"]
old_failures_preserved = sha((BASE / "DecimalSnapshot01/01_Dot_File.txt").read_bytes()) == guard["PrimarySHA256"]
separators_restored = restoration["Passed"] and restoration["Original"] == previous_separators and all(
    restoration[key] == previous_separators[key] for key in ("UseSystem", "Decimal", "Thousands"))
geometry_equal = len(geometries) == 2 and geometries[0] == geometries[1] and load(RUN / "CrossSeparatorGeometry.json")["Passed"]
stdout, stderr = (WATCH / "Worker.stdout.log").read_bytes(), (WATCH / "Worker.stderr.log").read_bytes()
memory = [load(path) for path in RUN.glob("Memory_*.json")]
worker_ok = (acceptance["Passed"] and completion["WorkerExitCode"] == 0 and not completion["TimedOut"]
             and not completion["OrphansAfterWorkerExit"] and closure["ExactIdentityAbsent"] and not stderr
             and json.loads(stdout.decode("utf-8-sig")) == acceptance and all(item["Ready"] for item in memory))
if not all((source_ok, helper_ok, old_failures_preserved, guard["RequiredNumericMethodUnchanged"], separators_restored, geometry_equal, worker_ok)):
    issues.append("Source/helper/historical-failure/worker/separator gate mismatch")
review = {"Status": "PASS_DIRECTED_DECIMAL_SNAPSHOT02_PRIMARY_REVIEW" if not issues else "REVIEW_REQUIRED",
    "ReviewedUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(), "AllTwoPrimariesReadEntirely": True,
    "TotalPrimaryBytesRead": sum(case["PrimaryBytesRead"] for case in cases),
    "TotalPrimaryLinesRead": sum(case["PrimaryLinesRead"] for case in cases),
    "AssertionsPassed": sum(case["AssertionsPassed"] for case in cases), "AssertionsFailed": sum(case["AssertionsFailed"] for case in cases),
    "Cases": cases, "SourceWorkbookSHA256": inputs["SourceSHA256"], "SourceWorkbookHashRechecked": source_ok,
    "SourceHelperSHA256": inputs["HelperSHA256"], "SourceHelperHashRechecked": helper_ok,
    "ActualCrossSeparatorGeometryBytesEqual": geometry_equal, "CrossSeparatorGeometrySHA256": sha(geometries[0]),
    "AllFourActualReopenFingerprintFilesReadAndCompared": True, "BothActualFile05ArchivesReadAndHashed": True,
    "OwnApplicationSeparatorsRestoredExactly": separators_restored, "SeparatorRestoration": restoration,
    "WindowsLocaleChanged": False, "Scope": "Two custom Excel separator profiles, not two Windows locales and not DiagramExtension No/Yes.",
    "HistoricalDecimalSnapshot01All122FailuresPreserved": old_failures_preserved,
    "RequiredNumericMethodUnchangedByPrivateEmptyGuardFix": guard["RequiredNumericMethodUnchanged"],
    "WatchdogCompletion": completion, "ProcessClosure": closure, "WorkerStderrBytes": len(stderr),
    "AllMemoryGatesReady": all(item["Ready"] for item in memory),
    "MinimumObservedFreeRAMGiB": min(item["FreeRAMGiB"] for item in memory),
    "MinimumObservedFreeCommitGiB": min(item["FreeCommitGiB"] for item in memory),
    "Issues": issues, "ReadOnlyReview": True, "ExcelOrCADStartedByReview": False, "FullRegressionPass": False}
(RUN / "PrimaryReview.json").write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({key: review[key] for key in ("Status", "AssertionsPassed", "AssertionsFailed", "TotalPrimaryBytesRead", "ActualCrossSeparatorGeometryBytesEqual", "Issues")}))
