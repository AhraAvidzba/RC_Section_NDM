# ДЛЯ ТЕСТОВ: проверяет PS5-синтаксис и явный строковый property-put без Excel.
$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$source = Join-Path $repo 'tools/build_workbook/SettingsCatalog.ps1'
$tokens = $null; $parseErrors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($source, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count) { throw ($parseErrors.Message -join '; ') }
$function = $ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Restore-InstructionCellFormat'}, $true)[0]
$statement = @($function.FindAll({param($node) $node -is [Management.Automation.Language.PipelineAst] -and $node.Extent.Text.StartsWith("[void]`$part.GetType().InvokeMember('Style',")}, $true))
if ($statement.Count -ne 1) { throw 'The exact production Style property-put statement must occur once.' }
Add-Type @'
public sealed class TestInstructionStyleTarget {
    private string style;
    public int Calls { get; private set; }
    public string Style { get { return style; } set { style=value; Calls++; } }
}
'@
$code = [scriptblock]::Create($statement[0].Extent.Text)
$part = New-Object TestInstructionStyleTarget
$record = [pscustomobject]@{Style='Обычный'}
. $code
if ($part.Calls -ne 1 -or $part.Style -cne 'Обычный') { throw 'A localized style name must be one string property value.' }
$record.Style = [psobject]'Hyperlink'
. $code
if ($part.Calls -ne 2 -or $part.Style -cne 'Hyperlink') { throw 'A PSObject wrapper must become one plain string property value.' }
[ordered]@{Status='PASS_SYNTAX_AND_MANAGED_PROPERTY_PUT_ONLY';PowerShellVersion=$PSVersionTable.PSVersion.ToString();ParseErrors=0;Checks=2;ExcelStarted=$false;NativeCOMVerification=$false;SourceSHA256=(Get-FileHash -LiteralPath $source).Hash} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Checks.json') -Encoding UTF8
