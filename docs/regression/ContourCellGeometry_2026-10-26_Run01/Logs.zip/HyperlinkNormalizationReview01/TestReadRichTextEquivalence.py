"""Read-only per-character appearance check; does not alter strict verifier."""
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as E
from zipfile import ZipFile
from openpyxl.styles.colors import COLOR_INDEX

BASE = Path(__file__).resolve().parent.parent
NS = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
RID = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'


def font_values(node, palette):
    result = {}
    if node is None:
        return result
    for part in node:
        name = part.tag.rsplit('}',1)[-1]
        if name == 'rFont':
            name = 'name'
        attrs = dict(part.attrib)
        if name == 'color' and 'indexed' in attrs:
            index = int(attrs['indexed'])
            assert index < len(palette), ('Unknown palette color', index)
            attrs = {'rgb':palette[index]}
        if name in ('b','i','strike','outline','shadow'):
            attrs = {'val':attrs.get('val','1')}
        result[name] = attrs
    return result


def load(name):
    with ZipFile(BASE/name/'RC_Section_NDM.xlsm') as archive:
        styles = E.fromstring(archive.read('xl/styles.xml'))
        palette = [n.get('rgb') for n in styles.findall('s:colors/s:indexedColors/s:rgbColor',NS)]
        if not palette:
            palette = ['FF'+value[-6:] for value in COLOR_INDEX]  # Стандартная indexed-палитра при отсутствии собственной таблицы; граница и шрифт используют непрозрачный RGB.
        assert palette[8][-6:] == '000000'
        fonts = [font_values(n,palette) for n in styles.find('s:fonts',NS)]
        xfs = list(styles.find('s:cellXfs',NS))
        strings = list(E.fromstring(archive.read('xl/sharedStrings.xml')))
        wb = E.fromstring(archive.read('xl/workbook.xml'))
        rels = {n.get('Id'):n.get('Target') for n in E.fromstring(archive.read('xl/_rels/workbook.xml.rels'))}
        cells = {}
        for sheet in wb.find('s:sheets',NS):
            target = rels[sheet.get(RID)]
            target = target.lstrip('/') if target.startswith('/') else 'xl/'+target
            for cell in E.fromstring(archive.read(target)).findall('s:sheetData/s:row/s:c',NS):
                if cell.get('t') != 's':
                    continue
                value = cell.find('s:v',NS)
                if value is None:
                    continue
                raw = strings[int(value.text)]
                base_font = fonts[int(xfs[int(cell.get('s','0'))].get('fontId','0'))]
                characters = []
                runs = list(raw.findall('s:r',NS))
                if not runs:
                    text = ''.join(n.text or '' for n in raw.findall('s:t',NS))
                    characters = [(c,base_font) for c in text]
                else:
                    for run in runs:
                        effective = dict(base_font)
                        effective.update(font_values(run.find('s:rPr',NS),palette))
                        text = ''.join(n.text or '' for n in run.findall('s:t',NS))
                        characters.extend((c,effective) for c in text)
                cells[(sheet.get('name'),cell.get('r'))] = (E.tostring(raw), characters)
        return cells


if __name__ == '__main__':
    before = load('ReleaseCandidate05')
    reports = []
    for name in ('HyperlinkNative05','HyperlinkNative06'):
        after = load(name)
        changed, different = [], []
        for key, (raw, rendered) in before.items():
            if key not in after or raw == after[key][0]:
                continue
            current = after[key][1]
            if ''.join(c for c,_ in rendered) != ''.join(c for c,_ in current):
                continue
            changed.append({'Sheet':key[0],'Cell':key[1], 'Characters':len(rendered),
                            'EffectiveAppearanceEqual':rendered==current,
                            'BeforeSHA256':hashlib.sha256(json.dumps(rendered,sort_keys=True).encode()).hexdigest().upper(),
                            'AfterSHA256':hashlib.sha256(json.dumps(current,sort_keys=True).encode()).hexdigest().upper()})
            if rendered != current:
                different.append(key)
        reports.append({'Book':name,'RawRichStringChanges':len(changed),'EffectivePerCharacterDifferences':different,
                        'Cells':changed,'Passed':not different})
    result = {'Status':'PASS_SCOPED_EFFECTIVE_RICH_TEXT_APPEARANCE' if all(r['Passed'] for r in reports) else 'FAIL',
              'ReadOnly':True,'ExcelStarted':False,'StrictVerifierUnchanged':True,
              'Scope':'All unchanged-text shared-string cells with changed raw rich-string XML; inherited cell font and actual indexed palette resolved.',
              'Reports':reports}
    (Path(__file__).parent/'RichTextAppearance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'Status':result['Status'],'Reports':[{k:v for k,v in r.items() if k!='Cells'} for r in reports]}))
    raise SystemExit(result['Status']=='FAIL')
