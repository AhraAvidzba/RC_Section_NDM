$ErrorActionPreference='Stop'
[string[]]$names=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path (Get-Location) 'docs/regression/ExcelGuardGuide_2026-10-13/ClassComments_2026-10-15/ModuleNames.json')))
Write-Output ('MODULE_COUNT: '+$names.Count)
& './tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/ExcelGuardGuide_2026-10-13/ClassComments_2026-10-15/Candidate/RC_Section_NDM.xlsm' -ModuleNames $names
