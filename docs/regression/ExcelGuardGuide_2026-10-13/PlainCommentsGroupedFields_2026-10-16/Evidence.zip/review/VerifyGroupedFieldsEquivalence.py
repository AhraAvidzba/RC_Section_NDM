from pathlib import Path
import importlib.util,json,re,hashlib,zipfile
root=Path(__file__).resolve().parents[2]
r=root/'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsGroupedFields_2026-10-16'
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
a=module('a',root/'tools/build_workbook/Audit-ClassComments.py');p=module('p',root/'tools/build_workbook/Verify-GuidePresentation.py')
def normalize(t):
 return ''.join(x if x.startswith(('"',"'")) else x.lower() for x in re.findall(r'"(?:[^"\n]|"")*"|\x27[^\n]*|[^"\x27\n]+|\n',t.replace('\r\n','\n')))
b=p.components(root/'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsLastReadability_2026-10-16/BaselineNativeVBA.txt');c=p.components(r/'CandidateNativeVBA.txt');published=p.components(r/'PublishedNativeVBA.txt')
assert b.keys()==c.keys() and len(b)==157
assert c==published
assert all(b[k][0]==c[k][0] for k in b)
before={k:a.executable_lines(normalize(v[2])) for k,v in b.items()};after={k:a.executable_lines(normalize(v[2])) for k,v in c.items()};assert before==after
fingerprint=hashlib.sha256(json.dumps(before,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest=json.loads((root/'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsFinalAcceptance_2026-10-16/Run.json').read_text(encoding='utf-8-sig'))
basehash=hashlib.sha256(Path(manifest['FrozenWorkbook']).read_bytes()).hexdigest();assert basehash==manifest['SourceSHA256'].lower()
package=json.loads((r/'Package.json').read_text(encoding='utf-8'))
assert package['ChangedZIPParts']==['xl/vbaProject.bin'] and package['UserDataFormulasSettingsFormattingPreserved']
currenthash=hashlib.sha256((root/'workbook/output/RC_Section_NDM.xlsm').read_bytes()).hexdigest();assert currenthash==package['WorkbookSHA256'].lower()
with zipfile.ZipFile(manifest['FrozenWorkbook']) as source, zipfile.ZipFile(root/'workbook/output/RC_Section_NDM.xlsm') as output:
 assert source.namelist()==output.namelist()
 assert [name for name in source.namelist() if source.read(name)!=output.read(name)]==['xl/vbaProject.bin']
assert fingerprint=='35c693194b97716482c632d2959e7e0ef2b40242b27c78a7be2602723ba3a190'
receipt={'status' :'PASS','components':len(b),'executableLinesAndOrderEqual':True,'baseWorkbookSHA256':basehash,'publishedWorkbookSHA256':currenthash,'baseCommit':manifest['SourceCommit'],'executionFingerprintSHA256':fingerprint,'normalization':'VBA identifiers case-insensitive; comments excluded; strings, statement order and declarations preserved','userDataZIPPartsEqual':True,'actualPublishedNativeReadbackMatched':True}
(r/'NativeExecutionEquivalence.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt,ensure_ascii=False))
