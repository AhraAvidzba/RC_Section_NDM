﻿$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$evidence=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsGroupedFields_2026-10-16'
$main=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$allCode=Join-Path $root 'workbook/output/VBA_All_Code.txt'
$execution=Join-Path $root 'workbook/output/RC_Section_NDM_execution_report.txt'
$baseline=Join-Path $evidence 'Baseline.xlsm'
$privateDirectory=Join-Path $evidence 'Candidate'
[void][IO.Directory]::CreateDirectory($privateDirectory)
$candidate=Join-Path $privateDirectory 'RC_Section_NDM.xlsm'
if ((Test-Path -LiteralPath $baseline) -or (Test-Path -LiteralPath $candidate)) {throw 'Fresh evidence paths are required.'}
# Exclusive reading prevents copying a workbook that Excel is saving.
$stream=[IO.File]::Open($main,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
try {
    $output=[IO.File]::Create($baseline)
    try {$stream.CopyTo($output)} finally {$output.Dispose()}
} finally {$stream.Dispose()}
Copy-Item -LiteralPath $baseline -Destination $candidate
Copy-Item -LiteralPath $allCode -Destination (Join-Path $evidence 'BaselineNativeVBA.txt')
$before=[ordered]@{
    WorkbookHash=(Get-FileHash -LiteralPath $main -Algorithm SHA256).Hash
    AllCodeHash=(Get-FileHash -LiteralPath $allCode -Algorithm SHA256).Hash
    ExecutionReportHash=(Get-FileHash -LiteralPath $execution -Algorithm SHA256).Hash
    BaseRef='fcc84e6'
}
$before | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $evidence 'Before.json') -Encoding UTF8
[string[]]$names=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $evidence 'ModuleNames.json')))
& (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath 'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsGroupedFields_2026-10-16/Candidate/RC_Section_NDM.xlsm' -ModuleNames $names
