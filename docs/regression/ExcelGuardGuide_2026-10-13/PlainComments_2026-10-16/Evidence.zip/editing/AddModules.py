import json,re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root=Path(__file__).resolve().parents[2];here=Path(__file__).resolve().parent
inventory=json.loads((here/'Inventory.json').read_text(encoding='utf-8'))
known={c['file'] for c in inventory}
pattern=re.compile(r'\b(?:typed|named[ -]?states?|meta|writer|solver|search|pipeline|snapshot|layout|facade|options|context|reader|callback|production|fixture|workflow|reusable|downstream|domain|probe|warm.start|fallback|retry|extension|active.set|bucket|reuse|cache|canonical|immutable|mutable|definition|query|executor|getter|setter|repository|strength|capacity|formation|crack|display|policy|presentation|selector|scalar|contract|target|source|ordinals|loops?|origin|explicit|implicit|generic|state|states|subtree|subtrees|result|results|input|output)\b|квантован|каноническ|скаляр|публикац|опубликован|доменн|семантич|оркестр|жизненн|инвалид|контракт|кандидат|пространственн|смыслов.{0,10}принадлеж',re.I)
new=[]
for path in sorted(p for folder in ('src','tests','docs/geometry_refactor/examples') for p in (root/folder).rglob('*.bas')):
 relative=path.relative_to(root).as_posix()
 if relative in known:continue
 lines=path.read_text(encoding='utf-8-sig').splitlines();blocks=[];i=0
 while i<len(lines):
  line=lines[i];quoted=False;j=0;start=None
  while j<len(line):
   if line[j]=='"':
    if quoted and j+1<len(line) and line[j+1]=='"':j+=2;continue
    quoted=not quoted
   elif line[j]=="'" and not quoted:start=j;break
   j+=1
  if start is None:i+=1;continue
  first=i;text=[line[start:]];code=line[:start].strip();inline=bool(code)
  if not inline:
   while i+1<len(lines) and lines[i+1].lstrip().startswith("'"):
    i+=1;text.append(lines[i].lstrip())
  tail=next((s.strip() for s in lines[i+1:] if s.strip() and not s.lstrip().startswith("'")),'')
  full='\n'.join(text)
  if re.search('[А-Яа-яЁёA-Za-z]',full):blocks.append({'line':first+1,'end':i+1,'text':full,'inline':inline,'code':code,'next':tail,'flagged':bool(pattern.search(full))})
  i+=1
 entry={'file':relative,'blocks':blocks};inventory.append(entry);new.append(path)
(here/'Inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with ZipFile(here/'BaselineSources.zip','a',ZIP_DEFLATED) as out:
 for path in new:out.write(path,path.relative_to(root).as_posix())
for i,c in enumerate(inventory):
 if Path(c['file']).suffix=='.bas':print(i,c['file'],len(c['blocks']),sum(b['flagged'] for b in c['blocks']))
print('TOTAL',len(inventory),sum(len(c['blocks']) for c in inventory))
