import re
from pathlib import Path

METHOD=re.compile(r'^\s*(?:(?:Public|Private|Friend)\s+)?(?:Static\s+)?(Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)',re.I)
TEST_METHODS={
'CBatchSectionCalculator':'CrackDomainBuildCount MechanicalPreparationBuildCount RunPreparationReleased TestRepeatCrackCalculation',
'CCrackWidthCalculator':'Audit02AutoPsiForTests',
'CAutoCADSectionModelImporter':'AddConcreteRegionArray AddRebarRegionArray HasArrayRows OptionalRegionDouble OptionalRegionString BuildFromRegionArrays DebugEdgeProbeCount',
'CSystemSettingsReader':'KeyAt',
'CFiberMeshBuilder':'BuildSeconds',
'CMaterialDiagram':'InitializeFromTwoCompressionPoints InitializeFromThreeCompressionPoints InitializeFromTwoTensionPoints InitializeFromThreeTensionPoints Initialize',
'CMaterialModelProvider':'InitializeFromParameters',
'CSectionGeometryQuery':'DomainBuildCount',
'CSectionModel':'RebarSourceName RebarSteelClass',
'CSectionPropertiesCalculator':'PreparationBuildCount LastCalculationSeconds',
'CCapacitySolver':'RetryCount CriticalStrain CriticalElement CriticalStrainUtilization',
'CLinearSystem3x3':'AbsoluteResidual',
'CSectionSolver':'LoadStepsCompleted InternalForceEvaluationCount TangentBuildCount EvaluationReuseCount InternalNewtonCallCount MatrixRestartCount',
'CStateSolutionRunner':'TestRunRetryAttempt TestRetryAttemptCount',
'modWorkbookCalculation':'Audit03ApplyLoadReferenceForTests',
'modAutoCADStressExport':'SP35ExportSavedContoursToModelSpaceForTests SP35ExportSavedMaterialContoursForTests SP35ExportSavedCrackRegionForTests Audit03ReadContourArcSweepsForTests Audit02ReadExportSnapshotForTests PerformanceExportReadDiagnosticsForTests Audit03AutoCADPresentationForTests Audit03CleanupAutoCADModelSpaceForTests Audit03ExportAutoCADDocumentForTests Audit03EnsureAutoCADLayerForTests',
}

def split_methods(lines):
    items=[];last_end=0
    for i,line in enumerate(lines):
        m=METHOD.match(line)
        if not m:continue
        kind=m[1].split()[0]
        end=next(j+1 for j in range(i+1,len(lines)) if re.match(r'\s*End\s+'+kind+r'\s*$',lines[j],re.I))
        start=i
        while start>last_end and (not lines[start-1].strip() or lines[start-1].lstrip().startswith("'")):start-=1
        items.append({'name':m[2],'kind':m[1],'start':start,'declaration':i,'end':end})
        last_end=end
    return items

def reorder(relative,lines):
    name=Path(relative).stem
    if name not in TEST_METHODS:return lines,None
    tests=set(TEST_METHODS[name].lower().split());items=split_methods(lines)
    actual={m['name'].lower() for m in items}
    assert tests<=actual,(name,tests-actual)
    prefix=lines[:items[0]['start']];normal=[];test=[];order=[]
    for m in items:
        comments=lines[m['start']:m['declaration']]
        body=lines[m['declaration']:m['end']]
        if m['name'].lower() not in tests:
            normal.extend(comments+body);continue
        order.append(m['name'])
        clean=[]
        for i,line in enumerate(comments):
            if re.match(r"\s*'\s*=+\s*$",line):continue
            if re.match(r"\s*'\s*ДЛЯ ТЕСТОВ\s*$",line,re.I):continue
            clean.append(line)
        while clean and not clean[0].strip():clean.pop(0)
        while clean and not clean[-1].strip():clean.pop()
        last_blank=max((i for i,s in enumerate(clean) if not s.strip()),default=-1)
        if not any('ДЛЯ ТЕСТОВ:' in s.upper() for s in clean[last_blank+1:]):
            first=next((i for i,s in enumerate(clean) if i>last_blank and s.strip().startswith("'")),None)
            assert first is not None,(name,m['name'])
            prose=clean[first].lstrip().removeprefix("'").lstrip()
            clean[first]="' ДЛЯ ТЕСТОВ: "+prose[0].lower()+prose[1:]
        test.extend(['']+clean+body)
    result=prefix+normal+['',"' "+'='*74,"' ДЛЯ ТЕСТОВ","' "+'='*74]+test
    result+=lines[items[-1]['end']:]
    # После переноса сохраняем небольшие интервалы между блоками.
    out=[]
    for line in result:
        if not line.strip() and len(out)>=2 and not out[-1].strip() and not out[-2].strip():continue
        out.append(line)
    return out,{'file':relative,'testMethods':order,'allMethods':len(items),'orderChanged':[m['name'] for m in items]!=[m['name'] for m in items if m['name'].lower() not in tests]+order}
