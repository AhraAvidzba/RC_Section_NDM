﻿$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$evidence=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/PlainComments_2026-10-16'
$main=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$allCode=Join-Path $root 'workbook/output/VBA_All_Code.txt'
$execution=Join-Path $root 'workbook/output/RC_Section_NDM_execution_report.txt'
$before=Get-Content -LiteralPath (Join-Path $evidence 'Before.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$package=Get-Content -LiteralPath (Join-Path $evidence 'Package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($package.Status -ne 'COMMENTS_AND_METHOD_ORDER_PACKAGE_PASS') {throw 'Package is not accepted.'}
if ((Get-FileHash -LiteralPath $execution).Hash -cne $before.ExecutionReportHash) {throw 'User execution report changed.'}
$mainStream=$null;$codeStream=$null
function Hash-Bytes([byte[]]$value) {
    $digest=[Security.Cryptography.SHA256]::Create()
    try {[BitConverter]::ToString($digest.ComputeHash($value)).Replace('-','')}
    finally {$digest.Dispose()}
}
function Read-Stream($stream) {
    $memory=New-Object IO.MemoryStream
    try {$stream.Position=0;$stream.CopyTo($memory);return ,$memory.ToArray()}
    finally {$memory.Dispose()}
}
function Write-Stream($stream,[byte[]]$value) {
    $stream.Position=0;$stream.Write($value,0,$value.Length);$stream.SetLength($value.Length);$stream.Flush($true)
}
try {
    $mainStream=[IO.File]::Open($main,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $codeStream=[IO.File]::Open($allCode,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $oldMain=Read-Stream $mainStream;$oldCode=Read-Stream $codeStream
    if ((Hash-Bytes $oldMain) -cne $before.WorkbookHash -or (Hash-Bytes $oldCode) -cne $before.AllCodeHash) {throw 'Production changed after the private copy; preserve user changes before publishing.'}
    $newMain=[IO.File]::ReadAllBytes((Join-Path $evidence 'Accepted.xlsm'))
    $newCode=[IO.File]::ReadAllBytes((Join-Path $evidence 'CandidateNativeVBA.txt'))
    if ((Hash-Bytes $newMain) -cne $package.WorkbookSHA256) {throw 'Accepted workbook hash mismatch.'}
    try {Write-Stream $mainStream $newMain;Write-Stream $codeStream $newCode}
    catch {Write-Stream $mainStream $oldMain;Write-Stream $codeStream $oldCode;throw}
} finally {
    if ($mainStream) {$mainStream.Dispose()}
    if ($codeStream) {$codeStream.Dispose()}
}
[ordered]@{Status='COMMENTS_PUBLISHED_PENDING_READBACK';WorkbookSHA256=(Get-FileHash -LiteralPath $main).Hash;ExecutionReportSHA256=(Get-FileHash -LiteralPath $execution).Hash;ActualReadbackPending=$true} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $evidence 'Publication.json') -Encoding UTF8
Write-Output 'COMMENTS_PUBLISHED_PENDING_READBACK'
