import hashlib
import importlib.util
import json
import re
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parents[2]
directory = root/'docs/regression/ExcelGuardGuide_2026-10-13/PlainComments_2026-10-16'
def module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result
audit=module('audit',root/'tools/build_workbook/Audit-ClassComments.py')
presentation=module('presentation',root/'tools/build_workbook/Verify-GuidePresentation.py')
def normalize(text):
    return ''.join(part if part.startswith(('"', "'")) else part.lower() for part in re.findall(
        r'"(?:[^"\n]|"")*"|\x27[^\n]*|[^"\x27\n]+|\n', text.replace('\r\n','\n')))
def code(text):
    return audit.code_units(normalize(text))
baseline=presentation.components(directory/'BaselineReadbackVBA.txt')
candidate=presentation.components(directory/'CandidateNativeVBA.txt')
assert baseline.keys()==candidate.keys() and len(candidate)==157
changed=sorted(name for name in baseline if normalize(baseline[name][2])!=normalize(candidate[name][2]))
code_changes=sorted(name for name in baseline if code(baseline[name][2])!=code(candidate[name][2]))
assert not code_changes, code_changes
requested=json.loads((directory/'ModuleNames.json').read_text())
assert set(changed)<=set(requested), set(changed)-set(requested)
assert len(changed)>70
assert json.loads((directory/'CandidateSourceEquality.json').read_text(encoding='utf-8-sig'))['Passed']
accepted=directory/'Accepted.xlsm'
assert not accepted.exists()
with ZipFile(directory/'Baseline.xlsm') as before, ZipFile(directory/'Candidate/RC_Section_NDM.xlsm') as after, ZipFile(accepted,'w') as output:
    for entry in before.infolist():
        output.writestr(entry, after.read(entry.filename) if entry.filename=='xl/vbaProject.bin' else before.read(entry.filename))
with ZipFile(directory/'Baseline.xlsm') as before, ZipFile(accepted) as after:
    assert before.namelist()==after.namelist()
    changed_parts=[name for name in before.namelist() if before.read(name)!=after.read(name)]
    assert changed_parts==['xl/vbaProject.bin']
receipt={
    'Status':'COMMENTS_AND_METHOD_ORDER_PACKAGE_PASS','NativeComponents':157,
    'ChangedComponents':changed,'MethodBodiesOrDeclarationsChanged':code_changes,'MethodReorderingOnly':True,
    'ChangedZIPParts':changed_parts,'UserDataFormulasSettingsFormattingPreserved':True,
    'WorkbookSHA256':hashlib.sha256(accepted.read_bytes()).hexdigest().upper(),
    'Errors':[],
}
(directory/'Package.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='ChangedComponents'},ensure_ascii=False))
