import hashlib
import json
import textwrap
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
INVENTORY = json.loads((HERE/'Inventory.json').read_text(encoding='utf-8'))
BY_NAME = {Path(c['file']).stem:c for c in INVENTORY}
CHANGES = {}
FIELDS = {}
FIELD_LINES = {}
RAW_REPLACEMENTS = {}
REVIEWED = set()

def edit(name, line, text):
    entry = BY_NAME[name]
    block = next(b for b in entry['blocks'] if b['line']==line)
    key = (entry['file'],line)
    assert key not in CHANGES, key
    CHANGES[key] = {'text':text.strip(), 'block':block}

def reviewed(*names):
    REVIEWED.update(names)

def edits(name, values):
    for line,text in values.items(): edit(name,line,text)

def field(name, member, text):
    FIELDS[(BY_NAME[name]['file'],member)] = text

def fieldline(name, line, text):
    FIELD_LINES[(BY_NAME[name]['file'],line)] = text

def replacecomment(name, old, new):
    RAW_REPLACEMENTS.setdefault(BY_NAME[name]['file'],[]).append((old,new))

def same(old, new):
    for entry in INVENTORY:
        for block in entry['blocks']:
            plain='\n'.join(line.lstrip().removeprefix("'").lstrip() for line in block['text'].splitlines())
            if plain==old and (entry['file'],block['line']) not in CHANGES:
                edit(Path(entry['file']).stem,block['line'],new)

def apply():
    from TestMethodOrder import reorder
    baseline = HERE/'BaselineSources.zip'
    if not baseline.exists():
        with ZipFile(baseline,'w',ZIP_DEFLATED) as out:
            for entry in INVENTORY:out.write(ROOT/entry['file'],entry['file'])
    state_path = HERE/'AppliedHashes.json'
    state = json.loads(state_path.read_text()) if state_path.exists() else {}
    records=[];orders=[]
    with ZipFile(baseline) as before:
        for entry in INVENTORY:
            relative=entry['file'];path=ROOT/relative;original=before.read(relative)
            current=path.read_bytes();sha=lambda data:hashlib.sha256(data).hexdigest()
            assert sha(current)==state.get(relative,sha(original)), 'File changed outside this edit: '+relative
            text=original.decode('utf-8-sig');eol='\r\n' if '\r\n' in text else '\n'
            lines=text.splitlines();changes=[]
            for (file,line),item in CHANGES.items():
                if file!=relative:continue
                b=item['block'];start=line-1;end=b['end']
                assert b['text'].splitlines()[0] in lines[start]
                if b['inline']:
                    prefix=lines[start][:lines[start].index(b['text'])]
                    replacement=[prefix+"' "+item['text'].replace('\n',' ')]
                else:
                    indent=lines[start][:len(lines[start])-len(lines[start].lstrip())]
                    replacement=[]
                    for paragraph in item['text'].splitlines():
                        wrapped=textwrap.wrap(paragraph,94-len(indent),break_long_words=False,break_on_hyphens=False) if paragraph else ['']
                        replacement.extend(indent+"'"+(' '+s if s else '') for s in wrapped)
                changes.append((start,end,replacement))
                records.append({'file':relative,'line':line,'before':b['text'],'after':'\n'.join(replacement)})
            for (file,member),comment in FIELDS.items():
                if file!=relative:continue
                import re
                matches=[i for i,s in enumerate(lines) if re.match(r'\s*(?:Private|Public|Friend)\s+(?:Const\s+|WithEvents\s+)?'+re.escape(member)+r'\b',s,re.I)]
                assert len(matches)==1, (file,member,matches)
                i=matches[0];line=lines[i]
                assert "'" not in line and not line.rstrip().endswith('_'), (file,member)
                replacement=[line+" ' "+comment]
                changes.append((i,i+1,replacement))
                records.append({'file':relative,'line':i+1,'before':'','after':replacement[0],'newFieldComment':True})
            for (file,line),comment in FIELD_LINES.items():
                if file!=relative:continue
                i=line-1
                assert "'" not in lines[i] and not lines[i].rstrip().endswith('_'), (file,line)
                replacement=[lines[i]+" ' "+comment]
                changes.append((i,i+1,replacement))
                records.append({'file':relative,'line':line,'before':'','after':replacement[0],'newFieldComment':True})
            for start,end,replacement in sorted(changes,reverse=True):lines[start:end]=replacement
            for old,new in RAW_REPLACEMENTS.get(relative,[]):
                count=sum(line.count(old) for line in lines)
                assert count,(relative,old)
                for i,line in enumerate(lines):
                    if old not in line:continue
                    assert line.lstrip().startswith("'"),(relative,line)
                    replacement=line.replace(old,new)
                    records.append({'file':relative,'line':i+1,'before':line,'after':replacement,'preservedLayout':True})
                    lines[i]=replacement
            lines,order=reorder(relative,lines)
            if order:orders.append(order)
            result=eol.join(lines)+(eol if text.endswith('\n') else '')
            data=(b'\xef\xbb\xbf' if original.startswith(b'\xef\xbb\xbf') else b'')+result.encode('utf-8')
            modified=changes or order or relative in RAW_REPLACEMENTS
            if modified and data!=current:path.write_bytes(data)
            state[relative]=sha(data if modified else current)
    state_path.write_text(json.dumps(state,indent=2)+'\n')
    (HERE/'Changes.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'Coverage.json').write_text(json.dumps({'classes':len(INVENTORY),'commentBlocks':sum(len(c['blocks']) for c in INVENTORY),'reviewed':sorted(REVIEWED),'edits':len(records),'editedClasses':len({r['file'] for r in records})},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'TestMethodOrder.json').write_text(json.dumps(orders,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Reviewed classes:',len(REVIEWED),'Edited blocks:',len(records),'Edited classes:',len({r['file'] for r in records}))
