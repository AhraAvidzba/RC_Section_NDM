﻿# скрипт обновляет отдельные части существующей книги без ручного импорта модулей через редактор VBA.

param(
    [string]$WorkbookPath = "workbook/output/RC_Section_NDM.xlsm"
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "SettingsCatalog.ps1")

# Добавляет структурный элемент книги или отчета, сохраняя единый формат сборочных скриптов.
function Add-VbaSourceFile {
    param(
        [object]$Workbook,
        [string]$Path
    )

    $extension = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()
    if ($extension -eq ".frm") {
        $Workbook.VBProject.VBComponents.Import($Path) | Out-Null
        return
    }

    $source = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    $lines = $source -split "`r?`n"
    $componentName = $null
    foreach ($line in $lines) {
        if ($line -match '^\uFEFF?Attribute\s+VB_Name\s*=\s*"([^"]+)"') {
            $componentName = $Matches[1]
            break
        }
    }
    if ([string]::IsNullOrWhiteSpace($componentName)) {
        throw "VBA source has no Attribute VB_Name: $Path"
    }

    $componentType = 1
    if ($extension -eq ".cls") {
        $componentType = 2
    }

    $component = $Workbook.VBProject.VBComponents.Add($componentType)
    $component.Name = $componentName

    $bodyLines = New-Object System.Collections.Generic.List[string]
    $insideVbaHeaderBlock = $false
    foreach ($line in $lines) {
        if ($line -match '^\uFEFF?VERSION\s+') { continue }
        if ($line -match '^\uFEFF?BEGIN\s*$') {
            $insideVbaHeaderBlock = $true
            continue
        }
        if ($insideVbaHeaderBlock) {
            if ($line -match '^\uFEFF?END\s*$') {
                $insideVbaHeaderBlock = $false
            }
            continue
        }
        if ($line -match '^\uFEFF?Attribute\s+VB_') { continue }
        $bodyLines.Add($line)
    }

    $body = ($bodyLines -join "`r`n").Trim()
    if ($body.Length -gt 0) {
        $component.CodeModule.AddFromString($body)
    }
}

# Импортирует исходные VBA-модули в книгу, сохраняя воспроизводимость сборки.
function Import-VbaSourceTree {
    param(
        [object]$Workbook,
        [string]$RootPath
    )

    $sourceDirs = @(
        (Join-Path $RootPath "src/Common"),
        (Join-Path $RootPath "src/Interfaces"),
        (Join-Path $RootPath "src/Geometry"),
        (Join-Path $RootPath "src/Section"),
        (Join-Path $RootPath "src/Materials"),
        (Join-Path $RootPath "src/Solver"),
        (Join-Path $RootPath "src/Crack"),
        (Join-Path $RootPath "src/Stability"),
        (Join-Path $RootPath "src/Batch"),
        (Join-Path $RootPath "src/Excel"),
        (Join-Path $RootPath "tests")
    )

    foreach ($dir in $sourceDirs) {
        if (Test-Path -LiteralPath $dir) {
            Get-ChildItem -LiteralPath $dir -Recurse -File |
                Where-Object { $_.Extension -in @(".bas", ".cls", ".frm") } |
                Sort-Object FullName |
                ForEach-Object {
                    Add-VbaSourceFile $Workbook $_.FullName
                }
        }
    }
}

# Удаляет только служебный объект, который может мешать повторяемой сборке или проверке.
function Remove-ImportedVbaComponents {
    param([object]$Workbook)

    $components = @()
    foreach ($component in $Workbook.VBProject.VBComponents) {
        if ($component.Type -ne 100) {
            $components += $component
        }
    }

    foreach ($component in $components) {
        $Workbook.VBProject.VBComponents.Remove($component)
    }
}

# Создает читаемый снимок фактического VBA-проекта рядом с обновленной книгой.
# Это экспорт сборочного артефакта, а не дополнительный источник исходников.
function Export-VbaSnapshot {
    param([object]$Workbook, [string]$Path)

    $text = New-Object System.Text.StringBuilder
    [void]$text.AppendLine("VBA PROJECT EXPORT")
    [void]$text.AppendLine("Workbook: " + $Workbook.Name)
    [void]$text.AppendLine("Date: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    foreach ($component in $Workbook.VBProject.VBComponents) {
        [void]$text.AppendLine("=" * 100)
        [void]$text.AppendLine("COMPONENT: " + $component.Name)
        [void]$text.AppendLine("TYPE: " + $component.Type)
        $lineCount = $component.CodeModule.CountOfLines
        [void]$text.AppendLine("LINES: " + $lineCount)
        [void]$text.AppendLine("=" * 100)
        if ($lineCount -gt 0) {
            [void]$text.AppendLine($component.CodeModule.Lines(1, $lineCount))
        }
        [void]$text.AppendLine()
    }
    [System.IO.File]::WriteAllText($Path, $text.ToString(), (New-Object System.Text.UTF8Encoding($true)))
}

$root = Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "../..")
$fullWorkbookPath = Join-Path $root $WorkbookPath

if (-not (Test-Path -LiteralPath $fullWorkbookPath)) {
    throw "Workbook not found: $fullWorkbookPath"
}

$excel = $null
$workbook = $null
$printAreas = @(Get-WorkbookPrintAreas $fullWorkbookPath)

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.ScreenUpdating = $false
    $excel.AutomationSecurity = 1

    $workbook = $excel.Workbooks.Open($fullWorkbookPath)
    Remove-ImportedVbaComponents $workbook
    Import-VbaSourceTree $workbook $root
    $workbook.Save()
    Export-VbaSnapshot $workbook (Join-Path (Split-Path $fullWorkbookPath) "VBA_All_Code.txt")
    Write-Output "VBA modules refreshed without changing worksheet data: $fullWorkbookPath"
}
finally {
    if ($workbook -ne $null) {
        $workbook.Close($false)
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) | Out-Null
    }
    if ($excel -ne $null) {
        $excel.Quit()
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
Restore-WorkbookPrintAreas $fullWorkbookPath $printAreas
