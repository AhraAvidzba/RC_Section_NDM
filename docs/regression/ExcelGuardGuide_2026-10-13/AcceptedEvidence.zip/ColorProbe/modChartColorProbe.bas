Attribute VB_Name = "modChartColorProbe"
Option Explicit

' ДЛЯ ДИАГНОСТИКИ: отдельная пустая книга, без кода и настроек NDM.
' Не активирует диаграмму и не переключает выделение после операции.
Public Sub NextProbeStep()
    Dim ws As Worksheet, co As ChartObject, ch As Chart
    Dim n As Long, label As String, item As Object, builder As Object
    Set ws = ThisWorkbook.Worksheets("Probe")
    n = CLng(ws.Range("H5").Value2) + 1
    On Error GoTo Failed
    If n >= 2 Then
        Set co = ws.ChartObjects(1)
        Set ch = co.Chart
    End If
    Select Case n
        Case 0
            label = "Пустой макрос: запись номера шага"
        Case 1
            label = "Создание обычной диаграммы"
            Set co = ws.ChartObjects.Add(30, 190, 620, 350)
        Case 2
            label = "Тип диаграммы: точечная XY"
            ch.ChartType = xlXYScatter
        Case 3
            label = "Добавление ряда данных"
            Set item = ch.SeriesCollection.NewSeries
            item.XValues = Array(1, 2, 3)
            item.Values = Array(2, 4, 3)
        Case 4
            label = "Удаление всех рядов данных"
            Do While ch.SeriesCollection.Count > 0
                ch.SeriesCollection(1).Delete
            Loop
        Case 5
            label = "Повторное присвоение типа XY"
            ch.ChartType = xlXYScatter
        Case 6
            label = "Оформление и размеры области построения"
            ch.HasLegend = False: ch.HasTitle = False
            ch.ChartArea.Format.Fill.ForeColor.RGB = RGB(255, 255, 255)
            ch.PlotArea.Format.Fill.ForeColor.RGB = RGB(255, 255, 255)
            ch.PlotArea.Left = 28: ch.PlotArea.Top = 36
            ch.PlotArea.Width = 400: ch.PlotArea.Height = 270
        Case 7
            label = "Масштаб и скрытие осей"
            ch.Axes(xlCategory).MinimumScale = 0
            ch.Axes(xlCategory).MaximumScale = 10
            ch.Axes(xlValue).MinimumScale = 0
            ch.Axes(xlValue).MaximumScale = 10
            ch.Axes(xlCategory).TickLabelPosition = xlNone
            ch.Axes(xlValue).TickLabelPosition = xlNone
        Case 8
            label = "Прямоугольник и круг внутри диаграммы"
            Set item = ch.Shapes.AddShape(msoShapeRectangle, 100, 100, 40, 30)
            Set item = ch.Shapes.AddShape(msoShapeOval, 150, 100, 20, 20)
        Case 9
            label = "Линия внутри диаграммы"
            Set item = ch.Shapes.AddLine(100, 130, 180, 150)
        Case 10
            label = "Произвольная фигура BuildFreeform"
            Set builder = ch.Shapes.BuildFreeform(msoEditingAuto, 100, 120)
            builder.AddNodes msoSegmentLine, msoEditingAuto, 180, 150
            builder.AddNodes msoSegmentLine, msoEditingAuto, 180, 155
            builder.AddNodes msoSegmentLine, msoEditingAuto, 100, 120
            Set item = builder.ConvertToShape
        Case 11
            label = "Создание пустой надписи AddTextbox"
            Set item = ch.Shapes.AddTextbox(msoTextOrientationHorizontal, 140, 60, 180, 30)
            item.Name = "ProbeText"
        Case 12
            label = "Запись текста через TextFrame.Characters"
            ch.Shapes("ProbeText").TextFrame.Characters.Text = "Annotation"
        Case 13
            label = "Шрифт, выравнивание и отступы надписи"
            Set item = ch.Shapes("ProbeText")
            item.TextFrame.Characters.Font.Size = 12
            item.TextFrame.Characters.Font.Color = RGB(0, 0, 0)
            item.TextFrame.Characters.Font.Bold = False
            item.TextFrame.Characters.Font.Italic = False
            item.TextFrame.HorizontalAlignment = xlCenter
            item.TextFrame.VerticalAlignment = xlCenter
            item.TextFrame.MarginLeft = 0: item.TextFrame.MarginRight = 0
            item.TextFrame.MarginTop = 0: item.TextFrame.MarginBottom = 0
            item.Line.Visible = False: item.Fill.Visible = False
        Case 14
            label = "Поворот и положение надписи"
            Set item = ch.Shapes("ProbeText")
            item.Rotation = 45: item.Left = 150: item.Top = 70
        Case 15
            label = "Удаление фигур внутри диаграммы"
            Do While ch.Shapes.Count > 0
                ch.Shapes(1).Delete
            Loop
        Case Else
            ws.Range("B5").Value2 = "Проверка завершена: шаги 0–15."
            Exit Sub
    End Select
    ws.Range("H5").Value2 = n
    ws.Range("B5").Value2 = "Шаг " & CStr(n) & ": " & label
    ws.Cells(n + 32, 2).Value2 = label
    Exit Sub
Failed:
    ws.Range("B5").Value2 = "Шаг " & CStr(n) & ": ошибка " & CStr(Err.Number) & " — " & Err.Description
End Sub
