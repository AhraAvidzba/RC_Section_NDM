Attribute VB_Name = "modActualPlotProbe"
Option Explicit

' ДЛЯ ДИАГНОСТИКИ: только отдельная копия книги, не рабочие исходники NDM.
Public SkipZOrder As Boolean
Private mInitialized As Boolean
Private mStage As Long
Private mReached As Long
Private mStageLabel As String
Private mZOrderCalls As Long
Private mZOrderErrors As String

Public Sub NextPlotProbeStage()
    If Not mInitialized Then mStage = -1: mInitialized = True
    mStage = mStage + 1
    If mStage > 9 Then
        ThisWorkbook.Worksheets("Расчет").Range("A1").Value2 = "Проверка завершена. Этапы 0–9."
        Exit Sub
    End If
    ExecuteProbe
End Sub

Public Sub FullPlotWithoutZOrder()
    mStage = 9
    SkipZOrder = True
    ExecuteProbe
End Sub

Private Sub ExecuteProbe()
    Dim savedRange As String, errorNumber As Long, description As String
    On Error GoTo Failed
    mReached = -1: mZOrderCalls = 0: mZOrderErrors = vbNullString
    savedRange = Application.ActiveWindow.RangeSelection.Address
    UpdateSectionPlotForWorkbook ThisWorkbook
    ThisWorkbook.Worksheets("Расчет").Range("A1").Value2 = "Этап " & CStr(mReached) & ": " & mStageLabel
    AppendProbeLog "stage=" & CStr(mReached) & "; label=" & mStageLabel & "; skipZOrder=" & CStr(SkipZOrder) & "; zOrderCalls=" & CStr(mZOrderCalls) & "; errors=" & mZOrderErrors & "; before=" & savedRange & "; after=" & Application.ActiveWindow.RangeSelection.Address & "; activeChart=" & TypeName(Application.ActiveChart)
    Exit Sub
Failed:
    errorNumber = Err.Number: description = Err.Description
    ThisWorkbook.Worksheets("Расчет").Range("A1").Value2 = "Ошибка этапа " & CStr(mStage) & ": " & CStr(errorNumber) & " — " & description
    AppendProbeLog "ERROR: " & CStr(errorNumber) & " — " & description
    Err.Raise errorNumber, "modActualPlotProbe", description
End Sub

Public Function StopAfterStage(ByVal number As Long, ByVal label As String) As Boolean
    mReached = number: mStageLabel = label
    StopAfterStage = (number >= mStage)
End Function

Public Sub RecordZOrder(ByVal errorNumber As Long, ByVal description As String)
    mZOrderCalls = mZOrderCalls + 1
    If errorNumber <> 0 Then mZOrderErrors = mZOrderErrors & CStr(errorNumber) & ": " & description & "; "
End Sub

Private Sub AppendProbeLog(ByVal text As String)
    Dim f As Integer: f = FreeFile
    Open ThisWorkbook.Path & "\ActualPlotProbe.txt" For Append As #f
    Print #f, Format$(Now, "yyyy-mm-dd hh:nn:ss") & " " & text
    Close #f
End Sub
