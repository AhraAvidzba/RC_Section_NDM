﻿$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$dir=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/PrepareChartProbe'
$source=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$target=Join-Path $dir 'NDM_PrepareOperations.xlsm'
Copy-Item -LiteralPath $source -Destination $target -Force
$sourceHash=(Get-FileHash -LiteralPath $source).Hash
$excel=New-Object -ComObject Excel.Application
try {
    $excel.DisplayAlerts=$false
    $excel.Visible=$false
    $excel.EnableEvents=$false
    $book=$excel.Workbooks.Open($target,0,$false)
    $plotter=$book.VBProject.VBComponents.Item('CSectionPlotter').CodeModule
    $plotter.DeleteLines(1,$plotter.CountOfLines)
    $plotter.AddFromString([IO.File]::ReadAllText((Join-Path $dir 'CSectionPlotter_Instrumented.txt'),[Text.Encoding]::UTF8))
    $component=$book.VBProject.VBComponents.Add(1)
    $component.Name='modActualPlotProbe'
    $component.CodeModule.AddFromString([IO.File]::ReadAllText((Join-Path $dir 'modActualPlotProbe.txt'),[Text.Encoding]::UTF8))
    $sheet=$book.Worksheets.Item('Расчет')
    $count=0
    foreach($shape in $sheet.Shapes) {
        if($shape.OnAction -match '(^|!)UpdateSectionPlot$') { $shape.OnAction='NextPlotProbeStage'; $count++ }
    }
    if($count -ne 1) { throw 'Expected one plot button.' }
    $co=$sheet.ChartObjects('chtNDMSectionPlot')
    $metadata=[ordered]@{ChartType=$co.Chart.ChartType;SeriesCount=$co.Chart.SeriesCollection().Count;ShapesCount=$co.Chart.Shapes.Count;SourceSHA256=$sourceHash}
    $metadata | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $dir 'Before.json') -Encoding UTF8
    $sheet.Activate()
    $sheet.Range('J15').Select()
    $book.Save()
    for($n=0;$n -le 9;$n++) {
        $excel.Run("'NDM_PrepareOperations.xlsm'!NextPlotProbeStage")
        Write-Output ([string]$sheet.Range('A1').Value2)
    }
} finally {
    if($book) { $book.Close($false) }
    $excel.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
}
if((Get-FileHash -LiteralPath $source).Hash -ne $sourceHash) { throw 'Production changed.' }
Write-Output 'PREPARE_OPERATIONS_READY: exact-call probe compiled and executed; production unchanged.'
