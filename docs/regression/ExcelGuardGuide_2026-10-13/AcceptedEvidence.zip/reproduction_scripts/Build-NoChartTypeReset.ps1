﻿$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$dir=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/ChartTypeCandidate'
New-Item -ItemType Directory -Path $dir -Force | Out-Null
$source=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/Release/Candidate.xlsm'
$baseline=Join-Path $dir 'NDM_LegacyChartType.xlsm'
$candidate=Join-Path $dir 'NDM_NoChartTypeReset.xlsm'
Copy-Item -LiteralPath $source -Destination $baseline -Force
Copy-Item -LiteralPath $source -Destination $candidate -Force
$plotSource=[IO.File]::ReadAllText((Join-Path $root 'src/Excel/CSectionPlotter.cls'),[Text.Encoding]::UTF8)
$plotSource=[regex]::Match($plotSource,'(?ms)^Option Explicit.*').Value
if([regex]::Matches($plotSource,'\.ChartType = XL_XY_SCATTER').Count -ne 1 -or $plotSource -match 'mChart\.ChartType =') {throw 'Chart type must be set only during creation.'}
[IO.File]::WriteAllText((Join-Path $dir 'CSectionPlotter_NoReset.txt'),$plotSource,[Text.Encoding]::UTF8)
$excel=New-Object -ComObject Excel.Application
try {
    $excel.Visible=$false
    $excel.DisplayAlerts=$false
    $excel.EnableEvents=$false
    $book=$excel.Workbooks.Open($candidate,0,$false)
    $module=$book.VBProject.VBComponents.Item('CSectionPlotter').CodeModule
    $module.DeleteLines(1,$module.CountOfLines)
    $module.AddFromString($plotSource)
    $excel.VBE.ActiveVBProject=$book.VBProject
    $compile=$excel.VBE.CommandBars.FindControl(1,578)
    if($compile.Enabled) {$compile.Execute()}
    if($compile.Enabled) {throw 'Candidate compilation failed.'}
    $book.Save()
    $book.Close($false)
    $book=$null
    $metadata=@()
    foreach($path in @($baseline,$candidate)) {
        $fileHash=(Get-FileHash -LiteralPath $path).Hash
        $book=$excel.Workbooks.Open($path,0,$false)
        $chart=$book.Worksheets.Item('Расчет').ChartObjects('chtNDMSectionPlot').Chart
        $beforeType=$chart.ChartType
        $excel.Run("'"+$book.Name+"'!UpdateSectionPlotForWorkbook",$book)
        $chart=$book.Worksheets.Item('Расчет').ChartObjects('chtNDMSectionPlot').Chart
        $imagePath=Join-Path $dir ([IO.Path]::GetFileNameWithoutExtension($path)+'.png')
        if(-not $chart.Export($imagePath,'PNG')) {throw 'Native chart export failed.'}
        $metadata+=[ordered]@{Workbook=$book.Name;SHA256=$fileHash;BeforeType=$beforeType;AfterType=$chart.ChartType;SeriesCount=$chart.SeriesCollection().Count;ShapesCount=$chart.Shapes.Count;ChartImage=$imagePath}
        $book.Close($false)
        $book=$null
    }
    $metadata | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $dir 'ChartComparison.json') -Encoding UTF8
    Write-Output ($metadata | ConvertTo-Json -Depth 4)
} finally {
    if($book) {$book.Close($false)}
    $excel.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
}
Write-Output 'PRIVATE_CHART_TYPE_CANDIDATE_READY: production source and workbook unchanged.'
