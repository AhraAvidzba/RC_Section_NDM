$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$dir=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/Release'
$before=Get-Content -LiteralPath (Join-Path $dir 'Before.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$preserve=Get-Content -LiteralPath (Join-Path $dir 'Preservation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$equality=Get-Content -LiteralPath (Join-Path $dir 'SourceEquality.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$help=Get-Content -LiteralPath (Join-Path $dir 'StandaloneHelp.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$tests=Get-Content -LiteralPath (Join-Path $dir 'FinalTargetedTests.txt') -Raw -Encoding UTF8
if(-not $preserve.AllPassed -or -not $equality.Passed -or $help.status -ne 'STANDALONE_HELP_PASS') {throw 'Candidate acceptance incomplete.'}
foreach($line in @('TOTAL_AUDIT03_GENERAL_PLOT: passed=3347; failed=0','TOTAL_AUDIT03_EXCEL_GUARD: passed=185; failed=0','TOTAL_EXCEL_GUARD_WORKFLOW: passed=8; failed=0','WATCHDOG_COMPLETED: exit=0; source unchanged=True')) {
    if(-not $tests.Contains($line)) {throw ('Missing accepted test result: '+$line)}
}
$candidate=Join-Path $dir 'Candidate.xlsm'
if((Get-FileHash -LiteralPath $candidate).Hash.ToLowerInvariant() -cne $preserve.CandidateSHA256) {throw 'Candidate changed after verification.'}
$published=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$allCode=Join-Path $root 'workbook/output/VBA_All_Code.txt'
$execution=Join-Path $root 'workbook/output/RC_Section_NDM_execution_report.txt'
if((Get-FileHash -LiteralPath $execution).Hash -cne $before.ExecutionReportSHA256) {throw 'User report changed; do not overwrite.'}
$native=[IO.File]::ReadAllText((Join-Path $dir 'NativeVBA.txt'),[Text.Encoding]::UTF8)
if($native -notmatch '(?m)^Workbook: Candidate.xlsm\r?$') {throw 'Unexpected export identity.'}
$native=$native.Replace('Workbook: Candidate.xlsm','Workbook: RC_Section_NDM.xlsm')
$utf8=New-Object Text.UTF8Encoding($true)
[byte[]]$bookBytes=[IO.File]::ReadAllBytes($candidate)
[byte[]]$codeBytes=$utf8.GetPreamble()+$utf8.GetBytes($native)
$bookStream=$null;$codeStream=$null
$digest=[Security.Cryptography.SHA256]::Create()
try {
    # Exclusive ownership avoids replacing an open workbook or a changed code dump.
    $bookStream=[IO.File]::Open($published,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $codeStream=[IO.File]::Open($allCode,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $actualBook=[BitConverter]::ToString($digest.ComputeHash($bookStream)).Replace('-','')
    $actualCode=[BitConverter]::ToString($digest.ComputeHash($codeStream)).Replace('-','')
    if($actualBook -cne $before.BeforeSHA256 -or $actualCode -cne $before.AllCodeSHA256) {throw 'Published inputs changed since snapshot.'}
    $bookStream.Position=0;$codeStream.Position=0
    $backup=[IO.File]::Create((Join-Path $dir 'AllCodeBeforePublication.txt'))
    try {$codeStream.CopyTo($backup)} finally {$backup.Dispose()}
    $bookStream.Position=0;$bookStream.Write($bookBytes,0,$bookBytes.Length);$bookStream.SetLength($bookBytes.Length);$bookStream.Flush($true)
    $codeStream.Position=0;$codeStream.Write($codeBytes,0,$codeBytes.Length);$codeStream.SetLength($codeBytes.Length);$codeStream.Flush($true)
} finally {
    if($codeStream) {$codeStream.Dispose()}
    if($bookStream) {$bookStream.Dispose()}
    $digest.Dispose()
}
if((Get-FileHash -LiteralPath $published).Hash.ToLowerInvariant() -cne $preserve.CandidateSHA256) {throw 'Published workbook differs from accepted candidate.'}
if((Get-FileHash -LiteralPath $execution).Hash -cne $before.ExecutionReportSHA256) {throw 'User execution report changed during publication.'}
[ordered]@{PublishedAt=(Get-Date -Format 'o');WorkbookSHA256=(Get-FileHash -LiteralPath $published).Hash;AllCodeSHA256=(Get-FileHash -LiteralPath $allCode).Hash;UserExecutionReportUnchanged=$true;BeforeWorkbookSHA256=$before.BeforeSHA256;ManualColourAcceptance='User confirmed three refreshes and a calculation preserve colours without selecting chart.';ReadbackPending=$true} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $dir 'Publication.json') -Encoding UTF8
Write-Output 'PUBLISHED_VERIFIED_PAIR: user data preserved; native readback remains.'
