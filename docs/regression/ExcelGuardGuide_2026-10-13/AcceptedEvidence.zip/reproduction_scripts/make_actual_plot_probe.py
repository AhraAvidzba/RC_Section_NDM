"""Инструментирование только диагностической копии штатного плоттера."""
from pathlib import Path
import re

directory = Path('docs/regression/ExcelGuardGuide_2026-10-13/ActualPlotProbe')
directory.mkdir(exist_ok=True)
source = Path('src/Excel/CSectionPlotter.cls').read_text(encoding='utf-8-sig')
source = source[source.index('Option Explicit'):]
start = source.index('Public Sub Draw(')
end = source.index('\nEnd Sub', start)
draw = source[start:end]
replacements = [
    ('    Set mChartObject = EnsureChart', '    If modActualPlotProbe.StopAfterStage(0, "Чтение данных и настроек") Then Exit Sub\n    Set mChartObject = EnsureChart'),
    ('    mElementShapeLayerEnabled =', '    If modActualPlotProbe.StopAfterStage(1, "Получение существующей диаграммы") Then Exit Sub\n    mElementShapeLayerEnabled ='),
    ('    ConfigureEqualScale data, settings', '    If modActualPlotProbe.StopAfterStage(2, "Тип диаграммы, удаление рядов, область построения") Then Exit Sub\n    ConfigureEqualScale data, settings'),
    ('    ClearGeneratedShapes', '    If modActualPlotProbe.StopAfterStage(3, "Масштаб и оформление осей") Then Exit Sub\n    ClearGeneratedShapes'),
    ('    AddElementSeries data', '    If modActualPlotProbe.StopAfterStage(4, "Удаление старых фигур") Then Exit Sub\n    AddElementSeries data'),
    ('    DrawShapeDecorations data', '    If modActualPlotProbe.StopAfterStage(5, "Бетон и арматура") Then Exit Sub\n    DrawShapeDecorations data'),
    ('    If data.GeometryOnly Then', '    If modActualPlotProbe.StopAfterStage(6, "Контур, размеры, обозначения арматуры") Then Exit Sub\n    If data.GeometryOnly Then'),
    ('    If mAxisLabelsEnabled Then DrawAxisNameLabels', '    If modActualPlotProbe.StopAfterStage(7, "Нейтральная линия, оси, точка нагрузки и легенды") Then Exit Sub\n    If mAxisLabelsEnabled Then DrawAxisNameLabels'),
    ('    DrawPlotTitleOverlay PlotTitleText(data)', '    If modActualPlotProbe.StopAfterStage(8, "Подписи осей") Then Exit Sub\n    DrawPlotTitleOverlay PlotTitleText(data)\n    Call modActualPlotProbe.StopAfterStage(9, "Заголовок: полное обновление завершено")'),
]
for old, new in replacements:
    if draw.count(old) != 1:
        raise ValueError('Non-unique instrumentation target: ' + old)
    draw = draw.replace(old, new)
source = source[:start] + draw + source[end:]
needle = '    shapeObject.ZOrder MSO_BRING_TO_FRONT'
assert source.count(needle) == 1
source = source.replace(needle, '    If modActualPlotProbe.SkipZOrder Then Exit Sub\n    Err.Clear\n' + needle + '\n    modActualPlotProbe.RecordZOrder Err.Number, Err.Description')
(directory / 'CSectionPlotter_Instrumented.txt').write_text(source, encoding='utf-8', newline='\r\n')
print('Prepared private plot-stage instrumentation; source plotter unchanged.')
