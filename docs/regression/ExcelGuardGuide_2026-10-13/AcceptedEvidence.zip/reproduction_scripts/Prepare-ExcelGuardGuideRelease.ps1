$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$relative='docs/regression/ExcelGuardGuide_2026-10-13/Release'
$dir=Join-Path $root $relative
if(Test-Path -LiteralPath $dir) { throw 'Release snapshot already exists; inspect before replacing.' }
New-Item -ItemType Directory -Path $dir | Out-Null
$production=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$beforeHash=(Get-FileHash -LiteralPath $production).Hash
foreach($name in @('Before.xlsm','LiveBefore.xlsm','Candidate.xlsm')) {
    Copy-Item -LiteralPath $production -Destination (Join-Path $dir $name)
}
$metadata=[ordered]@{BeforeSHA256=$beforeHash;AllCodeSHA256=(Get-FileHash -LiteralPath 'workbook/output/VBA_All_Code.txt').Hash;ExecutionReportSHA256=(Get-FileHash -LiteralPath 'workbook/output/RC_Section_NDM_execution_report.txt').Hash;PreparedAt=(Get-Date -Format 'o')}
$metadata | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $dir 'Before.json') -Encoding UTF8
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/build_workbook/Export-Audit03VbaSnapshot.ps1 -WorkbookPath "$relative/LiveBefore.xlsm" -OutputPath "$relative/LiveNative.txt"
if($LASTEXITCODE -ne 0) { throw 'Initial native snapshot failed.' }
& "$root/tools/build_workbook/Update-PrivateWorkbookCode.ps1" -WorkbookPath "$relative/Candidate.xlsm" -ModuleNames @('CExcelAppStateGuard','modWorkbookCalculation','modSectionRecipeSetup','modSectionRecipeApiGuide','modTestWorkbookInterface','CTestExcelApplicationState')
& "$root/tools/build_workbook/Update-RecipeAuthorGuide.ps1" -WorkbookPath "$relative/Candidate.xlsm"
& 'C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 tools/build_workbook/Restore-ExcelGuardGuideView.py $relative
if($LASTEXITCODE -ne 0) { throw 'View preservation failed.' }
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/build_workbook/Export-Audit03VbaSnapshot.ps1 -WorkbookPath "$relative/Candidate.xlsm" -OutputPath "$relative/NativeVBA.txt"
if($LASTEXITCODE -ne 0) { throw 'Candidate native snapshot failed.' }
if((Get-FileHash -LiteralPath $production).Hash -ne $beforeHash) { throw 'Production changed during private preparation.' }
Write-Output 'FRESH_RELEASE_PREPARED: current user data preserved; production unchanged.'
