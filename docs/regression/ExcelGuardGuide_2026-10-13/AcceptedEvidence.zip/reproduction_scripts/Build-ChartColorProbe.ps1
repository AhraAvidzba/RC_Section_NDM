﻿$ErrorActionPreference = 'Stop'
$dir = Join-Path (Get-Location) 'docs/regression/ExcelGuardGuide_2026-10-13/ColorProbe'
$excel = New-Object -ComObject Excel.Application
try {
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $book = $excel.Workbooks.Add()
    $sheet = $book.Worksheets.Item(1)
    $sheet.Name = 'Probe'
    $sheet.Range('B:H').ColumnWidth = 16
    $sheet.Range('B1:H1').Merge()
    $sheet.Range('B1').Value2 = 'Проверка подсветки формул после операций с диаграммой'
    $sheet.Range('B1').Font.Bold = $true
    $sheet.Range('B2').Value2 = 12
    $sheet.Range('C2').Value2 = 34
    $sheet.Range('D2').Formula = '=$B$2+$C$2'
    $sheet.Range('B2:D2').Font.Size = 18
    $sheet.Range('B2:D2').Interior.Color = 10092543
    $sheet.Range('2:2').RowHeight = 32
    $sheet.Range('B4:H4').Merge()
    $sheet.Range('B4').Value2 = 'После каждого шага: дважды щёлкните D2, проверьте цвета, нажмите Esc.'
    $sheet.Range('B5:G5').Merge()
    $sheet.Range('B5').Value2 = 'Сначала проверьте подсветку формулы в D2. Затем нажмите кнопку.'
    $sheet.Range('H5').Value2 = -1
    $sheet.Range('H5').NumberFormat = '0'
    $sheet.Range('B6:H6').Merge()
    $sheet.Range('B6').Value2 = 'Если цвета пропали — остановитесь и сообщите номер шага. Саму диаграмму не выделяйте.'
    $component = $book.VBProject.VBComponents.Add(1)
    $component.Name = 'modChartColorProbe'
    $source = [IO.File]::ReadAllText((Join-Path $dir 'modChartColorProbe.bas'), [Text.Encoding]::UTF8)
    $source = $source -replace '(?m)^Attribute VB_Name = .*\r?\n',''
    $component.CodeModule.AddFromString($source)
    $button = $sheet.Buttons().Add($sheet.Range('F2').Left, $sheet.Range('F2').Top, 190, 32)
    $button.Caption = 'Следующий шаг'
    $button.OnAction = 'NextProbeStep'
    $sheet.Range('D2').Select()
    $excel.ActiveWindow.Zoom = 110
    $path = Join-Path $dir 'ChartColorProbe.xlsm'
    $book.SaveAs($path, 52)
    $log = @()
    for($n=0; $n -le 15; $n++) {
        $excel.Run("'ChartColorProbe.xlsm'!NextProbeStep")
        $actual = [int]$sheet.Range('H5').Value2
        $message = [string]$sheet.Range('B5').Value2
        if($actual -ne $n) { throw $message }
        $log += $message
    }
    $log | Set-Content (Join-Path $dir 'Smoke.txt') -Encoding UTF8
    Write-Output ('SMOKE PASS: 16 isolated operations; formula colour remains a manual visual check. '+$path)
} finally {
    if ($book) { $book.Close($false) }
    $excel.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
}
