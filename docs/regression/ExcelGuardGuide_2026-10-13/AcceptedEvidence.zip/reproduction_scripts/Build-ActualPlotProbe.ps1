﻿$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
$dir = Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/ActualPlotProbe'
$source = Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$target = Join-Path $dir 'NDM_PlotStages.xlsm'
Copy-Item -LiteralPath $source -Destination $target -Force
$sourceHash = (Get-FileHash -LiteralPath $source).Hash
$excel = New-Object -ComObject Excel.Application
try {
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $book = $excel.Workbooks.Open($target, 0, $false)
    $plotter = $book.VBProject.VBComponents.Item('CSectionPlotter').CodeModule
    $body = [IO.File]::ReadAllText((Join-Path $dir 'CSectionPlotter_Instrumented.txt'), [Text.Encoding]::UTF8)
    $plotter.DeleteLines(1, $plotter.CountOfLines)
    $plotter.AddFromString($body)
    $component = $book.VBProject.VBComponents.Add(1)
    $component.Name = 'modActualPlotProbe'
    $body = [IO.File]::ReadAllText((Join-Path $dir 'modActualPlotProbe.bas'), [Text.Encoding]::UTF8) -replace '(?m)^Attribute VB_Name = .*\r?\n',''
    $component.CodeModule.AddFromString($body)
    $sheet = $book.Worksheets.Item('Расчет')
    $buttons = @()
    foreach($shape in $sheet.Shapes) {
        if($shape.OnAction -match '(^|!)UpdateSectionPlot$') {
            $shape.OnAction = 'NextPlotProbeStage'
            $buttons += $shape.Name
        }
    }
    if($buttons.Count -ne 1) { throw ('Expected one UpdateSectionPlot button: '+$buttons.Count) }
    $sheet.Activate()
    $sheet.Range('J15').Select()
    $book.Save()
    $book.SaveCopyAs((Join-Path $dir 'NDM_WithoutZOrder.xlsm'))
    Write-Output ('PROBE_READY: '+$target+'; buttons='+($buttons -join ','))
    for($n=0; $n -le 9; $n++) {
        $excel.Run("'NDM_PlotStages.xlsm'!NextPlotProbeStage")
        Write-Output ([string]$sheet.Range('A1').Value2)
    }
    $book.Close($false)
    $book = $excel.Workbooks.Open((Join-Path $dir 'NDM_WithoutZOrder.xlsm'), 0, $false)
    foreach($shape in $book.Worksheets.Item('Расчет').Shapes) {
        if($shape.OnAction -eq 'NextPlotProbeStage') { $shape.OnAction = 'FullPlotWithoutZOrder' }
    }
    $book.Save()
    $excel.Run("'NDM_WithoutZOrder.xlsm'!FullPlotWithoutZOrder")
    Write-Output ([string]$book.Worksheets.Item('Расчет').Range('A1').Value2)
} finally {
    if($book) { $book.Close($false) }
    $excel.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
}
if((Get-FileHash -LiteralPath $source).Hash -ne $sourceHash) { throw 'Production changed during probe preparation.' }
Write-Output 'SMOKE PASS: 10 actual plot stages and full plot without ZOrder; production unchanged.'
