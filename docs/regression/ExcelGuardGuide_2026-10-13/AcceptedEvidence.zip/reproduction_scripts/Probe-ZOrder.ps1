$ErrorActionPreference = 'Stop'
$dir = Join-Path (Get-Location) 'docs/regression/ExcelGuardGuide_2026-10-13/ColorProbe'
$excel = New-Object -ComObject Excel.Application
try {
    $excel.DisplayAlerts = $false
    $book = $excel.Workbooks.Add()
    $sheet = $book.Worksheets.Item(1)
    $sheet.Range('B2').Value2 = 1
    $sheet.Range('C2').Value2 = 2
    $sheet.Range('D2').Formula = '=$B$2+$C$2'
    $sheet.Range('D2').Select()
    $component = $book.VBProject.VBComponents.Add(1)
    $component.Name = 'modZOrderProbe'
    $component.CodeModule.AddFromString(@'
Option Explicit
Public Function ProbeZOrder() As String
    Dim co As Object, ch As Object, s As Object, result As String, n As Long
    Set co = ThisWorkbook.Worksheets(1).ChartObjects.Add(30, 100, 600, 350)
    Set ch = co.Chart: ch.ChartType = xlXYScatter
    For n = 1 To 3
        If n = 1 Then Set s = ch.Shapes.AddLine(100, 100, 160, 140)
        If n = 2 Then Set s = ch.Shapes.AddShape(msoShapeOval, 100, 100, 40, 30)
        If n = 3 Then Set s = ch.Shapes.AddTextbox(msoTextOrientationHorizontal, 100, 80, 180, 30)
        result = result & "BEFORE: shape=" & CStr(s.Type) & "; selection=" & TypeName(Application.Selection) & "; activeChart=" & TypeName(Application.ActiveChart) & vbCrLf
        On Error Resume Next
        Err.Clear
        s.ZOrder msoBringToFront
        result = result & "ZORDER: error=" & CStr(Err.Number) & "; description=" & Err.Description & "; selection=" & TypeName(Application.Selection) & "; activeChart=" & TypeName(Application.ActiveChart) & vbCrLf
        On Error GoTo 0
    Next n
    ProbeZOrder = result
End Function
'@)
    $result = $excel.Run('ProbeZOrder')
    $result | Set-Content (Join-Path $dir 'ZOrderRuntime.txt') -Encoding UTF8
    Write-Output $result
} finally {
    if ($book) { $book.Close($false) }
    $excel.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
}
