"""Разделяет установленный проблемный этап на точные вызовы Excel, только в копии."""
from pathlib import Path

directory = Path('docs/regression/ExcelGuardGuide_2026-10-13/PrepareChartProbe')
directory.mkdir(exist_ok=True)
source = Path('src/Excel/CSectionPlotter.cls').read_text(encoding='utf-8-sig')
source = source[source.index('Option Explicit'):]
start = source.index('Public Sub Draw(')
end = source.index('\nEnd Sub', start)
draw = source[start:end]
stop = draw.index('    ConfigureEqualScale data, settings')
draw = draw[:stop] + '    Exit Sub\n'
source = source[:start] + draw + source[end:]
start = source.index('Private Sub PrepareChart(')
end = source.index('\nEnd Sub', start)
prepare = source[start:end]
operations = [
    ('    mChart.ChartType = XL_XY_SCATTER', 'ChartType: повторное присвоение типа XY'),
    ('    mChart.HasLegend = False', 'HasLegend: скрытие легенды'),
    ('    mChart.HasTitle = False', 'HasTitle: скрытие штатного заголовка'),
    ('    Loop', 'Удаление всех рядов данных'),
    ('    mChart.ChartArea.Format.Fill.ForeColor.RGB = RGB(255, 255, 255)', 'Заливка всей диаграммы'),
    ('    mChart.PlotArea.Format.Fill.ForeColor.RGB = RGB(255, 255, 255)', 'Заливка области построения'),
    ('    mChart.PlotArea.Left = PLOT_FRAME_LEFT', 'PlotArea.Left'),
    ('    mChart.PlotArea.Top = PLOT_FRAME_TOP', 'PlotArea.Top'),
    ('    mChart.PlotArea.Width = StablePlotFrameWidth()', 'PlotArea.Width'),
    ('    mChart.PlotArea.Height = StablePlotFrameHeight()', 'PlotArea.Height'),
]
for index, (needle, label) in enumerate(operations):
    if prepare.count(needle) != 1:
        raise ValueError('Non-unique operation: ' + needle)
    prepare = prepare.replace(needle, needle + f'\n    If modActualPlotProbe.StopAfterStage({index}, "{label}") Then Exit Sub')
source = source[:start] + prepare + source[end:]
(directory / 'CSectionPlotter_Instrumented.txt').write_text(source, encoding='utf-8', newline='\r\n')
module = Path('docs/regression/ExcelGuardGuide_2026-10-13/ActualPlotProbe/modActualPlotProbe.bas').read_text(encoding='utf-8-sig')
module = module[module.index('Option Explicit'):]
(directory / 'modActualPlotProbe.txt').write_text(module, encoding='utf-8', newline='\r\n')
print('Prepared 10 exact PrepareChart operations; production source unchanged.')
