﻿$ErrorActionPreference='Stop'
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class AlertProbePid{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$excel=$null;$book=$null;$ownedId=0;$ticks=0
try {
 $excel=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][AlertProbePid]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id);$ownedId=[int]$id;$ticks=(Get-Process -Id $ownedId).StartTime.ToUniversalTime().Ticks
 $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.AutomationSecurity=1
 Write-Output ('BEFORE_OPEN: DisplayAlerts='+$excel.DisplayAlerts)
 $path=(Resolve-Path -LiteralPath 'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsFull_2026-10-16/Source/RC_Section_NDM.xlsm').Path
 $book=$excel.Workbooks.Open($path,0,$true)
 Write-Output ('AFTER_OPEN: DisplayAlerts='+$excel.DisplayAlerts)
 $excel.DisplayAlerts=$false
 $result=[string]$excel.Run("'RC_Section_NDM.xlsm'!modTestPolygonSpec.RunPolygonSpecTests")
 Write-Output ('AFTER_RUN: DisplayAlerts='+$excel.DisplayAlerts)
 Write-Output (($result -split "`r?`n" | Where-Object {$_ -like 'TOTAL*'}) -join '; ')
} finally {
 if($book){$book.Close($false)}
 if($excel){$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($ownedId){$owned=Get-Process -Id $ownedId -ErrorAction SilentlyContinue;if($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ticks){Stop-Process -Id $ownedId -Force -ErrorAction SilentlyContinue}}
}
