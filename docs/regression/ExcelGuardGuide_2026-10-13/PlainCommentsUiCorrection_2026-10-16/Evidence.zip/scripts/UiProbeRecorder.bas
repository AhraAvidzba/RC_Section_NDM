Option Explicit

Private Type TProbeDouble
    Value As Double
End Type
Private Type TProbeWords
    Low As Long
    High As Long
End Type

Public Sub SaveUiProbeArray(ByVal prefix As String, ByVal kind As String, ByRef values As Variant)
    Dim folder As String, stream As Object, row As Long, column As Long, text As String
    folder = ThisWorkbook.Path & "\Data"
    If Not CreateObject("Scripting.FileSystemObject").FolderExists(folder) Then MkDir folder
    Set stream = CreateObject("Scripting.FileSystemObject").CreateTextFile(folder & "\" & prefix & "." & kind & ".tsv", True, True)
    For row = 1 To UBound(values, 1)
        text = vbNullString
        For column = 1 To UBound(values, 2)
            If column > 1 Then text = text & vbTab
            text = text & ProbeCell(values(row, column))
        Next column
        stream.WriteLine text
    Next row
    stream.Close
End Sub

Private Function ProbeCell(ByVal value As Variant) As String
    Dim number As TProbeDouble, words As TProbeWords, text As String
    If IsEmpty(value) Then
        ProbeCell = "Z:"
    ElseIf IsError(value) Then
        ProbeCell = "E:cell"
    ElseIf VarType(value) = vbBoolean Then
        ProbeCell = "B:" & CStr(value)
    ElseIf VarType(value) <> vbString And IsNumeric(value) Then
        number.Value = CDbl(value): LSet words = number
        ProbeCell = "N:" & Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
    Else
        text = CStr(value)
        text = Replace(text, "\", "\\"): text = Replace(text, vbTab, "\t")
        text = Replace(text, vbCr, "\r"): text = Replace(text, vbLf, "\n")
        ProbeCell = "T:" & text
    End If
End Function
