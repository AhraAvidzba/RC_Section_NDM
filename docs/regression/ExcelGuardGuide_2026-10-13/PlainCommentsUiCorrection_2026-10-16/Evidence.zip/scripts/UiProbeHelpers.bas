Public Function ProbeValidationLists() As String
    Dim result As String
    result = "CalcMode=" & CStr(Application.Calculation) & vbCrLf
    result = result & "AutoCADCheck=" & CStr(AutoCADCombinationValidationIsDynamic()) & vbCrLf
    result = result & ProbeOneValidation("AutoCAD.Export.CombinationID")
    result = result & "PlotCheck=" & CStr(PlotLoadCaseValidationIsDynamic()) & vbCrLf
    result = result & ProbeOneValidation("Plot.LoadCase")
    ProbeValidationLists = result
End Function

Private Function ProbeOneValidation(ByVal key As String) As String
    On Error GoTo Failed
    Dim settings As Object, row As Long, formula As String, list As Object, result As String
    Set settings = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    For row = 2 To settings.Rows.Count
        If CStr(settings.Cells(row, 1).Value2) = key Then
            formula = CStr(settings.Cells(row, 2).Validation.Formula1)
            result = key & "; formula=" & formula & vbCrLf
            Set list = ThisWorkbook.Worksheets("Config").Range(Mid$(formula, 2))
            result = result & "BeforeCalculate=" & CStr(list.Cells(1, 1).Value2) & "|" & CStr(list.Cells(2, 1).Value2) & "; hasFormula=" & CStr(list.Cells(2, 1).HasFormula) & "; formula2=" & CStr(list.Cells(2, 1).Formula) & vbCrLf
            list.Calculate
            result = result & "AfterCalculate=" & CStr(list.Cells(1, 1).Value2) & "|" & CStr(list.Cells(2, 1).Value2) & vbCrLf
            ProbeOneValidation = result
            Exit Function
        End If
    Next row
    ProbeOneValidation = "NOT_FOUND:" & key & vbCrLf
    Exit Function
Failed:
    ProbeOneValidation = result & "ERROR: " & CStr(Err.Number) & "; " & Err.Description & vbCrLf
End Function

Private Sub ProbeDumpInputCase(ByVal prefix As String)
    Dim values As Variant, nm As Variant
    For Each nm In Array("rngSystemSettings", "rngCircleGeometry", "rngConcreteMaterialParameters", "rngSteelMaterialParameters")
        values = ThisWorkbook.Names.Item(CStr(nm)).RefersToRange.Value2: SaveUiProbeArray prefix, CStr(nm), values
    Next nm
    values = ResultTable("rngNDMSectionProperties"): SaveUiProbeArray prefix, "Properties", values
    values = ResultTable("rngNDMElementResults"): SaveUiProbeArray prefix, "Elements", values
    values = ResultTable("rngNDMSectionGeometry"): SaveUiProbeArray prefix, "Geometry", values
    values = ResultTable("rngNDMMaterialDiagrams"): SaveUiProbeArray prefix, "Diagrams", values
End Sub
