from pathlib import Path
import json,subprocess,importlib.util
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('audit',root/'tools/build_workbook/Audit-ClassComments.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
files=sorted(p for d in ('src','tests','docs/geometry_refactor/examples') for p in (root/d).rglob('*') if p.suffix.lower() in ('.bas','.cls'))
changed=[];working=0
for p in files:
 rel=p.relative_to(root).as_posix()
 old=subprocess.check_output(['git','show','7a9b53a:'+rel],cwd=root).decode('utf-8-sig')
 before,mb=a.code_units(old);after,ma=a.code_units(p.read_text(encoding='utf-8-sig'))
 assert before==after,(rel,'declarations')
 assert mb.keys()==ma.keys(),(rel,'method signatures')
 edits=sorted(name for kind,name in mb if mb[kind,name]!=ma[kind,name])
 if edits: changed.append({'path':rel,'procedures':edits})
 if p.relative_to(root).parts[0]=='src':
  assert not edits,p
  working+=1
assert len(files)==156,len(files)
assert changed==[
 {'path':'tests/modTestGeometry.bas','procedures':['assertinvalid']},
 {'path':'tests/modTestWorkbookInterface.bas','procedures':['autocadcombinationvalidationisdynamic','loadcasevalidationisdynamicforsetting','testaudit03inputunitconsumers']}],changed
out={'status':'PASS','baseRef':'7a9b53a','sourceComponents':len(files),'unchangedWorkingComponents':working,'changedTestMethods':changed,'declaredMethodsAndFieldsUnchanged':True,'solverTolerancesUnchanged':True}
path=root/'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsUiCorrection_2026-10-16/SourceCodeProof.json'
path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))
