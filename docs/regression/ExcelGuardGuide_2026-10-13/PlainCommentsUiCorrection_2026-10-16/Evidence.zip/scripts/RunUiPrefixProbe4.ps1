﻿$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$directory=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsAcceptance_2026-10-16/UiPrefixProbe4'
[void][IO.Directory]::CreateDirectory($directory)
$copy=Join-Path $directory 'RC_Section_NDM.xlsm'
if(Test-Path -LiteralPath $copy){throw 'Fresh probe path required.'}
Copy-Item -LiteralPath (Join-Path $root 'workbook/output/RC_Section_NDM.xlsm') -Destination $copy
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class UiProbePid{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
function Get-RawProperty($target,[string]$name) {
 $value=$target.GetType().InvokeMember($name,[Reflection.BindingFlags]::GetProperty,$null,$target,$null)
 if($null -eq $value){throw ('COM property null: '+$name)}
 return ,$value
}
$excel=$null;$book=$null;$ownedId=0;$ticks=0
try {
 $excel=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][UiProbePid]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id);$ownedId=[int]$id;$ticks=(Get-Process -Id $ownedId).StartTime.ToUniversalTime().Ticks
 $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.AutomationSecurity=1;$excel.EnableCancelKey=0
 Write-Output ('OWNED: '+$ownedId+'; '+$ticks)
 Write-Output 'OPEN_BEGIN'
 $book=$excel.Workbooks.Open($copy,0,$false);$excel.DisplayAlerts=$false
 Write-Output 'OPEN_END' 
 $project=Get-RawProperty $book 'VBProject'
 Write-Output ('PROJECT: '+$project.GetType().FullName)
 $components=Get-RawProperty $project 'VBComponents'
 Write-Output ('COMPONENTS: '+$components.GetType().FullName)
 $component=$components.Item('modTestWorkbookInterface')
 Write-Output ('COMPONENT: '+$component.Name)
 $module=Get-RawProperty $component 'CodeModule'
 Write-Output 'MODULE_READY'
 $start=$module.ProcStartLine('TestAudit03InputUnitConsumers',0);$count=$module.ProcCountLines('TestAudit03InputUnitConsumers',0)
 Write-Output ('PROC: '+$start+'; '+$count)
 $original=[string]$module.Lines($start,$count);$body=$original
 Write-Output 'BODY_READ'
 $body=$body.Replace('For Each shape In Array("Circle", "RectSet", "RoundedRectangle", "HollowRectangle")','For Each shape In Array("Circle")')
 $body=$body.Replace('For lengthIndex = 0 To 2','For lengthIndex = 0 To 0').Replace('For curvatureIndex = 0 To 1','For curvatureIndex = 0 To 0')
 $body=$body.Replace('caseCount = 120','caseCount = 5').Replace('caseCount = caseCount + 1',"ProbeDumpInputCase prefix`r`n                    caseCount = caseCount + 1")
 if($body -eq $original -or $body.Contains('caseCount = 120')){throw 'Probe patch mismatch.'}
 [IO.File]::WriteAllText((Join-Path $directory 'OriginalMethod.txt'),$original,[Text.Encoding]::UTF8)
 [IO.File]::WriteAllText((Join-Path $directory 'ProbeMethod.txt'),$body,[Text.Encoding]::UTF8)
 $module.DeleteLines($start,$count);$module.InsertLines($start,$body)
 $entryStart=$module.ProcStartLine('RunWorkbookInterfaceTests',0);$entryCount=$module.ProcCountLines('RunWorkbookInterfaceTests',0)
 $entry=[string]$module.Lines($entryStart,$entryCount)
 $needle='    TestAudit03InputUnitConsumers stats'
 if(-not $entry.Contains($needle)){throw 'Entry boundary missing'}
 $entry=$entry.Replace($needle,$needle+"`r`n    RunWorkbookInterfaceTests = stats.Report`r`n    Exit Function")
 $module.DeleteLines($entryStart,$entryCount);$module.InsertLines($entryStart,$entry)
 $module.AddFromString([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'UiProbeHelpers.bas'),[Text.Encoding]::UTF8))
 $recorder=$components.Add(1);$recorder.Name='modUiProbeRecorder';$recorder.CodeModule.AddFromString([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'UiProbeRecorder.bas'),[Text.Encoding]::UTF8))
 $excel.VBE.ActiveVBProject=$project;$compile=$excel.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Probe compile failed.'}
 $excel.DisplayAlerts=$false
 $settings=$book.Names.Item('rngSystemSettings').RefersToRange
 for($row=2;$row -le $settings.Rows.Count;$row++) {
  if([string]$settings.Cells.Item($row,1).Value2 -eq 'General.DiagramExtension'){$settings.Cells.Item($row,2).Value2='No'}
  if([string]$settings.Cells.Item($row,1).Value2 -eq 'Geometry.Type'){$settings.Cells.Item($row,2).Value2='RectSet'}
 }
 $result='Validation probed separately without changing prefix state' 
 [IO.File]::WriteAllText((Join-Path $directory 'Validation.txt'),$result,[Text.Encoding]::UTF8);Write-Output $result
 $excel.DisplayAlerts=$false
 $result=[string]$excel.Run("'RC_Section_NDM.xlsm'!modTestWorkbookInterface.RunWorkbookInterfaceTests")
 [IO.File]::WriteAllText((Join-Path $directory 'Units.txt'),$result,[Text.Encoding]::UTF8)
 Write-Output (($result -split "`r?`n" | Where-Object {$_ -match '^FAIL:|^TOTAL_|^RUNTIME ERROR'}) -join "`r`n")
} finally {
 if($book){try{$book.Close($false)}catch{Write-Output ('CLOSE_ERROR: '+$_.Exception.Message)}}
 if($excel){try{$excel.Quit()}catch{};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($ownedId){$owned=Get-Process -Id $ownedId -ErrorAction SilentlyContinue;if($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ticks){Stop-Process -Id $ownedId -Force -ErrorAction SilentlyContinue}}
}
