﻿$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$directory=Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsUiCorrection_2026-10-16/ValidationProbe'
[void][IO.Directory]::CreateDirectory($directory)
$copy=Join-Path $directory 'RC_Section_NDM.xlsm'
if(Test-Path -LiteralPath $copy){throw 'Fresh probe path required.'}
Copy-Item -LiteralPath (Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13/PlainCommentsUiCorrection_2026-10-16/Accepted.xlsm') -Destination $copy
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class UiProbePid{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
function Get-RawProperty($target,[string]$name) {
 $value=$target.GetType().InvokeMember($name,[Reflection.BindingFlags]::GetProperty,$null,$target,$null)
 if($null -eq $value){throw ('COM property null: '+$name)}
 return ,$value
}
$excel=$null;$book=$null;$ownedId=0;$ticks=0
try {
 $excel=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][UiProbePid]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id);$ownedId=[int]$id;$ticks=(Get-Process -Id $ownedId).StartTime.ToUniversalTime().Ticks
 $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.AutomationSecurity=1;$excel.EnableCancelKey=0
 Write-Output ('OWNED: '+$ownedId+'; '+$ticks)
 Write-Output 'OPEN_BEGIN'
 $book=$excel.Workbooks.Open($copy,0,$false);$excel.DisplayAlerts=$false
 Write-Output 'OPEN_END' 
 $project=Get-RawProperty $book 'VBProject'
 Write-Output ('PROJECT: '+$project.GetType().FullName)
 $components=Get-RawProperty $project 'VBComponents'
 Write-Output ('COMPONENTS: '+$components.GetType().FullName)
 $component=$components.Item('modTestWorkbookInterface')
 Write-Output ('COMPONENT: '+$component.Name)
 $module=Get-RawProperty $component 'CodeModule'
 Write-Output 'MODULE_READY'
 $helper=@"
Public Function ProbeChangedListFormulaValues() As String
    Dim settings As Object, loads As Object, list As Object, row As Long
    Dim cadOK As Boolean, plotOK As Boolean
    ThisWorkbook.Application.Calculation = xlCalculationManual
    Set settings = ThisWorkbook.Names.Item("rngSystemSettings").RefersToRange
    Set loads = ThisWorkbook.Names.Item("rngLoadCombinations").RefersToRange
    For row = 2 To settings.Rows.Count
        If CStr(settings.Cells(row, 1).Value2) = "Plot.LoadCase" Then
            Set list = ThisWorkbook.Worksheets("Config").Range(Mid(CStr(settings.Cells(row, 2).Validation.Formula1), 2))
            Exit For
        End If
    Next row
    loads.Cells(2, 1).Value2 = "BeforeAutoCAD": list.Calculate
    cadOK = AutoCADCombinationValidationIsDynamic()
    loads.Cells(2, 1).Value2 = "BeforePlot": list.Calculate
    plotOK = PlotLoadCaseValidationIsDynamic()
    ProbeChangedListFormulaValues = "AutoCAD=" & CStr(cadOK) & "; Plot=" & CStr(plotOK) & vbCrLf & _
        "TOTAL_CHANGED_LIST_FORMULAS: passed=" & CStr(Abs(CLng(cadOK)) + Abs(CLng(plotOK))) & "; failed=" & CStr(2 - Abs(CLng(cadOK)) - Abs(CLng(plotOK)))
End Function
"@
 $module.AddFromString($helper)
 $excel.VBE.ActiveVBProject=$project;$compile=$excel.VBE.CommandBars.FindControl(1,578);if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Probe compile failed.'}
 $excel.DisplayAlerts=$false
 $result=[string]$excel.Run("'RC_Section_NDM.xlsm'!modTestWorkbookInterface.ProbeChangedListFormulaValues")
 [IO.File]::WriteAllText((Join-Path $directory 'Validation.txt'),$result,[Text.Encoding]::UTF8)
 Write-Output $result
 if($result -notmatch 'passed=2; failed=0'){throw 'Changed list test failed'}
 $excel.DisplayAlerts=$false
} finally {
 if($book){try{$book.Close($false)}catch{Write-Output ('CLOSE_ERROR: '+$_.Exception.Message)}}
 if($excel){try{$excel.Quit()}catch{};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($ownedId){$owned=Get-Process -Id $ownedId -ErrorAction SilentlyContinue;if($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ticks){Stop-Process -Id $ownedId -Force -ErrorAction SilentlyContinue}}
}
