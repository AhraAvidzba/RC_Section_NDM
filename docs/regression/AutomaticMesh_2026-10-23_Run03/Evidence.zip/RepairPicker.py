"""Исправляет только 30 счётчиков выпадающего списка в частной копии."""
import copy
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E

directory = Path(__file__).resolve().parent
source = directory / 'RC_Section_NDM.xlsm'
backup = directory / 'BeforePickerFix.xlsm'
assert not backup.exists()
backup.write_bytes(source.read_bytes())
ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
m = '{' + ns['m'] + '}'
with ZipFile(source) as archive:
    info = archive.infolist()
    parts = {item.filename: archive.read(item.filename) for item in info}
sheet = E.fromstring(parts['xl/worksheets/sheet1.xml'])
strings = [''.join(item.itertext()) for item in E.fromstring(parts['xl/sharedStrings.xml'])]
lookup = {cell.get('r'): cell for cell in sheet.findall('.//m:sheetData/m:row/m:c', ns)}
for row in range(2, 32):
    cell = lookup['BS' + str(row)]
    cell.attrib.pop('t', None)
    for child in list(cell):
        cell.remove(child)
    E.SubElement(cell, m + 'f').text = 'IF(ROW()-1>ROWS(rngLoadCombinations)-1,"",INDEX(rngLoadCombinations,ROW(),1))'
    entry = lookup.get('H' + str(row + 69))
    value = entry.find('m:v', ns) if entry is not None else None
    if value is None or value.text is None:
        text = '0'
    elif entry.get('t') == 's':
        text = strings[int(value.text)]
        cell.set('t', 'str')
    else:
        text = value.text
        if entry.get('t'):
            cell.set('t', entry.get('t'))
    E.SubElement(cell, m + 'v').text = text
parts['xl/worksheets/sheet1.xml'] = E.tostring(sheet, encoding='UTF-8', xml_declaration=True, standalone=True)
target = directory / 'PickerFixed.xlsm'
with ZipFile(target, 'w') as archive:
    for item in info:
        archive.writestr(item, parts[item.filename])
with ZipFile(backup) as old, ZipFile(target) as new:
    changed = [name for name in old.namelist() if old.read(name) != new.read(name)]
assert changed == ['xl/worksheets/sheet1.xml']
source.write_bytes(target.read_bytes())
receipt = {'Status': 'PASS', 'ChangedParts': changed, 'Cells': 'Config!BS2:BS31',
           'BeforeSHA256': hashlib.sha256(backup.read_bytes()).hexdigest().upper(),
           'AfterSHA256': hashlib.sha256(source.read_bytes()).hexdigest().upper()}
(directory / 'PickerRepair.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
