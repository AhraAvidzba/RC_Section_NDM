$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot '../../../tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath 'docs/regression/AutomaticMesh_2026-10-23_Run03/RC_Section_NDM.xlsm' -ModuleNames @('CSystemSettingsReader','modTestContourMesh')
