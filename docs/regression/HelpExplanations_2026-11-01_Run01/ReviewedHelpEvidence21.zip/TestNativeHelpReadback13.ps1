﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет сохранённую книгу readonly и делает PDF всей справки без буфера обмена и без расчёта.
param([Parameter(Mandatory=$true)][string]$WorkbookPath,[Parameter(Mandatory=$true)][string]$OutputDirectory,[switch]$CaptureHelp)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
if(Test-Path -LiteralPath $OutputDirectory){throw 'Fresh native report directory required'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$source=(Resolve-Path -LiteralPath $WorkbookPath).Path;$before=(Get-FileHash -LiteralPath $source).Hash
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve insufficient'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMHelpReadOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMHelpReadOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o');WorkbookSHA256=$before}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($source,0,$true);if(-not $book.ReadOnly){throw 'Readonly required'}
 $sheet=$book.Worksheets.Item('Справка');$last=[int]$sheet.Cells.Find('*',$sheet.Cells.Item(1,1),-4123,2,1,2,$false).Row
 $data=$sheet.Range("A1:F$last").Value2;$rows=@();$headings=@{}
 for($row=1;$row -le $last;$row++){
  $values=@();for($column=1;$column -le 6;$column++){$values+=,[string]$data[$row,$column]}
  if(@($values|Where-Object {$_}).Count){$rows+=,[ordered]@{Row=$row;Values=$values}}
  if([string]$data[$row,1]){$headings[[string]$data[$row,1]]=$row}
 }
 $required=@('Расчет ширины раскрытия нормальных трещин','Расчет продольного изгиба и устойчивости','Справка по результатам расчета листа Results','СП 63: расчет ширины нормальных трещин','СП 35: расчет ширины нормальных трещин','СП 63: расчёт продольного изгиба и устойчивости','СП 35: расчёт продольного изгиба и устойчивости')
 foreach($title in $required){if(-not $headings.ContainsKey($title)){throw ('Missing Help heading '+$title)}}
 $crack=[int]$headings[$required[0]];$stability=[int]$headings[$required[1]];$results=[int]$headings[$required[2]]
 if(-not ($crack -lt $headings[$required[3]] -and $headings[$required[3]] -lt $headings[$required[4]] -and $headings[$required[4]] -lt $stability)){throw 'Crack subchapters mixed'}
 if(-not ($stability -lt $headings[$required[5]] -and $headings[$required[5]] -lt $headings[$required[6]] -and $headings[$required[6]] -lt $results)){throw 'Stability subchapters mixed'}
 foreach($title in $required[3..6]){$cell=$sheet.Cells.Item($headings[$title],1);if(-not $cell.Font.Bold -or $cell.Font.Size -ne 15){throw ('Wrong subchapter style '+$title)}}
 $longTitle='Продольные трещины: общая проверка по СП 35'
 if(-not $headings.ContainsKey($longTitle) -or -not ($headings[$required[4]] -lt $headings[$longTitle] -and $headings[$longTitle] -lt $stability)){throw 'Longitudinal checks mixed into one normal-crack code'}
 if(@($rows|Where-Object {($_.Values -join ' ') -match 'Результаты элементов и индекс защищены от'}).Count){throw 'Obsolete automatic protection claim'}
 $pictures=@()
 foreach($shape in $sheet.Shapes){
  $top=[int]$shape.TopLeftCell.Row;$height=[double]$sheet.Rows.Item($top).RowHeight
  if($shape.Height -le 0 -or $shape.Width -le 0 -or $shape.Height -gt $height+0.5){throw ('Invalid formula bounds '+$shape.Name)}
  $pictures+=,[ordered]@{Name=$shape.Name;Row=$top;Left=$shape.Left;Top=$shape.Top;Width=$shape.Width;Height=$shape.Height;RowHeight=$height;AlternativeText=$shape.AlternativeText}
 }
 if($pictures.Count -ne 80){throw ('Unexpected Help picture inventory '+$pictures.Count)}
 # Каждая картинка должна сопровождаться собственной расшифровкой уже в следующей строке.
 $catalogRoot='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM/tools/build_workbook'
 $definitions=@{};foreach($definition in (Get-Content (Join-Path $catalogRoot 'HelpFormulaExplanations.json') -Raw -Encoding UTF8|ConvertFrom-Json)){$definitions[$definition.Caption.Trim()]=$definition.Text}
 $local=@()
 foreach($picture in $pictures){
  $caption=([string]$picture.AlternativeText).Trim();$expectedText=[string]$definitions[$caption]
  if(-not $expectedText){throw ('Missing glossary '+$caption)}
  $actual='';$rr=[int]$picture.Row+1
  while($rr -le $last -and $actual.Length -lt $expectedText.Length){
   $part=[string]$data[$rr,1]
   if(-not $part){throw ('Glossary absent immediately after '+$picture.Name)}
   if($actual){$actual+=' '};$actual+=$part;$rr++
  }
  if($actual -cne $expectedText){throw ('Local glossary mismatch '+$picture.Name)}
  $local+=,[ordered]@{Picture=$picture.Name;Row=$picture.Row;GlossaryFirstRow=([int]$picture.Row+1);Text=$actual}
 }
 $lengthTitle='Геометрическая длина, расчётные длины и случайный эксцентриситет'
 if(-not ($headings[$lengthTitle] -gt $stability -and $headings[$lengthTitle] -lt $headings[$required[5]])){throw 'Length input explanation too late'}
 if(@($rows|Where-Object {$_.Values -ccontains 'Варианты LoadPath'}).Count -ne 1){throw 'LoadPath comparison table absent'}
 $local|ConvertTo-Json -Depth 6|Set-Content (Join-Path $OutputDirectory 'LocalDefinitions.json') -Encoding UTF8

 $links=@()
 foreach($ws in $book.Worksheets){foreach($link in $ws.Hyperlinks){
  $location=[string]$link.SubAddress
  if($location -match "^'?Справка'?!([A-Z]+)([0-9]+)$"){
   $target=$sheet.Range($Matches[1]+$Matches[2]);$text=[string]$target.MergeArea.Cells.Item(1,1).Value2
   if(-not $text){throw ('Empty Help link '+$ws.Name+' '+$location)}
   $links+=,[ordered]@{Sheet=$ws.Name;Address=$link.Range.Address();Target=$location;Text=$text}
  }
 }}
 $output=$book.Worksheets.Item('Results');$index=$book.Names.Item('rngNDMElementResultIndex').RefersToRange
 $expected=@('IndexKind','RunID','TableRows','TableColumns','FirstRow','RowCount','LoadCase','ProfileId','StateType')
 for($i=0;$i -lt 9;$i++){if([string]$index.Offset(0,$i).Value2 -cne $expected[$i]){throw 'Index compact header mismatch'}}
 if($app.WorksheetFunction.CountA($index.Offset(0,9).Resize(1,5)) -ne 0){throw 'Unused index headers remain'}
 if($output.ProtectContents){throw 'Automatic Results protection remains'}
 if(-not [bool]$index.Resize(1,9).Locked){throw 'Index cells not marked for optional protection'}
 $geometry=$book.Names.Item('rngNDMSectionGeometry').RefersToRange
 $bar=$output.Cells.Item($geometry.Row-2,$index.Column+8)
 if($bar.Interior.Color -ne 15652797){throw 'Snapshot band stops before index end'}
 $export=New-Object Text.StringBuilder
 [void]$export.AppendLine('VBA PROJECT EXPORT');[void]$export.AppendLine('Workbook: '+$book.Name);[void]$export.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
 for($i=1;$i -le $book.VBProject.VBComponents.Count;$i++){
  $component=$book.VBProject.VBComponents.Item($i);$count=$component.CodeModule.CountOfLines
  [void]$export.AppendLine('='*100);[void]$export.AppendLine('COMPONENT: '+$component.Name);[void]$export.AppendLine('TYPE: '+$component.Type);[void]$export.AppendLine('LINES: '+$count);[void]$export.AppendLine('='*100)
  if($count){[void]$export.AppendLine($component.CodeModule.Lines(1,$count))};[void]$export.AppendLine()
 }
 [IO.File]::WriteAllText((Join-Path $OutputDirectory 'VBA_All_Code.txt'),$export.ToString(),[Text.UTF8Encoding]::new($true))
 $rows|ConvertTo-Json -Depth 7|Set-Content (Join-Path $OutputDirectory 'AllHelpText.json') -Encoding UTF8
 $pictures|ConvertTo-Json -Depth 6|Set-Content (Join-Path $OutputDirectory 'Pictures.json') -Encoding UTF8
 $links|ConvertTo-Json -Depth 6|Set-Content (Join-Path $OutputDirectory 'Links.json') -Encoding UTF8
 if($CaptureHelp){
  $sheet.Rows.Hidden=$false;$sheet.Columns.Hidden=$false # Для PDF раскрываем также методические outline-группы; книгу не сохраняем.
  $sheet.PageSetup.PrintArea=$sheet.Range("A1:F$last").Address();$sheet.PageSetup.PaperSize=8;$sheet.PageSetup.Orientation=2
  $sheet.PageSetup.Zoom=$false;$sheet.PageSetup.FitToPagesWide=1;$sheet.PageSetup.FitToPagesTall=$false
  $sheet.PageSetup.LeftMargin=12;$sheet.PageSetup.RightMargin=12;$sheet.PageSetup.TopMargin=18;$sheet.PageSetup.BottomMargin=18
  $sheet.ExportAsFixedFormat(0,(Join-Path $OutputDirectory 'WholeHelp.pdf'),0,$false,$false)
 }
 [ordered]@{Status='PASS_SAVED_READONLY_FULL_HELP_AND_80_LOCAL_DEFINITIONS';WorkbookSHA256=$before;Components=$book.VBProject.VBComponents.Count;Pictures=$pictures.Count;HelpLastRow=$last;Links=$links.Count;ProtectionEnabled=$false;IndexColumns=9;BandLastCell=$bar.Address();SeparateCrackAndStabilityCodes=$true;SourceUnchanged=$true}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'Native.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;$sheet=$null;$output=$null;$index=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){if($own -gt 0 -and (Get-Process -Id $own -ErrorAction Stop).StartTime.ToUniversalTime().Ticks -eq $ticks){$app.Quit();$quit=$true};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'Quit.json') -Encoding UTF8
}
if((Get-FileHash -LiteralPath $source).Hash -ne $before){throw 'Readonly inspection changed workbook'}
Write-Output 'SAVED_HELP_AND_RESULTS_READBACK_PASS'
