"""ДЛЯ ТЕСТОВ. Полностью сверяет нативный текст справки и сохранность принятой области изменения."""
from pathlib import Path
import json,hashlib,collections,re
from pypdf import PdfReader
P=Path(__file__).resolve().parent;R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
cat=load(R/'tools/build_workbook/HelpSettingsDescriptions.json');refs=load(R/'tools/build_workbook/NormativeHelpReferences.json')
rows=load(P/'NativeClean18/AllHelpText.json');alltexts=[v for row in rows for v in row['Values'] if v];texts=set(alltexts)
missing=[];count=0
for item in cat:
 for line in item['Lines']:
  expected=refs[item['Key']] if line=='{{NormativeReference}}' else line
  if expected not in texts:missing.append((item['Key'],expected))
  count+=1
 for table in item.get('Tables',[]):
  assert table['Title'] in texts
  for h in table['Headers']:assert h in texts,h
  for row in table['Rows']:
   for v in row:assert v in texts,v
assert not missing,missing
assert not re.search(r'случайн.{0,18}плеч', ' '.join(alltexts),re.I), 'Wrong accidental-eccentricity terminology'
mock=load(P/'MockGuideRecords05.json');merged=' '.join(alltexts);norm=lambda s:re.sub(r'\s+',' ',s).strip()
for item in mock:
 if item['Kind'] in ('Title','Paragraph'):assert norm(item['Text']) in norm(merged),('Missing methodology text',item['Text'])
before=load(P/'Before/Pictures.json');after=load(P/'NativeClean18/Pictures.json')
assert collections.Counter(p['AlternativeText'].strip() for p in before)==collections.Counter(p['AlternativeText'].strip() for p in after)
for directory in ['NativeClean18','MainNative18','HeavyNative18']:
 d=P/directory;n=load(d/'Native.json');assert n['Status'].startswith('PASS_') and n['Pictures']==80 and n['Links']==155 and n['Components']==187
 assert load(d/'SourceEquality.json')['Status']=='PASS'
 assert load(d/'AllHelpText.json')==rows,('Help text differs',directory)
 assert len(load(d/'LocalDefinitions.json'))==80
fence=load(P/'RuntimeFence07.json');assert all(sha(R/k)==v for k,v in fence.items())
assert len(PdfReader(P/'NativeClean18/WholeHelp.pdf').pages)==39
visual=dict(Status='PASS_VISUAL_LAYOUT_REVIEW',AllPages=list(range(1,40)),ContactSheetsActuallyViewed=list(range(1,11)),FullSizeDetailsActuallyViewed=[10,13],PDFSHA256=sha(P/'NativeClean18/WholeHelp.pdf'),Findings='Текст и формулы читаемы; наложений и обрезания нет; рамка до правой границы. Отдельные формулы и следующие пояснения могут разделяться границей страницы PDF; в книге они идут соседними строками.',ImagesDeliveredToUser=False)
(P/'VisualReview18.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2),encoding='utf-8')
old=load(P/'Before/SettingsCatalog.json');old={x['Key']:x for x in old}
changed=sum([norm(' '.join(x['Lines']))!=norm(' '.join(y for y in old[x['Key']]['Lines'] if y.strip())) for x in cat])
review=dict(Status='PASS_COMPLETE_HELP_SOURCE_NATIVE_AND_VISUAL_REVIEW',HelpBlocksReviewed=152,NativeCatalogParagraphsVerified=count,NativeFullTextRead=True,FormulaOccurrences=76,SchemeOccurrences=4,LocalDefinitionsVerified=80,NativeBooks=3,ComponentsPerBook=187,LinksPerBook=155,PDFPagesActuallyReviewed=39,RuntimeSourceFilesUnchanged=len(fence),FormulaCaptionsPreserved=True,InputLengthBeforeCodes=True,SP35ProfileLimitationDisclosed=True,UserDataAndResultsPreserved=True,RecalculationPerformed=False,FullCalculationAcceptanceClaim=False)
(P/'FinalReview18.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
