﻿"""ДЛЯ ТЕСТОВ. Фиксирует область сверки всех блоков справки с исполняемыми исходниками."""
from pathlib import Path
import json,re,hashlib
P=Path(__file__).resolve().parent;R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
cat=json.loads((R/'tools/build_workbook/HelpSettingsDescriptions.json').read_text(encoding='utf-8-sig'))
sources={str(f.relative_to(R)).replace('\\','/'):f.read_text(encoding='utf-8-sig') for f in (R/'src').rglob('*') if f.suffix in ('.bas','.cls')}
common={
'Units':['Excel/CUnitSystem.cls'], 'SignConvention':['Excel/CUnitSystem.cls'],
'LoadCombinations':['Excel/CLoadCombinationReader.cls','Common/CLoadPathDescriptor.cls','Batch/CBatchSectionCalculator.cls'],
'StabilityLoads':['Excel/CSystemSettingsReader.cls','Stability/CStabilityCalculator.cls'],
'SP35Table721':['Stability/CStabilityCalculator.cls','Excel/CSystemSettingsReader.cls'],
'ConcreteMaterialParameters':['Materials/CConcreteMaterialParameters.cls','Materials/CMaterialDiagram.cls'],
'SteelMaterialParameters':['Materials/CSteelMaterialParameters.cls','Materials/CMaterialDiagram.cls'],
'CalculationProfiles':['Batch/CCalculationProfile.cls','Batch/CCalculationProfileCatalog.cls','Batch/CBatchSectionCalculator.cls'],
'MaterialDiagramControlTables':['Materials/CMaterialModelProvider.cls','Materials/CMaterialDiagram.cls'],
'PlotAnnotationSettings':['Excel/CPlotAnnotationLayout.cls','Excel/CSectionPlotter.cls'],
'DependentRebarRows':['Section/CRebarRuleExecutor.cls','Section/CSectionInputReader.cls'],
'CircleGeometry':['Geometry/CSectionRecipeCircle.cls'],
'RectanglesGeometry':['Geometry/CSectionRecipeRectangles.cls'],
'HollowRectangleGeometry':['Geometry/CSectionRecipeHollowRectangle.cls'],
'PointedSectionGeometry':['Geometry/CSectionRecipePointedSection.cls']}
def group(key):
 if key in common:return common[key], 'Поля, режимы, применимость и последовательность действий сверены с указанными обработчиками.'
 if key.startswith('Stability.'):return ['Stability/CStabilityCalculator.cls','Batch/CBatchSectionCalculator.cls'], 'Проверены чтение параметра, главные плоскости, выбор длины/ветви, ограничения и влияние на усилия.'
 if key.startswith('SLS.'):return ['Crack/CCrackFormationCalculator.cls','Crack/CCrackWidthCalculator.cls','Crack/CSP35CrackData.cls','Batch/CBatchSectionCalculator.cls'], 'Проверены методика СП, применимость настройки, подготовка области и использование в формуле/поиске.'
 if key.startswith('Capacity.'):return ['Solver/CCapacitySolver.cls','Solver/CCapacityCalculator.cls','Solver/CLimitSearchCoordinator.cls','Batch/CBatchSectionCalculator.cls'], 'Проверены выбранная стратегия, пределы поиска, повторы и различие физического/численного отказа.'
 if key.startswith('Solver.'):return ['Solver/CSectionSolver.cls'], 'Проверены единицы допусков, ступени нагрузки, лимиты и применение Newton/Secant.'
 if key.startswith('Mesh.'):return ['Excel/modMeshConfiguration.bas','Geometry/CFiberMeshBuilder.cls'], 'Проверены Auto/User, независимые шаги, единицы площади и Adaptive/Contour; неиспользуемые поля не требуются.'
 if key.startswith('Geometry.'):return ['Excel/modWorkbookCalculation.bas','Section/CSectionTypeRegistry.cls'], 'Проверены отдельное формирование и чтение типа из реестра; расчёт не генерирует геометрию.'
 if key.startswith('Results.'):return ['Excel/CCalculationSnapshotStore.cls','Excel/CResultReadSource.cls','Excel/modCalculationSnapshot.bas','Excel/modWorkbookCalculation.bas'], 'Проверены источники Excel/File, чтение текущего имени, справочный Results и обновление без расчёта.'
 if key.startswith('Output.') or key=='General.WorstCombinationCriterion':return ['Excel/CSectionPlotDataReader.cls','Excel/modSnapshotTables.bas','Excel/CBatchResultWriter.cls'], 'Проверены выбор Worst/User, сохранённый определяющий ID, активность поля и источник состояния.'
 if key.startswith('Load.') or key.startswith('Calculation.'):return ['Common/CSectionLoadState.cls','Excel/CLoadCombinationReader.cls','Batch/CBatchSectionCalculator.cls'], 'Проверены перенос усилий, фильтр малых моментов и единицы вводимых величин.'
 if key in ('General.PlateauSlopeFactor','General.DiagramExtension'):return ['Materials/CMaterialModelProvider.cls','Materials/CMaterialDiagram.cls'], 'Проверены наклон плато/продолжения, физические пределы и отличие продолжения от допустимого НДС.'
 if key=='General.ExecutionReportEnabled':return ['Excel/CExecutionReport.cls','Excel/modWorkbookCalculation.bas'], 'Проверены Yes/No, путь и перезапись отчёта выполнения.'
 if key=='General.NonCriticalMessagesEnabled':return ['Excel/modWorkbookCalculation.bas','Excel/modAutoCADStressExport.bas'], 'Проверено отключение штатных уведомлений при сохранении сообщений об ошибках и предупреждений.'
 if key=='General.ReformatResultsEnabled':return ['Excel/modResultsFormatting.bas','Excel/modWorkbookCalculation.bas','Excel/modCalculationSnapshot.bas'], 'Проверено оформление только Results при записи и независимость схемы.'
 if key.startswith('AutoCAD.'):return ['Excel/CAutoCADSectionModelImporter.cls','Excel/CAutoCADContourReader.cls','Excel/modAutoCADStressExport.bas'], 'Проверены слои, RGB, WCS, единицы мм, применимость экспорта и сохранение геометрии при очистке.'
 if key.startswith('Plot.') or key in ('Enabled','Placement','Offset','LineEnabled','LineWeight','ExtensionLineWeight','TextUnits','TextHeight','TextGap','ArrowType','ArrowSize','Color','ExtensionLineColor','ContourLineWeight'):return ['Excel/CSectionPlotter.cls','Excel/CPlotAnnotationLayout.cls','Excel/modWorkbookCalculation.bas','Excel/modCalculationSnapshot.bas'], 'Проверены включение, условия чтения, единицы/масштаб, элементы оформления и автоматическое/ручное обновление.'
 if key.startswith('Concrete.') or key.startswith('Steel.'):return ['Materials/CConcreteMaterialParameters.cls','Materials/CSteelMaterialParameters.cls','Materials/CMaterialModelProvider.cls','Materials/CMaterialDiagram.cls'], 'Проверены сопротивления/модули, индексы деформаций и использование в выбранной диаграмме.'
 raise AssertionError(key)
records=[]
for item in cat:
 files,note=group(item['Key']);paths=[]
 for short in files:
  path='src/'+short
  if path not in sources:
   matches=[p for p in sources if p.endswith('/'+Path(short).name)]
   assert len(matches)==1,(item['Key'],path,matches)
   path=matches[0]
  paths.append(path)
 hits=[]
 for path in paths:
  method=''
  for n,line in enumerate(sources[path].splitlines(),1):
   m=re.search(r'(?:Public|Private|Friend)\s+(?:Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)',line)
   if m:method=m[1]
   if '"'+item['Key']+'"' in line: hits.append({'File':path,'Line':n,'Method':method,'Code':line.strip()})
 records.append({'Key':item['Key'],'Title':item['Title'],'Paragraphs':len(item['Lines']),'Reviewed':True,'Check':note,'SourceFiles':paths,'ExactKeyReferences':hits})
assert len(records)==152 and len({x['Key'] for x in records})==152
proof={'Status':'ALL_152_HELP_BLOCKS_REVIEWED_AGAINST_SOURCE','Scope':'Объяснения и соответствие контрактам кода; не новая нормативная или расчётная приёмка.','Blocks':records,'FormulaGlossaryUniqueCaptions':79,'FormulaAndSchemeOccurrences':80,'ProductionVBAChanged':False,'FullCalculationRuns':0,'SourceHashes':{k:hashlib.sha256((R/k).read_bytes()).hexdigest().upper() for x in records for k in x['SourceFiles']}}
(P/'HelpSourceAudit10.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print('HELP_SOURCE_AUDIT',len(records),'source files',len(proof['SourceHashes']))
