# ==========================================================================
# ДЛЯ ТЕСТОВ: публикует два проверенных VBA-пакета и настоящий native AllCode.
# Проверяет исходные hashes; не заменяет данные пользователя или исходные FAIL.
# ==========================================================================
param([string]$Packages='RecoveryPackages01',[string]$Native='RecoveryNative01',[string]$Build='RecoveryFreshBuild01',[string]$Directed='RecoveryDirected01')
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
foreach($name in @($Packages,$Native,$Build,$Directed)){if($name -cnotmatch '^Recovery[A-Za-z0-9]+$'){throw 'Own recovery directory required'}}
$package=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Packages+'/PackageProof.json')) -Raw -Encoding UTF8|ConvertFrom-Json
$nativeReview=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Native+'/ExactNativeReview.json')) -Raw -Encoding UTF8|ConvertFrom-Json
$watch=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Native+'.Watchdog/Completion.json')) -Raw -Encoding UTF8|ConvertFrom-Json
$directedAcceptance=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Directed+'/Acceptance.json')) -Raw -Encoding UTF8|ConvertFrom-Json
$transfer=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Build+'/Transfer.json')) -Raw -Encoding UTF8|ConvertFrom-Json
$request=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'LaunchRequest.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $nativeReview.Passed -or $nativeReview.ComponentsEachBook -ne181 -or $nativeReview.UnchangedNativeComponents -ne177 -or -not $nativeReview.BothNativeBodiesExactlyEqual -or $nativeReview.ExactDoubleProofUsesG15){throw 'Exact native181 and unchanged177 proof required'}
if(-not $watch.Passed -or $watch.Timeout -or $watch.OrdinaryForceKilled -or $watch.Excel.State -cne'Absent' -or $watch.Worker.State -cne'Absent'){throw 'All source-only native processes must be closed normally'}
if(-not $directedAcceptance.Passed -or $directedAcceptance.Reports -ne20 -or $directedAcceptance.FullAcceptanceClaim){throw 'Twenty directed reports required; not a full PASS'}
if((Get-FileHash -LiteralPath $transfer.ClosureProof).Hash -cne$transfer.ClosureProofSHA256){throw 'Original full closure proof changed'}
$rows=@($request.ProtectedInputs)+@($request.SourceComponents)+@($request.ParticipatingScripts)
if($rows.Count -ne502 -or (& git rev-parse HEAD) -cne$request.SourceCommit){throw 'Original epoch required before publication'}
$changes=@{}
foreach($pin in $transfer.Records){$changes[[string]$pin.Path]=[string]$pin.CandidateSHA256}
if($changes.Count -ne4){throw 'Exactly four reviewed test-source changes required'}
foreach($row in $rows){
 $expected=if($changes.ContainsKey([string]$row.Path)){$changes[[string]$row.Path]}else{[string]$row.SHA256}
 if((Get-FileHash -LiteralPath (Join-Path $root $row.Path)).Hash -cne$expected){throw ('Unexpected input change before publication: '+$row.Path)}
}
$stage=Join-Path $PSScriptRoot 'RecoveryPublicationStage01';$backups=Join-Path $PSScriptRoot 'RecoveryPublicationBackups01'
if((Test-Path -LiteralPath $stage) -or (Test-Path -LiteralPath $backups)){throw 'Fresh publication directories required'}
if(@($package.Books).Count -ne2 -or @($package.Books|Where-Object {-not$_.UserDataAndResultsPreserved -or @($_.ChangedParts).Count -ne1 -or $_.ChangedParts[0] -cne'xl/vbaProject.bin'}).Count){throw 'Only VBA may change in the two preserved books'}
$files=@($package.Books|ForEach-Object {[pscustomobject]@{ID=$_.ID;Source=$_.Path;Relative=$_.RelativeOutput;Before=$_.BeforeSHA256;After=$_.SHA256}})
$code=Join-Path $PSScriptRoot ($Native+'/Main/VBA_All_Code.txt')
$files+=,[pscustomobject]@{ID='AllCode';Source=$code;Relative='workbook/output/VBA_All_Code.txt';Before=$request.AllCodeSHA256;After=$nativeReview.MainExportSHA256}
$allowed=@('workbook/output/RC_Section_NDM.xlsm','workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm','workbook/output/VBA_All_Code.txt')
if(@(Compare-Object ($allowed|Sort-Object) ($files.Relative|Sort-Object)).Count){throw 'Unexpected publication target'}
[void][IO.Directory]::CreateDirectory($stage);[void][IO.Directory]::CreateDirectory($backups)
$records=@()
foreach($file in $files){
 $target=Join-Path $root $file.Relative
 if((Get-FileHash -LiteralPath $target).Hash -cne$file.Before -or (Get-FileHash -LiteralPath $file.Source).Hash -cne$file.After){throw 'User changed an output or accepted private package'}
 $lock=[IO.File]::Open($target,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$lock.Dispose()
 $staged=Join-Path $stage $file.ID;Copy-Item -LiteralPath $file.Source -Destination $staged
 $records+=,[ordered]@{ID=$file.ID;Path=$file.Relative;Destination=$target;Stage=$staged;Backup=(Join-Path $backups $file.ID);BeforeSHA256=$file.Before;AfterSHA256=$file.After}
}
foreach($record in $records){
 if((Get-FileHash -LiteralPath $record.Destination).Hash -cne$record.BeforeSHA256){throw 'Output changed immediately before atomic replacement'}
 [IO.File]::Replace($record.Stage,$record.Destination,$record.Backup)
 if((Get-FileHash -LiteralPath $record.Destination).Hash -cne$record.AfterSHA256 -or (Get-FileHash -LiteralPath $record.Backup).Hash -cne$record.BeforeSHA256){throw 'Atomic replacement verification failed'}
}
[ordered]@{Passed=$true;Status='PUBLISHED_FOUR_TEST_FIXES_FULL_REPEAT_PENDING';Files=$records;PublishedUTC=[DateTimeOffset]::UtcNow.ToString('o');ProductionVBAChanged=$false;FullRegressionPass=$false}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'RecoveryPublication.json') -Encoding UTF8
