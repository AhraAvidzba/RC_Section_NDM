# ==========================================================================
# ДЛЯ ТЕСТОВ: только десять затронутых групп на свежей сборке, последовательно No/Yes.
# Не запускает полный UI; не публикует книгу и не присваивает ей полный PASS.
# ==========================================================================
param(
    [ValidatePattern('^RecoveryFreshBuild[0-9]+$')][string]$Build='RecoveryFreshBuild01',
    [ValidatePattern('^RecoveryDirected[0-9]+$')][string]$Attempt='RecoveryDirected01'
)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$buildDirectory=Join-Path $PSScriptRoot $Build
$buildProof=Get-Content -LiteralPath (Join-Path $buildDirectory 'Build.json') -Raw -Encoding UTF8|ConvertFrom-Json
$transfer=Get-Content -LiteralPath (Join-Path $buildDirectory 'Transfer.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($buildProof.Status -cne 'FRESH_SOURCE_BUILD_COMPILE' -or $transfer.Status -cne 'FOUR_TEST_SOURCES_TRANSFERRED_BOOKS_NOT_PUBLISHED'){throw 'Actual reviewed source transfer and fresh native build required'}
if((Get-FileHash -LiteralPath $transfer.ClosureProof).Hash -cne $transfer.ClosureProofSHA256){throw 'Previous full closure proof changed'}
$source=(Resolve-Path -LiteralPath $buildProof.Workbook).Path
if(-not $source.StartsWith($buildDirectory+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Only own fresh build allowed'}
$priorBuildProcess=$null
try{$priorBuildProcess=Get-Process -Id ([int]$buildProof.OwnExcelPID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -notmatch'^NoProcessFoundForGivenId(,|$)'){throw}}
if($priorBuildProcess){
    if($null -eq $priorBuildProcess.StartTime){throw 'Build Excel identity unavailable'}
    if($priorBuildProcess.ProcessName -ieq'EXCEL' -and [string]$priorBuildProcess.StartTime.ToUniversalTime().Ticks -ceq[string]$buildProof.OwnExcelStartTicksUTC){throw 'Build Excel still live; no directed process allowed'}
}
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'DeferredConfirmedFixes01/DeferredSourceManifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
$output=Join-Path $PSScriptRoot $Attempt
if(Test-Path -LiteralPath $output){throw 'Fresh directed evidence directory required'}
[void][IO.Directory]::CreateDirectory($output)
$records=@()
foreach($macro in $manifest.DirectedMacrosNoYes){
    foreach($mode in @('No','Yes')){
        foreach($pin in $transfer.Records){if((Get-FileHash -LiteralPath (Join-Path $root $pin.Path)).Hash -cne $pin.CandidateSHA256){throw 'Transferred source changed'}}
        if((Get-FileHash -LiteralPath $source).Hash -cne $buildProof.SHA256){throw 'Directed source workbook changed'}
        $name=([string]$macro).Replace('.','_')+'_'+$mode
        $report=Join-Path $output ($name+'.txt')
        $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory -ErrorAction Stop
        if($null -eq $m -or $null -eq $m.AvailableMBytes -or $null -eq $m.CommitLimit -or $null -eq $m.CommittedBytes -or [double]$m.CommitLimit -le0){throw 'Actual memory counters unavailable'}
        $ram=[double]$m.AvailableMBytes/1024;$commit=([double]$m.CommitLimit-[double]$m.CommittedBytes)/1GB
        [ordered]@{RAMGiB=$ram;CommitGiB=$commit;RequiredRAMGiB=8;RequiredCommitGiB=14}|ConvertTo-Json|Set-Content -LiteralPath ($report+'.Memory.json') -Encoding UTF8
        if($ram -lt8 -or $commit -lt14){throw '8RAM/14commit required before each sequential Excel'}
        $parameters=@{SourceWorkbook=$source;ReportPath=$report.Substring($root.Length+1);Macro=$macro;Mode=$mode;TimeoutSeconds=600}
        if($macro -in @('modTestCalculationSnapshot.RunCalculationSnapshotTests','modTestWorkbookInterface.RunSectionWorkflowCalculationTests')){
            $parameters.VerifyResultsReopen=$true;$parameters.VerifyStatusReopen=$true
        }
        & (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') @parameters
        $exit=$LASTEXITCODE
        $text=[IO.File]::ReadAllText($report,[Text.Encoding]::UTF8)
        $failures=@([regex]::Matches($text,'(?m)^(?:FAIL[: ]|RUNTIME(?: ERROR|:)|SCRIPT ERROR|WATCHDOG_FAILURE|CLEANUP ERROR|RESTORE ERROR)[^\r\n]*')|ForEach-Object{$_.Value})
        $totals=@([regex]::Matches($text,'(?m)^TOTAL[^\r\n]*?passed=(\d+); failed=(\d+)[^\r\n]*'))
        $badTotals=@($totals|Where-Object{[int]$_.Groups[2].Value -ne0})
        $closure=Get-Content -LiteralPath ($report+'.ProcessClosure.json') -Raw -Encoding UTF8|ConvertFrom-Json
        $passed=$exit -eq0 -and -not $failures.Count -and $totals.Count -gt0 -and -not $badTotals.Count -and $closure.Passed -and $text.Contains('SUITE_FINISHED: '+$macro+';') -and $text.Contains('SOURCE_SHA256: '+$buildProof.SHA256) -and $text.Contains('SOURCE_UNCHANGED: True') -and $text.Contains('WATCHDOG_COMPLETED: exit=0;')
        if($macro -ceq 'modTestConfiguration.RunLocaleSavedContractTests'){$passed=$passed -and [int]$totals[-1].Groups[1].Value -eq25}
        $records+=,[ordered]@{Macro=$macro;Mode=$mode;Passed=[bool]$passed;ExitCode=$exit;Report=$report;SHA256=(Get-FileHash -LiteralPath $report).Hash;AllPrimaryRead=$true;Failures=$failures;Totals=@($totals|ForEach-Object{$_.Value});OwnClosurePassed=$closure.Passed;SourceSHA256=$buildProof.SHA256;FullAcceptanceClaim=$false}
        ConvertTo-Json -InputObject $records -Depth 7|Set-Content -LiteralPath (Join-Path $output 'Results.json') -Encoding UTF8
        if(-not $passed){throw ('Directed failure preserved: '+$report)}
    }
}
[ordered]@{Status='PASS_ISOLATED_TEN_GROUPS_NO_YES_ONLY';Passed=$true;Reports=$records.Count;SourceSHA256=$buildProof.SHA256;FullAcceptanceClaim=$false;NativeFullRepeatStillRequired=$true;FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $output 'Acceptance.json') -Encoding UTF8
