# ==========================================================================
# ДЛЯ ТЕСТОВ: перенос четырёх подготовленных test-source и чистая частная сборка.
# Ничего не публикует; требует полного исходного разбора и выхода всех владельцев.
# ==========================================================================
param(
    [Parameter(Mandatory=$true)][string]$FullClosureProof,
    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9A-F]{64}$')][string]$ExpectedClosureSHA256,
    [ValidatePattern('^RecoveryFreshBuild[0-9]+$')][string]$Attempt='RecoveryFreshBuild01'
)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required'}
$testRecoveryRoot=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $testRecoveryRoot
$testRecoveryProofPath=(Resolve-Path -LiteralPath $FullClosureProof).Path
if(-not $testRecoveryProofPath.StartsWith($PSScriptRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Own closure proof required'}
if((Get-FileHash -LiteralPath $testRecoveryProofPath).Hash -cne $ExpectedClosureSHA256){throw 'Closure proof changed'}
$testRecoveryClosure=Get-Content -LiteralPath $testRecoveryProofPath -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $testRecoveryClosure.AllOwnIdentitiesTerminal -or -not $testRecoveryClosure.PrimaryLogsReviewed -or [int]$testRecoveryClosure.CoreMacrosReviewed -ne178 -or [int]$testRecoveryClosure.FocusedSingleCasesReviewed -ne122 -or [int]$testRecoveryClosure.FocusedRecordCount -ne26 -or -not $testRecoveryClosure.IncludesFocusedComposition){throw 'Entire178+122/26 primary review and all closures required'}
$testRecoveryRequest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'LaunchRequest.json') -Raw -Encoding UTF8|ConvertFrom-Json
$testRecoveryCompletion=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Completion.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not $testRecoveryCompletion.FinishedUTC -or @($testRecoveryCompletion.ChangedInputs).Count -or $testRecoveryCompletion.HeadChanged){throw 'Original terminal input review must be clean'}
if($testRecoveryClosure.SourceSHA256 -cne $testRecoveryRequest.SourceSHA256 -or $testRecoveryCompletion.SourceSHA256 -cne $testRecoveryRequest.SourceSHA256){throw 'Original epoch mismatch'}
$testRecoveryIdentities=@($testRecoveryClosure.Identities)
foreach($name in @('DriverRun.json','HostRun.json')){
    $identity=Get-Content -LiteralPath (Join-Path $PSScriptRoot $name) -Raw -Encoding UTF8|ConvertFrom-Json
    if(@($testRecoveryIdentities|Where-Object{[int]$_.PID -eq[int]$identity.PID -and [string]$_.StartTicksUTC -ceq[string]$identity.StartTicks -and $_.Name -ieq'powershell'}).Count -ne1){throw 'Exact previous driver and host must be included'}
}
foreach($identity in $testRecoveryIdentities){
    if([int]$identity.PID -le0 -or [long]$identity.StartTicksUTC -le0 -or [string]$identity.Name -notin @('EXCEL','acad','powershell')){throw 'Invalid prior identity'}
    $process=$null
    try{$process=Get-Process -Id ([int]$identity.PID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -notmatch'^NoProcessFoundForGivenId(,|$)'){throw}}
    if($process){
        if([string]::IsNullOrWhiteSpace([string]$process.ProcessName)){throw 'Prior process name unknown'}
        if($process.ProcessName -ine[string]$identity.Name){continue} # Чужое имя процесса уже исключает прежний Excel; номер PID не обязан оставаться свободным.
        if($null -eq $process.StartTime){throw 'Prior identity unknown'}
        if($process.ProcessName -ieq[string]$identity.Name -and [string]$process.StartTime.ToUniversalTime().Ticks -ceq[string]$identity.StartTicksUTC){throw 'Previous own process still live'}
    }
}
$testRecoveryInputs=@($testRecoveryRequest.ProtectedInputs)+@($testRecoveryRequest.SourceComponents)+@($testRecoveryRequest.ParticipatingScripts)
if($testRecoveryInputs.Count -ne502 -or (& git rev-parse HEAD) -cne $testRecoveryRequest.SourceCommit){throw 'Original502/HEAD mismatch'}
foreach($entry in $testRecoveryInputs){if((Get-FileHash -LiteralPath (Join-Path $testRecoveryRoot $entry.Path)).Hash -cne [string]$entry.SHA256){throw ('Original input changed: '+$entry.Path)}}
$testRecoveryManifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'DeferredConfirmedFixes01/DeferredSourceManifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
$testRecoveryWanted=@('tests/modTestConfiguration.bas','tests/modTestWorkbookInterface.bas','tests/modTestPlotConfig.bas','tests/modTestContourMesh.bas')
if(@($testRecoveryManifest.Records).Count -ne4 -or $testRecoveryManifest.SourceSHA256 -cne $testRecoveryRequest.SourceSHA256){throw 'Exact four-module manifest required'}
foreach($entry in $testRecoveryManifest.Records){
    if($entry.Path -cnotin $testRecoveryWanted){throw 'Forbidden source transfer'}
    $source=Join-Path $testRecoveryRoot $entry.Path
    $candidate=Join-Path $PSScriptRoot ('DeferredConfirmedFixes01/Candidate/'+[IO.Path]::GetFileName($entry.Path))
    if((Get-FileHash -LiteralPath $source).Hash -cne $entry.OriginalSHA256 -or (Get-FileHash -LiteralPath $candidate).Hash -cne $entry.CandidateSHA256){throw 'Original/candidate source hash changed'}
}
if(@($testRecoveryManifest.Records.Path|Sort-Object -Unique).Count -ne4){throw 'Duplicate source row'}
$testRecoveryOutput=Join-Path $PSScriptRoot $Attempt
if(Test-Path -LiteralPath $testRecoveryOutput){throw 'Preserve earlier evidence; choose fresh attempt'}
$testRecoveryMemory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory -ErrorAction Stop
if($null -eq $testRecoveryMemory -or $null -eq $testRecoveryMemory.AvailableMBytes -or $null -eq $testRecoveryMemory.CommitLimit -or $null -eq $testRecoveryMemory.CommittedBytes -or [double]$testRecoveryMemory.CommitLimit -le0){throw 'Actual memory counters unavailable'}
$testRecoveryRAM=[double]$testRecoveryMemory.AvailableMBytes/1024
$testRecoveryCommit=([double]$testRecoveryMemory.CommitLimit-[double]$testRecoveryMemory.CommittedBytes)/1GB
if($testRecoveryRAM -lt8 -or $testRecoveryCommit -lt14){throw '8RAM/14commit required before source transfer and fresh native build'}
[void][IO.Directory]::CreateDirectory($testRecoveryOutput)
[ordered]@{RAMGiB=$testRecoveryRAM;CommitGiB=$testRecoveryCommit;RequiredRAMGiB=8;RequiredCommitGiB=14}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $testRecoveryOutput 'MemoryBefore.json') -Encoding UTF8
foreach($entry in $testRecoveryManifest.Records){
    $source=Join-Path $testRecoveryRoot $entry.Path
    $backup=Join-Path $testRecoveryOutput ('Before/'+$entry.Path)
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $backup))
    Copy-Item -LiteralPath $source -Destination $backup
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('DeferredConfirmedFixes01/Candidate/'+[IO.Path]::GetFileName($entry.Path))) -Destination $source
    if((Get-FileHash -LiteralPath $source).Hash -cne $entry.CandidateSHA256){throw 'Transferred source mismatch'}
}
$testRecoveryChanged=@(foreach($entry in $testRecoveryInputs){if((Get-FileHash -LiteralPath (Join-Path $testRecoveryRoot $entry.Path)).Hash -cne [string]$entry.SHA256){[string]$entry.Path}})
if(@(Compare-Object ($testRecoveryWanted|Sort-Object) ($testRecoveryChanged|Sort-Object)).Count){throw 'Unexpected transfer changes'}
[ordered]@{Status='FOUR_TEST_SOURCES_TRANSFERRED_BOOKS_NOT_PUBLISHED';SourceSHA256=$testRecoveryRequest.SourceSHA256;ClosureProof=$testRecoveryProofPath;ClosureProofSHA256=$ExpectedClosureSHA256;ChangedInputs=$testRecoveryChanged;ProductionVBAChanged=$false;Records=$testRecoveryManifest.Records}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $testRecoveryOutput 'Transfer.json') -Encoding UTF8
& {
    $testRecoveryBuiltBook=Join-Path $testRecoveryOutput 'RC_Section_NDM.xlsm'
    . (Join-Path $testRecoveryRoot 'tools/build_workbook/Build-Workbook.ps1') -OutputPath $testRecoveryBuiltBook.Substring($testRecoveryRoot.Length+1) -FormulaImageDirectory (Join-Path $testRecoveryOutput 'FormulaImages').Substring($testRecoveryRoot.Length+1)
    [ordered]@{Status='FRESH_SOURCE_BUILD_COMPILE';Workbook=$testRecoveryBuiltBook;SHA256=(Get-FileHash -LiteralPath $testRecoveryBuiltBook).Hash;OwnExcelPID=$ownedExcelProcessId;OwnExcelStartTicksUTC=[string]$ownedExcelStartTicks;PublishedBooksChanged=$false;FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $testRecoveryOutput 'Build.json') -Encoding UTF8
}
