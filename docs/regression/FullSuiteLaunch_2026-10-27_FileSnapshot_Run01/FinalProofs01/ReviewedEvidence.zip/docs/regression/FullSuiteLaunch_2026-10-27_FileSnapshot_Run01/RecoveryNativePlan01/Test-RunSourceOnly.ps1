﻿# ==========================================================================
# ДЛЯ ТЕСТОВ: readonly native source175+6 двух готовых книг без импорта и расчёта.
# ==========================================================================
param([Parameter(Mandatory=$true)][string]$PlanJson,[Parameter(Mandatory=$true)][string]$EvidenceDirectory)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required.'}
Import-Module ([IO.Path]::Combine($PSHOME,'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1')) -Global
Import-Module ([IO.Path]::Combine($PSHOME,'Modules/Microsoft.PowerShell.Management/Microsoft.PowerShell.Management.psd1')) -Global
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$allowed=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path+[IO.Path]::DirectorySeparatorChar
$planPath=(Resolve-Path -LiteralPath $PlanJson).Path;$plan=Get-Content -LiteralPath $planPath -Raw -Encoding UTF8|ConvertFrom-Json
$directory=[IO.Path]::GetFullPath($EvidenceDirectory)
if(-not $directory.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $directory)){throw 'Fresh own evidence required.'}
[void][IO.Directory]::CreateDirectory($directory)
function Proof([string]$Name,$Value){[IO.File]::WriteAllText((Join-Path $directory $Name),(ConvertTo-Json -InputObject $Value -Depth 12),[Text.UTF8Encoding]::new($true))}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Только явный NotFound доказывает отсутствие; неизвестная identity не разрешает cleanup.
function Test-ProcessState([int]$ID,[long]$Start,[string]$Name){
 $state=[ordered]@{State='Unknown';PID=$ID;ExpectedStartTicksUTC=[string]$Start;ExpectedName=$Name;Error=$null}
 if($ID -le0 -or $Start -le0){$state.Error='Missing process identity';return [pscustomobject]$state}
 try{$p=Get-Process -Id $ID -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -match'^NoProcessFoundForGivenId(,|$)'){$state.State='Absent'}else{$state.Error=$_.Exception.Message};return [pscustomobject]$state}
 try{if($null -eq$p -or $null -eq$p.StartTime){throw 'Process or StartTime unavailable'};$state['ObservedName']=$p.ProcessName;$state['ObservedStartTicksUTC']=[string]$p.StartTime.ToUniversalTime().Ticks;if($p.ProcessName -ieq$Name -and $p.StartTime.ToUniversalTime().Ticks -eq$Start){$state.State='Live'}else{$state.Error='PID identity mismatch'}}catch{$state.Error=$_.Exception.Message}
 return [pscustomobject]$state
}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет фактическую память непосредственно до единственного нового Excel.
function Test-Memory {
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($null -eq$m -or $null -eq$m.AvailableMBytes -or $null -eq$m.CommitLimit -or $null -eq$m.CommittedBytes -or [double]$m.CommitLimit -le0){throw 'Actual memory unavailable; no Excel created.'}
 $ram=[double]$m.AvailableMBytes/1024;$commit=([double]$m.CommitLimit-[double]$m.CommittedBytes)/1GB
 if([double]::IsNaN($ram) -or [double]::IsInfinity($ram) -or [double]::IsNaN($commit) -or [double]::IsInfinity($commit)){throw 'Nonfinite memory counters.'}
 Proof 'MemoryBeforeExcel.json' ([ordered]@{RAMGiB=$ram;CommitGiB=$commit;RequiredRAMGiB=8;RequiredCommitGiB=14})
 if($ram -lt8 -or $commit -lt14){throw '8RAM/14commit reserve required; no Excel created.'}
}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Native export сохраняет реальную Date; только эта строка исключается из body comparison.
function Test-CompareAllCode([string]$Actual,[string]$Reference){
 $pattern='\AVBA PROJECT EXPORT\r?\n(?<Workbook>Workbook: [^\r\n]+)\r?\n(?<Date>Date: \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\r?\n(?<Body>[\s\S]*)\z'
 $a=[regex]::Match([IO.File]::ReadAllText($Actual,[Text.Encoding]::UTF8),$pattern);$b=[regex]::Match([IO.File]::ReadAllText($Reference,[Text.Encoding]::UTF8),$pattern)
 if(-not$a.Success -or -not$b.Success){throw 'Exact native AllCode format required.'}
 $equal=$a.Groups['Workbook'].Value -ceq$b.Groups['Workbook'].Value -and $a.Groups['Body'].Value -ceq$b.Groups['Body'].Value
 if(-not$equal){throw 'Main native component bodies differ from published reference AllCode.'}
 return [ordered]@{Passed=$true;ActualRawSHA256=(Get-FileHash -LiteralPath $Actual).Hash;ReferenceRawSHA256=(Get-FileHash -LiteralPath $Reference).Hash;ActualDate=$a.Groups['Date'].Value;ReferenceDate=$b.Groups['Date'].Value;NativeDatePreserved=$true;OnlyExcludedHeader='Date';WorkbookHeaderAndAllBodyBytesEqual=$true;CodeCaseOrNumberOrWhitespaceNormalizationUsed=$false}
}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сравнивает два native-текста по 181 компоненту буквально, без G15/регистра/пробелов.
function Test-CompareNativeBodies([string]$Main,[string]$Saved){
 $sets=@()
 foreach($path in @($Main,$Saved)){
  $raw=[IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)
  if($raw.Replace("`r`n",'').Contains("`n")){throw 'Native export must retain its CRLF format.'}
  $lines=$raw.Split(@("`r`n"),[StringSplitOptions]::None);$map=[ordered]@{}
  for($i=0;$i -lt$lines.Count;$i++){
   if(-not$lines[$i].StartsWith('COMPONENT: ')){continue}
   $name=$lines[$i].Substring(11);$type=[int]$lines[$i+1].Substring(6);$count=[int]$lines[$i+2].Substring(7)
   if($map.Contains($name) -or $count -lt0 -or $i+3+$count -ge$lines.Count){throw 'Invalid/duplicate native component.'}
   $body=if($count){$lines[($i+4)..($i+3+$count)] -join "`r`n"}else{''}
   $map[$name]=[ordered]@{Type=$type;Lines=$count;Body=$body};$i=$i+3+$count
  }
  if($map.Count -ne181){throw 'Raw native comparison requires181 components.'};$sets+=,$map
 }
 $different=@();$missing=@();$compared=0
 foreach($name in $sets[0].Keys){
  if(-not$sets[1].Contains($name)){$missing+=$name;continue}
  $a=$sets[0][$name];$b=$sets[1][$name];$compared++
  if($a.Type -ne$b.Type -or $a.Lines -ne$b.Lines -or $a.Body -cne$b.Body){$different+=,[ordered]@{Component=$name;Main=$a;Saved=$b}}
 }
 $order=(@($sets[0].Keys)-join'|') -ceq(@($sets[1].Keys)-join'|')
 return [ordered]@{Passed=($compared -eq181 -and -not$missing.Count -and -not$different.Count -and $order);ComponentsCompared=$compared;OrderEqual=$order;Missing=$missing;RawDifferences=$different;NumberNormalization=$false;IdentifierCaseNormalization=$false;WhitespaceNormalization=$false;ActualNativeCRLF=$true}
}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Читает только VBProject; не читает и не исправляет Config и расчётные таблицы fixture.
function Test-ReadBookSource($Case){
 $caseDirectory=Join-Path $directory ([string]$Case.ID);[void][IO.Directory]::CreateDirectory($caseDirectory)
 $path=[IO.Path]::GetFullPath([string]$Case.Path);$before=(Get-FileHash -LiteralPath $path).Hash
 if($before -cne[string]$Case.SHA256){throw 'Book SHA changed before readonly open.'}
 $book=$null;$project=$null;$component=$null;$code=$null
 try{
  if($script:app.Workbooks.Count -ne0){throw 'No previous workbook may remain before the next open.'}
  $book=$script:app.Workbooks.Open($path,0,$true)
  if($null -eq$book -or $script:app.Workbooks.Count -ne1 -or -not$book.ReadOnly -or -not[string]::Equals([IO.Path]::GetFullPath([string]$book.FullName),$path,[StringComparison]::OrdinalIgnoreCase)){throw 'Exact own readonly workbook required.'}
  $layout=Get-Content -LiteralPath (Join-Path $root 'tools/build_workbook/WorkbookLayout.json') -Raw -Encoding UTF8|ConvertFrom-Json
  $anchors=@()
  foreach($item in $layout.Names|Where-Object {$_.Name -like 'rngNDM*'}){
   $anchor=$book.Names.Item([string]$item.Name).RefersToRange
   $equal=[string]$anchor.Worksheet.Name -ceq[string]$item.Sheet -and [string]$anchor.Address() -ceq[string]$item.Address
   $anchors+=,[ordered]@{Name=$item.Name;Address=$anchor.Address();Expected=$item.Address;Equal=$equal}
   if(-not$equal){throw ('Native layout mismatch: '+$item.Name)}
  }
  Proof ($Case.ID+'/LayoutAnchors.json') $anchors
  # -------------------- Р”Р›РЇ РўР•РЎРўРћР’ --------------------
  # РџСЂРѕРІРµСЂСЏРµС‚ РёРјРµРЅРЅРѕ СЃРѕС…СЂР°РЅС‘РЅРЅС‹Рµ С‚РµРєСЃС‚РѕРІС‹Рµ СЏС‡РµР№РєРё РґРѕ С‡С‚РµРЅРёСЏ РєРѕРґР°, Р±РµР· РёСЃРїСЂР°РІР»РµРЅРёСЏ РєРЅРёРіРё.
  $textFits=@()
  Add-Type -AssemblyName System.Drawing
  foreach($cell in $Case.TextCells){
   $sheetIndex=if($cell.Part -eq 'xl/worksheets/sheet1.xml'){1}elseif($cell.Part -eq 'xl/worksheets/sheet3.xml'){3}else{throw 'Unexpected text part.'}
   $value=[string]$book.Worksheets.Item($sheetIndex).Range([string]$cell.Cell).Value2
   if($value -cne[string]$cell.After){throw ('Native text mismatch: '+$Case.ID+'/'+$cell.Cell)}
   $range=$book.Worksheets.Item($sheetIndex).Range([string]$cell.Cell)
   $hidden=[bool]$range.EntireRow.Hidden
   if($hidden){$range.EntireRow.Hidden=$false}
   $width=[double]$range.MergeArea.Width;$height=[double]$range.RowHeight
   $style=[Drawing.FontStyle]::Regular;if($range.Font.Bold){$style=$style -bor [Drawing.FontStyle]::Bold}
   $font=New-Object Drawing.Font([string]$range.Font.Name,[single]$range.Font.Size,$style)
   $bitmap=New-Object Drawing.Bitmap(1,1);$graphics=[Drawing.Graphics]::FromImage($bitmap)
   try{$size=$graphics.MeasureString($value,$font,[single](($width-4)*96/72))}finally{$font.Dispose();$graphics.Dispose();$bitmap.Dispose()}
   if($hidden){$range.EntireRow.Hidden=$true}
   $required=[double]$size.Height*72/96
   $textFits+=,[ordered]@{Cell=$cell.Cell;WidthPt=$width;RowHeightPt=$height;TextHeightPt=$required;Fits=($required -le($height+1))}
  }
  Proof ($Case.ID+'/TextFits.json') $textFits
  if(@($textFits|Where-Object {-not$_.Fits}).Count){throw 'Changed Help text does not fit its preserved row'}
  $project=$book.VBProject;$count=[int]$project.VBComponents.Count
  if(-not$book.HasVBProject -or $count -ne181){throw 'Exactly181 native components required.'}
  $text=New-Object Text.StringBuilder
  [void]$text.AppendLine('VBA PROJECT EXPORT');[void]$text.AppendLine('Workbook: '+$book.Name);[void]$text.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $inventory=@()
  for($i=1;$i -le$count;$i++){
   $component=$project.VBComponents.Item($i);$code=$component.CodeModule
   $inventory+=,[ordered]@{Name=[string]$component.Name;Type=[int]$component.Type;Lines=[int]$code.CountOfLines}
   [void]$text.AppendLine('='*100);[void]$text.AppendLine('COMPONENT: '+$component.Name);[void]$text.AppendLine('TYPE: '+$component.Type);[void]$text.AppendLine('LINES: '+$code.CountOfLines);[void]$text.AppendLine('='*100)
   if($code.CountOfLines){[void]$text.AppendLine($code.Lines(1,$code.CountOfLines))};[void]$text.AppendLine()
  }
  if($project.VBComponents.Count -ne181 -or @($inventory|Where-Object Type -eq 100).Count -ne6){throw 'Native inventory changed or document count differs.'}
  $export=Join-Path $caseDirectory 'VBA_All_Code.txt';[IO.File]::WriteAllText($export,$text.ToString(),[Text.UTF8Encoding]::new($true))
  Proof ($Case.ID+'/Inventory.json') $inventory
  $equality=Join-Path $caseDirectory 'SourceEquality.json'
  & (Join-Path $PSHOME 'powershell.exe') -NoProfile -ExecutionPolicy Bypass -File ([string]$plan.Verifier.Path) -ExportPath $export.Substring($root.Length+1) -ReportPath $equality.Substring($root.Length+1) -ExpectedOverrideCount 0
  if($LASTEXITCODE -ne0){throw 'Strict native source equality failed.'}
  $verified=Get-Content -LiteralPath $equality -Raw -Encoding UTF8|ConvertFrom-Json
  if(-not$verified.Passed -or $verified.SourceComponents -ne175 -or $verified.ExportComponents -ne181 -or @($verified.Components|Where-Object ExplicitOverride).Count -ne0 -or @($verified.DocumentSourceMatches).Count -ne6 -or @($verified.DocumentSourceMatches|Where-Object {-not$_.Equal}).Count -ne0){throw 'Incomplete strict175+6 equality.'}
  $allCode=$null # Actual Main native dump becomes AllCode; scoped raw178 comparison is reviewed separately.
  return [ordered]@{Case=$Case.ID;Passed=$true;Book=$path;BookSHA256=$before;Components=181;SourceComponents=175;DocumentModules=6;ImportedComponents=0;CompileRequested=$false;CalculationOrRunRequested=$false;SettingsReadOrModified=$false;ReadOnly=$true;SourceEquality=$equality;ExportSHA256=(Get-FileHash -LiteralPath $export).Hash;AllCodeComparison=$allCode}
 }finally{
  if($book){$book.Close($false)}
  $code=$null;$component=$null;$project=$null;$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if((Get-FileHash -LiteralPath $path).Hash -cne$before){throw 'Readonly source book changed.'}
 }
}
$app=$null;$owned=0;$ticks=0L;$results=@();$failure=$null;$cleanupErrors=@();$quitSucceeded=$false;$frozen=@()
try{
 if([string]$plan.Status -cne'PRIVATE_SOURCE_ONLY_TWO_BOOKS_NO_IMPORT' -or @($plan.Cases).Count -ne2 -or [string]$plan.Cases[0].ID -cne'Main' -or [string]$plan.Cases[1].ID -cne'SavedExcelWarm2'){throw 'Exact source-only two-book plan required.'}
 foreach($item in @($plan.Cases)+@($plan.PublishedAllCode,$plan.Verifier)){
  if([string]$item.SHA256 -cnotmatch'^[0-9A-F]{64}$' -or (Get-FileHash -LiteralPath $item.Path).Hash -cne[string]$item.SHA256){throw 'Frozen dependency SHA mismatch.'}
  $frozen+=,[ordered]@{Path=[string]$item.Path;SHA256=[string]$item.SHA256}
 }
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $root 'src'),(Join-Path $root 'tests') -File -Recurse|Where-Object Extension -in @('.bas','.cls')){$frozen+=,[ordered]@{Path=$file.FullName;SHA256=(Get-FileHash -LiteralPath $file.FullName).Hash}}
 foreach($relative in @('tools/build_workbook/Build-Workbook.ps1','tools/build_workbook/WorkbookHelpEvents.vba')){$path=Join-Path $root $relative;$frozen+=,[ordered]@{Path=$path;SHA256=(Get-FileHash -LiteralPath $path).Hash}}
 Proof 'Inputs.json' ([ordered]@{Plan=$plan;Frozen=$frozen;NoImportCompileRunSettings=$true})
 Test-Memory
 $prior=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
 Add-Type 'using System;using System.Runtime.InteropServices;public static class TestFinalCodeOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr w,out uint p);}'
 $app=New-Object -ComObject Excel.Application
 [uint32]$native=0;[void][TestFinalCodeOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$native);$owned=[int]$native
 $p=Get-Process -Id $owned -ErrorAction Stop;if($null -eq$p.StartTime){throw 'Owned StartTime unavailable.'};$ticks=$p.StartTime.ToUniversalTime().Ticks
 if($owned -in$prior -or (Test-ProcessState $owned $ticks 'EXCEL').State -ne'Live'){throw 'Fresh exact own Excel required.'}
 Proof 'Ownership.json' ([ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Name='EXCEL';PriorExcel=$prior;BeforeAnyWorkbookOpen=$true})
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AskToUpdateLinks=$false;$app.AutomationSecurity=3
 foreach($case in $plan.Cases){$results+=,(Test-ReadBookSource $case);Proof 'Cases.json' $results}
 $rawComparison=Test-CompareNativeBodies (Join-Path $directory 'Main/VBA_All_Code.txt') (Join-Path $directory 'SavedExcelWarm2/VBA_All_Code.txt')
 Proof 'RawNativeComponentComparison.json' $rawComparison
 if(-not$rawComparison.Passed){throw 'Saved native raw component bodies differ; preserve exact differences for review.'}
}catch{$failure=[ordered]@{Message=$_.Exception.ToString();ScriptStackTrace=$_.ScriptStackTrace};Proof 'Failure.json' $failure}
finally{
 if($app -and (Test-ProcessState $owned $ticks 'EXCEL').State -eq'Live'){
  try{if($app.Workbooks.Count -eq0){$app.Quit();$quitSucceeded=$true}else{$cleanupErrors+='Unexpected workbook remained; Quit skipped.'}}catch{$cleanupErrors+=$_.Exception.Message}
 }
 if($app){try{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}catch{$cleanupErrors+=$_.Exception.Message};$app=$null}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 Proof 'CleanupRequests.json' ([ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;QuitSucceeded=$quitSucceeded;Errors=$cleanupErrors;PostChildClosureRequired=$true;OrdinaryForceKilled=$false})
}
$changed=@($frozen|Where-Object {(Get-FileHash -LiteralPath $_.Path).Hash -cne$_.SHA256})
$pass=-not$failure -and $results.Count -eq2 -and -not$changed.Count -and $quitSucceeded -and -not$cleanupErrors.Count
Proof 'Acceptance.json' ([ordered]@{Passed=[bool]$pass;Status=$(if($pass){'PASS_SOURCE_ONLY_PENDING_POST_CHILD_CLOSURE'}else{'REVIEW_REQUIRED'});Cases=$results;ChangedInputs=$changed;Failure=$failure;QuitSucceeded=$quitSucceeded;PostChildClosureRequired=$true;NoImportCompileSaveRunSettings=$true;FullRegressionPass=$false})
if(-not$pass){exit 1}
