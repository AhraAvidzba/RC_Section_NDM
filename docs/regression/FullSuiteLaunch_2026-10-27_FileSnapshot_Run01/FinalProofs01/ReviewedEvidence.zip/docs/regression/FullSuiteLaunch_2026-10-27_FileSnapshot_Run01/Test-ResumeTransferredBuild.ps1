# ==========================================================================
# ДЛЯ ТЕСТОВ: продолжает проверенный перенос после pre-native ошибки пути.
# Прежнюю попытку сохраняет; сборка получает относительные workspace-пути.
# ==========================================================================
param([string]$Transferred='RecoveryFreshBuild01',[string]$Attempt='RecoveryFreshBuild02')
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required'}
foreach($name in @($Transferred,$Attempt)){if($name -cnotmatch '^RecoveryFreshBuild[0-9]+$'){throw 'Own build paths required'}}
$testResumeRoot=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $testResumeRoot
$testResumeBefore=Join-Path $PSScriptRoot $Transferred
if((Test-Path (Join-Path $testResumeBefore 'Build.json')) -or (Test-Path (Join-Path $testResumeBefore 'BuildOwnership.json')) -or (Test-Path (Join-Path $testResumeBefore 'RC_Section_NDM.xlsm'))){throw 'Only the proved pre-native failure may be resumed by this worker'}
$testResumeTransferPath=Join-Path $testResumeBefore 'Transfer.json'
$testResumeTransfer=Get-Content -LiteralPath $testResumeTransferPath -Raw -Encoding UTF8|ConvertFrom-Json
if($testResumeTransfer.Status -cne'FOUR_TEST_SOURCES_TRANSFERRED_BOOKS_NOT_PUBLISHED' -or $testResumeTransfer.ProductionVBAChanged -or @($testResumeTransfer.Records).Count -ne4){throw 'Four verified transferred test sources required'}
if((Get-FileHash -LiteralPath $testResumeTransfer.ClosureProof).Hash -cne$testResumeTransfer.ClosureProofSHA256){throw 'Full closure proof changed'}
$testResumeClosures=Get-Content -LiteralPath $testResumeTransfer.ClosureProof -Raw -Encoding UTF8|ConvertFrom-Json
if(-not$testResumeClosures.AllOwnIdentitiesTerminal -or -not$testResumeClosures.PrimaryLogsReviewed -or $testResumeClosures.CoreMacrosReviewed -ne178 -or $testResumeClosures.FocusedSingleCasesReviewed -ne122){throw 'Whole original full closure required'}
foreach($testResumeIdentity in $testResumeClosures.Identities){
 $testResumeProcess=$null;try{$testResumeProcess=Get-Process -Id ([int]$testResumeIdentity.PID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -notmatch '^NoProcessFoundForGivenId(,|$)'){throw}}
 if($testResumeProcess){
  if([string]::IsNullOrWhiteSpace([string]$testResumeProcess.ProcessName)){throw 'Prior process name unavailable'}
  if($testResumeProcess.ProcessName -ine$testResumeIdentity.Name){continue}
  if($null -eq$testResumeProcess.StartTime){throw 'Prior process identity unavailable'}
  if([string]$testResumeProcess.StartTime.ToUniversalTime().Ticks -ceq[string]$testResumeIdentity.StartTicksUTC){throw 'Previous own process still live'}
 }
}
$testResumeRequest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'LaunchRequest.json') -Raw -Encoding UTF8|ConvertFrom-Json
if((& git rev-parse HEAD) -cne$testResumeRequest.SourceCommit){throw 'Original HEAD must remain before native verification'}
$testResumeChanges=@{}
foreach($testResumeRow in $testResumeTransfer.Records){$testResumeChanges[[string]$testResumeRow.Path]=[string]$testResumeRow.CandidateSHA256}
$testResumeRows=@($testResumeRequest.ProtectedInputs)+@($testResumeRequest.SourceComponents)+@($testResumeRequest.ParticipatingScripts)
if($testResumeRows.Count -ne502 -or $testResumeChanges.Count -ne4){throw 'Original502/four intended differences required'}
foreach($testResumeRow in $testResumeRows){
 $testResumeExpected=if($testResumeChanges.ContainsKey([string]$testResumeRow.Path)){$testResumeChanges[[string]$testResumeRow.Path]}else{[string]$testResumeRow.SHA256}
 if((Get-FileHash -LiteralPath (Join-Path $testResumeRoot $testResumeRow.Path)).Hash -cne$testResumeExpected){throw ('Unexpected changed input: '+$testResumeRow.Path)}
}
$testResumeTiming=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'TimingObservation01/ParityAndTimingReview.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not$testResumeTiming.AllPassed -or -not$testResumeTiming.AllNumericalRecordsExactlyEqual){throw 'Planned timing observations require prior review'}
$testResumeOutput=Join-Path $PSScriptRoot $Attempt
if(Test-Path -LiteralPath $testResumeOutput){throw 'Fresh native build evidence required'}
$testResumeMemory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($null -eq$testResumeMemory -or $null -eq$testResumeMemory.AvailableMBytes -or $null -eq$testResumeMemory.CommitLimit -or $null -eq$testResumeMemory.CommittedBytes -or [double]$testResumeMemory.CommitLimit -le0){throw 'Actual memory counters unavailable'}
$testResumeRAM=[double]$testResumeMemory.AvailableMBytes/1024;$testResumeCommit=([double]$testResumeMemory.CommitLimit-[double]$testResumeMemory.CommittedBytes)/1GB
if($testResumeRAM -lt8 -or $testResumeCommit -lt14){throw '8RAM/14commit required before Excel'}
[void][IO.Directory]::CreateDirectory($testResumeOutput)
Copy-Item -LiteralPath $testResumeTransferPath -Destination (Join-Path $testResumeOutput 'Transfer.json')
[ordered]@{RAMGiB=$testResumeRAM;CommitGiB=$testResumeCommit;RequiredRAMGiB=8;RequiredCommitGiB=14}|ConvertTo-Json|Set-Content (Join-Path $testResumeOutput 'MemoryBefore.json') -Encoding UTF8
& {
 $testResumeBuilt=Join-Path $testResumeOutput 'RC_Section_NDM.xlsm'
 $testResumeOutputRelative=$testResumeBuilt.Substring($testResumeRoot.Length+1)
 $testResumeImagesRelative=(Join-Path $testResumeOutput 'FormulaImages').Substring($testResumeRoot.Length+1)
 . (Join-Path $testResumeRoot 'tools/build_workbook/Build-Workbook.ps1') -OutputPath $testResumeOutputRelative -FormulaImageDirectory $testResumeImagesRelative
 [ordered]@{Status='FRESH_SOURCE_BUILD_COMPILE';Workbook=$testResumeBuilt;SHA256=(Get-FileHash -LiteralPath $testResumeBuilt).Hash;OwnExcelPID=$ownedExcelProcessId;OwnExcelStartTicksUTC=[string]$ownedExcelStartTicks;PublishedBooksChanged=$false;FinishedUTC=[DateTimeOffset]::UtcNow.ToString('o');ResumedAfterPreNativePathFailure=$true;OriginalTransfer=$testResumeTransferPath}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $testResumeOutput 'Build.json') -Encoding UTF8
}
