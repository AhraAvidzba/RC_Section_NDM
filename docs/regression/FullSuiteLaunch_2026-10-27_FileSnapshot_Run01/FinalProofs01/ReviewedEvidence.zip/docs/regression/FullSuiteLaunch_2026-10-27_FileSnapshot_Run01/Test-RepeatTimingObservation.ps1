# ==========================================================================
# ДЛЯ ТЕСТОВ: заранее ограниченные No/No/Yes повторы 23 Saved-случаев.
# Исходный отказ 10.375 с сохраняется; предел 10 с и расчётный код не меняются.
# ==========================================================================
param([string]$Attempt='TimingObservation01')
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -ne5){throw 'Windows PowerShell5.1 required'}
if($Attempt -cnotmatch '^TimingObservation[0-9]+$'){throw 'Own fresh timing evidence required'}
$root=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $root
$closure=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'AllOwnClosuresReviewed.json') -Raw -Encoding UTF8|ConvertFrom-Json
if(-not$closure.AllOwnIdentitiesTerminal -or -not$closure.PrimaryLogsReviewed -or $closure.CoreMacrosReviewed -ne178 -or $closure.FocusedSingleCasesReviewed -ne122){throw 'Original full primary review and all closures required'}
foreach($row in $closure.Identities){
 $p=$null;try{$p=Get-Process -Id ([int]$row.PID) -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -notmatch '^NoProcessFoundForGivenId(,|$)'){throw}}
 if($p){if([string]::IsNullOrWhiteSpace([string]$p.ProcessName)){throw 'Previous process name unavailable'};if($p.ProcessName -ine$row.Name){continue};if($null -eq$p.StartTime){throw 'Previous process identity unavailable'};if([string]$p.StartTime.ToUniversalTime().Ticks -ceq[string]$row.StartTicksUTC){throw 'Previous own process still live'}}
}
$request=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'LaunchRequest.json') -Raw -Encoding UTF8|ConvertFrom-Json
if((& git rev-parse HEAD) -cne$request.SourceCommit -or $closure.SourceSHA256 -cne$request.SourceSHA256){throw 'Original full epoch required'}
foreach($pin in @($request.ProtectedInputs)+@($request.SourceComponents)+@($request.ParticipatingScripts)){
 if((Get-FileHash -LiteralPath (Join-Path $root $pin.Path)).Hash -cne$pin.SHA256){throw ('Original input changed: '+$pin.Path)}
}
$probe=Join-Path $root ($request.EvidenceDirectory+'/Focused/Probe/RC_Section_NDM.xlsm')
$preparation=Get-Content -LiteralPath (Join-Path (Split-Path -Parent $probe) 'Preparation.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($preparation.SourceSHA256 -cne$request.SourceSHA256 -or (Get-FileHash -LiteralPath $probe).Hash -cne$preparation.ProbeWorkbookSHA256){throw 'Exact unchanged original Focused probe required'}
$directory=Join-Path $PSScriptRoot $Attempt
if(Test-Path -LiteralPath $directory){throw 'Preserve previous timing evidence'}
[void][IO.Directory]::CreateDirectory($directory)
$records=@();$index=0
foreach($mode in @('No','No','Yes')){
 $index++
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($null -eq$m -or $null -eq$m.AvailableMBytes -or $null -eq$m.CommitLimit -or $null -eq$m.CommittedBytes -or [double]$m.CommitLimit -le0){throw 'Actual memory unavailable'}
 $ram=[double]$m.AvailableMBytes/1024;$commit=([double]$m.CommitLimit-[double]$m.CommittedBytes)/1GB
 if($ram -lt8 -or $commit -lt14){throw '8RAM/14commit required before each sequential timing observation'}
 $report=Join-Path $directory ('Saved_'+$index+'_'+$mode+'.txt')
 [ordered]@{RAMGiB=$ram;CommitGiB=$commit}|ConvertTo-Json|Set-Content -LiteralPath ($report+'.Memory.json') -Encoding UTF8
 & (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') -SourceWorkbook $probe -ReportPath $report.Substring($root.Length+1) -Macro 'modTestBatchCalculation.TestRunFocusedAcceptanceCases' -MacroArgument1 'SavedWorkbook' -MacroArgument2 'Saved' -Mode $mode -TimeoutSeconds 360 -VerifyResultsReopen -VerifyStatusReopen
 $exit=$LASTEXITCODE
 $text=[IO.File]::ReadAllText($report,[Text.Encoding]::UTF8)
 $times=@([regex]::Matches($text,'(?m)^FOCUSED_TIME\|[^\r\n]+')|ForEach-Object Value)
 $failures=@([regex]::Matches($text,'(?m)^(?:FAIL[: ]|RUNTIME(?: ERROR|:)|SCRIPT ERROR|WATCHDOG_FAILURE|CLEANUP ERROR|RESTORE ERROR)[^\r\n]*')|ForEach-Object Value)
 $unexpectedFailures=@($failures|Where-Object {$_ -notmatch '^FAIL: focused\.SavedWorkbook\..+\.within10Seconds$'})
 $own=Get-Content -LiteralPath ($report+'.ProcessClosure.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $terminal=$own.Passed -and -not$unexpectedFailures.Count -and $text.Contains('SUITE_FINISHED: modTestBatchCalculation.TestRunFocusedAcceptanceCases;') -and $text.Contains('SOURCE_SHA256: '+$preparation.ProbeWorkbookSHA256) -and $text.Contains('SOURCE_UNCHANGED: True') -and $times.Count -eq23
 $records+=,[ordered]@{Index=$index;Mode=$mode;ExitCode=$exit;Terminal=[bool]$terminal;Passed=($terminal -and $exit -eq0 -and -not$failures.Count);Report=$report;SHA256=(Get-FileHash -LiteralPath $report).Hash;AllPrimaryRead=$true;Times=$times;Failures=$failures;OwnClosurePassed=$own.Passed;SourceSHA256=$preparation.ProbeWorkbookSHA256}
 ConvertTo-Json -InputObject $records -Depth 6|Set-Content -LiteralPath (Join-Path $directory 'Results.json') -Encoding UTF8
 if(-not$terminal){throw 'Nonterminal/error observation; preserve evidence and stop additional timing processes'}
}
[ordered]@{Status='THREE_PLANNED_TIMING_OBSERVATIONS_RECORDED_NOT_FULL_ACCEPTANCE';AllPassed=(@($records|Where-Object {-not$_.Passed}).Count -eq0);Reports=$records.Count;OriginalTimingFailurePreserved=$true;LimitSeconds=10;WorkingCodeChanged=$false;FullAcceptanceClaim=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $directory 'Review.json') -Encoding UTF8
