"""ДЛЯ ТЕСТОВ: обновляет только проверенный VBA, сохраняя каждый иной ZIP-компонент книги."""
from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET
import importlib.util
import sys

P = Path(__file__).resolve().parent
R = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')

def sha(data):
    return hashlib.sha256(data).hexdigest().upper()

def codes(parts):
    result = {}
    for name, data in parts.items():
        if name == 'xl/workbook.xml' or (name.startswith('xl/worksheets/sheet') and name.endswith('.xml')):
            root = ET.fromstring(data)
            prop = root.find('{*}workbookPr') if name == 'xl/workbook.xml' else root.find('{*}sheetPr')
            result[name] = None if prop is None else prop.get('codeName')
    return result

def main():
    sys.path.insert(0, str(R/'tools/build_workbook'))
    spec = importlib.util.spec_from_file_location('release_check', R/'tools/build_workbook/Verify-CalculationSnapshotRelease.py')
    verify = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verify)
    export = P/'CodeDonorNative/VBA_All_Code.txt'
    count, documents, errors = verify.verify_native_sources(export, R)
    assert (count, documents, errors) == (181, 6, []), (count, documents, errors)
    with zipfile.ZipFile(P/'CodeDonor/RC_Section_NDM.xlsm') as z:
        donor = {name: z.read(name) for name in z.namelist()}
    cases = [
        ('Clean', R/'docs/regression/IndexedResults_2026-11-01_Run01/CleanBuild/RC_Section_NDM.xlsm', '7A85A8E92B3BAAA381F2E12B0064B390C216A52D87A65C01930FDDCB622A2738', 'RC_Section_NDM.xlsm'),
        ('Main', R/'workbook/output/RC_Section_NDM.xlsm', 'DD9E31DAD225D6B8EE9CFDB9B0711463D37D42178547DB7C9842A94B91EF48FF', 'RC_Section_NDM.xlsm'),
        ('Heavy', R/'workbook/output/NDM_HeavyCircle_1232_30_2026-11-01/RC_Section_NDM_HeavyCircle_1232_30.xlsm', '93F817D72892BD22BFA9AA41AB47973746D4070AD4255C513E833892B833CC35', 'RC_Section_NDM_HeavyCircle_1232_30.xlsm'),
    ]
    records = []
    for label, source, expected, basename in cases:
        assert sha(source.read_bytes()) == expected, (label, 'source changed; preserve new user data')
        directory = P/'Prepared'/label
        directory.mkdir(parents=True, exist_ok=False)
        target = directory/basename
        with zipfile.ZipFile(source) as old:
            before = {name: old.read(name) for name in old.namelist()}
            assert not any('signature' in name.lower() for name in before), 'Signed book needs separate treatment'
            assert codes(before) == codes(donor), (label, 'document code names differ')
            with zipfile.ZipFile(target, 'w') as new:
                for info in old.infolist():
                    new.writestr(info, donor[info.filename] if info.filename == 'xl/vbaProject.bin' else before[info.filename])
        with zipfile.ZipFile(target) as new:
            assert new.testzip() is None
            assert set(new.namelist()) == set(before)
            changed = [name for name, data in before.items() if new.read(name) != data]
            assert changed == ['xl/vbaProject.bin'], changed
        records.append(dict(Label=label, Source=str(source), SourceSHA256=expected, Prepared=str(target),
                            PreparedSHA256=sha(target.read_bytes()), OnlyVBAChanged=True, UnchangedParts=len(before)-1,
                            DataResultsPicturesSettingsAndLayoutByteExact=True, DocumentCodeNamesEqual=True))
    (P/'PreparedOutputs.json').write_text(json.dumps(dict(Status='PREPARED_NATIVE_REOPEN_REQUIRED',
        SourceComponents=count, DocumentComponents=documents, Errors=errors, Books=records), ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(records, ensure_ascii=False))

if __name__ == '__main__':
    main()
