Attribute VB_Name = "modTestFormationReopen"
Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Воспроизводит штатное формирование после открытия индексированной книги, без AutoCAD и расчёта.
Private mTestStage As String

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Принимает место вызова из инструментированной частной копии writer-а.
Public Sub TestStage(ByVal value As String)
    mTestStage = value
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет только существующие значения в Config тестовой копии.
Private Sub TestSetting(ByVal key As String, ByVal value As String)
    Dim target As Range, row As Long: Set target = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = key Then target.Cells(row, 2).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, , "Missing setting " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет реальный entrypoint формирования при потерянном после открытия UserInterfaceOnly.
Public Function TestForm(ByVal mode As String) As String
    On Error GoTo Failed
    Dim sheet As Worksheet: Set sheet = ThisWorkbook.Worksheets("Results")
    If Not sheet.ProtectContents Or sheet.ProtectionMode Then Err.Raise 5, , "Reopen protection precondition"
    If mode = "Clear" Then
        ClearSectionResultsForWorkbook ThisWorkbook
        TestForm = "PASS|Mode=Clear|Protected=" & CStr(sheet.ProtectContents) & "|UIOnly=" & CStr(sheet.ProtectionMode)
        Exit Function
    End If
    modTestPerformance.TestConfigurePerformanceFixture "MIXED", 1, "Newton", "Circle", "Normal", "No"
    TestSetting "Results.SnapshotStorage", mode
    TestSetting "Results.SnapshotName", "TestFormationReopen"
    TestSetting "General.ExecutionReportEnabled", "No"
    TestSetting "General.NonCriticalMessagesEnabled", "No"
    TestSetting "General.ReformatResultsEnabled", "No"
    mTestStage = "FormSectionForWorkbook"
    Dim message As String: message = FormSectionForWorkbook(ThisWorkbook)
    TestForm = "PASS|Mode=" & mode & "|Protected=" & CStr(sheet.ProtectContents) & "|UIOnly=" & CStr(sheet.ProtectionMode) & "|" & message
    Exit Function
Failed:
    TestForm = "ERROR|Stage=" & mTestStage & "|Number=" & CStr(Err.Number) & "|Source=" & Err.Source & "|" & Err.Description
End Function
