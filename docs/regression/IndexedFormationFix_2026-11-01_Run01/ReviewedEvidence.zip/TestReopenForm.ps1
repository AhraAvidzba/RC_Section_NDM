﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Открывает только частную копию и проверяет штатное формирование с сохранённой структурной защитой.
param([string]$Tag='Before',[string]$Mode='Excel',[switch]$Updated)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM';$out=Join-Path $p $Tag
if(Test-Path -LiteralPath $out){throw 'Fresh case directory required'}
[void][IO.Directory]::CreateDirectory($out)
$source=Join-Path $root 'workbook/output/NDM_HeavyCircle_1232_30_2026-11-01/RC_Section_NDM_HeavyCircle_1232_30.xlsm'
$path=Join-Path $out 'TestFormation.xlsm';Copy-Item -LiteralPath $source -Destination $path
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestFormationOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestFormationOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135
 $component=$book.VBProject.VBComponents.Add(1);$component.Name='modTestFormationReopen'
 $code=[IO.File]::ReadAllText((Join-Path $p 'modTestFormationReopen.bas'),[Text.Encoding]::UTF8)
 $component.CodeModule.AddFromString(([regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')))
 foreach($name in @('CBatchResultWriter')){
  $component=$book.VBProject.VBComponents.Item($name)
  if($Updated){$code=[IO.File]::ReadAllText((Join-Path $root ('src/Excel/'+$name+'.cls')),[Text.Encoding]::UTF8);$code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')}else{$code=$component.CodeModule.Lines(1,$component.CodeModule.CountOfLines)}
  $code=[regex]::Replace($code,'(?im)^(    ClearSummaryBody SummaryClearRange\(workbook\))','    modTestFormationReopen.TestStage "CBatchResultWriter.ClearSummaryBody"'+[Environment]::NewLine+'$1')
  $component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines);$component.CodeModule.AddFromString($code)
 }
 $result=[string]$app.Run("'$($book.Name)'!modTestFormationReopen.TestForm",$Mode)
 $result|Set-Content (Join-Path $out 'Result.txt') -Encoding UTF8;Write-Output $result
 if($Updated -and -not $result.StartsWith('PASS|')){throw $result}
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
