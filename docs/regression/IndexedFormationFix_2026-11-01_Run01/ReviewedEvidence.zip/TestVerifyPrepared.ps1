﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Последовательно проверяет сохранённый код, неизменность данных и реальные входы после открытия.
param([switch]$ResumeAfterDonor)
$ErrorActionPreference='Stop'
$p=$PSScriptRoot
$ps='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
$python='C:/Users/avidzba/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$readonly=Join-Path (Split-Path $p) 'IndexedResults_2026-11-01_Run01/TestReadOnlyOutput23.ps1'
function TestOwn {
 & $ps -NoProfile -ExecutionPolicy Bypass -File (Join-Path $p 'TestAllOwn.ps1')
 if($LASTEXITCODE -ne 0){throw 'Exact own closure failed'}
}
function TestNative([string]$book,[string]$tag){
 TestOwn
 & $ps -NoProfile -ExecutionPolicy Bypass -File $readonly -WorkbookPath $book -OutputDirectory (Join-Path $p $tag)
 if($LASTEXITCODE -ne 0){throw ('Readonly native verification failed '+$tag)}
}
if(-not $ResumeAfterDonor){TestNative (Join-Path $p 'CodeDonor/RC_Section_NDM.xlsm') 'CodeDonorNative'}
& $python -X utf8 (Join-Path $p 'TestPrepareOutputs.py')
if($LASTEXITCODE -ne 0){throw 'Package preservation failed'}
TestNative (Join-Path $p 'Prepared/Clean/RC_Section_NDM.xlsm') 'CleanNative'
TestNative (Join-Path $p 'Prepared/Main/RC_Section_NDM.xlsm') 'MainNative'
TestNative (Join-Path $p 'Prepared/Heavy/RC_Section_NDM_HeavyCircle_1232_30.xlsm') 'HeavyNative'
foreach($mode in 'Excel','File','Clear'){
 TestOwn
 & $ps -NoProfile -ExecutionPolicy Bypass -File (Join-Path $p 'TestReopenFinal.ps1') -Tag ('Final'+$mode) -Mode $mode
 if($LASTEXITCODE -ne 0){throw ('Actual saved reopen failed '+$mode)}
}
TestOwn
Write-Output 'PASS_FINAL_NATIVE_CODE_DATA_AND_REOPEN'
