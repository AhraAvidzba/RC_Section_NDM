"""ДЛЯ ТЕСТОВ: сохраняет проверяемый компактный итог адресного исправления, без общей приёмки."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone

P = Path(__file__).resolve().parent
R = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
E = R/'docs/regression/IndexedFormationFix_2026-11-01_Run01'

def sha(data):
    return hashlib.sha256(data).hexdigest().upper()

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def main():
    publication = load(P/'Publication.json')
    review = load(P/'DirectedPrimaryReview.json')
    own = load(P/'AllOwnClosures.json')
    assert review['AssertionsPassed']==4970 and review['AssertionsFailed']==0 and review['Suites']==14
    assert own['Status']=='ALL_OWN_TERMINAL' and len(own['Processes'])==13
    for book in publication['Books']:
        assert sha(Path(book['Destination']).read_bytes())==book['SHA256']
        assert sha(Path(book['Backup']).read_bytes())==book['BackupSHA256']
    assert sha((R/'workbook/output/VBA_All_Code.txt').read_bytes())==publication['NativeEquality'][1]['ExportSHA256']
    E.mkdir(exist_ok=False)
    for name in ['Publication.json','DirectedPrimaryReview.json','AllOwnClosures.json','PreparedOutputs.json']:
        shutil.copy2(P/name,E/name)
    files = []
    for directory in ['Before','AfterExcel','AfterFile','FinalExcel','FinalFile','FinalClear','CodeDonor','CodeDonorNative','CleanNative','MainNative','HeavyNative']:
        files += [f for f in (P/directory).glob('*') if f.suffix in ['.json','.txt'] and f.name!='VBA_All_Code.txt']
    for mode in ['No','Yes']:
        files += list((P/'DirectedMessages_Attempt1'/mode).glob('*.txt'))
        files += list((P/'DirectedMessages_Attempt1'/mode).glob('*.json'))
    files += list(P.glob('*.ps1')) + list(P.glob('*.py')) + list(P.glob('*.bas'))
    files += [P/'PreparationAttempt1Error.txt',P/'CleanNative/VBA_All_Code.txt',P/'DirectedMessages_Attempt1/Run.json']
    archive = E/'ReviewedEvidence.zip'
    manifest = []
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for file in sorted(set(files)):
            raw = file.read_bytes()
            name = file.relative_to(P).as_posix()
            z.writestr(name,raw)
            manifest.append(dict(File=name,Bytes=len(raw),SHA256=sha(raw)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for file in manifest:
            assert sha(z.read(file['File']))==file['SHA256']
    (E/'Manifest.json').write_text(json.dumps(dict(ArchiveSHA256=sha(archive.read_bytes()),Files=manifest),ensure_ascii=False,indent=2),encoding='utf-8')
    sources = ['src/Excel/CBatchResultWriter.cls','src/Excel/modWorkbookCalculation.bas','src/Excel/modWorkbookMessages.bas',
               'tests/modTestCalculationSnapshot.bas','tests/modTestAudit02Api.bas']
    result = dict(Status='PASS_AFFECTED_FORMATION_PROTECTION_AND_MESSAGES',ProcessedUTC=datetime.now(timezone.utc).isoformat(),
        Suites=14,AssertionsPassed=4970,AssertionsFailed=0,ActualSavedReopen=['ExcelFormation','FileFormation','ClearResults'],
        NativeSourceComponents=181,NativeDocumentComponents=6,OwnTerminal=13,ForcedTerminations=0,
        DataResultsPicturesSettingsAndLayoutByteExact=True,FullOnOffPerformed=False,FullAcceptanceClaim=False,
        Sources=[dict(File=f,SHA256=sha((R/f).read_bytes())) for f in sources],
        CleanGitWorkbookSHA256=load(P/'PreparedOutputs.json')['Books'][0]['PreparedSHA256'],
        PublishedBooks=publication['Books'],EvidenceSHA256=sha(archive.read_bytes()),
        HarnessNotes=['First preparation attempt stopped before publication because a Python helper search path was missing; fixed and resumed from the already verified donor.'])
    (E/'Processed.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    report = '''# Формирование после повторного открытия и понятные ошибки Excel

01.11.2026. Адресное исправление в `codex/ndm-indexed-results`.

В сохранённой индексированной книге «Сформировать сечение» мог завершиться ошибкой 1004 при очистке сводки. Excel сохраняет защиту Results, но не сохраняет разрешение UserInterfaceOnly для макросов. В ветви Excel очистка и смена заливки общей сводки выполнялись раньше восстановления этого разрешения. Отказ воспроизведён в частной копии тяжёлой книги, непосредственно в CBatchResultWriter.ClearSummaryBody; первичный журнал сохранён.

CBatchResultWriter.ClearSummary теперь восстанавливает доступ макросов перед первой очисткой. Это защищает также ручную очистку Results и общие вызовы writer-а. Структурная защита индекса сохраняется; посторонняя защита не снимается.

При отказе очистки сообщение называет действие, именованный диапазон и его фактический адрес. Защита называется причиной только после проверки листа. Общее «Application-defined or object-defined error» получает русское объяснение с честным указанием, что Excel не уточнил причину. Исходное описание, источник и номер сохранены в технических сведениях. Ошибки после подготовки модели не дополняются советами исправлять размеры сечения или слои AutoCAD.

## Проверки

В двух режимах продолжения диаграмм No/Yes выполнены по семь направленных наборов: сообщения, InputErr, композиция комментариев, пакетные ошибки ввода, расчётный workflow, снимок сформированной геометрии и полный контракт снимка. Все 14 первичных журналов прочитаны целиком: **4970 passed, 0 failed**. В RunCalculationSnapshotTests — по 1001 проверке, включая оба режима оформления, восстановление доступа и отказ при посторонней защите. Новые проверки не ослабляют численные ожидания.

В сохранённой и действительно повторно открытой исправленной тяжёлой книге отдельно проверены штатные формирование Excel, формирование File и ручная очистка. Для проверки формирования использована параметрическая тестовая геометрия в частной копии; пользовательский AutoCAD не использовался. Приняты нативная компиляция и совпадение 181 исходного и 6 документных компонентов в чистой, основной и тяжёлой книгах. Все 13 собственных Excel подтверждённо вышли, принудительных завершений нет.

## Файлы и сохранность

Основная рабочая книга и выданный тяжёлый пример обновлены с резервом. В каждом файле заменён только xl/vbaProject.bin; все остальные 120 ZIP-компонентов совпадают побайтно. Нагрузки, результаты, настройки, стили и рисунки сохранены. Тяжёлое сечение осталось 1232 бетонных элемента / 8 стержней / 30 сочетаний, с четырьмя историческими InputErr; его нагрузки не пересчитывались. Внешний NDMSNP06 не изменён, комплект ZIP обновлён.

Чистый шаблон для Git получен такой же заменой VBA, остальные 115 компонентов неизменны. Исходники сборки обновлены; полная сборка импортирует эти компоненты. В Git включаются чистые книга и экспорт, рабочая книга с пользовательским расчётом остаётся локальной.

Полные ON/OFF+Focused после этой адресной правки не запускались; общий PASS нового полного набора не заявляется. Результаты прежних измерений производительности не переизмерялись и не переносятся на новую SHA как отдельная приёмка.

Доказательства: [Processed](../regression/IndexedFormationFix_2026-11-01_Run01/Processed.json), [первичные журналы и нативный экспорт](../regression/IndexedFormationFix_2026-11-01_Run01/ReviewedEvidence.zip), [манифест](../regression/IndexedFormationFix_2026-11-01_Run01/Manifest.json), [публикация и резерв](../regression/IndexedFormationFix_2026-11-01_Run01/Publication.json).
'''
    (R/'docs/reports/SectionFormationProtection_2026-11-01.md').write_text(report,encoding='utf-8')
    progress = R/'docs/geometry_refactor/PROGRESS.md'
    text = progress.read_text(encoding='utf-8-sig')
    heading, body = text.split('\n',1)
    paragraph = '''
## 01.11.2026 — Формирование после открытия защищённого Results

Доступ макросов восстанавливается до очистки сводок; защита индекса остаётся включённой. Отказы очистки показывают действие и фактический адрес, общий текст Excel — только как техническую подробность. Ошибки вывода не сопровождаются советами менять геометрию. Приняты 14 адресных No/Yes наборов (4970/0), реальные reopen Excel/File/Clear, нативные 181+6 и 13 own без kill. В основной и тяжёлой книгах изменён только VBA, остальные 120 ZIP-компонентов точны; нагрузки и результаты сохранены. Чистый шаблон для Git проверен отдельно. Полного ON/OFF+Focused нет. [Отчёт](../reports/SectionFormationProtection_2026-11-01.md).

'''
    progress.write_text(heading+'\n'+paragraph+body.lstrip('\n'),encoding='utf-8')
    print(json.dumps(dict(Status=result['Status'],ProofFiles=len(manifest),EvidenceBytes=archive.stat().st_size,EvidenceSHA256=result['EvidenceSHA256']),ensure_ascii=False))

if __name__ == '__main__':
    main()
