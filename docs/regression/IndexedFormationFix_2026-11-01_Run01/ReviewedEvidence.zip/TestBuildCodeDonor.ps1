﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Компилирует пять изменённых компонентов в чистой частной книге. Пользовательские данные не открывает.
param([string]$Tag='CodeDonor')
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM';$out=Join-Path $PSScriptRoot $Tag
if(Test-Path -LiteralPath $out){throw 'Fresh donor directory required'}
[void][IO.Directory]::CreateDirectory($out)
$path=Join-Path $out 'RC_Section_NDM.xlsm'
Copy-Item -LiteralPath (Join-Path $root 'docs/regression/IndexedResults_2026-11-01_Run01/CleanBuild/RC_Section_NDM.xlsm') -Destination $path
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestDonorOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestDonorOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135
 foreach($relative in @('src/Excel/CBatchResultWriter.cls','src/Excel/modWorkbookMessages.bas','src/Excel/modWorkbookCalculation.bas','tests/modTestCalculationSnapshot.bas','tests/modTestAudit02Api.bas')){
  $file=Get-Item -LiteralPath (Join-Path $root $relative)
  $component=$book.VBProject.VBComponents.Item($file.BaseName)
  $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  if($file.Extension -eq '.cls'){$code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')}else{$code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')}
  $component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines);$component.CodeModule.AddFromString($code)
 }
 $app.VBE.ActiveVBProject=$book.VBProject;$app.VBE.CommandBars.FindControl(1,578).Execute()
 $book.Save();$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book);$book=$null
 [ordered]@{Status='SAVED_COMPILED_PRIVATE_CODE_DONOR';Components=187;ChangedComponents=5}|ConvertTo-Json|Set-Content (Join-Path $out 'Build.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
