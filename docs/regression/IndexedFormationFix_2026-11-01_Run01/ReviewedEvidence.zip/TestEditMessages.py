from pathlib import Path

root = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')

def edit(path, old, new):
    p = root / path
    text = p.read_text(encoding='utf-8-sig')
    assert text.count(old) == 1, (path, text.count(old), old[:80])
    p.write_text(text.replace(old, new), encoding='utf-8', newline='\r\n')

edit('src/Excel/modWorkbookMessages.bas', "' Сохраняет исходную причину ошибки кнопки и технический источник для проверки разработчиком.", '''' Распознаёт только общее системное описание Excel, которое само по себе не называет причину.
' Код 1004 не используется как диагноз: он относится ко многим разным отказам.
Public Function IsUnexplainedExcelError(ByVal reason As String) As Boolean
    Select Case LCase$(Trim$(reason))
        Case "application-defined or object-defined error", "ошибка, определяемая приложением или объектом", _
                "ошибка, определенная приложением или объектом", "ошибка, определённая приложением или объектом"
            IsUnexplainedExcelError = True
    End Select
End Function

' Называет фактическое действие и место остановки; защиту указывает только после проверки листа.
' Исходное описание остаётся технической подробностью, а неизвестная причина не подменяется предположением.
Public Function WorkbookOperationFailureText(ByVal action As String, ByVal reason As String, _
        Optional ByVal location As String = "", Optional ByVal protectionBlocksMacros As Boolean = False) As String
    WorkbookOperationFailureText = "Не удалось " & action & "."
    If protectionBlocksMacros Then
        WorkbookOperationFailureText = WorkbookOperationFailureText & vbCrLf & vbCrLf & _
            "Лист защищён, и изменение его ячеек из макросов недоступно."
    ElseIf IsUnexplainedExcelError(reason) Then
        WorkbookOperationFailureText = WorkbookOperationFailureText & vbCrLf & vbCrLf & _
            "Excel не сообщил точную причину отказа."
    ElseIf Len(Trim$(reason)) > 0 Then
        WorkbookOperationFailureText = WorkbookOperationFailureText & vbCrLf & vbCrLf & reason
    End If
    If Len(location) > 0 Then WorkbookOperationFailureText = WorkbookOperationFailureText & vbCrLf & vbCrLf & "Место остановки:" & vbCrLf & location
    WorkbookOperationFailureText = WorkbookOperationFailureText & vbCrLf & vbCrLf & _
        "Возможное решение:" & vbCrLf & "Сохраните копию книги. Если ошибка повторяется в актуальной сборке, передайте разработчику полный текст этого сообщения."
    If IsUnexplainedExcelError(reason) Or protectionBlocksMacros Then WorkbookOperationFailureText = WorkbookOperationFailureText & _
        vbCrLf & vbCrLf & "Технические сведения:" & vbCrLf & "Сообщение Excel: " & reason
End Function

' Сохраняет исходную причину ошибки кнопки и технический источник для проверки разработчиком.''')
edit('src/Excel/modWorkbookMessages.bas', '    WorkbookErrorMessage = operation & ":" & vbCrLf & vbCrLf\n', '''    If IsUnexplainedExcelError(reason) Then reason = WorkbookOperationFailureText("выполнить действие в Excel", reason)
    WorkbookErrorMessage = operation & ":" & vbCrLf & vbCrLf
''')
edit('src/Excel/modWorkbookMessages.bas', '''        ByVal settings As CSystemSettingsReader) As String
    SectionFormationFailureText = SectionRecipeErrorText(reason)
''', '''        ByVal settings As CSystemSettingsReader, Optional ByVal inputStage As Boolean = True) As String
    If IsUnexplainedExcelError(reason) Then reason = WorkbookOperationFailureText("сформировать сечение", reason)
    SectionFormationFailureText = SectionRecipeErrorText(reason)
    If Not inputStage Then Exit Function ' После подготовки модели отказ вывода не означает ошибку размеров или слоёв импорта.
''')
edit('src/Excel/CBatchResultWriter.cls', '''    PrepareIndexedResultsWrite workbook ' UserInterfaceOnly не сохраняется в файле: доступ макросов нужен до первой очистки и смены заливки сводки.
    ClearSummaryBody SummaryClearRange(workbook)
    ClearStrengthSummary workbook
    ClearCrackSummary workbook
    ClearStabilitySummary workbook
End Sub
''', '''    On Error GoTo Failed
    Dim action As String, rangeName As String
    action = "подготовить доступ макросов к сводкам результатов": rangeName = "rngBatchSummary"
    PrepareIndexedResultsWrite workbook ' UserInterfaceOnly не сохраняется в файле: доступ макросов нужен до первой очистки и смены заливки сводки.
    action = "очистить общую сводку результатов"
    ClearSummaryBody SummaryClearRange(workbook)
    action = "очистить сводку прочности": rangeName = "rngStrengthSummaryAnchor"
    ClearStrengthSummary workbook
    action = "очистить сводку трещин": rangeName = "rngCrackSummaryAnchor"
    ClearCrackSummary workbook
    action = "очистить сводку устойчивости": rangeName = "rngStabilitySummaryAnchor"
    ClearStabilitySummary workbook
    Exit Sub
Failed:
    Dim number As Long, reason As String, origin As String, location As String, blocked As Boolean, target As Object
    number = Err.Number: reason = Err.Description: origin = Err.Source
    location = rangeName
    On Error Resume Next ' Диагностика не должна скрыть исходный отказ, если повреждено и само имя диапазона.
    Set target = workbook.Names.Item(rangeName).RefersToRange
    If Not target Is Nothing Then
        location = rangeName & ", " & target.Worksheet.Name & "!" & target.Address(False, False)
        blocked = target.Worksheet.ProtectContents And Not target.Worksheet.ProtectionMode
    End If
    On Error GoTo 0
    reason = WorkbookOperationFailureText(action, reason, location, blocked)
    Err.Raise number, "CBatchResultWriter.ClearSummary / " & origin, reason
End Sub
''')
edit('src/Excel/modWorkbookCalculation.bas', '''    Dim snapshot As CSectionPropertiesCalculator: Set snapshot = PrepareSectionSnapshot(section)
    Dim summary As CBatchResultWriter: Set summary = New CBatchResultWriter
''', '''    Dim snapshot As CSectionPropertiesCalculator: Set snapshot = PrepareSectionSnapshot(section)
    Dim outputStage As Boolean: outputStage = True ' Модель готова: последующие отказы относятся к сохранению или выводу, а не к вводу геометрии.
    Dim summary As CBatchResultWriter: Set summary = New CBatchResultWriter
''')
edit('src/Excel/modWorkbookCalculation.bas', '    description = SectionFormationFailureText(description, source, settings)\n', '    description = SectionFormationFailureText(description, source, settings, Not outputStage)\n')

edit('tests/modTestAudit02Api.bas', '    TestGeometryWarningParagraphs\n', '''    TestUnexplainedExcelMessages
    TestGeometryWarningParagraphs
''')
edit('tests/modTestAudit02Api.bas', "' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Проверяет все типизированные статусы каждого этапа", '''' -------------------- ДЛЯ ТЕСТОВ --------------------
' Общий отказ Excel не считается ошибкой геометрии; подтверждённая защита и технический текст показаны отдельно.
Private Sub TestUnexplainedExcelMessages()
    Dim raw As String, text As String, settings As CSystemSettingsReader
    raw = "Application-defined or object-defined error"
    text = WorkbookErrorMessage("Сечение не сформировано", 1004, "VBAProject", raw)
    TestCheck "presentation.excel.humanFirst", InStr(text, "Не удалось выполнить действие в Excel.") > 0
    TestCheck "presentation.excel.unknownHonest", InStr(text, "точную причину") > 0 And InStr(text, "Лист защищён") = 0
    TestCheck "presentation.excel.rawTechnical", InStr(text, "Сообщение Excel: " & raw) > InStr(text, "Технические сведения:")
    TestCheck "presentation.excel.code", InStr(text, "Код ошибки: 1004.") > 0
    TestCheck "presentation.excel.unknownNotInput", InStr(SectionFormationFailureText(raw, "AutoCAD", settings), "Слои, указанные") = 0
    text = WorkbookOperationFailureText("очистить общую сводку результатов", raw, "rngBatchSummary, Results!A1:AG50", True)
    text = SectionFormationFailureText(text, "AutoCAD", settings, False)
    TestCheck "presentation.excel.protection", InStr(text, "Лист защищён") > 0
    TestCheck "presentation.excel.place", InStr(text, "rngBatchSummary, Results!A1:AG50") > 0
    TestCheck "presentation.excel.outputNotInput", InStr(text, "Размеры и армирование") = 0 And InStr(text, "Проверьте активный чертёж") = 0
    text = WorkbookOperationFailureText("очистить сводку", "Именованный диапазон не найден.", "rngBatchSummary")
    TestCheck "presentation.excel.specificPreserved", InStr(text, "Именованный диапазон не найден.") > 0
    TestCheck "presentation.excel.specificNotGeneric", InStr(text, "точную причину") = 0
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет все типизированные статусы каждого этапа''')
print('Edited context messages and protection regression')
