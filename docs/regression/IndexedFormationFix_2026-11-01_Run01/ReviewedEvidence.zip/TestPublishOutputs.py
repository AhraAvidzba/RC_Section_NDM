"""ДЛЯ ТЕСТОВ: публикует только нативно проверенный код, с резервом и строгим сохранением данных."""
from pathlib import Path
import hashlib
import importlib
import json
import os
import shutil
import sys
import zipfile
from datetime import datetime, timezone

P = Path(__file__).resolve().parent
R = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
sys.path.insert(0, str(R/'tools/build_workbook'))
verify = importlib.import_module('Verify-CalculationSnapshotRelease')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def main():
    assert load(P/'DirectedPrimaryReview.json')['AssertionsPassed'] == 4970
    own = load(P/'AllOwnClosures.json')
    assert own['Status'] == 'ALL_OWN_TERMINAL'
    assert (datetime.now(timezone.utc) - datetime.fromisoformat(own['ObservedUTC'].replace('Z','+00:00'))).total_seconds() < 120
    assert len(own['Processes']) == 13
    for mode in ['Excel','File','Clear']:
        text = (P/('Final'+mode)/'Result.txt').read_text(encoding='utf-8-sig')
        assert text.startswith('PASS|Mode='+mode+'|Protected=True|UIOnly=True|') or (mode=='Clear' and text.strip()=='PASS|Mode=Clear|Protected=True|UIOnly=True'), text
    preparation = load(P/'PreparedOutputs.json')
    native_records = []
    for item in preparation['Books']:
        label = item['Label']
        source, candidate = Path(item['Source']), Path(item['Prepared'])
        assert digest(source) == item['SourceSHA256']
        assert digest(candidate) == item['PreparedSHA256']
        native = load(P/(label+'Native')/'Native.json')
        assert native['WorkbookSHA256'] == item['PreparedSHA256'] and native['Components'] == 187
        count, docs, errors = verify.verify_native_sources(P/(label+'Native')/'VBA_All_Code.txt', R)
        assert (count,docs,errors) == (181,6,[]), (label,errors)
        native_records.append(dict(Label=label,SourceComponents=count,DocumentComponents=docs,Errors=errors,
                                   ExportSHA256=digest(P/(label+'Native')/'VBA_All_Code.txt')))
    backup = P/'BeforePublication'
    backup.mkdir(exist_ok=False)
    receipts = []
    for item in preparation['Books']:
        if item['Label'] == 'Clean':
            continue
        target, candidate = Path(item['Source']), Path(item['Prepared'])
        label = item['Label']
        reserve = backup/label/target.name
        reserve.parent.mkdir(parents=True)
        shutil.copy2(target,reserve)
        assert digest(reserve) == item['SourceSHA256'] == digest(target)
        temporary = target.with_name(target.stem+'.ndm-update.tmp')
        assert not temporary.exists()
        shutil.copy2(candidate,temporary)
        try:
            os.replace(temporary,target)
            standard_updated = True
        except PermissionError:
            # Открытая пользователем книга остаётся открытой; исправленная копия имеет тот же basename.
            temporary.unlink()
            target = target.parent.with_name(target.parent.name+'_Fixed_2026-11-01')/target.name
            target.parent.mkdir(exist_ok=True)
            assert not target.exists(), target
            shutil.copy2(candidate,target)
            standard_updated = False
        assert digest(target) == item['PreparedSHA256']
        receipts.append(dict(Label=label,Destination=str(target),SHA256=digest(target),StandardPathUpdated=standard_updated,
                             Backup=str(reserve),BackupSHA256=digest(reserve),OnlyVBAChanged=True,UnchangedParts=item['UnchangedParts']))
        if label == 'Main':
            code = target.parent/'VBA_All_Code.txt'
            if code.exists():
                shutil.copy2(code,backup/'Main/VBA_All_Code.txt')
            shutil.copy2(P/'MainNative/VBA_All_Code.txt',code)
    heavy = next(item for item in receipts if item['Label']=='Heavy')
    folder = Path(heavy['Destination']).parent
    original_folder = R/'workbook/output/NDM_HeavyCircle_1232_30_2026-11-01'
    snapshot = original_folder/'NDM_HeavyCircle_1232_30.ndm'
    assert digest(snapshot) == 'E48038B73A6E4146A9AB6D594BC57B4E7C26C561D2DBAC3A9FE7496AFA96C9AA'
    if folder != original_folder:
        shutil.copy2(snapshot,folder/snapshot.name)
    for name in ['Прочитать.txt','Verification.json','NDM_HeavyCircle_1232_30_Комплект.zip']:
        old = original_folder/name
        if old.exists():
            shutil.copy2(old,backup/'Heavy'/name)
    verification = load(original_folder/'Verification.json')
    verification['WorkbookSHA256'] = heavy['SHA256']
    verification['FormationProtectionFix'] = dict(ChangedParts=['xl/vbaProject.bin'],UnchangedParts=heavy['UnchangedParts'],
        DataAndResultsByteExact=True,ActualReopenExcel=True,ActualReopenFile=True,ActualReopenClear=True,
        DirectedSuites=14,DirectedPassed=4970,DirectedFailed=0,FullOnOffPerformed=False)
    (folder/'Verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
    readme = (original_folder/'Прочитать.txt').read_text(encoding='utf-8-sig')
    readme = readme.replace('Код: актуальная версия 8854c08, 01.11.2026. Основная книга проекта не заменена.',
        'Код: исправление формирования после повторного открытия и понятные сообщения Excel, 01.11.2026.')
    readme += '\nИсправлено восстановление доступа макросов к защищённому Results до очистки сводок.\nДанные, расчётные результаты, настройки и иллюстрации сохранены побайтно.\nФормирование Excel/File и очистка проверены после настоящего повторного открытия.\nПолные ON/OFF+Focused после этой адресной правки не запускались.\n'
    (folder/'Прочитать.txt').write_text(readme,encoding='utf-8-sig')
    archive = folder/'NDM_HeavyCircle_1232_30_Комплект.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for file in [Path(heavy['Destination']),folder/snapshot.name,folder/'Прочитать.txt',folder/'Verification.json']:
            z.write(file,file.name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert hashlib.sha256(z.read(Path(heavy['Destination']).name)).hexdigest().upper() == heavy['SHA256']
    result = dict(Status='PUBLISHED_NATIVE_VERIFIED_FORMATION_FIX',PublishedUTC=datetime.now(timezone.utc).isoformat(),
        Books=receipts,NativeEquality=native_records,SnapshotSHA256=digest(snapshot),Package=str(archive),PackageSHA256=digest(archive),
        FullOnOffPerformed=False,UserApplicationsClosed=False)
    (P/'Publication.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))

if __name__ == '__main__':
    main()
