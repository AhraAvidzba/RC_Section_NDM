from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import copy,hashlib,json
P=Path(__file__).parent;R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
with ZipFile(P/'CandidateNativeSaved.xlsm') as z:vba=z.read('xl/vbaProject.bin')
rows=[]
for case,source in [('Main',R/'workbook/output/RC_Section_NDM.xlsm'),('Ready',R/'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm')]:
 if case=='Main':assert sha(source)=='A907AF64246A2CD9E5C174561CCA7A6502D2C14B25808083707DF1869C5DA1C5'
 target=P/'ReleaseCandidate'/case/'RC_Section_NDM.xlsm';target.parent.mkdir(parents=True,exist_ok=True)
 with ZipFile(source) as a,ZipFile(target,'w',ZIP_DEFLATED) as b:
  for item in a.infolist():b.writestr(copy.copy(item),vba if item.filename=='xl/vbaProject.bin' else a.read(item.filename))
 with ZipFile(source) as a,ZipFile(target) as b:
  changed=[n for n in a.namelist() if a.read(n)!=b.read(n)];assert changed==['xl/vbaProject.bin'],changed
  rows.append(dict(Case=case,Source=str(source),SourceSHA256=sha(source),Candidate=str(target),CandidateSHA256=sha(target),Entries=len(a.namelist()),Changed=changed,OtherPartsByteIdentical=len(a.namelist())-1))
(P/'PackagePreparation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False,indent=2))
