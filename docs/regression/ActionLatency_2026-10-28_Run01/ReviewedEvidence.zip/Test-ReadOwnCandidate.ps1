﻿# ==========================================================================
# ДЛЯ ТЕСТОВ: читает объектную модель только собственного остановленного Excel.
# ==========================================================================
# Не вызывает Run, не меняет проект, не завершает процесс и не закрывает книгу.
param([int]$TestProcessId=32028,[long]$ExpectedStartTicks=639284773488278557)
$ErrorActionPreference='Stop'
$process=Get-Process -Id $TestProcessId -ErrorAction Stop
if($process.ProcessName -ne 'EXCEL' -or $process.StartTime.ToUniversalTime().Ticks -ne $ExpectedStartTicks){throw 'Own Excel process identity mismatch'}
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class NdmTestExcelNativeReader {
    public delegate bool TestEnumWindow(IntPtr h,IntPtr p);
    [DllImport("user32.dll")] public static extern bool EnumWindows(TestEnumWindow f,IntPtr p);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h,TestEnumWindow f,IntPtr p);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder b,int n);
    [DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr h,uint id,ref Guid iid,[MarshalAs(UnmanagedType.Interface)] out object obj);
    public static string TestClass(IntPtr h){var s=new StringBuilder(256);GetClassName(h,s,s.Capacity);return s.ToString();}
    public static IntPtr TestFindGrid(uint pid){
        IntPtr grid=IntPtr.Zero;
        EnumWindows((h,p)=>{
            uint actual;GetWindowThreadProcessId(h,out actual);
            if(actual==pid && TestClass(h)=="XLMAIN"){
                EnumChildWindows(h,(c,q)=>{if(TestClass(c)=="EXCEL7"){grid=c;return false;}return true;},IntPtr.Zero);
            }
            return grid==IntPtr.Zero;
        },IntPtr.Zero);
        return grid;
    }
}
'@
$grid=[NdmTestExcelNativeReader]::TestFindGrid([uint32]$TestProcessId)
if($grid -eq [IntPtr]::Zero){throw 'Own Excel native grid not found'}
$iid=[Guid]'00020400-0000-0000-C000-000000000046'
$native=$null
$hr=[NdmTestExcelNativeReader]::AccessibleObjectFromWindow($grid,[uint32]4294967280,[ref]$iid,[ref]$native)
if($hr -ne 0 -or -not $native){throw ('Own Excel native object HRESULT='+$hr)}
$app=$native.Application
[uint32]$actualPid=0
[void][NdmTestExcelNativeReader]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$actualPid)
if($actualPid -ne $TestProcessId){throw 'Native Excel application belongs to another process'}
$result=[ordered]@{Schema=2;Checked=(Get-Date).ToString('o');PID=$TestProcessId;StartTicks=[string]$ExpectedStartTicks;Grid=[long]$grid;ApplicationPID=$actualPid;Books=@();ProjectModes=@();RunCommands=@();Selection=$null;ReadErrors=@()}
try{
    foreach($book in $app.Workbooks){$result.Books+=,[ordered]@{FullName=[string]$book.FullName;ReadOnly=[bool]$book.ReadOnly;Saved=[bool]$book.Saved}}
}catch{$result.ReadErrors+=('Books: '+$_.Exception.Message)}
# -------------------- ДЛЯ ТЕСТОВ --------------------
# Прямой getter отличает отсутствующее COM-свойство от действительного нуля.
function Test-ReadProperty([object]$Target,[string]$Name){
    if($null -eq $Target){throw ('Null COM target: '+$Name)}
    return ,$Target.GetType().InvokeMember($Name,[Reflection.BindingFlags]::GetProperty,$null,$Target,$null)
}
try{
    $vbe=Test-ReadProperty $app 'VBE'
    $projects=Test-ReadProperty $vbe 'VBProjects'
    $count=Test-ReadProperty $projects 'Count'
    for($index=1;$index -le [int]$count;$index++){
        $project=$projects.Item($index)
        $mode=Test-ReadProperty $project 'Mode'
        $result.ProjectModes+=,[ordered]@{Name=[string](Test-ReadProperty $project 'Name');Mode=$mode}
    }
}catch{$result.ReadErrors+=('ProjectModes: '+$_.Exception.Message)}
try{
    $bars=Test-ReadProperty $vbe 'CommandBars'
    $runBar=$bars.Item('Run')
    foreach($control in $runBar.Controls){$result.RunCommands+=,[ordered]@{ID=[int]$control.Id;Caption=[string]$control.Caption;Enabled=[bool]$control.Enabled}}
}catch{$result.ReadErrors+=('RunCommands: '+$_.Exception.Message)}
try{
    $pane=Test-ReadProperty $vbe 'ActiveCodePane'
    if($pane){
        $r1=0;$c1=0;$r2=0;$c2=0
        $pane.GetSelection([ref]$r1,[ref]$c1,[ref]$r2,[ref]$c2)
        $result.Selection=[ordered]@{Module=[string]$pane.CodeModule.Name;StartRow=$r1;EndRow=$r2;Text=[string]$pane.CodeModule.Lines($r1,[Math]::Max(1,$r2-$r1+1))}
    }
}catch{$result.ReadErrors+=('Selection: '+$_.Exception.Message)}
$result|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $PSScriptRoot ('NativeRuntimeV2_'+$TestProcessId+'.json')) -Encoding UTF8
$result|ConvertTo-Json -Depth 6
