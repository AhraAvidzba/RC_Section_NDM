Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Измеряет только частную копию, не меняя входы и результаты штатных методов.
Private Declare PtrSafe Function TestQpc Lib "kernel32" Alias "QueryPerformanceCounter" (ByRef value As Currency) As Long
Private Declare PtrSafe Function TestQpf Lib "kernel32" Alias "QueryPerformanceFrequency" (ByRef value As Currency) As Long
Private mTestStart As Object, mTestValue As Object, mTestCount As Object
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает монотонный таймер высокой точности без Excel COM.
Private Function TestNow() As Double
 Dim ticks As Currency, frequency As Currency
 TestQpc ticks: TestQpf frequency: TestNow = ticks / frequency
End Function
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отделяет счётчики независимых пользовательских действий.
Public Sub TestReset()
 Set mTestStart = CreateObject("Scripting.Dictionary")
 Set mTestValue = CreateObject("Scripting.Dictionary")
 Set mTestCount = CreateObject("Scripting.Dictionary")
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запоминает начало измеряемого участка.
Public Sub TestBegin(ByVal name As String)
 mTestStart(name) = TestNow()
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Суммирует повторения участка, сохраняя число фактических вызовов.
Public Sub TestEnd(ByVal name As String)
 If Not mTestValue.Exists(name) Then mTestValue.Add name, 0#: mTestCount.Add name, 0&
 mTestValue(name) = mTestValue(name) + TestNow() - CDbl(mTestStart(name))
 mTestCount(name) = mTestCount(name) + 1&
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Даёт Excel обработать ожидающие сообщения после возврата штатной функции.
Public Function TestIdle() As Double
 Dim started As Double, i As Long: started = TestNow()
 For i = 1 To 3: DoEvents: Next i
 TestIdle = TestNow() - started
End Function
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает компактные времена, без геометрии и вычисленных результатов.
Public Function TestDump() As String
 Dim key As Variant
 For Each key In mTestValue.Keys
  TestDump = TestDump & CStr(key) & vbTab & Replace$(CStr(mTestValue(key)), ",", ".") & vbTab & CStr(mTestCount(key)) & vbLf
 Next key
End Function
