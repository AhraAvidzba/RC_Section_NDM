Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Подготавливает файловый источник из той же геометрии частной измерительной книги.
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет геометрию без генерации, сохраняя точные границы и физические характеристики.
Public Sub TestSaveGeometryFile()
 Dim model As CSectionModel: Set model = ReadFormedSectionFromResults(ThisWorkbook)
 Dim settings As CSystemSettingsReader: Set settings = New CSystemSettingsReader
 settings.LoadFromWorkbook ThisWorkbook
 Dim units As CUnitSystem: Set units = New CUnitSystem: units.LoadFromSettings settings
 Dim writer As CNDMResultsWriter: Set writer = New CNDMResultsWriter
 Dim saved As CCalculationSnapshot
 Set saved = writer.PrepareGeometryPreviewSnapshot(ThisWorkbook, model, PrepareSectionSnapshot(model), units)
 Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
 store.SaveFile ThisWorkbook, saved
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт ошибку внешнему измерителю без модального окна редактора VBA.
Public Function TestCalculateSafe() As String
 On Error GoTo Failed
 TestCalculateSafe = RunSectionCalculationForWorkbook(ThisWorkbook, False)
 Exit Function
Failed:
 TestCalculateSafe = "TEST_CALCULATION_ERROR: " & CStr(Err.Number) & " " & Err.Description
End Function
