﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сравнивает короткие штатные команды на частных копиях одной пользовательской книги.
param([string[]]$Cases=@('Current'))
$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
$manifest=Get-Content -LiteralPath (Join-Path $directory 'Preparation.json') -Raw|ConvertFrom-Json
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestLatencyOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=New-Object 'System.Collections.Generic.List[object]'
if(Test-Path (Join-Path $directory 'CandidateMeasurements.json')){foreach($record in (Get-Content (Join-Path $directory 'CandidateMeasurements.json') -Raw|ConvertFrom-Json)){$records.Add($record)}}

# Меняет только имеющуюся настройку в частной книге; список ключей не расширяет.
function Set-TestLatencySetting([string]$Key,[string]$Value){
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2
 for($r=1;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}}
 throw ('Unknown setting '+$Key)
}

# Фиксирует внешний интервал включая возврат COM и проверку готовности после команды.
function Invoke-TestLatencyAction([string]$Action,[string]$Fixture,[int]$Repeat){
 $method=if($Action-eq'Form'){'FormSectionForWorkbook'}else{'RunSectionCalculationForWorkbook'}
 $watch=[Diagnostics.Stopwatch]::StartNew();$message='';$errorText=''
 try{if($Action-eq'Form'){$message=[string]$app.Run("'$($book.Name)'!$method",$book)}else{$message=[string]$app.Run("'$($book.Name)'!$method",$book,$false)}}catch{$errorText=$_.Exception.ToString()}
 $seconds=$watch.Elapsed.TotalSeconds
 $post=[Diagnostics.Stopwatch]::StartNew();$ready=$app.Ready;$state=$app.CalculationState;$post.Stop()
 $record=[ordered]@{Case='Candidate';Commit=$case.Commit;Fixture=$Fixture;Action=$Action;Repeat=$Repeat;ExternalSeconds=$seconds;PostReadySeconds=$post.Elapsed.TotalSeconds;Ready=$ready;CalculationState=$state;Message=$message;Error=$errorText;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')}
 $records.Add($record);$records|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $directory 'CandidateMeasurements.json') -Encoding UTF8
 Write-Output (('{0} {1} {2} #{3}: {4:N3}s; ready={5}; error={6}'-f$case.Name,$Fixture,$Action,$Repeat,$seconds,$ready,[bool]$errorText))
 if($errorText){throw $errorText}
}


$TestProcessId=24724;$ExpectedStartTicks=639287879205499768
$process=Get-Process -Id $TestProcessId -ErrorAction Stop
if($process.ProcessName -ne 'EXCEL' -or $process.StartTime.ToUniversalTime().Ticks -ne $ExpectedStartTicks){throw 'Own Excel process identity mismatch'}
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class NdmTestExcelNativeReader {
    public delegate bool TestEnumWindow(IntPtr h,IntPtr p);
    [DllImport("user32.dll")] public static extern bool EnumWindows(TestEnumWindow f,IntPtr p);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h,TestEnumWindow f,IntPtr p);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder b,int n);
    [DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr h,uint id,ref Guid iid,[MarshalAs(UnmanagedType.Interface)] out object obj);
    public static string TestClass(IntPtr h){var s=new StringBuilder(256);GetClassName(h,s,s.Capacity);return s.ToString();}
    public static IntPtr TestFindGrid(uint pid){
        IntPtr grid=IntPtr.Zero;
        EnumWindows((h,p)=>{
            uint actual;GetWindowThreadProcessId(h,out actual);
            if(actual==pid && TestClass(h)=="XLMAIN"){
                EnumChildWindows(h,(c,q)=>{if(TestClass(c)=="EXCEL7"){grid=c;return false;}return true;},IntPtr.Zero);
            }
            return grid==IntPtr.Zero;
        },IntPtr.Zero);
        return grid;
    }
}
'@
$grid=[NdmTestExcelNativeReader]::TestFindGrid([uint32]$TestProcessId)
if($grid -eq [IntPtr]::Zero){throw 'Own Excel native grid not found'}
$iid=[Guid]'00020400-0000-0000-C000-000000000046'
$native=$null
$hr=[NdmTestExcelNativeReader]::AccessibleObjectFromWindow($grid,[uint32]4294967280,[ref]$iid,[ref]$native)
if($hr -ne 0 -or -not $native){throw ('Own Excel native object HRESULT='+$hr)}
$app=$native.Application
[uint32]$actualPid=0
[void][NdmTestExcelNativeReader]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$actualPid)
if($actualPid -ne $TestProcessId){throw 'Native Excel application belongs to another process'}

$case=$manifest.Cases|Where-Object Name -eq 'Current'
$owned=$TestProcessId;$ticks=$ExpectedStartTicks
$book=$app.Workbooks.Item(1)
if($book.FullName -cne $case.Path -or $app.Workbooks.Count-ne1 -or $book.VBProject.Mode-ne2){throw 'Own diagnostic workbook identity/design gate failed'}
$body=[string]$book.VBProject.VBComponents.Item('modSectionSnapshot').CodeModule.Lines(1,$book.VBProject.VBComponents.Item('modSectionSnapshot').CodeModule.CountOfLines)
if($body-notmatch'TSavedBoundaryLayout'){throw 'Candidate was not imported'}
try{
 $app.Visible=$true;$app.EnableEvents=$true;$app.Calculation=-4105
 foreach($n in 1..3){Invoke-TestLatencyAction 'Calculate' 'UserSaved_Auto005' $n}
 foreach($n in 1..2){Invoke-TestLatencyAction 'Form' 'UserSaved_Auto005' $n;Invoke-TestLatencyAction 'Calculate' 'UserSaved_Auto005_Reformed' $n}
 Set-TestLatencySetting 'Mesh.StepMode' 'Auto 0.1'
 foreach($n in 1..3){Invoke-TestLatencyAction 'Form' 'UserSaved_L_Auto01' $n;Invoke-TestLatencyAction 'Calculate' 'UserSaved_L_Auto01' $n}
}catch{[IO.File]::WriteAllText((Join-Path $directory 'CandidateResumeFailure.txt'),$_.Exception.ToString());throw}
finally{
 $app.EnableEvents=$false;$native=$null;$book.Close($false);$book=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();$app.Quit();$app=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
}
