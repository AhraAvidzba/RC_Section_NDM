from pathlib import Path
p=Path(__file__).parent
s=(p/'Test-Baseline.ps1').read_text(encoding='utf-8-sig').replace("@('Current','PriorAccepted','BeforeFileChanges')","@('Current')",1)
s=s.replace("if(Test-Path (Join-Path $directory 'BaselineMeasurements.json')){foreach($record in (Get-Content (Join-Path $directory 'BaselineMeasurements.json') -Raw|ConvertFrom-Json)){$records.Add($record)}}",'')
s=s.replace('BaselineMeasurements.json','ProfileMeasurements.json').replace("$case.Name+'Ownership.json'","$case.Name+'ProfileOwnership.json'").replace("$case.Name+'Closure.json'","$case.Name+'ProfileClosure.json'")
needle=" $watch=[Diagnostics.Stopwatch]::StartNew();$message='';$errorText=''"
s=s.replace(needle," [void]$app.Run(\"'$($book.Name)'!modTestActionProfiler.TestReset\")\n"+needle)
s=s.replace('$post.Stop()', '''$post.Stop()
 $idle=[double]$app.Run("'$($book.Name)'!modTestActionProfiler.TestIdle")
 $phases=[ordered]@{}
 $dump=[string]$app.Run("'$($book.Name)'!modTestActionProfiler.TestDump")
 foreach($row in $dump -split "`n"){if(-not$row.Trim()){continue};$v=$row.Trim() -split "`t";$phases[$v[0]]=[ordered]@{Seconds=[double]::Parse($v[1],[Globalization.CultureInfo]::InvariantCulture);Calls=[int]$v[2]}}''')
s=s.replace('ExternalSeconds=$seconds;','ExternalSeconds=$seconds;IdleDrainSeconds=$idle;Phases=$phases;')
start=s.index("  $out=Join-Path $directory ('Native/'")
end=s.index('  foreach($n in 1..2)',start)
s=s[:start]+s[end:]
needle="  $app.Visible=$true;$book.Worksheets.Item('Config').Activate();$app.EnableEvents=$true;$app.Calculation=-4105"
insert='''  $project=$book.VBProject
  $component=$project.VBComponents.Add(1);$component.Name='modTestActionProfiler';$component.CodeModule.AddFromString([IO.File]::ReadAllText((Join-Path $directory 'modTestActionProfiler.bas'),[Text.Encoding]::UTF8))
  foreach($file in Get-ChildItem (Join-Path $directory 'Instrumented') -Filter '*.txt'){
   $code=$project.VBComponents.Item($file.BaseName).CodeModule
   $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString([IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8))
  }
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578)
  if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private profiler compilation failed'}
  $compile=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
'''
assert needle in s
s=s.replace(needle,insert+needle)
needle="  foreach($n in 1..3){Invoke-TestLatencyAction 'Form' 'UserSaved_L_Auto01' $n;Invoke-TestLatencyAction 'Calculate' 'UserSaved_L_Auto01' $n}"
extra='''
  Set-TestLatencySetting 'Plot.Enabled' 'No'
  foreach($n in 1..3){Invoke-TestLatencyAction 'Calculate' 'Auto01_NoPlot' $n}
  Set-TestLatencySetting 'General.ReformatResultsEnabled' 'No'
  foreach($n in 1..3){Invoke-TestLatencyAction 'Calculate' 'Auto01_NoPlot_MinimalFormatting' $n}
'''
assert needle in s
s=s.replace(needle,needle+extra)
(p/'Test-Profile.ps1').write_text(s,encoding='utf-8-sig')
