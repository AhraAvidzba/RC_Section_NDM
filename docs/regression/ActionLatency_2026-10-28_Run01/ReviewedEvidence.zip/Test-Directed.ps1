﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Сравнивает короткие штатные команды на частных копиях одной пользовательской книги.
param([string[]]$Cases=@('Current'),[string[]]$Modes=@('No','Yes'))
$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
$manifest=Get-Content -LiteralPath (Join-Path $directory 'Preparation.json') -Raw|ConvertFrom-Json
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestLatencyOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=New-Object 'System.Collections.Generic.List[object]'
if(Test-Path (Join-Path $directory 'DirectedMeasurements.json')){foreach($record in (Get-Content (Join-Path $directory 'DirectedMeasurements.json') -Raw|ConvertFrom-Json)){$records.Add($record)}}

# Меняет только имеющуюся настройку в частной книге; список ключей не расширяет.
function Set-TestLatencySetting([string]$Key,[string]$Value){
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2
 for($r=1;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}}
 throw ('Unknown setting '+$Key)
}

# Фиксирует внешний интервал включая возврат COM и проверку готовности после команды.
function Invoke-TestLatencyAction([string]$Action,[string]$Fixture,[int]$Repeat){
 $method=if($Action-eq'Form'){'FormSectionForWorkbook'}else{'RunSectionCalculationForWorkbook'}
 $watch=[Diagnostics.Stopwatch]::StartNew();$message='';$errorText=''
 try{if($Action-eq'Form'){$message=[string]$app.Run("'$($book.Name)'!$method",$book)}else{$message=[string]$app.Run("'$($book.Name)'!$method",$book,$false)}}catch{$errorText=$_.Exception.ToString()}
 $seconds=$watch.Elapsed.TotalSeconds
 $post=[Diagnostics.Stopwatch]::StartNew();$ready=$app.Ready;$state=$app.CalculationState;$post.Stop()
 $record=[ordered]@{Case='Candidate';Commit=$case.Commit;Fixture=$Fixture;Action=$Action;Repeat=$Repeat;ExternalSeconds=$seconds;PostReadySeconds=$post.Elapsed.TotalSeconds;Ready=$ready;CalculationState=$state;Message=$message;Error=$errorText;AtUTC=[DateTimeOffset]::UtcNow.ToString('o')}
 $records.Add($record);$records|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $directory 'DirectedMeasurements.json') -Encoding UTF8
 Write-Output (('{0} {1} {2} #{3}: {4:N3}s; ready={5}; error={6}'-f$case.Name,$Fixture,$Action,$Repeat,$seconds,$ready,[bool]$errorText))
 if($errorText){throw $errorText}
}

foreach($case in $manifest.Cases){
 if($case.Name-notin$Cases){continue}
 $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'RAM/commit reserve insufficient'}
 $app=$null;$book=$null;$project=$null;$component=$null;$owned=0;$ticks=0
 try{
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][TestLatencyOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Source=$case.Path;AvailableRAMMB=$m.AvailableMBytes;CommitFreeBytes=($m.CommitLimit-$m.CommittedBytes)}|ConvertTo-Json|Set-Content (Join-Path $directory ($case.Name+'DirectedOwnership.json')) -Encoding UTF8
  $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
  $book=$app.Workbooks.Open($case.Path,0,$false)
  if($case.Name-ne'Current'){
   $sheet=$book.Worksheets.Item('Config');$sheet.Range('A150').Value2='Plot.LoadCase';$sheet.Range('B150').Value2='Worst'
   $sheet.Range('A151').Value2='AutoCAD.Export.CombinationID';$sheet.Range('B151').Value2='Worst'
   $book.Names.Item('rngSystemSettings').RefersTo='=Config!$A$3:$E$151'
   $sheet=$null
  }
  $project=$book.VBProject;$code=$project.VBComponents.Item('modSectionSnapshot').CodeModule
  $body=[IO.File]::ReadAllText((Join-Path $directory 'Candidate/modSectionSnapshot.bas'),[Text.Encoding]::UTF8)
  $body=[regex]::Replace($body,'(?m)^Attribute [^\r\n]*\r?\n','')
  $code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
  $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578)
  if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Candidate compilation failed'}
  $compile=$null;$code=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $app.Visible=$true;$book.Worksheets.Item('Config').Activate();$app.EnableEvents=$true;$app.Calculation=-4105
  $book.SaveCopyAs((Join-Path $directory 'CandidateNativeSaved.xlsm'))
  foreach($mode in $Modes){
   Set-TestLatencySetting 'General.DiagramExtension' $mode
   foreach($method in @('RunConcreteGeometrySnapshotTests','RunGeometryPreviewStorageTests','RunCalculationSnapshotTests')){
    $watch=[Diagnostics.Stopwatch]::StartNew()
    $log=[string]$app.Run("'$($book.Name)'!modTestCalculationSnapshot.$method")
    $elapsed=$watch.Elapsed.TotalSeconds
    [IO.File]::WriteAllText((Join-Path $directory ($method+'_'+$mode+'.txt')),$log,[Text.Encoding]::UTF8)
    [ordered]@{Mode=$mode;Method=$method;Seconds=$elapsed;LogLength=$log.Length}|ConvertTo-Json -Compress|Write-Output
    if($log-match'(?im)^(?:FAIL|RUNTIME)' -or $log-notmatch'TOTAL[ _][^\r\n]+(?:failed=0|/0)') {throw ('Directed primary review required: '+$method+' '+$mode)}
   }
  }

 }catch{[IO.File]::WriteAllText((Join-Path $directory 'DirectedFailure.txt'),$_.Exception.ToString());throw}
 finally{
  $code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
  $absent=$false;$w=[Diagnostics.Stopwatch]::StartNew()
  do{
   try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'PID identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}}
   Start-Sleep -Milliseconds 250
  }while($w.Elapsed.TotalSeconds-lt15)
  [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $directory ($case.Name+'DirectedClosure.json')) -Encoding UTF8
  if(-not$absent){throw 'Own Excel did not exit; not force-closed'}
 }
}
