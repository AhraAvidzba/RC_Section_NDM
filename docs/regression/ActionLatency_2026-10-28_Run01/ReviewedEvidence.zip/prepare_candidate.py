from pathlib import Path
import re,hashlib,json
D=Path(__file__).parent; R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
p=R/'src/Excel/modSectionSnapshot.bas';s=p.read_text(encoding='utf-8-sig');original=s
marker="Private mSnapshotTableReadCount As Long"
i=s.index(marker);i=s.index('\n',i)+1
s=s[:i]+'''
' Положение и единицы общих колонок одной неизменяемой матрицы проверяются один раз.
' Числовые значения каждой строки по-прежнему проходят отдельную строгую проверку.
Private Type TSavedBoundaryLayout
    XColumn As Long
    YColumn As Long
    AreaColumn As Long
    IxColumn As Long
    IyColumn As Long
    IxyColumn As Long
    WidthColumn As Long
    HeightColumn As Long
    RotationColumn As Long
    LengthUnit As String
    AreaUnit As String
    InertiaUnit As String
End Type
'''+s[i:]
needle='    Dim item As Variant, region As CConcreteRegion, query As CSectionGeometryQuery: Set query = New CSectionGeometryQuery'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
    Dim loopNames As Object, actualLoopNames As Object
    Set loopNames = CreateObject("Scripting.Dictionary"): loopNames.CompareMode = vbBinaryCompare
    Set actualLoopNames = CreateObject("Scripting.Dictionary"): actualLoopNames.CompareMode = vbBinaryCompare
    Dim layout As TSavedBoundaryLayout, layoutReady As Boolean ' Один заголовок для всех элементов этого чтения; между действиями ничего не кэшируется.
''')
s=s.replace('Set region = SavedConcreteRegion(contours, query)','Set region = SavedConcreteRegion(contours, query, loopNames, actualLoopNames)')
needle='        ValidateSavedBoundaryProperties region, geometryData, CLng(rows.Item(CStr(item))), geometryAnchor'
assert s.count(needle)==1
s=s.replace(needle,'''        If Not layoutReady Then
            ReadSavedBoundaryLayout geometryData, geometryAnchor, layout
            layoutReady = True
        End If
        ValidateSavedBoundaryProperties region, geometryData, CLng(rows.Item(CStr(item))), geometryAnchor, query, layout''')
s=s.replace('Private Function SavedConcreteRegion(ByVal contours As CSectionContours, ByVal query As CSectionGeometryQuery) As CConcreteRegion', '''Private Function SavedConcreteRegion(ByVal contours As CSectionContours, ByVal query As CSectionGeometryQuery, _
        ByVal loops As Object, ByVal actualLoops As Object) As CConcreteRegion''')
needle='    Dim loops As Object: Set loops = CreateObject("Scripting.Dictionary"): loops.CompareMode = vbBinaryCompare\n    Dim actualLoops As Object: Set actualLoops = CreateObject("Scripting.Dictionary"): actualLoops.CompareMode = vbBinaryCompare'
assert s.count(needle)==1
s=s.replace(needle,'''    loops.RemoveAll: actualLoops.RemoveAll ' Эти рабочие словари принадлежат одному чтению и очищаются для каждого элемента; возвращаемая область от них не зависит.''')
start=s.index('Private Sub ValidateSavedBoundaryProperties(')
end=s.index('\nEnd Sub',start)+len('\nEnd Sub')
body=s[start:end]
header_start=body.index('    Dim xColumn As Long:')
header_end=body.index('    If SavedBoundaryNumber(data, row, widthColumn')
header=body[header_start:header_end]
fields={'xColumn':'XColumn','yColumn':'YColumn','areaColumn':'AreaColumn','ixColumn':'IxColumn','iyColumn':'IyColumn','ixyColumn':'IxyColumn','widthColumn':'WidthColumn','heightColumn':'HeightColumn','rotationColumn':'RotationColumn','lengthUnit':'LengthUnit','areaUnit':'AreaUnit','inertiaUnit':'InertiaUnit'}
header=re.sub(r'    Dim (\w+) As (?:Long|String): ', '    ',header)
for var,field in fields.items():header=re.sub(r'\b'+var+r'\b','layout.'+field,header)
newhelper="""' Проверяет заголовок одной матрицы до чтения свойств её первого точного элемента.
' Адреса и требования совпадают с построчной проверкой; текущие единицы Config не используются.
Private Sub ReadSavedBoundaryLayout(ByRef data As Variant, ByVal anchor As Object, ByRef layout As TSavedBoundaryLayout)
"""+header+'End Sub\n\n'
signature_end=body.index('\n    Dim query')
signature=body[:signature_end]
signature=signature.replace('ByVal anchor As Object)', 'ByVal anchor As Object, _\n        ByVal query As CSectionGeometryQuery, ByRef layout As TSavedBoundaryLayout)')
rest=body[header_end:]
for var,field in fields.items():rest=re.sub(r'\b'+var+r'\b','layout.'+field,rest)
s=s[:start]+newhelper+"' Сверяет каждую строку с точной границей тем же общим валидатором.\n' Общая шапка подготовлена для этого чтения; данные и числовые допуски не кэшируются.\n"+signature+'\n'+rest+s[end:]
oldrun='''    Dim snapshotRun As Variant, geometryAnchor As Object
    Set geometryAnchor = workbook.Names.Item("rngNDMSectionGeometry").RefersToRange
    If CStr(geometryAnchor.Value2) = "RunID" Then snapshotRun = geometryAnchor.Offset(1, 0).Value2'''
newrun='''    Dim snapshotRun As Variant, geometryData As Variant
    geometryData = ReadAnchoredResultTable(workbook, "rngNDMSectionGeometry") ' Номер запуска берётся из того же источника Excel/File, что и контуры; справочный Results в File не участвует.
    If HasResultTableRows(geometryData) Then
        If CStr(geometryData(1, 1)) = "RunID" Then snapshotRun = geometryData(2, 1)
    End If'''
assert s.count(oldrun)==1 and original.count(oldrun)==1
s=s.replace(oldrun,newrun)
assert s!=original
out=D/'Candidate';out.mkdir(exist_ok=True)
(out/'modSectionSnapshot.bas').write_text(s,encoding='utf-8-sig')
(out/'modSectionSnapshot.FileSourceFixOnly.bas').write_text(original.replace(oldrun,newrun),encoding='utf-8-sig')
testpath=R/'tests/modTestCalculationSnapshot.bas';test=testpath.read_text(encoding='utf-8-sig')
needle='''        Set preview = store.LoadFile(ThisWorkbook)
        store.ClearReference ThisWorkbook'''
assert test.count(needle)==1
test=test.replace(needle,'''        Set preview = store.LoadFile(ThisWorkbook)
        Dim sheetRunCell As Object: Set sheetRunCell = ThisWorkbook.Names.Item("rngNDMSectionGeometry").RefersToRange.Offset(1, 0)
        Dim previousSheetRun As Variant: previousSheetRun = sheetRunCell.Value2
        sheetRunCell.Value2 = -1# ' Справочная геометрия намеренно относится к другому запуску; источник File обязан оставаться самодостаточным.
        Dim staleRunError As Long
        On Error Resume Next
        Err.Clear
        Set beforeModel = ReadFormedSectionFromResults(ThisWorkbook)
        staleRunError = Err.Number
        Err.Clear
        On Error GoTo 0
        sheetRunCell.Value2 = previousSheetRun
        TestSnapshotCheck CStr(geometryMode) & ".source.fileIgnoresStaleSheetRunID", staleRunError = 0
        store.ClearReference ThisWorkbook''')
(out/'modTestCalculationSnapshot.bas').write_text(test,encoding='utf-8-sig')
(out/'SourceManifest.json').write_text(json.dumps({'OriginalSHA256':hashlib.sha256(p.read_bytes()).hexdigest().upper(),'CandidateSHA256':hashlib.sha256((out/'modSectionSnapshot.bas').read_bytes()).hexdigest().upper(),'Changes':['Hoist header discovery within one boundary matrix read','Reuse two empty scratch dictionaries per read','Reuse existing geometry query for pure property validation'],'NoGeometryMathToleranceOrValidationRuleChanges':True},indent=2),encoding='utf-8')
print('Prepared isolated candidate',len(s),'characters')
