from pathlib import Path
import copy,hashlib,json,re,zipfile
P=Path(__file__).parent
R=Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
E=R/'docs/regression/ActionLatency_2026-10-28_Run01'
E.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
publication=json.loads((P/'Publication.json').read_text(encoding='utf-8-sig'))
for item in publication['Books']:assert sha(Path(item['Path']))==item['AfterSHA256']
assert sha(R/'workbook/output/VBA_All_Code.txt')==publication['AllCodeSHA256']
for case in ['Main','Ready']:
 assert json.loads((P/f'SourceEquality_{case}.json').read_text(encoding='utf-8-sig'))['Passed']
reviews=[]
for f in P.glob('*Tests_*.txt'):
 text=f.read_text(encoding='utf-8-sig')
 errors=[x for x in text.splitlines() if re.match(r'^(FAIL|RUNTIME)',x)]
 total=[x for x in text.splitlines() if x.startswith('TOTAL')]
 assert not errors and len(total)==1,(f,errors,total)
 reviews.append(dict(File=f.name,SHA256=sha(f),Total=total[0],WholePrimaryRead=True,Errors=errors))
(P/'DirectedPrimaryReview.json').write_text(json.dumps(reviews,ensure_ascii=False,indent=2),encoding='utf-8')
stale=[]
for f in P.glob('Final_RunFileGeometryAuthorityTests_*.txt'):
 stale += [dict(File=f.name,Assertion=line) for line in f.read_text(encoding='utf-8-sig').splitlines() if 'source.fileIgnoresStaleSheetRunID' in line]
assert len(stale)==4 and all(v['Assertion'].startswith('PASS ') for v in stale)
processed=dict(Status='PASS_DIRECTED_ACTION_LATENCY_AND_FILE_SOURCE',
 Scope='Short directed performance/source checks only; no new full ON/OFF, UI or Focused run',
 SourceInputs='Original user-saved workbook A907AF64... preserved in local backup; all non-VBA ZIP parts retained in published workbook',
 FinalDirected=dict(No='FileAuthority125/0; Boundaries123/0; Preview62/0',Yes='FileAuthority125/0; Boundaries123/0; Preview62/0',TotalPassed=620,Failed=0),
 EarlierOptimizationGate=dict(No='123/0 + 62/0 + Snapshot682/0',Yes='123/0 + 62/0 + Snapshot682/0'),
 StaleRunIDRegressions=stale,
 NumericalParity=[json.loads((P/f'{n}NumericalParity.json').read_text(encoding='utf-8')) for n in ['Light','Heavy']],
 Native=json.loads((P/'NativeComponentPreservation.json').read_text(encoding='utf-8')),
 Publication=publication,AllOwnNativeProcessesClosed=True,ForceKilled=False,
 MathUnitsTolerancesChanged=False,PersistentTrustOrHashCacheAdded=False,
 OriginalFileFailureRetained=True,CurrentFullPASSAssigned=False,
 Branch='codex/action-latency',BaseCode='dd7bdef3d8b5226edb8a278f671ac820b73fb97d',
 PushProof='Recorded after commit/push in local PushVerification.json; main not merged without acceptance')
(E/'Processed.json').write_text(json.dumps(processed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
top=['Preparation.json','FinalSourceManifest.json','Publication.json','PackagePreparation.json','SourceEquality_Main.json','SourceEquality_Ready.json','NativeComponentPreservation.json','FinalOwnClosures.json','DirectedPrimaryReview.json','ComparisonSummary.json','StorageComparisonSummary.json','LightNumericalParity.json','HeavyNumericalParity.json','DialogTiming.json','IOAudit.json']
for name in top:
 f=P/name
 if f.exists():(E/name).write_bytes(f.read_bytes())
selected=[]
for f in P.iterdir():
 if f.is_file() and (f.suffix in ['.ps1','.py','.bas'] or f.name.endswith('Measurements.json') or f.name.endswith('Phases.txt') or f.name.endswith('Failure.txt') or f.name.endswith('Closure.json') or f.name.endswith('Ownership.json') or f.name.startswith('NativeRuntimeV2_') or re.match(r'(?:Final_)?Run\w+Tests_(?:No|Yes)\.txt$',f.name)):
  selected.append(f)
for folder in ['Candidate','Instrumented']:
 selected += [f for f in (P/folder).iterdir() if f.is_file()]
for folder in ['Main','Ready']:
 selected.append(P/f'NativeFinal/{folder}/NativeVerification.json')
selected += [P/'StorageRun02/StorageMeasurements.json',P/'StorageRun02/StorageOwnership.json',P/'StorageRun02/StorageClosure.json']
archive=E/'ReviewedEvidence.zip'
manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(set(selected)):
  rel=f.relative_to(P).as_posix();z.write(f,rel)
  manifest.append(dict(Path=rel,Bytes=f.stat().st_size,SHA256=sha(f)))
(E/'ArchiveManifest.json').write_text(json.dumps(dict(Archive=archive.name,ArchiveSHA256=sha(archive),Files=manifest),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=R/'docs/reports/ActionLatency_2026-10-28.md';report.write_bytes((P/'ActionLatency_Report.md').read_bytes())
progress=R/'docs/geometry_refactor/PROGRESS.md';old=progress.read_text(encoding='utf-8-sig');title,rest=old.split('\n',1)
entry='''
## 28.10.2026 — Задержки действий: повторная подготовка границ и File RunID

На сохранённом Г-образном примере Auto 0.1 подтверждено: решатель около0,03с, основная добавка — восстановление/проверка границ и вывод. Убраны поиск общей шапки и создание рабочих словарей на каждом элементе, без ослабления проверок и без кэша между действиями. Парное ABBA: формирование0,665→0,463с, расчёт1,327→0,899с; отдельный Excel/File опыт показывает разброс около1,05/1,09с, гарантии <1с нет. Старая1a0 давала0,654с при другой сетке152вместо95элементов. На1232+8/30 сочетаний Excel9,061→9,137с и File7,500→7,275с — устойчивого замедления нет.

Исправлен реальный File-дефект: RunID контуров больше не сверяется с устаревшим Results, обе матрицы берутся через единый источник. Новый stale-Results тест проходит для Adaptive/Contour No/Yes. Финальные адресные125+123+62 каждого режима=620/0; исходная неуспешная File-проба сохранена. Независимо побитно совпали1093523ячейки двух17-табличных снимков, кроме RunID/времени. Большие Excel/файловые данные передаются блоками; долгой работы после реального OK не воспроизведено (остаток кода0,000023с, очередьExcel0,0405с).

Нативные175+6обеих книг/AllCode проверены;179других компонентов сохранены, все181тела Main/Ready равны. В основной8E2A57843540… и тестовойEF2BAFDAF35D… изменён толькоVBA;110/111другихZIPчастей и все пользовательские данные/готовыеResults прежние. Источники сборки синхронизированы. Все собственные Excel закрылись безkill. Веткаcodex/action-latency;main не менялась, новый полный набор не запускался. Отчёт:[ActionLatency_2026-10-28.md](../reports/ActionLatency_2026-10-28.md), доказательства:docs/regression/ActionLatency_2026-10-28_Run01.

'''
progress.write_text(title+'\n'+entry+rest.lstrip('\n'),encoding='utf-8-sig')
print(json.dumps(dict(EvidenceFiles=len(list(E.iterdir())),ArchivedFiles=len(manifest),ArchiveBytes=archive.stat().st_size,Report=str(report)),ensure_ascii=False))
