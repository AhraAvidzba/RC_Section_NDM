import copy, hashlib, io, json, pathlib, subprocess, zipfile
from lxml import etree as ET

ROOT = pathlib.Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
OUT = pathlib.Path(__file__).parent
SOURCE = ROOT/'workbook/output/RC_Section_NDM.xlsm'
NS = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
S = '{'+NS['s']+'}'
def sha(b): return hashlib.sha256(b).hexdigest().upper()
data = SOURCE.read_bytes()
assert sha(data) == 'A907AF64246A2CD9E5C174561CCA7A6502D2C14B25808083707DF1869C5DA1C5'
(OUT/'UserSavedOriginal.xlsm').write_bytes(data)
z = zipfile.ZipFile(io.BytesIO(data))
sst = [''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',NS)]
sheet = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
def value(c):
    if c is None: return ''
    if c.get('t') == 'inlineStr': return ''.join(c.find('s:is',NS).itertext())
    v = c.find('s:v',NS)
    if v is None: return ''
    return sst[int(v.text)] if c.get('t') == 's' else v.text
settings = {}
for row in sheet.findall('s:sheetData/s:row',NS):
    cs = {c.get('r').rstrip('0123456789'):c for c in row.findall('s:c',NS)}
    key = value(cs.get('A'))
    if key: settings[key] = value(cs.get('B'))
choice = 'Worst' if settings['Output.CombinationMode'] == 'Worst' else settings['Output.CombinationID']
cases = []
for name,ref in [('Current','dd7bdef3'),('PriorAccepted','b18fe3ea'),('BeforeFileChanges','470501f8'),('PreContour','1a0c03a8')]:
    old = data if name == 'Current' else subprocess.run(['git','show',ref+':workbook/output/RC_Section_NDM.xlsm'], cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    vba = zipfile.ZipFile(io.BytesIO(old)).read('xl/vbaProject.bin')
    parts = {}
    if name != 'Current':
        sd = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
        rows = sd.find('s:sheetData',NS)
        for rn,key in [(150,'Plot.LoadCase'),(151,'AutoCAD.Export.CombinationID')]:
            row = rows.find(f"s:row[@r='{rn}']",NS)
            if row is None: row = ET.SubElement(rows,S+'row',{'r':str(rn)})
            for col,val in [('A',key),('B',choice),('C','-')]:
                cell = row.find(f"s:c[@r='{col}{rn}']",NS)
                if cell is None: cell = ET.SubElement(row,S+'c',{'r':f'{col}{rn}'})
                for child in list(cell): cell.remove(child)
                cell.set('t','inlineStr')
                ET.SubElement(ET.SubElement(cell,S+'is'),S+'t').text=val
        rows[:] = sorted(rows,key=lambda r:int(r.get('r')))
        parts['xl/worksheets/sheet1.xml']=ET.tostring(sd,encoding='utf-8',xml_declaration=True)
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        for n in wb.findall('s:definedNames/s:definedName',NS):
            if n.get('name')=='rngSystemSettings': n.text='Config!$A$3:$E$151'
        parts['xl/workbook.xml']=ET.tostring(wb,encoding='utf-8',xml_declaration=True)
    # Compatibility aliases are applied through native Excel before timed calls.
    # Keep all original XML parts byte-identical, avoiding unrelated XML rewrites.
    parts.clear()
    parts['xl/vbaProject.bin']=vba
    path=OUT/(name+'.xlsm')
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as out:
        for item in z.infolist(): out.writestr(copy.copy(item),parts.get(item.filename,z.read(item.filename)))
    cases.append({'Name':name,'Commit':ref,'Path':str(path),'SHA256':sha(path.read_bytes()),'VbaSHA256':sha(vba),'Aliases':None if name=='Current' else {'Plot.LoadCase':choice,'AutoCAD.Export.CombinationID':choice}})
manifest={'Source':str(SOURCE),'SourceSHA256':sha(data),'Settings':settings,'Cases':cases,'Notes':'Same saved user workbook data. Historical VBA only; two old selector aliases added for compatibility.'}
(OUT/'Preparation.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'SourceSHA256':sha(data),'Cases':cases},ensure_ascii=False,indent=2))
