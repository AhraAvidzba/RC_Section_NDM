﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Короткое сравнение полного расчёта Excel/File: лёгкая сетка и сохранённые 1232/30.
$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestStorageOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=New-Object 'System.Collections.Generic.List[object]'
function Set-TestStorageSetting([string]$Key,[string]$Value){
 $range=$book.Names.Item('rngSystemSettings').RefersToRange;$v=$range.Value2
 for($r=1;$r-le$v.GetLength(0);$r++){if([string]$v[$r,1]-ceq$Key){$range.Cells.Item($r,2).Value2=$Value;return}}
 throw ('Missing setting '+$Key)
}
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve insufficient'}
$app=$null;$book=$null;$project=$null;$component=$null;$code=$null
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][TestStorageOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 $owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;RAMMB=$m.AvailableMBytes;CommitFreeBytes=($m.CommitLimit-$m.CommittedBytes)}|ConvertTo-Json|Set-Content (Join-Path $directory 'StorageOwnership.json') -Encoding UTF8
 $app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.Visible=$true
 foreach($fixture in @('Light','Heavy1232_30')){
  foreach($variant in @('Original','Optimized')){
   $source=if($fixture-eq'Light'){Join-Path $directory 'UserSavedOriginal.xlsm'}else{Join-Path $root 'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm'}
   $copy=Join-Path $directory ($fixture+'_'+$variant+'.xlsm');Copy-Item -LiteralPath $source -Destination $copy
   $book=$app.Workbooks.Open($copy,0,$false)
   $project=$book.VBProject;$component=$project.VBComponents.Add(1);$component.Name='modTestLatencyStorage';$component.CodeModule.AddFromString([IO.File]::ReadAllText((Join-Path $directory 'modTestLatencyStorage.bas'),[Text.Encoding]::UTF8))
   $module=if($variant-eq'Original'){Join-Path $directory 'Native/Current/modSectionSnapshot.txt'}else{Join-Path $directory 'Candidate/modSectionSnapshot.bas'}
   $body=[regex]::Replace([IO.File]::ReadAllText($module,[Text.Encoding]::UTF8),'(?m)^Attribute [^\r\n]*\r?\n','')
   $code=$project.VBComponents.Item('modSectionSnapshot').CodeModule;$code.DeleteLines(1,$code.CountOfLines);$code.AddFromString($body)
   $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578)
   if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Private storage compile failed'}
   $code=$null;$component=$null;$project=$null;$compile=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
   $book.Worksheets.Item('Config').Activate();$app.EnableEvents=$true;$app.Calculation=-4105
   Set-TestStorageSetting 'General.ExecutionReportEnabled' 'No'
   Set-TestStorageSetting 'Results.SnapshotStorage' 'Excel'
   Set-TestStorageSetting 'Results.SnapshotName' ($fixture+'_'+$variant)
   if($fixture-eq'Light'){Set-TestStorageSetting 'Mesh.StepMode' 'Auto 0.1';[void]$app.Run("'$($book.Name)'!FormSectionForWorkbook",$book)}
   foreach($mode in @('Excel','File')){
    if($mode-eq'File'){
     [void]$app.Run("'$($book.Name)'!modTestLatencyStorage.TestSaveGeometryFile")
     Set-TestStorageSetting 'Results.SnapshotStorage' 'File'
    }
    foreach($n in 1..3){
     $watch=[Diagnostics.Stopwatch]::StartNew();$message=[string]$app.Run("'$($book.Name)'!RunSectionCalculationForWorkbook",$book,$false);$seconds=$watch.Elapsed.TotalSeconds
     $records.Add([ordered]@{Fixture=$fixture;Variant=$variant;Mode=$mode;Repeat=$n;Seconds=$seconds;Message=$message;ActiveSheet=[string]$book.ActiveSheet.Name})
     $records|ConvertTo-Json -Depth 6|Set-Content (Join-Path $directory 'StorageMeasurements.json') -Encoding UTF8
     Write-Output (('{0}/{1}/{2} #{3}: {4:N3}s'-f$fixture,$variant,$mode,$n,$seconds))
    }
    if($mode-eq'Excel'){$book.SaveCopyAs((Join-Path $directory ($fixture+'_'+$variant+'_ExcelResults.xlsm')))}
   }
   $app.EnableEvents=$false;$book.Close($false);$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  }
 }
}catch{[IO.File]::WriteAllText((Join-Path $directory 'StorageFailure.txt'),$_.Exception.ToString());throw}
finally{
 $compile=$null;$code=$null;$component=$null;$project=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ne'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Identity changed'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds-lt15)
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $directory 'StorageClosure.json') -Encoding UTF8
 if(-not$absent){throw 'Own Excel exit not proven'}
}
