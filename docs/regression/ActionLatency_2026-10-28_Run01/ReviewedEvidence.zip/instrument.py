from pathlib import Path
import json, re
D=Path(__file__).parent
OUT=D/'Instrumented';OUT.mkdir(exist_ok=True)
texts={p.stem:p.read_text(encoding='utf-8-sig') for p in (D/'Native/Current').glob('*.txt')}
proof=[]
def line(module,method,needle,key=None):
    text=texts[module]
    proc=re.search(r'(?ims)^(?:Public |Private |Friend )?(?:Sub|Function) '+re.escape(method)+r'\b.*?^End (?:Sub|Function)\b',text)
    assert proc,(module,method)
    body=proc.group()
    m=list(re.finditer(r'(?im)^'+re.escape(needle)+r'[^\r\n]*$',body))
    assert len(m)==1,(module,method,needle,len(m))
    hit=m[0]; original=hit.group()
    assert not original.rstrip().endswith('_'),original
    key=key or method+'.'+needle.strip().split(' ')[0]
    expression=key if key.startswith('EXPR:') else '"'+key+'"'
    expression=expression.removeprefix('EXPR:')
    changed='    modTestActionProfiler.TestBegin '+expression+'\n'+original+'\n    modTestActionProfiler.TestEnd '+expression
    body=body[:hit.start()]+changed+body[hit.end():]
    texts[module]=text[:proc.start()]+body+text[proc.end():]
    proof.append({'Module':module,'Method':method,'Original':original,'Key':key})
for method,guard in [('RunSectionCalculationForWorkbook','excelGuard'),('FormSectionForWorkbook','guard')]:
    for needle,key in [(f'    {guard}.Enter workbook.Application','Enter'),('    workbook.Application.Calculate','GlobalCalculate'),('    settings.LoadFromWorkbook workbook','Settings'),('    CalculateResultsSheet workbook','ResultsCalculate'),(f'    {guard}.Restore True','Restore')]:
        line('modWorkbookCalculation',method,needle,method+'.'+key)
for needle,key in [
 ('    Set section = ReadFormedSectionFromResults','ReadGeometry'),
 ('    materialProvider.Initialize settings, units','Materials'),
 ('    profiles.LoadFromWorkbook workbook','Profiles'),
 ('    batch.ApplySettings settings, units','BatchSettings'),
 ('    reader.LoadFromWorkbook workbook, batch, units','Loads'),
 ('    ValidateResultsOutputLayout workbook','Layout'),
 ('    batch.Execute','Solve'),
 ('    summaryWriter.WriteSummary workbook','PrepareSummary'),
 ('    ndmWriter.WriteResults workbook','PrepareTechnical'),
 ('    savedSnapshot.Validate','ValidatePrepared'),
 ('    plotWarning = SaveAndDisplayCalculationSnapshot','DisplayAndSave'),
 ('    snapshotStore.UpdateSavedElapsed workbook','SaveElapsed'),
 ('    If snapshotStore.StorageMode(workbook) = "File" Then savedDestination','ReadDestination')]:
 line('modWorkbookCalculation','RunSectionCalculationForWorkbook',needle,'Calculation.'+key)
for needle,key in [('        Set section = BuildWorkbookSectionModel','Generate'),('    Dim snapshot As CSectionPropertiesCalculator:','Properties'),('        writer.WriteGeometryPreview workbook','WriteGeometry'),('    ClearSectionPlotForNoData workbook','ClearOldPlot'),('    UpdateSectionGeometryPreviewForWorkbook workbook','DrawPreview')]:
 line('modWorkbookCalculation','FormSectionForWorkbook',needle,'Form.'+key)
for method in ['UpdateSectionPlotForWorkbook','UpdateSectionGeometryPreviewForWorkbook']:
 line('modWorkbookCalculation',method,'    settings.LoadFromWorkbook workbook',method+'.Settings')
 line('modWorkbookCalculation',method,'    plotter.Draw workbook',method+'.Draw')
line('modWorkbookCalculation','TryLoadFullPlotReader','    reader.LoadFromWorkbook workbook','Plot.ReadFull')
line('modWorkbookCalculation','UpdateSectionGeometryPreviewForWorkbook','    reader.LoadGeometryPreviewFromWorkbook','Plot.ReadPreview')
for needle,key in [('    writer.RestoreSnapshotBase workbook','WriteBase'),('        summary.RestoreSummary workbook','WriteSummary'),('        plotWarning = TryUpdateCalculatedSnapshotPlot','AutomaticPlot')]:
 line('modCalculationSnapshot','UpdateSectionResultsForWorkbook',needle,'Display.'+key)
line('CExcelAppStateGuard','Enter','        mValues(i) = ReadProperty(i)','EXPR:"Guard.Enter.Read." & CStr(i)')
line('CExcelAppStateGuard','Enter','        WriteProperty i, fastValues(i)','EXPR:"Guard.Enter.Write." & CStr(i)')
line('CExcelAppStateGuard','Restore','                WriteProperty i, mValues(i)','EXPR:"Guard.Restore.Write." & CStr(i)')
for needle,key in [('    snapshot.Validate','Validate'),('        ClearNamedRegion workbook','Clear'),('        target.Resize(UBound(data, 1), UBound(data, 2)).Value2 = data','AssignValues'),('        FormatResultsBlock target','Format')]:
 line('CNDMResultsWriter','RestoreSnapshotBase',needle,'Base.'+key)
for needle in ['    PrepareChart data','    ConfigureEqualScale data','    ClearGeneratedShapes','    AddElementSeries data, settings','    DrawShapeDecorations data','        DrawGeometryReferenceOverlay data','        DrawAnalysisOverlay data','    DrawPlotTitleOverlay PlotTitleText(data)']:
 line('CSectionPlotter','Draw',needle,'Draw.'+needle.strip().split(' ')[0])
line('modSectionSnapshot','ReadConcreteBoundaryMap','        Set region = SavedConcreteRegion(contours, query)','Boundary.BuildRegion')
line('modSectionSnapshot','ReadConcreteBoundaryMap','        ValidateSavedBoundaryProperties region','Boundary.ValidateProperties')
# Header discovery is invariant for all rows of one matrix; measure it as a block.
text=texts['modSectionSnapshot']
proc=re.search(r'(?ims)^Private Sub ValidateSavedBoundaryProperties\b.*?^End Sub\b',text)
body=proc.group()
start=re.search(r'(?im)^    Dim xColumn As Long:',body).start()
end=re.search(r'(?im)^    Call SavedBoundaryHeaderUnit\(data, rotationColumn[^\r\n]*',body).end()
body=body[:start]+'    modTestActionProfiler.TestBegin "Boundary.Headers"\n'+body[start:end]+'\n    modTestActionProfiler.TestEnd "Boundary.Headers"'+body[end:]
texts['modSectionSnapshot']=text[:proc.start()]+body+text[proc.end():]
proof.append({'Module':'modSectionSnapshot','Method':'ValidateSavedBoundaryProperties','Key':'Boundary.Headers','Original':'Header-column and unit discovery block'})
for module in sorted({p['Module'] for p in proof}):
 (OUT/(module+'.txt')).write_text(texts[module],encoding='utf-8-sig')
(OUT/'Instrumentation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared',len(proof),'exact anchors in',len({p['Module'] for p in proof}),'private modules')
