Attribute VB_Name = "modTestIndexedProbes"
Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Читает контролируемо повреждённые частные файлы; не запускает решатель и не меняет исходные книги.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выбирает один файл частного runner-а по штатной настройке Config.
Private Sub TestSelectFile(ByVal name As String)
    Dim target As Range, row As Long
    Set target = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = "Results.SnapshotStorage" Then target.Cells(row, 2).Value2 = "File"
        If CStr(target.Cells(row, 1).Value2) = "Results.SnapshotName" Then target.Cells(row, 2).Value2 = name
    Next row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Даёт runner-у точные смещения первого и последнего состояния для мутаций копий.
Public Function TestBounds() As String
    On Error GoTo Failed
    TestSelectFile "Valid"
    Dim store As New CCalculationSnapshotStore, reader As New CIndexedSnapshotFile
    If Not reader.OpenRead(store.SnapshotPath(ThisWorkbook), store) Then Err.Raise 5, , "Expected v6"
    TestBounds = reader.TestStateBlockLocation(1) & vbLf & reader.TestStateBlockLocation(0)
    reader.CloseFile
    Exit Function
Failed:
    TestBounds = "ERROR|" & Err.Source & "|" & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает локальный просмотр с явной проверкой/полным восстановлением и отказами записи.
Public Function TestProbe(ByVal mode As String, ByVal name As String, ByVal combination As String, ByVal state As String) As String
    Dim entered As Boolean
    On Error GoTo Failed
    TestSelectFile name
    Dim store As New CCalculationSnapshotStore, snapshot As CCalculationSnapshot, values As Variant
    Select Case mode
        Case "View"
            BeginCalculationSnapshotRead ThisWorkbook: entered = True
            values = ReadElementResultTable(ThisWorkbook, combination, state)
            EndCalculationSnapshotRead
            entered = False
            If UBound(values, 1) < 2 Then Err.Raise 5, , "Requested state empty"
        Case "Full"
            Set snapshot = store.LoadFile(ThisWorkbook)
        Case "Verify"
            store.VerifyFile ThisWorkbook
        Case "Link"
            store.LinkFile ThisWorkbook
        Case "LinkedFull"
            store.LinkFile ThisWorkbook: Set snapshot = store.LoadLinkedFile(ThisWorkbook)
        Case "Save"
            Set snapshot = store.LoadFile(ThisWorkbook): store.SaveFile ThisWorkbook, snapshot
        Case "ElapsedWrongRun"
            Set snapshot = store.LoadFile(ThisWorkbook): store.UpdateElapsedValue ThisWorkbook, 1#, snapshot.RunID + 1#
        Case Else
            Err.Raise 5, , "Unknown test mode"
    End Select
    TestProbe = "PASS|" & mode & "|" & name
    Exit Function
Failed:
    Dim number As Long, reason As String, origin As String
    number = Err.Number: reason = Err.Description: origin = Err.Source
    If entered Then EndCalculationSnapshotRead
    TestProbe = "ERROR|" & CStr(number) & "|" & origin & "|" & reason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вызывает штатный перенос уже сохранённой книги, не подменяя файл иной копией.
Public Function TestEnsureBeside(ByVal previousFolder As String) As String
    On Error GoTo Failed
    Dim store As New CCalculationSnapshotStore
    store.EnsureBesideWorkbook ThisWorkbook, previousFolder
    Dim snapshot As CCalculationSnapshot: Set snapshot = store.LoadFile(ThisWorkbook)
    TestEnsureBeside = "PASS|RunID=" & CStr(snapshot.RunID)
    Exit Function
Failed:
    TestEnsureBeside = "ERROR|" & Err.Source & "|" & Err.Description
End Function
