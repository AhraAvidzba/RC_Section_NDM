"""ДЛЯ ТЕСТОВ: исключает полный RunID-столбец из адресного чтения опубликованного индекса."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'modIndexedExcelResults.bas').read_text(encoding='utf8')
t=t.replace('NDMResultIndex01','NDMResultIndex02')
t=t.replace('data(2, 5) = 0: data(2, 6) = 0','data(2, 5) = 0: data(2, 6) = index.Count')
a=t.index('Private Function ReadElementResultIndex(');b=t.index("' Принимает только целые относительные строки",a)
t=t[:a]+'''Private Function ReadElementResultIndex(ByVal workbook As Object, ByVal elements As Object) As CResultBlockIndex
    Dim anchor As Object: Set anchor = ExistingIndexAnchor(workbook)
    Dim rows As Long
    If anchor Is Nothing Then
        If OwnProtection(workbook) Then Err.Raise 5, , "Опубликованный индекс удалён. Очистите Results и выполните расчёт заново."
        rows = AnchoredRowCount(elements): If rows < 1 Then rows = 1
        Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, rows): Exit Function
    End If
    Dim metadata As Variant: metadata = anchor.Resize(2, INDEX_COLUMNS).Value2
    mTestRowsRead = mTestRowsRead + 2
    If Len(CStr(metadata(1, 1))) = 0 And Not OwnProtection(workbook) Then
        rows = AnchoredRowCount(elements): If rows < 1 Then rows = 1
        Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, rows): Exit Function
    End If
    If CStr(metadata(1, 1)) <> "IndexKind" Then Err.Raise 5, , "Повреждена шапка " & INDEX_NAME & "."
    If CStr(metadata(2, 1)) = "Invalid" Then
        If Len(CStr(elements.Offset(1, 0).Value2)) = 0 Then
            Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, 1): Exit Function
        End If
        Err.Raise 5, , "Индекс не опубликован; завершите расчёт либо очистите Results."
    End If
    If Len(CStr(metadata(2, 1))) = 0 And Not OwnProtection(workbook) Then
        rows = AnchoredRowCount(elements): If rows < 1 Then rows = 1
        Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, rows): Exit Function
    End If
    If CStr(metadata(2, 1)) <> INDEX_FORMAT Then Err.Raise 5, , "Неизвестный или повреждённый формат индекса результатов."
    rows = ExactIndexLong(metadata(2, 3))
    Dim count As Long: count = ExactIndexLong(metadata(2, 6))
    If rows < 1 Or ExactIndexLong(metadata(2, 4)) <> 9 Or count > rows - 1 Then Err.Raise 5, , "Повреждены размеры индекса."
    If CDbl(elements.Row) + rows - 1 > elements.Worksheet.Rows.Count Or CDbl(anchor.Row) + count + 1 > anchor.Worksheet.Rows.Count Then Err.Raise 5, , "Индекс выходит за границы листа."
    If Not OwnProtection(workbook) Or Not elements.Worksheet.ProtectContents Then Err.Raise 5, , "Структурная защита результатов снята; индекс больше не подтверждает порядок строк. Очистите Results и выполните расчёт заново."
    If Not CBool(elements.Cells(1, 1).Locked) Then Err.Raise 5, , "Якорь результатов перемещён из защищённой структуры."
    Dim locked As Variant: locked = anchor.Resize(count + 2, INDEX_COLUMNS).Locked
    If IsNull(locked) Then Err.Raise 5, , "Часть индекса результатов не защищена."
    If Not CBool(locked) Then Err.Raise 5, , "Индекс результатов не защищён."
    ' Полная область была защищена при публикации. Здесь проверяется граница, без сканирования RunID-столбца.
    If elements.Row + rows <= elements.Worksheet.Rows.Count Then
        If Len(CStr(elements.Offset(rows, 0).Value2)) > 0 Then Err.Raise 5, , "За сохранённой границей результатов появились строки без индекса."
        mTestRowsRead = mTestRowsRead + 1
    End If
    Dim header As Variant: header = elements.Resize(1, 9).Value2: mTestRowsRead = mTestRowsRead + 1
    Dim index As New CResultBlockIndex: index.Initialize header, CDbl(metadata(2, 2))
    If count > 0 Then
        Dim values As Variant: values = anchor.Offset(2, 0).Resize(count, INDEX_COLUMNS).Value2
        mTestRowsRead = mTestRowsRead + count
        Dim row As Long, column As Long, sample(1 To 1, 1 To 9) As Variant
        For row = 1 To count
            If CStr(values(row, 1)) <> "Block" Then Err.Raise 5, , "Повреждена запись индекса состояний."
            sample(1, 1) = values(row, 2)
            For column = 2 To 9: sample(1, column) = values(row, column + 5): Next column
            index.Append ExactIndexLong(values(row, 5)), ExactIndexLong(values(row, 6)), sample
        Next row
    End If
    If index.TotalRows <> rows Then Err.Raise 5, , "Индекс не покрывает всю таблицу результатов."
    Set ReadElementResultIndex = index
End Function

'''+t[b:]
t=t.replace('If AnchoredColumnCount(elements) = 0 Then Exit Function','If Len(CStr(elements.Cells(1, 1).Value2)) = 0 Then Exit Function')
(P/'modIndexedExcelResults.bas').write_text(t,encoding='utf8')
print('Indexed Excel reads metadata and selected blocks; RunID extent only in legacy bootstrap')
