Attribute VB_Name = "modTestResultPhases"
Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Накопительные таймеры точек чтения и вывода только частного VBProject.
Private Declare PtrSafe Function TestCounter Lib "kernel32" Alias "QueryPerformanceCounter" (ByRef value As Currency) As Long
Private Declare PtrSafe Function TestFrequency Lib "kernel32" Alias "QueryPerformanceFrequency" (ByRef value As Currency) As Long
Private mStarted As Object, mSeconds As Object

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает монотонное время; Currency сохраняет точность 64-битного счётчика VBA.
Private Function TestNow() As Double
    Dim count As Currency, frequency As Currency
    TestCounter count: TestFrequency frequency: TestNow = count / frequency
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Начинает один именованный этап; вложенные этапы имеют разные имена.
Public Sub TestStart(ByVal phase As String)
    If mStarted Is Nothing Then Set mStarted = CreateObject("Scripting.Dictionary")
    If mSeconds Is Nothing Then Set mSeconds = CreateObject("Scripting.Dictionary")
    mStarted(phase) = TestNow()
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Суммирует завершённые этапы, не меняя вызываемые параметры и результаты.
Public Sub TestStop(ByVal phase As String)
    Dim elapsed As Double: elapsed = TestNow() - CDbl(mStarted(phase))
    If Not mSeconds.Exists(phase) Then mSeconds.Add phase, 0#
    mSeconds(phase) = CDbl(mSeconds(phase)) + elapsed
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет штатное обновление с пустым scope, возвращает время и распределение этапов.
Public Function TestMeasurePhases(ByVal mode As String) As String
    Set mStarted = Nothing: Set mSeconds = Nothing
    Dim total As Double: total = modTestIndexedBaseline.TestMeasure("Update" & mode)
    If total < 0# Then TestMeasurePhases = "ERROR|" & modTestIndexedBaseline.TestLastError: Exit Function
    Dim key As Variant, text As String: text = "Total=" & CStr(total)
    If Not mSeconds Is Nothing Then
        For Each key In mSeconds.Keys: text = text & "|" & CStr(key) & "=" & CStr(mSeconds(key)): Next key
    End If
    TestMeasurePhases = text
End Function
