﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Синхронизирует три комментария тестов в уже подготовленной частной книге; данные не читает и не пересчитывает.
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM';$out=Join-Path $p 'Current25'
if(Test-Path -LiteralPath $out){throw 'Fresh patch directory required'}
[void][IO.Directory]::CreateDirectory($out)
$path=Join-Path $out 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath (Join-Path $p 'Current22_Attempt2/RC_Section_NDM.xlsm') -Destination $path
. (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
$areas=@(Get-WorkbookPrintAreas (Join-Path $p 'Current22_Attempt2/Before.xlsm'))
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestPatchOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestPatchOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135;$app.CalculateBeforeSave=$false
 foreach($name in 'modTestAudit02Api','modTestCalculationSnapshot','modTestElementGeometry'){
  $component=$book.VBProject.VBComponents.Item($name)
  $code=[IO.File]::ReadAllText((Join-Path $root ('tests/'+$name+'.bas')),[Text.Encoding]::UTF8)
  $code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')
  $component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines);$component.CodeModule.AddFromString($code)
 }
 $app.VBE.ActiveVBProject=$book.VBProject;$compile=$app.VBE.CommandBars.FindControl(1,578)
 if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Compile did not finish'}
 $book.Save()
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;$compile=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
Restore-WorkbookPrintAreas $path $areas
Write-Output 'Private output comments/print names synchronized'
