﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Повторяет Quit только для точного собственного пустого Excel после завершённой серии.
$ErrorActionPreference='Stop'
$p=$PSScriptRoot;$out=Join-Path $p 'Prototype7'
$own=Get-Content -LiteralPath (Join-Path $out 'Own.json') -Raw|ConvertFrom-Json
$quit=Get-Content -LiteralPath (Join-Path $out 'Quit.json') -Raw|ConvertFrom-Json
if([int]$own.PID -ne 70948 -or [string]$own.UTCStartTicks -ne '639291220195408614' -or -not $quit.QuitReturned){throw 'Exact completed-run identity required'}
if(-not([IO.File]::ReadAllText((Join-Path $out 'ExcelResult.txt')).StartsWith('PASS|'))){throw 'Native Excel tests incomplete'}
$process=Get-Process -Id 70948 -ErrorAction SilentlyContinue
if(-not $process){Write-Output 'ConfirmedNotFound';exit}
if($process.ProcessName -ne 'EXCEL' -or [string]$process.StartTime.ToUniversalTime().Ticks -ne [string]$own.UTCStartTicks){throw 'PID reused; do not touch'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class TestEmptyPrototypeOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null
try{
 $app=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
 [uint32]$id=0;[void][TestEmptyPrototypeOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if([int]$id -ne [int]$own.PID){throw 'ROT belongs to another Excel; no action permitted'}
 $count=[int]$app.Workbooks.Count
 [ordered]@{PID=$own.PID;UTCStartTicks=$own.UTCStartTicks;Workbooks=$count;CPU=$process.CPU;PrivateBytes=$process.PrivateMemorySize64;OriginalQuitReturned=$true;ObservedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'EmptyOwnBeforeRetryQuit.json') -Encoding UTF8
 if($count -ne 0){throw 'Excel is not empty; do not Quit'}
 $app.Quit()
 Write-Output 'Exact empty own Excel: retry Quit returned'
}finally{
 if($app){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
