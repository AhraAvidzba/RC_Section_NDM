﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Нативные отказы, совместимость и Save As на частной копии; без расчёта сочетаний.
param([int]$Attempt=1)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$out=Join-Path $p ('Integrity12_Attempt'+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh integrity directory required'}
[void][IO.Directory]::CreateDirectory($out)
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
$bookPath=Join-Path $out 'Probe.xlsm'
Copy-Item -LiteralPath (Join-Path $p 'Prototype10/Prototype.xlsm') -Destination $bookPath
Copy-Item -LiteralPath (Join-Path $p 'Prototype8/IndexedBaseline.ndm') -Destination (Join-Path $out 'Valid.ndm')
Copy-Item -LiteralPath (Join-Path $p '../ActionLatency_2026-10-28_Run01/StorageRun02/Heavy1232_30_Optimized.ndm') -Destination (Join-Path $out 'Legacy04.ndms')
Copy-Item -LiteralPath (Join-Path $p 'Baseline900_Attempt5/IndexedBaseline.ndm') -Destination (Join-Path $out 'Legacy05.ndms')
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestProbeOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false;$records=@()
# Один вызов сохраняет результат до проверки ожидания, поэтому отказы не теряются.
function Test-Probe([string]$mode,[string]$name,[string]$combination,[string]$state,[bool]$expectPass){
 $prefix="'$($book.Name)'!modTestIndexedProbes."
 $result=[string]$app.Run($prefix+'TestProbe',$mode,$name,$combination,$state)
 $script:records+=,[ordered]@{Mode=$mode;Name=$name;ExpectedPass=$expectPass;Result=$result}
 $script:records|ConvertTo-Json -Depth 4|Set-Content (Join-Path $out 'Probes.json') -Encoding UTF8
 Write-Output ($mode+' '+$name+' '+$result)
 if($result.StartsWith('PASS|') -ne $expectPass){throw ('Probe expectation failed: '+$result)}
}
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestProbeOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($bookPath,0,$false);$app.Calculation=-4135
 $component=$book.VBProject.VBComponents.Add(1);$component.Name='modTestIndexedProbes'
 $code=[IO.File]::ReadAllText((Join-Path $p 'modTestIndexedProbes.bas'),[Text.Encoding]::UTF8)
 $component.CodeModule.AddFromString(([regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')))
 $prefix="'$($book.Name)'!modTestIndexedProbes."
 $bounds=[string]$app.Run($prefix+'TestBounds');$bounds|Set-Content (Join-Path $out 'Bounds.txt') -Encoding UTF8
 if($bounds.StartsWith('ERROR|')){throw $bounds}
 $parts=$bounds.Trim().Split([char]10);$first=$parts[0].Trim().Split('|');$last=$parts[1].Trim().Split('|')
 $raw=[IO.File]::ReadAllBytes((Join-Path $out 'Valid.ndm'))
 $directoryOffset=[BitConverter]::ToInt32($raw,$raw.Length-88)
 # Каждая мутация пишет новый частный файл; Valid остаётся побайтно прежним.
 foreach($case in @(@('BadHeader',20),@('BadIndex',($directoryOffset+9)),@('BadFirst',([int]$first[0]+[int]$first[1]-1)),@('BadLast',([int]$last[0]+[int]$last[1]-1)),@('BadAddress',($raw.Length-88)))){
  $copy=[byte[]]$raw.Clone();$copy[[int]$case[1]]=$copy[[int]$case[1]] -bxor 1
  [IO.File]::WriteAllBytes((Join-Path $out ($case[0]+'.ndm')),$copy)
 }
 $truncated=New-Object byte[] ($raw.Length-20);[Array]::Copy($raw,$truncated,$truncated.Length)
 [IO.File]::WriteAllBytes((Join-Path $out 'Truncated.ndm'),$truncated)
 Test-Probe 'View' 'Valid' $first[2] $first[3] $true
 Test-Probe 'Full' 'Valid' '' '' $true
 Test-Probe 'Verify' 'Valid' '' '' $true
 foreach($name in 'BadHeader','BadIndex','BadAddress','Truncated'){Test-Probe 'View' $name $first[2] $first[3] $false}
 Test-Probe 'View' 'BadFirst' $first[2] $first[3] $false
 Test-Probe 'View' 'BadLast' $first[2] $first[3] $true
 Test-Probe 'View' 'BadLast' $last[2] $last[3] $false
 Test-Probe 'Full' 'BadLast' '' '' $false
 Test-Probe 'Verify' 'BadLast' '' '' $false
 Test-Probe 'LinkedFull' 'BadLast' '' '' $false
 Test-Probe 'Full' 'Legacy04' '' '' $true
 Test-Probe 'Full' 'Legacy05' '' '' $true
 Copy-Item -LiteralPath (Join-Path $out 'Valid.ndm') -Destination (Join-Path $out 'Priority.ndms')
 Copy-Item -LiteralPath (Join-Path $out 'BadHeader.ndm') -Destination (Join-Path $out 'Priority.ndm')
 Test-Probe 'View' 'Priority' $first[2] $first[3] $false
 Copy-Item -LiteralPath (Join-Path $out 'Valid.ndm') -Destination (Join-Path $out 'BusySave.ndm')
 [IO.File]::WriteAllText((Join-Path $out 'BusySave.ndm.part'),'DO_NOT_TOUCH')
 $before=(Get-FileHash (Join-Path $out 'BusySave.ndm')).Hash
 Test-Probe 'Save' 'BusySave' '' '' $false
 if((Get-FileHash (Join-Path $out 'BusySave.ndm')).Hash -ne $before -or [IO.File]::ReadAllText((Join-Path $out 'BusySave.ndm.part')) -cne 'DO_NOT_TOUCH'){throw 'Occupied-part refusal changed original data'}
 Copy-Item -LiteralPath (Join-Path $out 'Valid.ndm') -Destination (Join-Path $out 'WrongElapsed.ndm')
 Test-Probe 'ElapsedWrongRun' 'WrongElapsed' '' '' $false
 if((Get-FileHash (Join-Path $out 'WrongElapsed.ndm')).Hash -ne $before -or (Test-Path -LiteralPath (Join-Path $out 'WrongElapsed.ndm.part'))){throw 'Wrong-RunID failure did not preserve file and remove own part'}
 Test-Probe 'Link' 'Valid' '' '' $true
 $moved=Join-Path $out 'Moved';[void][IO.Directory]::CreateDirectory($moved)
 $book.SaveAs((Join-Path $moved 'ProbeMoved.xlsm'),52)
 $prefix="'$($book.Name)'!modTestIndexedProbes."
 $saved=[string]$app.Run($prefix+'TestEnsureBeside',$out);Write-Output ('SaveAs '+$saved)
 if(-not $saved.StartsWith('PASS|')){throw $saved}
 if((Get-FileHash (Join-Path $moved 'Valid.ndm')).Hash -ne (Get-FileHash (Join-Path $out 'Valid.ndm')).Hash){throw 'Save As copy changed bytes'}
 Copy-Item -LiteralPath (Join-Path $out 'BadHeader.ndm') -Destination (Join-Path $moved 'Valid.ndm') -Force
 $wrong=[string]$app.Run($prefix+'TestEnsureBeside',$out)
 if(-not $wrong.StartsWith('ERROR|')){throw 'Different target accepted at Save As'}
 [ordered]@{Status='PASS_NATIVE_CORRUPTION_COMPATIBILITY_ATOMIC_SAVE_AS';Probes=$records.Count;SelectedUnreadCorruptionPolicyProved=$true;Legacy04=$true;Legacy05=$true;Extensions=@('.ndm','.ndms');OccupiedPartPreserved=$true;WrongElapsedRunPreserved=$true;SaveAsByteExact=$true;DifferentSaveAsTargetRejected=$true}|ConvertTo-Json|Set-Content (Join-Path $out 'Complete.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
