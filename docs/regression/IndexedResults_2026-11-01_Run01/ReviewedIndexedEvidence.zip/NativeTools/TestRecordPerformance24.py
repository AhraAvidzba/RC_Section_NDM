"""ДЛЯ ТЕСТОВ: фиксирует фактические замеры и точный исходник измеренного кандидата."""
from pathlib import Path
import hashlib,json,statistics
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parent
repo=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
data=json.loads((root/'PairedBenchmarkSummary18.json').read_text(encoding='utf-8'))
replacements={
 'CCalculationSnapshotStore.cls':("' Проверяет контрольную сумму до выделения матриц и чтения значений.","' Полное восстановление v6 проверяет каждый блок; v4/v5 проверяет общий SHA до выделения матриц."),
 'modCalculationSnapshot.bas':("' Выводит готовый расчёт из памяти либо восстанавливает полный снимок File.","' Выводит готовый расчёт из памяти; ручной File читает общие блоки и выбранное НДС."),
 'CResultBlockIndex.cls':("' Однократно индексирует прежнюю таблицу только по RunID/LC/Profile/State, без всех девяти колонок.","' Однократно индексирует таблицу без каталога по RunID/LC/Profile/State, без всех девяти колонок.")}
archive=root/'MeasuredCandidate18.zip'
with ZipFile(archive,'w',compression=ZIP_DEFLATED) as out:
 for path in sorted((root/'Candidate').iterdir()):
  raw=path.read_bytes()
  if path.name in replacements:
   old,new=replacements[path.name]
   text=raw.decode('utf-8-sig');assert text.count(new)==1
   raw=text.replace(new,old).encode('utf-8')
   # Исходники кандидата до уточнения комментариев имели LF; сохраняем точный SHA замера.
  expected=data['CandidateFilesSHA256'][path.name]
  if hashlib.sha256(raw).hexdigest().upper()!=expected:
   raw=raw.replace(b'\r\n',b'\n')
  assert hashlib.sha256(raw).hexdigest().upper()==expected,path.name
  out.writestr(path.name,raw)
with ZipFile(archive) as source:
 for name,expected in data['CandidateFilesSHA256'].items():assert hashlib.sha256(source.read(name)).hexdigest().upper()==expected

phases=json.loads((root/'Phases21_Heavy_Attempt3/Measurements.json').read_text(encoding='utf-8-sig'))
phaseSummary={}
for version in ('Before','After'):
 for mode in ('File','Excel'):
  records=[]
  for row in phases:
   if row['Version']==version and row['Mode']==mode and row['Repeat']>0:
    records.append({key:float(value.replace(',','.')) for key,value in (part.split('=',1) for part in row['Result'].split('|'))})
  assert len(records)==3 and all('Draw' in row and 'PlotData' in row for row in records)
  phaseSummary[version+mode]={key:statistics.median(row[key] for row in records) for key in records[0]}
(root/'PhaseSummary24.json').write_text(json.dumps(phaseSummary,indent=2),encoding='utf-8')
def cell(dataset,action):
 row=data['Datasets'][dataset]['Actions'][action]
 return f"{row['Before']['Median']:.3f} → {row['After']['Median']:.3f}"
rows=[]
for mode in ('File','Excel'):
 for label,action in [('Сохранение подготовленных результатов','SavePrepared'),('Первое чтение состояния','First'),('Повторное чтение','Repeat'),('Переключение состояния','Switch'),('Полное восстановление','Restore'),('Обновление таблиц и схемы','Update')]:
  action+=mode
  rows.append(f"| {mode} | {label} | {cell('Light',action)} | {cell('Heavy',action)} |")
report=f'''# Адресное хранение и чтение результатов NDM

Реализованы независимо читаемые блоки NDMSNP06 и адресный каталог видимой таблицы Excel. Подготовка конечных книг и их публикация ещё проверяются. Расчётное ядро, геометрия, единицы и численные ожидания не менялись. SQLite и внешние зависимости не добавлялись.

## Замеры на одинаковых готовых данных

Лёгкий круг: 284 бетонных элемента + 8 стержней, 20 сочетаний, 80 фактических пар сочетание/состояние, 23 360 строк результатов. Тяжёлый сохранённый круг: **1232 бетонных элемента + 8 стержней, 30 исходных сочетаний, 92 пары, 114 080 строк**. Его исходные данные и результаты не пересчитывались. Сохранены четыре исторических InputErr PERF_14/21/27/28. Геометрия — наружная окружность и два круглых отверстия, 12 аналитических дуг. Текущий селектор Geometry.Type не использовался для определения сохранённой геометрии.

Время в секундах, медианы шести измерений каждой версии: три цикла ABBA, прогрев исключён. Полные диапазоны min/max, все исходные значения и счётчики — в `PairedBenchmarkSummary18.json` и `Paired16_*/Measurements.json` доказательств. «Первое» означает новый контекст без готового снимка; файловый кэш ОС принудительно не очищался.

| Носитель | Операция | Лёгкий до → после, с | Тяжёлый до → после, с |
|---|---|---:|---:|
{chr(10).join(rows)}

Сохранение измерено от подготовки независимого приёмника готовых массивов и нового индекса до записи всех таблиц/блоков, сумм, привязки и завершения времени. В самом writer границы индекса собираются одновременно с формированием состояний. Это замер хранения подготовленного расчёта, без solver и без сохранения XLSM на диск; обновление схемы измерено отдельно. Воспроизводимого замедления этого пути записи не обнаружено.

**Полное восстановление File стало медленнее:** на тяжёлом примере 0,514 → 0,889 с. Это явная отдельная операция с проверкой всех независимых блоков и полного семантического контракта; обычный выбор и обновление её не вызывают. Ускорение отдельного reader не выдаётся за такое же ускорение всей команды.

Отдельная серия с таймерами внутри штатного обновления тяжёлого примера (три повтора, иной прогрев):

| Этап | File до → после, с | Excel до → после, с |
|---|---:|---:|
| Общие данные, чтение и проверка | {phaseSummary['BeforeFile'].get('CommonRead',0):.3f} → {phaseSummary['AfterFile'].get('CommonRead',0):.3f} | Включены в reader |
| Подготовка данных схемы | {phaseSummary['BeforeFile']['PlotData']:.3f} → {phaseSummary['AfterFile']['PlotData']:.3f} | {phaseSummary['BeforeExcel']['PlotData']:.3f} → {phaseSummary['AfterExcel']['PlotData']:.3f} |
| Вывод общих таблиц | {phaseSummary['BeforeFile']['BaseOutput']:.3f} → {phaseSummary['AfterFile']['BaseOutput']:.3f} | Команда не переписывает таблицы |
| Вывод верхних сводок | {phaseSummary['BeforeFile']['SummaryOutput']:.3f} → {phaseSummary['AfterFile']['SummaryOutput']:.3f} | Команда не переписывает таблицы |
| Рисование схемы | {phaseSummary['BeforeFile']['Draw']:.3f} → {phaseSummary['AfterFile']['Draw']:.3f} | {phaseSummary['BeforeExcel']['Draw']:.3f} → {phaseSummary['AfterExcel']['Draw']:.3f} |

Reader схемы включает сбор геометрии/аннотаций и выбор результата; это шире чтения одного блока. Рисование почти не изменилось. Медианы этапов отдельной серии не нужно складывать для получения медианы основной ABBA-серии.

## Доказательство адресного IO

На тяжёлом примере первое File-чтение одного состояния: **9 017 010 → 88 891 байт**, 90 → 8 физических чтений, один блок НДС. Excel: **1 157 033 → 12 487 реально прочитанных ячеек**, поиск протяжённости 130 304 → 0 ячеек; 1240 подробных строк и малые заголовки/метаданные. `indexOnly` не читает блоков НДС. Счётчики включают служебный поиск высоты: обнаруженный в промежуточном варианте полный обход RunID устранён.

## Реализация и проверки

Новые компоненты: CResultBlockIndex, CIndexedSnapshotFile, CResultReadSource, modSnapshotTables, modIndexedExcelResults. CBinarySnapshotFile и CFileChecksum обеспечивают ограниченное буферизованное чтение и потоковый SHA; store разделяет v6 и совместимость v4/v5; snapshot хранит общий индекс. Writer захватывает границы блоков при формировании. Потребители схемы, сводок и AutoCAD используют выборочный источник без предварительной полной загрузки.

Один якорь индекса **rngNDMElementResultIndex, Results!DL156**, справа от аннотаций с двумя пустыми колонками; существующие таблицы не перемещены. Видимая большая таблица сохраняется. Индекс и строки НДС защищены от ручной перестановки, остальные области доступны. Отказ записи оставляет Invalid. Подробнее: [контракт формата](../IndexedSnapshotFormat.md).

Нативно проверены все 92 пары тяжёлого файла, полное и выборочное чтение, точность Double/Unicode/порядка и специальные смешанные типы; более 3 млн сравнений ячеек File/Excel. Проверены разные профили, несмежные участки одного ключа, разные количества/порядок элементов, отсутствующее состояние, reopen, File/Excel, настоящий новый расчёт на лёгком круге, очистка и перенос таблицы целиком. 19 проб повреждения/совместимости/атомарности и Save As завершены по ожиданиям. Повреждение непрочитанного блока допускает чтение другого состояния, но отвергается при чтении этого блока, полной проверке и полном восстановлении.

12 затронутых наборов No/Yes завершились без отказов: по 69 prepared, 62 preview, 123 boundary, 48 policy, 82 views и 992 full snapshot проверок в каждом режиме. Это **направленная приёмка**, не новый полный ON/OFF+Focused.

Неуспешные попытки сохранены. Исправлены ошибки только тестовых harness: проверка очистки ошибочно запрещала сохранённую шапку; последовательный runner оставлял File перед sheet-fixture; искусственный fixture индекса заменён реальной девятиколоночной схемой с явным RunID, проверки порядка/регистра/точных значений сохранены. В дополнительном таймере удалена лишняя зависимость от отсутствовавшей TestReadStateDetails; фаза без записанных таймеров исключена. Ожидания инженерных результатов не ослаблялись.

## Конечные артефакты

Публикация книги, сохранность пользовательских ячеек, исходники/экспорт и выход всех собственных процессов — ожидают конечной проверки. Исходный расчёт и резервы остаются локально; в Git предназначен чистый шаблон.
'''
(repo/'docs/reports/IndexedResults_2026-11-01.md').write_text(report,encoding='utf-8')
print('Measured sources sealed and factual performance report recorded')
