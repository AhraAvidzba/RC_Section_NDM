﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Измеряет исходную реализацию в отдельном Excel и сохраняет фактические данные.
param([int]$Diameter=900,[int]$Repeats=5,[int]$Attempt=2,[string]$SavedSnapshot="")
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$out=Join-Path $p ('Baseline'+$Diameter+"_Attempt"+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh baseline directory required'}
[void][IO.Directory]::CreateDirectory($out)
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Insufficient native memory reserve'}
$source=Join-Path $p 'Before.xlsm';$path=Join-Path $out 'Baseline.xlsm'
Copy-Item -LiteralPath $source -Destination $path
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestBaselineOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false;$records=@()
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestBaselineOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel attachment refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;Diameter=$Diameter;BaselineSourceSHA256=(Get-FileHash $source).Hash;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135
 $component=$book.VBProject.VBComponents.Add(1);$component.Name='modTestIndexedBaseline'
 $code=[IO.File]::ReadAllText((Join-Path $p 'modTestIndexedBaseline.bas'),[Text.Encoding]::UTF8)
 $component.CodeModule.AddFromString(($code -replace '(?m)^Attribute VB_Name.*\r?\n',''))
 # Счётчики добавляются только в эту частную копию; рабочий код не меняется.
 $module=$book.VBProject.VBComponents.Item('CBinarySnapshotFile').CodeModule
 $code=$module.Lines(1,$module.CountOfLines)
 $code=$code.Replace('mPosition = mPosition + remaining: copied = count','modTestIndexedBaseline.TestReadBytes remaining'+[Environment]::NewLine+'            mPosition = mPosition + remaining: copied = count')
 $code=$code.Replace('mReadCount = take: mReadOffset = 0','modTestIndexedBaseline.TestReadBytes take'+[Environment]::NewLine+'            mReadCount = take: mReadOffset = 0')
 $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($code)
 $module=$book.VBProject.VBComponents.Item('modSectionSnapshot').CodeModule
 $code=$module.Lines(1,$module.CountOfLines)
 $code=[regex]::Replace($code,'(?im)^(\s*ReadPhysicalResultTable = anchor\.Resize\(rowCount, columnCount\)\.value2)\s*$','$1'+[Environment]::NewLine+'    modTestIndexedBaseline.TestReadRows rowCount')
 $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($code)
 $module=$book.VBProject.VBComponents.Item('modCalculationSnapshot').CodeModule
 $module.AddFromString("`r`nPublic Function TestReadStateDetails() As String`r`nTestReadStateDetails = CStr(mReadDepth) & `"|`" & CStr(mReadSnapshot Is Nothing) & `"|`" & CStr(mReadWorkbook Is Nothing)`r`nEnd Function")
 $app.VBE.CommandBars.FindControl(1,578).Execute()
 $prefix="'$($book.Name)'!modTestIndexedBaseline."
 if($SavedSnapshot){Copy-Item -LiteralPath $SavedSnapshot -Destination (Join-Path $out 'IndexedBaseline.ndm');$created=[string]$app.Run($prefix+'TestUseSavedDataset')}else{$created=[string]$app.Run($prefix+'TestCreateDataset',[double]$Diameter)}
 Write-Output $created
 if(-not $created.StartsWith('OK|')){throw $created}
 $created|Set-Content (Join-Path $out 'Dataset.txt') -Encoding UTF8
 # Замеры записи включают свежий снимок, валидацию, вывод, привязку и elapsed.
 foreach($mode in @('File','Excel')){
  for($repeat=1;$repeat -le $Repeats;$repeat++){
   foreach($action in @("Save$mode","Select$mode","Select$mode","Restore$mode","Update$mode")){
    $process=Get-Process -Id $own
    if($process.PrivateMemorySize64 -gt 900MB){throw 'Private Excel memory guard'}
    $seconds=[double]$app.Run($prefix+'TestMeasure',[string]$action)
    if($seconds -lt 0){throw [string]$app.Run($prefix+'TestLastError')}
    $metric=[string]$app.Run($prefix+'TestMetrics')
    $records+=,[ordered]@{Action=$action;Repeat=$repeat;Seconds=$seconds;Metrics=$metric;PrivateBytes=(Get-Process -Id $own).PrivateMemorySize64}
    $records|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'Measurements.json') -Encoding UTF8
    Write-Output ($action+' '+$repeat+' '+$seconds.ToString('F4')+' '+$metric)
   }
  }
 }
 $book.Save()
 [ordered]@{Status='BASELINE_MEASURED';Dataset=$created;Records=$records.Count;SourceRuntimeUnchanged=$true;InstrumentationPrivate=$true;OSFileCache='Not evicted';SolverExcludedFromIOTiming=$true}|ConvertTo-Json|Set-Content (Join-Path $out 'Complete.json') -Encoding UTF8
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;$module=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
