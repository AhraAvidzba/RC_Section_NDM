Attribute VB_Name = "modTestIndexedBaseline"
Option Explicit

' ==================== ДЛЯ ТЕСТОВ ====================
' Создаёт реальный небольшой расчёт и измеряет IO отдельно от начального решателя.
' Работает только в частной книге runner-а. Не предназначен для основной книги.
Private Declare PtrSafe Function TestQpc Lib "kernel32" Alias "QueryPerformanceCounter" (ByRef value As Currency) As Long
Private Declare PtrSafe Function TestQpf Lib "kernel32" Alias "QueryPerformanceFrequency" (ByRef value As Currency) As Long
Private mTestFixture As CCalculationSnapshot
Private mTestRunID As Double, mTestElapsed As Double
Private mTestBytes As Double, mTestRows As Double, mTestReads As Long
Private mTestLastError As String, mTestState As String, mTestCase As String
Private mTestMetric As String, mTestDatasetStage As String
Private mTestUpperRows(1 To 4) As Long, mTestUpperColumns(1 To 4) As Long
Private mTestRangeCells As Double, mTestExtentCells As Double, mTestRangeCalls As Long
Private mTestPreparedSave As Boolean

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Таймер Windows измеряет весь явно указанный этап.
Private Function TestNow() As Double
    Dim ticks As Currency, frequency As Currency
    TestQpc ticks: TestQpf frequency: TestNow = ticks / frequency
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Runner добавляет этот вызов только в частную копию физического ReadFile.
Public Sub TestReadBytes(ByVal bytes As Long)
    mTestBytes = mTestBytes + bytes: mTestReads = mTestReads + 1
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Runner учитывает реальные диапазоны каждого пакетного Value2-чтения.
Public Sub TestReadRows(ByVal rows As Long)
    mTestRows = mTestRows + rows
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет только указанное значение существующей настройки в тестовой книге.
Private Sub TestSetting(ByVal key As String, ByVal value As Variant)
    Dim target As Range, row As Long
    Set target = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = key Then target.Cells(row, 2).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, , "Missing test setting " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает параметр круга по ключу; адреса пользовательской геометрии не зашиты.
Private Sub TestCircleValue(ByVal key As String, ByVal value As Double)
    Dim target As Range, row As Long
    Set target = ThisWorkbook.Names("rngCircleGeometry").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = key Then target.Cells(row, 3).Value2 = value: Exit Sub
    Next row
    Err.Raise 5, , "Missing Circle test key " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выбирает одинаковое отображаемое состояние во всех используемых профилях.
Private Sub TestVisualizationProfiles()
    Dim target As Range, data As Variant, row As Long, column As Long, header As Long
    Set target = ThisWorkbook.Names("rngCalculationProfiles").RefersToRange: data = target.Value2
    For row = 1 To UBound(data, 1)
        If CStr(data(row, 3)) = "PR1" Then header = row: Exit For
    Next row
    If header = 0 Then Err.Raise 5, , "Missing profile header"
    For row = 1 To UBound(data, 1)
        For column = 3 To UBound(data, 2)
            If Left$(CStr(data(header, column)), 2) = "PR" Then
                If CStr(data(row, 2)) = "Visualization.State" Then data(row, column) = "StrengthState"
                If CStr(data(row, 2)) = "Visualization.Quantity" Then data(row, column) = "Stress"
            End If
        Next column
    Next row
    target.Value2 = data
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подготавливает 20 валидных входных сочетаний без намеренных InputErr MIXED-фикстуры.
Public Function TestCreateDataset(ByVal diameter As Double) As String
    On Error GoTo Failed
    mTestDatasetStage = "Configure"
    modTestPerformance.TestConfigurePerformanceFixture "CAPACITY_CRACK_SP63", 20, "Newton", "Circle", "Normal", "Yes"
    TestSetting "General.ExecutionReportEnabled", "No"
    TestSetting "General.NonCriticalMessagesEnabled", "No"
    TestSetting "General.ReformatResultsEnabled", "No"
    TestSetting "Results.SnapshotStorage", "File"
    TestSetting "Results.SnapshotName", "IndexedBaseline"
    TestSetting "Mesh.StepMode", "User"
    TestSetting "Mesh.StepX", 50#: TestSetting "Mesh.StepY", 50#
    TestSetting "Mesh.CellGeometry", "Contour"
    TestSetting "Plot.Enabled", "No"
    TestSetting "Plot.AutoUpdateAfterCalculation", "No"
    TestCircleValue "D", diameter
    TestVisualizationProfiles
    Dim loads As Range, data As Variant, row As Long, factor As Double
    Set loads = ThisWorkbook.Names("rngLoadCombinations").RefersToRange: data = loads.Value2
    factor = diameter / 900#
    For row = 2 To 21
        data(row, 2) = CDbl(data(row, 2)) * factor ^ 2
        data(row, 3) = CDbl(data(row, 3)) * factor ^ 3
        data(row, 4) = CDbl(data(row, 4)) * factor ^ 3
        If row Mod 4 = 0 Then data(row, 5) = "PR2"
    Next row
    loads.Value2 = data
    mTestCase = "PERF_01": mTestState = "StrengthState"
    TestSetting "Output.CombinationMode", "User": TestSetting "Output.CombinationID", mTestCase
    Dim message As String
    mTestDatasetStage = "Form"
    message = FormSectionForWorkbook(ThisWorkbook)
    mTestDatasetStage = "Calculate"
    message = RunSectionCalculationForWorkbook(ThisWorkbook)
    Dim store As New CCalculationSnapshotStore
    Set mTestFixture = store.LoadFile(ThisWorkbook)
    mTestRunID = mTestFixture.RunID: mTestElapsed = mTestFixture.ElapsedSeconds
    TestRememberShapes
    Dim selected As Variant, states As Variant
    selected = mTestFixture.SelectElementResults(mTestCase, mTestState, False)
    If UBound(selected, 1) < 2 Then Err.Raise 5, , "Selected state absent in the actual fixture"
    states = mTestFixture.SelectElementResults("", "", True)
    TestSetting "Plot.Enabled", "Yes"
    TestCreateDataset = "OK|Elements=" & CStr(mTestFixture.TableRowCount("rngNDMSectionGeometry") - 1) & _
        "|ResultRows=" & CStr(mTestFixture.TableRowCount("rngNDMElementResults") - 1) & _
        "|LCStatePairs=" & CStr(UBound(states, 1) - 1) & "|SelectedRows=" & CStr(UBound(selected, 1) - 1)
    Exit Function
Failed:
    mTestLastError = mTestDatasetStage & "|" & Err.Source & "|" & CStr(Err.Number) & "|" & Err.Description: TestCreateDataset = "ERROR|" & mTestLastError
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Для замера записи заново присоединяет исходные таблицы, включая подготовку индекса.
Private Function TestFreshSnapshot() As CCalculationSnapshot
    If mTestPreparedSave Then Set TestFreshSnapshot = mTestFixture.TestPreparedClone: Exit Function
    If mTestFixture Is Nothing Then
        Dim loader As New CCalculationSnapshotStore
        Set mTestFixture = loader.LoadFile(ThisWorkbook)
    End If
    Dim sample As New CCalculationSnapshot, key As Variant, values As Variant
    sample.RunID = mTestRunID: sample.ElapsedSeconds = mTestElapsed
    For Each key In mTestFixture.Keys
        values = mTestFixture.Table(CStr(key)): sample.AddTable CStr(key), values
    Next key
    sample.Validate
    Set TestFreshSnapshot = sample
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Делит сценарии на доступ к данным, полную запись и полную команду обновления.
Public Function TestMeasure(ByVal action As String) As Double
    On Error GoTo Failed
    mTestLastError = vbNullString
    If Not TestCalculationSnapshotReadReleased() Then Err.Raise 5, , "Read context leaked before " & action
    Dim store As New CCalculationSnapshotStore, writer As New CNDMResultsWriter, summary As New CBatchResultWriter
    Dim fresh As CCalculationSnapshot, loaded As CCalculationSnapshot, values As Variant
    Dim started As Double, entered As Boolean, warning As String, hasWarning As Boolean
    mTestPreparedSave = (action = "SavePreparedFile" Or action = "SavePreparedExcel")
    If action = "SaveFile" Or action = "SaveExcel" Or mTestPreparedSave Then
        If mTestFixture Is Nothing Then Set mTestFixture = store.LoadFile(ThisWorkbook)
    Else
        Set mTestFixture = Nothing ' Первое чтение не использует подготовленный полный снимок.
    End If
    If Right$(action, 5) = "Excel" Then
        TestSetting "Results.SnapshotStorage", "Excel"
    Else
        TestSetting "Results.SnapshotStorage", "File"
    End If
    mTestBytes = 0#: mTestRows = 0#: mTestReads = 0
    mTestRangeCells = 0#: mTestExtentCells = 0#: mTestRangeCalls = 0
    started = TestNow()
    Select Case action
        Case "SaveFile", "SaveExcel", "SavePreparedFile", "SavePreparedExcel"
            Set fresh = TestFreshSnapshot()
            If action = "SaveFile" Or action = "SavePreparedFile" Then
                store.SaveFile ThisWorkbook, fresh
                writer.RestoreSnapshotBase ThisWorkbook, fresh, False, False
                summary.RestoreSummary ThisWorkbook, fresh, False
                store.LinkFile ThisWorkbook
                store.UpdateSavedElapsed ThisWorkbook, fresh
            Else
                writer.RestoreSnapshotBase ThisWorkbook, fresh, False, True
                summary.RestoreSummary ThisWorkbook, fresh, False
                store.ClearReference ThisWorkbook
            End If
        Case "SelectFile", "SelectExcel"
            BeginCalculationSnapshotRead ThisWorkbook: entered = True
            values = ReadElementResultTable(ThisWorkbook, mTestCase, mTestState)
            Call EndCalculationSnapshotRead: entered = False
        Case "RestoreFile"
            Set loaded = store.LoadFile(ThisWorkbook)
        Case "RestoreExcel"
            Dim key As Variant, restored As Object, anchor As Range, item As Long, names As Variant, headers As Variant
            Set restored = CreateObject("Scripting.Dictionary")
            For Each key In Array("rngNDMSectionGeometry", "rngNDMSectionContours", "rngNDMElementGeometry", "rngNDMSectionProperties", "rngNDMMaterialDiagrams", "rngNDMElementResults", "rngNDMSectionAnnotations")
                values = ReadPhysicalResultTable(ThisWorkbook, CStr(key)): restored.Add CStr(key), values
            Next key
            names = Array("rngBatchSummary", "rngStrengthSummaryAnchor", "rngCrackSummaryAnchor", "rngStabilitySummaryAnchor")
            headers = Array(0, 4, 4, 5)
            For item = 0 To 3
                Set anchor = ThisWorkbook.Names(CStr(names(item))).RefersToRange.Offset(-CLng(headers(item)), 0)
                values = anchor.Resize(mTestUpperRows(item + 1), mTestUpperColumns(item + 1)).Value2
                TestReadRange mTestUpperRows(item + 1), mTestUpperColumns(item + 1), False
                restored.Add CStr(names(item)), values
            Next item
        Case "UpdateFile", "UpdateExcel"
            UpdateSectionResultsForWorkbook ThisWorkbook, , warning, hasWarning
            If hasWarning Then Err.Raise 5, , warning
        Case Else
            Err.Raise 5, , "Unknown benchmark action " & action
    End Select
    TestMeasure = TestNow() - started
    If Not TestCalculationSnapshotReadReleased() Then Err.Raise 5, , "Read context leaked after " & action
    mTestMetric = "Bytes=" & CStr(mTestBytes) & "|PhysicalReadCalls=" & CStr(mTestReads) & "|RangeCells=" & CStr(mTestRangeCells) & "|ExtentCells=" & CStr(mTestExtentCells) & "|RangeCalls=" & CStr(mTestRangeCalls)
    If action = "SelectFile" Or action = "SelectExcel" Then
        If UBound(values, 1) < 2 Then Err.Raise 5, , "Empty selected result"
        mTestMetric = mTestMetric & "|SelectedRows=" & CStr(UBound(values, 1) - 1)
    End If
    Exit Function
Failed:
    If entered Then EndCalculationSnapshotRead
    mTestLastError = Err.Description: TestMeasure = -1#
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает фактические счётчики той же измеренной операции.
Public Function TestMetrics() As String
    TestMetrics = mTestMetric
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ошибка передаётся runner-у без окна отладчика Excel.
Public Function TestLastError() As String
    TestLastError = mTestLastError
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Использует подлинный сохранённый тяжёлый расчёт; решатель не запускается.
Public Function TestUseSavedDataset() As String
    On Error GoTo Failed
    TestSetting "General.ExecutionReportEnabled", "No"
    TestSetting "General.NonCriticalMessagesEnabled", "No"
    TestSetting "General.ReformatResultsEnabled", "No"
    TestSetting "Results.SnapshotStorage", "File"
    TestSetting "Results.SnapshotName", "IndexedBaseline"
    TestSetting "Plot.Enabled", "Yes"
    mTestCase = "PERF_01": mTestState = "StrengthState"
    TestSetting "Output.CombinationMode", "User": TestSetting "Output.CombinationID", mTestCase
    TestVisualizationProfiles
    Dim store As New CCalculationSnapshotStore, states As Variant, selected As Variant
    Set mTestFixture = store.LoadFile(ThisWorkbook)
    mTestRunID = mTestFixture.RunID: mTestElapsed = mTestFixture.ElapsedSeconds
    TestRememberShapes
    states = mTestFixture.SelectElementResults("", "", True)
    selected = mTestFixture.SelectElementResults(mTestCase, mTestState, False)
    If UBound(selected, 1) < 2 Then Err.Raise 5, , "Heavy selected state missing"
    TestUseSavedDataset = "OK|Elements=" & CStr(mTestFixture.TableRowCount("rngNDMSectionGeometry") - 1) & _
        "|ResultRows=" & CStr(mTestFixture.TableRowCount("rngNDMElementResults") - 1) & _
        "|LCStatePairs=" & CStr(UBound(states, 1) - 1) & "|SelectedRows=" & CStr(UBound(selected, 1) - 1) & "|SolverCalls=0"
    Exit Function
Failed:
    mTestLastError = Err.Description: TestUseSavedDataset = "ERROR|" & mTestLastError
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет только размеры реально сохранённых верхних таблиц, не полный снимок для чтения.
Private Sub TestRememberShapes()
    mTestUpperRows(1) = mTestFixture.TableRowCount("Summary"): mTestUpperColumns(1) = 33
    mTestUpperRows(2) = mTestFixture.TableRowCount("Strength.Data") + 4: mTestUpperColumns(2) = 49
    mTestUpperRows(3) = mTestFixture.TableRowCount("Cracks.Data") + 4: mTestUpperColumns(3) = 72
    mTestUpperRows(4) = mTestFixture.TableRowCount("Stability.Data") + 5: mTestUpperColumns(4) = 84
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает все физические диапазоны Value2, включая поиск высоты и индексные метаданные.
Public Sub TestReadRange(ByVal rows As Long, ByVal columns As Long, ByVal extent As Boolean)
    mTestRangeCells = mTestRangeCells + CDbl(rows) * columns: mTestRangeCalls = mTestRangeCalls + 1
    If extent Then mTestExtentCells = mTestExtentCells + CDbl(rows) * columns
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Переключает выбор на другое фактически существующее состояние без расчёта и без полного снимка в кэше.
Public Sub TestSelectState(ByVal combinationID As String, ByVal stateType As String)
    mTestCase = combinationID: mTestState = stateType
End Sub
