"""ДЛЯ ТЕСТОВ: передаёт настоящий RunID только из завершённого расчётного потока."""
from pathlib import Path
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM');P=Path(__file__).parent/'Candidate'
t=(R/'src/Excel/modWorkbookCalculation.bas').read_text(encoding='utf-8-sig')
t=t.replace('Dim completed As Boolean, destination As String, message As String\n    message = CalculateSectionCore(workbook, showMessages, startedAt, informationEnabled, requiresAttention, completed, destination)','Dim completed As Boolean, destination As String, message As String, savedRunID As Double\n    message = CalculateSectionCore(workbook, showMessages, startedAt, informationEnabled, requiresAttention, completed, destination, savedRunID)')
t=t.replace('"Время расчёта", requiresAttention, True)','"Время расчёта", requiresAttention, True, savedRunID)')
t=t.replace('Optional ByRef completed As Boolean = False, Optional ByRef savedDestination As String = "") As String','Optional ByRef completed As Boolean = False, Optional ByRef savedDestination As String = "", Optional ByRef savedRunID As Double = 0#) As String')
a=t.index('Private Function CalculateSectionCore(');b=t.index('End Function',a)
section=t[a:b]
assert section.count('    completed = True')==1
section=section.replace('    completed = True','    savedRunID = savedSnapshot.RunID\n    completed = True')
t=t[:a]+section+t[b:]
t=t.replace('ByVal timeCaption As String, ByRef requiresAttention As Boolean, Optional ByVal calculated As Boolean = False) As String','ByVal timeCaption As String, ByRef requiresAttention As Boolean, Optional ByVal calculated As Boolean = False, Optional ByVal expectedRunID As Double = 0#) As String')
old='''        Dim snapshot As CCalculationSnapshot: Set snapshot = New CCalculationSnapshot
        snapshot.ElapsedSeconds = ElapsedSecondsFrom(startedAt)
        Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
        store.UpdateSavedElapsed workbook, snapshot
        Dim summary As CBatchResultWriter: Set summary = New CBatchResultWriter
        summary.UpdateElapsedSeconds workbook, snapshot.ElapsedSeconds'''
assert old in t
t=t.replace(old,'''        Dim elapsed As Double: elapsed = ElapsedSecondsFrom(startedAt)
        Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
        store.UpdateElapsedValue workbook, elapsed, expectedRunID
        Dim summary As CBatchResultWriter: Set summary = New CBatchResultWriter
        summary.UpdateElapsedSeconds workbook, elapsed''')
assert t.count('savedRunID = savedSnapshot.RunID')==1
(P/'modWorkbookCalculation.bas').write_text(t,encoding='utf8')
print('Prepared workflow elapsed metadata with actual RunID and no partial snapshot')
