﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Закрывает только доказанно завершённый собственный Excel с неизменной CPU после Quit.
$ErrorActionPreference='Stop'
$d=Join-Path $PSScriptRoot 'Prototype7'
$own=Get-Content -LiteralPath (Join-Path $d 'Own.json') -Raw|ConvertFrom-Json
$quit=Get-Content -LiteralPath (Join-Path $d 'Quit.json') -Raw|ConvertFrom-Json
$measurements=@(Get-Content -LiteralPath (Join-Path $d 'Measurements.json') -Raw|ConvertFrom-Json)
if([int]$own.PID -ne 70948 -or [string]$own.UTCStartTicks -ne '639291220195408614' -or -not $quit.QuitReturned -or $measurements.Count -ne 40){throw 'Exact completed native run with all measurements required'}
foreach($name in 'Result.txt','ExcelResult.txt'){
 if(-not([IO.File]::ReadAllText((Join-Path $d $name)).StartsWith('PASS|'))){throw 'Primary pass missing'}
}
$process=Get-Process -Id 70948 -ErrorAction SilentlyContinue
if(-not $process){Write-Output 'ConfirmedNotFound';exit}
if($process.ProcessName -ne 'EXCEL' -or [string]$process.StartTime.ToUniversalTime().Ticks -ne [string]$own.UTCStartTicks){throw 'PID reuse: do not touch'}
$cpuBefore=$process.CPU;$private=$process.PrivateMemorySize64
if($process.WaitForExit(10000)){Write-Output 'Ordinary exit during observation';exit}
$process.Refresh();$cpuAfter=$process.CPU
if([string]$process.StartTime.ToUniversalTime().Ticks -ne [string]$own.UTCStartTicks -or $cpuAfter-$cpuBefore -gt 0.05){throw 'Identity changed or Excel is still using CPU; do not stop'}
[ordered]@{PID=$own.PID;UTCStartTicks=$own.UTCStartTicks;OriginalBookCloseCompleted=$true;OriginalQuitReturned=$quit.QuitReturned;PrimaryFilePASS=$true;PrimaryExcelPASS=$true;Measurements=$measurements.Count;CPUStart=$cpuBefore;CPUEnd=$cpuAfter;CPUObservationMilliseconds=10000;PrivateBytes=$private;ObservedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $d 'IdleCompletedOwnBeforeClose.json') -Encoding UTF8
Stop-Process -Id 70948 -ErrorAction Stop
if(-not $process.WaitForExit(5000)){throw 'Own Excel did not exit'}
Write-Output 'Closed only completed idle own Excel 70948 / 639291220195408614 after proofs'
