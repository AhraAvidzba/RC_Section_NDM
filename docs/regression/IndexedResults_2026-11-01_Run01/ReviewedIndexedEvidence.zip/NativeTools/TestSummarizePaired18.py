"""ДЛЯ ТЕСТОВ: сводит фактически завершённые парные измерения без округления исходных данных."""
import hashlib
import json
import statistics
from pathlib import Path
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

results = {}
for dataset in ('Light', 'Heavy'):
    folder = root / f'Paired16_{dataset}_Attempt1'
    completion = json.loads((folder / 'Complete.json').read_text(encoding='utf-8-sig'))
    assert completion['Status'] == 'PAIRED_BENCHMARK_MEASURED'
    records = json.loads((folder / 'Measurements.json').read_text(encoding='utf-8-sig'))
    result = {'RawSHA256': digest(folder / 'Measurements.json'), 'Actions': {}}
    for action in dict.fromkeys(r['Label'] for r in records if r['Cycle'] > 0):
        entry = {}
        for version in ('Before', 'After'):
            group = [r for r in records if r['Label'] == action and r['Version'] == version and r['Cycle'] > 0]
            assert len(group) == 6, (action, version, len(group))
            seconds = [r['Seconds'] for r in group]
            entry[version] = {'Count': len(seconds), 'Median': statistics.median(seconds),
                              'Min': min(seconds), 'Max': max(seconds),
                              'Metrics': list(dict.fromkeys(r['Metrics'] for r in group))}
        entry['BeforeOverAfter'] = entry['Before']['Median'] / entry['After']['Median']
        result['Actions'][action] = entry
    results[dataset] = result

manifest = {p.name: digest(p) for p in sorted((root / 'Candidate').iterdir()) if p.is_file()}
output = {'Status': 'PAIRED_LIGHT_HEAVY_NATIVE_MEASURED', 'UTC': datetime.now(timezone.utc).isoformat(),
          'Method': 'Three ABBA cycles, six samples per version and phase; warm-ups excluded; no OS cache flush',
          'PreparedIndexIncluded': True, 'CandidateFilesSHA256': manifest, 'Datasets': results}
(root / 'PairedBenchmarkSummary18.json').write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
for dataset, result in results.items():
    print(dataset)
    for action, entry in result['Actions'].items():
        print(f"{action}: {entry['Before']['Median']:.6f} -> {entry['After']['Median']:.6f}; x{entry['BeforeOverAfter']:.2f}")
