"""ДЛЯ ТЕСТОВ: устраняет повторную защиту листа и повторные преобразования ключей."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'CResultBlockIndex.cls').read_text(encoding='utf8')
a=t.index('Private Sub BuildCore(');b=t.index("' Устанавливает шапку",a)
t=t[:a]+'''Private Sub BuildCore(ByRef values As Variant, ByRef header As Variant, ByVal runID As Double, ByVal runIDsValidated As Boolean)
    Dim row As Long, first As Long, previousCase As String, previousProfile As String, previousState As String
    Dim caseKind As Long, profileKind As Long, stateKind As Long, changed As Boolean
    Initialize header, runID
    If UBound(values, 1) < 2 Then Exit Sub
    first = 2
    previousCase = CStr(values(2, 2)): previousProfile = CStr(values(2, 3)): previousState = CStr(values(2, 4))
    caseKind = VarType(values(2, 2)): profileKind = VarType(values(2, 3)): stateKind = VarType(values(2, 4))
    If Len(previousCase) = 0 Or Len(previousProfile) = 0 Or Len(previousState) = 0 Then Err.Raise 5, , "Пустой ключ сочетания, профиля или состояния."
    For row = 2 To UBound(values, 1)
        If Not runIDsValidated Then
            If Not IsNumeric(values(row, 1)) And VarType(values(row, 1)) <> vbDate Then Err.Raise 5, , "В результатах элементов отсутствует RunID."
            If CDbl(values(row, 1)) <> runID Then Err.Raise 5, , "Результаты элементов относятся к другому расчёту."
        End If
        changed = StrComp(values(row, 2), previousCase, vbBinaryCompare) <> 0 Or StrComp(values(row, 3), previousProfile, vbBinaryCompare) <> 0 Or _
            StrComp(values(row, 4), previousState, vbBinaryCompare) <> 0 Or VarType(values(row, 2)) <> caseKind Or VarType(values(row, 3)) <> profileKind Or VarType(values(row, 4)) <> stateKind
        If changed Then
            AppendArrayBlock values, first, row - first
            first = row
            previousCase = CStr(values(row, 2)): previousProfile = CStr(values(row, 3)): previousState = CStr(values(row, 4))
            caseKind = VarType(values(row, 2)): profileKind = VarType(values(row, 3)): stateKind = VarType(values(row, 4))
            If Len(previousCase) = 0 Or Len(previousProfile) = 0 Or Len(previousState) = 0 Then Err.Raise 5, , "Пустой ключ сочетания, профиля или состояния."
        End If
    Next row
    AppendArrayBlock values, first, UBound(values, 1) - first + 1
End Sub

'''+t[b:]
(P/'CResultBlockIndex.cls').write_text(t,encoding='utf8')
t=(P/'modIndexedExcelResults.bas').read_text(encoding='utf8')
t=t.replace('''        sheet.Protect Password:=PROTECTION_PASSWORD, DrawingObjects:=False, Contents:=True, Scenarios:=False, UserInterfaceOnly:=True
    ElseIf''','''        If Not sheet.ProtectContents Or Not sheet.ProtectionMode Then sheet.Protect Password:=PROTECTION_PASSWORD, DrawingObjects:=False, Contents:=True, Scenarios:=False, UserInterfaceOnly:=True
    ElseIf''')
t=t.replace('''    sheet.Protect Password:=PROTECTION_PASSWORD, DrawingObjects:=False, Contents:=True, Scenarios:=False, UserInterfaceOnly:=True
    Exit Sub''','''    If Not sheet.ProtectContents Or Not sheet.ProtectionMode Then sheet.Protect Password:=PROTECTION_PASSWORD, DrawingObjects:=False, Contents:=True, Scenarios:=False, UserInterfaceOnly:=True
    Exit Sub''')
a=t.index('    Dim locked As Variant: locked = elements.Resize(rows, 9).Locked')
b=t.index('    locked = anchor.Resize(indexRows, INDEX_COLUMNS).Locked',a)
t=t[:a]+'''    Dim locked As Variant: locked = elements.Cells(1, 1).Locked
    If Not CBool(locked) Then Err.Raise 5, , "Якорь результатов перемещён из защищённой структуры. Выполните расчёт заново."
'''+t[b:]
t=t.replace('прежней книги','книги без индекса').replace('прежней таблицу','таблицу без индекса')
(P/'modIndexedExcelResults.bas').write_text(t,encoding='utf8')
print('Prepared bounded structural checks and cheaper shared index build')
