"""ДЛЯ ТЕСТОВ: готовит изолированные потоковые изменения; исходники проекта не меняет."""
from pathlib import Path
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
P=Path(__file__).parent/'Candidate'
P.mkdir(exist_ok=True)
def one(t,a,b):
 assert t.count(a)==1,(a,t.count(a))
 return t.replace(a,b)
t=(R/'src/Excel/CFileChecksum.cls').read_text(encoding='utf-8-sig')
t=one(t,'Private mGeometryProvider As LongPtr', 'Private mStreamProvider As LongPtr, mStreamHash As LongPtr\nPrivate mGeometryProvider As LongPtr')
t=one(t,'Private Sub Class_Terminate()','Private Sub Class_Terminate()\n    CancelDigest\n    If mStreamProvider <> 0 Then CryptReleaseContext mStreamProvider, 0: mStreamProvider = 0')
t+='''
' Начинает независимый SHA256-блок, повторно используя только провайдер Windows.
Public Sub BeginDigest()
    If mStreamHash <> 0 Then Err.Raise 5, , "Предыдущая контрольная сумма не завершена."
    If mStreamProvider = 0 Then
        If CryptAcquireContextW(mStreamProvider, 0, 0, 24, &HF0000000) = 0 Then Err.Raise 5, , "Не удалось открыть SHA256 Windows."
    End If
    If CryptCreateHash(mStreamProvider, &H800C&, 0, 0, mStreamHash) = 0 Then Err.Raise 5, , "Не удалось создать SHA256 блока."
End Sub

' Учитывает уже подготовленную память без файлового прохода и промежуточного массива.
Friend Sub DigestMemory(ByVal address As LongPtr, ByVal count As Long)
    If mStreamHash = 0 Or count < 0 Then Err.Raise 5, , "Не начата контрольная сумма блока."
    If count = 0 Then Exit Sub
    If HashGeometryMemory(mStreamHash, address, count, 0) = 0 Then Err.Raise 5, , "Ошибка SHA256 блока."
End Sub

' Завершает только текущий блок; соседний блок получает новый объект hash.
Public Function EndDigest() As String
    If mStreamHash = 0 Then Err.Raise 5, , "Контрольная сумма не начата."
    Dim digest(0 To 31) As Byte, count As Long, i As Long
    count = 32
    If CryptGetHashParam(mStreamHash, 2, digest(0), count, 0) = 0 Or count <> 32 Then Err.Raise 5, , "Не удалось получить SHA256 блока."
    For i = 0 To 31: EndDigest = EndDigest & Right$("0" & Hex$(digest(i)), 2): Next i
    CancelDigest
End Function

' Освобождает незавершённую сумму после ошибки, не меняя геометрический hash.
Public Sub CancelDigest()
    If mStreamHash <> 0 Then CryptDestroyHash mStreamHash: mStreamHash = 0
End Sub
'''
(P/'CFileChecksum.cls').write_text(t,encoding='utf8')
t=(R/'src/Excel/CBinarySnapshotFile.cls').read_text(encoding='utf-8-sig')
t=one(t,'Private mReadCount As Long, mReadOffset As Long', '''Private mDigest As CFileChecksum ' Потоковая сумма блока; не требует сброса буфера между состояниями.
Private mDigestWriting As Boolean, mDigestReading As Boolean, mDigestStart As Long
Private mReadLimit As Long ' Конец текущего проверяемого окна, исключая соседние блоки из prefetch.
Private mBytesRead As Double, mReadCalls As Long
Private mReadCount As Long, mReadOffset As Long''')
t=one(t,'    mPosition = 0\nEnd Sub','    mPosition = 0: mReadLimit = mSize: mBytesRead = 0#: mReadCalls = 0\nEnd Sub')
t=one(t,'    If mHandle <> 0 Then FlushWrites: CloseHandle mHandle: mHandle = 0','''    If mHandle <> 0 Then FlushWrites: CloseHandle mHandle: mHandle = 0
    If Not mDigest Is Nothing Then mDigest.CancelDigest
    mDigestWriting = False: mDigestReading = False''')
t=one(t,'Public Property Let Position(ByVal value As Long)','''Public Property Let Position(ByVal value As Long)
    If mDigestWriting Or mDigestReading Then Err.Raise 5, , "Перемещение внутри незавершённого блока запрещено."
    mReadLimit = mSize''')
t=t.replace('count > mSize - mPosition','count > mReadLimit - mPosition').replace('CDbl(count) * 8 > mSize - mPosition','CDbl(count) * 8 > mReadLimit - mPosition').replace('CDbl(count) * 4 > mSize - mPosition','CDbl(count) * 4 > mReadLimit - mPosition')
t=one(t,'            mPosition = mPosition + remaining: copied = count','''            mBytesRead = mBytesRead + remaining: mReadCalls = mReadCalls + 1
            If mDigestReading Then mDigest.DigestMemory target + copied, remaining
            mPosition = mPosition + remaining: copied = count''')
t=one(t,'            take = mSize - mPosition: If take > 65536 Then take = 65536','            take = mReadLimit - mPosition: If take > 65536 Then take = 65536')
t=one(t,'            mReadCount = take: mReadOffset = 0','''            mBytesRead = mBytesRead + take: mReadCalls = mReadCalls + 1
            If mDigestReading Then mDigest.DigestMemory VarPtr(mReadBuffer(0)), take
            mReadCount = take: mReadOffset = 0''')
t=one(t,'        If WriteFile(mHandle, source, count, done, 0) = 0 Or done <> count Then Err.Raise 5, "CBinarySnapshotFile", "Ошибка записи файла: " & mPath','''        If WriteFile(mHandle, source, count, done, 0) = 0 Or done <> count Then Err.Raise 5, "CBinarySnapshotFile", "Ошибка записи файла: " & mPath
        If mDigestWriting Then mDigest.DigestMemory source, count''')
t=one(t,'    mBuffered = 0\nEnd Sub','''    If mDigestWriting Then
        If mBuffered > mDigestStart Then mDigest.DigestMemory VarPtr(mWriteBuffer(mDigestStart)), mBuffered - mDigestStart
        mDigestStart = 0
    End If
    mBuffered = 0
End Sub''')
t+='''
' Начинает сумму следующего записываемого блока без физического сброса 64-КиБ буфера.
Public Sub BeginWriteDigest()
    If mDigestWriting Or mDigestReading Then Err.Raise 5, , "Контрольная сумма предыдущего блока не завершена."
    If mDigest Is Nothing Then Set mDigest = New CFileChecksum
    mDigest.BeginDigest: mDigestStart = mBuffered: mDigestWriting = True
End Sub

' Учитывает оставшийся хвост блока, оставляя его в общем буфере записи.
Public Function EndWriteDigest() As String
    If Not mDigestWriting Then Err.Raise 5, , "Не начата запись проверяемого блока."
    If mBuffered > mDigestStart Then mDigest.DigestMemory VarPtr(mWriteBuffer(mDigestStart)), mBuffered - mDigestStart
    EndWriteDigest = mDigest.EndDigest: mDigestWriting = False: mDigestStart = mBuffered
End Function

' Ограничивает физическое чтение ровно выбранным блоком до выделения его матриц.
Public Sub BeginReadDigest(ByVal offset As Long, ByVal bytes As Long)
    If mDigestWriting Or mDigestReading Then Err.Raise 5, , "Предыдущий блок не завершён."
    If offset < 0 Or bytes < 1 Or CDbl(offset) + bytes > mSize Then Err.Raise 5, , "Блок выходит за границы файла."
    Position = offset: mReadLimit = offset + bytes
    If mDigest Is Nothing Then Set mDigest = New CFileChecksum
    mDigest.BeginDigest: mDigestReading = True
End Sub

' Полное потребление ограниченного блока обязательно: лишние байты также являются ошибкой.
Public Function EndReadDigest() As String
    If Not mDigestReading Or mPosition <> mReadLimit Then Err.Raise 5, , "Длина прочитанного блока не совпадает с каталогом."
    EndReadDigest = mDigest.EndDigest: mDigestReading = False: mReadLimit = mSize
End Function

' Возвращает доступный остаток текущего блока для проверки размеров до выделения памяти.
Public Property Get RemainingBytes() As Long
    RemainingBytes = mReadLimit - mPosition
End Property

' Счётчик реальных байтов ReadFile включает все проверки, но не логические обращения к буферу.
Public Property Get BytesRead() As Double
    BytesRead = mBytesRead
End Property

' Счётчик физических обращений к Windows показывает действие буферизации.
Public Property Get ReadCalls() As Long
    ReadCalls = mReadCalls
End Property
'''
(P/'CBinarySnapshotFile.cls').write_text(t,encoding='utf8')
print('Prepared isolated checksum and bounded-stream candidate; no production changes')
