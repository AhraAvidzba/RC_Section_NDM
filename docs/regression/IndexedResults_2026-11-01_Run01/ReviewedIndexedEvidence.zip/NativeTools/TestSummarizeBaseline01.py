"""ДЛЯ ТЕСТОВ: фиксирует измеренный baseline и неизменность производственных исходников."""
import json,hashlib,statistics,datetime
from pathlib import Path
P=Path(__file__).parent
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
before=json.loads((P/'BeforeManifest.json').read_text(encoding='utf-8-sig'))
changed=[f['Path'] for f in before['Files'] if hashlib.sha256((R/f['Path']).read_bytes()).hexdigest().upper()!=f['SHA256']]
assert not changed,changed
records=[]
for name in ['Baseline900_Attempt5','Baseline2100_Attempt5','Baseline1232_Attempt6']:
 d=P/name
 complete=json.loads((d/'Complete.json').read_text(encoding='utf-8-sig'))
 data=json.loads((d/'Measurements.json').read_text(encoding='utf-8-sig'))
 assert len(data)==50 and complete['Status']=='BASELINE_MEASURED'
 actions={}
 for a in dict.fromkeys(r['Action'] for r in data):
  group=[r for r in data if r['Action']==a]
  seconds=[r['Seconds'] for r in group]
  actions[a]={'Count':len(group),'MedianSeconds':statistics.median(seconds),'MinSeconds':min(seconds),'MaxSeconds':max(seconds),'Metrics':sorted(set(r['Metrics'] for r in group))}
 records.append({'Directory':name,'Dataset':complete['Dataset'],'Actions':actions,'Artifacts':{f.name:hashlib.sha256(f.read_bytes()).hexdigest().upper() for f in d.iterdir() if f.is_file()}})
out={'Status':'BASELINE_MEASURED_PRODUCTION_RUNTIME_UNCHANGED','BeforeCommit':before['Commit'],'ProductionFilesChecked':len(before['Files']),'ChangedProductionFiles':changed,'MeasuredUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'Datasets':records,'Limitations':['Select repetitions each use a new read scope; OS cache was not evicted. No ready full snapshot is reused.','RestoreExcel measures all seven physical technical result tables, not a full CCalculationSnapshot including upper summaries/profiles; additional full-table timing is still required.','Current series selects one state repeatedly; switching/reopen/parity and additional correctness scenarios remain to be completed.','The genuine heavy archive was loaded, never recalculated. Its 30 input combinations include four historical InputErr cases.','Failed harness attempts 1..4 are retained and excluded; attempt 2 was not a cold-read baseline because an ambiguous bare VBA label skipped a scope-end call.']}
(P/'BaselineMeasured01.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
for d in records:
 print(d['Directory'],d['Dataset'])
 for k,v in d['Actions'].items():print(k,round(v['MedianSeconds'],4))
