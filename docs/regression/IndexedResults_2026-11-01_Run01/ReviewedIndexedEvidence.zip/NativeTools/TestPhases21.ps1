﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Измеряет этапы штатного обновления без перерасчёта в двух частных VBProject.
param([ValidateSet('Light','Heavy')][string]$Dataset='Heavy',[int]$Attempt=1)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$out=Join-Path $p ('Phases21_'+$Dataset+'_Attempt'+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh phases directory required'}
[void][IO.Directory]::CreateDirectory($out)
$payload=Join-Path $p 'Baseline900_Attempt5/IndexedBaseline.ndm'
if($Dataset -eq 'Heavy'){$payload=Join-Path $p '../ActionLatency_2026-10-28_Run01/StorageRun02/Heavy1232_30_Optimized.ndm'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestPhasesOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$records=@()
foreach($version in 'Before','After'){
 $os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
 $dir=Join-Path $out $version;[void][IO.Directory]::CreateDirectory($dir)
 $path=Join-Path $dir 'Phases.xlsm';Copy-Item -LiteralPath (Join-Path $p 'Before.xlsm') -Destination $path
 Copy-Item -LiteralPath $payload -Destination (Join-Path $dir 'IndexedBaseline.ndm')
 $app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
 $existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
 try{
  $app=New-Object -ComObject Excel.Application
  [uint32]$id=0;[void][NDMTestPhasesOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
  if($existing -contains [int]$id){throw 'Existing Excel refused'}
  $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
  [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $dir 'Own.json') -Encoding UTF8
  $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
  $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135
  $files=@((Get-Item -LiteralPath (Join-Path $p 'modTestIndexedBaseline.bas')),(Get-Item -LiteralPath (Join-Path $p 'modTestResultPhases.bas')))
  if($version -eq 'After'){$files+=@(Get-ChildItem -File -LiteralPath (Join-Path $p 'Candidate'))}
  foreach($file in $files){
   $component=$null;try{$component=$book.VBProject.VBComponents.Item($file.BaseName)}catch{}
   if(-not $component){$kind=1;if($file.Extension -eq '.cls'){$kind=2};$component=$book.VBProject.VBComponents.Add($kind);$component.Name=$file.BaseName}
   $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
   if($file.Extension -eq '.cls'){$code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')}else{$code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')}
   if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
   $component.CodeModule.AddFromString($code)
  }
  foreach($name in 'modWorkbookCalculation','modCalculationSnapshot','CNDMResultsWriter','CBatchResultWriter'){
   $component=$book.VBProject.VBComponents.Item($name);$code=$component.CodeModule.Lines(1,$component.CodeModule.CountOfLines)
   if($name -eq 'modWorkbookCalculation'){
    $code=[regex]::Replace($code,'(?im)^    reader\.LoadFromWorkbook workbook, settings\s*$','    modTestResultPhases.TestStart "PlotData": reader.LoadFromWorkbook workbook, settings: modTestResultPhases.TestStop "PlotData"')
    $code=[regex]::Replace($code,'(?im)^    plotter\.Draw workbook, reader, settings, containerNotice\s*$','    modTestResultPhases.TestStart "Draw": plotter.Draw workbook, reader, settings, containerNotice: modTestResultPhases.TestStop "Draw"')
   }
   if($name -eq 'modCalculationSnapshot'){
    $code=[regex]::Replace($code,'(?im)^            Set snapshot = store\.LoadFile\(workbook\)\s*$','            modTestResultPhases.TestStart "CommonRead": Set snapshot = store.LoadFile(workbook): modTestResultPhases.TestStop "CommonRead"')
    $code=[regex]::Replace($code,'(?im)^    source\.ValidateForDisplay\s*$','    modTestResultPhases.TestStart "CommonRead": source.ValidateForDisplay: modTestResultPhases.TestStop "CommonRead"')
    $code=[regex]::Replace($code,'(?im)^    writer\.RestoreSnapshotBase workbook, snapshot, fullFormatting, mode = "Excel"\s*$','    modTestResultPhases.TestStart "BaseOutput": writer.RestoreSnapshotBase workbook, snapshot, fullFormatting, mode = "Excel": modTestResultPhases.TestStop "BaseOutput"')
    $code=[regex]::Replace($code,'(?im)^    writer\.RestoreIndexedBase workbook, source, fullFormatting\s*$','    modTestResultPhases.TestStart "BaseOutput": writer.RestoreIndexedBase workbook, source, fullFormatting: modTestResultPhases.TestStop "BaseOutput"')
    $code=[regex]::Replace($code,'(?im)^        summary\.RestoreSummary workbook, snapshot, fullFormatting\s*$','        modTestResultPhases.TestStart "SummaryOutput": summary.RestoreSummary workbook, snapshot, fullFormatting: modTestResultPhases.TestStop "SummaryOutput"')
    $code=[regex]::Replace($code,'(?i)Else summary\.RestoreIndexedSummary workbook, source, fullFormatting','Else modTestResultPhases.TestStart "SummaryOutput": summary.RestoreIndexedSummary workbook, source, fullFormatting: modTestResultPhases.TestStop "SummaryOutput"')
   }
   if($name -in @('modWorkbookCalculation','modCalculationSnapshot') -and $code -notmatch 'modTestResultPhases.TestStart'){throw ('Phase instrumentation missing: '+$name)}
   $code|Set-Content (Join-Path $dir ($name+'.instrumented.txt')) -Encoding UTF8
   $component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines);$component.CodeModule.AddFromString($code)
  }
  $prefix="'$($book.Name)'!"
  $datasetInfo=[string]$app.Run($prefix+'modTestIndexedBaseline.TestUseSavedDataset')
  if(-not $datasetInfo.StartsWith('OK|')){throw $datasetInfo}
  foreach($mode in 'File','Excel'){
   $save=[double]$app.Run($prefix+'modTestIndexedBaseline.TestMeasure',('Save'+$mode));if($save -lt 0){throw [string]$app.Run($prefix+'modTestIndexedBaseline.TestLastError')}
   for($repeat=0;$repeat -le 3;$repeat++){
    $result=[string]$app.Run($prefix+'modTestResultPhases.TestMeasurePhases',$mode)
    Write-Output ($version+' '+$mode+' '+$repeat+' '+$result)
    if($result.StartsWith('ERROR|')){throw $result}
    if($result -notmatch '\|Draw=' -or $result -notmatch '\|PlotData='){throw 'Phase timers did not record real read and draw calls'}
    $records+=,[ordered]@{Version=$version;Mode=$mode;Repeat=$repeat;Dataset=$Dataset;Result=$result}
    $records|ConvertTo-Json|Set-Content (Join-Path $out 'Measurements.json') -Encoding UTF8
   }
  }
 }finally{
  if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
  $component=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
  if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
  [GC]::Collect();[GC]::WaitForPendingFinalizers()
  [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $dir 'Quit.json') -Encoding UTF8
 }
}
[ordered]@{Status='NATIVE_PHASES_MEASURED';Records=$records.Count;NoSolver=$true;WarmupsExcludedByRepeat0=$true}|ConvertTo-Json|Set-Content (Join-Path $out 'Complete.json') -Encoding UTF8
