"""ДЛЯ ТЕСТОВ: переносит только принятый IO-кандидат и воспроизводимую структуру сборки."""
from pathlib import Path
import json, hashlib, shutil
root=Path(__file__).resolve().parent
repo=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest().upper()
gate=json.loads((root/'Directed19_Attempt3/Complete.json').read_text(encoding='utf-8-sig'))
assert gate['Status']=='PASS_AFFECTED_SNAPSHOT_VIEWS_NO_YES'
manifest=json.loads((root/'BeforeManifest.json').read_text(encoding='utf-8-sig'))
for item in manifest['Files']:
    assert sha(repo/item['Path'])==item['SHA256'], f"Concurrent source modification: {item['Path']}"
backup=root/'BeforeIntegration20'
assert not backup.exists()
backup.mkdir()
changes=[]
for source in sorted((root/'Candidate').iterdir()):
    target=repo/'src/Excel'/source.name
    if target.exists(): shutil.copy2(target,backup/source.name)
    shutil.copy2(source,target)
    changes.append({'Path':str(target.relative_to(repo)).replace('\\','/'),'SHA256':sha(target)})
for source in (root/'CandidateTests').iterdir():
    target=repo/'tests'/source.name
    shutil.copy2(target,backup/source.name);shutil.copy2(source,target)
    changes.append({'Path':str(target.relative_to(repo)).replace('\\','/'),'SHA256':sha(target)})

builder=repo/'tools/build_workbook/Build-Workbook.ps1'
shutil.copy2(builder,backup/builder.name)
text=builder.read_text(encoding='utf-8-sig')
needle='. (Join-Path $PSScriptRoot "SectionIllustrations.ps1")'
assert text.count(needle)==1
text=text.replace(needle,needle+'\n. (Join-Path $PSScriptRoot "IndexedResultsTable.ps1")')
needle='    Add-WorkbookName $workbook "rngNDMElementGeometry" $results \'$BR$156\''
assert text.count(needle)==1
text=text.replace(needle,needle+'\n    Add-IndexedResultsTable $workbook $script:WorkbookLayout')
builder.write_text(text,encoding='utf-8-sig')

layoutPath=repo/'tools/build_workbook/WorkbookLayout.json'
shutil.copy2(layoutPath,backup/layoutPath.name)
layout=json.loads(layoutPath.read_text(encoding='utf-8-sig'))
assert not any(x['Name']=='rngNDMElementResultIndex' for x in layout['Names'])
layout['Names'].append({'Name':'rngNDMElementResultIndex','RefersTo':'=Results!$DL$156','Sheet':'Results','Address':'$DL$156','Rows':1,'Columns':1})
sheet=next(x for x in layout['Sheets'] if x['Name']=='Results')
sheet['Columns'].append({'First':116,'Last':129,'Width':14,'Hidden':False})
layout['Provenance']['IndexedResults']={'Format':'NDMResultIndex02','Anchor':'rngNDMElementResultIndex','Address':'Results!DL156','GapAfterAnnotations':2,'ExistingTableLocationsUnchanged':True}
layoutPath.write_text(json.dumps(layout,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

catalog=repo/'tools/build_workbook/SettingsCatalog.ps1'
shutil.copy2(catalog,backup/catalog.name)
text=catalog.read_text(encoding='utf-8-sig')
old='Кнопка «Обновить схему и результаты» при выбранном File загружает снимок с именем Results.SnapshotName и восстанавливает схему и подробные таблицы без нового расчёта.'
new='Кнопка «Обновить схему и результаты» при выбранном File читает общие данные и выбранное состояние из Results.SnapshotName, обновляет схему и справочные таблицы без нового расчёта.'
assert text.count(old)==1
text=text.replace(old,new)
old='В режиме Excel данные сочетаний и области трещин сохраняются в таблицах Results; кнопка «Обновить схему и результаты» обновляет только схему.'
new='В Excel подробная таблица Results остаётся читаемой. Справа от аннотаций находится rngNDMElementResultIndex: небольшой служебный каталог относительных строк. Схема читает только выбранные участки. Результаты элементов и индекс защищены от ручной сортировки, вставки и удаления; остальные области доступны. Для изменения результатов выполните расчёт заново. При чтении книги без индекса он строится один раз по ключевым столбцам; сохраните книгу. Кнопка «Обновить схему и результаты» обновляет только схему.'
assert text.count(old)==1
text=text.replace(old,new)
old='полные состояния и границы элементов остаются в файле, на листе — их шапки." -RowCount 3'
new='полные состояния и границы элементов остаются в файле, на листе — их шапки." -RowCount 6\n    $row = Add-GuideParagraph $Sheet $row "Новые файлы NDMSNP06 содержат каталог независимых блоков. Просмотр проверяет каталог и только прочитанные блоки; повреждение другого состояния обнаружится при его чтении, полном восстановлении либо VerifyFile. Форматы NDMSNP04/05 и расширение .ndms читаются без конвертации; для них требуется полное чтение. Файловая привязка и обновление времени не выполняют скрытый полный SHA-проход по NDMSNP06." -RowCount 3'
assert text.count(old)==1
text=text.replace(old,new)
catalog.write_text(text,encoding='utf-8-sig')

agents=repo/'AGENTS.md';shutil.copy2(agents,backup/agents.name)
text=agents.read_text(encoding='utf-8-sig')
assert 'и формат NDMSNP05' in text
text=text.replace('и формат NDMSNP05','и формат NDMSNP06 (чтение NDMSNP04/05 сохраняется)')
agents.write_text(text,encoding='utf-8')
(root/'Integration20.json').write_text(json.dumps({'Status':'SOURCE_AND_BUILDER_INTEGRATED_OUTPUT_PENDING','Changes':changes,'SolverGeometryMaterialsUnchanged':True,'BookNotPublished':True},ensure_ascii=False,indent=2),encoding='utf-8')
print('Integrated storage sources and builder; output publication remains gated')
