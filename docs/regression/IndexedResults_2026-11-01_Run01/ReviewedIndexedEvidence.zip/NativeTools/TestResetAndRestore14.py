"""ДЛЯ ТЕСТОВ: ограничивает кэши одним источником и сохраняет проверенный индекс полного restore."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'CIndexedSnapshotFile.cls').read_text(encoding='utf8')
a=t.index('Private Sub Class_Initialize()');b=t.index("' Записывает блоки подряд",a)
t=t[:a]+'''Private Sub Class_Initialize()
    ResetSource
End Sub

' Новый путь всегда получает пустые каталоги и счётчики; кэш другого файла не переиспользуется.
Private Sub ResetSource()
    If Not mFile Is Nothing Then mFile.CloseFile
    Set mFile = Nothing: Set mCodec = Nothing: Set mIndex = Nothing
    Set mTables = CreateObject("Scripting.Dictionary"): mTables.CompareMode = vbBinaryCompare
    Set mCache = CreateObject("Scripting.Dictionary"): mCache.CompareMode = vbBinaryCompare
    Set mEntries = New Collection: Set mStateEntries = New Collection
    mIdentityEntry = Empty: mHeaderEntry = Empty: mIdentities = Empty
    mLoadedStateBlocks = 0: mDirectoryHash = vbNullString: mRunID = 0#: mElapsed = 0#
End Sub

'''+t[b:]
t=t.replace('Public Sub WriteFile(ByVal path As String, ByVal snapshot As CCalculationSnapshot, ByVal codec As CCalculationSnapshotStore)\n    Set mCodec','Public Sub WriteFile(ByVal path As String, ByVal snapshot As CCalculationSnapshot, ByVal codec As CCalculationSnapshotStore)\n    ResetSource\n    Set mCodec')
t=t.replace('Public Function OpenRead(ByVal path As String, ByVal codec As CCalculationSnapshotStore) As Boolean\n    Set mCodec','Public Function OpenRead(ByVal path As String, ByVal codec As CCalculationSnapshotStore) As Boolean\n    ResetSource\n    Set mCodec')
t=t.replace('''    For Each key In mTables.Keys
        values = Table(CStr(key)): snapshot.AddTable CStr(key), values
    Next key''','''    Dim elements() As Variant
    For Each key In mTables.Keys
        If CStr(key) = "rngNDMElementResults" Then
            elements = SelectElementResults("", "", False)
            snapshot.AddPreparedElementResults elements, mIndex.TotalRows, mIndex
        Else
            values = Table(CStr(key)): snapshot.AddTable CStr(key), values
        End If
    Next key''')
(P/'CIndexedSnapshotFile.cls').write_text(t,encoding='utf8')
t=(P/'CResultReadSource.cls').read_text(encoding='utf8')
t=t.replace('Public Sub UsePrepared(ByVal snapshot As CCalculationSnapshot)\n    snapshot.Validate','Public Sub UsePrepared(ByVal snapshot As CCalculationSnapshot)\n    mCommonValidated = False: Set mValidatedBoundaries = Nothing\n    snapshot.Validate')
t=t.replace('Public Sub OpenWorkbook(ByVal workbook As Object, ByVal store As CCalculationSnapshotStore)\n    Dim path','Public Sub OpenWorkbook(ByVal workbook As Object, ByVal store As CCalculationSnapshotStore)\n    Set mPrepared = Nothing: Set mIndexed = Nothing: Set mValidatedBoundaries = Nothing: mCommonValidated = False\n    Dim path')
(P/'CResultReadSource.cls').write_text(t,encoding='utf8')
t=(P/'modCalculationSnapshot.bas').read_text(encoding='utf8')
lines=[]
for line in t.splitlines():
 if line.startswith('Private mReadSourceResolved ') or line.strip().startswith('mReadSourceResolved ='):continue
 line=line.replace(': mReadSourceResolved = False','')
 lines.append(line)
(P/'modCalculationSnapshot.bas').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('Prepared source-scoped caches and full restore with verified persisted index')
