"""ДЛЯ ТЕСТОВ: общий индекс умеет однократно восстановиться по четырём ключевым колонкам."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'CResultBlockIndex.cls').read_text(encoding='utf8')
a=t.index('    first = 2',t.index('Public Sub Build('));b=t.index("' Устанавливает шапку",a)
loop=t[a:b]
pre=t[t.index('Public Sub Build('):a]
pre=pre.replace('    Initialize header, runID\n','    BuildCore values, header, runID, runIDsValidated\nEnd Sub\n\n')
core='''
' Однократно индексирует прежнюю таблицу только по RunID/LC/Profile/State, без всех девяти колонок.
Public Sub BuildKeyColumns(ByRef keys As Variant, ByRef header As Variant, ByVal runID As Double)
    If UBound(keys, 2) <> 4 Then Err.Raise 5, , "Для перестроения индекса нужны четыре ключевые колонки."
    BuildCore keys, header, runID, False
End Sub

' Общие правила группировки одинаковы для массива расчёта и однократного чтения ключей Excel.
Private Sub BuildCore(ByRef values As Variant, ByRef header As Variant, ByVal runID As Double, ByVal runIDsValidated As Boolean)
    Dim row As Long, first As Long, previousCase As String, previousProfile As String, previousState As String
    Dim currentCase As String, currentProfile As String, currentState As String
    Initialize header, runID
'''+loop
start=t.index('Public Sub Build(')
t=t[:start]+pre+core+t[b:]
t=t.replace('For column = 1 To 9: sample(1, column) = values(first, column): Next column','For column = 1 To UBound(values, 2): sample(1, column) = values(first, column): Next column')
t+='''
' Дополняет индекс ключей только первой полной строкой каждого участка, до его публикации.
Public Sub SetRepresentative(ByVal block As Long, ByRef sample As Variant)
    Dim record As Variant: record = mBlocks.Item(block)
    Dim expected As Variant, column As Long: expected = record(2)
    If UBound(sample, 1) <> 1 Or UBound(sample, 2) <> 9 Then Err.Raise 5, , "Неверная представительская строка индекса."
    For column = 1 To 4
        If StrComp(CStr(sample(1, column)), CStr(expected(1, column)), vbBinaryCompare) <> 0 Then Err.Raise 5, , "Таблица изменилась во время построения индекса."
    Next column
    mBlocks.Remove block
    If block > mBlocks.Count Then
        mBlocks.Add Array(record(0), record(1), sample)
    Else
        mBlocks.Add Array(record(0), record(1), sample), , block
    End If
End Sub
'''
(P/'CResultBlockIndex.cls').write_text(t,encoding='utf8')
print('Prepared one-time key-column bootstrap')
