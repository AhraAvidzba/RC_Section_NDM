"""ДЛЯ ТЕСТОВ: актуализирует только ожидания версии контейнера, сохраняя численные проверки."""
from pathlib import Path
import json
root = Path(__file__).resolve().parent
repo = Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
source = (repo/'tests/modTestCalculationSnapshot.bas').read_text(encoding='utf-8-sig')
changes = {
    '"preview.file.version05", file.ReadASCII(8) = "NDMSNP05" And file.ReadLong() = 5': '"preview.file.version06", file.ReadASCII(8) = "NDMSNP06" And file.ReadLong() = 6',
    '"preview.adaptive.requires05", file.ReadASCII(8) = "NDMSNP05" And file.ReadLong() = 5': '"preview.adaptive.indexed06", file.ReadASCII(8) = "NDMSNP06" And file.ReadLong() = 6',
    '    store.SaveFile ThisWorkbook, legacy\n': '    TestSnapshotWriteLegacy savedPath, legacy, 4\n',
    '"boundary.file.new05Header", signature = "NDMSNP05" And version = 5': '"boundary.file.new06Header", signature = "NDMSNP06" And version = 6',
    '"boundary.file.new05Footer", file.ReadASCII(8) = signature': '"boundary.file.new06Footer", file.ReadASCII(8) = "NDMIDX06"',
    '"boundary.file.elapsed05"': '"boundary.file.elapsed06"',
}
for old,new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old,new)
old = '    store.SaveFile ThisWorkbook, sample\n    file.OpenRead savedPath'
new = '''    ' Проверка чтения v5 не зависит от текущего writer-а v6.
    TestSnapshotWriteLegacy savedPath, sample, 5
    Set loaded = store.LoadFile(ThisWorkbook)
    TestSnapshotEqual "boundary.file.legacy05Read", sample, loaded
    store.SaveFile ThisWorkbook, sample
    file.OpenRead savedPath'''
assert source.count(old) == 1
source=source.replace(old,new)
start = source.index('Private Sub TestSnapshotElementIndex()')
end = source.index('End Sub', start) + len('End Sub')
source = source[:start] + '''Private Sub TestSnapshotElementIndex()
    Dim snapshot As New CCalculationSnapshot: snapshot.RunID = 1#
    Dim data(1 To 7, 1 To 9) As Variant, row As Long, column As Long, names As Variant
    ' Fixture использует девять рабочих колонок; перестановка значений между колонками не является результатом НДС.
    names = Array("RunID", "LoadCase", "ProfileId", "StateType", "ElementID", "MaterialType", "Strain", "Stress", "PhysicalState")
    For column = 1 To 9: data(1, column) = names(column - 1): Next column
    For row = 2 To 7
        data(row, 1) = 1#: data(row, 5) = "Element" & CStr(row): data(row, 3) = "ULS"
        data(row, 2) = IIf(row = 4 Or row = 7, "B", "A")
        data(row, 4) = IIf(row = 3 Or row = 7, "CrackedState", "StrengthState")
    Next row
    snapshot.AddTable "rngNDMElementResults", data
    Dim actual As Variant: actual = snapshot.SelectElementResults("a", "strengthstate", False)
    TestSnapshotCheck "index.nonAdjacentOrder", UBound(actual, 1) = 4 And actual(2, 5) = "Element2" And actual(3, 5) = "Element5" And actual(4, 5) = "Element6"
    actual = snapshot.SelectElementResults("", "", True)
    TestSnapshotCheck "index.firstRows", UBound(actual, 1) = 5 And actual(2, 5) = "Element2" And actual(3, 5) = "Element3" And actual(4, 5) = "Element4" And actual(5, 5) = "Element7"
    actual = snapshot.SelectElementResults("missing", "", False)
    TestSnapshotCheck "index.missingHeaderOnly", UBound(actual, 1) = 1
    actual = snapshot.SelectElementResults("", "", False)
    TestSnapshotCheck "index.fullExact", TestSnapshotSameMatrix(data, actual)
End Sub''' + source[end:]
source += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создаёт частный совместимый v4/v5 fixture; рабочая запись всегда использует v6.
' Контейнер и SHA соответствуют формату, матрицы используют сохранённый колонковый кодек.
Private Sub TestSnapshotWriteLegacy(ByVal path As String, ByVal snapshot As CCalculationSnapshot, ByVal version As Long)
    If version <> 4 And version <> 5 Then Err.Raise 5, , "Test legacy version"
    Dim file As New CBinarySnapshotFile, codec As New CCalculationSnapshotStore
    Dim key As Variant, count As Long, values As Variant, signature As String
    For Each key In snapshot.Keys(): count = count + 1: Next key
    signature = "NDMSNP0" & CStr(version)
    file.OpenWrite path
    file.WriteASCII signature: file.WriteLong version
    file.WriteDouble snapshot.RunID: file.WriteDouble snapshot.ElapsedSeconds: file.WriteLong count
    For Each key In snapshot.Keys()
        file.WriteSizedUTF16 CStr(key): values = snapshot.Table(CStr(key))
        codec.WriteIndexedValues file, values
    Next key
    file.CloseFile
    Dim digest As New CFileChecksum, hash As String: hash = digest.FileSHA256(path)
    file.OpenUpdate path: file.Position = file.Size
    file.WriteASCII hash: file.WriteASCII signature: file.CloseFile
End Sub
'''
(root/'CandidateTests').mkdir(exist_ok=True)
(root/'CandidateTests/modTestCalculationSnapshot.bas').write_text(source,encoding='utf-8-sig')
(root/'Directed19TestChanges.json').write_text(json.dumps({'VersionExpectations':changes,'LegacyFixtures':'Explicit test-only v4/v5 writer; numerical expectations unchanged'},ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared directed snapshot tests; numeric expectations unchanged')
