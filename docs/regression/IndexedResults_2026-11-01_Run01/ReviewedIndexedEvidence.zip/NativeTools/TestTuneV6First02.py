"""ДЛЯ ТЕСТОВ: убирает выявленные повторные проходы из изолированного writer v6."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'CIndexedSnapshotFile.cls').read_text(encoding='utf8')
a=t.index('Friend Sub WriteElements(');b=t.index("' Сериализует только небольшой каталог",a)
t=t[:a]+'''Friend Sub WriteElements(ByRef values As Variant, ByVal index As CResultBlockIndex)
    Dim header As Variant: header = index.Header: WriteTable "rngNDMElementResults", "ElementHeader", header
    Dim dictionary As Object: Set dictionary = CreateObject("Scripting.Dictionary"): dictionary.CompareMode = vbBinaryCompare
    Dim pairs As New Collection, baseCount As Long, row As Long, id As String, material As String, identity As String
    If index.Count > 0 Then baseCount = index.RowCount(1)
    For row = 2 To baseCount + 1
        If VarType(values(row, 5)) <> vbString Or VarType(values(row, 6)) <> vbString Then Err.Raise 5, , "ElementID и MaterialType должны быть строками."
        id = CStr(values(row, 5)): material = CStr(values(row, 6)): identity = CStr(Len(id)) & ":" & id & material
        pairs.Add Array(id, material)
        If Not dictionary.Exists(identity) Then dictionary.Add identity, pairs.Count + 1
    Next row
    Dim block As Long, first As Long, last As Long, column As Long, offset As Long, sample As Variant, localCodes() As Long, digest As String, same As Boolean, relative As Long
    For block = 1 To index.Count
        first = index.FirstRow(block): last = first + index.RowCount(block) - 1: sample = index.Representative(block)
        offset = mFile.Position: mFile.BeginWriteDigest: mFile.WriteLong index.RowCount(block)
        For column = 1 To 4: mCodec.WriteIndexedScalar mFile, sample(1, column): Next column
        same = (index.RowCount(block) = baseCount)
        If same Then
            For row = first To last
                relative = row - first + 2
                If VarType(values(row, 5)) <> vbString Or VarType(values(row, 6)) <> vbString Then same = False: Exit For
                If StrComp(values(row, 5), values(relative, 5), vbBinaryCompare) <> 0 Or StrComp(values(row, 6), values(relative, 6), vbBinaryCompare) <> 0 Then same = False: Exit For
            Next row
        End If
        If same Then
            mFile.WriteByte 0 ' Общая последовательность ID/Material хранится один раз; значения каждой строки проверены.
        Else
            mFile.WriteByte 1: ReDim localCodes(1 To index.RowCount(block))
            For row = first To last
                If VarType(values(row, 5)) <> vbString Or VarType(values(row, 6)) <> vbString Then Err.Raise 5, , "ElementID и MaterialType должны быть строками."
                id = CStr(values(row, 5)): material = CStr(values(row, 6)): identity = CStr(Len(id)) & ":" & id & material
                If Not dictionary.Exists(identity) Then pairs.Add Array(id, material): dictionary.Add identity, pairs.Count + 1
                localCodes(row - first + 1) = CLng(dictionary.Item(identity))
            Next row
            mFile.WriteLongs localCodes
        End If
        WriteNumericColumn values, first, last, 7
        WriteNumericColumn values, first, last, 8
        mCodec.WriteIndexedValues mFile, values, first, last, 9, 9
        digest = mFile.EndWriteDigest
        mEntries.Add Array("rngNDMElementResults", "State", offset, mFile.Position - offset, digest, index.RowCount(block), 9, first, sample)
    Next block
    Dim identityValues() As Variant, pair As Variant, sharedValues As Variant
    ReDim identityValues(1 To pairs.Count + 1, 1 To 2): identityValues(1, 1) = "ElementID": identityValues(1, 2) = "MaterialType"
    For row = 1 To pairs.Count
        pair = pairs.Item(row): identityValues(row + 1, 1) = pair(0): identityValues(row + 1, 2) = pair(1)
    Next row
    sharedValues = identityValues: WriteTable "#ElementIdentities", "ElementIDs", sharedValues
End Sub

' Числовая колонка Double пишется плотным массивом; редкие смешанные типы используют общий кодек.
Private Sub WriteNumericColumn(ByRef values As Variant, ByVal first As Long, ByVal last As Long, ByVal column As Long)
    Dim numbers() As Double, row As Long: ReDim numbers(1 To last - first + 1)
    For row = first To last
        If VarType(values(row, column)) <> vbDouble Then
            mFile.WriteByte 1: mCodec.WriteIndexedValues mFile, values, first, last, column, column
            Exit Sub
        End If
        numbers(row - first + 1) = values(row, column)
    Next row
    mFile.WriteByte 0: mFile.WriteDoubles numbers
End Sub

'''+t[b:]
t=t.replace('Dim keys(1 To 4) As Variant, column As Long, codes() As Long, data As Variant, sample As Variant, digest As String','Dim keys(1 To 4) As Variant, column As Long, codes() As Long, data As Variant, strain As Variant, stress As Variant, sample As Variant, digest As String, idMode As Byte')
t=t.replace('    codes = mFile.ReadLongs(rows): data = mCodec.ReadIndexedValues(mFile, rows, 3): digest = mFile.EndReadDigest','''    idMode = mFile.ReadByte
    If idMode = 1 Then
        codes = mFile.ReadLongs(rows)
    ElseIf idMode = 0 Then
        If rows + 1 > UBound(mIdentities, 1) Then Err.Raise 5, , "Общая последовательность ID слишком короткая."
        ReDim codes(1 To rows)
        Dim element As Long: For element = 1 To rows: codes(element) = element + 1: Next element
    Else
        Err.Raise 5, , "Неизвестный способ адресации ID."
    End If
    strain = ReadNumericColumn(rows): stress = ReadNumericColumn(rows)
    data = mCodec.ReadIndexedValues(mFile, rows, 1): digest = mFile.EndReadDigest''')
t=t.replace('        For column = 7 To 9: values(row, column) = data(row, column - 6): Next column','        values(row, 7) = strain(row, 1): values(row, 8) = stress(row, 1): values(row, 9) = data(row, 1)')
t+='''
' Восстанавливает плотный Double без округления; общий кодек сохраняет смешанные значения.
Private Function ReadNumericColumn(ByVal rows As Long) As Variant
    Dim mode As Byte: mode = mFile.ReadByte
    If mode = 1 Then ReadNumericColumn = mCodec.ReadIndexedValues(mFile, rows, 1): Exit Function
    If mode <> 0 Then Err.Raise 5, , "Неизвестный способ хранения числовой колонки."
    Dim numbers() As Double, values() As Variant, row As Long
    numbers = mFile.ReadDoubles(rows): ReDim values(1 To rows, 1 To 1)
    For row = 1 To rows: values(row, 1) = numbers(row): Next row
    ReadNumericColumn = values
End Function
'''
(P/'CIndexedSnapshotFile.cls').write_text(t,encoding='utf8')
t=(P/'CResultBlockIndex.cls').read_text(encoding='utf8')
t=t.replace('Public Sub Build(ByRef values As Variant, ByVal runID As Double)','Public Sub Build(ByRef values As Variant, ByVal runID As Double, Optional ByVal runIDsValidated As Boolean = False)')
t=t.replace('''        If Not IsNumeric(values(row, 1)) And VarType(values(row, 1)) <> vbDate Then Err.Raise 5, , "В результатах элементов отсутствует RunID."
        If CDbl(values(row, 1)) <> runID Then Err.Raise 5, , "Результаты элементов относятся к другому расчёту."''','''        If Not runIDsValidated Then
            If Not IsNumeric(values(row, 1)) And VarType(values(row, 1)) <> vbDate Then Err.Raise 5, , "В результатах элементов отсутствует RunID."
            If CDbl(values(row, 1)) <> runID Then Err.Raise 5, , "Результаты элементов относятся к другому расчёту."
        End If''')
(P/'CResultBlockIndex.cls').write_text(t,encoding='utf8')
t=(P/'CCalculationSnapshot.cls').read_text(encoding='utf8').replace('mElementIndex.Build mElements, mRunID','mElementIndex.Build mElements, mRunID, mValidated')
(P/'CCalculationSnapshot.cls').write_text(t,encoding='utf8')
print('Prepared isolated write optimizations; fresh v6 prototype files required')
