"""ДЛЯ ТЕСТОВ: расширяет кодек в изолированной копии для последовательных участков."""
from pathlib import Path
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
P=Path(__file__).parent/'Candidate'
t=(R/'src/Excel/CCalculationSnapshotStore.cls').read_text(encoding='utf-8-sig')
start=t.index('Private Sub WriteMatrix(');end=t.index("' Проверяет повторение точного списка ElementID",start)
original=t[start:end]
adapt=original.replace('Private Sub WriteMatrix(', 'Friend Sub WriteIndexedValues(')
adapt=adapt.replace('Optional ByVal elementCount As Long = 0)', 'Optional ByVal first As Long = 1, Optional ByVal last As Long = 0, Optional ByVal firstColumn As Long = 1, Optional ByVal lastColumn As Long = 0)')
adapt=adapt.replace('    rows = UBound(values, 1): columns = UBound(values, 2)', '''    If last = 0 Then last = UBound(values, 1)
    If lastColumn = 0 Then lastColumn = UBound(values, 2)
    If first < 1 Or first > last Or last > UBound(values, 1) Or firstColumn < 1 Or firstColumn > lastColumn Or lastColumn > UBound(values, 2) Then Err.Raise 5, , "Неверные границы записываемого участка."
    rows = last - first + 1: columns = lastColumn - firstColumn + 1''')
adapt=adapt.replace('For j = 1 To columns','For j = firstColumn To lastColumn')
adapt=adapt.replace('values(i, j)','values(i + first - 1, j)')
adapt=adapt.replace('WriteRepeatedColumn(file, values, j, rows)','WriteIndexedRepeatedColumn(file, values, j, rows, first)')
a=adapt.index('        If elementCount > 0 And j = 5 Then');b=adapt.index('        ReDim flags',a)
adapt=adapt[:a]+adapt[b:]
start=t.index('Private Function WriteRepeatedColumn(');end=t.index("' Восстанавливает значения без десятичных",start)
repeated=t[start:end].replace('Private Function WriteRepeatedColumn(', 'Private Function WriteIndexedRepeatedColumn(')
repeated=repeated.replace('ByVal rows As Long) As Boolean','ByVal rows As Long, ByVal first As Long) As Boolean').replace('WriteRepeatedColumn = True','WriteIndexedRepeatedColumn = True').replace('values(row, column)','values(row + first - 1, column)')
t+='''
' Пишет только переданный непрерывный участок исходного массива, не копируя всю таблицу.
' Штатный колоночный кодек и повторяющиеся серии сохранены; индексы колонок не зависят от Excel.
'''+adapt+"\n' Сжимает серии одного участка с точным сравнением Double и Unicode.\n"+repeated
# Читатель принимает ожидаемые размеры из проверенного каталога до ReDim.
t=t.replace('Private Function ReadMatrix(ByVal file As CBinarySnapshotFile) As Variant','Friend Function ReadIndexedValues(ByVal file As CBinarySnapshotFile, Optional ByVal expectedRows As Long = 0, Optional ByVal expectedColumns As Long = 0) As Variant')
t=t.replace('    Dim values() As Variant, flags() As Byte, numbers() As Double, codes() As Long, strings() As String\n    ReDim values', '''    If expectedRows > 0 Then If rows <> expectedRows Then Err.Raise 5, , "Число строк блока не совпадает с каталогом."
    If expectedColumns > 0 Then If columns <> expectedColumns Then Err.Raise 5, , "Число колонок блока не совпадает с каталогом."
    Dim values() As Variant, flags() As Byte, numbers() As Double, codes() As Long, strings() As String
    ReDim values''')
t=t.replace('    ReadMatrix = values','    ReadIndexedValues = values')
t=t.replace('ReadMatrix(file)','ReadIndexedValues(file)')
t+='''
' Скалярный кодек общий для плотных таблиц и четырёх ключей независимого блока.
Friend Sub WriteIndexedScalar(ByVal file As CBinarySnapshotFile, ByRef value As Variant)
    WriteScalar file, value
End Sub

' Восстанавливает тип скалярного ключа без преобразования строки в число.
Friend Function ReadIndexedScalar(ByVal file As CBinarySnapshotFile) As Variant
    ReadIndexedScalar = ReadScalar(file)
End Function
'''
(P/'CCalculationSnapshotStore.cls').write_text(t,encoding='utf8')
print('Prepared isolated row-range codec; production unchanged')
