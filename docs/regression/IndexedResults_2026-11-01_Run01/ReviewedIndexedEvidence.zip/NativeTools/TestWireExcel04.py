"""ДЛЯ ТЕСТОВ: связывает пакетную запись и адресное чтение Excel в isolated candidate."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'modIndexedExcelResults.bas').read_text(encoding='utf8')
t=t.replace('''    On Error Resume Next
    Set ExistingIndexAnchor = workbook.Names.Item(INDEX_NAME).RefersToRange
    On Error GoTo 0''','''    Dim owner As Object
    On Error Resume Next
    Set owner = workbook.Names.Item(INDEX_NAME)
    On Error GoTo 0
    If Not owner Is Nothing Then Set ExistingIndexAnchor = owner.RefersToRange''')
t=t.replace('''    PrepareIndexedResultsWrite workbook
    If Len(CStr(anchor.Value2))''','''    PrepareIndexedResultsWrite workbook
    If Len(CStr(anchor.Value2))''')
t=t.replace('    anchor.Offset(1, 0).Value2 = "Invalid"\nEnd Sub','    anchor.Value2 = "IndexKind": anchor.Offset(1, 0).Value2 = "Invalid"\nEnd Sub')
t=t.replace('''    If anchor Is Nothing Then Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, rows): Exit Function''','''    If anchor Is Nothing Then
        If OwnProtection(workbook) And rows > 1 Then Err.Raise 5, , "Опубликованный индекс удалён. Очистите Results и выполните расчёт заново."
        Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, rows): Exit Function
    End If''')
t=t.replace('''    If indexRows < 2 Then Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, rows): Exit Function''','''    If indexRows < 2 Then
        If OwnProtection(workbook) Then Err.Raise 5, , "Запись опубликованного индекса повреждена. Выполните расчёт заново."
        Set ReadElementResultIndex = BootstrapElementResultIndex(workbook, elements, rows): Exit Function
    End If''')
# Расширение существующей таблицы не может уничтожить соседние данные ниже неё.
t=t.replace('''        If Len(CStr(anchor.Value2)) > 0 And CStr(anchor.Value2) <> "IndexKind" Then Err.Raise 5, , "В " & INDEX_NAME & " находятся посторонние данные."
    End If''','''        If Len(CStr(anchor.Value2)) > 0 And CStr(anchor.Value2) <> "IndexKind" Then Err.Raise 5, , "В " & INDEX_NAME & " находятся посторонние данные."
        Dim oldRows As Long: oldRows = AnchoredRowCount(anchor)
        If oldRows < 1 Then oldRows = 1
        If rows > oldRows Then
            If workbook.Application.WorksheetFunction.CountA(anchor.Offset(oldRows, 0).Resize(rows - oldRows, INDEX_COLUMNS)) <> 0 Then Err.Raise 5, , "Под индексом находятся посторонние данные; расширение запрещено."
        End If
    End If''')
(P/'modIndexedExcelResults.bas').write_text(t,encoding='utf8')
t=(P/'modSectionSnapshot.bas').read_text(encoding='utf8')
a=t.index('    Dim data As Variant: data = ReadAnchoredResultTable(workbook, "rngNDMElementResults")',t.index('Public Function ReadElementResultTable('));b=t.index('End Function',a)
t=t[:a]+'''    ReadElementResultTable = ReadIndexedExcelElementResults(workbook, combinationID, stateType, indexOnly)
'''+t[b:]
(P/'modSectionSnapshot.bas').write_text(t,encoding='utf8')
t=(P/'CNDMResultsWriter.cls').read_text(encoding='utf8')
t=t.replace('''    snapshot.Validate
    RestoreBaseTables workbook, snapshot, fullFormatting, includeElements''','''    snapshot.Validate
    Dim indexData As Variant, indexAnchor As Object
    If includeElements Then
        indexData = ElementResultIndexMatrix(snapshot.ElementIndex)
        Set indexAnchor = EnsureElementResultIndexAnchor(workbook, UBound(indexData, 1))
    End If
    InvalidateElementResultIndex workbook
    PrepareIndexedResultsWrite workbook
    RestoreBaseTables workbook, snapshot, fullFormatting, includeElements
    If includeElements Then PublishElementResultIndex workbook, indexData, Me''')
t=t.replace('''    source.ValidateForDisplay
    RestoreBaseTables workbook, source, fullFormatting, False''','''    source.ValidateForDisplay
    InvalidateElementResultIndex workbook
    PrepareIndexedResultsWrite workbook
    RestoreBaseTables workbook, source, fullFormatting, False''')
(P/'CNDMResultsWriter.cls').write_text(t,encoding='utf8')
t=(P/'modCalculationSnapshot.bas').read_text(encoding='utf8')
t=t.replace('''Public Sub ClearPublishedCalculationSnapshot(ByVal workbook As Object)
    Dim store''','''Public Sub ClearPublishedCalculationSnapshot(ByVal workbook As Object)
    InvalidateElementResultIndex workbook
    PrepareIndexedResultsWrite workbook
    Dim store''')
(P/'modCalculationSnapshot.bas').write_text(t,encoding='utf8')
print('Prepared isolated Excel integration; native validation still required')
