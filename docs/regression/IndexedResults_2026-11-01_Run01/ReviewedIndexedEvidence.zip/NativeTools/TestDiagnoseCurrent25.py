"""ДЛЯ ТЕСТОВ: выводит точную причину отличий источников и структуры, не меняя книгу."""
from pathlib import Path
import sys,importlib,json,difflib
root=Path(__file__).resolve().parent;repo=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
sys.path.insert(0,str(repo/'tools/build_workbook'))
check=importlib.import_module('Verify-CalculationSnapshotRelease');reader=importlib.import_module('Verify-SectionRecipeGuide')
native=check.exported_components(root/'Current22_Attempt2/VBA_All_Code.txt')
before=check.exported_components(root/'AllCodeBefore.txt')
for name in ('CSectionGeometryQuery','modTestAudit02Api','modTestCalculationSnapshot','modTestElementGeometry'):
 path=next(p for folder in ('src','tests') for p in (repo/folder).rglob(name+'.*') if p.suffix in ('.bas','.cls'))
 a=check.normalized_vba(check.source_body(path));b=check.normalized_vba(native[name][1])
 print(name,'OriginalSameAsAfter',check.normalized_vba(before.get(name,(0,''))[1])==b)
 for line in list(difflib.unified_diff(a,b,n=1))[:18]: print(line[:400])
old=reader.read(root/'Current22_Attempt2/Before.xlsm');new=reader.read(root/'Current22_Attempt2/RC_Section_NDM.xlsm')
print('addedNames', {n:new['names'][n] for n in new['names'].keys()-old['names'].keys()})
print('index',new['names'].get('rngNDMElementResultIndex'))
print('indexCell',new['sheets']['Results']['cells'].get('DL156'))
for sheet in ('Config','Сечения'):
 a=old['sheets'][sheet]['document'].find(reader.S+'mergeCells');b=new['sheets'][sheet]['document'].find(reader.S+'mergeCells')
 print(sheet,'merges equal as sets',sorted(x.get('ref') for x in a)==sorted(x.get('ref') for x in b))
