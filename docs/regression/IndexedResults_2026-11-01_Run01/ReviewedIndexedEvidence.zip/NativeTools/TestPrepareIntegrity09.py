"""ДЛЯ ТЕСТОВ: полная потоковая проверка и атомарный перенос при Save As."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'CIndexedSnapshotFile.cls').read_text(encoding='utf8')
needle='        nextOffset = offset + length\n    Next row'
assert t.count(needle)==1
t=t.replace(needle,'        mEntries.Add entry\n'+needle)
t+='''
' Проверяет SHA256 всех блоков по каталогу без восстановления больших матриц.
' Полный LoadAll дополнительно проверяет семантический контракт восстановленных таблиц.
Public Sub VerifyAllBlocks()
    Dim entry As Variant, bytes As Variant, take As Long, digest As String
    For Each entry In mEntries
        mFile.BeginReadDigest CLng(entry(2)), CLng(entry(3))
        Do While mFile.RemainingBytes > 0
            take = mFile.RemainingBytes: If take > 65536 Then take = 65536
            bytes = mFile.ReadBytes(take)
        Loop
        digest = mFile.EndReadDigest
        If digest <> CStr(entry(4)) Then Err.Raise 5, , "Контрольная сумма блока не совпадает: " & CStr(entry(0))
    Next entry
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает адреса первого и последнего состояния для контролируемого повреждения частной копии.
Friend Function TestStateBlockLocation(ByVal block As Long) As String
    If block = 0 Then block = mStateEntries.Count
    Dim entry As Variant, sample As Variant: entry = mStateEntries.Item(block): sample = entry(8)
    TestStateBlockLocation = CStr(entry(2)) & "|" & CStr(entry(3)) & "|" & CStr(sample(1, 2)) & "|" & CStr(sample(1, 4))
End Function
'''
(P/'CIndexedSnapshotFile.cls').write_text(t,encoding='utf8')
t=(P/'CCalculationSnapshotStore.cls').read_text(encoding='utf8')
a=t.index('Public Sub EnsureBesideWorkbook(');b=t.index("' Обновляет только фиксированное поле времени",a)
t=t[:a]+'''Public Sub EnsureBesideWorkbook(ByVal workbook As Object, Optional ByVal previousFolder As String = "")
    If Not HasFileReference(workbook) Then Exit Sub
    If StorageMode(workbook) <> "File" Then Exit Sub
    Dim fileSystem As Object: Set fileSystem = CreateObject("Scripting.FileSystemObject")
    Dim name As String: name = LinkText(workbook, "File")
    If name <> fileSystem.GetFileName(name) Then Err.Raise 5, , "В привязке снимка требуется имя без пути."
    If StrComp(fileSystem.GetBaseName(SnapshotPath(workbook)), fileSystem.GetBaseName(name), vbTextCompare) <> 0 Then Exit Sub
    Dim target As String: target = CStr(workbook.Path) & Application.PathSeparator & name
    Dim source As String: source = LinkText(workbook, "Folder") & Application.PathSeparator & name
    If fileSystem.FileExists(target) Then
        If FileIdentity(target) <> LinkText(workbook, "Hash") Then Err.Raise 5, , "Рядом с книгой находится другой одноимённый снимок: " & target
        Exit Sub ' Обычное сохранение книги проверяет каталог v6; подробные блоки остаются адресными.
    End If
    If Len(previousFolder) > 0 Then
        Dim previous As String: previous = previousFolder & Application.PathSeparator & name
        If fileSystem.FileExists(previous) Then
            If FileIdentity(previous) = LinkText(workbook, "Hash") Then source = previous
        End If
    End If
    If FileIdentity(source) <> LinkText(workbook, "Hash") Then Err.Raise 5, , "Исходный снимок изменился: " & source
    Dim temporary As String: temporary = target & ".part"
    Dim ownsTemporary As Boolean
    On Error GoTo Failed
    If FileExists(temporary) Then Err.Raise 5, , "Временный файл переноса занят: " & temporary
    ownsTemporary = True: fileSystem.CopyFile source, temporary, False
    If FileIdentity(temporary) <> LinkText(workbook, "Hash") Then Err.Raise 5, , "Копия не соответствует привязанному снимку."
    VerifyPath temporary ' Проверка всех блоков выполняется только при фактическом переносе, до публикации копии.
    If MoveFileExW(StrPtr(temporary), StrPtr(target), 8) = 0 Then Err.Raise 5, , "Не удалось опубликовать снимок рядом с новой книгой. Код Windows: " & CStr(Err.LastDllError)
    Exit Sub
Failed:
    Dim number As Long, reason As String: number = Err.Number: reason = Err.Description
    On Error Resume Next
    If ownsTemporary Then If FileExists(temporary) Then DeleteFile temporary
    On Error GoTo 0
    Err.Raise number, "CCalculationSnapshotStore.EnsureBesideWorkbook", reason
End Sub

' Явно проверяет все блоки текущего выбранного файла, не выдавая локальную проверку за полную.
Public Sub VerifyFile(ByVal workbook As Object)
    VerifyPath SelectedReadPath(workbook)
End Sub

' Для v6 проверяет весь поток по блоковым SHA; v4/v5 сохраняют полный совместимый reader.
Private Sub VerifyPath(ByVal path As String)
    Dim indexed As New CIndexedSnapshotFile
    If indexed.OpenRead(path, Me) Then
        indexed.VerifyAllBlocks
    Else
        Dim snapshot As CCalculationSnapshot: Set snapshot = ReadBinary(path): snapshot.Validate
    End If
End Sub

'''+t[b:]
(P/'CCalculationSnapshotStore.cls').write_text(t,encoding='utf8')
print('Prepared explicit full-block verification and atomic Save As copy')
