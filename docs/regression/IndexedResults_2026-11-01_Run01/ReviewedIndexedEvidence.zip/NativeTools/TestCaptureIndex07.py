"""ДЛЯ ТЕСТОВ: собирает индекс одновременно с формированием готовых массивов writer-а."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'CResultBlockIndex.cls').read_text(encoding='utf8')
t+='''
' Принимает фактически созданный участок writer-а; обход всех результатов ради границ не нужен.
Friend Sub AppendPreparedBlock(ByRef values() As Variant, ByVal first As Long, ByVal rows As Long)
    If rows < 1 Then Exit Sub
    Dim sample(1 To 1, 1 To 9) As Variant, column As Long
    For column = 1 To 9: sample(1, column) = values(first, column): Next column
    Append first, rows, sample
End Sub
'''
(P/'CResultBlockIndex.cls').write_text(t,encoding='utf8')
t=(P/'CCalculationSnapshot.cls').read_text(encoding='utf8')
t=t.replace('Friend Sub AddPreparedElementResults(ByRef values() As Variant, ByVal usedRows As Long)','Friend Sub AddPreparedElementResults(ByRef values() As Variant, ByVal usedRows As Long, Optional ByVal preparedIndex As CResultBlockIndex = Nothing)')
needle='    Set mElementIndex = Nothing: mValidated = False: Set mValidatedBoundaries = Nothing\nEnd Sub'
assert t.count(needle)==1
t=t.replace(needle,'''    Set mElementIndex = preparedIndex
    If Not mElementIndex Is Nothing Then
        If mElementIndex.TotalRows <> usedRows Or mElementIndex.RunID <> mRunID Then Err.Raise 5, , "Готовый индекс не соответствует массиву результатов."
    End If
    mValidated = False: Set mValidatedBoundaries = Nothing
End Sub''')
(P/'CCalculationSnapshot.cls').write_text(t,encoding='utf8')
t=(P/'CNDMResultsWriter.cls').read_text(encoding='utf8')
t=t.replace('Private mCapturedSnapshot As CCalculationSnapshot','Private mPendingElementIndex As CResultBlockIndex\nPrivate mCapturedSnapshot As CCalculationSnapshot',1)
needle='''    PutElementResultHeaders data, units

    Dim rowIndex As Long'''
assert t.count(needle)==1
t=t.replace(needle,'''    PutElementResultHeaders data, units
    Dim blockIndex As New CResultBlockIndex, indexHeader(1 To 1, 1 To 9) As Variant, indexColumn As Long, firstStateRow As Long
    For indexColumn = 1 To 9: indexHeader(1, indexColumn) = data(1, indexColumn): Next indexColumn
    blockIndex.Initialize indexHeader, CDbl(runID)

    Dim rowIndex As Long''')
t=t.replace('''            PutCombinationElementResults data, rowIndex, section, batch, preparedCombinations(preparedIndex), _
                preparedStates(preparedIndex), runID, units''','''            firstStateRow = rowIndex
            PutCombinationElementResults data, rowIndex, section, batch, preparedCombinations(preparedIndex), _
                preparedStates(preparedIndex), runID, units
            blockIndex.AppendPreparedBlock data, firstStateRow, rowIndex - firstStateRow''')
t=t.replace('''                PutCombinationElementResults data, rowIndex, section, batch, i, _
                    batch.ResultAt(i).StateRepository.StateAt(stateIndex), runID, units''','''                firstStateRow = rowIndex
                PutCombinationElementResults data, rowIndex, section, batch, i, _
                    batch.ResultAt(i).StateRepository.StateAt(stateIndex), runID, units
                blockIndex.AppendPreparedBlock data, firstStateRow, rowIndex - firstStateRow''')
t=t.replace('mCapturedSnapshot.AddPreparedElementResults data, rowIndex - 1','mCapturedSnapshot.AddPreparedElementResults data, rowIndex - 1, blockIndex')
needle='''    target.Resize(rowCount, ELEMENT_RESULT_COLUMNS).Value2 = data
    FormatResultsBlock target, rowCount, ELEMENT_RESULT_COLUMNS, "Результаты элементов по сочетаниям"
End Sub'''
assert t.count(needle)==1
t=t.replace(needle,'''    target.Resize(rowCount, ELEMENT_RESULT_COLUMNS).Value2 = data
    FormatResultsBlock target, rowCount, ELEMENT_RESULT_COLUMNS, "Результаты элементов по сочетаниям"
    Set mPendingElementIndex = blockIndex
End Sub''')
# Прямая запись завершается публикацией индекса только после всех технических таблиц.
a=t.index('Public Sub WriteResults(');b=t.index('End Sub',a)
body=t[a:b]
body+='''    If Not mPendingElementIndex Is Nothing Then
        Dim indexData As Variant: indexData = ElementResultIndexMatrix(mPendingElementIndex)
        PublishElementResultIndex workbook, indexData, Me
        Set mPendingElementIndex = Nothing
    End If
'''
t=t[:a]+body+t[b:]
(P/'CNDMResultsWriter.cls').write_text(t,encoding='utf8')
t=(P/'modIndexedExcelResults.bas').read_text(encoding='utf8')
t=t.replace('''    Dim anchor As Object: Set anchor = ExistingIndexAnchor(workbook)
    If anchor Is Nothing Then Exit Sub
    PrepareIndexedResultsWrite workbook''','''    Dim anchor As Object: Set anchor = ExistingIndexAnchor(workbook)
    If anchor Is Nothing Then Set anchor = EnsureElementResultIndexAnchor(workbook, 2)
    PrepareIndexedResultsWrite workbook''')
(P/'modIndexedExcelResults.bas').write_text(t,encoding='utf8')
t=(P/'modSectionSnapshot.bas').read_text(encoding='utf8')
needle='    Dim data As Variant: data = ReadAnchoredResultTable(workbook, rangeName)'
assert t.count(needle)==1
t=t.replace(needle,'''    Dim data As Variant
    If rangeName = "rngNDMElementResults" Then data = ReadElementResultTable(workbook, , , True) Else data = ReadAnchoredResultTable(workbook, rangeName)''')
(P/'modSectionSnapshot.bas').write_text(t,encoding='utf8')
print('Prepared simultaneous producer index and indexed Worst fallback')
