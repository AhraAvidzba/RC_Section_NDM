﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Проверяет жизненный цикл индекса и адресные реакции на незавершённую запись.
param([int]$Attempt=1)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$out=Join-Path $p ('Lifecycle17_Attempt'+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh lifecycle directory required'}
[void][IO.Directory]::CreateDirectory($out)
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
$path=Join-Path $out 'Lifecycle.xlsm'
Copy-Item -LiteralPath (Join-Path $p 'Prototype11/Prototype.xlsm') -Destination $path
Copy-Item -LiteralPath (Join-Path $p 'Prototype11/IndexedBaseline.ndm') -Destination (Join-Path $out 'IndexedBaseline.ndm')
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestLifecycleOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestLifecycleOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135
 $component=$book.VBProject.VBComponents.Add(1);$component.Name='modTestIndexedLifecycle'
 $code=[IO.File]::ReadAllText((Join-Path $p 'modTestIndexedLifecycle.bas'),[Text.Encoding]::UTF8)
 $component.CodeModule.AddFromString(([regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')))
 $component=$book.VBProject.VBComponents.Item('CNDMResultsWriter')
 $code=$component.CodeModule.Lines(1,$component.CodeModule.CountOfLines)
 $needle='    For Each key In snapshot.BaseKeys()'
 if(([regex]::Matches($code,[regex]::Escape($needle))).Count -ne 1){throw 'Unique restore injection point required'}
 $code=$code.Replace($needle,$needle+[Environment]::NewLine+'        If modTestIndexedLifecycle.TestShouldFailWrite(CStr(key)) Then Err.Raise 5, , "Injected private output failure"')
 $component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines);$component.CodeModule.AddFromString($code)
 $prefix="'$($book.Name)'!modTestIndexedLifecycle."
 $result=[string]$app.Run($prefix+'TestLifecycle');Write-Output $result
 $result|Set-Content (Join-Path $out 'Result.txt') -Encoding UTF8
 if(-not $result.StartsWith('PASS|')){throw $result}
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
