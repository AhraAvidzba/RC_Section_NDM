﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Готовит частную копию текущей книги: VBA, справка и один индекс; расчёт не запускает.
param([int]$Attempt=1)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$root='C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'
$out=Join-Path $p ('Current22_Attempt'+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh current output directory required'}
[void][IO.Directory]::CreateDirectory($out)
$source=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
if((Get-FileHash $source).Hash -ne 'A5C7E6B7E6105E9107C260DF888B7C77FE15386080DD8AD4B235B9CDE1AED540'){throw 'Current user workbook changed; take a new baseline before proceeding'}
Copy-Item -LiteralPath $source -Destination (Join-Path $out 'Before.xlsm')
$path=Join-Path $out 'RC_Section_NDM.xlsm';Copy-Item -LiteralPath $source -Destination $path
. (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
. (Join-Path $root 'tools/build_workbook/SectionRecipeGuide.ps1')
. (Join-Path $root 'tools/build_workbook/HelpOutline.ps1')
. (Join-Path $root 'tools/build_workbook/StandaloneHelpText.ps1')
. (Join-Path $root 'tools/build_workbook/IndexedResultsTable.ps1')
# Добавляет только один проверенный якорь; остальные имена не меняет.
function Add-WorkbookName($Workbook,$Name,$Sheet,$Address){$Workbook.Names.Add($Name,("='"+$Sheet.Name+"'!"+$Address))|Out-Null}
$script:FormulaImageDir=Join-Path $out 'FormulaImages'
$layout=Get-Content (Join-Path $root 'tools/build_workbook/WorkbookLayout.json') -Raw -Encoding UTF8|ConvertFrom-Json
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestCurrentOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestCurrentOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($path,0,$false);$app.Calculation=-4135;$app.CalculateBeforeSave=$false
 foreach($file in @((Get-ChildItem -File -LiteralPath (Join-Path $p 'Candidate'))+(Get-ChildItem -File -LiteralPath (Join-Path $p 'CandidateTests')))){
  $component=$null;try{$component=$book.VBProject.VBComponents.Item($file.BaseName)}catch{}
  if(-not $component){$kind=1;if($file.Extension -eq '.cls'){$kind=2};$component=$book.VBProject.VBComponents.Add($kind);$component.Name=$file.BaseName}
  $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  if($file.Extension -eq '.cls'){$code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')}else{$code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')}
  if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
  $component.CodeModule.AddFromString($code)
 }
 $anchor=$book.Worksheets.Item('Results').Range(($layout.Names|Where-Object Name -eq rngNDMElementResultIndex).Address)
 if($app.WorksheetFunction.CountA($anchor.Offset(-1,0).Resize(3,14)) -ne 0){throw 'New index location is occupied'}
 Add-IndexedResultsTable $book $layout
 $anchor.Resize(1,14).EntireColumn.ColumnWidth=14
 $component=$book.VBProject.VBComponents.Add(1);$component.Name='modTestCurrentIndex'
 $component.CodeModule.AddFromString("Option Explicit`r`nPublic Function TestCreateIndex() As Long`r`nDim rows As Variant`r`nrows = ReadIndexedExcelElementResults(ThisWorkbook, vbNullString, vbNullString, True)`r`nIf IsArray(rows) Then TestCreateIndex = UBound(rows, 1) - 1`r`nEnd Function")
 $app.AutomationSecurity=1
 $count=[int]$app.Run("'$($book.Name)'!modTestCurrentIndex.TestCreateIndex")
 $book.VBProject.VBComponents.Remove($component);$component=$null
 Write-Output ('Current data index states='+$count)
 $sheet=$book.Worksheets.Item('Справка')
 $book.Names.Item('rngSectionRecipeGuide').Delete()
 Add-SettingsInstructions $book $book.Worksheets.Item('Config') $sheet
 Update-SectionRecipeGuide $book $root|Out-Null
 Update-StandaloneHelpText $book|Out-Null
 Fit-SettingsInstructionRows $sheet
 Set-HelpSectionOrderAndOutline $book -Expanded|Out-Null
 if($sheet.Shapes.Count -ne 78){throw 'Help formula/image inventory changed'}
 $app.VBE.ActiveVBProject=$book.VBProject;$compile=$app.VBE.CommandBars.FindControl(1,578)
 if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'Current book compile failed'}
 $book.Save();$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book);$book=$null
 $component=$null;$sheet=$null;$anchor=$null;[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $app.AutomationSecurity=3;$book=$app.Workbooks.Open($path,0,$true)
 if(-not $book.ReadOnly){throw 'Reopen must be readonly'}
 $text=New-Object Text.StringBuilder
 [void]$text.AppendLine('VBA PROJECT EXPORT');[void]$text.AppendLine('Workbook: '+$book.Name);[void]$text.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
 $components=[int]$book.VBProject.VBComponents.Count
 for($i=1;$i -le $components;$i++){
  $component=$book.VBProject.VBComponents.Item($i);$lines=$component.CodeModule.CountOfLines
  [void]$text.AppendLine('='*100);[void]$text.AppendLine('COMPONENT: '+$component.Name);[void]$text.AppendLine('TYPE: '+$component.Type);[void]$text.AppendLine('LINES: '+$lines);[void]$text.AppendLine('='*100)
  if($lines){[void]$text.AppendLine($component.CodeModule.Lines(1,$lines))};[void]$text.AppendLine()
 }
 [IO.File]::WriteAllText((Join-Path $out 'VBA_All_Code.txt'),$text.ToString(),[Text.UTF8Encoding]::new($true))
 $index=$book.Names.Item('rngNDMElementResultIndex').RefersToRange
 if($index.Address() -ne '$DL$156' -or [string]$index.Value2 -ne 'IndexKind'){throw 'Saved index anchor/header differs'}
 [ordered]@{Status='CURRENT_BOOK_SAVED_REOPENED_NATIVE_REVIEW_PENDING';BeforeSHA256=(Get-FileHash $source).Hash;AfterSHA256=(Get-FileHash $path).Hash;IndexStates=$count;Components=$components;HelpPictures=78;CalculationRun=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'Native.json') -Encoding UTF8
 Write-Output ('Saved/reopened current book; components='+$components)
}catch{
 $_.Exception.ToString()|Set-Content (Join-Path $out 'Error.txt') -Encoding UTF8
 throw
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;$compile=$null;$sheet=$null;$index=$null;$anchor=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
