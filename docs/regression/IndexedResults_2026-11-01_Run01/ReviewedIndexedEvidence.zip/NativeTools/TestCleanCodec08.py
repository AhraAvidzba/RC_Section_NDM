"""ДЛЯ ТЕСТОВ: оставляет один writer кодека и совместимый reader v4/v5."""
from pathlib import Path
P=Path(__file__).parent/'Candidate'
t=(P/'CCalculationSnapshotStore.cls').read_text(encoding='utf8')
def remove(t,start,end):
 a=t.index(start);b=t.index(end,a);return t[:a]+t[b:]
t=remove(t,"' Записывает матрицы плотным колоночным кодеком.","' Отличает новую обязательную геометрию")
t=remove(t,"' Записывает переданный снимком массив", "' Проверяет контрольную сумму до выделения")
t=remove(t,"' Сохраняет колонку плотными массивами", "' Готовит крупный словарь")
t=remove(t,"' Служебные поля состояния хранятся сериями", "' Восстанавливает значения без десятичных")
(P/'CCalculationSnapshotStore.cls').write_text(t,encoding='utf8')
t=(P/'CCalculationSnapshot.cls').read_text(encoding='utf8')
t=remove(t,"' Передаёт большую таблицу элементов кодеку", "' Возвращает размер без копирования")
(P/'CCalculationSnapshot.cls').write_text(t,encoding='utf8')
t=(P/'CNDMResultsWriter.cls').read_text(encoding='utf8')
a=t.index('Public Sub WriteResults(');b=t.index('End Sub',a)
segment=t[a:b].replace('    mMinimalFormatting = Not fullFormatting','    mMinimalFormatting = Not fullFormatting\n    Set mPendingElementIndex = Nothing',1)
t=t[:a]+segment+t[b:]
(P/'CNDMResultsWriter.cls').write_text(t,encoding='utf8')
print('Removed unused legacy writer duplication; v4/v5 reader preserved')
