"""ДЛЯ ТЕСТОВ: единый расширенный benchmark для sealed before и изолированного after."""
from pathlib import Path
S=Path(__file__).parent
t=(S/'modTestIndexedBaseline.bas').read_text(encoding='utf8')
t=t.replace('Private mTestMetric As String, mTestDatasetStage As String','''Private mTestMetric As String, mTestDatasetStage As String
Private mTestUpperRows(1 To 4) As Long, mTestUpperColumns(1 To 4) As Long
Private mTestRangeCells As Double, mTestExtentCells As Double, mTestRangeCalls As Long
Private mTestPreparedSave As Boolean''')
t=t.replace('    mTestRunID = mTestFixture.RunID: mTestElapsed = mTestFixture.ElapsedSeconds','    mTestRunID = mTestFixture.RunID: mTestElapsed = mTestFixture.ElapsedSeconds\n    TestRememberShapes')
t=t.replace('''Private Function TestFreshSnapshot() As CCalculationSnapshot
    If mTestFixture''','''Private Function TestFreshSnapshot() As CCalculationSnapshot
    If mTestPreparedSave Then Set TestFreshSnapshot = mTestFixture.TestPreparedClone: Exit Function
    If mTestFixture''')
t=t.replace('''    If action = "SaveFile" Or action = "SaveExcel" Then''','''    mTestPreparedSave = (action = "SavePreparedFile" Or action = "SavePreparedExcel")
    If action = "SaveFile" Or action = "SaveExcel" Or mTestPreparedSave Then''')
t=t.replace('If action = "SaveExcel" Or action = "SelectExcel" Or action = "RestoreExcel" Or action = "UpdateExcel" Then','If Right$(action, 5) = "Excel" Then')
t=t.replace('mTestBytes = 0#: mTestRows = 0#: mTestReads = 0','mTestBytes = 0#: mTestRows = 0#: mTestReads = 0\n    mTestRangeCells = 0#: mTestExtentCells = 0#: mTestRangeCalls = 0')
t=t.replace('Case "SaveFile", "SaveExcel"','Case "SaveFile", "SaveExcel", "SavePreparedFile", "SavePreparedExcel"')
t=t.replace('If action = "SaveFile" Then','If action = "SaveFile" Or action = "SavePreparedFile" Then')
a=t.index('        Case "RestoreExcel"');b=t.index('        Case "UpdateFile"',a)
t=t[:a]+'''        Case "RestoreExcel"
            Dim key As Variant, restored As Object, anchor As Range, item As Long, names As Variant, headers As Variant
            Set restored = CreateObject("Scripting.Dictionary")
            For Each key In Array("rngNDMSectionGeometry", "rngNDMSectionContours", "rngNDMElementGeometry", "rngNDMSectionProperties", "rngNDMMaterialDiagrams", "rngNDMElementResults", "rngNDMSectionAnnotations")
                values = ReadPhysicalResultTable(ThisWorkbook, CStr(key)): restored.Add CStr(key), values
            Next key
            names = Array("rngBatchSummary", "rngStrengthSummaryAnchor", "rngCrackSummaryAnchor", "rngStabilitySummaryAnchor")
            headers = Array(0, 4, 4, 5)
            For item = 0 To 3
                Set anchor = ThisWorkbook.Names(CStr(names(item))).RefersToRange.Offset(-CLng(headers(item)), 0)
                values = anchor.Resize(mTestUpperRows(item + 1), mTestUpperColumns(item + 1)).Value2
                TestReadRange mTestUpperRows(item + 1), mTestUpperColumns(item + 1), False
                restored.Add CStr(names(item)), values
            Next item
'''+t[b:]
t=t.replace('mTestMetric = "Bytes=" & CStr(mTestBytes) & "|Rows=" & CStr(mTestRows) & "|ReadCalls=" & CStr(mTestReads)','mTestMetric = "Bytes=" & CStr(mTestBytes) & "|PhysicalReadCalls=" & CStr(mTestReads) & "|RangeCells=" & CStr(mTestRangeCells) & "|ExtentCells=" & CStr(mTestExtentCells) & "|RangeCalls=" & CStr(mTestRangeCalls)')
t+='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет только размеры реально сохранённых верхних таблиц, не полный снимок для чтения.
Private Sub TestRememberShapes()
    mTestUpperRows(1) = mTestFixture.TableRowCount("Summary"): mTestUpperColumns(1) = 33
    mTestUpperRows(2) = mTestFixture.TableRowCount("Strength.Data") + 4: mTestUpperColumns(2) = 49
    mTestUpperRows(3) = mTestFixture.TableRowCount("Cracks.Data") + 4: mTestUpperColumns(3) = 72
    mTestUpperRows(4) = mTestFixture.TableRowCount("Stability.Data") + 5: mTestUpperColumns(4) = 84
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает все физические диапазоны Value2, включая поиск высоты и индексные метаданные.
Public Sub TestReadRange(ByVal rows As Long, ByVal columns As Long, ByVal extent As Boolean)
    mTestRangeCells = mTestRangeCells + CDbl(rows) * columns: mTestRangeCalls = mTestRangeCalls + 1
    If extent Then mTestExtentCells = mTestExtentCells + CDbl(rows) * columns
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Переключает выбор на другое фактически существующее состояние без расчёта и без полного снимка в кэше.
Public Sub TestSelectState(ByVal combinationID As String, ByVal stateType As String)
    mTestCase = combinationID: mTestState = stateType
End Sub
'''
(S/'modTestIndexedBaselineExtended.bas').write_text(t,encoding='utf8')
# Оба адаптера копируют те же исходные массивы; after готовит свежий индекс из известных границ фактических состояний внутри таймера.
common='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Моделирует подготовку writer-а из готовых массивов; импортируется только в частную benchmark-книгу.
Friend Function TestPreparedClone() As CCalculationSnapshot
    Dim result As New CCalculationSnapshot, key As Variant, values As Variant, elements() As Variant
    result.RunID = mRunID: result.ElapsedSeconds = mElapsedSeconds
    For Each key In mTables.Keys
        If CStr(key) = "rngNDMElementResults" Then
            elements = mElements
            TEST_PREPARE_ELEMENTS
        Else
            values = Table(CStr(key)): result.AddTable CStr(key), values
        End If
    Next key
    result.Validate
    Set TestPreparedClone = result
End Function
'''
before=common.replace('TEST_PREPARE_ELEMENTS','result.AddPreparedElementResults elements, UBound(elements, 1)')
after=common.replace('TEST_PREPARE_ELEMENTS','''Dim sourceIndex As CResultBlockIndex: Set sourceIndex = ElementIndex
            Dim prepared As New CResultBlockIndex, header As Variant, sample As Variant, block As Long
            header = sourceIndex.Header: prepared.Initialize header, mRunID
            For block = 1 To sourceIndex.Count
                sample = sourceIndex.Representative(block): prepared.Append sourceIndex.FirstRow(block), sourceIndex.RowCount(block), sample
            Next block
            result.AddPreparedElementResults elements, UBound(elements, 1), prepared''')
(S/'TestPreparedCloneBefore.bas.txt').write_text(before,encoding='utf8')
(S/'TestPreparedCloneAfter.bas.txt').write_text(after,encoding='utf8')
print('Prepared complete 7+4 table read, scope switching, honest producer-style save adapter and extent counters')
