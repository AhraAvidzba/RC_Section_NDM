"""ДЛЯ ТЕСТОВ: проверяет сохранность данных, формул и исходников нативной конечной книги."""
import importlib, json, struct, sys, hashlib, posixpath
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parent
repo=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
sys.path.insert(0,str(repo/'tools/build_workbook'))
check=importlib.import_module('Verify-CalculationSnapshotRelease')
reader=importlib.import_module('Verify-SectionRecipeGuide')
S=reader.S;R=reader.R

def content(path):
    with ZipFile(path) as archive:
        strings=[]
        if 'xl/sharedStrings.xml' in archive.namelist(): strings=[''.join(n.itertext()) for n in ET.fromstring(archive.read('xl/sharedStrings.xml'))]
        book=ET.fromstring(archive.read('xl/workbook.xml'))
        relations={n.get('Id'):n.get('Target') for n in ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))}
        result={}
        for sheet in book.find(S+'sheets'):
            target=relations[sheet.get(R+'id')];target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
            doc=ET.fromstring(archive.read(target));cells={}
            for cell in doc.findall('.//'+S+'sheetData/'+S+'row/'+S+'c'):
                v=cell.find(S+'v');value=None if v is None else v.text;kind=cell.get('t','n')
                if kind=='s': value=strings[int(value)];kind='text'
                elif kind=='inlineStr': value=''.join(cell.find(S+'is').itertext());kind='text'
                elif kind=='n' and value is not None: value=struct.pack('<d',float(value)).hex()
                cells[cell.get('r')]=(kind,value,reader.canonical(cell.find(S+'f')))
            result[sheet.get('name')]=(cells,doc)
        return result

folder=root/'Current26'
before,after=content(root/'Current22_Attempt2/Before.xlsm'),content(folder/'RC_Section_NDM.xlsm')
errors=[];checks=0
for sheet,(cells,doc) in before.items():
    if sheet=='Справка': continue
    new,newdoc=after[sheet]
    for address,value in cells.items():
        if value[1] is None and value[2] is None: continue
        checks+=1
        if new.get(address)!=value: errors.append(f'Changed cell {sheet}!{address}: {value} -> {new.get(address)}')
    for tag in ('dataValidations','mergeCells','conditionalFormatting'):
        if sheet=='Results' and tag=='mergeCells': continue
        if tag=='mergeCells':
            a=doc.find(S+tag);b=newdoc.find(S+tag)
            if sorted(n.get('ref') for n in ([] if a is None else a))!=sorted(n.get('ref') for n in ([] if b is None else b)): errors.append(f'Changed merge regions: {sheet}')
            continue
        if reader.canonical(doc.find(S+tag))!=reader.canonical(newdoc.find(S+tag)): errors.append(f'Changed {tag}: {sheet}')
old,new=reader.read(root/'Current22_Attempt2/Before.xlsm'),reader.read(folder/'RC_Section_NDM.xlsm')
def pictures(path):
    relns='{http://schemas.openxmlformats.org/package/2006/relationships}'
    an='{http://schemas.openxmlformats.org/drawingml/2006/main}'
    xn='{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}'
    with ZipFile(path) as archive:
        def rels(owner):
            part=posixpath.join(posixpath.dirname(owner),'_rels',posixpath.basename(owner)+'.rels')
            return {n.get('Id'):posixpath.normpath(posixpath.join(posixpath.dirname(owner),n.get('Target'))).lstrip('/') for n in ET.fromstring(archive.read(part)) if n.get('TargetMode')!='External'}
        book=ET.fromstring(archive.read('xl/workbook.xml'));links=rels('xl/workbook.xml');output={}
        for sheet in book.find(S+'sheets'):
            if sheet.get('name')=='Справка': continue
            part=links[sheet.get(R+'id')];doc=ET.fromstring(archive.read(part));drawing=doc.find(S+'drawing')
            if drawing is None: continue
            draw=rels(part)[drawing.get(R+'id')];media=rels(draw)
            for pic in ET.fromstring(archive.read(draw)).iter(xn+'pic'):
                name=pic.find(xn+'nvPicPr/'+xn+'cNvPr').get('name');blip=pic.find('.//'+an+'blip')
                if blip is not None:output[sheet.get('name')+'!'+name]=hashlib.sha256(archive.read(media[blip.get(R+'embed')])).hexdigest()
        props={}
        if 'docProps/custom.xml' in archive.namelist():
            props={n.get('name'):tuple((c.tag,c.text) for c in n) for n in ET.fromstring(archive.read('docProps/custom.xml'))}
        return output,props
oldpics,oldprops=pictures(root/'Current22_Attempt2/Before.xlsm');newpics,newprops=pictures(folder/'RC_Section_NDM.xlsm')
if oldpics!=newpics: errors.append('Changed non-Help picture content/names')
for name,value in oldprops.items():
    if newprops.get(name)!=value: errors.append('Changed custom property '+name)
if set(newprops)-set(oldprops)!={'NDM.ElementResultIndex.Protection'}: errors.append('Unexpected custom properties')
for name,value in old['names'].items():
    if 'Справка' in value or name.startswith('_xlnm.'): continue
    if new['names'].get(name)!=value: errors.append('Changed anchor '+name)
if set(new['names'])-set(old['names'])!={'rngNDMElementResultIndex'}: errors.append('Unexpected added names')
for sheet in ('Config','Сечения','Расчет','Calc'):
    if sheet not in old['sheets']: continue
    for address,value in old['sheets'][sheet]['cells'].items():
        if new['sheets'][sheet]['cells'].get(address,{}).get('style')!=value['style']: errors.append(f'Changed input cell style {sheet}!{address}')
    if old['sheets'][sheet]['columns']!=new['sheets'][sheet]['columns']: errors.append('Changed input widths '+sheet)
sources,documents,source_errors=check.verify_native_sources(folder/'VBA_All_Code.txt',repo)
errors.extend(source_errors)
result={'Status':'FAIL' if errors else 'PASS_CURRENT_DATA_AND_SOURCE_NATIVE','CellChecks':checks,'SourceComponents':sources,'DocumentComponents':documents,'PicturesByteIdentical':len(oldpics),'ExistingCustomPropertiesPreserved':len(oldprops),'Recalculated':False,'Errors':errors}
(root/'CurrentBookReview23.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(bool(errors))
