Attribute VB_Name = "modTestIndexedLifecycle"
Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Жизненный цикл Excel-индекса в частной книге: очистка, новая публикация и однократное восстановление.
Private mTestFailWrite As Boolean

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Одноразовая точка отказа добавляется runner-ом только в частный writer.
Public Function TestShouldFailWrite(ByVal key As String) As Boolean
    If mTestFailWrite And key = "rngNDMSectionProperties" Then mTestFailWrite = False: TestShouldFailWrite = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выбирает источник в тестовом Config без вызова расчёта.
Private Sub TestStorage(ByVal mode As String)
    Dim target As Range, row As Long: Set target = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = "Results.SnapshotStorage" Then target.Cells(row, 2).Value2 = mode: Exit Sub
    Next row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает размеры, типы и значения выбранного состояния после операций жизненного цикла.
Private Sub TestEqual(ByRef expected As Variant, ByRef actual As Variant)
    If UBound(expected, 1) <> UBound(actual, 1) Or UBound(expected, 2) <> UBound(actual, 2) Then Err.Raise 5, , "Lifecycle result dimensions"
    Dim row As Long, column As Long
    For row = 1 To UBound(expected, 1)
        For column = 1 To UBound(expected, 2)
            If VarType(expected(row, column)) <> VarType(actual(row, column)) Or expected(row, column) <> actual(row, column) Then Err.Raise 5, , "Lifecycle result differs"
        Next column
    Next row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет инвалидацию до записи и восстановление индекса по ключам только один раз.
Public Function TestLifecycle() As String
    On Error GoTo Failed
    TestStorage "File"
    Dim store As New CCalculationSnapshotStore, snapshot As CCalculationSnapshot, writer As New CNDMResultsWriter
    Set snapshot = store.LoadFile(ThisWorkbook)
    writer.RestoreSnapshotBase ThisWorkbook, snapshot, False, True: TestStorage "Excel"
    Dim expected As Variant, actual As Variant, code As Long, refused As Long
    expected = snapshot.SelectElementResults("PERF_01", "StrengthState", False)
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual
    Dim index As Range, elements As Range, sheet As Worksheet, originalAddress As String, indexRows As Long
    Set index = ThisWorkbook.Names("rngNDMElementResultIndex").RefersToRange: originalAddress = index.Address
    Set elements = ThisWorkbook.Names("rngNDMElementResults").RefersToRange: Set sheet = elements.Worksheet
    indexRows = CLng(index.Offset(1, 5).Value2) + 2
    ' Неверное число записей индекса не запускает повторное построение поверх противоречивых данных.
    index.Offset(1, 5).Value2 = 0
    On Error Resume Next
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): code = Err.Number: Err.Clear
    On Error GoTo Failed
    If code = 0 Then Err.Raise 5, , "Corrupt index accepted" Else refused = refused + 1
    index.Offset(1, 5).Value2 = indexRows - 2
    ' Отказ после записи части таблиц обязан оставить индекс Invalid и не возвращать смешанные результаты.
    mTestFailWrite = True
    On Error Resume Next
    writer.RestoreSnapshotBase ThisWorkbook, snapshot, False, True: code = Err.Number: Err.Clear
    On Error GoTo Failed
    If code = 0 Then Err.Raise 5, , "Injected write failure did not occur"
    On Error Resume Next
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): code = Err.Number: Err.Clear
    On Error GoTo Failed
    If code = 0 Then Err.Raise 5, , "Partially published output accepted" Else refused = refused + 1
    writer.RestoreSnapshotBase ThisWorkbook, snapshot, False, True
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual
    writer.ClearResults ThisWorkbook
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False)
    ' Минимальное оформление сохраняет шапку; после очистки строк НДС быть не должно.
    If IsArray(actual) Then
        If UBound(actual, 1) > 1 Then Err.Raise 5, , "Clear retained old state rows: " & CStr(UBound(actual, 1) - 1)
    End If
    actual = ReadElementResultTable(ThisWorkbook, "", "", True)
    If IsArray(actual) Then
        If UBound(actual, 1) > 1 Then Err.Raise 5, , "Clear retained state index rows"
    End If
    writer.RestoreSnapshotBase ThisWorkbook, snapshot, False, True
    If ThisWorkbook.Names("rngNDMElementResultIndex").RefersToRange.Address <> originalAddress Then Err.Raise 5, , "Index anchor drifted"
    ' Удаление собственной структуры имитирует книгу без индекса. Читаемые результаты остаются прежними.
    sheet.Unprotect "NDM_ResultIndex_v1"
    index.Offset(-1, 0).Resize(indexRows + 1, 14).Clear
    ThisWorkbook.Names("rngNDMElementResultIndex").Delete
    ThisWorkbook.CustomDocumentProperties.Item("NDM.ElementResultIndex.Protection").Delete
    Call TestIndexedExcelReadCounters(True)
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual
    Dim bootstrap As String: bootstrap = TestIndexedExcelReadCounters()
    If CDbl(Split(bootstrap, "|")(2)) <> snapshot.TableRowCount("rngNDMElementResults") Then Err.Raise 5, , "Expected one-time bootstrap"
    Call TestIndexedExcelReadCounters(True)
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual
    If Split(TestIndexedExcelReadCounters(), "|")(2) <> "0" Then Err.Raise 5, , "Bootstrap repeated"
    Set index = ThisWorkbook.Names("rngNDMElementResultIndex").RefersToRange
    If index.Address <> originalAddress Then Err.Raise 5, , "Bootstrap shifted anchor"
    ' Перенос целой таблицы средствами VBA сохраняет относительные смещения и именованный якорь.
    Dim destination As Range, oldLocation As Range
    Set oldLocation = elements.Cells(1, 1): Set destination = index.Offset(0, 16)
    If ThisWorkbook.Application.WorksheetFunction.CountA(destination.Resize(snapshot.TableRowCount("rngNDMElementResults"), 9)) <> 0 Then Err.Raise 5, , "Move destination occupied"
    elements.Resize(snapshot.TableRowCount("rngNDMElementResults"), 9).Cut Destination:=destination
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual
    Set elements = ThisWorkbook.Names("rngNDMElementResults").RefersToRange
    elements.Resize(snapshot.TableRowCount("rngNDMElementResults"), 9).Cut Destination:=oldLocation
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual
    TestLifecycle = "PASS|Refusals=" & CStr(refused) & "|Clear=true|Republish=true|BootstrapOnce=true|StableAnchor=true|WholeTableMove=true"
    Exit Function
Failed:
    TestLifecycle = "ERROR|" & Err.Source & "|" & Err.Description
End Function
