"""ДЛЯ ТЕСТОВ: обновляет время как метаданные, без фиктивного неполного CCalculationSnapshot."""
from pathlib import Path
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM');P=Path(__file__).parent/'Candidate'
t=(P/'CCalculationSnapshotStore.cls').read_text(encoding='utf8')
needle='Public Sub UpdateSavedElapsed(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot)'
assert t.count(needle)==1
t=t.replace(needle,'''Public Sub UpdateSavedElapsed(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot)
    UpdateElapsedValue workbook, snapshot.ElapsedSeconds, snapshot.RunID
End Sub

' Обновляет только длительность подтверждённого запуска; не принимает частичный объект полного снимка.
Public Sub UpdateElapsedValue(ByVal workbook As Object, ByVal seconds As Double, Optional ByVal expectedRunID As Double = 0#)''')
t=t.replace('If indexed.RunID <> snapshot.RunID Then Err.Raise 5, , "Обновляемое время относится к другому расчёту."','If expectedRunID <> 0# Then If indexed.RunID <> expectedRunID Then Err.Raise 5, , "Обновляемое время относится к другому расчёту."')
t=t.replace('indexed.UpdateElapsed temporary, snapshot.ElapsedSeconds','indexed.UpdateElapsed temporary, seconds')
t=t.replace('file.WriteDouble snapshot.ElapsedSeconds','file.WriteDouble seconds')
# Единственный Failed этой операции должен освободить и новый reader до удаления своей копии.
a=t.index('Public Sub UpdateElapsedValue(');b=t.index("' Проверяет существование Unicode",a)
section=t[a:b].replace('    file.CloseFile\n    If ownsTemporary','    file.CloseFile\n    indexed.CloseFile\n    Set indexed = Nothing\n    If ownsTemporary')
t=t[:a]+section+t[b:]
(P/'CCalculationSnapshotStore.cls').write_text(t,encoding='utf8')
t=(P/'CIndexedSnapshotFile.cls').read_text(encoding='utf8')
t+='''
' Явно освобождает собственный дескриптор перед удалением или заменой временного файла.
Public Sub CloseFile()
    If Not mFile Is Nothing Then mFile.CloseFile
End Sub
'''
(P/'CIndexedSnapshotFile.cls').write_text(t,encoding='utf8')
t=(R/'src/Excel/modWorkbookCalculation.bas').read_text(encoding='utf-8-sig')
t=t.replace('Dim completed As Boolean, destination As String, message As String\n    message = CalculateSectionCore(workbook, showMessages, startedAt, informationEnabled, requiresAttention, completed, destination)','Dim completed As Boolean, destination As String, message As String, savedRunID As Double\n    message = CalculateSectionCore(workbook, showMessages, startedAt, informationEnabled, requiresAttention, completed, destination, savedRunID)')
t=t.replace('"Время расчёта", requiresAttention, True)','"Время расчёта", requiresAttention, True, savedRunID)')
t=t.replace('Optional ByRef completed As Boolean = False, Optional ByRef savedDestination As String = "") As String','Optional ByRef completed As Boolean = False, Optional ByRef savedDestination As String = "", Optional ByRef savedRunID As Double = 0#) As String')
t=t.replace('    completed = True\n    Exit Function','    savedRunID = savedSnapshot.RunID\n    completed = True\n    Exit Function')
t=t.replace('ByVal timeCaption As String, ByRef requiresAttention As Boolean, Optional ByVal calculated As Boolean = False) As String','ByVal timeCaption As String, ByRef requiresAttention As Boolean, Optional ByVal calculated As Boolean = False, Optional ByVal expectedRunID As Double = 0#) As String')
t=t.replace('''        Dim snapshot As CCalculationSnapshot: Set snapshot = New CCalculationSnapshot
        snapshot.ElapsedSeconds = ElapsedSecondsFrom(startedAt)
        Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
        store.UpdateSavedElapsed workbook, snapshot
        Dim summary As CBatchResultWriter: Set summary = New CBatchResultWriter
        summary.UpdateElapsedSeconds workbook, snapshot.ElapsedSeconds''','''        Dim elapsed As Double: elapsed = ElapsedSecondsFrom(startedAt)
        Dim store As CCalculationSnapshotStore: Set store = New CCalculationSnapshotStore
        store.UpdateElapsedValue workbook, elapsed, expectedRunID
        Dim summary As CBatchResultWriter: Set summary = New CBatchResultWriter
        summary.UpdateElapsedSeconds workbook, elapsed''')
assert t.count('savedRunID = savedSnapshot.RunID')==1
(P/'modWorkbookCalculation.bas').write_text(t,encoding='utf8')
print('Prepared explicit elapsed-value API and checked actual calculated RunID')
