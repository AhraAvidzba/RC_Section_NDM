﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Компилирует только изолированный кандидат и сравнивает его с сохранённым v4/v5.
param([int]$Attempt=1,[int]$FixtureDiameter=0,[int]$Repeats=5)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$out=Join-Path $p ('Prototype'+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh prototype directory required'}
[void][IO.Directory]::CreateDirectory($out)
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
$bookPath=Join-Path $out 'Prototype.xlsm'
Copy-Item -LiteralPath (Join-Path $p 'Before.xlsm') -Destination $bookPath
Copy-Item -LiteralPath (Join-Path $p '../ActionLatency_2026-10-28_Run01/StorageRun02/Heavy1232_30_Optimized.ndm') -Destination (Join-Path $out 'IndexedBaseline.ndm')
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestIndexedOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
$app=$null;$book=$null;$own=0;$ticks=0;$quit=$false
try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestIndexedOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;StartedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 $book=$app.Workbooks.Open($bookPath,0,$false);$app.Calculation=-4135
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $p 'Candidate') -Filter '*.cls'){
  $component=$null;$pane=$null
  try{$component=$book.VBProject.VBComponents.Item($file.BaseName)}catch{}
  if(-not $component){$component=$book.VBProject.VBComponents.Add(2);$component.Name=$file.BaseName}
  $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  $code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')
  if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
  $component.CodeModule.AddFromString($code)
 }
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $p 'Candidate') -Filter '*.bas'){
  $component=$null
  try{$component=$book.VBProject.VBComponents.Item($file.BaseName)}catch{}
  if(-not $component){$component=$book.VBProject.VBComponents.Add(1);$component.Name=$file.BaseName}
  $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
  $code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')
  if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
  $component.CodeModule.AddFromString($code)
 }
 foreach($name in 'modTestIndexedBaseline','modTestIndexedPrototype'){
  $component=$book.VBProject.VBComponents.Add(1);$component.Name=$name
  $code=[IO.File]::ReadAllText((Join-Path $p ($name+'.bas')),[Text.Encoding]::UTF8)
  $component.CodeModule.AddFromString(([regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')))
 }
 # Диагностика helper-а остаётся строго тестовой и не меняет семантику контекста.
 $component=$book.VBProject.VBComponents.Item('modCalculationSnapshot')
 $component.CodeModule.AddFromString("`r`nPublic Function TestReadStateDetails() As String`r`nTestReadStateDetails = CStr(mReadDepth) & `"|`" & CStr(mReadSnapshot Is Nothing) & `"|`" & CStr(mReadWorkbook Is Nothing)`r`nEnd Function")
 $app.VBE.ActiveVBProject=$book.VBProject
 $app.VBE.CommandBars.FindControl(1,578).Execute()
 $prefix="'$($book.Name)'!"
 if($FixtureDiameter){$dataset=[string]$app.Run($prefix+'modTestIndexedBaseline.TestCreateDataset',[double]$FixtureDiameter)}else{$dataset=[string]$app.Run($prefix+'modTestIndexedBaseline.TestUseSavedDataset')}
 Write-Output $dataset
 if(-not $dataset.StartsWith('OK|')){throw $dataset}
 $result=[string]$app.Run($prefix+'modTestIndexedPrototype.TestRunV6');Write-Output $result
 $result|Set-Content (Join-Path $out 'Result.txt') -Encoding UTF8
 if(-not $result.StartsWith('PASS|')){throw $result}
 $edgeResult=[string]$app.Run($prefix+'modTestIndexedPrototype.TestRunEdgeCases');Write-Output $edgeResult
 $edgeResult|Set-Content (Join-Path $out 'EdgeResult.txt') -Encoding UTF8
 if(-not $edgeResult.StartsWith('PASS|')){throw $edgeResult}
 $excelResult=[string]$app.Run($prefix+'modTestIndexedPrototype.TestRunExcel');Write-Output $excelResult
 $excelResult|Set-Content (Join-Path $out 'ExcelResult.txt') -Encoding UTF8
 if(-not $excelResult.StartsWith('PASS|')){throw $excelResult}
 $heavyDetails=[string]$app.Run($prefix+'modTestIndexedPrototype.TestHeavyDetails');Write-Output $heavyDetails; $heavyDetails|Set-Content (Join-Path $out 'HeavyDetails.txt') -Encoding UTF8
 $measurements=@()
 for($repeat=1;$repeat -le $Repeats;$repeat++){
  foreach($action in 'SaveFile','SelectFile','RestoreFile','UpdateFile','SaveExcel','SelectExcel','RestoreExcel','UpdateExcel'){
   $seconds=[double]$app.Run($prefix+'modTestIndexedBaseline.TestMeasure',$action)
   if($seconds -lt 0){throw [string]$app.Run($prefix+'modTestIndexedBaseline.TestLastError')}
   $measurements+=,[ordered]@{Action=$action;Repeat=$repeat;Seconds=$seconds}
   $measurements|ConvertTo-Json|Set-Content (Join-Path $out 'Measurements.json') -Encoding UTF8
   Write-Output ($action+' '+$repeat+' '+$seconds.ToString('F4'))
  }
 }
 $book.Save()
 $book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book);$book=$null
 $component=$null;$pane=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 $book=$app.Workbooks.Open($bookPath,0,$false)
 $prefix="'$($book.Name)'!"
 $reopenResult=[string]$app.Run($prefix+'modTestIndexedPrototype.TestRunReopenProtection');Write-Output $reopenResult
 $reopenResult|Set-Content (Join-Path $out 'ReopenResult.txt') -Encoding UTF8
 if(-not $reopenResult.StartsWith('PASS|')){throw $reopenResult}
}catch{
 $problem=$_.Exception.ToString()
 try{$problem+=[Environment]::NewLine+[string]$app.Run($prefix+'modTestIndexedPrototype.TestStageDetails')}catch{$problem+=[Environment]::NewLine+$_.Exception.ToString()}
 try{$pane=$app.VBE.ActiveCodePane;$sl=0;$sc=0;$el=0;$ec=0;$pane.GetSelection([ref]$sl,[ref]$sc,[ref]$el,[ref]$ec);$problem+=[Environment]::NewLine+$pane.CodeModule.Name+':'+$sl+' '+$pane.CodeModule.Lines($sl,1)}catch{}
 $problem|Set-Content (Join-Path $out 'Error.txt') -Encoding UTF8
 Write-Output $problem
 throw
}finally{
 if($book){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $component=$null;$pane=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
