"""ДЛЯ ТЕСТОВ: выделяет общие табличные контракты в изолированном кандидате."""
from pathlib import Path
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM');P=Path(__file__).parent/'Candidate'
source=(R/'src/Excel/CCalculationSnapshot.cls').read_text(encoding='utf-8-sig')
def body(start,end):return source[source.index(start):source.index(end,source.index(start))]
shape=body('Private Sub ValidateTableShape(',"' Объединяет общие и LC-зависимые")
shape=shape.replace('Private Sub ValidateTableShape(', 'Public Sub ValidateSnapshotTableShape(')
profile=body('Public Function SavedVisualizationProfile(',"' Получает матрицу")
profile=profile.replace('Public Function SavedVisualizationProfile(ByVal profileID As String)', 'Public Function SnapshotVisualizationProfile(ByRef values As Variant, ByVal profileID As String)')
profile=profile.replace('    Dim values As Variant: values = Table("Calculation.Profiles")\n','').replace('Set SavedVisualizationProfile = profile','Set SnapshotVisualizationProfile = profile')
same=body('Private Function SameConcreteGeometryMatrix(',"' Проверяет запуск непосредственно")
same=same.replace('Private Function SameConcreteGeometryMatrix(', 'Public Function SnapshotMatricesEqual(').replace('SameConcreteGeometryMatrix = True','SnapshotMatricesEqual = True')
join=body('Public Function ResultTable(',"' Разделяет готовые свойства")
a=join.index('    Dim common As Variant');b=join.index('    ReDim joined',a)
join='''Public Function JoinSnapshotTables(ByRef common As Variant, ByRef cases As Variant) As Variant
    Dim joined() As Variant, i As Long, j As Long
'''+join[b:]
join=join.replace('    ResultTable = joined','    JoinSnapshotTables = joined')
run='''Public Sub ValidateSnapshotRunID(ByRef values As Variant, ByVal key As String, ByVal runID As Double)
    Dim row As Long
    If Left$(key, 6) <> "rngNDM" And Left$(key, 9) <> "LoadCase." Then Exit Sub
    For row = 2 To UBound(values, 1)
        If Len(CStr(values(row, 1))) > 0 Then
            If CDbl(values(row, 1)) <> runID Then Err.Raise 5, , "Таблицы относятся к разным запускам: " & key
        End If
    Next row
End Sub
'''
text='''Attribute VB_Name = "modSnapshotTables"
Option Explicit
' ==========================================================================
' Общие контракты неизменяемых таблиц полного снимка и адресного чтения
' ==========================================================================
' Здесь нет файлового или Excel-ввода; проверки и объединения не выполняют расчёт.
'''+"\n' Проверяет размеры готовой таблицы, не меняя её содержимого.\n"+shape+"\n' Восстанавливает только сохранённые настройки профиля просмотра.\n"+profile+"\n' Сравнивает исходную геометрию перед повторным использованием проверенных границ.\n"+same+"\n' Объединяет общие и LC-зависимые строки в исходном порядке.\n"+join+"\n' Проверяет принадлежность используемой таблицы текущему расчёту.\n"+run
(P/'modSnapshotTables.bas').write_text(text,encoding='utf8')
t=(P/'CCalculationSnapshot.cls').read_text(encoding='utf8')
for start,end,replacement in [
 ('Public Function SavedVisualizationProfile(',"' Получает матрицу",'''Public Function SavedVisualizationProfile(ByVal profileID As String) As CCalculationProfile
    Dim values As Variant: values = Table("Calculation.Profiles")
    Set SavedVisualizationProfile = SnapshotVisualizationProfile(values, profileID)
End Function

'''),
 ('Private Function SameConcreteGeometryMatrix(',"' Проверяет запуск непосредственно",'''Private Function SameConcreteGeometryMatrix(ByRef actual As Variant, ByRef expected As Variant) As Boolean
    SameConcreteGeometryMatrix = SnapshotMatricesEqual(actual, expected)
End Function

'''),
 ('Private Sub ValidateTableShape(',"' Объединяет общие и LC-зависимые",'''Private Sub ValidateTableShape(ByVal key As String, ByRef values As Variant)
    ValidateSnapshotTableShape key, values
End Sub

''')]:
 a=t.index(start);b=t.index(end,a);t=t[:a]+replacement+t[b:]
a=t.index('    Dim common As Variant',t.index('Public Function ResultTable('));b=t.index('End Function',a)
t=t[:a]+'''    Dim common As Variant, cases As Variant
    common = Table(key): cases = Table(extra)
    ResultTable = JoinSnapshotTables(common, cases)
'''+t[b:]
(P/'CCalculationSnapshot.cls').write_text(t,encoding='utf8')
print('Prepared isolated shared table contracts')
