﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Парные ABBA-замеры sealed before и изолированного after на одинаковых готовых данных.
param([ValidateSet('Light','Heavy')][string]$Dataset='Heavy',[int]$Cycles=3,[int]$Attempt=1)
$ErrorActionPreference='Stop'
Import-Module C:/Windows/System32/WindowsPowerShell/v1.0/Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1 -Global
$p=$PSScriptRoot;$out=Join-Path $p ('Paired16_'+$Dataset+'_Attempt'+$Attempt)
if(Test-Path -LiteralPath $out){throw 'Fresh paired benchmark directory required'}
[void][IO.Directory]::CreateDirectory($out)
$os=Get-CimInstance Win32_OperatingSystem;$mem=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($os.FreePhysicalMemory*1024 -lt 8GB -or $mem.CommitLimit-$mem.CommittedBytes -lt 14GB){throw 'Native memory reserve'}
$payload=Join-Path $p 'Baseline900_Attempt5/IndexedBaseline.ndm'
if($Dataset -eq 'Heavy'){$payload=Join-Path $p '../ActionLatency_2026-10-28_Run01/StorageRun02/Heavy1232_30_Optimized.ndm'}
foreach($version in 'Before','After'){
 $d=Join-Path $out $version;[void][IO.Directory]::CreateDirectory($d)
 Copy-Item -LiteralPath (Join-Path $p 'Before.xlsm') -Destination (Join-Path $d ($version+'.xlsm'))
 Copy-Item -LiteralPath $payload -Destination (Join-Path $d 'IndexedBaseline.ndm')
}
Add-Type 'using System;using System.Runtime.InteropServices;public static class NDMTestPairedOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$books=@{};$own=0;$ticks=0;$quit=$false;$records=@()
$existing=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)

# Импортирует один Unicode-компонент в соответствующий частный VBProject.
function Test-ImportComponent($book,$file){
 $name=$file.BaseName;$component=$null
 try{$component=$book.VBProject.VBComponents.Item($name)}catch{}
 if(-not $component){$kind=1;if($file.Extension -eq '.cls'){$kind=2};$component=$book.VBProject.VBComponents.Add($kind);$component.Name=$name}
 $code=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
 if($file.Extension -eq '.cls'){$code=[regex]::Replace($code,'(?s)^.*?(?=Option Explicit)','')}else{$code=[regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')}
 if($component.CodeModule.CountOfLines){$component.CodeModule.DeleteLines(1,$component.CodeModule.CountOfLines)}
 $component.CodeModule.AddFromString($code)
}

# Считает реальное чтение, включая вспомогательное определение высоты/ширины.
function Test-Instrument($book){
 $module=$book.VBProject.VBComponents.Item('CBinarySnapshotFile').CodeModule
 $code=$module.Lines(1,$module.CountOfLines)
 $code=$code.Replace('mPosition = mPosition + remaining: copied = count','modTestIndexedBaseline.TestReadBytes remaining'+[Environment]::NewLine+'            mPosition = mPosition + remaining: copied = count')
 $code=$code.Replace('mReadCount = take: mReadOffset = 0','modTestIndexedBaseline.TestReadBytes take'+[Environment]::NewLine+'            mReadCount = take: mReadOffset = 0')
 $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($code)
 $module=$book.VBProject.VBComponents.Item('modSectionSnapshot').CodeModule;$code=$module.Lines(1,$module.CountOfLines)
 $code=[regex]::Replace($code,'(?im)^(\s*ReadPhysicalResultTable = anchor\.Resize\(rowCount, columnCount\)\.value2)\s*$','$1'+[Environment]::NewLine+'    modTestIndexedBaseline.TestReadRange rowCount, columnCount, False')
 $code=[regex]::Replace($code,'(?im)^(\s*block = anchor\.Offset\(0, offset\)\.Resize\(1, count\)\.value2)\s*$','$1'+[Environment]::NewLine+'            modTestIndexedBaseline.TestReadRange 1, count, True')
 $code=[regex]::Replace($code,'(?im)^(\s*block = anchor\.Offset\(offset, 0\)\.Resize\(count, 1\)\.value2)\s*$','$1'+[Environment]::NewLine+'            modTestIndexedBaseline.TestReadRange count, 1, True')
 $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($code)
 $indexComponent=$null
 try{$indexComponent=$book.VBProject.VBComponents.Item('modIndexedExcelResults')}catch{}
 if($indexComponent){
  $module=$indexComponent.CodeModule;$code=$module.Lines(1,$module.CountOfLines)
  $code=[regex]::Replace($code,'(?i)(metadata = anchor\.Resize\(2, INDEX_COLUMNS\)\.value2)','$1: modTestIndexedBaseline.TestReadRange 2, INDEX_COLUMNS, False')
  $code=[regex]::Replace($code,'(?i)(header = elements\.Resize\(1, 9\)\.value2)','$1: modTestIndexedBaseline.TestReadRange 1, 9, False')
  $code=[regex]::Replace($code,'(?i)(keys = elements\.Resize\(rows, 4\)\.value2)','$1: modTestIndexedBaseline.TestReadRange rows, 4, False')
  $code=[regex]::Replace($code,'(?i)(values = anchor\.Offset\(2, 0\)\.Resize\(count, INDEX_COLUMNS\)\.value2)','$1: modTestIndexedBaseline.TestReadRange count, INDEX_COLUMNS, False')
  $code=[regex]::Replace($code,'(?i)(sample = elements\.Offset\(index\.FirstRow\(block\) - 1, 0\)\.Resize\(1, 9\)\.value2)','$1: modTestIndexedBaseline.TestReadRange 1, 9, False')
  $code=[regex]::Replace($code,'(?i)(data = elements\.Offset\(index\.FirstRow\(CLng\(block\)\) - 1, 0\)\.Resize\(index\.RowCount\(CLng\(block\)\), 9\)\.value2)','$1: modTestIndexedBaseline.TestReadRange index.RowCount(CLng(block)), 9, False')
  $code=[regex]::Replace($code,'(?im)^(\s*)(If Len\(CStr\(elements\.Cells\(1, 1\)\.value2\)\) = 0 Then Exit Function)','$1modTestIndexedBaseline.TestReadRange 1, 1, False'+[Environment]::NewLine+'$1$2')
  $code=[regex]::Replace($code,'(?im)^(\s*)(If Len\(CStr\(elements\.Offset\(rows, 0\)\.value2\)\) > 0 Then)','$1modTestIndexedBaseline.TestReadRange 1, 1, False'+[Environment]::NewLine+'$1$2')
  $module.DeleteLines(1,$module.CountOfLines);$module.AddFromString($code)
 }
}

# Измеряет один полный этап и сохраняет счётчики непосредственно после него.
function Test-Measure([string]$version,[string]$action,[string]$label,[int]$cycle){
 $book=$books[$version];$prefix="'$($book.Name)'!modTestIndexedBaseline."
 $process=Get-Process -Id $own
 if([string]$process.StartTime.ToUniversalTime().Ticks -ne [string]$ticks -or $process.PrivateMemorySize64 -gt 900MB){throw 'Native identity/memory guard'}
 $seconds=[double]$app.Run($prefix+'TestMeasure',$action)
 if($seconds -lt 0){throw [string]$app.Run($prefix+'TestLastError')}
 $metric=[string]$app.Run($prefix+'TestMetrics')
 $script:records+=,[ordered]@{Version=$version;Action=$action;Label=$label;Cycle=$cycle;Seconds=$seconds;Metrics=$metric;PrivateBytes=(Get-Process -Id $own).PrivateMemorySize64}
 $script:records|ConvertTo-Json -Depth 4|Set-Content (Join-Path $out 'Measurements.json') -Encoding UTF8
 Write-Output ($version+' '+$label+' '+$cycle+' '+$seconds.ToString('F4')+' '+$metric)
}

try{
 $app=New-Object -ComObject Excel.Application
 [uint32]$id=0;[void][NDMTestPairedOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 if($existing -contains [int]$id){throw 'Existing Excel refused'}
 $own=[int]$id;$ticks=(Get-Process -Id $own).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;Dataset=$Dataset;Cycles=$Cycles;SourcePayloadSHA256=(Get-FileHash $payload).Hash;StartedUTC=[DateTime]::UtcNow.ToString('o');Order='ABBA';Visible=$false;OSFileCache='Not evicted';Calculation=-4135}|ConvertTo-Json|Set-Content (Join-Path $out 'Own.json') -Encoding UTF8
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1;$app.ScreenUpdating=$false
 foreach($version in 'Before','After'){
  $book=$app.Workbooks.Open((Join-Path (Join-Path $out $version) ($version+'.xlsm')),0,$false);$books[$version]=$book;$app.Calculation=-4135
  if($version -eq 'After'){
   foreach($file in Get-ChildItem -LiteralPath (Join-Path $p 'Candidate') -File|Where-Object {$_.Extension -in '.cls','.bas'}){Test-ImportComponent $book $file}
  }
  $component=$book.VBProject.VBComponents.Add(1);$component.Name='modTestIndexedBaseline'
  $code=[IO.File]::ReadAllText((Join-Path $p 'modTestIndexedBaselineExtended.bas'),[Text.Encoding]::UTF8)
  $component.CodeModule.AddFromString(([regex]::Replace($code,'(?m)^Attribute VB_Name.*\r?\n','')))
  $component=$book.VBProject.VBComponents.Item('CCalculationSnapshot')
  $component.CodeModule.AddFromString([IO.File]::ReadAllText((Join-Path $p ('TestPreparedClone'+$version+'.bas.txt')),[Text.Encoding]::UTF8))
  $component=$book.VBProject.VBComponents.Item('modCalculationSnapshot')
  $component.CodeModule.AddFromString("`r`nPublic Function TestReadStateDetails() As String`r`nTestReadStateDetails = CStr(mReadDepth) & `"|`" & CStr(mReadSnapshot Is Nothing) & `"|`" & CStr(mReadWorkbook Is Nothing)`r`nEnd Function")
  Test-Instrument $book
  $app.VBE.ActiveVBProject=$book.VBProject;$app.VBE.CommandBars.FindControl(1,578).Execute()
  $datasetInfo=[string]$app.Run("'$($book.Name)'!modTestIndexedBaseline.TestUseSavedDataset")
  if(-not $datasetInfo.StartsWith('OK|')){throw $datasetInfo}
  $datasetInfo|Set-Content (Join-Path (Join-Path $out $version) 'Dataset.txt') -Encoding UTF8
 }
 # Прогрев исполняемых процедур отделён от измерений, новые индексы всё равно собираются свежему snapshot внутри Save.
 foreach($mode in 'File','Excel'){
  foreach($version in 'Before','After'){Test-Measure $version ('SavePrepared'+$mode) ('WarmupSave'+$mode) 0}
  for($cycle=1;$cycle -le $Cycles;$cycle++){
   foreach($phase in 'SavePrepared','First','Repeat','Switch','Restore','Update'){
    $action=$phase+$mode
    if($phase -in 'First','Repeat','Switch'){$action='Select'+$mode}
    foreach($version in 'Before','After','After','Before'){
     $case='PERF_01';$state='StrengthState';if($phase -eq 'Switch'){$case='PERF_02'}
     [void]$app.Run("'$($books[$version].Name)'!modTestIndexedBaseline.TestSelectState",$case,$state)
     Test-Measure $version $action ($phase+$mode) $cycle
    }
   }
  }
 }
 [ordered]@{Status='PAIRED_BENCHMARK_MEASURED';Dataset=$Dataset;Records=$records.Count;Cycles=$Cycles;NoSolver=$true;PreparedIndexPreparationIncluded=$true;ExcelFullRead='Seven technical tables plus four upper summaries';FullRawRangeCountersIncludeExtent=$true}|ConvertTo-Json|Set-Content (Join-Path $out 'Complete.json') -Encoding UTF8
}catch{
 $_.Exception.ToString()|Set-Content (Join-Path $out 'Error.txt') -Encoding UTF8
 throw
}finally{
 foreach($book in $books.Values){$book.Close($false);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)}
 $books=@{};$book=$null;$component=$null;$module=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit();$quit=$true;[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 [ordered]@{PID=$own;UTCStartTicks=[string]$ticks;QuitReturned=$quit;FinishedUTC=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Quit.json') -Encoding UTF8
}
