Attribute VB_Name = "modTestIndexedPrototype"
Option Explicit
' ==================== ДЛЯ ТЕСТОВ ====================
' Проверяет изолированный v6 на подлинном тяжёлом снимке без запуска решателя.
Private Declare PtrSafe Sub TestCopyBits Lib "kernel32" Alias "RtlMoveMemory" (ByRef target As Currency, ByRef source As Double, ByVal count As LongPtr)
Private mTestError As String, mTestChecks As Long, mTestStage As String
Private Declare PtrSafe Sub TestMoveMemory Lib "kernel32" Alias "RtlMoveMemory" (ByVal target As LongPtr, ByVal source As LongPtr, ByVal count As LongPtr)

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает все ячейки, включая восемь битовых байтов Double и UTF-16 строк.
Private Sub TestEqual(ByRef expected As Variant, ByRef actual As Variant, ByVal label As String)
    If UBound(expected, 1) <> UBound(actual, 1) Or UBound(expected, 2) <> UBound(actual, 2) Then Err.Raise 5, , label & " size"
    Dim row As Long, column As Long, a As Double, b As Double, bitsA As Currency, bitsB As Currency
    For row = 1 To UBound(expected, 1)
        For column = 1 To UBound(expected, 2)
            If VarType(expected(row, column)) <> VarType(actual(row, column)) Then Err.Raise 5, , label & " type " & CStr(row) & ":" & CStr(column)
            Select Case VarType(expected(row, column))
                Case vbDouble
                    a = CDbl(expected(row, column)): b = CDbl(actual(row, column)): TestCopyBits bitsA, a, 8: TestCopyBits bitsB, b, 8
                    If bitsA <> bitsB Then Err.Raise 5, , label & " IEEE " & CStr(row) & ":" & CStr(column)
                Case vbString
                    If StrComp(CStr(expected(row, column)), CStr(actual(row, column)), vbBinaryCompare) <> 0 Then Err.Raise 5, , label & " Unicode " & CStr(row) & ":" & CStr(column)
                Case Else
                    If expected(row, column) <> actual(row, column) Then Err.Raise 5, , label & " value " & CStr(row) & ":" & CStr(column)
            End Select
            mTestChecks = mTestChecks + 1
        Next column
    Next row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет полное восстановление и все фактические LC/State тяжёлого примера.
Public Function TestRunV6() As String
    On Error GoTo Failed
    Dim store As New CCalculationSnapshotStore, expected As CCalculationSnapshot, actual As CCalculationSnapshot
    Dim reader As CIndexedSnapshotFile, values As Variant, selected As Variant, key As Variant, states As Variant, row As Long
    mTestStage = "Load legacy": Set expected = store.LoadFile(ThisWorkbook)
    mTestStage = "Save v6": store.SaveFile ThisWorkbook, expected
    mTestStage = "Link v6": store.LinkFile ThisWorkbook
    mTestStage = "Elapsed v6": store.UpdateSavedElapsed ThisWorkbook, expected
    mTestStage = "Full restore v6": Set actual = store.LoadFile(ThisWorkbook)
    For Each key In expected.Keys
        values = expected.Table(CStr(key)): selected = actual.Table(CStr(key)): TestEqual values, selected, CStr(key)
    Next key
    Set actual = Nothing
    Set reader = New CIndexedSnapshotFile
    If Not reader.OpenRead(store.SnapshotPath(ThisWorkbook), store) Then Err.Raise 5, , "Expected v6"
    values = expected.SelectElementResults("", "", True): states = reader.SelectElementResults("", "", True): TestEqual values, states, "indexOnly"
    If reader.LoadedStateBlocks <> 0 Then Err.Raise 5, , "indexOnly loaded states"
    Dim bytesIndex As Double: bytesIndex = reader.BytesRead
    For row = 2 To UBound(states, 1)
        values = expected.SelectElementResults(CStr(states(row, 2)), CStr(states(row, 4)), False)
        selected = reader.SelectElementResults(CStr(states(row, 2)), CStr(states(row, 4)), False)
        TestEqual values, selected, CStr(states(row, 2)) & "/" & CStr(states(row, 4))
    Next row
    values = expected.SelectElementResults("missing", "missing", False): selected = reader.SelectElementResults("missing", "missing", False)
    TestEqual values, selected, "missing"
    Set reader = New CIndexedSnapshotFile
    If Not reader.OpenRead(store.SnapshotPath(ThisWorkbook), store) Then Err.Raise 5, , "Expected cold v6"
    selected = reader.SelectElementResults("perf_01", "strengthstate", False)
    values = expected.SelectElementResults("PERF_01", "StrengthState", False): TestEqual values, selected, "case-insensitive"
    TestRunV6 = "PASS|CellChecks=" & CStr(mTestChecks) & "|StatePairs=" & CStr(UBound(states, 1) - 1) & _
        "|IndexBytes=" & CStr(bytesIndex) & "|SelectedBytes=" & CStr(reader.BytesRead) & "|SelectedBlocks=" & CStr(reader.LoadedStateBlocks)
    Exit Function
Failed:
    mTestError = Err.Source & ": " & Err.Description: TestRunV6 = "ERROR|" & mTestError
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Печатает происхождение и фактические прямые/дуги тяжёлого сохранённого сечения.
Public Function TestHeavyDetails() As String
    On Error GoTo Failed
    TestStorage "File"
    Dim store As New CCalculationSnapshotStore, snapshot As CCalculationSnapshot, values As Variant, row As Long
    Set snapshot = store.LoadFile(ThisWorkbook)
    values = snapshot.Table("rngNDMSectionProperties")
    For row = 2 To UBound(values, 1)
        If CStr(values(row, 3)) = "Geometry.Source" Then TestHeavyDetails = TestHeavyDetails & "|Geometry.Source=" & CStr(values(row, 4))
    Next row
    values = snapshot.Table("rngNDMSectionGeometry")
    Dim concrete As Long, rebar As Long, arcs As Long, lines As Long, radius As Double
    For row = 2 To UBound(values, 1)
        If CStr(values(row, 3)) = "Concrete" Then concrete = concrete + 1 Else rebar = rebar + 1
    Next row
    values = snapshot.Table("rngNDMSectionContours")
    For row = 2 To UBound(values, 1)
        If CStr(values(row, 6)) = "CONTOUR_ARC" Then
            arcs = arcs + 1: radius = Sqr((CDbl(values(row, 7)) - CDbl(values(row, 11))) ^ 2 + (CDbl(values(row, 8)) - CDbl(values(row, 12))) ^ 2)
        ElseIf CStr(values(row, 6)) = "CONTOUR_LINE" Then
            lines = lines + 1
        End If
    Next row
    TestHeavyDetails = "Concrete=" & CStr(concrete) & "|Rebar=" & CStr(rebar) & TestHeavyDetails & "|Arcs=" & CStr(arcs) & "|Lines=" & CStr(lines) & "|LastRadius=" & CStr(radius)
    Exit Function
Failed:
    TestHeavyDetails = "ERROR|" & Err.Description
End Function

Public Function TestStageDetails() As String
TestStageDetails = mTestStage & "|" & mTestError
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет только выбор носителя в частной книге.
Private Sub TestStorage(ByVal mode As String)
    Dim target As Range, row As Long
    Set target = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = "Results.SnapshotStorage" Then target.Cells(row, 2).Value2 = mode: Exit Sub
    Next row
    Err.Raise 5, , "Storage test key missing"
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет адресный Excel по всем подлинным состояниям и штатное обновление схемы.
Public Function TestRunExcel() As String
    On Error GoTo Failed
    mTestStage = "Excel expected": TestStorage "File"
    Dim store As New CCalculationSnapshotStore, expected As CCalculationSnapshot, writer As New CNDMResultsWriter, summary As New CBatchResultWriter
    Set expected = store.LoadFile(ThisWorkbook)
    mTestStage = "Excel publish": writer.RestoreSnapshotBase ThisWorkbook, expected, False, True
    summary.RestoreSummary ThisWorkbook, expected, False
    TestStorage "Excel"
    Dim values As Variant, states As Variant, selected As Variant, row As Long, counters As String
    Call TestIndexedExcelReadCounters(True)
    values = expected.SelectElementResults("", "", True): states = ReadElementResultTable(ThisWorkbook, , , True): TestEqual values, states, "Excel indexOnly"
    counters = TestIndexedExcelReadCounters()
    If Split(counters, "|")(1) <> "0" Or Split(counters, "|")(2) <> "0" Then Err.Raise 5, , "Index-only bootstrapped or read detailed blocks"
    mTestStage = "Excel states"
    For row = 2 To UBound(states, 1)
        values = expected.SelectElementResults(CStr(states(row, 2)), CStr(states(row, 4)), False)
        BeginCalculationSnapshotRead ThisWorkbook
        selected = ReadElementResultTable(ThisWorkbook, CStr(states(row, 2)), CStr(states(row, 4)), False)
        EndCalculationSnapshotRead
        TestEqual values, selected, "Excel " & CStr(states(row, 2)) & "/" & CStr(states(row, 4))
    Next row
    mTestStage = "Excel missing"
    values = expected.SelectElementResults("missing", "missing", False): selected = ReadElementResultTable(ThisWorkbook, "missing", "missing", False): TestEqual values, selected, "Excel missing"
    Call TestIndexedExcelReadCounters(True)
    selected = ReadElementResultTable(ThisWorkbook, "perf_01", "strengthstate", False)
    values = expected.SelectElementResults("PERF_01", "StrengthState", False): TestEqual values, selected, "Excel case-insensitive"
    counters = TestIndexedExcelReadCounters()
    If Split(counters, "|")(1) <> "1" Or Split(counters, "|")(2) <> "0" Then Err.Raise 5, , "Selection did not use exactly one indexed block"
    Dim warning As String, hasWarning As Boolean
    mTestStage = "Excel update": UpdateSectionResultsForWorkbook ThisWorkbook, , warning, hasWarning
    If hasWarning Then Err.Raise 5, , warning
    If Not TestCalculationSnapshotReadReleased() Then Err.Raise 5, , "Excel scope leaked"
    TestRunExcel = "PASS|CellChecks=" & CStr(mTestChecks) & "|ExcelSelectedCounters=" & counters & "|StatePairs=" & CStr(UBound(states, 1) - 1)
    Exit Function
Failed:
    mTestError = Err.Source & ": " & Err.Description: TestRunExcel = "ERROR|" & mTestError
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет и меняет только имя частного тестового снимка.
Private Function TestSnapshotName(ByVal value As String) As String
    Dim target As Range, row As Long
    Set target = ThisWorkbook.Names("rngSystemSettings").RefersToRange
    For row = 1 To target.Rows.Count
        If CStr(target.Cells(row, 1).Value2) = "Results.SnapshotName" Then
            TestSnapshotName = CStr(target.Cells(row, 2).Value2)
            If Len(value) > 0 Then target.Cells(row, 2).Value2 = value
            Exit Function
        End If
    Next row
    Err.Raise 5, , "Snapshot-name test key missing"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подставляет только синтетическую поэлементную таблицу к неизменённым общим таблицам.
Private Function TestEdgeSnapshot(ByVal original As CCalculationSnapshot, ByRef elements As Variant) As CCalculationSnapshot
    Dim result As New CCalculationSnapshot, key As Variant, values As Variant
    result.RunID = original.RunID: result.ElapsedSeconds = original.ElapsedSeconds
    For Each key In original.Keys
        If CStr(key) = "rngNDMElementResults" Then values = elements Else values = original.Table(CStr(key))
        result.AddTable CStr(key), values
    Next key
    result.Validate
    Set TestEdgeSnapshot = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет несмежные участки, разные профили, разный состав элементов и смешанные значения.
Public Function TestRunEdgeCases() As String
    On Error GoTo Failed
    mTestStage = "Edges prepare": TestStorage "File"
    Dim store As New CCalculationSnapshotStore, original As CCalculationSnapshot, fixture As CCalculationSnapshot, loaded As CCalculationSnapshot
    Set original = store.LoadFile(ThisWorkbook)
    Dim source As Variant: source = original.SelectElementResults("PERF_01", "StrengthState", False)
    Dim data(1 To 14, 1 To 9) As Variant, row As Long, column As Long, caseA As String
    For row = 1 To 14
        For column = 1 To 9: data(row, column) = source(row, column): Next column
    Next row
    caseA = "ЛК:" & Chr$(30) & ChrW$(&H3B1)
    For row = 2 To 14
        data(row, 2) = caseA: data(row, 3) = "PR1": data(row, 4) = "StrengthState"
        If row >= 5 And row <= 6 Then data(row, 2) = "B": data(row, 3) = "PR2": data(row, 4) = "CrackedState"
        If row >= 7 And row <= 9 Then data(row, 3) = "PR2"
        If row >= 10 And row <= 11 Then data(row, 2) = LCase$(caseA)
        If row >= 12 Then data(row, 2) = "Сочетание 中文" & vbCrLf & "строка": data(row, 3) = "PR2": data(row, 4) = "Состояние σ"
    Next row
    data(5, 5) = source(7, 5): data(6, 5) = source(5, 5)
    data(12, 5) = "ID" & ChrW$(0) & "漢字": data(12, 6) = "Материал" & vbCrLf & "μ"
    data(12, 7) = Empty: data(13, 7) = True
    Dim negativeZero As Double, high As Long: high = &H80000000
    TestMoveMemory VarPtr(negativeZero) + 4, VarPtr(high), 4
    data(14, 8) = negativeZero
    Dim values As Variant: values = data
    Set fixture = TestEdgeSnapshot(original, values)
    Dim previousName As String: previousName = TestSnapshotName("IndexedEdges")
    mTestStage = "Edges file": store.SaveFile ThisWorkbook, fixture
    Set loaded = store.LoadFile(ThisWorkbook)
    Dim actual As Variant, expected As Variant
    expected = fixture.Table("rngNDMElementResults"): actual = loaded.Table("rngNDMElementResults"): TestEqual expected, actual, "Edges full IEEE and NUL"
    Dim reader As New CIndexedSnapshotFile
    If Not reader.OpenRead(store.SnapshotPath(ThisWorkbook), store) Then Err.Raise 5, , "Edges expected v6"
    expected = fixture.SelectElementResults(caseA, "StrengthState", False): actual = reader.SelectElementResults(caseA, "StrengthState", False): TestEqual expected, actual, "Edges disjoint"
    If UBound(actual, 1) <> 9 Then Err.Raise 5, , "Lost disjoint spans"
    expected = fixture.SelectElementResults(caseA, "StrengthState", False, "PR2"): actual = reader.SelectElementResults(caseA, "StrengthState", False, "PR2"): TestEqual expected, actual, "Edges profile"
    If UBound(actual, 1) <> 4 Then Err.Raise 5, , "Profile selection lost or mixed rows"
    expected = fixture.SelectElementResults("", "", True): actual = reader.SelectElementResults("", "", True): TestEqual expected, actual, "Edges indexOnly"
    Set reader = Nothing: Set loaded = Nothing
    ' Листовая серия использует обычный Unicode-идентификатор и +0; специальные байты NUL и -0 проверены файловой серией.
    data(12, 5) = "ID_漢字": data(14, 8) = 0#: values = data
    Set fixture = TestEdgeSnapshot(original, values)
    Dim writer As New CNDMResultsWriter
    mTestStage = "Edges Excel": writer.RestoreSnapshotBase ThisWorkbook, fixture, False, True: TestStorage "Excel"
    expected = fixture.Table("rngNDMElementResults"): actual = ReadElementResultTable(ThisWorkbook): TestEqual expected, actual, "Edges Excel all"
    expected = fixture.SelectElementResults(caseA, "StrengthState", False): actual = ReadElementResultTable(ThisWorkbook, caseA, "StrengthState", False): TestEqual expected, actual, "Edges Excel disjoint"
    expected = fixture.SelectElementResults(caseA, "StrengthState", False, "PR2"): actual = ReadElementResultTable(ThisWorkbook, caseA, "StrengthState", False, "PR2"): TestEqual expected, actual, "Edges Excel profile"
    Call TestSnapshotName(previousName)
    TestStorage "File"
    TestRunEdgeCases = "PASS|DisjointSpans=3|ProfileRows=3|VariableElementCounts=true|FileNUL=true|FileNegativeZero=true|MixedTypes=true|CellChecks=" & CStr(mTestChecks)
    Exit Function
Failed:
    mTestError = Err.Source & ": " & Err.Description
    If Len(previousName) > 0 Then Call TestSnapshotName(previousName)
    TestRunEdgeCases = "ERROR|" & mTestError
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет реальную защиту после сохранения/повторного открытия без UserInterfaceOnly.
Public Function TestRunReopenProtection() As String
    On Error GoTo Failed
    mTestStage = "Reopen expected": TestStorage "File"
    Dim store As New CCalculationSnapshotStore, snapshot As CCalculationSnapshot
    Set snapshot = store.LoadFile(ThisWorkbook): TestStorage "Excel"
    Dim expected As Variant, actual As Variant
    expected = snapshot.SelectElementResults("PERF_01", "StrengthState", False)
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual, "Reopen selected"
    Dim anchor As Range, index As Range, sheet As Worksheet
    Set anchor = ThisWorkbook.Names("rngNDMElementResults").RefersToRange
    Set index = ThisWorkbook.Names("rngNDMElementResultIndex").RefersToRange: Set sheet = anchor.Worksheet
    If Not sheet.ProtectContents Or sheet.ProtectionMode Then Err.Raise 5, , "Saved protection not restored as expected"
    If Not CBool(anchor.Resize(snapshot.TableRowCount("rngNDMElementResults"), 9).Locked) Then Err.Raise 5, , "Inner result cells not locked"
    Dim rejected As Long, number As Long
    On Error Resume Next
    anchor.Offset(3, 0).EntireRow.Insert: number = Err.Number: Err.Clear
    On Error GoTo Failed
    If number = 0 Then Err.Raise 5, , "Protected insertion accepted" Else rejected = rejected + 1
    On Error Resume Next
    anchor.Offset(3, 0).Resize(10, 9).Sort Key1:=anchor.Offset(3, 6), Order1:=xlDescending, Header:=xlNo
    number = Err.Number: Err.Clear
    On Error GoTo Failed
    If number = 0 Then Err.Raise 5, , "Protected sorting accepted" Else rejected = rejected + 1
    Dim old As Variant: old = index.Offset(-10, 16).Value2
    index.Offset(-10, 16).Value2 = "Доступно": index.Offset(-10, 16).Value2 = old
    ' Привилегированная имитация повреждения меняет внутренние строки разных состояний, оставляя концы блоков прежними.
    sheet.Unprotect "NDM_ResultIndex_v1"
    Dim first As Long, second As Long, a As Variant, b As Variant
    first = CLng(index.Offset(2, 4).Value2): second = CLng(index.Offset(3, 4).Value2)
    a = anchor.Offset(first, 0).Resize(1, 9).Value2: b = anchor.Offset(second, 0).Resize(1, 9).Value2
    anchor.Offset(first, 0).Resize(1, 9).Value2 = b: anchor.Offset(second, 0).Resize(1, 9).Value2 = a
    sheet.Protect Password:="NDM_ResultIndex_v1", DrawingObjects:=False, Contents:=True, Scenarios:=False
    On Error Resume Next
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): number = Err.Number: Err.Clear
    On Error GoTo Failed
    If number = 0 Then Err.Raise 5, , "Interior foreign-state swap was accepted" Else rejected = rejected + 1
    sheet.Unprotect "NDM_ResultIndex_v1"
    anchor.Offset(first, 0).Resize(1, 9).Value2 = a: anchor.Offset(second, 0).Resize(1, 9).Value2 = b
    sheet.Protect Password:="NDM_ResultIndex_v1", DrawingObjects:=False, Contents:=True, Scenarios:=False
    actual = ReadElementResultTable(ThisWorkbook, "PERF_01", "StrengthState", False): TestEqual expected, actual, "Restored after swap"
    TestRunReopenProtection = "PASS|RejectedOperations=" & CStr(rejected) & "|OtherCellsEditable=true|InnerCellsLocked=true|CellChecks=" & CStr(mTestChecks)
    Exit Function
Failed:
    mTestError = Err.Source & ": " & Err.Description: TestRunReopenProtection = "ERROR|" & mTestError
End Function
