﻿# ==================== ДЛЯ ТЕСТОВ ====================
# Свежие PID/ticks всех собственных baseline/prototype Excel; чужие процессы не закрывает.
param([string]$AllowedRunningDirectory='')
$ErrorActionPreference='Stop'
$records=@()
foreach($d in Get-ChildItem -LiteralPath $PSScriptRoot -Directory){
 $f=Join-Path $d.FullName 'Own.json'
 if(-not(Test-Path -LiteralPath $f)){continue}
 $own=Get-Content -LiteralPath $f -Raw|ConvertFrom-Json
 $state='Unknown';$actualTicks='';$exe='';$creation=''
 $cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$own.PID)
 if(-not $cim){$state='ConfirmedNotFound'}else{
  $exe=[string]$cim.Name;$creation=[string]$cim.CreationDate
  if($exe -ine 'EXCEL.EXE'){$state='PIDReusedDifferentExecutable'}else{
   $process=Get-Process -Id ([int]$own.PID)
   $actualTicks=[string]$process.StartTime.ToUniversalTime().Ticks
   if($actualTicks -eq [string]$own.UTCStartTicks){$state='ExactAlive'}else{$state='PIDReusedDifferentStart'}
  }
 }
 $records+=,[ordered]@{Directory=$d.Name;PID=[int]$own.PID;ExpectedUTCStartTicks=[string]$own.UTCStartTicks;State=$state;ActualUTCStartTicks=$actualTicks;CIMExecutable=$exe;CIMCreation=$creation;AllowedRunning=($d.Name -eq $AllowedRunningDirectory)}
}
$bad=@($records|Where-Object {$_.State -eq 'Unknown' -or ($_.State -eq 'ExactAlive' -and -not $_.AllowedRunning)})
[ordered]@{Status=$(if($bad.Count){'REVIEW_REQUIRED'}else{'OWN_IDENTITIES_REVIEWED'});ObservedUTC=[DateTime]::UtcNow.ToString('o');AllowedRunningDirectory=$AllowedRunningDirectory;Records=$records}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot 'OwnClosuresLatest01.json') -Encoding UTF8
$records|ConvertTo-Json -Depth 4
if($bad.Count){throw 'Some historical own identities remain alive or unknown; inspect before another native launch'}
