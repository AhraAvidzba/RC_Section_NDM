"""ДЛЯ ТЕСТОВ: переводит реальные потребители на явный адресный источник в private candidate."""
from pathlib import Path
import re
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM');P=Path(__file__).parent/'Candidate'
def one(t,a,b):
 assert t.count(a)==1,(a,t.count(a));return t.replace(a,b)
for name in ['modSectionSnapshot.bas','CSectionPlotDataReader.cls','modAutoCADStressExport.bas','CNDMResultsWriter.cls']:
 t=(R/'src/Excel'/name).read_text(encoding='utf-8-sig')
 lines=[]
 for line in t.splitlines():
  if 'CurrentCalculationSnapshot(' in line:
   line=line.replace('As CCalculationSnapshot','As CResultReadSource').replace('CurrentCalculationSnapshot(', 'CurrentResultSource(')
  lines.append(line)
 t='\n'.join(lines)+'\n'
 if name=='modAutoCADStressExport.bas':t=t.replace('data = ReadPhysicalResultTable(workbook, "rngNDMElementResults")','data = ReadElementResultTable(workbook, , , True)')
 if name=='CNDMResultsWriter.cls':
  signature='Public Sub RestoreSnapshotBase(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot, Optional ByVal fullFormatting As Boolean = True, Optional ByVal includeElements As Boolean = True)'
  t=one(t,signature,'''Public Sub RestoreSnapshotBase(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot, Optional ByVal fullFormatting As Boolean = True, Optional ByVal includeElements As Boolean = True)
    If snapshot Is Nothing Then Err.Raise 5, , "Снимок для восстановления не передан."
    snapshot.Validate
    RestoreBaseTables workbook, snapshot, fullFormatting, includeElements
End Sub

' Восстанавливает общие таблицы File; адресный источник не выдаётся за полный снимок.
Public Sub RestoreIndexedBase(ByVal workbook As Object, ByVal source As CResultReadSource, ByVal fullFormatting As Boolean)
    source.ValidateForDisplay
    RestoreBaseTables workbook, source, fullFormatting, False
End Sub

' Общее блочное оформление вызывается только после проверки явно типизированного источника.
Private Sub RestoreBaseTables(ByVal workbook As Object, ByVal snapshot As Object, ByVal fullFormatting As Boolean, ByVal includeElements As Boolean)''')
  t=t.replace('    snapshot.Validate \' Публичный прямой вызов также отклоняет потерю обязательной границы до очистки первой ячейки Results.','')
 (P/name).write_text(t,encoding='utf8')
for name in ['CBatchResultWriter.cls','CStrengthSummaryWriter.cls','CCrackSummaryWriter.cls','CStabilitySummaryWriter.cls']:
 t=(R/'src/Excel'/name).read_text(encoding='utf-8-sig')
 signature='Public Sub RestoreSummary(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot, Optional ByVal fullFormatting As Boolean = True)'
 t=one(t,signature,'''Public Sub RestoreSummary(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot, Optional ByVal fullFormatting As Boolean = True)
    snapshot.Validate
    RestoreSummaryTables workbook, snapshot, fullFormatting
End Sub

' Восстанавливает только готовые общие сводки из проверенного адресного источника.
Public Sub RestoreIndexedSummary(ByVal workbook As Object, ByVal source As CResultReadSource, ByVal fullFormatting As Boolean)
    source.ValidateForDisplay
    RestoreSummaryTables workbook, source, fullFormatting
End Sub

' Записывает те же массивы и оформление для двух явно проверенных входных контрактов.
Private Sub RestoreSummaryTables(ByVal workbook As Object, ByVal snapshot As Object, ByVal fullFormatting As Boolean)''')
 if name=='CBatchResultWriter.cls':
  t=t.replace('Private Function SummaryForDisplay(ByVal snapshot As CCalculationSnapshot)', 'Private Function SummaryForDisplay(ByVal snapshot As Object)')
  t=t.replace('Private Function SavedSummaryUnit(ByVal snapshot As CCalculationSnapshot,', 'Private Function SavedSummaryUnit(ByVal snapshot As Object,')
  for writer in ['strength','cracks','stability']:
   needle=f'    {writer}.RestoreSummary workbook, snapshot, fullFormatting'
   t=one(t,needle,f'''    If TypeOf snapshot Is CResultReadSource Then
        {writer}.RestoreIndexedSummary workbook, snapshot, fullFormatting
    Else
        {writer}.RestoreSummary workbook, snapshot, fullFormatting
    End If''')
 (P/name).write_text(t,encoding='utf8')
t=(R/'src/Excel/modCalculationSnapshot.bas').read_text(encoding='utf-8-sig')
t=one(t,'Private mReadSnapshot As CCalculationSnapshot','''Private mReadView As CResultReadSource ' Адресный источник существует только внутри одной операции.
Private mReadViewResolved As Boolean
Private mReadSnapshot As CCalculationSnapshot''')
t=one(t,'    If mReadDepth = 0 Then\n        If Not snapshot Is Nothing Then snapshot.Validate','''    If mReadDepth = 0 Then
        Set mReadView = Nothing: mReadViewResolved = False
        If Not snapshot Is Nothing Then snapshot.Validate''')
t=one(t,'        Set mReadSnapshot = snapshot\n        mReadSourceResolved = True','        Set mReadSnapshot = snapshot: Set mReadView = Nothing: mReadViewResolved = False\n        mReadSourceResolved = True')
t=one(t,'    If mReadDepth = 0 Then Set mReadSnapshot = Nothing: Set mReadWorkbook = Nothing: mReadSourceResolved = False','''    If mReadDepth = 0 Then
        Set mReadSnapshot = Nothing: Set mReadWorkbook = Nothing: mReadSourceResolved = False
        Set mReadView = Nothing: mReadViewResolved = False
    End If''')
a=t.index('Public Function CurrentCalculationSnapshot(');b=t.index("' Выводит готовый расчёт",a)
t=t[:a]+'''Public Function CurrentCalculationSnapshot(ByVal workbook As Object) As CCalculationSnapshot
    Dim source As CResultReadSource: Set source = CurrentResultSource(workbook)
    If Not source Is Nothing Then Set CurrentCalculationSnapshot = source.LoadAll
End Function

' Возвращает адресный File либо готовый снимок текущего вывода; Excel без prepared читает лист.
Public Function CurrentResultSource(ByVal workbook As Object) As CResultReadSource
    If workbook Is mReadWorkbook Then
        If mReadViewResolved Then Set CurrentResultSource = mReadView: Exit Function
    End If
    Dim source As CResultReadSource, store As New CCalculationSnapshotStore
    If workbook Is mReadWorkbook And Not mReadSnapshot Is Nothing Then
        Set source = New CResultReadSource: source.UsePrepared mReadSnapshot
    ElseIf store.StorageMode(workbook) = "File" Then
        Set source = New CResultReadSource: source.OpenWorkbook workbook, store
    End If
    If mReadDepth > 0 And workbook Is mReadWorkbook Then Set mReadView = source: mReadViewResolved = True
    Set CurrentResultSource = source
End Function

'''+t[b:]
t=one(t,'            Set snapshot = store.LoadFile(workbook)','''            UpdateIndexedResultsForWorkbook workbook, plotWarning, plotHasWarning
            guard.Restore True
            CompleteWorkbookDrawing workbook
            Exit Sub''')
t=t.replace('Private Sub ValidateRestoredSnapshotLayout(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot,','Private Sub ValidateRestoredSnapshotLayout(ByVal workbook As Object, ByVal snapshot As Object,')
t=t.replace('Private Function RestoredSnapshotMandatoryRowsFit(ByVal workbook As Object, ByVal snapshot As CCalculationSnapshot)','Private Function RestoredSnapshotMandatoryRowsFit(ByVal workbook As Object, ByVal snapshot As Object)')
t=t.replace('mReadWorkbook Is Nothing)','mReadWorkbook Is Nothing And mReadView Is Nothing)')
t+='''
' Ручное обновление File восстанавливает общие таблицы и выбранную схему без всех НДС.
' Источник сначала проверяет обязательные общие блоки, затем допускает изменение Results.
Private Sub UpdateIndexedResultsForWorkbook(ByVal workbook As Object, ByRef plotWarning As String, ByRef plotHasWarning As Boolean)
    Dim entered As Boolean
    On Error GoTo Failed
    BeginCalculationSnapshotRead workbook: entered = True
    Dim source As CResultReadSource: Set source = CurrentResultSource(workbook)
    source.ValidateForDisplay
    ValidateRestoredSnapshotLayout workbook, source, False
    Dim writer As New CNDMResultsWriter, summary As New CBatchResultWriter, store As New CCalculationSnapshotStore
    Dim settings As New CSystemSettingsReader: settings.LoadFromWorkbook workbook
    Dim fullFormatting As Boolean: fullFormatting = settings.GetRequiredBoolean("General.ReformatResultsEnabled")
    writer.RestoreIndexedBase workbook, source, fullFormatting
    If source.IsGeometryPreview Then summary.ClearSummary workbook, fullFormatting Else summary.RestoreIndexedSummary workbook, source, fullFormatting
    store.LinkFile workbook
    If source.IsGeometryPreview Then UpdateSectionGeometryPreviewForWorkbook workbook, plotWarning Else UpdateSectionPlotForWorkbook workbook, False, plotWarning
    plotHasWarning = (Len(plotWarning) > 0)
    EndCalculationSnapshotRead
    entered = False
    Exit Sub
Failed:
    Dim number As Long, reason As String, origin As String
    number = Err.Number: reason = Err.Description: origin = Err.Source
    If entered Then EndCalculationSnapshotRead
    Err.Raise number, origin, reason
End Sub
'''
(P/'modCalculationSnapshot.bas').write_text(t,encoding='utf8')
t=(P/'CCalculationSnapshotStore.cls').read_text(encoding='utf8').replace('Private Function SelectedReadPath(', 'Friend Function SelectedReadPath(')
(P/'CCalculationSnapshotStore.cls').write_text(t,encoding='utf8')
print('Prepared isolated real File consumers; Excel index still pending')
