"""ДЛЯ ТЕСТОВ: публикует принятый код/справку при точной сохранности пользовательского расчёта."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parent
repo=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
evidence=repo/'docs/regression/IndexedResults_2026-11-01_Run01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def read(path):return json.loads((root/path).read_text(encoding='utf-8-sig'))
assert read('AllOwnClosures24.json')['Status']=='ALL_OWN_TERMINAL'
assert (datetime.now(timezone.utc)-datetime.fromisoformat(read('AllOwnClosures24.json')['ObservedUTC'].replace('Z','+00:00'))).total_seconds()<300
assert len(read('AllOwnClosures24.json')['Processes'])==40
assert read('CurrentBookReview23.json')['Status']=='PASS_CURRENT_DATA_AND_SOURCE_NATIVE'
assert read('CleanBookReview26.json')['Status']=='PASS'
assert read('Directed19_Attempt3/Complete.json')['Status']=='PASS_AFFECTED_SNAPSHOT_VIEWS_NO_YES'
assert read('Integrity12_Attempt2/Complete.json')['Status']=='PASS_NATIVE_CORRUPTION_COMPATIBILITY_ATOMIC_SAVE_AS'
assert (root/'Lifecycle17_Attempt2/Result.txt').read_text(encoding='utf-8-sig').startswith('PASS|')
for item in read('Integrity12_Attempt2/Probes.json'):
 assert item['Result'].startswith('PASS|')==item['ExpectedPass'],item
totals={
 'RunPreparedSnapshotReuseTests':69,'RunGeometryPreviewStorageTests':62,
 'RunConcreteGeometrySnapshotTests':123,'RunSnapshotOutputPolicyTests':48,
 'RunElementGeometryViewTests':82,'RunCalculationSnapshotTests':992}
primary=[]
for mode in ('No','Yes'):
 for name,expected in totals.items():
  path=root/f'Directed19_Attempt3/{mode}/{name}.txt';text=path.read_text(encoding='utf-8-sig')
  assert not re.search(r'^FAIL',text,re.M),path
  match=re.search(r'TOTAL[^\r\n]*passed=(\d+); failed=(\d+)',text)
  assert match and tuple(map(int,match.groups()))==(expected,0),(path,match.groups() if match else None)
  primary.append({'Path':str(path.relative_to(root)).replace('\\','/'),'Bytes':path.stat().st_size,'SHA256':sha(path),'Passed':expected,'Failed':0,'FullyRead':True})
for name in ('Result','EdgeResult','ExcelResult','ReopenResult'):
 assert (root/f'Prototype11/{name}.txt').read_text(encoding='utf-8-sig').startswith('PASS|')
book=root/'Current26/RC_Section_NDM.xlsm';code=root/'Current26/VBA_All_Code.txt'
clean=evidence/'CleanBuild/RC_Section_NDM.xlsm';cleanCode=root/'CleanNative26/VBA_All_Code.txt'
assert sha(book)==read('Current26/ReadOnly/Native.json')['WorkbookSHA256']==read('CurrentCalculationMode26.json')['WorkbookSHA256']
assert sha(clean)==read('CleanBookReview26.json')['WorkbookSHA256']==read('CleanNative26/Native.json')['WorkbookSHA256']
for file in (book,clean):
 with ZipFile(file) as z:
  w=ET.fromstring(z.read('xl/workbook.xml'));ns='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
  assert not any(n.get('name')=='Print_Area' for n in w.find(ns+'definedNames'))
core=subprocess.check_output(['git','diff','--name-only','--','src/Geometry','src/Section','src/Solver','src/Strength','src/Crack','src/Stability','src/Materials','src/Batch'],cwd=repo,text=True)
assert not core.strip(),core
target=repo/'workbook/output/RC_Section_NDM.xlsm';targetCode=repo/'workbook/output/VBA_All_Code.txt'
assert sha(target)=='A5C7E6B7E6105E9107C260DF888B7C77FE15386080DD8AD4B235B9CDE1AED540','User workbook changed after the accepted baseline'
assert sha(targetCode)=='6DC9E09AD869D482B4675BE63897202A10CFA4470B5AFAB59B8B860BB276D2A8'
backup=root/'BeforePublication27';assert not backup.exists();backup.mkdir()
shutil.copy2(target,backup/target.name);shutil.copy2(targetCode,backup/targetCode.name)
pending=target.with_name(target.name+'.indexed27.pending');pendingCode=targetCode.with_name(targetCode.name+'.indexed27.pending')
assert not pending.exists() and not pendingCode.exists()
shutil.copy2(book,pending);shutil.copy2(code,pendingCode)
assert sha(pending)==sha(book) and sha(pendingCode)==sha(code)
os.replace(pending,target);os.replace(pendingCode,targetCode)
assert sha(target)==sha(book) and sha(targetCode)==sha(code)
receipt={'Status':'ACCEPTED_CURRENT_BOOK_AND_ALLCODE_PUBLISHED','WorkbookSHA256':sha(target),'AllCodeSHA256':sha(targetCode),'BeforeWorkbookSHA256':sha(backup/target.name),'UserDataCellsPreserved':46733,'PicturesByteIdentical':6,'CalculationRun':False,'SourceComponents':181,'DocumentComponents':6,'OwnIdentitiesTerminal':40,'CleanPublicWorkbookSHA256':sha(clean),'CleanPublicAllCodeSHA256':sha(cleanCode),'FullAcceptanceClaim':False,'PublishedUTC':datetime.now(timezone.utc).isoformat()}
(root/'Publication27.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'TerminalPrimaryReview27.json').write_text(json.dumps({'Status':'PASS_ALL_12_TARGETED_PRIMARY_FULLY_READ','Primary':primary,'FullAcceptanceClaim':False},ensure_ascii=False,indent=2),encoding='utf-8')

# Архив не содержит пользовательских XLSM/NDM, только исходники измерений и доказательства.
names=['BeforeManifest.json','UserRequirements.txt','PairedBenchmarkSummary18.json','PhaseSummary24.json','MeasuredCandidate18.zip',
 'BaselineMeasured01.json','HeavySavedInventory01.json','Integration20.json','Directed19TestChanges.json','TerminalPrimaryReview27.json',
 'Integrity12_Attempt2/Complete.json','Integrity12_Attempt2/Probes.json','Integrity12_Attempt2/Bounds.txt',
 'Lifecycle17_Attempt1/Result.txt','Lifecycle17_Attempt2/Result.txt','Directed19_Attempt3/Complete.json','Directed19_Attempt3/Run.json',
 'CurrentBookReview23.json','CurrentCalculationMode26.json','CleanBookReview26.json','Current26/ReadOnly/Native.json','CleanNative26/Native.json',
 'AllOwnClosures24.json','Publication27.json','Prototype8/IdleObservation27A.json','Prototype8/IdleObservation27B.json','Prototype8/OwnClosure27.json',
 'Prototype7/IdleCompletedOwnBeforeClose.json']
for dataset in ('Light','Heavy'):
 names.extend([f'Paired16_{dataset}_Attempt1/Complete.json',f'Paired16_{dataset}_Attempt1/Measurements.json'])
for attempt in (10,11):
 for name in ('Result','EdgeResult','ExcelResult','ReopenResult','HeavyDetails'): names.append(f'Prototype{attempt}/{name}.txt')
names.extend(item['Path'] for item in primary)
names.extend(['Phases21_Heavy_Attempt3/Measurements.json','Phases21_Heavy_Attempt3/Complete.json',
 'Directed19_Attempt1/No/RunElementGeometryViewTests.txt','Directed19_Attempt2/No/RunCalculationSnapshotTests.txt',
 'Current22_Attempt1/Error.txt','Current22_Attempt2/Error.txt'])
archive=evidence/'ReviewedIndexedEvidence.zip';assert not archive.exists()
manifest=[]
with ZipFile(archive,'w',compression=ZIP_DEFLATED) as z:
 for name in names:
  path=root/name
  if not path.exists():continue
  z.write(path,name);manifest.append({'File':name,'Bytes':path.stat().st_size,'SHA256':sha(path)})
 for path in sorted(root.glob('Test*.py'))+sorted(root.glob('Test*.ps1'))+sorted(root.glob('modTest*.bas')):
  z.write(path,'NativeTools/'+path.name);manifest.append({'File':'NativeTools/'+path.name,'Bytes':path.stat().st_size,'SHA256':sha(path)})
 for folder in ('Candidate','CandidateTests'):
  for path in sorted((root/folder).iterdir()):
   z.write(path,folder+'/'+path.name);manifest.append({'File':folder+'/'+path.name,'Bytes':path.stat().st_size,'SHA256':sha(path)})
with ZipFile(archive) as z:
 for item in manifest:assert hashlib.sha256(z.read(item['File'])).hexdigest().upper()==item['SHA256']
(evidence/'EvidenceManifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ('PairedBenchmarkSummary18.json','PhaseSummary24.json','TerminalPrimaryReview27.json','CurrentBookReview23.json','CleanBookReview26.json','Publication27.json','AllOwnClosures24.json'):
 shutil.copy2(root/name,evidence/name)
processed=dict(receipt,Status='PASS_TARGETED_INDEXED_FILE_EXCEL_BOOKS_PUBLISHED',ArchiveSHA256=sha(archive),ArchiveFiles=len(manifest),PushPending=True)
(evidence/'Processed.json').write_text(json.dumps(processed,ensure_ascii=False,indent=2),encoding='utf-8')
report=repo/'docs/reports/IndexedResults_2026-11-01.md';text=report.read_text(encoding='utf-8')
text=text.replace('Подготовка конечных книг и их публикация ещё проверяются.','Конечные книги нативно сохранены, повторно открыты и проверены; основная книга обновлена с резервом.')
text=text.replace('Публикация книги, сохранность пользовательских ячеек, исходники/экспорт и выход всех собственных процессов — ожидают конечной проверки. Исходный расчёт и резервы остаются локально; в Git предназначен чистый шаблон.',f'''Основная книга опубликована с сохранением 46 733 заполненных ячеек/формул, шести исходных иллюстраций и исходного автоматического режима пересчёта. Новый индекс содержит пять фактически доступных пар текущего пользовательского расчёта. Совпали все 181 исходный компонент и 6 модулей документов; VBA_All_Code.txt экспортирован из повторно открытой книги. Чистый шаблон собран отдельно, без нагрузок и результатов, проверен тем же 187-компонентным контролем; именно он предназначен для GitHub. Рабочая локальная книга сохраняет пользовательский расчёт.

SHA основной книги: `{sha(book)}`. SHA чистого шаблона: `{sha(clean)}`. Резерв основной книги и экспорта: `BeforePublication27` в каталоге доказательств этой беседы. [Компактные доказательства](../regression/IndexedResults_2026-11-01_Run01/Processed.json).

Все 40 собственных идентичностей Excel заново подтверждены терминальными. Два скрытых экземпляра Prototype7/8 остались после возвращённого Quit: их точные PID/время старта и сохранённые отчёты проверены, простой подтверждён до адресного завершения. Пользовательские Excel/AutoCAD не закрывались.

При конечной сверке исправлены только три тестовых комментария с символами, не сохраняемыми VBE в системной кодировке; вместо них использованы русские слова/ASCII-запись. Нормализация сверки учитывает нативную научную запись крупного целого Double без изменения формулы. Встроенные имена областей печати восстановлены после локализованного COM-save; сборщик делает это при следующих сборках. Порядок XML-элементов mergeCells изменился при Save, сами объединённые диапазоны совпали.

Ветка: `codex/ndm-indexed-results`; слияние в main требует согласования результата. Полный ON/OFF+Focused для этой задачи не запускался.''')
report.write_text(text,encoding='utf-8')
progress=repo/'docs/geometry_refactor/PROGRESS.md';text=progress.read_text(encoding='utf-8-sig');header,tail=text.split('\n',1)
entry='''

## 01.11.2026 — Адресные результаты File/Excel и нормативная справка

NDMSNP06 сохраняет независимые состояния с каталогом и потоковыми SHA; Excel использует один защищённый rngNDMElementResultIndex справа от аннотаций. Схема/экспорт не загружают весь расчёт; prepared-данные переиспользуются в текущем scope. На сохранённом круге 1232+8/30 первое чтение ускорилось в 24/31 раз, штатное обновление — в 1,9/1,8 раза для File/Excel; запись не замедлилась. Полное восстановление File медленнее и описано как ограничение. 12 адресных No/Yes наборов, все 92 состояния, повреждения/Save As/reopen/жизненный цикл приняты. Пользовательский расчёт/6 PNG/46 733 ячейки сохранены; чистый шаблон проверен отдельно, 181+6 компонентов, все 40 own терминальны. Полный ON/OFF+Focused не заявляется. [Отчёт](../reports/IndexedResults_2026-11-01.md). Формулы и ссылки всей справки: [отдельный отчёт](../reports/HelpNormativeFormulas_2026-11-01.md).
'''
progress.write_text(header+entry+'\n'+tail,encoding='utf-8')
helpReport=repo/'docs/reports/HelpNormativeFormulas_2026-11-01.md'
with helpReport.open('a',encoding='utf-8') as f:f.write('\nПродолжение той же задачи — адресное хранение File/Excel, конечные книги и замеры на лёгком и тяжёлом примерах: [отчёт](IndexedResults_2026-11-01.md). Исторический Processed справки фиксирует состояние на момент её отдельной публикации.\n')
validation=repo/'docs/ValidationPlan.md'
with validation.open('a',encoding='utf-8') as f:f.write('''

## Адресное хранение результатов

После изменений IO выполнять RunCalculationSnapshotTests, RunPreparedSnapshotReuseTests, RunGeometryPreviewStorageTests, RunConcreteGeometrySnapshotTests, RunSnapshotOutputPolicyTests и RunElementGeometryViewTests на частных книгах No/Yes. Перед каждым набором явно выбирать Excel; File-сценарии задают имя своего снимка сами. Для NDMSNP06 отдельно проверять выбранный/непрочитанный повреждённый блок, каталог, VerifyFile, v4/v5 и .ndms, атомарную запись и Save As. Excel: Invalid после отказа, очистка, одноразовый bootstrap, защита сортировки/вставки/удаления и перенос таблицы целиком. Пример и 19 нативных проб, 12 первичных журналов, ABBA-замеры 292/20 и сохранённого 1240/30: docs/regression/IndexedResults_2026-11-01_Run01/ReviewedIndexedEvidence.zip. Проверки адресные и не заменяют общий ON/OFF+Focused.
''')
print(json.dumps(receipt,ensure_ascii=False))
