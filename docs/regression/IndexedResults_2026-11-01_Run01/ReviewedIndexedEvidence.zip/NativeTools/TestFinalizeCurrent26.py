"""ДЛЯ ТЕСТОВ: возвращает исходные флаги пересчёта после служебного Manual COM-сеанса."""
from pathlib import Path
import copy,hashlib,json
from zipfile import ZipFile
from lxml import etree as ET
root=Path(__file__).resolve().parent
source=root/'Current25/RC_Section_NDM.xlsm';before=root/'Current22_Attempt2/Before.xlsm'
folder=root/'Current26';assert not folder.exists();folder.mkdir()
M='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
with ZipFile(source) as archive:
    infos=archive.infolist();parts={n:archive.read(n) for n in archive.namelist()}
with ZipFile(before) as archive: original=ET.fromstring(archive.read('xl/workbook.xml')).find(M+'calcPr')
doc=ET.fromstring(parts['xl/workbook.xml']);current=doc.find(M+'calcPr')
if current is not None:
    index=list(doc).index(current);doc.remove(current)
else: index=len(doc)
if original is not None:doc.insert(index,copy.deepcopy(original))
parts['xl/workbook.xml']=ET.tostring(doc,encoding='UTF-8',xml_declaration=True,standalone=True)
target=folder/source.name
with ZipFile(target,'w') as archive:
    for info in infos:archive.writestr(info,parts[info.filename])
with ZipFile(source) as old,ZipFile(target) as new:
    changed=[n for n in old.namelist() if old.read(n)!=new.read(n)]
    assert changed==['xl/workbook.xml']
    assert old.read('xl/vbaProject.bin')==new.read('xl/vbaProject.bin')
(root/'CurrentCalculationMode26.json').write_text(json.dumps({'Status':'PASS_ORIGINAL_CALCULATION_FLAGS_RESTORED','ChangedParts':changed,'CalculationFlags':None if original is None else dict(original.attrib),'VBAAndUserSheetsByteIdenticalToAccepted25':True,'WorkbookSHA256':hashlib.sha256(target.read_bytes()).hexdigest().upper()},indent=2),encoding='utf-8')
print('Original automatic/manual preference restored; data/VBA ZIP parts unchanged')
