"""ДЛЯ ТЕСТОВ: пассивно сверяет сохранённый тяжёлый пример без запуска Excel."""
import hashlib, json, zipfile, xml.etree.ElementTree as E
from pathlib import Path
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM')
B=Path(__file__).parent.parent
paths=[R/'workbook/output/NDM_Test_1232_30/RC_Section_NDM.xlsm',B/'ActionLatency_2026-10-28_Run01/StorageRun02/Heavy1232_30_Optimized_ExcelResults.xlsm']
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
records=[]
for path in paths:
 with zipfile.ZipFile(path) as z:
  ss=E.fromstring(z.read('xl/sharedStrings.xml'))
  strings=[''.join(t.text or '' for t in si.iter('{'+ns['m']+'}t')) for si in ss]
  wb=E.fromstring(z.read('xl/workbook.xml'))
  names={n.attrib['name']:n.text for n in wb.find('m:definedNames',ns)}
  settings={}
  results={}
  for sn in ('sheet1','sheet5'):
   cells={}
   sheet=E.fromstring(z.read('xl/worksheets/'+sn+'.xml'))
   for c in sheet.findall('.//m:c',ns):
    v=c.find('m:v',ns)
    if v is None: continue
    text=v.text or ''
    if c.attrib.get('t')=='s': text=strings[int(text)]
    cells[c.attrib['r']]=text
   if sn=='sheet1':
    for address,v in cells.items():
     if v in ('Geometry.Type','Results.SnapshotStorage','Results.SnapshotName'): settings[v]=cells.get('B'+''.join(filter(str.isdigit,address)))
   else:
    results={'Dimension':sheet.find('m:dimension',ns).attrib['ref'],'PopulatedCells':len(cells)}
  records.append({'Path':str(path),'SHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'Bytes':path.stat().st_size,'Settings':settings,'Names':{k:v for k,v in names.items() if k in ('rngNDMElementResults','rngNDMSectionGeometry','rngLoadCombinations','rngNDMElementGeometry')},'Results':results})
print(json.dumps(records,ensure_ascii=False,indent=2))
Path(__file__).with_name('HeavySavedInventory01.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8')
