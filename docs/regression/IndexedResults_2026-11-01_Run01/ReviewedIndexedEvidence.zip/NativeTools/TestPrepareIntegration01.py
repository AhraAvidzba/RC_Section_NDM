"""ДЛЯ ТЕСТОВ: связывает изолированный v6 с полным снимком, без публикации в проект."""
from pathlib import Path
import shutil
R=Path(r'C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM'); S=Path(__file__).parent; P=S/'Candidate'
def one(t,a,b):
 assert t.count(a)==1,(a,t.count(a));return t.replace(a,b)
t=(R/'src/Excel/CCalculationSnapshot.cls').read_text(encoding='utf-8-sig')
a=t.index('Private mElementFirst()');b=t.index("' Создаёт отдельный набор",a)
t=t[:a]+"Private mElementIndex As CResultBlockIndex ' Общий индекс фактических участков для обоих носителей.\n\n"+t[b:]
t=t.replace('mElementGroupCount = 0','Set mElementIndex = Nothing')
a=t.index('Public Function SelectElementResults(');b=t.index("' Проверяет наличие необязательной части",a)
t=t[:a]+'''Public Function SelectElementResults(ByVal combinationID As String, ByVal stateType As String, ByVal indexOnly As Boolean) As Variant
    If Len(combinationID) = 0 And Len(stateType) = 0 And Not indexOnly Then SelectElementResults = Table("rngNDMElementResults"): Exit Function
    Dim index As CResultBlockIndex: Set index = ElementIndex
    If indexOnly Then SelectElementResults = index.StateRows(combinationID, stateType): Exit Function
    Dim blocks As Collection: Set blocks = index.SelectBlocks(combinationID, stateType)
    Dim block As Variant, rows As Long, row As Long, column As Long, used As Long, selected() As Variant
    For Each block In blocks: rows = rows + index.RowCount(CLng(block)): Next block
    ReDim selected(1 To rows + 1, 1 To 9)
    For column = 1 To 9: selected(1, column) = mElements(1, column): Next column
    used = 1
    For Each block In blocks
        For row = index.FirstRow(CLng(block)) To index.FirstRow(CLng(block)) + index.RowCount(CLng(block)) - 1
            used = used + 1
            For column = 1 To 9: selected(used, column) = mElements(row, column): Next column
        Next row
    Next block
    SelectElementResults = selected
End Function

' Один индекс относится только к неизменяемому массиву данного снимка.
Friend Property Get ElementIndex() As CResultBlockIndex
    If mElementIndex Is Nothing Then
        Set mElementIndex = New CResultBlockIndex
        mElementIndex.Build mElements, mRunID
    End If
    Set ElementIndex = mElementIndex
End Property

' Передаёт принадлежащий снимку массив непосредственно последовательному v6-writer.
Friend Sub WriteIndexedElementBlocks(ByVal target As CIndexedSnapshotFile)
    target.WriteElements mElements, ElementIndex
End Sub

'''+t[b:]
(P/'CCalculationSnapshot.cls').write_text(t,encoding='utf8')
shutil.copyfile(S/'CResultBlockIndex.cls',P/'CResultBlockIndex.cls')
t=(P/'CCalculationSnapshotStore.cls').read_text(encoding='utf8')
t=one(t,'Private Sub WriteBinary(ByVal path As String, ByVal snapshot As CCalculationSnapshot)','Private Sub WriteLegacyBinary(ByVal path As String, ByVal snapshot As CCalculationSnapshot)')
t+='''
' Новые сохранения используют индексированный v6; v4/v5 остаются читаемыми без конвертации.
Private Sub WriteBinary(ByVal path As String, ByVal snapshot As CCalculationSnapshot)
    Dim indexed As New CIndexedSnapshotFile
    indexed.WriteFile path, snapshot, Me
End Sub

' Проверяет каталог v6 для привязки; совместимость v4/v5 использует их полный файловый SHA256.
Private Function FileIdentity(ByVal path As String) As String
    Dim indexed As New CIndexedSnapshotFile
    If indexed.OpenRead(path, Me) Then
        FileIdentity = indexed.Identity
    Else
        Dim digest As New CFileChecksum: FileIdentity = digest.FileSHA256(path)
    End If
End Function
'''
t=one(t,'Private Function ReadBinary(ByVal path As String) As CCalculationSnapshot','''Private Function ReadBinary(ByVal path As String) As CCalculationSnapshot
    Dim indexed As New CIndexedSnapshotFile
    If indexed.OpenRead(path, Me) Then Set ReadBinary = indexed.LoadAll: Exit Function''')
# Замены касаются только привязки и Save As; legacy footer хранит полный SHA256.
for expression in ('path','previous','source','target'):
 t=t.replace('digest.FileSHA256('+expression+')','FileIdentity('+expression+')')
# Возвращаем собственный fallback, чтобы не получить рекурсивный вызов.
t=t.replace('FileIdentity = FileIdentity(path)','FileIdentity = digest.FileSHA256(path)')
needle='    file.OpenRead temporary: signature = file.ReadASCII(8): version = file.ReadLong'
t=one(t,needle,'''    Dim indexed As New CIndexedSnapshotFile
    If indexed.OpenRead(temporary, Me) Then
        indexed.UpdateElapsed temporary, snapshot.ElapsedSeconds
        Set indexed = Nothing
        If MoveFileExW(StrPtr(temporary), StrPtr(target), 9) = 0 Then Err.Raise 5, , "Не удалось обновить время снимка: " & target
        LinkFile workbook
        Exit Sub
    End If
'''+needle)
t=t.replace('    Dim values() As Variant, flags() As Byte, numbers() As Double, codes() As Long, strings() As String\n    ReDim values', '''    If expectedRows = 0 And expectedColumns = 17 Then If rows > 100000 Then Err.Raise 5, , "Превышено число записей каталога."
    Dim values() As Variant, flags() As Byte, numbers() As Double, codes() As Long, strings() As String
    ReDim values''')
(P/'CCalculationSnapshotStore.cls').write_text(t,encoding='utf8')
t=(P/'CIndexedSnapshotFile.cls').read_text(encoding='utf8')
t=t.replace('Dim entry As Variant, key As String, kind As String, sample(1 To 1, 1 To 9) As Variant','Dim entry As Variant, key As String, kind As String, sample As Variant, cells(1 To 1, 1 To 9) As Variant')
t=t.replace('For column = 1 To 9: sample(1, column) = values(row, column + 8): Next column','For column = 1 To 9: cells(1, column) = values(row, column + 8): Next column\n        sample = cells')
t+='''
' Обновляет фиксированный заголовок и его SHA256, не перечитывая состояния.
' Вызывается только для собственной временной копии; атомарная публикация принадлежит Store.
Public Sub UpdateElapsed(ByVal path As String, ByVal seconds As Double)
    mFile.CloseFile
    mFile.OpenUpdate path: mFile.Position = 0: mFile.BeginWriteDigest
    mFile.WriteASCII SIGNATURE: mFile.WriteLong 6: mFile.WriteDouble mRunID: mFile.WriteDouble seconds: mFile.WriteLong mTables.Count
    Dim digest As String: digest = mFile.EndWriteDigest: mFile.WriteASCII digest: mFile.CloseFile
End Sub
'''
(P/'CIndexedSnapshotFile.cls').write_text(t,encoding='utf8')
print('Prepared isolated snapshot/index/store integration; no production publication')
