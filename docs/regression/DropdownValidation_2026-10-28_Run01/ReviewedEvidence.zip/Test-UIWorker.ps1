﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Проверяет отдельные пункты средствами Excel и оставляет собственную readonly-копию для UI-проверки.
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$root=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$source=Join-Path $PSScriptRoot 'ReleaseCandidate/Main/RC_Section_NDM.xlsm';$path=Join-Path $PSScriptRoot 'NDM_Dropdown_Probe.xlsm'
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory;if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Insufficient memory'}
Copy-Item $source $path -Force
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class TestDvUIOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$scratch=$null;$owned=0;$ticks=0
try{
 $app=New-Object -ComObject Excel.Application;$app.Visible=$true;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 [uint32]$id=0;[void][TestDvUIOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Path=$path}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'UIOwnership.json') -Encoding UTF8
 $book=$app.Workbooks.Open($path,0,$true)
 $cell=$book.Worksheets.Item('Config').Range('B26');$original=$cell.Formula
 . (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
 $scratch=$app.Workbooks.Add();$probe=$scratch.Worksheets.Item(1).Range('A1')
 $choices=@('Circle','Rectangles','PointedSection','HollowRectangle');$inline=Get-ConfigValidationListAddress $probe.Worksheet $choices

 $probe.Validation.Add(3,1,1,$inline)
 $records=@();$pass=0
 foreach($decimal in @('.',',')){
  $app.UseSystemSeparators=$false;$app.ThousandsSeparator=" ";$app.DecimalSeparator=$decimal;$app.ThousandsSeparator=$(if($decimal-eq'.'){','}else{'.'})
  foreach($target in @($cell,$probe)){
   foreach($choice in $choices){$target.Value2=$choice;if(-not$target.Validation.Value){throw ('Separate choice rejected: '+$choice+'; target='+$target.Worksheet.Name+'!'+$target.Address()+'; decimal='+$decimal+'; getter='+$target.Validation.Formula1)};$pass++}
   foreach($bad in @('Circle;Rectangles;PointedSection;HollowRectangle','TEST_UNKNOWN_GEOMETRY_TYPE')){$target.Value2=$bad;if($target.Validation.Value){throw 'Invalid joined/unknown choice accepted'};$pass++}
   $records+=,[ordered]@{DecimalSeparator=$decimal;Target=$target.Worksheet.Name+'!'+$target.Address();GetterFormula1=$target.Validation.Formula1;FourSeparateChoicesAccepted=$true;JoinedAndUnknownRejected=$true}
  }
 }
 $cell.Formula=$original;$app.UseSystemSeparators=$true;$scratch.Close($false);$scratch=$null
 [ordered]@{Passed=$true;Checks=$pass;Locales=@('decimal dot','decimal comma');BuilderAndSavedWorkbookChecked=$true;Records=$records;SourceValueRestored=$true}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot 'NativeChoiceBehavior.json') -Encoding UTF8
 [ordered]@{Ready=$true;PID=$owned;StartTicksUTC=[string]$ticks;Title='NDM_Dropdown_Probe.xlsm';Readonly=$book.ReadOnly}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'UIReady.json') -Encoding UTF8
 $timer=[Diagnostics.Stopwatch]::StartNew()
 while(-not(Test-Path (Join-Path $PSScriptRoot 'UIFinished.signal'))){if($timer.Elapsed.TotalMinutes-gt10){throw 'UI review timeout'};Start-Sleep -Milliseconds 500}
}catch{
 [ordered]@{Message=$_.Exception.Message;Stack=$_.ScriptStackTrace}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'UIError.json') -Encoding UTF8
 throw
}finally{
 if($scratch){$scratch.Close($false)};if($book){$book.Close($false)};if($app){$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 $app=$null;$book=$null;$scratch=$null;$cell=$null;$probe=$null;$target=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$timer=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ine'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Identity mismatch'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 200}while($timer.ElapsedMilliseconds-lt10000)
 [ordered]@{Passed=$absent;PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'UIClosure.json') -Encoding UTF8
 if(-not$absent){Write-Output 'Own Excel exit pending post-host observation; no kill'}
}
Write-Output 'NATIVE_CHOICE_AND_UI_REVIEW_CLOSED'
