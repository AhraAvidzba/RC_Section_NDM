﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# Читает частную книгу без импорта, запуска VBA и сохранения; закрывает только собственный Excel.
param([Parameter(Mandatory=$true)][ValidateSet('Main','Ready')][string]$Case,[switch]$CaptureLayout)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$root=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$path=Join-Path $PSScriptRoot ('ReleaseCandidate/'+$Case+'/RC_Section_NDM.xlsm')
$out=Join-Path $PSScriptRoot ('Native/'+$Case)
New-Item -ItemType Directory -Force -Path $out|Out-Null
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes -lt8192 -or ($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve below 8 GiB RAM/14 GiB commit'}
$hash=(Get-FileHash -LiteralPath $path).Hash
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class TestUnifiedOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$owned=0;$ticks=0;$success=$false
try{
 $app=New-Object -ComObject Excel.Application
 $app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=3
 [uint32]$id=0;[void][TestUnifiedOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id)
 $owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;Path=$path;Hash=$hash}|ConvertTo-Json|Set-Content (Join-Path $out 'Ownership.json') -Encoding UTF8
 $book=$app.Workbooks.Open($path,0,$true)
 if(-not$book.ReadOnly -or -not$book.HasVBProject){throw 'Native readonly VBA book required'}
 $text=New-Object Text.StringBuilder
 [void]$text.AppendLine('VBA PROJECT EXPORT');[void]$text.AppendLine('Workbook: '+$book.Name);[void]$text.AppendLine('Date: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
 $project=$book.VBProject;$count=[int]$project.VBComponents.Count
 if($count-ne181){throw 'Expected 175+6 native components'}
 $components=@()
 for($i=1;$i-le$count;$i++){
  $component=$project.VBComponents.Item($i);$lines=[int]$component.CodeModule.CountOfLines
  [void]$text.AppendLine('='*100);[void]$text.AppendLine('COMPONENT: '+$component.Name);[void]$text.AppendLine('TYPE: '+$component.Type);[void]$text.AppendLine('LINES: '+$lines);[void]$text.AppendLine('='*100)
  if($lines){[void]$text.AppendLine($component.CodeModule.Lines(1,$lines))};[void]$text.AppendLine()
  $components+=,[ordered]@{Name=[string]$component.Name;Type=[int]$component.Type;Lines=$lines}
 }
 [IO.File]::WriteAllText((Join-Path $out 'VBA_All_Code.txt'),$text.ToString(),(New-Object Text.UTF8Encoding($true)))
 $config=$book.Worksheets.Item('Config');$range=$book.Names.Item('rngSystemSettings').RefersToRange;$matrix=$range.Value2;$keys=@{};$positions=@{}
 for($i=2;$i-le$range.Rows.Count;$i++){
  $key=[string]$matrix[$i,1]
  if($key -and -not$key.StartsWith('[')){if($keys.ContainsKey($key)){throw ('Duplicate key '+$key)};$keys[$key]=$matrix[$i,2];$positions[$key]=$i+2}
 }
 if($keys['Output.CombinationMode']-cne'Worst' -or $keys.ContainsKey('Plot.LoadCase') -or $keys.ContainsKey('AutoCAD.Export.CombinationID')){throw 'Shared output settings mismatch'}
 if($positions['Output.CombinationMode']+1-ne$positions['General.WorstCombinationCriterion'] -or $positions['General.WorstCombinationCriterion']+1-ne$positions['Output.CombinationID']){throw 'Output order mismatch'}
 $titles=@();foreach($row in @(4,11,12,16,20,37,113)){
  $styles=@();foreach($column in 1..5){
   $cell=$config.Cells.Item($row,$column);$edges=@();foreach($edge in @(7,8,9,10)){$edges+=,[ordered]@{Edge=$edge;Line=$cell.Borders.Item($edge).LineStyle;Weight=$cell.Borders.Item($edge).Weight;Color=$cell.Borders.Item($edge).Color}}
   $styles+=,[ordered]@{Font=$cell.Font.Name;Size=$cell.Font.Size;Bold=$cell.Font.Bold;FontColor=$cell.Font.Color;Fill=$cell.Interior.Color;Horizontal=$cell.HorizontalAlignment;Vertical=$cell.VerticalAlignment;Wrap=$cell.WrapText;Borders=$edges}
  }
  $titles+=,[ordered]@{Row=$row;Title=$config.Cells.Item($row,1).Value2;Height=$config.Rows.Item($row).RowHeight;Styles=$styles}
 }
 $main=($titles[0].Styles|ConvertTo-Json -Depth 8 -Compress);$sub=($titles[5].Styles|ConvertTo-Json -Depth 8 -Compress)
 if(($titles[1].Styles|ConvertTo-Json -Depth 8 -Compress)-cne$main){throw 'Main heading style differs'}
 foreach($i in @(2,3,4,6)){if(($titles[$i].Styles|ConvertTo-Json -Depth 8 -Compress)-cne$sub){throw 'Subheading style differs'}}
 $idcell=$config.Cells.Item($positions['Output.CombinationID'],2);$modecell=$config.Cells.Item($positions['Output.CombinationMode'],2)
 if($idcell.Validation.Formula1-cne'=$H$71:$H$100' -or $config.Range('L71').Validation.Formula1-cne'=$J$39:$M$39'){throw 'Direct visible list source mismatch'}
 if($modecell.Validation.Formula1 -notin @('Worst,User','Worst;User')){throw 'Mode list mismatch'}
 if($config.Range('BQ:EF').EntireColumn.Hidden-ne$false){throw 'Helper columns still hidden'}
 $helper=$null;try{$helper=$book.Names.Item('rngSectionRecipeTypes')}catch{}
 if($helper){throw 'Obsolete helper name remains'}
 $units=@();foreach($key in @('Load.ReferenceOffsetX','Load.ReferenceOffsetY','Mesh.StepX','Mesh.StepY')){$cell=$config.Cells.Item($positions[$key],3);if([string]$cell.Text-match '^#'){throw ('Broken unit formula '+$key)};$units+=,[ordered]@{Key=$key;Value=$cell.Value2;Formula=$cell.Formula}}
 [ordered]@{Case=$Case;Passed=$true;SourceSHA256=$hash;Components=$components;SettingsKeys=$keys.Count;Mode=$keys['Output.CombinationMode'];UserID=$keys['Output.CombinationID'];SettingPositions=$positions;NativeTitleStyles=$titles;AllHeadingStylesMatch=$true;CombinationList=$idcell.Validation.Formula1;ProfileList=$config.Range('L71').Validation.Formula1;ModeList=$modecell.Validation.Formula1;Units=$units;NoHiddenHelpers=$true;Readonly=$book.ReadOnly;ImportCompileSaveMacroRun=$false}|ConvertTo-Json -Depth 12|Set-Content (Join-Path $out 'NativeVerification.json') -Encoding UTF8
 if($CaptureLayout){
  . (Join-Path $root 'tools/build_workbook/WorkbookLayout.ps1')
  $layout=Get-WorkbookLayoutSnapshot $book (Get-WorkbookLayoutXmlSheets $path)
  $layout|Add-Member Provenance ([ordered]@{Workbook='RC_Section_NDM.xlsm';SHA256=$hash;Captured=(Get-Date).ToString('s')})
  $layout|ConvertTo-Json -Depth 15|Set-Content (Join-Path $out 'WorkbookLayout.json') -Encoding UTF8
 }
 $success=$true
}finally{
 if($book){$book.Close($false)}
 if($app){$app.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app)}
 $component=$null;$project=$null;$cell=$null;$idcell=$null;$modecell=$null;$config=$null;$range=$null;$helper=$null;$book=$null;$app=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{
  try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ine'EXCEL' -or $p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Owner identity differs; no absence assertion'}}catch{if($_.FullyQualifiedErrorId-match '^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}}
  Start-Sleep -Milliseconds 250
 }while($watch.ElapsedMilliseconds-lt15000)
 [ordered]@{Passed=$absent;PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;QuitRequested=$true;ForceKilled=$false;ObservedUTC=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'Closure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal Excel exit not proven; nothing force-closed'}
}
if(-not$success -or (Get-FileHash -LiteralPath $path).Hash-cne$hash){throw 'Readonly verification failed or source changed'}
Write-Output ('NATIVE_PASS: '+$Case+'; 181 components; readonly; styles uniform; own Excel absent')
