﻿# -------------------- ДЛЯ ТЕСТОВ --------------------
# В частной копии доказывает отказ нового теста на старом списке, исправляет только два модуля и компилирует.
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -Global
$root=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$source=Join-Path $root 'workbook/output/RC_Section_NDM.xlsm';$hash=(Get-FileHash $source).Hash
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
if($m.AvailableMBytes-lt8192-or($m.CommitLimit-$m.CommittedBytes)-lt14GB){throw 'Memory reserve below 8 RAM/14 commit GiB'}
[ordered]@{RAMGiB=$m.AvailableMBytes/1024;CommitFreeGiB=($m.CommitLimit-$m.CommittedBytes)/1GB}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'MemoryBeforePrepare.json') -Encoding UTF8
$private=Join-Path $PSScriptRoot 'NativeCandidate';New-Item -ItemType Directory -Force -Path $private|Out-Null
$path=Join-Path $private 'RC_Section_NDM.xlsm';Copy-Item $source $path
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class TestDvOwner{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);}'
$app=$null;$book=$null;$owned=0;$ticks=0
try{
 $app=New-Object -ComObject Excel.Application;$app.Visible=$false;$app.DisplayAlerts=$false;$app.EnableEvents=$false;$app.AutomationSecurity=1
 [uint32]$id=0;[void][TestDvOwner]::GetWindowThreadProcessId([IntPtr]$app.Hwnd,[ref]$id);$owned=[int]$id;$ticks=(Get-Process -Id $owned).StartTime.ToUniversalTime().Ticks
 [ordered]@{PID=$owned;StartTicksUTC=[string]$ticks;SourceSHA256=$hash}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'PrepareOwnership.json') -Encoding UTF8
 $book=$app.Workbooks.Open($path,0,$false);$project=$book.VBProject
 $name='modTestRecipeSetbacks';$text=[IO.File]::ReadAllText((Join-Path $root ('tests/'+$name+'.bas')),[Text.Encoding]::UTF8)
 $ansi=Join-Path $private ($name+'.bas');[IO.File]::WriteAllText($ansi,$text,[Text.Encoding]::GetEncoding(1251))
 $project.VBComponents.Remove($project.VBComponents.Item($name));$null=$project.VBComponents.Import($ansi)
 $before=[string]$app.Run("'"+$book.Name+"'!modTestRecipeSetbacks.RunRecipeTypeListTests")
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'Regression_BeforeFix.txt'),$before,(New-Object Text.UTF8Encoding($true)))
 if($before-notmatch'failed=([1-9][0-9]*)' -or $before-notmatch'FAIL: types.option.accepted.Circle'){throw 'New regression check did not detect the real bug'}
 $module=$project.VBComponents.Item('modSectionRecipeSetup').CodeModule;$changed=0
 for($i=1;$i-le$module.CountOfLines;$i++){
  if($module.Lines($i,1)-like'*choices = Join(ids, CStr(ThisWorkbook.Application.International(xlListSeparator)))*'){
   $target=([IO.File]::ReadAllLines((Join-Path $root 'src/Excel/modSectionRecipeSetup.bas'),[Text.Encoding]::UTF8)|Where-Object {$_-like'*choices = Join(ids,*'})
   if(@($target).Count-ne1){throw 'Ambiguous source correction'};$module.ReplaceLine($i,[string]$target);$changed++
  }
 }
 if($changed-ne1){throw 'Expected exactly one production line correction'}
 $app.VBE.ActiveVBProject=$project;$compile=$app.VBE.CommandBars.FindControl(1,578);if(-not$compile){throw 'Compile control unavailable'};if($compile.Enabled){$compile.Execute()};if($compile.Enabled){throw 'VBA compile failed'}
 $after=[string]$app.Run("'"+$book.Name+"'!modTestRecipeSetbacks.RunRecipeTypeListTests")
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'Regression_AfterFix.txt'),$after,(New-Object Text.UTF8Encoding($true)))
 if($after-match'^FAIL:'-or$after-notmatch'TOTAL RECIPE TYPE LIST: passed=18; failed=0'){throw 'Corrected regression check failed'}
 $null=$app.Run("'"+$book.Name+"'!modSectionRecipeSetup.UpdateSectionRecipeTypes")
 if($book.VBProject.VBComponents.Count-ne181){throw 'Unexpected component count'}
 $book.Save()
 [ordered]@{Passed=$true;Compile578=$true;BeforeFailedAsExpected=$true;After='18/0';SourceSHA256=$hash;CandidateSHA256="HASH_AFTER_CLOSE";ProductionLinesChanged=1}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'Preparation.json') -Encoding UTF8
}finally{
 $module=$null;$compile=$null;$project=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($book){$book.Close($false)};$book=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
 if($app){$app.Quit()};$app=$null
 [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
 $absent=$false;$watch=[Diagnostics.Stopwatch]::StartNew()
 do{try{$p=Get-Process -Id $owned -ErrorAction Stop;if($p.ProcessName-ine'EXCEL'-or$p.StartTime.ToUniversalTime().Ticks-ne$ticks){throw 'Own identity mismatch'}}catch{if($_.FullyQualifiedErrorId-match'^NoProcessFoundForGivenId(,|$)'){$absent=$true;break}else{throw}};Start-Sleep -Milliseconds 200}while($watch.ElapsedMilliseconds-lt10000)
 [ordered]@{Passed=$absent;PID=$owned;StartTicksUTC=[string]$ticks;Absent=$absent;ForceKilled=$false}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'PrepareClosure.json') -Encoding UTF8
 if(-not$absent){throw 'Own normal exit not proven'}
}
if((Get-FileHash $source).Hash-cne$hash){throw 'Published source changed during private preparation'}
$proofPath=Join-Path $PSScriptRoot 'Preparation.json';$proof=Get-Content $proofPath -Raw -Encoding UTF8|ConvertFrom-Json;$proof.CandidateSHA256=(Get-FileHash $path).Hash;$proof|ConvertTo-Json|Set-Content $proofPath -Encoding UTF8
Write-Output 'PREPARED: regression before FAIL, after18/0; compile578; own Excel absent'
