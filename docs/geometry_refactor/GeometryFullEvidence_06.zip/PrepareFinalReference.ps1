# Независимый source-built эталон: обновляются исходники, пользовательский output не изменяется.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
Copy-Item -LiteralPath ($dir+'/FreshReference.xlsm') -Destination ($dir+'/FinalFreshReference.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/FinalFreshReference.xlsm')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/FinalFreshReference.xlsm') -OutputPath ($dir+'/VBA_FinalFreshReference.txt')
'FINAL_SOURCE_REFERENCE_READY'
