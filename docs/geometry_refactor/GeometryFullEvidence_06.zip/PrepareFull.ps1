$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
& 'tools/build_workbook/Update-ReviewHelp.ps1' -WorkbookPath ($dir+'/Candidate.xlsm') -ReportDirectory ($dir+'/Help')
Copy-Item -LiteralPath ($dir+'/Candidate.xlsm') -Destination ($dir+'/Ready.xlsm')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/Ready.xlsm') -OutputPath ($dir+'/VBA_Ready.txt')
