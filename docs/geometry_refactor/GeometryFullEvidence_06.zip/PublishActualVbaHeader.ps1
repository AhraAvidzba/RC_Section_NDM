# Записывает экспорт фактической output-книги; весь VBA-код обязан совпадать побайтно.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$publication=Get-Content -LiteralPath ($dir+'/Publication.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$reference=[IO.File]::ReadAllLines((Join-Path (Get-Location) ($dir+'/VBA_SnapshotFixed.txt')),[Text.Encoding]::UTF8)
$actual=[IO.File]::ReadAllLines((Join-Path (Get-Location) ($dir+'/VBA_Published.txt')),[Text.Encoding]::UTF8)
if ($actual.Length -ne $reference.Length -or $actual[1] -cne 'Workbook: RC_Section_NDM.xlsm' -or $actual[2] -notmatch '^Date: \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$') {throw 'Unexpected native export header.'}
$reference[1]=$actual[1];$reference[2]=$actual[2]
if ([string]::Join("`n",$reference) -cne [string]::Join("`n",$actual)) {throw 'Native VBA payload differs beyond workbook/date header.'}
$book='workbook/output/RC_Section_NDM.xlsm';$dump='workbook/output/VBA_All_Code.txt'
if ((Get-FileHash -LiteralPath $book).Hash.ToLowerInvariant() -ne $publication.WorkbookSHA256 -or
 (Get-FileHash -LiteralPath $dump).Hash.ToLowerInvariant() -ne $publication.ExportSHA256) {throw 'Published pair changed before native header update.'}
Copy-Item -LiteralPath ($dir+'/VBA_Published.txt') -Destination ($dir+'/VBA_ActualPublished.txt')
$bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) ($dir+'/VBA_ActualPublished.txt')))
$stream=[IO.File]::Open((Join-Path (Get-Location) $dump),[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try {$stream.SetLength(0);$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)} finally {$stream.Dispose()}
$publication | Add-Member -NotePropertyName CandidateExportSHA256 -NotePropertyValue $publication.ExportSHA256
$publication.ExportSHA256=(Get-FileHash -LiteralPath $dump).Hash.ToLowerInvariant()
$publication | Add-Member -NotePropertyName NativeOutputExport -NotePropertyValue 'VBA_ActualPublished.txt'
$publication | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($dir+'/Publication.json') -Encoding UTF8
if ((Get-FileHash -LiteralPath $book).Hash.ToLowerInvariant() -ne $publication.WorkbookSHA256) {throw 'Book changed during native header update.'}
foreach ($item in $publication.ForeignOutputFiles) {
 if ((Get-FileHash -LiteralPath $item.Path).Hash.ToLowerInvariant() -ne $item.SHA256) {throw ('Unrelated output changed: '+$item.Path)}
}
[ordered]@{Status='PASS';ChangedLines=@('Workbook','Date');NativePayloadExactlyEqual=$true;WorkbookUnchanged=$true;
 PreviousDumpSHA256=$publication.CandidateExportSHA256;ActualDumpSHA256=$publication.ExportSHA256;
 ForeignOutputsPreserved=$true} | ConvertTo-Json | Set-Content -LiteralPath ($dir+'/PublishedDumpHeaderEvidence.json') -Encoding UTF8
'ACTUAL_OUTPUT_VBA_PAYLOAD_IDENTICAL_HEADER_UPDATED'
