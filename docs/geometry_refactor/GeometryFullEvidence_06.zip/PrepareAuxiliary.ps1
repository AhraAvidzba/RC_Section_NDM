# Общие дополнительные тесты только в private fixture, не в рабочей книге.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
Copy-Item -LiteralPath ($dir+'/Ready.xlsm') -Destination ($dir+'/Auxiliary.xlsm')
Copy-Item -LiteralPath ($dir+'/Baseline/RC_Section_NDM.xlsm') -Destination ($dir+'/AuxiliaryBaseline.xlsm')
foreach ($book in @('Auxiliary.xlsm','AuxiliaryBaseline.xlsm')) {
 & 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/'+$book) -ModuleNames @('modFinalGeometryChecks') -ExampleFiles @('docs/geometry_refactor/examples/modFinalGeometryChecks.bas')
}
