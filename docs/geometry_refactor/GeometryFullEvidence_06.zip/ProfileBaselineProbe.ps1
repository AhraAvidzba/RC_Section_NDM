# Reproduce original visualization-oracle errors on the unchanged old kernel.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$book=$dir+'/ProfileBaselineProbe.xlsm'
if (Test-Path -LiteralPath $book) {throw 'Profile baseline probe already exists.'}
Copy-Item -LiteralPath ($dir+'/Baseline/RC_Section_NDM.xlsm') -Destination $book
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $book -ModuleNames @('modTestProfileConfig')
[ordered]@{Prepared=$true;SourceModuleSHA256=(Get-FileHash -LiteralPath 'tests/modTestProfileConfig.bas').Hash;WorkbookSHA256=(Get-FileHash -LiteralPath $book).Hash} | ConvertTo-Json | Set-Content -LiteralPath ($dir+'/ProfileBaselinePrepared.json') -Encoding UTF8
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $book -Mode Yes -ReportPath ($dir+'/ProfileBaselineOriginal_On.txt') -FixtureGeometryType RectSet -Macro 'modTestProfileConfig.RunAudit03ProfileConfigTests' -TimeoutSeconds 1200
'ORIGINAL_PROFILE_PROBE_TERMINAL: exit='+$LASTEXITCODE
exit $LASTEXITCODE
