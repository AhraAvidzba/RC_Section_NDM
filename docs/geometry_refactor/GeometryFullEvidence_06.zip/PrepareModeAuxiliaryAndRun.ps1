# Новый private helper сохраняет входной режим ON/OFF вместо принудительного OFF.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
foreach ($kind in @('Baseline','Final')) {
 $book=$dir+'/AuxiliaryMode'+$kind+'.xlsm'
 Copy-Item -LiteralPath ($dir+'/Auxiliary'+$kind+'.xlsm') -Destination $book
 & 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $book -ModuleNames @('modFinalGeometryChecks') -ExampleFiles @('docs/geometry_refactor/examples/modFinalGeometryChecks.bas')
 & 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath $book -OutputPath ($dir+'/VBA_AuxiliaryMode'+$kind+'.txt')
}
& python 'tools/build_workbook/Verify-GeometryAuxiliary.py' --directory $dir --book-prefix AuxiliaryMode --report ModeAuxiliaryInputsEvidence.json
if ($LASTEXITCODE -ne 0) {throw 'Private helper changed original code.'}
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/AuxiliaryModeFinal.xlsm') -Mode $mode -ReportPath ($dir+'/FinalSP35Projection_'+$label+'.txt') -Macro 'modFinalGeometryChecks.RunSP35ProjectionFixture' -TimeoutSeconds 300 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('Projection mode failed: '+$label)}
}
& ($dir+'/FinalPerformanceAndPlots.ps1')
'ACTUAL_MODE_PERFORMANCE_AND_PLOTS_COMPLETED'
