$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/GeometryFull_2026-10-13/Candidate.xlsm' -ModuleNames @('CSectionPropertiesCalculator','modTestGeometry','modSectionRecipeApiGuide')
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/GeometryFull_2026-10-13/Candidate.xlsm' -Mode No -ReportPath 'docs/regression/GeometryFull_2026-10-13/Preflight.txt' -Macro 'modTestGeometry.RunGeometryTests,modTestGeometryQuery.RunGeometryQueryTests' -TimeoutSeconds 300 -FailFast
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
