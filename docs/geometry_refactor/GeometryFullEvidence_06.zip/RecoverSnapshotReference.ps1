# Read-only recovery of the independently saved reference after COM close failure.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/SnapshotFixedReference.xlsm') -OutputPath ($dir+'/VBA_SnapshotFixedReference.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_SnapshotFixed.txt') -ReferenceExportPath ($dir+'/VBA_SnapshotFixedReference.txt') -ReportPath ($dir+'/SnapshotFixedSourceEquality.json')
& 'tools/build_workbook/Validate-Workbook.ps1' -WorkbookPath ($dir+'/ReleaseSnapshotFixed.xlsm') -ReportPath ($dir+'/SnapshotFixedStructure.json') -UserConfiguredWorkbook
& python 'tools/build_workbook/Verify-ReviewWorkbook.py' --before ($dir+'/Baseline/RC_Section_NDM.xlsm') --after ($dir+'/ReleaseSnapshotFixed.xlsm') --report ($dir+'/SnapshotFixedUserData.json')
if ($LASTEXITCODE -ne 0) {throw 'Snapshot candidate user data changed.'}
& python 'tools/build_workbook/Verify-StandaloneHelp.py' --book ($dir+'/ReleaseSnapshotFixed.xlsm') --dump ($dir+'/VBA_SnapshotFixed.txt') --report ($dir+'/SnapshotFixedStandaloneHelp.json')
if ($LASTEXITCODE -ne 0) {throw 'Snapshot candidate Help failed.'}
'SNAPSHOT_RELEASE_RECOVERED_AND_VERIFIED'
