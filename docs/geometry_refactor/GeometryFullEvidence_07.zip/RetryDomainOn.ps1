# Только завершившийся I/O-сбой ON; успешный OFF не повторяется и не затирается.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$body=[IO.File]::ReadAllText(($dir+'/DomainFixedOnOff.ps1'))
$match=[regex]::Match($body,'(?s)\$macros=@\((.*?)\)\s*foreach')
if (-not $match.Success) {throw 'Domain macro manifest missing'}
$macros=@([regex]::Matches($match.Groups[1].Value,"'([^']+)'" ) | ForEach-Object {$_.Groups[1].Value})
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/ReadyHarnessFixed.xlsm') -Mode Yes -ReportPath ($dir+'/DomainFixed_On_Retry1.txt') -FixtureGeometryType RectSet -Macro ($macros -join ',') -TimeoutSeconds 1800 -FailFast
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
