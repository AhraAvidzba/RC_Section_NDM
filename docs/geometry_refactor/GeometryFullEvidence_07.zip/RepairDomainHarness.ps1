# Исправлены только native-precondition и устаревшая проверка номера колонки.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
Copy-Item -LiteralPath ($dir+'/Ready.xlsm') -Destination ($dir+'/ReadyHarnessFixed.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/ReadyHarnessFixed.xlsm') -ModuleNames @('modTestSP35CrackWidth')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-PostAudit03NativeCAD.ps1' -SourceWorkbook ($dir+'/ReadyHarnessFixed.xlsm') -ReportDirectory ($dir+'/NativeSP35Workbook_'+$label) -Macro RunSP35WorkbookTests -Mode $mode -LaunchInstalledAutoCAD
}
