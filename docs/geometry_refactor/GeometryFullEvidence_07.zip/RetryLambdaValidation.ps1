# Retry a genuinely terminated 900s OFF macro; numerical criteria stay fixed.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$absolute=(Resolve-Path -LiteralPath $dir).Path
$ticks=(Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks
[ordered]@{PID=$PID;Ticks=$ticks} | ConvertTo-Json | Set-Content -LiteralPath ($dir+'/LambdaRetryIdentity.json') -Encoding UTF8
Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$absolute+'/WaitThenWatchRepair.ps1"'),'-RepairId',$PID,'-RepairTicks',$ticks,'-PreviousId','19616','-PreviousTicks','639274492453923572','-Directory',('"'+$absolute+'"')) -RedirectStandardOutput ($dir+'/LambdaRetryWatcher.stdout.log') -RedirectStandardError ($dir+'/LambdaRetryWatcher.stderr.log')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 $limit=if ($mode -eq 'No') {2700} else {1800}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/ReleaseLambdaFixed.xlsm') -Mode $mode -ReportPath ($dir+'/LambdaFixedDirectedRetry_'+$label+'.txt') -FixtureGeometryType RectSet -Macro 'modTestConfiguration.RunAudit03CapacityNumericConfigTests' -TimeoutSeconds $limit -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('Corrected full configuration test failed: '+$label)}
}
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/ReleaseLambdaFixed.xlsm') -Mode Yes -ReportPath ($dir+'/LambdaFixedBatch_On.txt') -FixtureGeometryType RectSet -Macro 'modTestBatchCalculation.RunBatchCalculationTests' -TimeoutSeconds 5400
if ($LASTEXITCODE -ne 0) {throw 'Full corrected BatchON failed.'}
'LAMBDA_RETRY_AND_FULL_BATCH_COMPLETED'
