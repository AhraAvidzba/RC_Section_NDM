# Revalidate all profile scenarios using the retained diagrams; tolerances unchanged.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$book=$dir+'/ReleaseSnapshotFixed.xlsm'
if (Test-Path -LiteralPath $book) {throw 'Snapshot-corrected candidate already exists.'}
Copy-Item -LiteralPath ($dir+'/ReleaseLambdaFixed.xlsm') -Destination $book
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $book -ModuleNames @('modTestProfileConfig')
$absolute=(Resolve-Path -LiteralPath $dir).Path
$ticks=(Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks
[ordered]@{PID=$PID;Ticks=$ticks} | ConvertTo-Json | Set-Content -LiteralPath ($dir+'/ProfileRepairIdentity.json') -Encoding UTF8
Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$absolute+'/WaitThenWatchRepair.ps1"'),'-RepairId',$PID,'-RepairTicks',$ticks,'-PreviousId','28932','-PreviousTicks','639274612714914437','-Directory',('"'+$absolute+'"')) -RedirectStandardOutput ($dir+'/ProfileRepairWatcher.stdout.log') -RedirectStandardError ($dir+'/ProfileRepairWatcher.stderr.log')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $book -Mode $mode -ReportPath ($dir+'/ProfileSnapshotFixed_'+$label+'.txt') -FixtureGeometryType RectSet -Macro 'modTestProfileConfig.RunAudit03ProfileConfigTests' -TimeoutSeconds 1800 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('Complete profile suite failed: '+$label)}
}
'PROFILE_SNAPSHOT_ORACLE_BOTH_MODES_COMPLETED'
