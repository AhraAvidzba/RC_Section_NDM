# Only the private configuration-test assertion changes; production is frozen.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$release=$dir+'/ReleaseLambdaFixed.xlsm'
$baseline=$dir+'/LambdaBaselineProbe.xlsm'
if ((Test-Path -LiteralPath $release) -or (Test-Path -LiteralPath $baseline)) {throw 'Repair inputs already exist; inspect them.'}
Copy-Item -LiteralPath ($dir+'/Release.xlsm') -Destination $release
Copy-Item -LiteralPath ($dir+'/Baseline/RC_Section_NDM.xlsm') -Destination $baseline
foreach ($book in @($release,$baseline)) {
 & 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $book -ModuleNames @('modTestConfiguration')
}
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $baseline -Mode Yes -ReportPath ($dir+'/LambdaBaselineProbe_On.txt') -FixtureGeometryType RectSet -Macro 'modTestConfiguration.RunAudit03CapacityNumericConfigTests' -TimeoutSeconds 900 -FailFast
if ($LASTEXITCODE -ne 0) {throw 'Baseline lambda contract probe failed.'}
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $release -Mode $mode -ReportPath ($dir+'/LambdaFixedDirected_'+$label+'.txt') -FixtureGeometryType RectSet -Macro 'modTestConfiguration.RunAudit03CapacityNumericConfigTests' -TimeoutSeconds 900 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('Corrected lambda assertion failed: '+$label)}
}
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $release -Mode Yes -ReportPath ($dir+'/LambdaFixedBatch_On.txt') -FixtureGeometryType RectSet -Macro 'modTestBatchCalculation.RunBatchCalculationTests' -TimeoutSeconds 5400
if ($LASTEXITCODE -ne 0) {throw 'Full corrected BatchON failed.'}
'LAMBDA_TOLERANCE_REPAIR_COMPLETED'
