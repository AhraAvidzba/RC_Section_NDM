# Изменяется только private native-export check; полные стандартные входы неизменяемы.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$release=$dir+'/Release.xlsm'
Copy-Item -LiteralPath ($dir+'/FinalReady.xlsm') -Destination $release
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $release -ModuleNames @('modTestContourMesh')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-PostAudit03NativeCAD.ps1' -SourceWorkbook $release -ReportDirectory ($dir+'/NativeReleaseMesh_'+$label) -Macro RunRealAutoCADContourMeshTests -Mode $mode -LaunchInstalledAutoCAD
}
'NATIVE_EXPORT_FIXTURE_REPAIR_COMPLETED'
