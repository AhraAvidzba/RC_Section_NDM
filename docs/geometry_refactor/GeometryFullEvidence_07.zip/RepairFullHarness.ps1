# Направленная проверка исправленных предпосылок полного тестового набора.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
Copy-Item -LiteralPath ($dir+'/ReadyHarnessFixed.xlsm') -Destination ($dir+'/ReadyHarnessV3.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/ReadyHarnessV3.xlsm') -ModuleNames @('modTestConfiguration','modTestGeometryConfig','modTestProfileConfig','modTestWorkbookInterface')
$macros=@('modTestWorkbookInterface.RunAudit03NumericSettingsInputTests',
 'modTestGeometryConfig.RunAudit03RebarFieldConfigTests',
 'modTestProfileConfig.RunAudit03RelocatedInputTests',
 'modTestWorkbookInterface.RunAudit03SettingErrorMessageTests',
 'modTestConfiguration.RunAudit03CapacityNumericConfigTests')
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/ReadyHarnessV3.xlsm') -Mode No -FixtureGeometryType RectSet -ReportPath ($dir+'/RepairFullDirected.txt') -Macro ($macros -join ',') -TimeoutSeconds 1800
if ($LASTEXITCODE -ne 0) {throw 'Directed full-harness repair failed.'}
