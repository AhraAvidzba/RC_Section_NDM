# Общий поиск подписей, адресная диагностика и исправленные fixtures.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$book=$dir+'/ReadyHarnessV4.xlsm'
Copy-Item -LiteralPath ($dir+'/ReadyHarnessV3.xlsm') -Destination $book
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $book -ModuleNames @('CSectionInputTable','modSectionRecipeTypes','CSectionRecipeRectSet','modTestSectionRecipes','modTestWorkbookInterface','modTestConfiguration','modSectionRecipeApiGuide')
$ticks=(Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks
Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',($dir+'/WatchMergeDialogs.ps1'),'-RunnerId',$PID,'-RunnerTicks',$ticks,'-Directory',$dir) -RedirectStandardOutput ($dir+'/CommonInputWatcher.stdout.log') -RedirectStandardError ($dir+'/CommonInputWatcher.stderr.log')
$macros=@('modTestSectionRecipes.RunWorkbookRecipeInputTests',
 'modTestGeometryConfig.RunAudit03RebarFieldConfigTests',
 'modTestConfiguration.RunAudit03CapacityNumericConfigTests',
 'modTestWorkbookInterface.RunAudit03InputUnitConsumerTests')
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $book -Mode No -FixtureGeometryType RectSet -ReportPath ($dir+'/RepairCommonInput.txt') -Macro ($macros -join ',') -TimeoutSeconds 1800
if ($LASTEXITCODE -ne 0) {throw 'Common input repair failed.'}
'COMMON_INPUT_REPAIR_COMPLETED'
