# Независимая отдельная source-сборка предыдущего этапа, обновлена теми же source.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
Copy-Item -LiteralPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/RC_Section_NDM.xlsm' -Destination ($dir+'/FreshReference.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/FreshReference.xlsm') -ModuleNames @('CSectionPropertiesCalculator','modTestGeometry','modSectionRecipeApiGuide')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/FreshReference.xlsm') -OutputPath ($dir+'/VBA_FreshReference.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_Ready.txt') -ReferenceExportPath ($dir+'/VBA_FreshReference.txt') -ReportPath ($dir+'/SourceEquality.json')
