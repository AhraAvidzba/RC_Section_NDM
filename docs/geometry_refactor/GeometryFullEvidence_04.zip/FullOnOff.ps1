# Полные штатные suite и дополнения после удаления неиспользуемой обёртки.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$source=$dir+'/Ready.xlsm'
$driverTicks=(Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks
[ordered]@{PID=$PID;StartTicks=$driverTicks;SourceSHA256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash;StartedUTC=(Get-Date).ToUniversalTime().ToString('o')} |
 ConvertTo-Json | Set-Content -LiteralPath ($dir+'/FullDriverIdentity.json') -Encoding UTF8
$watch=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -WindowStyle Hidden -PassThru -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',($dir+'/WatchMergeDialogs.ps1'),'-RunnerId',$PID,'-RunnerTicks',$driverTicks,'-Directory',$dir) -RedirectStandardOutput ($dir+'/DialogWatcher.stdout.log') -RedirectStandardError ($dir+'/DialogWatcher.stderr.log')
$macros=@('modTestDeclarativeGeometry.RunCoreGeometryTests','modTestGeometryQuery.RunGeometryQueryTests',
 'modTestSectionRecipes.RunWorkbookRecipeInputTests','modTestSectionRecipes.RunRecipeMeshBoundaryTests',
 'modTestSectionRecipes.RunRecipeRuleTests','modTestSectionRecipes.RunRecipeDefinitionTests',
 'modTestRecipeOperations.RunRecipeOperationTests','modTestRecipeOperations.RunRecipeDiagnosticTests',
 'modTestRecipeAnnotations.RunRecipeAnnotationTests','modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests',
 'modTestGeometryReview.RunRoundedEndpointTests','modTestGeometryReview.RunGeometryReviewTests',
 'modTestSectionRecipes.RunRoundedRecipeEquilibriumTests','modTestGeometryReview.RunRebarLabelBoundaryTests')
foreach ($mode in @('No','Yes')) {
    $label=if ($mode -eq 'No') {'Off'} else {'On'}
    & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/Full_'+$label+'.txt') -FixtureGeometryType RectSet -TimeoutSeconds 10800
    if ($LASTEXITCODE -ne 0) {throw ('Full failed: '+$label)}
    & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/Supplement_'+$label+'.txt') -Macro ($macros -join ',') -TimeoutSeconds 900
    if ($LASTEXITCODE -ne 0) {throw ('Supplement failed: '+$label)}
}
'FULL_AND_SUPPLEMENT_ON_OFF_COMPLETED'
