$ErrorActionPreference='Stop'
$taskDir='docs/regression/GeometryFull_2026-10-13'
function ReadJson($name) {Get-Content -LiteralPath ($taskDir+'/'+$name) -Raw -Encoding UTF8 | ConvertFrom-Json}
$taskC=ReadJson 'FinalReleaseCandidate.json'
$taskA=ReadJson 'FINAL_ACCEPTANCE_EVIDENCE.json'
$taskF=ReadJson 'FinalFullEvidence.json'
$taskS=ReadJson $taskC.source
$taskD=ReadJson $taskC.data
$taskH=ReadJson 'FinalHelp/HelpEvidence.json'
$taskST=@(ReadJson $taskC.structure)
$taskNB=ReadJson $taskC.nativeBridge
$taskLB=ReadJson $taskC.lambdaBridge
$taskPB=ReadJson $taskC.profileBridge
$taskStandalone=ReadJson $taskC.standalone
[ordered]@{Candidate=$taskC;Acceptance=$taskA.status;Full=$taskF.status;ReportCount=$taskF.reports.Count;
 SourcePassed=$taskS.AllPassed;Actual=$taskS.ActualComponents;Repository=$taskS.RepositoryComponents;
 DataStatus=$taskD.status;DataCells=$taskD.userCellsChecked;HelpStatus=$taskH.Status;Idempotent=$taskH.Idempotent;Reopen=$taskH.ReopenText;
 StructureCount=$taskST.Count;StructureType=$taskST[0].GetType().FullName;StructureFailed=@($taskST | Where-Object {-not $_.Passed}).Count;
 NativeBridge=$taskNB;LambdaBridge=$taskLB;ProfileBridge=$taskPB;Standalone=$taskStandalone} | ConvertTo-Json -Depth 5
