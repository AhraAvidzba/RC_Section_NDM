﻿# Известный cleanup SP35_TEST_SNAPSHOT в собственной readonly test-копии.
$ErrorActionPreference='Stop'
$owned=Get-Process -Id 14708
if ($owned.StartTime.ToUniversalTime().Ticks -ne 639274392206201749) {throw 'Domain Excel identity mismatch'}
Add-Type @"
using System;using System.Text;using System.Runtime.InteropServices;
public class OwnedSheetDelete {
 public delegate bool E(IntPtr h,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumWindows(E e,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumChildWindows(IntPtr h,E e,IntPtr p);
 [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetWindowText(IntPtr h,StringBuilder b,int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetClassName(IntPtr h,StringBuilder b,int n);
 [DllImport("user32.dll")]public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 public static int Confirm(uint wanted){int count=0;EnumWindows((h,p)=>{uint id;GetWindowThreadProcessId(h,out id);if(id!=wanted)return true;
 var c=new StringBuilder(100);var t=new StringBuilder(300);GetClassName(h,c,100);GetWindowText(h,t,300);if(c.ToString()!="#32770"||t.ToString()!="Microsoft Excel")return true;
 string body="";IntPtr button=IntPtr.Zero;EnumChildWindows(h,(ch,cp)=>{var b=new StringBuilder(2000);GetWindowText(ch,b,2000);body+=b.ToString();if(b.ToString()=="Удалить")button=ch;return true;},IntPtr.Zero);
 if(body.Contains("Microsoft Excel удалит лист без возможности восстановления. Продолжить?")&&button!=IntPtr.Zero){if(!PostMessage(button,0xF5,IntPtr.Zero,IntPtr.Zero))throw new Exception("Cannot confirm test cleanup");count++;}return true;},IntPtr.Zero);return count;}
}
"@
$count=[OwnedSheetDelete]::Confirm(14708)
if ($count -ne 1) {throw ('Expected exactly one known sheet cleanup prompt, found '+$count)}
Add-Content -LiteralPath 'docs/regression/GeometryFull_2026-10-13/DialogInterventions.txt' -Encoding UTF8 -Value ((Get-Date).ToUniversalTime().ToString('o')+'; Domain_Off.txt; Excel14708 ticks639274392206201749; confirmed deletion of test-created SP35_TEST_SNAPSHOT in readonly temporary fixture after source inspection')
