# Standalone ValidationPlan cases not called by standard aggregators.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$macros=@('modTestCapacitySolver.RunAudit03UltimateContracts',
 'modTestCapacitySolver.RunCapacityMomentMeritTests',
 'modTestCapacitySolver.RunLimitGuessScalingTests',
 'modTestCapacitySolver.RunBracketFinalizationRecoveryTests',
 'modTestBatchCalculation.RunSavedCrackLambdaToleranceTests',
 'modTestConfiguration.RunAudit03LambdaSettingsTests',
 'modTestWorkbookInterface.RunExecutionReportFormattingTests')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/FinalReady.xlsm') -Mode $mode -ReportPath ($dir+'/FinalValidationPlan_'+$label+'.txt') -FixtureGeometryType RectSet -Macro ($macros -join ',') -TimeoutSeconds 900 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('ValidationPlan standalone sets failed: '+$label)}
}
