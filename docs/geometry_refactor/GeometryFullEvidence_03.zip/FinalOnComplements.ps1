# Remaining ON supplements on the corrected immutable candidate.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$macros=@('modTestDeclarativeGeometry.RunCoreGeometryTests','modTestGeometryQuery.RunGeometryQueryTests',
 'modTestSectionRecipes.RunWorkbookRecipeInputTests','modTestSectionRecipes.RunRecipeMeshBoundaryTests',
 'modTestSectionRecipes.RunRecipeRuleTests','modTestSectionRecipes.RunRecipeDefinitionTests',
 'modTestRecipeOperations.RunRecipeOperationTests','modTestRecipeOperations.RunRecipeDiagnosticTests',
 'modTestRecipeAnnotations.RunRecipeAnnotationTests','modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests',
 'modTestGeometryReview.RunRoundedEndpointTests','modTestGeometryReview.RunGeometryReviewTests',
 'modTestSectionRecipes.RunRoundedRecipeEquilibriumTests','modTestGeometryReview.RunRebarLabelBoundaryTests')
$extra=@('modTestGeometry.RunConcreteMeshCenterTests','modTestGeometryQuery.RunTangentClipRegressionTests',
 'modTestMaterialDiagrams.RunAsymmetricSteelStrengthTests','modTestCapacitySolver.RunCommonStrainLimitTests',
 'modTestCapacitySolver.RunSolverWorkStatsTests','modTestBatchCalculation.RunBatchWorkStatsTests',
 'modTestMaterialDiagrams.RunPlateauSlopeTests','modTestMaterialDiagrams.RunAudit03MaterialControlUnitsTests',
 'modTestBatchCalculation.RunPlateauResultsDiagramTests')
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/ReleaseLambdaFixed.xlsm') -Mode Yes -ReportPath ($dir+'/FinalSupplement_On.txt') -Macro ($macros -join ',') -TimeoutSeconds 900 -FailFast
if ($LASTEXITCODE -ne 0) {throw 'Final supplement ON failed.'}
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/ReleaseLambdaFixed.xlsm') -Mode Yes -ReportPath ($dir+'/FinalExtras_On.txt') -Macro ($extra -join ',') -TimeoutSeconds 900 -FailFast
if ($LASTEXITCODE -ne 0) {throw 'Final extras ON failed.'}
'FINAL_ON_COMPLEMENTS_COMPLETED'
