# Завершает только ещё не пройденные native-сценарии на release-книге.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$source=$dir+'/Release.xlsm'
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 $macros=@('RunRealAutoCADFarOriginTests','RunRealAutoCADFarCapacityTests','RunSP35WorkbookTests')
 if ($mode -eq 'Yes') {$macros=@('RunRealAutoCADContourTests')+$macros}
 foreach ($macro in $macros) {
  $args=@{SourceWorkbook=$source;ReportDirectory=($dir+'/NativeRelease_'+$macro+'_'+$label);Macro=$macro;Mode=$mode;LaunchInstalledAutoCAD=$true}
  if ($macro -eq 'RunRealAutoCADContourTests') {$args.AcquireInsideExcel=$true}
  & 'tools/build_workbook/Run-PostAudit03NativeCAD.ps1' @args
 }
}
'ALL_REMAINING_NATIVE_COMPLETED'
