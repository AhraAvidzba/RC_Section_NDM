# Повтор только native-части после startup COM refusal; остальные PASS не повторяются.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$source=$dir+'/FinalReady.xlsm'
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 foreach ($macro in @('RunRealAutoCADContourTests','RunRealAutoCADContourMeshTests','RunRealAutoCADFarOriginTests','RunRealAutoCADFarCapacityTests','RunSP35WorkbookTests')) {
  $args=@{SourceWorkbook=$source;ReportDirectory=($dir+'/FinalNativeRetry_'+$macro+'_'+$label);Macro=$macro;Mode=$mode;LaunchInstalledAutoCAD=$true}
  if ($macro -eq 'RunRealAutoCADContourTests') {$args.AcquireInsideExcel=$true}
  & 'tools/build_workbook/Run-PostAudit03NativeCAD.ps1' @args
 }
}
'FINAL_NATIVE_ON_OFF_COMPLETED'
