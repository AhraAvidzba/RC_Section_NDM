# Парные замеры одинаковых workflows и нативные изображения всех семей.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 foreach ($kind in @('Baseline','Current')) {
  $source=if ($kind -eq 'Baseline') {$dir+'/AuxiliaryModeBaseline.xlsm'} else {$dir+'/AuxiliaryModeFinal.xlsm'}
  $args=@{SourceWorkbook=$source;Mode=$mode;ReportPath=($dir+'/FinalWorkflow_'+$label+'_'+$kind+'.txt');Macro='modFinalGeometryChecks.MeasureFamilyWorkflow';TimeoutSeconds=600;FailFast=$true}
  $png=$dir+'/FinalPlots_'+$label+'_'+$kind
  New-Item -ItemType Directory -Force $png | Out-Null
  $args.MacroArgument1=(Resolve-Path -LiteralPath $png).Path
  & 'tools/build_workbook/Run-Audit03Watchdog.ps1' @args
  if ($LASTEXITCODE -ne 0) {throw ('Workflow failed: '+$label+'/'+$kind)}
  & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/FinalStagesMixed_'+$label+'_'+$kind+'.txt') -Macro 'modFinalGeometryChecks.MeasureFamilyStages,modFinalGeometryChecks.MeasureMixedWorkflow' -TimeoutSeconds 600 -FailFast
  if ($LASTEXITCODE -ne 0) {throw ('Staged/mixed workflow failed: '+$label+'/'+$kind)}
 }
 New-Item -ItemType Directory -Force ($dir+'/FinalPlotModes_'+$label) | Out-Null
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/AuxiliaryModeFinal.xlsm') -Mode $mode -ReportPath ($dir+'/FinalPlotModes_'+$label+'.txt') -Macro 'modFinalGeometryChecks.RunDirectedPlotModes' -MacroArgument1 ((Resolve-Path ($dir+'/FinalPlotModes_'+$label)).Path) -TimeoutSeconds 600 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('Plot modes failed: '+$label)}
}
