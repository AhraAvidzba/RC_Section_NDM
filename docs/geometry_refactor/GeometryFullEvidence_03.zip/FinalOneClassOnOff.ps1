﻿# Учебный тип добавляется только на копии: один recipe, одна регистрация.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$book=$dir+'/OneClassFinal.xlsm'
Copy-Item -LiteralPath ($dir+'/FinalReady.xlsm') -Destination $book
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $book -ModuleNames @('CSectionTypeRegistry','CSectionRecipeRoundedTrapezoid','modTestRoundedTrapezoidExample','modTestDeclarativeExamples') -ExampleFiles @('docs/geometry_refactor/examples/CSectionRecipeRoundedTrapezoid.cls','docs/geometry_refactor/examples/modTestRoundedTrapezoidExample.bas') -RecipeRegistration @('RoundedTrapezoid','CSectionRecipeRoundedTrapezoid','rngRoundedTrapezoidGeometry')
$ticks=(Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks
Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',($dir+'/WatchMergeDialogs.ps1'),'-RunnerId',$PID,'-RunnerTicks',$ticks,'-Directory',$dir) -RedirectStandardOutput ($dir+'/OneClassFinalWatcher.stdout.log') -RedirectStandardError ($dir+'/OneClassFinalWatcher.stderr.log')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $book -Mode $mode -ReportPath ($dir+'/OneClassFinalInputBuild_'+$label+'.txt') -Macro 'modTestRoundedTrapezoidExample.RunExampleBuildTests,modTestRoundedTrapezoidExample.RunExampleInputTests,modTestDeclarativeExamples.RunRoundedFrameExampleTests' -TimeoutSeconds 600 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('One-class input/build failed: '+$label)}
 foreach ($width in @('1200','1400')) {
  $png=$dir+'/OneClassFinalPlots_'+$label+'_'+$width
  New-Item -ItemType Directory -Force $png | Out-Null
  & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $book -Mode $mode -ReportPath ($dir+'/OneClassFinalWorkflow_'+$label+'_'+$width+'.txt') -Macro 'modTestRoundedTrapezoidExample.RunExampleWorkflow' -MacroArgument1 ((Resolve-Path -LiteralPath $png).Path) -MacroArgument2 $width -TimeoutSeconds 600 -VerifyResultsReopen -VerifyStatusReopen -FailFast
  if ($LASTEXITCODE -ne 0) {throw ('One-class workflow failed: '+$label+'/'+$width)}
 }
}
'ONE_CLASS_ON_OFF_COMPLETED'
