# Повтор полного набора после PASS адресных проверок. Отрицательные логи сохранены.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$gate=Get-Content -LiteralPath ($dir+'/RepairCommonInput.txt') -Raw -Encoding UTF8
if ($gate -notmatch 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' -or $gate -match '(?m)^FAIL:|failed=[1-9]|RUNTIME ERROR') {throw 'Common-input preflight is not a complete PASS.'}
$source=$dir+'/FinalReady.xlsm'
if (Test-Path -LiteralPath $source) {throw 'Immutable final input already exists.'}
Copy-Item -LiteralPath ($dir+'/ReadyHarnessV4.xlsm') -Destination $source
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $source -ModuleNames @('modSectionRecipeApiGuide')
& 'tools/build_workbook/Update-ReviewHelp.ps1' -WorkbookPath $source -ReportDirectory ($dir+'/FinalHelp')
$ticks=(Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks
[ordered]@{PID=$PID;StartTicks=$ticks;SourceSHA256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash;StartedUTC=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath ($dir+'/FinalFullDriverIdentity.json') -Encoding UTF8
Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',($dir+'/WatchMergeDialogs.ps1'),'-RunnerId',$PID,'-RunnerTicks',$ticks,'-Directory',$dir) -RedirectStandardOutput ($dir+'/FinalFullWatcher.stdout.log') -RedirectStandardError ($dir+'/FinalFullWatcher.stderr.log')
$macros=@('modTestDeclarativeGeometry.RunCoreGeometryTests','modTestGeometryQuery.RunGeometryQueryTests',
 'modTestSectionRecipes.RunWorkbookRecipeInputTests','modTestSectionRecipes.RunRecipeMeshBoundaryTests',
 'modTestSectionRecipes.RunRecipeRuleTests','modTestSectionRecipes.RunRecipeDefinitionTests',
 'modTestRecipeOperations.RunRecipeOperationTests','modTestRecipeOperations.RunRecipeDiagnosticTests',
 'modTestRecipeAnnotations.RunRecipeAnnotationTests','modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests',
 'modTestGeometryReview.RunRoundedEndpointTests','modTestGeometryReview.RunGeometryReviewTests',
 'modTestSectionRecipes.RunRoundedRecipeEquilibriumTests','modTestGeometryReview.RunRebarLabelBoundaryTests')
$extra=@('modTestGeometry.RunConcreteMeshCenterTests','modTestGeometryQuery.RunTangentClipRegressionTests',
 'modTestMaterialDiagrams.RunAsymmetricSteelStrengthTests','modTestCapacitySolver.RunCommonStrainLimitTests',
 'modTestCapacitySolver.RunSolverWorkStatsTests','modTestBatchCalculation.RunBatchWorkStatsTests',
 'modTestMaterialDiagrams.RunPlateauSlopeTests','modTestMaterialDiagrams.RunAudit03MaterialControlUnitsTests',
 'modTestBatchCalculation.RunPlateauResultsDiagramTests')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/FinalFull_'+$label+'.txt') -FixtureGeometryType RectSet -TimeoutSeconds 10800
 if ($LASTEXITCODE -ne 0) {throw ('Final full failed: '+$label)}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/FinalSupplement_'+$label+'.txt') -Macro ($macros -join ',') -TimeoutSeconds 900
 if ($LASTEXITCODE -ne 0) {throw ('Final supplement failed: '+$label)}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/FinalExtras_'+$label+'.txt') -Macro ($extra -join ',') -TimeoutSeconds 900
 if ($LASTEXITCODE -ne 0) {throw ('Final extras failed: '+$label)}
}
'FINAL_FULL_ON_OFF_COMPLETED'
