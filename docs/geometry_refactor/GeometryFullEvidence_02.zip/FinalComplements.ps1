# Все дополнения повторяются на текущем неизменяемом production-коде.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$source=$dir+'/FinalReady.xlsm'
$identity=Get-Content -LiteralPath ($dir+'/FinalFullDriverIdentity.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $identity.SourceSHA256) {throw 'Final full input fingerprint changed.'}
Copy-Item -LiteralPath $source -Destination ($dir+'/AuxiliaryFinal.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/AuxiliaryFinal.xlsm') -ModuleNames @('modFinalGeometryChecks') -ExampleFiles @('docs/geometry_refactor/examples/modFinalGeometryChecks.bas')
& ($dir+'/FinalDomainOnOff.ps1')
& ($dir+'/FinalFamilyOnOff.ps1')
foreach ($mode in @('Off','On')) {
 foreach ($code in @('SP35','SP63')) {
  & python 'tools/build_workbook/Compare-GeometrySnapshots.py' ($dir+'/FinalFamily_'+$code+'_'+$mode+'_Baseline.txt') ($dir+'/FinalFamily_'+$code+'_'+$mode+'_Current.txt') --exact --report ($dir+'/FinalFamily_'+$code+'_'+$mode+'_Equality.json')
  if ($LASTEXITCODE -ne 0) {throw ('Exact final family comparison failed: '+$code+'/'+$mode)}
 }
}
& ($dir+'/FinalOneClassOnOff.ps1')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 foreach ($macro in @('RunRealAutoCADContourTests','RunRealAutoCADContourMeshTests','RunRealAutoCADFarOriginTests','RunRealAutoCADFarCapacityTests','RunSP35WorkbookTests')) {
  $args=@{SourceWorkbook=$source;ReportDirectory=($dir+'/FinalNative_'+$macro+'_'+$label);Macro=$macro;Mode=$mode;LaunchInstalledAutoCAD=$true}
  if ($macro -eq 'RunRealAutoCADContourTests') {$args.AcquireInsideExcel=$true}
  & 'tools/build_workbook/Run-PostAudit03NativeCAD.ps1' @args
 }
}
'FINAL_COMPLEMENTS_COMPLETED'
