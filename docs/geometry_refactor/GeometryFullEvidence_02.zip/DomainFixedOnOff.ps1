﻿# Независимые suite; native СП35 workbook вынесен в owned-CAD запуск.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$source=$dir+'/ReadyHarnessFixed.xlsm'
$macros=@('modTestContourMesh.RunContourMeshTests','modTestAutoCADContours.RunAutoCADContourTests',
 'modTestAutoCADContours.RunPostAudit03ContourSnapshotTests','modTestCrackWidth.RunCrackGeometryTests',
 'modTestSP35CrackWidth.RunSP35PipelineTests',
 'modTestSP35CrackWidth.RunSP35FormulaTests','modTestSP35CrackWidth.RunSP35LocalOpeningTests',
 'modTestSP35CrackWidth.RunSP35PreparationTests','modTestSP35CrackWidth.RunSP35NeighborSettingsTests',
 'modTestSP35CrackWidth.RunSP35EndToEndTests','modTestAutoCADConfig.RunAudit03CircleTranslationStateTests',
 'modTestPlotConfig.RunCrackAnnotationPlotTests','modTestPlotConfig.RunAudit03ContourArcTests',
 'modTestPlotConfig.RunAudit03NamedAnnotationTests','modTestPlotConfig.RunAudit03AutoPlotTests',
 'modTestPlotConfig.RunAudit03SnapshotMetadataTests','modTestPerformance.RunPerformanceStorageTests',
 'modTestPerformance.RunPerformanceNumericTests','modTestPerformance.RunPerformancePreparationTests',
 'modTestPerformance.RunPerformanceBatchIsolationTests','modTestPerformance.RunPerformanceExportCacheTests')
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/DomainFixed_'+$label+'.txt') -FixtureGeometryType RectSet -Macro ($macros -join ',') -TimeoutSeconds 1800 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('Domain failed: '+$label)}
}
