# Снимки девяти семей и все применимые этапы по обеим нормам и режимам.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
foreach ($mode in @('No','Yes')) {
 $label=if ($mode -eq 'No') {'Off'} else {'On'}
 foreach ($code in @('SP35','SP63')) {
  foreach ($kind in @('Baseline','Current')) {
   $source=if ($kind -eq 'Baseline') {$dir+'/AuxiliaryBaseline.xlsm'} else {$dir+'/Auxiliary.xlsm'}
   & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode $mode -ReportPath ($dir+'/Family_'+$code+'_'+$label+'_'+$kind+'.txt') -Macro 'modTestShapeArchitecture.DumpShapeCalculationSnapshot' -MacroArgument1 $code -TimeoutSeconds 1800 -FailFast
   if ($LASTEXITCODE -ne 0) {throw ('Family snapshot failed: '+$code+'/'+$label+'/'+$kind)}
  }
  & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/Auxiliary.xlsm') -Mode $mode -ReportPath ($dir+'/FamilyComplement_'+$code+'_'+$label+'.txt') -Macro 'modFinalGeometryChecks.RunFamilyComplement' -MacroArgument1 $code -TimeoutSeconds 1800 -FailFast
  if ($LASTEXITCODE -ne 0) {throw ('Family complement failed: '+$code+'/'+$label)}
 }
 & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook ($dir+'/Auxiliary.xlsm') -Mode $mode -ReportPath ($dir+'/SP35Projection_'+$label+'.txt') -Macro 'modFinalGeometryChecks.RunSP35ProjectionFixture' -TimeoutSeconds 300 -FailFast
 if ($LASTEXITCODE -ne 0) {throw ('SP35 projection failed: '+$label)}
}
