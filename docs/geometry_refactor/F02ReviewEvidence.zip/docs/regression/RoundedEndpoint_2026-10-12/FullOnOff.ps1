﻿$ErrorActionPreference='Stop'
$failed=$false
foreach ($mode in @('No','Yes')) {
    $label=if ($mode -eq 'No') {'Off'} else {'On'}
    & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/Ready.xlsm' -Mode $mode -ReportPath ('docs/regression/RoundedEndpoint_2026-10-12/Full_'+$label+'.txt') -FixtureGeometryType RectSet -TimeoutSeconds 10800
    if ($LASTEXITCODE -ne 0) {$failed=$true}
    Write-Output ('FULL_MODE_COMPLETED: '+$label+'; exit='+$LASTEXITCODE)
    & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/Ready.xlsm' -Mode $mode -ReportPath ('docs/regression/RoundedEndpoint_2026-10-12/Supplement_'+$label+'.txt') -Macro 'modTestDeclarativeGeometry.RunCoreGeometryTests,modTestGeometryQuery.RunGeometryQueryTests,modTestSectionRecipes.RunWorkbookRecipeInputTests,modTestSectionRecipes.RunRecipeMeshBoundaryTests,modTestSectionRecipes.RunRecipeRuleTests,modTestSectionRecipes.RunRecipeDefinitionTests,modTestRecipeOperations.RunRecipeOperationTests,modTestRecipeOperations.RunRecipeDiagnosticTests,modTestRecipeAnnotations.RunRecipeAnnotationTests,modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests,modTestGeometryReview.RunRoundedEndpointTests,modTestGeometryReview.RunGeometryReviewTests,modTestSectionRecipes.RunRoundedRecipeEquilibriumTests' -TimeoutSeconds 900
    if ($LASTEXITCODE -ne 0) {$failed=$true}
    Write-Output ('SUPPLEMENT_MODE_COMPLETED: '+$label+'; exit='+$LASTEXITCODE)
}
if ($failed) {exit 1}

