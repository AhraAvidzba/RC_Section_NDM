"""Проверяет только адресную подготовку к аудиту; full остаётся отложенным."""
from pathlib import Path
import hashlib, json, re
root = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
specs = {
    'LabelsFinal.txt': ['modTestGeometryReview.RunRebarLabelBoundaryTests'],
    'F02Final.txt': ['modTestGeometryReview.RunRoundedEndpointTests'],
    'AnnotationFinal.txt': ['modTestRecipeAnnotations.RunRecipeAnnotationTests', 'modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests', 'modTestGeometryReview.RunGeometryReviewTests', 'modTestSectionRecipes.RunRoundedRecipeEquilibriumTests', 'modTestGeometryReview.RunRoundedOrdinarySnapshots'],
    'LabelPreviewFinal_Circle.txt': ['modTestShapeArchitecture.DumpShapePreviewSnapshot'],
    'LabelPreviewFinal_HollowOffset.txt': ['modTestShapeArchitecture.DumpShapePreviewSnapshot'],
}
reports = []
for name, expected in specs.items():
    path = root / name
    text = path.read_text(encoding='utf-8-sig')
    source = re.search(r'^SOURCE_SHA256: (\w+)', text, re.M)
    finishes = re.findall(r'^SUITE_FINISHED: ([^;]+);', text, re.M)
    totals = re.findall(r'^TOTAL[^\r\n]*?passed=(\d+); failed=(\d+)', text, re.M)
    failures = re.findall(r'^(?:FAIL:|RUNTIME ERROR|WATCHDOG_FAILURE|SCRIPT ERROR).*$', text, re.M)
    passed = finishes == expected and not failures and all(int(f) == 0 for _, f in totals) and source and source[1].lower() == sha(root/'Review30Ready.xlsm') and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    if 'Preview' not in name: passed = passed and len(totals) == len(expected) and all(int(p) > 0 for p, _ in totals)
    reports.append({'name': name, 'status': 'PASS' if passed else 'FAIL', 'suiteFinishes': finishes,
                    'passedAssertions': sum(int(p) for p, _ in totals), 'failedAssertions': sum(int(f) for _, f in totals),
                    'sourceSHA256': source[1].lower() if source else None, 'reportSHA256': sha(path), 'failures': failures})
fixtures = ('RoundedSimple\t', 'RoundedTapered\t', 'RoundedMixed\t', 'RoundedMixedLeft\t')
def records(path): return [s for s in path.read_text(encoding='utf-8-sig').splitlines() if s.startswith(fixtures)]
before, after = records(root/'OrdinaryBefore.txt'), records(root/'AnnotationFinal.txt')
ordinary = {'status': 'PASS' if before == after and len(before) == 7958 else 'FAIL', 'records': len(before), 'actualRecords': len(after), 'exactNumericAndTextEquality': before == after}
(root/'OrdinaryReviewEquality.json').write_text(json.dumps(ordinary, indent=2)+'\n', encoding='utf-8')
result = {'status': 'PASS' if all(r['status'] == 'PASS' for r in reports) and ordinary['status'] == 'PASS' else 'FAIL',
          'purpose': 'EXTERNAL_CODE_REVIEW', 'fullAcceptance': 'DEFERRED_BY_USER', 'reports': reports,
          'passedAssertions': sum(r['passedAssertions'] for r in reports), 'failedAssertions': sum(r['failedAssertions'] for r in reports),
          'ordinaryRecords': ordinary, 'notes': ['Полные on/off остановлены пользователем, push отложен.', 'Ранние неуспешные LabelsDirected: исправлены предположения test harness о форме массива координат и уникальности ID аннотации, production для этого не менялся.']}
(root/'DirectedCodeReviewEvidence.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k: result[k] for k in ('status', 'purpose', 'fullAcceptance', 'passedAssertions', 'failedAssertions')}))
if result['status'] != 'PASS': raise SystemExit(1)
