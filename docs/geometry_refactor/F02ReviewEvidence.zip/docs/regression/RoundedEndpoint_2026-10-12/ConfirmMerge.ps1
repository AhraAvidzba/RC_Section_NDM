﻿$ErrorActionPreference='Stop'
$testProcess=Get-Process -Id 30860
if ($testProcess.ProcessName -ne 'EXCEL' -or $testProcess.StartTime.ToUniversalTime().Ticks -ne 639274318137589417) {throw 'Owned Excel identity mismatch'}
Add-Type @"
using System;using System.Text;using System.Runtime.InteropServices;
public class EndpointMergeDialog {
 public delegate bool EnumProc(IntPtr h,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumWindows(EnumProc cb,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumChildWindows(IntPtr h,EnumProc cb,IntPtr p);
 [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")]public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 public static int Confirm(uint wanted) {
 int count=0;EnumWindows((h,p)=>{uint id;GetWindowThreadProcessId(h,out id);if(id!=wanted)return true;
 var title=new StringBuilder(512);var cls=new StringBuilder(128);GetWindowText(h,title,512);GetClassName(h,cls,128);
 if(cls.ToString()!="#32770"||title.ToString()!="Microsoft Excel")return true;
 string body="";EnumChildWindows(h,(ch,cp)=>{var s=new StringBuilder(2048);GetWindowText(ch,s,2048);body+=s.ToString();return true;},IntPtr.Zero);
 if(body.Contains("В объединенной ячейке сохраняется только значение из верхней левой ячейки диапазона")||body.Contains("Merging cells only keeps the upper-left value")){
 if(!PostMessage(h,0x111,new IntPtr(1),IntPtr.Zero))throw new Exception("Cannot confirm known merge warning");
 Console.WriteLine("CONFIRMED_TEST_ONLY_MERGE_WARNING: pid="+id+"; hwnd="+h);count++;}
 return true;},IntPtr.Zero);return count;
 }
}
"@
$count=[EndpointMergeDialog]::Confirm(30860)
if ($count -ne 1) {throw ('Expected one known merge dialog, found '+$count)}
Add-Content -LiteralPath 'docs/regression/RoundedEndpoint_2026-10-12/DialogInterventions.txt' -Encoding UTF8 -Value ((Get-Date).ToUniversalTime().ToString('o')+'; Full_Off; Excel30860 ticks639274318137589417; accepted one known merge warning in read-only temporary fixture; production unchanged')
