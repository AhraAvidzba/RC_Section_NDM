﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/OrdinaryBaseline.xlsm' -ModuleNames @('modTestGeometryReview') -EntryPointNames @('RunRoundedOrdinarySnapshots')
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/OrdinaryBaseline.xlsm' -Mode No -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/OrdinaryBefore.txt' -Macro 'modTestGeometryReview.RunRoundedOrdinarySnapshots' -TimeoutSeconds 300
