﻿$ErrorActionPreference='Stop'
$runnerId=25216
$runnerTicks=(Get-Process -Id $runnerId).StartTime.ToUniversalTime().Ticks
$directory=(Resolve-Path -LiteralPath 'docs/regression/RoundedEndpoint_2026-10-12').Path
$native=[regex]::Match((Get-Content -LiteralPath (Join-Path $directory 'ConfirmMerge.ps1') -Raw),'(?s)Add-Type @"\r?\n(.*?)\r?\n"@').Groups[1].Value
if (-not $native) {throw 'Known native dialog handler missing'}
Add-Type $native
while ($true) {
    $owner=Get-Process -Id $runnerId -ErrorAction SilentlyContinue
    if (-not $owner -or $owner.StartTime.ToUniversalTime().Ticks -ne $runnerTicks) {break}
    foreach ($name in @('Full_Off.txt','Full_On.txt','Supplement_Off.txt','Supplement_On.txt')) {
        $path=Join-Path $directory $name
        if (-not (Test-Path -LiteralPath $path)) {continue}
        $head=@(Get-Content -LiteralPath $path -TotalCount 8)
        $fixtureLine=@($head | Where-Object {$_ -like 'FIXTURE: *'})[0]
        if (-not $fixtureLine -or $fixtureLine -notlike '*\Temp\RC_NDM_ModeSuite_*\RC_Section_NDM.xlsm') {continue}
        $identity=@($head | Where-Object {$_ -match '^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$'})[0]
        if ($identity -match '^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$') {
            $excelId=[int]$Matches[1];$excelTicks=[long]$Matches[2]
            $owned=Get-Process -Id $excelId -ErrorAction SilentlyContinue
            if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $excelTicks) {
                $count=[EndpointMergeDialog]::Confirm($excelId)
                if ($count) {Add-Content -LiteralPath (Join-Path $directory 'DialogInterventions.txt') -Encoding UTF8 -Value ((Get-Date).ToUniversalTime().ToString('o')+'; '+$name+'; Excel'+$excelId+' ticks'+$excelTicks+'; known merge warning confirmed in temporary fixture; count='+$count)}
            }
        }
    }
    Start-Sleep -Milliseconds 50
}
'OWNED_TEST_DIALOG_WATCHER_COMPLETED'

