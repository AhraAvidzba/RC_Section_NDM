"""Проверяет завершённость каждого полного режима по фактическому native-журналу."""
from pathlib import Path
import json,re,hashlib
root=Path(__file__).resolve().parent
expected_full=['modTestGeometry.RunGeometryTests','modTestMaterialDiagrams.RunMaterialDiagramTests','modTestSectionSolver.RunSectionSolverTests','modTestCapacitySolver.RunCapacitySolverTests','modTestCrackWidth.RunCrackWidthTests','modTestBatchCalculation.RunBatchCalculationTests','modTestWorkbookInterface.RunWorkbookInterfaceTests','modTestRegressionBaseline.RunRegressionBaselineTests']
expected_supp=['modTestDeclarativeGeometry.RunCoreGeometryTests','modTestGeometryQuery.RunGeometryQueryTests','modTestSectionRecipes.RunWorkbookRecipeInputTests','modTestSectionRecipes.RunRecipeMeshBoundaryTests','modTestSectionRecipes.RunRecipeRuleTests','modTestSectionRecipes.RunRecipeDefinitionTests','modTestRecipeOperations.RunRecipeOperationTests','modTestRecipeOperations.RunRecipeDiagnosticTests','modTestRecipeAnnotations.RunRecipeAnnotationTests','modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests','modTestGeometryReview.RunRoundedEndpointTests','modTestGeometryReview.RunGeometryReviewTests','modTestSectionRecipes.RunRoundedRecipeEquilibriumTests']
reports=[]
for mode in ['Off','On']:
    for prefix,expected in [('Full',expected_full),('Supplement',expected_supp)]:
        name=f'{prefix}_{mode}.txt'; path=root/name
        if not path.exists(): reports.append({'name':name,'status':'NOT_STARTED'}); continue
        text=path.read_text(encoding='utf-8-sig'); finished=re.findall(r'^SUITE_FINISHED: ([^;]+); (.+)$',text,re.M)
        started=re.findall(r'^SUITE_STARTED: ([^;]+); (.+)$',text,re.M)
        totals=re.findall(r'^(TOTAL[^\r\n]*?passed=(\d+); failed=(\d+)[^\r\n]*)',text,re.M)
        failures=re.findall(r'^(?:FAIL:|RUNTIME ERROR|WATCHDOG_FAILURE|SCRIPT ERROR|ABORTED_FOR_).*$',text,re.M)
        completed='WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
        source=re.search(r'^SOURCE_SHA256: (\w+)',text,re.M)
        elapsed=None
        if len(finished)==len(expected):
            from datetime import datetime
            elapsed=(datetime.fromisoformat(finished[-1][1].strip())-datetime.fromisoformat(started[0][1].strip())).total_seconds()
        passed=completed and [x[0] for x in finished]==expected and not failures and totals and all(int(x[2])==0 for x in totals)
        stopped='STOPPED_BY_USER_FOR_CODE_REVIEW:' in text
        reports.append({'name':name,'status':'STOPPED_BY_USER' if stopped else 'PASS' if passed else 'FAIL' if completed or failures else 'RUNNING','expectedSuites':len(expected),'finishedSuites':len(finished),'passedAssertions':sum(int(x[1]) for x in totals),'failedAssertions':sum(int(x[2]) for x in totals),'failures':failures,'suiteStarts':started,'suiteFinishes':finished,'elapsedSeconds':elapsed,'sourceSHA256':source[1].lower() if source else None,'reportSHA256':hashlib.sha256(path.read_bytes()).hexdigest()})
result={'status':'PASS' if all(x['status']=='PASS' for x in reports) else 'INCOMPLETE','reports':reports,'note':'Счётчики режимов приведены раздельно. Явный On в настройке отдельных исторических fixtures сохранён штатным runner-ом; глобальный режим восстанавливается перед каждой suite.'}
(root/'FullOnOffEvidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'reports':[{k:x[k] for k in ['name','status','finishedSuites','passedAssertions','failedAssertions'] if k in x} for x in reports]}))
