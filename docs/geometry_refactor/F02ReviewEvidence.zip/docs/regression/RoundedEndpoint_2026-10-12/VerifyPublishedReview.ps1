$ErrorActionPreference='Stop'
$dir='docs/regression/RoundedEndpoint_2026-10-12'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath 'workbook/output/RC_Section_NDM.xlsm' -OutputPath ($dir+'/VBA_PublishedReview.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_PublishedReview.txt') -ReferenceExportPath ($dir+'/FreshBuild/VBA_Review30.txt') -ReportPath ($dir+'/SourceEqualityPublishedReview.json')
