﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/Candidate.xlsm' -ModuleNames @('modSectionRecipeApiGuide')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/Candidate.xlsm' -OutputPath 'docs/regression/RoundedEndpoint_2026-10-12/VBA_Candidate.txt'
