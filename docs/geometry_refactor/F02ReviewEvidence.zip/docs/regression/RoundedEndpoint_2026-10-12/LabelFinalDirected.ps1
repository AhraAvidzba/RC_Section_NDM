$ErrorActionPreference='Stop'
$source='docs/regression/RoundedEndpoint_2026-10-12/ReviewReady.xlsm'
$directory='docs/regression/RoundedEndpoint_2026-10-12'
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode No -ReportPath ($directory+'/AnnotationSnapshots.txt') -Macro 'modTestRecipeAnnotations.RunRecipeAnnotationTests,modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests,modTestGeometryReview.RunGeometryReviewTests,modTestSectionRecipes.RunRoundedRecipeEquilibriumTests,modTestGeometryReview.RunRoundedOrdinarySnapshots' -TimeoutSeconds 300 -FailFast
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
foreach ($fixture in @('Circle','HollowOffset')) {
    & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode No -ReportPath ($directory+'/LabelPreview_'+$fixture+'.txt') -Macro 'modTestShapeArchitecture.DumpShapePreviewSnapshot' -MacroArgument1 ((Resolve-Path ($directory+'/LabelPreview')).Path) -MacroArgument2 $fixture -TimeoutSeconds 120 -FailFast
    if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
}
