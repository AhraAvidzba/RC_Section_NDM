$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/ReviewReady.xlsm' -ModuleNames @('modTestGeometryReview','modSectionRecipeApiGuide')
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/ReviewReady.xlsm' -Mode No -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/LabelsAccepted.txt' -Macro 'modTestGeometryReview.RunRebarLabelBoundaryTests' -MacroArgument1 ((Resolve-Path 'docs/regression/RoundedEndpoint_2026-10-12/LabelPreview').Path) -TimeoutSeconds 300 -FailFast
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/ReviewReady.xlsm' -Mode No -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/F02LabelsAccepted.txt' -Macro 'modTestGeometryReview.RunRoundedEndpointTests' -MacroArgument1 ((Resolve-Path 'docs/regression/RoundedEndpoint_2026-10-12/LabelPreview').Path) -TimeoutSeconds 300 -FailFast
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
