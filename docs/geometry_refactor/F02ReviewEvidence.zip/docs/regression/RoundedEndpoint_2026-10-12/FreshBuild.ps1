﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Build-Workbook.ps1' -OutputPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/RC_Section_NDM.xlsm' -FormulaImageDirectory 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/formula_images'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/RC_Section_NDM.xlsm' -OutputPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/VBA_All_Code.txt'
