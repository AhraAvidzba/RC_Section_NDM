﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/Candidate.xlsm' -ModuleNames @('modTestGeometryReview')
& 'tools/build_workbook/Run-Audit02ModeTests.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/Candidate.xlsm' -Mode No -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/Red.txt' -Macro @('modTestGeometryReview.RunRoundedEndpointTests') -FailFast
