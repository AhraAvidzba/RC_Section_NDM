$ErrorActionPreference='Stop'
Copy-Item -LiteralPath 'docs/regression/RoundedEndpoint_2026-10-12/Release.xlsm' -Destination 'docs/regression/RoundedEndpoint_2026-10-12/ReviewReady.xlsm'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/ReviewReady.xlsm' -ModuleNames @('CSectionGeometryQuery','CSectionPlotDataReader','CPlotAnnotationLayout','CSectionPlotter','modTestGeometryReview')
New-Item -ItemType Directory -Force 'docs/regression/RoundedEndpoint_2026-10-12/LabelPreview' | Out-Null
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/ReviewReady.xlsm' -Mode No -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/LabelsDirected.txt' -Macro 'modTestGeometryReview.RunRebarLabelBoundaryTests' -MacroArgument1 ((Resolve-Path 'docs/regression/RoundedEndpoint_2026-10-12/LabelPreview').Path) -TimeoutSeconds 300 -FailFast
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
