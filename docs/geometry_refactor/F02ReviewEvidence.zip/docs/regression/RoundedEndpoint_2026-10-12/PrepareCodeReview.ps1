$ErrorActionPreference='Stop'
$dir='docs/regression/RoundedEndpoint_2026-10-12'
Copy-Item -LiteralPath ($dir+'/ReviewReady.xlsm') -Destination ($dir+'/ReviewRelease.xlsm')
& 'tools/build_workbook/Update-ReviewHelp.ps1' -WorkbookPath ($dir+'/ReviewRelease.xlsm') -ReportDirectory ($dir+'/HelpCodeReview')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/FreshBuild/RC_Section_NDM.xlsm') -ModuleNames @('CSectionGeometryQuery','CSectionPlotDataReader','CPlotAnnotationLayout','CSectionPlotter','modTestGeometryReview','modSectionRecipeApiGuide')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/FreshBuild/RC_Section_NDM.xlsm') -OutputPath ($dir+'/FreshBuild/VBA_Review.txt')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/ReviewReady.xlsm') -OutputPath ($dir+'/VBA_ReviewReady.txt')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/ReviewRelease.xlsm') -OutputPath ($dir+'/VBA_Review.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_ReviewReady.txt') -ReferenceExportPath ($dir+'/FreshBuild/VBA_Review.txt') -ReportPath ($dir+'/SourceEqualityReviewReady.json')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_Review.txt') -ReferenceExportPath ($dir+'/FreshBuild/VBA_Review.txt') -ReportPath ($dir+'/SourceEqualityReview.json')
& 'tools/build_workbook/Validate-Workbook.ps1' -WorkbookPath ($dir+'/ReviewRelease.xlsm') -ReportPath ($dir+'/StructureReview.json') -UserConfiguredWorkbook
