﻿Add-Type @"
using System; using System.Text; using System.Runtime.InteropServices;
public class EndpointWindows {
 public delegate bool EnumProc(IntPtr h, IntPtr p);
 [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
 [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, EnumProc cb, IntPtr p);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
 [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
 public static void Inspect(uint wanted, bool dismiss) {
 EnumWindows((h,p)=>{uint id; GetWindowThreadProcessId(h,out id); if(id!=wanted)return true;
 var s=new StringBuilder(512);var c=new StringBuilder(128);GetWindowText(h,s,512);GetClassName(h,c,128);
 Console.WriteLine(h+" | "+c+" | "+s);
 if(c.ToString()=="#32770") {EnumChildWindows(h,(ch,cp)=>{var t=new StringBuilder(1024);GetWindowText(ch,t,1024);Console.WriteLine("  "+ch+" | "+t);return true;},IntPtr.Zero);
 if(dismiss)SendMessage(h,0x100,new IntPtr(13),IntPtr.Zero);}
 return true;},IntPtr.Zero); }
}
"@
[EndpointWindows]::Inspect(30060,$true)
