﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/Ready.xlsm' -ModuleNames @('modTestDeclarativeGeometry')
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook 'docs/regression/RoundedEndpoint_2026-10-12/Ready.xlsm' -Mode No -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/CoreAccepted.txt' -Macro 'modTestDeclarativeGeometry.RunCoreGeometryTests,modTestRecipeOperations.RunRecipeOperationTests,modTestRecipeOperations.RunRecipeDiagnosticTests' -TimeoutSeconds 300 -FailFast
