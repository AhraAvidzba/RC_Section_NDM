﻿$ErrorActionPreference='Stop'
. 'tools/build_workbook/SettingsCatalog.ps1'
$areas=@(Get-WorkbookPrintAreas 'docs/regression/RoundedEndpoint_2026-10-12/Baseline/RC_Section_NDM.xlsm')
Restore-WorkbookPrintAreas 'docs/regression/RoundedEndpoint_2026-10-12/Ready.xlsm' $areas
Write-Output ('PRINT_AREAS_RESTORED: '+$areas.Count)
