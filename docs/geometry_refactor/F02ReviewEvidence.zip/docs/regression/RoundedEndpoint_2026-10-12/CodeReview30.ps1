$ErrorActionPreference='Stop'
$dir='docs/regression/RoundedEndpoint_2026-10-12'
$source=$dir+'/Review30Ready.xlsm'
Copy-Item -LiteralPath ($dir+'/ReviewReady.xlsm') -Destination $source
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $source -ModuleNames @('CPlotAnnotationLayout','CSectionPlotter','modTestGeometryReview')
& 'tools/build_workbook/Update-ReviewHelp.ps1' -WorkbookPath $source -ReportDirectory ($dir+'/HelpCodeReview30') -HalveDefaultRebarLabelOffset
New-Item -ItemType Directory -Force ($dir+'/LabelPreview30') | Out-Null
foreach ($entry in @(@('LabelsFinal','modTestGeometryReview.RunRebarLabelBoundaryTests'),@('F02Final','modTestGeometryReview.RunRoundedEndpointTests'))) {
    & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode No -ReportPath ($dir+'/'+$entry[0]+'.txt') -Macro $entry[1] -MacroArgument1 ((Resolve-Path ($dir+'/LabelPreview30')).Path) -TimeoutSeconds 300 -FailFast
    if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
}
& 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode No -ReportPath ($dir+'/AnnotationFinal.txt') -Macro 'modTestRecipeAnnotations.RunRecipeAnnotationTests,modTestRecipeAnnotations.RunRecipeAnnotationSnapshotTests,modTestGeometryReview.RunGeometryReviewTests,modTestSectionRecipes.RunRoundedRecipeEquilibriumTests,modTestGeometryReview.RunRoundedOrdinarySnapshots' -TimeoutSeconds 300 -FailFast
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
foreach ($fixture in @('Circle','HollowOffset')) {
    & 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $source -Mode No -ReportPath ($dir+'/LabelPreviewFinal_'+$fixture+'.txt') -Macro 'modTestShapeArchitecture.DumpShapePreviewSnapshot' -MacroArgument1 ((Resolve-Path ($dir+'/LabelPreview30')).Path) -MacroArgument2 $fixture -TimeoutSeconds 120 -FailFast
    if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
}
Copy-Item -LiteralPath $source -Destination ($dir+'/Review30Release.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/FreshBuild/RC_Section_NDM.xlsm') -ModuleNames @('CPlotAnnotationLayout','CSectionPlotter','modTestGeometryReview')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/FreshBuild/RC_Section_NDM.xlsm') -OutputPath ($dir+'/FreshBuild/VBA_Review30.txt')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath $source -OutputPath ($dir+'/VBA_Review30Ready.txt')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/Review30Release.xlsm') -OutputPath ($dir+'/VBA_Review30.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_Review30Ready.txt') -ReferenceExportPath ($dir+'/FreshBuild/VBA_Review30.txt') -ReportPath ($dir+'/SourceEqualityReview30Ready.json')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_Review30.txt') -ReferenceExportPath ($dir+'/FreshBuild/VBA_Review30.txt') -ReportPath ($dir+'/SourceEqualityReview30.json')
& 'tools/build_workbook/Validate-Workbook.ps1' -WorkbookPath ($dir+'/Review30Release.xlsm') -ReportPath ($dir+'/StructureReview30.json') -UserConfiguredWorkbook
