from pathlib import Path
import subprocess, json
root=Path.cwd()
lines=subprocess.check_output(['git','rev-list','--objects','origin/codex/material-diagram-architecture..HEAD'],text=True,encoding='utf-8').splitlines()
checked=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize) %(rest)'],input='\n'.join(lines)+'\n',text=True,encoding='utf-8',capture_output=True,check=True).stdout.splitlines()
blobs=[]
for line in checked:
    fields=line.split(' ',3)
    if len(fields)>2 and fields[1]=='blob': blobs.append({'oid':fields[0],'size':int(fields[2]),'path':fields[3] if len(fields)>3 else ''})
r={'unpublishedCommits':int(subprocess.check_output(['git','rev-list','--count','origin/codex/material-diagram-architecture..HEAD'],text=True)),'blobBytes':sum(x['size'] for x in blobs),'largestBlobs':sorted(blobs,key=lambda x:x['size'],reverse=True)[:8],'above100MiB':[x for x in blobs if x['size']>100*1024**2]}
(root/'docs/regression/RoundedEndpoint_2026-10-12/PushPreflight.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:r[k] for k in ('unpublishedCommits','blobBytes','above100MiB')}))
