﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-ReviewHelp.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/Release.xlsm' -ReportDirectory 'docs/regression/RoundedEndpoint_2026-10-12/HelpAccepted'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/Release.xlsm' -OutputPath 'docs/regression/RoundedEndpoint_2026-10-12/VBA_Release.txt'
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath 'docs/regression/RoundedEndpoint_2026-10-12/VBA_Release.txt' -ReferenceExportPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/VBA_Final.txt' -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/SourceEqualityRelease.json'
