﻿$ErrorActionPreference='Stop'
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/RC_Section_NDM.xlsm' -ModuleNames @('modTestDeclarativeGeometry')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/RC_Section_NDM.xlsm' -OutputPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/VBA_Final.txt'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath 'docs/regression/RoundedEndpoint_2026-10-12/Ready.xlsm' -OutputPath 'docs/regression/RoundedEndpoint_2026-10-12/VBA_Final.txt'
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath 'docs/regression/RoundedEndpoint_2026-10-12/VBA_Final.txt' -ReferenceExportPath 'docs/regression/RoundedEndpoint_2026-10-12/FreshBuild/VBA_Final.txt' -ReportPath 'docs/regression/RoundedEndpoint_2026-10-12/SourceEqualityFinal.json'
