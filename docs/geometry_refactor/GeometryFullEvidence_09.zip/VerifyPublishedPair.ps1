# Read back the actual published workbook without macros, edits or Save.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
$book='workbook/output/RC_Section_NDM.xlsm'
$dump=$dir+'/VBA_PublishedHeaderCheck.txt'
$candidate=Get-Content -LiteralPath ($dir+'/FinalReleaseCandidate.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$publication=Get-Content -LiteralPath ($dir+'/Publication.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $publication.Published) {throw 'No successful publication record.'}
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath $book -OutputPath $dump
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath $dump -ReferenceExportPath ($dir+'/'+$candidate.dump) -ReportPath ($dir+'/PublishedSourceEquality.json')
& 'tools/build_workbook/Validate-Workbook.ps1' -WorkbookPath $book -ReportPath ($dir+'/PublishedStructure.json') -UserConfiguredWorkbook
& python 'tools/build_workbook/Verify-ReviewWorkbook.py' --before ($dir+'/Baseline/RC_Section_NDM.xlsm') --after $book --report ($dir+'/PublishedUserData.json')
if ($LASTEXITCODE -ne 0) {throw 'Published user-data verification failed.'}
& python 'tools/build_workbook/Verify-StandaloneHelp.py' --book $book --dump $dump --report ($dir+'/PublishedStandaloneHelp.json')
if ($LASTEXITCODE -ne 0) {throw 'Published Help verification failed.'}
$source=Get-Content -LiteralPath ($dir+'/PublishedSourceEquality.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$data=Get-Content -LiteralPath ($dir+'/PublishedUserData.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$help=Get-Content -LiteralPath ($dir+'/PublishedStandaloneHelp.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$structure=Get-Content -LiteralPath ($dir+'/PublishedStructure.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($check in $structure) {if ($check.Passed -isnot [bool]) {throw 'Published structure lacks Boolean checks.'}}
$bookHash=(Get-FileHash -LiteralPath $book -Algorithm SHA256).Hash.ToLowerInvariant()
$dumpHash=(Get-FileHash -LiteralPath 'workbook/output/VBA_All_Code.txt' -Algorithm SHA256).Hash.ToLowerInvariant()
if ($bookHash -ne $publication.WorkbookSHA256 -or $dumpHash -ne $publication.ExportSHA256 -or
 -not $source.AllPassed -or $source.ActualComponents -ne 149 -or $source.RepositoryComponents -ne 144 -or
 $data.status -ne 'REVIEW_XML_PRESERVATION_PASS' -or $data.userCellsChecked -ne 52003 -or
 $help.status -ne 'STANDALONE_HELP_PASS' -or $help.apiMembers -ne 275 -or
 $structure.Count -ne 27 -or @($structure | Where-Object {-not $_.Passed}).Count) {throw 'Actual published-pair gates failed.'}
foreach ($item in $publication.ForeignOutputFiles) {
 if ((Get-FileHash -LiteralPath $item.Path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.SHA256) {throw ('Unrelated output changed: '+$item.Path)}
}
[ordered]@{Status='PASS';WorkbookSHA256=$bookHash;AllCodeSHA256=$dumpHash;NativeComponents=149;
 SourceMatch=$true;UserCellsPreserved=52003;StructureChecks=27;APIMembers=275;ForeignOutputsPreserved=$true;
 ReadOnlyVerification=$true;CompletedUTC=(Get-Date).ToUniversalTime().ToString('o')} |
 ConvertTo-Json | Set-Content -LiteralPath ($dir+'/PublishedPairEvidence.json') -Encoding UTF8
'PUBLISHED_PAIR_READBACK_PASS'
