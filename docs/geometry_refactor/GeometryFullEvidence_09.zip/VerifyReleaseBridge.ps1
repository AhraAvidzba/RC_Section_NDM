# Доказывает единственный native-only harness delta относительно полного входа.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/Release.xlsm') -OutputPath ($dir+'/VBA_Release.txt')
Copy-Item -LiteralPath ($dir+'/FinalFreshReference.xlsm') -Destination ($dir+'/ReleaseReference.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/ReleaseReference.xlsm') -ModuleNames @('modTestContourMesh')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/ReleaseReference.xlsm') -OutputPath ($dir+'/VBA_ReleaseReference.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_Release.txt') -ReferenceExportPath ($dir+'/VBA_ReleaseReference.txt') -ReportPath ($dir+'/ReleaseSourceEquality.json')
& python 'tools/build_workbook/Verify-NativeHarnessBridge.py' --before-book ($dir+'/FinalReady.xlsm') --after-book ($dir+'/Release.xlsm') --before-dump ($dir+'/VBA_Final.txt') --after-dump ($dir+'/VBA_Release.txt') --report ($dir+'/NativeHarnessBridge.json')
if ($LASTEXITCODE -ne 0) {throw 'Native harness bridge failed.'}
'RELEASE_SOURCE_AND_BRIDGE_VERIFIED'
