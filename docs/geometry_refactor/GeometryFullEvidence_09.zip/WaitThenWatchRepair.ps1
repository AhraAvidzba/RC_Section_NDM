param([int]$RepairId,[long]$RepairTicks,[int]$PreviousId,[long]$PreviousTicks,[string]$Directory)
$ErrorActionPreference='Stop'
while ($true) {
 $repair=Get-Process -Id $RepairId -ErrorAction SilentlyContinue
 if (-not $repair -or $repair.StartTime.ToUniversalTime().Ticks -ne $RepairTicks) { 'REPAIR_ALREADY_TERMINAL'; exit 0 }
 $previous=Get-Process -Id $PreviousId -ErrorAction SilentlyContinue
 if (-not $previous -or $previous.StartTime.ToUniversalTime().Ticks -ne $PreviousTicks) {break}
 Start-Sleep -Seconds 2
}
& (Join-Path $Directory 'WatchMergeDialogs.ps1') -RunnerId $RepairId -RunnerTicks $RepairTicks -Directory $Directory
