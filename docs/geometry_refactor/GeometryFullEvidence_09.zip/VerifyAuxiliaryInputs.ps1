# Read-only native exports; these books only add the shared acceptance helper.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
foreach ($kind in @('Baseline','Final')) {
 & 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/Auxiliary'+$kind+'.xlsm') -OutputPath ($dir+'/VBA_Auxiliary'+$kind+'.txt')
}
