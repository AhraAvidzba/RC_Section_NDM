# Native equality and user-data gates of the final test-only oracle correction.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/ReleaseSnapshotFixed.xlsm') -OutputPath ($dir+'/VBA_SnapshotFixed.txt')
& python 'tools/build_workbook/Verify-ProfileSnapshotBridge.py' --before-book ($dir+'/ReleaseLambdaFixed.xlsm') --after-book ($dir+'/ReleaseSnapshotFixed.xlsm') --before-dump ($dir+'/VBA_LambdaFixed.txt') --after-dump ($dir+'/VBA_SnapshotFixed.txt') --report ($dir+'/ProfileSnapshotBridge.json')
if ($LASTEXITCODE -ne 0) {throw 'Snapshot oracle exact bridge failed.'}
Copy-Item -LiteralPath ($dir+'/LambdaFixedReference.xlsm') -Destination ($dir+'/SnapshotFixedReference.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/SnapshotFixedReference.xlsm') -ModuleNames @('modTestProfileConfig')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/SnapshotFixedReference.xlsm') -OutputPath ($dir+'/VBA_SnapshotFixedReference.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_SnapshotFixed.txt') -ReferenceExportPath ($dir+'/VBA_SnapshotFixedReference.txt') -ReportPath ($dir+'/SnapshotFixedSourceEquality.json')
& 'tools/build_workbook/Validate-Workbook.ps1' -WorkbookPath ($dir+'/ReleaseSnapshotFixed.xlsm') -ReportPath ($dir+'/SnapshotFixedStructure.json') -UserConfiguredWorkbook
& python 'tools/build_workbook/Verify-ReviewWorkbook.py' --before ($dir+'/Baseline/RC_Section_NDM.xlsm') --after ($dir+'/ReleaseSnapshotFixed.xlsm') --report ($dir+'/SnapshotFixedUserData.json')
if ($LASTEXITCODE -ne 0) {throw 'Snapshot candidate user data changed.'}
& python 'tools/build_workbook/Verify-StandaloneHelp.py' --book ($dir+'/ReleaseSnapshotFixed.xlsm') --dump ($dir+'/VBA_SnapshotFixed.txt') --report ($dir+'/SnapshotFixedStandaloneHelp.json')
if ($LASTEXITCODE -ne 0) {throw 'Snapshot candidate Help failed.'}
'SNAPSHOT_RELEASE_VERIFIED'
