﻿# Известные Merge и cleanup-листа: только собственные временные test-Excel.
param([int]$RunnerId,[long]$RunnerTicks,[string]$Directory)
$ErrorActionPreference='Stop'
Add-Type @"
using System;using System.Text;using System.Runtime.InteropServices;
public class FullRegressionMergeDialog {
 public delegate bool EnumProc(IntPtr h,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumWindows(EnumProc cb,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumChildWindows(IntPtr h,EnumProc cb,IntPtr p);
 [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll",SetLastError=true)]public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 public static int Confirm(uint wanted) {
 int count=0;EnumWindows((h,p)=>{uint id;GetWindowThreadProcessId(h,out id);if(id!=wanted)return true;
 var title=new StringBuilder(512);var cls=new StringBuilder(128);GetWindowText(h,title,512);GetClassName(h,cls,128);
 if(cls.ToString()!="#32770"||title.ToString()!="Microsoft Excel")return true;
 string body="";IntPtr deleteButton=IntPtr.Zero;EnumChildWindows(h,(ch,cp)=>{var s=new StringBuilder(2048);GetWindowText(ch,s,2048);body+=s.ToString();if(s.ToString()=="Удалить")deleteButton=ch;return true;},IntPtr.Zero);
 if(body.Contains("В объединенной ячейке сохраняется только значение из верхней левой ячейки диапазона")||body.Contains("Merging cells only keeps the upper-left value")){
 if(!PostMessage(h,0x111,new IntPtr(1),IntPtr.Zero)){Console.WriteLine("MISSED_TEST_ONLY_MERGE_WARNING: pid="+id+"; hwnd="+h+"; error="+Marshal.GetLastWin32Error());return true;}
 Console.WriteLine("CONFIRMED_TEST_ONLY_MERGE_WARNING: pid="+id+"; hwnd="+h);count++;}
 else if(body.Contains("Microsoft Excel удалит лист без возможности восстановления. Продолжить?")&&deleteButton!=IntPtr.Zero){
 if(!PostMessage(deleteButton,0xF5,IntPtr.Zero,IntPtr.Zero)){Console.WriteLine("MISSED_TEST_ONLY_SHEET_CLEANUP: pid="+id+"; hwnd="+h+"; error="+Marshal.GetLastWin32Error());return true;}
 Console.WriteLine("CONFIRMED_TEST_ONLY_SHEET_CLEANUP: pid="+id+"; hwnd="+h);count++;}
 return true;},IntPtr.Zero);return count;
 }
}
"@
while ($true) {
    $owner=Get-Process -Id $RunnerId -ErrorAction SilentlyContinue
    if (-not $owner -or $owner.StartTime.ToUniversalTime().Ticks -ne $RunnerTicks) {break}
    foreach ($report in @(Get-ChildItem -LiteralPath $Directory -Filter '*.txt')) {
        $head=@();$inputStream=$null;$inputReader=$null
        try {
            # Reader не запрещает runner-у перезаписать собственный progress-файл.
            $inputStream=[IO.File]::Open($report.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
            $inputReader=New-Object IO.StreamReader($inputStream,[Text.Encoding]::UTF8,$true)
            for ($n=0;$n -lt 8;$n++) {$line=$inputReader.ReadLine();if ($null -eq $line) {break};$head+=,$line}
        } catch {continue} finally {if ($inputReader) {$inputReader.Dispose()} elseif ($inputStream) {$inputStream.Dispose()}}
        $fixtureLine=@($head | Where-Object {$_ -like 'FIXTURE: *'})
        if (-not $fixtureLine.Count -or $fixtureLine[0] -notlike '*\Temp\RC_NDM_ModeSuite_*\RC_Section_NDM.xlsm') {continue}
        $identity=@($head | Where-Object {$_ -match '^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$'})
        if ($identity.Count -and $identity[0] -match '^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$') {
            $excelId=[int]$Matches[1];$excelTicks=[long]$Matches[2]
            $owned=Get-Process -Id $excelId -ErrorAction SilentlyContinue
            if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $excelTicks) {
                $count=[FullRegressionMergeDialog]::Confirm($excelId)
                if ($count) {
                    # Каждый watcher пишет отдельный журнал; прямой append
                    # исключает provider-ошибку и конфликт соседних наблюдателей.
                    $entry=(Get-Date).ToUniversalTime().ToString('o')+'; '+$report.Name+'; owned Excel'+$excelId+' ticks'+$excelTicks+'; known test-only merge/cleanup warning confirmed; count='+$count+[Environment]::NewLine
                    $entryBytes=[Text.Encoding]::UTF8.GetBytes($entry)
                    $entryStream=[IO.File]::Open((Join-Path $Directory ('DialogInterventions_'+$PID+'.txt')),[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
                    try {$entryStream.Write($entryBytes,0,$entryBytes.Length);$entryStream.Flush()} finally {$entryStream.Dispose()}
                }
            }
        }
    }
    Start-Sleep -Milliseconds 500
}
'OWNED_TEST_DIALOG_WATCHER_COMPLETED'
