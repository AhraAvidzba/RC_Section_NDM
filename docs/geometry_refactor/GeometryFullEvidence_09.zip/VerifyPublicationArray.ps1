$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
function ReadJson($name) {Get-Content -LiteralPath ($dir+'/'+$name) -Raw -Encoding UTF8 | ConvertFrom-Json}
$structure=ReadJson 'SnapshotFixedStructure.json'
$passed=($structure.Count -eq 27 -and @($structure | Where-Object {-not $_.Passed}).Count -eq 0)
$structure[0].Passed=$false
$rejected=($structure.Count -ne 27 -or @($structure | Where-Object {-not $_.Passed}).Count -gt 0)
if (-not $passed -or -not $rejected) {throw 'Structure array validation failed.'}
[ordered]@{Status='PASS';PowerShell=$PSVersionTable.PSVersion.ToString();Checks=27;RealProofAccepted=$passed;FalseRecordRejected=$rejected;
 FailedPublicationBeforeWrite=$true;OutputSHA256=(Get-FileHash -LiteralPath 'workbook/output/RC_Section_NDM.xlsm').Hash;
 BackupCreated=(Test-Path -LiteralPath ($dir+'/OriginalOutputBackup'))} | ConvertTo-Json | Set-Content -LiteralPath ($dir+'/PublisherArrayEvidence.json') -Encoding UTF8
'PUBLISHER_ARRAY_PASS_27_AND_REJECT_FALSE'
