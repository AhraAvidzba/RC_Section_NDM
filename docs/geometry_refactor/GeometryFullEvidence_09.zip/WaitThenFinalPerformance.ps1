# Изолированные замеры только после успешного завершения всех тяжёлых повторов.
$ErrorActionPreference='Stop'
while ($true) {
 $taskOwner=Get-Process -Id 2156 -ErrorAction SilentlyContinue
 if (-not $taskOwner -or $taskOwner.StartTime.ToUniversalTime().Ticks -ne 639274653594673842) {break}
 Start-Sleep -Seconds 3
}
$dir='docs/regression/GeometryFull_2026-10-13'
& python 'tools/build_workbook/Summarize-GeometryFull.py' --directory $dir --source ($dir+'/FinalReady.xlsm') --report ($dir+'/FinalFullEvidence.json')
if ($LASTEXITCODE -ne 0) {throw 'Completed full-scope acceptance must pass before isolated measurements.'}
& python 'tools/build_workbook/Verify-ValidationPlanCoverage.py' --directory $dir
if ($LASTEXITCODE -ne 0) {throw 'All29 ValidationPlan entries must pass before isolated measurements.'}
foreach ($taskId in @(19616,28932,14344,34704,15464)) {
 if (Get-Process -Id $taskId -ErrorAction SilentlyContinue) {throw ('Previous test process still exists: '+$taskId)}
}
& ($dir+'/FinalPerformanceAndPlots.ps1')
'FINAL_PERFORMANCE_AND_PLOTS_COMPLETED'
