# Exact native readback of the test-only correction and its independent source build.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/ReleaseLambdaFixed.xlsm') -OutputPath ($dir+'/VBA_LambdaFixed.txt')
& python 'tools/build_workbook/Verify-LambdaHarnessBridge.py' --before-book ($dir+'/Release.xlsm') --after-book ($dir+'/ReleaseLambdaFixed.xlsm') --before-dump ($dir+'/VBA_Release.txt') --after-dump ($dir+'/VBA_LambdaFixed.txt') --report ($dir+'/LambdaHarnessBridge.json')
if ($LASTEXITCODE -ne 0) {throw 'Exact lambda test bridge failed.'}
Copy-Item -LiteralPath ($dir+'/ReleaseReference.xlsm') -Destination ($dir+'/LambdaFixedReference.xlsm')
& 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath ($dir+'/LambdaFixedReference.xlsm') -ModuleNames @('modTestConfiguration')
& 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath ($dir+'/LambdaFixedReference.xlsm') -OutputPath ($dir+'/VBA_LambdaFixedReference.txt')
& 'tools/build_workbook/Compare-PerformanceVba.ps1' -ExportPath ($dir+'/VBA_LambdaFixed.txt') -ReferenceExportPath ($dir+'/VBA_LambdaFixedReference.txt') -ReportPath ($dir+'/LambdaFixedSourceEquality.json')
& 'tools/build_workbook/Validate-Workbook.ps1' -WorkbookPath ($dir+'/ReleaseLambdaFixed.xlsm') -ReportPath ($dir+'/LambdaFixedStructure.json') -UserConfiguredWorkbook
& python 'tools/build_workbook/Verify-ReviewWorkbook.py' --before ($dir+'/Baseline/RC_Section_NDM.xlsm') --after ($dir+'/ReleaseLambdaFixed.xlsm') --report ($dir+'/LambdaFixedUserData.json')
if ($LASTEXITCODE -ne 0) {throw 'Lambda candidate user data changed.'}
& python 'tools/build_workbook/Verify-StandaloneHelp.py' --book ($dir+'/ReleaseLambdaFixed.xlsm') --dump ($dir+'/VBA_LambdaFixed.txt') --report ($dir+'/LambdaFixedStandaloneHelp.json')
if ($LASTEXITCODE -ne 0) {throw 'Lambda candidate Help failed.'}
'LAMBDA_RELEASE_VERIFIED'
