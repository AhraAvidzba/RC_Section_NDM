# Дополняет native контуры реальной сеткой и расчётами на удалённых координатах.
$ErrorActionPreference='Stop'
$dir='docs/regression/GeometryFull_2026-10-13'
foreach ($macro in @('RunRealAutoCADContourMeshTests','RunRealAutoCADFarOriginTests','RunRealAutoCADFarCapacityTests')) {
 & 'tools/build_workbook/Run-PostAudit03NativeCAD.ps1' -SourceWorkbook ($dir+'/Ready.xlsm') -ReportDirectory ($dir+'/Native_'+$macro) -Macro $macro -LaunchInstalledAutoCAD
}
